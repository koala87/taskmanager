###############################################################################
# encoding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
����Ǩ��

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import logging
import threading
import datetime
import copy
import logging
reload(sys)
sys.setdefaultencoding('utf-8')

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "db_manager.settings")
from django.core.management import execute_from_command_line
sys.path.append('../common/db_manager')
import django

import horae.models
import django.contrib.auth.models
import common.models

class DelExpireRunhistory(object):
    def __init__(self):
        self.__delete_expire_runhistory()

    def __delete_expire_runhistory(self):
        try:
            cur = django.db.connection.cursor()
            sql = "select word ,attrs from interest_graphs_term where source_id in (select id from interest_graphs_dictsource where dict_id=11);"
            cur.execute(sql)
            rows = cur.fetchall()
            fd = open("./dict_word.txt", "w")
            for row in rows:
                fd.write("%s`%s\n" % (row[0], row[1]))
            fd.close()
        except exceptions.Exception as ex:
            error_info = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            print(error_info)
            return None

if __name__ == "__main__":
    task_move = DelExpireRunhistory()
