﻿###############################################################################
# encoding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
任务迁移

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import logging
import threading
import datetime
import copy
import logging
reload(sys)
sys.setdefaultencoding('utf-8')

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "db_manager.settings")
from django.core.management import execute_from_command_line
sys.path.append('../common/db_manager')
import django

import pymysql
import horae.models
import django.contrib.auth.models
import common.models

sys.path.append('../common')
import graph_group
import task_util
import no_block_sys_cmd
import linux_file_cmd
import pangu_command
import sm_mail

mail_list = 'xielei.xl@alibaba-inc.com'

class TaskMove(object):
    def __init__(self, config):
        self.__graph_mgr = graph_group.GraphGroup()
        self.__task_map = {}

    def move_handler(self):
        try:
            task_rows = self.__get_all_tasks()
            for row in task_rows:
                self.__task_map[str(row[0])] = row

            self.__show_diff_depend_info(task_rows)
            return True
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            print("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            print("ex:%s, trace:%s" % (
                str(ex), traceback.format_exc()))
            return False

    def __show_diff_depend_info(self, rows):
        subject = "Noah(诺亚)计算平台-依赖关系错误"
        for row in rows:
            prev_task_list = row[2].split(',')
            for id in prev_task_list:
                if id.strip() == '':
                    continue
                                
                if id.strip() not in self.__task_map:
                    content = "任务id:%s 不存在" % id.strip()
                    sm_mail.send(subject, content, mail_list, None)
                    continue

                pre_task_next_ids = self.__task_map[id.strip()][1].split(',')
                finded = False
                for pre_task_next_id in pre_task_next_ids:
                    if pre_task_next_id.strip() == '':
                        continue

                    if pre_task_next_id.strip() == str(row[0]):
                        finded = True
                        break
                if not finded:
                    content = ("prev has no next:%s:%s" % (str(self.__task_map[id.strip()]), str(row[0])))
                    sm_mail.send(subject, content, mail_list, None)

            next_task_list = row[1].split(',')
            for id in next_task_list:
                if id.strip() == '':
                    continue

                if id.strip() not in self.__task_map:
                    content = "任务id:%s 不存在" % id.strip()
                    sm_mail.send(subject, content, mail_list, None)
                    continue

                next_task_prev_ids = self.__task_map[id.strip()][2].split(',')
                finded = False
                for next_task_prev_id in next_task_prev_ids:
                    if next_task_prev_id.strip() == '':
                        continue

                    if next_task_prev_id.strip() == str(row[0]):
                        finded = True
                        break
                if not finded:
                    countent = ("next has no prev:%s:%s" % (str(self.__task_map[id.strip()]), str(row[0])))
                    sm_mail.send(subject, content, mail_list, None)

    def __get_all_tasks(self):
        try:
            cur = django.db.connection.cursor()
            sql = "select id, next_task_ids, prev_task_ids from horae_task;"
            cur.execute(sql)
            return cur.fetchall()
        except exceptions.Exception as ex:
            error_info = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            print(error_info)
            return None

if __name__ == "__main__":
    task_move = TaskMove(None)
    task_move.move_handler()
