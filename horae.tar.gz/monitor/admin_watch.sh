#!/bin/bash

MAIL_LIST="xielei.xl@alibaba-inc.com"
#������־��·��
CHECK_ADMIN_RUNNING_PATH="/home/admin/data_platform/horae/task_admin/log/horae_admin.log"

python_cmd=/home/admin/data_platform/Python-2.7.9/bin/python
host_ip=`hostname | xargs host | awk -F' ' '{print $4}'`
count=0
    DELAY_SEC=60
    DETAIL=`date -d''${DELAY_SEC}' sec ago' +"%m-%d %H:%M:"`

    tmp_count=`cat succ_count.log|awk '{print $0}'`	  
    grep "${DETAIL}.*check_succeeded_tasks.py" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> admin.list
    if [ `cat admin.list | wc -l` -eq 0 ];then
        let tmp_count=$tmp_count+1
        if [ $tmp_count -ge 4 ];then
            $python_cmd ./sm_mail.py 'ark-ADMIN-monitor-'$host_ip "check_succeeded_tasks-thread-not-running" ${MAIL_LIST}
        fi
    else
        let tmp_count=0
    fi
    echo $tmp_count > succ_count.log


    tmp_count=`cat admin_lock.log|awk '{print $0}'`	  
    grep "${DETAIL}.*this admin has getted lock!" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> admin.list
    if [ `cat admin.list | wc -l` -eq 0 ];then
        grep "${DETAIL}.*this admin has getted lock!" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> admin.lis
        if [ `cat admin.list | wc -l` -eq 0 ];then
            let tmp_count=$tmp_count+1
            if [ $tmp_count -ge 4 ];then
                $python_cmd ./sm_mail.py 'ark-ADMIN-monitor-'$host_ip "admin_check_zookeeper_lock-thread-not-running" ${MAIL_LIST}
            fi
        else
            let tmp_count=0
        fi
    else
        let tmp_count=0
    fi
    echo $tmp_count > admin_lock.log

    tmp_count=`cat uncall_count.log|awk '{print $0}'`	  
    grep "${DETAIL}.*check_uncalled_tasks.py" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> admin.list
    if [ `cat admin.list | wc -l` -eq 0 ];then
        let tmp_count=$tmp_count+1
        if [ $tmp_count -ge 4 ];then
           $python_cmd ./sm_mail.py 'ark-ADMIN-monitor-'$host_ip "check_uncalled_tasks-thread-not-running" ${MAIL_LIST}
        fi
    else
        let tmp_count=0
    fi
    echo $tmp_count > uncall_count.log

    tmp_count=`cat dispatcher_count.log|awk '{print $0}'`	  
    grep "${DETAIL}.*task_dispacher.py" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> admin.list
    if [ `cat admin.list | wc -l` -eq 0 ];then
        let tmp_count=$tmp_count+1
        if [ $tmp_count -ge 4 ];then
            $python_cmd ./sm_mail.py 'ark-ADMIN-monitor-'$host_ip "task_dispacher-thread-not-running" ${MAIL_LIST}
        fi
    else
        let tmp_count=0
    fi
    echo $tmp_count > dispatcher_count.log

    tmp_count=`cat unexp_count.log|awk '{print $0}'`	  
    grep "${DETAIL}.*check_unexpect_status_tasks.py" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> admin.list
    if [ `cat admin.list | wc -l` -eq 0 ];then
        let tmp_count=$tmp_count+1
        if [ $tmp_count -ge 4 ];then
            $python_cmd ./sm_mail.py 'ark-ADMIN-monitor-'$host_ip "check_unexpect_status_tasks-thread-not-running" ${MAIL_LIST}
        fi
    else
        let tmp_count=0
    fi
    echo $tmp_count > unexp_count.log

    tmp_count=`cat schedule_creator.log|awk '{print $0}'`	  
    grep "${DETAIL}.*schedule_creator.py" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> admin.list
    if [ `cat admin.list | wc -l` -eq 0 ];then
        let tmp_count=$tmp_count+1
        if [ $tmp_count -ge 4 ];then
            $python_cmd ./sm_mail.py 'ark-ADMIN-monitor-'$host_ip "schedule_creator-thread-not-running" ${MAIL_LIST}
        fi
    else
        let tmp_count=0
    fi
    echo $tmp_count > schedule_creator.log
