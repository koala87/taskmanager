###############################################################################
# encoding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
����Ǩ��

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import logging
import threading
import datetime
import copy
import logging
reload(sys)
sys.setdefaultencoding('utf-8')

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "db_manager.settings")
from django.core.management import execute_from_command_line
sys.path.append('../common/db_manager')
import django

import horae.models
import django.contrib.auth.models
import common.models

class DelExpireRunhistory(object):
    def __init__(self):
        self.__delete_expire_runhistory()

    def __delete_expire_runhistory(self):
        now_time = (datetime.datetime.now() - datetime.timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
        try:
            cur = django.db.connection.cursor()
            sql = "select task_id, pl_id, run_time, init_time from horae_schedule where init_time <= '%s';" % now_time
            print sql
            cur.execute(sql)
            rows = cur.fetchall()
            print len(rows)

            for row in rows:
                sql = "delete from horae_runhistory where task_id = %s and pl_id = %s and run_time = '%s';" % (row[0], row[1], row[2])
                cur.execute(sql)
                print sql

                sql = "delete from horae_schedule where task_id = %s and pl_id = %s and run_time = '%s';" % (row[0], row[1], row[2])
                cur.execute(sql)
                print sql

        except exceptions.Exception as ex:
            error_info = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            print(error_info)
            return None

if __name__ == "__main__":
    task_move = DelExpireRunhistory()
