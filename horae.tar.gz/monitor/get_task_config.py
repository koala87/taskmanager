###############################################################################
# encoding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
谢磊

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import logging
import threading
import datetime
import copy
import logging
import csv
reload(sys)
sys.setdefaultencoding('utf-8')

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "db_manager.settings")
from django.core.management import execute_from_command_line
sys.path.append('../common/db_manager')
import django

import horae.models
import django.contrib.auth.models
import common.models

class GetTaskConfigList(object):
    def __init__(self):
        self.__get_task_config_list()

    def __get_task_config_list(self):
        try:
            cur = django.db.connection.cursor()
            
            sql = ("select t3.pl_name, t3.task_name, t4.ali_name, t4.ali_mail, t3.enable, t3.config from (select t2.name as pl_name, t1.name as task_name, t1.config, t2.owner_id, t2.enable from( "
            "select id, name, config, pl_id from horae_task where config like '%sAY500%s')t1 left outer join( "
            "select id, name, owner_id, enable from horae_pipeline)t2 on t1.pl_id = t2.id) t3 left outer join(select user_id, ali_name, ali_mail from ark_user_info) t4 on t3.owner_id = t4.user_id;" % ('%', '%'))
            cur.execute(sql)
            rows = cur.fetchall()
            print sql
            cvs_file_name = "./pipe_task_config.csv"
            cvs_file = file(cvs_file_name, 'wb')
            writer = csv.writer(cvs_file)

            writer.writerow(['流程名', '任务名', '用户名', '邮箱', '是否上线', '配置'])

            for row in rows:
                writer.writerow(row)
            cvs_file.close()
        except exceptions.Exception as ex:
            error_info = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            print(error_info)
            return None

if __name__ == "__main__":
    task_config = GetTaskConfigList()