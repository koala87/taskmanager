#!/bin/bash

MAIL_LIST="xielei.xl@alibaba-inc.com"
#������־��·��
CHECK_ADMIN_RUNNING_PATH="/home/admin/data_platform/horae/task_node/log/horae_log.log"

python_cmd=/home/admin/data_platform/Python-2.7.9/bin/python
host_ip=`hostname | xargs host | awk -F' ' '{print $4}'`
count=0
    DELAY_SEC=60
    DETAIL=`date -d''${DELAY_SEC}' sec ago' +"%m-%d %H:%M:"`

    failed_count=`cat handle_ready_tasks_failed_count.log|awk '{print $0}'` 
    grep "${DETAIL}.*handle_ready_tasks.py" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> node.list
    if [ `cat node.list | wc -l` -eq 0 ];then
        let failed_count=$failed_count+1
        if [ $failed_count -ge 4 ];then
            $python_cmd ./sm_mail.py 'ark-NODE-monitor-'$host_ip "handle_ready_tasks-thread-not-running" ${MAIL_LIST}
        fi
    else
        let failed_count=0
    fi
    echo $failed_count > handle_ready_tasks_failed_count.log
    
    grep "${DETAIL}.*thread num: [0-99]" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> node.list
    if [ `cat node.list | wc -l` -le 1 ];then
        $python_cmd ./sm_mail.py 'ark-NODE-monitor-'$host_ip "handle_ready_tasks_handler-thread-not-running" ${MAIL_LIST}
    fi

