#sh admin_watch.sh 
sh deamon_watch.sh 
sh fatal_watch.sh 
sh node_watch.sh 
sh monitor_disk.sh 
sh memory_watch.sh 
sh super_daemon_watch.sh
