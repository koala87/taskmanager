LOG_PATH=/home/admin/ark_service/ark_tools/work_dir/
    rm -rf del_expire_path.log
    ls $LOG_PATH | awk -F' ' '{print "'${LOG_PATH}'"$1}' | awk '{system("sudo stat -c %Y "$0);print $0}' | awk '{print $0 >> "del_expire_path.log"}'
    cat del_expire_path.log | awk 'BEGIN{prev_num = 0} {pos = index($0, "/"); if (pos == 0) {prev_num=$0} else {arr[$0] = prev_num}}END{now_ts=(systime() - 21600);for (i in arr) {if (arr[i] < now_ts) {print i} }}' | awk -F'/' '{if (int($7) > 9999999999999) system("sudo rm -rf '${LOG_PATH}'"$7)}' 
