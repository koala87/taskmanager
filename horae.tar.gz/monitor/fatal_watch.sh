#coding: utf-8
#!/bin/bash

MAIL_LIST="xielei.xl@alibaba-inc.com,ark_alarm@list.alibaba-inc.com"
PHONE_LIST="13735484728,18501153301,18910158721"
#������־��·��
LOG_PATH="/home/admin/data_platform/horae/*/log/*.log.wf"

python_cmd=/home/admin/data_platform/Python-2.7.9/bin/python
count=0
host_ip=`hostname | xargs host | awk -F' ' '{print $4}'`
    DELAY_SEC=60
    DETAIL=`date -d''${DELAY_SEC}' sec ago' +"%m-%d %H:%M:"`


    grep "${DETAIL}.*ERROR:" ${LOG_PATH} | grep -v -E "(MySQL server has gone away)|(NodeExistsError)|(Deadlock)|(must less than now)|(RunHistory matching query does not exist)|(task_daemon)|(10.99.16.78)"> fatal.list
    if [ `cat fatal.list | wc -l` -ne 0 ];then
        test_str=`head -n 100 fatal.list`
        ${test_str//'\n'/' '}
        $python_cmd ./sm_mail.py 'ark-FATAL-monitor-'$host_ip "$test_str" ${MAIL_LIST}
#	$python_cmd ./ali_mobile.py $PHONE_LIST 'ark-FATAL-monitor-'$host_ip "admin-RUNLOG-ERROR-Please-check" $DETAIL "ERROR"
    fi


