LOG_PATH=/home/admin/data_platform/horae/work_dir/data_platform/
    rm -rf del_expire_path.log
    ls $LOG_PATH | awk -F' ' '{print "'${LOG_PATH}'"$1}' | awk '{system("stat -c %Y "$0);print $0}' | awk '{print $0 >> "del_expire_path.log"}'
    awk 'BEGIN{prev_num = 0} {pos = index($0, "/"); if (pos == 0) {prev_num=$0} else {arr[$0] = prev_num}}END{now_ts=(systime() - 86400 * 7);for (i in arr) {if (arr[i] < now_ts) {system("rm -rf "i)} }}' del_expire_path.log
