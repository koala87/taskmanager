#!/bin/bash

MAIL_LIST="xielei.xl@alibaba-inc.com"
#������־��·��
CHECK_ADMIN_RUNNING_PATH="/home/admin/data_platform/super_cmd_horae/task_daemon/log/horae_log.log"

python_cmd=/home/admin/data_platform/Python-2.7.9/bin/python
host_ip=`hostname | xargs host | awk -F' ' '{print $4}'`
count=0
    DELAY_SEC=60
    DETAIL=`date -d''${DELAY_SEC}' sec ago' +"%m-%d %H:%M:"`

    failed_count=`cat daemon_faile.log|awk '{print $0}'`
    grep "${DETAIL}.*task_manager.py" ${CHECK_ADMIN_RUNNING_PATH} | grep -v -E "(MYSQL)"> super_deamon.list
    if [ `cat deamon.list | wc -l` -eq 0 ];then
        let failed_count=$failed_count+1
        if [ $failed_count -ge 5 ];then
            let failed_count=0
            $python_cmd ./sm_mail.py 'ark-DAEMON-monitor-'$host_ip "task_manager-thread-not-running" ${MAIL_LIST}
        fi
    else
        let failed_count=0
    fi
    echo $failed_count > super_daemon_faile.log


