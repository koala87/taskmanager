#!/bin/bash

MAIL_LIST="xielei.xl@alibaba-inc.com"
#Ƥ׃ɕ־µł·¾¶

python_cmd=/home/admin/data_platform/Python-2.7.9/bin/python
host_ip=`hostname | xargs host | awk -F' ' '{print $4}'`

> memory.log
noad_pid=`ps -e -o 'args,rsz' | grep /home/admin/data_platform/ | awk -F' ' '{if ($2 >= 5000000) print $2 >> "memory.log"}'`
if [ `cat memory.log | wc -l` -eq 0 ];then
    echo 1
else
    $python_cmd ./sm_mail.py 'ark-NODE-monitor-'$host_ip "memory use exceeded 5000M." ${MAIL_LIST}
fi
