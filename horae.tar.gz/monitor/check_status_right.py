﻿###############################################################################
# encoding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
任务迁移

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import logging
import threading
import datetime
import copy
import logging

import json
import urllib
import httplib

reload(sys)
sys.setdefaultencoding('utf-8')

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "db_manager.settings")
from django.core.management import execute_from_command_line
sys.path.append('../common/db_manager')
import django

import pymysql
import horae.models
import django.contrib.auth.models
import common.models

sys.path.append('../common')
import graph_group
import task_util
import no_block_sys_cmd
import linux_file_cmd
import pangu_command
import sm_mail

mail_list = 'xielei.xl@alibaba-inc.com'

class CheckStatusRight(object):
    def check_handler(self):
        try:
            subject = "Noah(诺亚)计算平台-依赖关系错误"
            print subject
            schedules = horae.models.Schedule.objects.filter(status__in=(0, 1))
            for schedule in schedules:
                run_history = horae.models.RunHistory.objects.get(task_id=schedule.task_id, run_time=schedule.run_time)
                print schedule.status,run_history.status
                if schedule.status != run_history.status:
                    user_schedules = horae.models.OrderdSchedule.objects.filter(task_id=schedule.task_id, run_time=schedule.run_time)
                    if len(user_schedules) <= 0:
                        content = "[流程：%s, 任务:%s]的执行状态紊乱。[schedule:%s, history: %s]" % (run_history.pl_name, run_history.task_name, schedule.status, run_history.status)
                        print content
                        sm_mail.send(subject, content, mail_list, None)

        except exceptions.Exception as ex:
            error_info = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            print(error_info)

if __name__ == "__main__":
    checkstatusright = CheckStatusRight()
    checkstatusright.check_handler()
