﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2016 alibaba-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
supper cmd前端工具接口

Authors: xielei.xl(xielei.xl@alibaba-inc.com)
"""

import os
import sys
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import urllib
import logging
import threading
import datetime
import copy
import logging
import json
import httplib
reload(sys)
sys.setdefaultencoding('utf-8')
            
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "db_manager.settings")
from django.core.management import execute_from_command_line
sys.path.append('../common/db_manager')
import django
        
import horae.models
import django.contrib.auth.models
import common.models
            
sys.path.append('../common')
import graph_group
import task_util
import no_block_sys_cmd
import linux_file_cmd
import pangu_command
import sm_mail
        
class StopExpireTask(object):
    def __init__(self):
        pass

    def stop_handler(self):
        try:        
            self.__get_all_tasks()
            return True
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            print("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            print("ex:%s, trace:%s" % (
                str(ex), traceback.format_exc()))
            return False

    def __stop_task(self, pl_name, task_name, run_time):
        req_map = {}
        req_map["username"] = "ark_admin"
        req_map["password"] = "*1#ark_123456"
        req_map["cmd"] = "stop_task"

        task_list = []
        task_map = {
            "pipeline_name": pl_name,
            "task_name": task_name,
            "run_time": run_time
        }
        task_list.append(task_map)
        req_map["tasks"] = task_list
        

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        print req_map
        params = urllib.urlencode({'req_pkg': req_json})
        headers = {
                "Content-type": "application/x-www-form-urlencoded",
                "Accept": "text/plain"}
        http_client = httplib.HTTPConnection(
                "140.205.216.134", 
                9999, 
                timeout=30)
        http_client.request(
                "POST", 
                "/api/pipeline/auto_post_pipeline/", 
                params, 
                headers)
        response = http_client.getresponse()
        res_data = response.read()
        res_json = json.loads(res_data)
        res_json = json.loads(res_json)
        if res_json["status"] != 0:
            print(
                    "stop task failed: [pl_name:%s] [task_name:%s][run_time:%s]!reason: %s" % (
                    pl_name, task_name, run_time, res_json["info"]))
        print res_json

    def __get_all_tasks(self):
        try:
            cur = django.db.connection.cursor()
            sql = "select pl_name, task_name, run_time, start_time, end_time from horae_runhistory where status = 1;"
            cur.execute(sql)
            rows = cur.fetchall()
            for row in rows:
                use_time = row[4] - row[3]
                use_seconds = use_time.days * 24 * 3600 + use_time.seconds
                if use_seconds / 86400 >= 3:
                    print row[4], row[3], use_seconds
                    self.__stop_task(row[0], row[1], row[2])
        except exceptions.Exception as ex:
            error_info = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            print(error_info)
            return None

if __name__ == "__main__":
    task_move = StopExpireTask()
    task_move.stop_handler()
                                                            
