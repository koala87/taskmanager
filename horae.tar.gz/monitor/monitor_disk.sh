#!/bin/bash

MAIL_LIST="xielei.xl@alibaba-inc.com,wei.guow1@alibaba-inc.com,dengtan.lei@alibaba-inc.com"
PHONE_LIST="13735484728,18501153301,18910158721"
python_cmd=/home/admin/data_platform/Python-2.7.9/bin/python
host_ip=`hostname | xargs host | awk -F' ' '{print $4}'`
left=`df -hl | grep -i '/home' | awk -F' ' '{split($5, arr, "%");print arr[1]}'`
DETAIL=`date -d''${DELAY_SEC}' sec ago' +"%m-%d-%H:%M:"`
let left=$left+0
if [ $left -ge 80 ];then
    $python_cmd ./sm_mail.py 'ark-NODE-monitor-'$host_ip-'disk used: '$left 'ark-NODE-monitor-'$host_ip'-disk left: '"`df -hl | grep -i 'disk8'`"  ${MAIL_LIST}
    $python_cmd ./ali_mobile.py $PHONE_LIST 'ark-home-monitor-'$host_ip "磁盘空间超过80" $DETAIL "失败"
else
    echo $left
fi
