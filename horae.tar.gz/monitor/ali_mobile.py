###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
阿里旺旺消息推送

"""

import os
import sys
import urllib2
import urllib
reload(sys)
sys.setdefaultencoding("utf-8")

import no_block_sys_cmd

class Mobile(object):
    @staticmethod
    def send_message(
            receiver, 
            pl_name, 
            task_name, 
            run_time, 
            status='失败'):
        curl = (
                """http://10.181.204.100:8088/message_sender/MobileMsg?"""
                """receiver={0}&&pl_name=\[{1}\]&task_name=\[{2}\]&"""
                """runtime=\[{3}\]&status={4}""".format(
                receiver, 
                pl_name, 
                task_name, 
                run_time, 
                status))
        curl_cmd = """curl "%s" """ % curl
        stdout, stderr, return_code = \
                no_block_sys_cmd.NoBlockSysCommand().run_once(curl_cmd)
        return stdout, stderr, return_code

if __name__ == "__main__":
    receiver = sys.argv[1]
    pl_name = sys.argv[2]
    task_name = sys.argv[3]
    run_time = sys.argv[4]
    status = sys.argv[5]
    receive_list = receiver.split(",")
    for receive in receive_list:
        if receive.strip() == "":
            continue

        print(Mobile.send_message(
                receive, 
                pl_name, 
                task_name, 
                run_time,
                status))

