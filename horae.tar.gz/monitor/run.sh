#!/bin/bash
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/admin/libgd/libgd/lib/

#MAIL_LIST='lei.xie@shenma-inc.com,xielei.xl@alibaba-inc.com,ark_alarm@list.alibaba-inc.com'
MAIL_LIST='lei.xie@shenma-inc.com,xielei.xl@alibaba-inc.com'
function WriteLog()
{
    fntmp_date=`date`
    fnMSG=$1
    echo "[$fntmp_date] $fnMSG" >> ./log/report.log
}

DAY=$(date -d "-1 days" +%Y%m%d)
MONTH=$(date +%Y-%m)

MIN_RUN_TIME=$(date -d "-1 days" +%Y-%m-%d)
MAX_RUN_TIME=$(date -d "-1 days" +%Y-%m-%d)
echo $MIN_RUN_TIME
echo $MAX_RUN_TIME
>./tmp/mysql.${DAY}.log

echo "$(mysql -ulogarktools -piOid3978Ld9KdshKdf -h11.226.2.70  -P13309 -e 'select count(id) from log_ark_tools.horae_runhistory where start_time >= "'$MIN_RUN_TIME' 00:00:00" and start_time <= "'$MAX_RUN_TIME' 23:59:59"\G')" | awk '
BEGIN {
    RS="\\*[^\n]*\\*\n"
    FS="\n"
    OFS="\t"
}

NR>1 {
    $0 = gensub(/[^:\n]+: /, "", "g", $0)
    print $1 > "'./tmp/mysql.all.$DAY.log'" 
}'

echo "$(mysql -ulogarktools -piOid3978Ld9KdshKdf -h11.226.2.70  -P13309 -e 'select count(id) from log_ark_tools.horae_runhistory where  start_time >= "'$MIN_RUN_TIME' 00:00:00" and start_time <= "'$MAX_RUN_TIME' 23:59:59" and pl_id in(select id from log_ark_tools.horae_pipeline where type = 0)\G')" | awk '
BEGIN {
    RS="\\*[^\n]*\\*\n"
    FS="\n"
    OFS="\t"
}

NR>1 {
    $0 = gensub(/[^:\n]+: /, "", "g", $0)
    print $1 > "'./tmp/mysql.0.$DAY.log'" 
}'
echo "$(mysql -ulogarktools -piOid3978Ld9KdshKdf -h11.226.2.70  -P13309 -e 'select count(id) from log_ark_tools.horae_runhistory where status = 3 and start_time >= "'$MIN_RUN_TIME' 00:00:00" and start_time <= "'$MAX_RUN_TIME' 23:59:59"\G')" | awk '
BEGIN {
    RS="\\*[^\n]*\\*\n"
    FS="\n"
    OFS="\t"
}

NR>1 {
    $0 = gensub(/[^:\n]+: /, "", "g", $0)
    print $1 > "'./tmp/mysql.fail.$DAY.log'" 
}'

LOG_PATH=/home/admin/ark_service/ark_tools/log/user_log.log
MONTH_LOG=/home/admin/ark_service/ark_tools/log/user_log.log.$MONTH*

>./tmp/report.${DAY}.tmp
>./tmp/report_handle.${DAY}.tmp
>./tmp/max_time.log
#>./tmp/name_num.log
DETAIL=`date -d "-1 days" +"%Y-%m-%d"`
echo ${DETAIL}'.*horae_interface.py' $LOG_PATH $MONTH_LOG
grep ${DETAIL}'.*horae_interface.py' $LOG_PATH $MONTH_LOG | awk -F' ' 'BEGIN{OFS = FS = " ";}{
    split($0, owner_arr, "owner_id: "); 
    if(length(owner_arr[2]) != 0) {
        split(owner_arr[2], owner_id_arr, " ");
        id_arr[owner_id_arr[1]]++;
    } 
    arr[$7]++; 
    n=split($NF, use_time_arr, ":"); 
    split(use_time_arr[n], urr, "]"); 
    trr[$7] += urr[1]; 
    if(urr[1] + 0 > mrr[$7] + 0) 
        mrr[$7] = urr[1]; 
    count++;
}
END{
    for (i in arr) {
        num = arr[i]
        while (num in tmp_num_arr) num++;
        tmp_num_arr[num] = num
        new_num = sprintf("%08d", num)
        num_arr[new_num]=i
    }
    
    slen=asorti(num_arr, tA); 
    for (j = slen; j >= 1; j--) {
        i = num_arr[tA[j]]
        print i " " arr[i] " " trr[i]/arr[i] " " mrr[i] >> "'./tmp/report_handle.${DAY}.tmp'";
    } 
    print length(id_arr) "\t" count >> "'./tmp/report.${DAY}.tmp'";
    for (i in max_log)
        print i " " mrr[i] >> "./tmp/max_time.log"
}'
if [ $? != 0 ]
then
    WriteLog "FATAL: handle dat failed"
    exit 1
fi

> ./result/report.${DAY}.30days

i=0
while ((i<30))
do
    clk=0
    uv=0
    res_file="./tmp/report.$(date -d "-$i days ${DAY}" +%Y%m%d).tmp"
    if [ -f "${res_file}" ]
    then
        uv=$(head -n 1 "$res_file" | awk -F"\t" '{print $1}')
        clk=$(head -n 1 "$res_file" | awk -F"\t" '{print $2}')
    fi

    echo -e "$(date -d "-$i days ${DAY}" +%Y%m%d)\t$uv\t$clk" >> ./result/report.${DAY}.30days
    ((i++))
done


> ./result/report.${DAY}.uv.jpeg
> ./result/report.${DAY}.clk.jpeg

CMD="'./result/report.${DAY}.30days' u 1:2 title 'UV' with linespoints linetype 1"
~/gnuplot/bin/gnuplot <<EOF
set terminal jpeg
set output "./result/report.${DAY}.uv.jpeg"
set xdata time
set title "UV curve"
set timefmt "%Y%m%d"
set format x "%Y%m%d"
set xlabel "date"
set ylabel "number"
plot $CMD 
EOF

CMD="'./result/report.${DAY}.30days' u 1:3 title 'PV' with linespoints linetype 1"
~/gnuplot/bin/gnuplot <<EOF
set terminal jpeg
set output "./result/report.${DAY}.pv.jpeg"
set xdata time
set title "PV curve"
set timefmt "%Y%m%d"
set format x "%Y%m%d"
set xlabel "date"
set ylabel "number"
plot \
$CMD
EOF

mail_file=./result/report.${DAY}.html
> ${mail_file}

(
echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">'
echo "<html><head><title>[报表][Noah计算平台]简要指标-$DAY</title></head>"
echo '
<BODY bgColor=#ffffff>
<style >
body {
    font-family: "宋体","Arial";
    font-size: 12px;
    text-align: center
}
A {
    color: #0000AA;
    text-decoration: none
}
A:hover {
    color: #ff0000;
    text-decoration: underline
}
DIV {
    overflow: hidden;
    text-overflow: ellipsis
}
    font-family: 宋体;
    font-size: 16px;
table.f12 {
    font-family: 宋体;
}
</style>'

echo '
<br>
'
) >> ${mail_file}

(
echo '
<div id="name" align="center"><strong><SPAN lang="EN-US"><font face="微软雅黑, 宋体" size="5">'
echo "[报表][Noah计算平台]简要指标-$DAY"
echo '</font></SPAN></strong></div>
<br>
<br>
<div id="name" align="center"><strong><SPAN lang="EN-US"><font face="微软雅黑, 宋体" size="4">简要指标</font></SPAN></strong></div>
<br>
<div>
<table border="1" width="80%" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" bordercolorlight="#8AA4EE" bordercolordark="#FFFFFF" class="f12" align="center">
 <tr height="30" align="center" bgcolor="#DBE5F1">
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>UV/周同期</B></font></td>
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>PV/周同期</B></font></td>
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>调度任务数/周同期</B></font></td>
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>常规任务数/周同期</B></font></td>
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>失败任务数/周同期</B></font></td>
 </tr>'
) >> ${mail_file}

week_uv=0
week_clk=0
week_all=0
week_fail=0
week_type0=0

week_res_file="./tmp/report.$(date -d "-7 days ${DAY}" +%Y%m%d).tmp"
if [ -f "$week_res_file" ]
then
    week_uv=$(head -n 1 "$week_res_file" | awk -F"\t" '{print $1}')
    week_clk=$(head -n 1 "$week_res_file" | awk -F"\t" '{print $2}')
fi

week_mysql_all_file="./tmp/mysql.all.$(date -d "-7 days ${DAY}" +%Y%m%d).log"
if [ -f "$week_mysql_all_file" ]
then
    week_all=$(head -n 1 "$week_mysql_all_file" | awk -F"\t" '{print $1}')
fi

week_mysql_all_file="./tmp/mysql.fail.$(date -d "-7 days ${DAY}" +%Y%m%d).log"
if [ -f "$week_mysql_all_file" ]
then
    week_fail=$(head -n 1 "$week_mysql_all_file" | awk -F"\t" '{print $1}')
fi

week_mysql_all_file="./tmp/mysql.0.$(date -d "-7 days ${DAY}" +%Y%m%d).log"
if [ -f "$week_mysql_all_file" ]
then
    week_type0=$(head -n 1 "$week_mysql_all_file" | awk -F"\t" '{print $1}')
fi

res_file="./tmp/report.${DAY}.tmp"

uv=$(head -n 1 "$res_file" | awk -F"\t" '{print $1}')
clk=$(head -n 1 "$res_file" | awk -F"\t" '{print $2}')

now_mysql_file="./tmp/mysql.all.$DAY.log"
mysql_all=$(head -n 1 "$now_mysql_file" | awk -F"\t" '{print $1}')
now_mysql_file="./tmp/mysql.fail.$DAY.log"
mysql_fail=$(head -n 1 "$now_mysql_file" | awk -F"\t" '{print $1}')
now_mysql_file="./tmp/mysql.0.$DAY.log"
mysql_type0=$(head -n 1 "$now_mysql_file" | awk -F"\t" '{print $1}')
################################################################
(
echo '<tr>'
echo '<td align="center">'$uv/$week_uv'</td>'
echo '<td align="center">'$clk/$week_clk'</td>'
echo '<td align="center">'$mysql_all/$week_all'</td>'
echo '<td align="center">'$mysql_type0/$week_type0'</td>'
echo '<td align="center">'$mysql_fail/$week_fail'</td>'
echo "</tr></table></div>"
) >> ${mail_file}

pic1=`cat ./result/report.${DAY}.uv.jpeg | openssl base64`
pic2=`cat ./result/report.${DAY}.pv.jpeg | openssl base64`
(
echo '
<br>
<div id="name" align="center"><strong><SPAN lang="EN-US"><font face="微软雅黑, 宋体" size="4">UV/PV分布趋势</font></SPAN></strong></div>'

echo '<div id="name" align="center"><br>'
echo '<IMG src="data:image/jpeg;base64,'${pic1}'" align=center border=0></IMG>'
echo "<br>"
echo '<IMG src="data:image/jpeg;base64,'${pic2}'" align=center border=0></IMG>'
echo "</BODY></HTML>"
) >> ${mail_file}
(
echo '<div>
<div id="name" align="center"><strong><SPAN lang="EN-US"><font face="微软雅黑, 宋体" size="4">用户行为统计</font></SPAN></strong></div>
<br>
<table border="1" width="80%" bgcolor="#FFFFFF" cellspacing="0" cellpadding="0" bordercolorlight="#8AA4EE" bordercolordark="#FFFFFF" class="f12" align="center">
 <tr height="30" align="center" bgcolor="#DBE5F1">
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>点击动作名</B></font></td>
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>点击量/周同期</B></font></td>
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>平均耗时/周同期</B></font></td>
 <td colspan="1" rowspan="1" align="center"><font face="微软雅黑, 宋体" size="3" color="#000000" ><B>最大耗时/周同期</B></font></td>
 </tr>'
) >> ${mail_file}


num_map[0]=0
num_map[2]=2
mt_map[0]=0
eval_map[0]=0
num_array[0]=0

awk '
BEGIN {
    OFS = FS = " ";
    while (getline < "'./tmp/report_handle.$(date -d "-7 days ${DAY}" +%Y%m%d).tmp'" > 0) {
        week_num_arr[$1] = $2
        week_et_arr[$1] = $3
        week_mt_arr[$1] = $4
    }
}
{
	
    print "<tr>" >> "'${mail_file}'"
    printf("<td align=\"center\">%s</td>", $1) >> "'${mail_file}'"
    printf("<td align=\"center\">%4d/%4d</td>", $2, week_num_arr[$1]) >> "'${mail_file}'"
    printf("<td align=\"center\">%.4f/%.4f</td>", $3 + 0, week_et_arr[$1] + 0) >> "'${mail_file}'"
    printf("<td align=\"center\">%.4f/%.4f</td>", $4 + 0, week_mt_arr[$1] + 0) >> "'${mail_file}'"
    print "</tr>" >>  "'${mail_file}'"
} END {
}' "./tmp/report_handle.$DAY.tmp"

(
echo "</table></div>"
) >> ${mail_file}



content=`cat ./result/report.$DAY.html`
/home/admin/data_platform/Python-2.7.9/bin/python ./sm_mail.py "Noah计算平台-报表-$DAY" "$content" $MAIL_LIST
