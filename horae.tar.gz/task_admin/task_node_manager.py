﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
管理task node节点信息

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import threading
import random
import logging

sys.path.append('../common')
import task_util
import admin_sql_manager

class TaskNodeManager():
    """
        管理tasknode信息
        1.监控zookeeper相关路径，获取task_node信息
        2.提供给task有效的机器ip
    """
    def __init__(self, config, zk_manager):
        self.__log = logging
        self.__mutex = threading.Lock()
        self.__type_task_node_map = {}
        self.__zk_manager = zk_manager
        self.__task_type_conf_name = (
            'script',
            'apsara_job',
            'odps_sql',
            'odps_mr',
            'odps_xlab',
            'odps_spark'
        )

        self.__type_name_id_map = {
            'script': task_util.TaskType.SCRIPT_TYPE,
            'apsara_job': task_util.TaskType.APSARA_JOB,
            'odps_sql': task_util.TaskType.ODPS_SQL,
            'odps_mr': task_util.TaskType.ODPS_MAP_REDUCE,
            'odps_xlab': task_util.TaskType.ODPS_XLAB_SCRIPT,
            'odps_spark': task_util.TaskType.ODPS_SPARK
        }

        self.__type_name_watch_func_map = {
            'script': self.__watch_script_task_node_children,
            'apsara_job': self.__watch_apsara_job_task_node_children,
            'odps_sql': self.__watch_odps_sql_task_node_children,
            'odps_mr': self.__watch_odps_mr_task_node_children,
            'odps_xlab': self.__watch_odps_xlab_task_node_children,
            'odps_spark': self.__watch_odps_spark_task_node_children
        }

        self.__get_path_info_from_conf(config)

    def get_valid_ip(self, task_type, server_tag):
        # task_util.AutoLock(self.__mutex)
        self.__mutex.acquire()
        try:
            if len(self.__type_task_node_map[task_type][server_tag]) <= 0:
                return None

            random_ip = random.randint(
                    0, 
                    len(self.__type_task_node_map[task_type][server_tag]) - 1)
            return self.__type_task_node_map[task_type][server_tag][random_ip]
        except KeyError as ex:
            self.__log.error(str(ex) + "type_task_node_map wrong!")
            return None
        except Exception as ex:
            self.__log.error(str(ex) + "type_task_node_map wrong!")
            return None
        finally:
            self.__mutex.release()

    def __handle_watch(self, children, type):
        # task_util.AutoLock(self.__mutex)
        self.__mutex.acquire()
        if children is None or len(children) <= 0:
            if type in self.__type_task_node_map:
                del self.__type_task_node_map[type]
            self.__mutex.release()
            return

        if type in self.__type_task_node_map:
            self.__type_task_node_map[type] = {}

        for child in children:
            child_split = child.split(":")
            if len(child_split) != 2:
                self.__log.error(
                        "type:%d zookeeper path wrong child![%s]", 
                        type, child)
                continue
            if type in self.__type_task_node_map:
                if child_split[0] in self.__type_task_node_map[type]:
                    self.__type_task_node_map[type][child_split[0]].append(
                            child_split[1])
                else:
                    ip_list = []
                    ip_list.append(child_split[1])
                    tmp_map = {}
                    self.__type_task_node_map[type][child_split[0]] = ip_list
            else:
                ip_list = []
                ip_list.append(child_split[1])
                tmp_map = {}
                tmp_map[child_split[0]] = ip_list
                self.__type_task_node_map[type] = tmp_map
        self.__mutex.release()

    def __watch_script_task_node_children(self, children):
        self.__handle_watch(children, task_util.TaskType.SCRIPT_TYPE)

    def __watch_apsara_job_task_node_children(self, children):
        self.__handle_watch(children, task_util.TaskType.APSARA_JOB)

    def __watch_odps_sql_task_node_children(self, children):
        self.__handle_watch(children, task_util.TaskType.ODPS_SQL)

    def __watch_odps_mr_task_node_children(self, children):
        self.__handle_watch(children, task_util.TaskType.ODPS_MAP_REDUCE)

    def __watch_odps_xlab_task_node_children(self, children):
        self.__handle_watch(children, task_util.TaskType.ODPS_XLAB_SCRIPT)

    def __watch_odps_spark_task_node_children(self, children):
        self.__handle_watch(children, task_util.TaskType.ODPS_SPARK)

    def __get_path_info_from_conf(self, config):
        for task_type_name in self.__task_type_conf_name:
            zk_path = config.get("zk", task_type_name)
            self.__handle_watch(
                    self.__zk_manager.get_children(zk_path), 
                    self.__type_name_id_map[task_type_name])
            self.__zk_manager.watch_children(
                    zk_path, 
                    self.__type_name_watch_func_map[task_type_name])
