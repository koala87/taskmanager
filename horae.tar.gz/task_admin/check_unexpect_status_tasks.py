﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
检查ready_task，获取非正常状态的任务（TIMEOUT， FAILED，STOPED_BY_USER）

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import time
import datetime
import threading
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import exceptions
import traceback
import logging

import crontab
import horae.models
import django.core.exceptions

import admin_sql_manager
import admin_task_base
sys.path.append('../common')
import graph_group
import task_util

class CheckUnexpectStatusTasks(admin_task_base.AdminTaskBase):
    """
        获取非正常状态任务，从ready_task中删除失败任务，
        重试失败任务
        非正常状态写日志并报警
    """
    def __init__(self, task_node_manager):
        admin_task_base.AdminTaskBase.__init__(self)
        self.__unexp_task_list = []
        self.__log = logging
        self.__sql_manager = admin_sql_manager.SqlManager()
        self.__sql_del_list = []
        self.__sql_save_list = []
        self.__sql_list = []
        self.__task_node_manager = task_node_manager

    def run(self):
        self.__log.info("CheckUnexpectStatusTasks thread starting...")
        # 全局退出标示字段
        while not task_util.CONSTANTS.GLOBAL_STOP:
            # admin是否获取了zookeeper锁，具有处理数据的权限
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                time.sleep(1)
                continue

            while True:
                begin_time = time.time()
                self.__log.info("CheckUnexpectStatusTasks handle data started")

                self.__handle_unexp_tasks()
                use_time = time.time() - begin_time
                self.__log.info("CheckUnexpectStatusTasks handle data "
                        "exit.use time[%f]" % use_time)
                break

            time.sleep(10)  # 失败后任然需要sleep

        self.__log.info("CheckUnexpectStatusTasks thread existed!")

    def __retry_failed_task(self, unexp_task):
        # 检查休眠时长
        if not self.__check_rerun_time_period(unexp_task):
            return True

        # 检查任务数限制
        owner_id = unexp_task.owner_id
        task_type = unexp_task.type
        if not self._check_limit_num_can_run(owner_id, task_type):
            self.__log.info("limit is over![type:%d]"
                    "[owner_id:%d]" % (task_type, owner_id))
            return True

        # 获取可以执行的task_node，合法性检查会通过get_valid_ip进行
        tmp_run_server = self.__task_node_manager.get_valid_ip(
                unexp_task.type, 
                unexp_task.server_tag)
        if tmp_run_server is None:
            self.__log.error("get task node run_server failed![task_id:%s]"
                    "[type:%d][server_tag:%s]" % (
                    unexp_task.task_id, 
                    unexp_task.type, 
                    unexp_task.server_tag))
            return False
        ready_task_sql = ("update horae_readytask set status = %d, "
                "retried_count = %d, run_server = '%s', update_time = '%s'"
                " where id = %d and status = %d "
                " and retried_count = %d;" % (
                task_util.TaskState.TASK_READY, 
                unexp_task.retried_count + 1, 
                tmp_run_server,
                task_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S"),
                unexp_task.id, 
                unexp_task.status, 
                unexp_task.retried_count))
        self.__sql_list.append(ready_task_sql)

        # 更新schedule
        schedule_sql = ("update horae_schedule set status = %d "
                "where id = %d and status = %d;" % (
                task_util.TaskState.TASK_READY, 
                unexp_task.schedule_id, 
                unexp_task.status))
        self.__sql_list.append(schedule_sql)

        # 写run_history
        run_history_sql = ("update horae_runhistory set status = %d, "
                "run_server = '%s', schedule_id = %d where task_id = %s "
                "and status = %d and run_time = '%s'; " % (
                task_util.TaskState.TASK_READY, 
                tmp_run_server,
                unexp_task.schedule_id,
                unexp_task.task_id,
                unexp_task.status,
                unexp_task.run_time))
        self.__sql_list.append(run_history_sql)

        return True
 
    # 任务重试给一个休眠惩罚，防止频繁重试
    def __check_rerun_time_period(self, unexp_task):
        try:
            sleep_period = 0
            # 防止溢出
            if unexp_task.retried_count >= 100:
                sleep_period = task_util.CONSTANTS.TASK_RETRY_MAX_TIME_PERIOD
            else:
                sleep_period = (
                        (task_util.CONSTANTS.TASK_RETRY_STEP_INC_RATIO ** 
                        float(unexp_task.retried_count)) * 
                        task_util.CONSTANTS.TASK_RETRY_STEP_INC_TIME)
            if sleep_period > task_util.CONSTANTS.TASK_RETRY_MAX_TIME_PERIOD:
                sleep_period = task_util.CONSTANTS.TASK_RETRY_MAX_TIME_PERIOD

            now_time = time.time()
            last_run_time = time.mktime(time.strptime(
                    str(unexp_task.update_time), 
                    '%Y-%m-%d %H:%M:%S'))
            if now_time - last_run_time >= sleep_period:
                return True
            return False
        except exceptions.Exception as ex:
            self.__log.error("there is error: %s, trace: %s" % (
                    str(ex), traceback.format_exc()))
            return False

    def __handle_failed_tasks(self, unexp_task):
        try:
            task = horae.models.Task.objects.get(id=unexp_task.task_id)
            if task.retry_count == -1:  # 一直重试
                return self.__retry_failed_task(unexp_task)

            if unexp_task.retried_count < task.retry_count:
                return self.__retry_failed_task(unexp_task)

        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False
        
        self.__sql_del_list.append(unexp_task)
        return True
    
    # 获取失败状态的任务，重试或者从ready_task中删除
    def __handle_unexp_tasks(self):
        self.__unexp_task_list = self.__sql_manager.get_all_unexp_tasks()
        if self.__unexp_task_list is None or len(self.__unexp_task_list) <= 0:
            return True

        for unexp_task in self.__unexp_task_list:
            self.__sql_del_list = []
            self.__sql_save_list = []
            self.__sql_list = []

            if unexp_task.status == task_util.TaskState.TASK_FAILED:
                if not self.__handle_failed_tasks(unexp_task):
                    self.__log.info("handle failed task failed![task_id:%d]"
                            "[run_time:%s]" % (
                            unexp_task.task_id, unexp_task.run_time))
                    continue
            else:
                continue

            if not self.__sql_manager.batch_execute_with_affect_one(
                    self.__sql_save_list, 
                    self.__sql_del_list,
                    self.__sql_list):
                self.__log.error("save or del db data failed!")
        return True

if __name__ == "__main__":
    for retried_count in range(0, 100):
        sleep_period = 0
        # 防止溢出
        if unexp_task.retried_count >= 100:
            sleep_period = task_util.CONSTANTS.TASK_RETRY_MAX_TIME_PERIOD
        else:
            sleep_period = (
                    (task_util.CONSTANTS.TASK_RETRY_STEP_INC_RATIO ** 
                    float(retried_count)) * 
                    task_util.CONSTANTS.TASK_RETRY_STEP_INC_TIME)
        if sleep_period > task_util.CONSTANTS.TASK_RETRY_MAX_TIME_PERIOD:
            sleep_period = task_util.CONSTANTS.TASK_RETRY_MAX_TIME_PERIOD
        print(sleep_period)

    print("please run test in db_manager!")
