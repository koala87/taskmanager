﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
admin 端http服务实现，解决实时命令请求

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import logging
import json

import tornado.httpserver
import tornado.web
import tornado.ioloop
import horae.models
import task_controled_by_user
import django.db

sys.path.append('../common')
import task_util
import admin_sql_manager

class AdminHttpServer(object):
    '''
        admin的http服务
    '''
    def __init__(self, config, task_dispacher):
        self.__config = config
        self.__admin_http_port = config.get("admin", "admin_http_port")
        self.__node_http_port = config.get("admin", "node_http_port")
        self.__task_dispacher = task_dispacher
        self.__http_param = HttpHandlerParams(
                self.__node_http_port, 
                self.__task_dispacher)

    def start(self):
        self.__app = tornado.web.Application(handlers=[
                (r"/stop_task", StopTaskHandler),
                (r"/stop_pipeline", StopPipelineHandler),
                (r"/restart_task", RestartTask),
                (r"/restart_pipeline", RestartPipeline), 
                (r"/list_work_dir", ListWorkDirHandler),
                (r"/get_file_content", GetFileContentHandler),
                (r"/get_file_tail", GetFileTailHandler),
                (r"/get_proceeding", GetProceeding),

            ])

        self.__httpserver = tornado.httpserver.HTTPServer(self.__app)
        self.__httpserver.listen(self.__admin_http_port)
        self.__httpserver.start()
        logging.info("admin httpserver bind[%s:%s] started!" % (
                task_util.StaticFunction.get_local_ip(), 
                self.__admin_http_port))
        tornado.ioloop.IOLoop.instance().start()

    def stop(self):
        self.__httpserver.stop()
        tornado.ioloop.IOLoop.instance().stop()
        logging.info("admin httpserver bind[%s:%s] stopped!" % (
                task_util.StaticFunction.get_local_ip(), 
                self.__admin_http_port))

class HttpHandlerParams(task_util.Singleton):
    def __init__(self, node_http_port=None, task_dispacher=None):
        if not hasattr(self, "a"):
            if node_http_port is None or task_dispacher is None:
                raise EnvironmentError("none:task_dispacher, node_http_port")

            self.node_http_port = node_http_port
            self.task_dispacher = task_dispacher
            self.a = "a"  # 必须在后面

class StopTaskHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            self.__node_http_port = HttpHandlerParams().node_http_port
            self.__sql_manager = admin_sql_manager.SqlManager()

            unique_id = self.get_argument("unique_id", "").strip()
            if unique_id == '':
                self.write("error:unique_id is none")
                return

            schedule_id = self.get_argument("schedule_id", "").strip()
            if not schedule_id:
                self.write("error:schedule_id is none")
                return

            schedule = horae.models.Schedule.objects.get(id=schedule_id)
            if schedule.status == task_util.TaskState.TASK_WAITING \
                    or schedule.status == task_util.TaskState.TASK_READY:
                if not self.__sql_manager.stop_task_with_schedule_id(
                        schedule_id):
                    self.write("error:stop waiting task failed![db error!]")
                    return

                self.write("OK")
                return

            if schedule.status != task_util.TaskState.TASK_RUNNING:
                if not self.__sql_manager.stop_task_with_schedule_id(
                        schedule_id):
                    self.write("error:stop task failed![db error!]")
                    return
                self.write("OK")
                return

            run_history = self.__sql_manager.get_runhsitory_with_id(
                    schedule_id)
            if run_history is None:
                self.write("error: find running task failed! not running!")
                return

            node_req_url = (
                    "http://%s:%s/stop_task?unique_id=%s&schedule_id=%s" % (
                    run_history.run_server, 
                    self.__node_http_port, 
                    unique_id,
                    schedule_id))
            self.write(urllib2.urlopen(node_req_url).read())
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            logging.error("stop task failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write('error:' + str(ex) + traceback.format_exc())
        finally:
            self.finish()

class StopPipelineHandler(tornado.web.RequestHandler):
    """
        此处停止pipeline可能会对task_node执行任务产生冲突，
        所以，task_node如果改写db失败，则将其任务改写状态为失败
    """
    # 停止pipeline的流程
    # 1.停止schedule里面所有waiting状态的task
    # 2.改写run_history的任务状态
    # 3.停止ready_task正在执行的任务
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            self.__sql_manager = admin_sql_manager.SqlManager()
            pl_id = self.get_argument("pl_id", "").strip()
            run_time = self.get_argument("run_time", "").strip()
            if pl_id == '' or run_time == '':
                self.write("error:pl_id or run_time is none")
                return
            pl_id = int(pl_id)
            if not self.__sql_manager.stop_pipeline(pl_id, run_time):
                self.write("error:write db failed")
                return
            self.write("OK")
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            logging.error("stop pipeline failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write('error:' + str(ex) + traceback.format_exc())
        finally:
            self.finish()

class ListWorkDirHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            self.__node_http_port = HttpHandlerParams().node_http_port
            self.__sql_manager = admin_sql_manager.SqlManager()
            schedule_id = self.get_argument("schedule_id", "").strip()
            if not schedule_id:
                self.write("error:schedule_id is none")
                return
            path = self.get_argument("path", "").strip()
            run_history = self.__sql_manager.get_runhsitory_with_id(
                    int(schedule_id))
            if run_history is None:
                self.write('error: has no ready_task info with'
                        ' schedule_id:%s' % schedule_id)
                return
            node_req_url = (
                    "http://%s:%s/list_work_dir?"
                    "schedule_id=%s&path=%s" % (
                    run_history.run_server, 
                    self.__node_http_port, 
                    schedule_id, 
                    path))
            self.write(urllib2.urlopen(node_req_url).read())
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            logging.error("list workdir failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

class GetFileContentHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            self.__node_http_port = HttpHandlerParams().node_http_port
            self.__sql_manager = admin_sql_manager.SqlManager()
            schedule_id = self.get_argument("schedule_id", "").strip()
            file_name = self.get_argument("file", "").strip()
            start = int(self.get_argument("start", "0").strip())
            len = int(self.get_argument("len", "10240").strip())
            if schedule_id.strip() == '' or file_name.strip() == '':
                self.write("admin error:schedule_id or file_name required")
                return
            run_history = self.__sql_manager.get_runhsitory_with_id(
                    int(schedule_id))
            if run_history is None:
                self.write('error: has no ready_task info with'
                        ' schedule_id:%s' % schedule_id)
                return
            node_req_url = ("http://%s:%s/get_file_content?schedule_id=%s"
                    "&file=%s&start=%d&len=%d" % (
                    run_history.run_server, 
                    self.__node_http_port, 
                    schedule_id,
                    file_name, 
                    start, 
                    len))
            self.write(urllib2.urlopen(node_req_url).read())
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            logging.error("get file content failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

class GetFileTailHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            self.__node_http_port = HttpHandlerParams().node_http_port
            self.__sql_manager = admin_sql_manager.SqlManager()
            schedule_id = self.get_argument("schedule_id", "").strip()
            file_name = self.get_argument("file", "").strip()
            if schedule_id.strip() == '' or file_name.strip() == '':
                self.write("admin error:schedule_id or file_name required")
                return
            run_history = self.__sql_manager.get_runhsitory_with_id(
                    int(schedule_id))
            if run_history is None:
                self.write('error: has no ready_task info with'
                        ' schedule_id:%s' % schedule_id)
                return
            node_req_url = ("http://%s:%s/get_file_tail?schedule_id=%s"
                    "&file=%s" % (
                    run_history.run_server, 
                    self.__node_http_port, 
                    schedule_id,
                    file_name))
            self.write(urllib2.urlopen(node_req_url).read())
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            logging.error("get file content failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

class RestartTask(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            task_pair_json = self.get_argument("task_pair_json", "").strip()
            if task_pair_json == '':
                self.write("error:task_id_list is none")
                return

            ordered = self.get_argument("ordered", "0").strip()
            if ordered != '0':
                ordered = int(ordered)
                if ordered <= 0:
                    ordered = 0
            else:
                ordered = 0

            task_pair_json = urllib2.unquote(str(task_pair_json)).decode("gbk")
            task_pair_json = json.loads(task_pair_json)
            json_task_pair_list = task_pair_json["task_pair_list"]
            task_pair_list = []
            for task_pair in json_task_pair_list:
                task_pair_list.append((
                        str(task_pair["task_id"]), 
                        task_pair["run_time"].strip()))

            task_control = task_controled_by_user.TaskControledByUser()
            ret = task_control.restart_tasks(task_pair_list, ordered)
            self.write(ret)
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            logging.error("RestartTask task failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write('error:' + str(ex) + traceback.format_exc())
        finally:
            self.finish()

class RestartPipeline(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            pl_id = self.get_argument("pl_id", "").strip()
            if pl_id == '':
                self.write("error:pipeline_id is none")
                return

            run_time = self.get_argument("run_time", "").strip()
            if run_time == '':
                self.write("error:run_time is none")
                return

            tasks = horae.models.Task.objects.filter(pl_id=pl_id)
            if tasks is None or len(tasks) <= 0:
                self.write("error:pipeline_id[%s] has no tasks." % pl_id)
                return

            task_pair_list = []
            for task in tasks:
                task_pair_list.append((str(task.id), run_time))

            task_control = task_controled_by_user.TaskControledByUser()
            ret = task_control.restart_tasks(task_pair_list, 0)
            self.write(ret)
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("error:%s" % traceback.format_exc())
        except exceptions.Exception as ex:
            logging.error("stop task failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write('error:' + str(ex) + traceback.format_exc())
        finally:
            self.finish()

class GetProceeding(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            if task_util.CONSTANTS.HOLD_FOR_ZOOKEEPER_LOCK:
                self.write('error: this server has not got lock!')
                return

            self.__node_http_port = HttpHandlerParams().node_http_port
            self.__sql_manager = admin_sql_manager.SqlManager()
            unique_id = self.get_argument("unique_id", "").strip()
            if unique_id == '':
                self.write("error:unique_id is none")
                return

            schedule_id = self.get_argument("schedule_id", "").strip()
            if not schedule_id:
                self.write("error:schedule_id is none")
                return
            run_history = self.__sql_manager.get_runhsitory_with_id(
                    int(schedule_id))
            if run_history is None:
                self.write('error: has no run_history info with'
                        ' schedule_id:%s' % schedule_id)
                return
            node_req_url = (
                    "http://%s:%s/get_proceeding?"
                    "unique_id=%s&schedule_id=%s" % (
                    run_history.run_server, 
                    self.__node_http_port, 
                    unique_id, 
                    schedule_id))
            self.write(urllib2.urlopen(node_req_url).read())
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            logging.error("stop list workdir failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

if __name__ == "__main__":
    server = HttpServer()
    server.start()
