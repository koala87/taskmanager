###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
task_node模块入口

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import signal
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import ConfigParser
import time
import os
import re
import exceptions
import logging

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "db_manager.settings")
from django.core.management import execute_from_command_line
sys.path.append('../common/db_manager')
import django

sys.path.append('../common')
import task_util
import zk_manager
import zookeeper_path_manager
import handle_ready_tasks
import no_block_sys_cmd
import node_sql_manager
import node_http_server
import common_logger
import check_limit_num

class NodeMain(object):
    """
        主程序入口相关数据初始化
    """
    def __init__(self, config):
        django.setup()
        self.__log = logging

        self.__zk_manager = zk_manager.ZookeeperManager(
                hosts = config.get("zk", "hosts"))
        # 防止同一个IP启动两个进程，否则会造成任务状态错误，必须避免
        if not self.__can_run():
            raise exceptions.EnvironmentError("this ip is handling data!")

        # 注意顺序
        self.__check_limit_num = check_limit_num.CheckLimitNum()

        self.__zk_path_mgr = zookeeper_path_manager.ZooKeeperPathManager(
                config, 
                self.__zk_manager)
        self.__handle_ready_task = handle_ready_tasks.ReadyTasksCreator(config)
        self.__http_server = node_http_server.NodeHttpServer(
                config, 
                self.__handle_ready_task)
        self.__register_signal()

    def start(self):
        self.__log.info("task node started now!")
        self.__zk_path_mgr.start()
        self.__handle_ready_task.start()
        self.__check_limit_num.start()
        self.__http_server.start()

        self.__log.info("task node ended! wait all the thread exit!")

        self.__handle_ready_task.join()
        self.__check_limit_num.join()
        self.__zk_path_mgr.join() 
        self.__log.info("task node exit! all threads exited!")
        return True

    def __sig_handler(self, signum, frame):
        task_util.CONSTANTS.GLOBAL_STOP = True
        self.__http_server.stop()
        self.__log.info(
                "receive a signal %d, will stop process. please wait" % signum)

    def __register_signal(self):
        signal.signal(signal.SIGINT, self.__sig_handler)
        signal.signal(signal.SIGTERM, self.__sig_handler)
        signal.signal(signal.SIGPIPE, signal.SIG_IGN)

    def __can_run(self):
        ip_lock_path = "%s/%s" % (
                config.get("zk", "ip_lock"), 
                task_util.StaticFunction.get_local_ip())
        if self.__zk_manager.exists(ip_lock_path) is None:
            if self.__zk_manager.create(ip_lock_path) is None:
                self.__log.error("create zk path failed![%s]" % ip_lock_path)
                return False

        node_lock = self.__zk_manager.create_lock(ip_lock_path)
        if node_lock is None:
            self.__log.error("create node lock failed![%s]" % ip_lock_path)
            return False

        return self.__zk_manager.aquire_lock(node_lock, False, 10)

if __name__ == "__main__":
    config = ConfigParser.RawConfigParser()
    config.read("./conf/node.conf")
    ip_lock = config.get("zk", "ip_lock").strip()
    pos = ip_lock.rfind('/')
    zk_path = ip_lock[0: pos]
    tag_list = [
            'script', 
            'odps_sql', 
            'apsara_job', 
            'odps_mr', 
            'odps_xlab', 
            'odps_spark']
    for tag in tag_list:
        if config.has_option("zk", tag):
             config.set(
                    "zk", 
                    tag, 
                    "%s,%s" % (
                    config.get("zk", tag), 
                    task_util.StaticFunction.get_local_ip()))
        else:
             config.set(
                    "zk", 
                    tag, 
                    "%s/script:%s" % (
                    zk_path, 
                    task_util.StaticFunction.get_local_ip()))

    common_logger.init_log(config.get("log", "log_dir"))

    node_main = NodeMain(config)
    if not node_main.start():
        sys.exit(1)

