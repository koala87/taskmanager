﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
飞天job管理

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import ConfigParser
import datetime
import select
import subprocess
import json
import exceptions
import traceback
import time
import logging
import types
import re

import simplejson
import horae.models

import task_handle_base
sys.path.append('../common')
import task_util
import node_sql_manager
import no_block_sys_cmd
import remote_sys_command
import resource_performance

class ApsaraJobTaskHandler(task_handle_base.TaskHandleBase):
    """
        启动飞天job
        获取job状态
        停止飞天job
        每一种任务都需要重新创建实例，线程不安全
    """
    def __init__(self, config):
        task_handle_base.TaskHandleBase.__init__(self, config)
        self.__run_nuwa_addr = config.get('apsara', 'nuwa_address')
        if self.__run_nuwa_addr.startswith(
                    task_util.CONSTANTS.NUWA_ADDRESS_HEAD):
            self.__run_nuwa_addr = self.__run_nuwa_addr[
                    len(task_util.CONSTANTS.NUWA_ADDRESS_HEAD): ]
        self.__apsara_deploy_dir = config.get('apsara', 'apsara_deploy_dir')
        self.__retry_times = int(config.get('apsara', 'retry_times'))
        self.__job_tools_user_key = config.get('apsara', "job_tools_user_key")
        self.__config_user_key = None
        self.__rpc_caller_clt = config.get('apsara', "rpc_caller_clt")
        self.__default_priority = config.get('apsara', "priority")
        self.__job_tools_bin = config.get('apsara', "job_tools_bin")
        self.__job_name = None
        self.__user = None
        self.__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand()
        self.__remote_sys_cmd = remote_sys_command.RemoteSysCommand()
        self.__job_work_dir = ''
        self.__use_config_user = False

    def run_task(self, task_info):
        self._job_status = task_util.TaskState.TASK_FAILED
        self._old_job_status = task_util.TaskState.TASK_READY
        while True:
            if not self._init_task(task_info):
                err_log = ("init task failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            if self._task_type != task_util.TaskType.APSARA_JOB:
                err_log = ("this is just for apsara_job[%d],but now[%d]" % \
                        (task_util.TaskType.APSARA_JOB, self._task_type))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break
            # 准备工作路径
            self.__job_work_dir = self._prepair_work_dir()
            self._add_error_log("work_ip: %s\nwork_dir: %s\n" % (
                    task_util.StaticFunction.get_local_ip(), 
                    self.__job_work_dir))

            if not self._download_package(self.__job_work_dir):
                err_log = ("download job package failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 初始化，包括配置中的时间转化，盘古路径处理，下载运行包，
            if not self._init(self.__job_work_dir):
                err_log = ("apsara job handle config failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # json.tpl转化为run.json
            if task_util.CONSTANTS.TPL_CONFIG_NAME not in self._config_map:
                err_log = (
                        "error config info [ready_task_id:%d][has no %s]" % (
                        self._ready_task_id, 
                        task_util.CONSTANTS.TPL_CONFIG_NAME))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break
            tpl_in_file = os.path.join(
                    self.__job_work_dir, 
                    self._config_map[task_util.CONSTANTS.TPL_CONFIG_NAME])
            run_json_out_file = os.path.join(
                    self.__job_work_dir, 
                    task_util.CONSTANTS.APSARA_JOB_TPL_OUT_CONFIG_NAME)
            if not self._handle_tpl_files(tpl_in_file, run_json_out_file):
                err_log = ("write file failed![%s]" % run_json_out_file)
                self._log.warn(err_log)
                self._add_error_log(err_log)
                break

            # 获取配置user key
            if not self.__create_apsara_user_key():
                err_log = ("get user key failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 替换run.json中的用户名和job_name
            if not self.__replace_run_json_param():
                err_log = ("__replace_run_json_param "
                        " failed[%s]" % self.__job_work_dir)
                self._log.warn(err_log)
                self._add_error_log(err_log)
                break
        
            # 执行飞天job
            if not self.__run_job(run_json_out_file):
                err_log = ("apsara run job failed![%s]" % str(task_info))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            self._job_status = task_util.TaskState.TASK_RUNNING
            break  # break for while True

        # 执行成功后，改写相关db数据
        # 如果写db失败了，这个时候可能导致用户数据和任务的运行情况不一致
        # 需要人工介入修改db状态
        task_handler = None
        if self.__user is not None and self.__job_name is not None:
            task_handler = "%s/%s" % (self.__user, self.__job_name)

        if not self._write_task_status_to_db(
                self._job_status, 
                self._old_job_status,
                task_handler,
                self.__job_work_dir):
            err_log = ("write_start_task_status_to_db failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            # 直接标记任务为失败，由用户决定处理
            self._set_task_status_failed()

        if self.__job_work_dir is None:
            return False

        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return self._job_status == task_util.TaskState.TASK_RUNNING

    def stop_task(self, task_info):
        if not self._init_task(task_info):
            return False
        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        ret = self.__stop_task(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_task_status(self, task_info):
        if not self._init_task(task_info):
            return task_util.TaskState.TASK_FAILED
        self._update_run_history_end_time(self._schedule_id)
        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return task_util.TaskState.TASK_FAILED
        ret = self.__get_task_status(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_proceeding(self, task_info):
        if not self._init_task(task_info):
            return False
        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        ret = self.__get_proceeding()
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def __create_apsara_user_key(self):
        if "_priority" in self._config_map \
                and self._config_map["_priority"].strip() != '':
            try:
                self.__default_priority = int(self._config_map["_priority"])
            except exceptions.Exception as ex:
                err_log = ("get _priority failed![_priority:%s]" % \
                        self._config_map["_priority"])
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False
            
        if task_util.CONSTANTS.USER_KEY_CONFIG_NAME in self._config_map:
            self.__config_user_key = self._config_map[
                    task_util.CONSTANTS.USER_KEY_CONFIG_NAME].strip()
            if self.__config_user_key != '':
                # 如果配置user key存在且和默认user 可以不一致，则用配置user key
                if self.__config_user_key != self.__job_tools_user_key:
                    self.__job_tools_user_key = self.__config_user_key
                    self.__use_config_user = True
                return True

        # 如果用户没有配置user key，则从db获取user key且用配置的user_name
        ret, ark_user = self._sql_manager.get_odps_access_info_by_userid(
                self._owner_id)
        if not ret:
            err_log = ("get apsara_user_key failed![owner_id:%s]" % \
                    self._owner_id)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        if ark_user is None \
                or ark_user.job_user_key is None \
                or ark_user.job_user_key.strip() == '':
            return True
        self.__job_tools_user_key = ark_user.job_user_key
        self.__use_config_user = True
        return True

    def __parse_job_status_detail(self, status_content):
        statusjson = self.__get_status_json_object(status_content)
        progress = {}
        status_list = ['WAITING', 'RUNNING', 'FAILED', 'TERMINATED', 'READY']
        for name, task in statusjson['tasks'].items():
            progress[name] = {}
            progress[name]['progress'] = task['progress'].upper()
            if progress[name]['progress'] == 'WAITING' \
                    or progress[name]['progress'] == 'READY':
                continue

            progress[name]['instances'] = {
                    'WAITING': 0, 
                    'RUNNING': 0, 
                    'FAILED': 0, 
                    'TERMINATED': 0, 
                    'READY': 0, 
                    'UNKNOWN': 0}
            progress[name]['try_count'] = 0
            for instance in task['instances'].values():
                status = instance['progress'].upper()
                if(status in status_list):
                    progress[name]['instances'][status] += 1
                else:
                    progress[name]['instances']['UNKNOWN'] += 1
                progress[name]['try_count'] += len(instance['history'])
        return progress

    def __get_proceeding(self):
        if self._task_handler.strip() == '':
            err_log = ("_task_handler failed![%s]" % str(task_info))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return "Failed"

        handler_split = self._task_handler.split("/")
        if len(handler_split) != 2:
            err_log = ("_task_handler failed![%s]" % str(task_info))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return "Failed"
        self.__user = handler_split[0]
        self.__job_name = handler_split[1]

        full_status_content = self.__get_full_status()
        if full_status_content is None:
            err_log = ("get full status content failed!")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return "Failed"

        try:
            info_dict = self.__parse_job_status_detail(full_status_content)
            if info_dict is None:
                err_log = ("__parse_job_status_detail failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                return "Failed"

            result = ''
            for task in info_dict:
                result += ("user: %s jobname: %s task: %s progress: %s: ["
                        "(RUNNING: %d) (TERMINATED: %d) (FAILED: %d)"
                        " (WAITING: %d) (READY: %d) (Retry: %d)]\n" % (
                        self.__user,
                        self.__job_name,
                        task,
                        info_dict[task]['progress'],
                        info_dict[task]['instances']['RUNNING'],
                        info_dict[task]['instances']['TERMINATED'],
                        info_dict[task]['instances']['FAILED'],
                        info_dict[task]['instances']['WAITING'],
                        info_dict[task]['instances']['READY'],
                        info_dict[task]['try_count']))
            return result
        except exceptions.Exception as ex:
            err_log = "get task proceeding ex:%s error: %s" % (str(ex), 
                    traceback.format_exc())
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return err_log

    def __get_task_status(self, task_info):
        status = task_util.TaskState.TASK_FAILED
        while True:
            if not self._init_task(task_info):
                err_log = ("init task failed![%s]" % str(task_info))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            if self._task_handler.strip() == '':
                err_log = ("_task_handler failed![%s]" % str(task_info))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            handler_split = self._task_handler.split("/")
            if len(handler_split) != 2:
                err_log = ("_task_handler failed![%s]" % str(task_info))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break
            self.__user = handler_split[0]
            self.__job_name = handler_split[1]

            status = self.__check_apsara_job_status()
            if status is None:
                err_log = ("get task status failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                status = task_util.TaskState.TASK_FAILED
                break

            if status == task_util.TaskState.TASK_RUNNING:
                return status

            break  # break for while True
        total_cpu, total_mem = 0, 0
        ret = self.__get_full_status()
        if ret is not None:
            jstatus_file = os.path.join(self.__job_work_dir, "jstatus.log")
            try:
                total_cpu, total_mem = \
                        resource_performance.ResourcePerformance.\
                        collect_job_using(jstatus_file)
            except exceptions.Exception as ex:
                self._log.warn("get jstatus cpu and mem info failed!"
                        "[ex: %s][trace: %s]!" % (
                        str(ex), traceback.format_exc()))

        if not self._write_task_status_to_db(
                task_status=status, 
                old_status=task_util.TaskState.TASK_RUNNING,
                cpu=total_cpu,
                mem=total_mem):
            status = task_util.TaskState.TASK_FAILED
            err_log = ("write_start_task_status_to_db failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            self._set_task_status_failed()
        # 只要任务结束，都需要清理资源
        self.__clear_task()
        return status

    def __stop_task(self, task_info):
        if not self._init_task(task_info):
            err_log = ("init task failed![%s]" % str(task_info))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        task_handle_base.TaskHandleBase.stop_task(self)
        if self._task_handler.strip() == '':
            err_log = ("_task_handler failed![%s]" % str(task_info))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        handler_split = self._task_handler.split("/")
        if len(handler_split) != 2:
            err_log = ("_task_handler failed![%s]" % str(task_info))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        self.__user = handler_split[0]
        self.__job_name = handler_split[1]
        return self.__clear_task()

    # 启动飞天job
    def __run_job(self, json_file):
        # 执行任务前，先清除任务
        self.__clear_task()

        # 尝试多次启动飞天job，直到成功
        cmd = ("%s start %s %s" % (
                self.__job_tools_bin, 
                json_file,
                self.__job_tools_user_key))
        self._add_error_log(cmd)
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                "stdout.log", 
                "stderr.log")
        if not status:
            err_log = ("run apsara job failed[status: %s\n%s\n%s]" % (
                    status, 
                    stdout, 
                    stderr))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        if stdout.find("rpc run success!") != -1:
            return True
        return False

    def __check_apsara_job_status(self):
        cmd = ("%s --Server=nuwa://%s/sys/fuxi/master/ForChildMaster "
                "--Method=GetWorkItemStatus "
                "--Parameter=nuwa://%s/%s/%s/JobMaster" % (
                self.__rpc_caller_clt,
                self.__run_nuwa_addr, 
                self.__run_nuwa_addr, 
                self.__user, 
                self.__job_name))
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                None,
                None)
        if not status:
            self._add_error_log(stdout)
            self.__get_failed_log()
            return task_util.TaskState.TASK_FAILED

        if stdout.find("Running") != -1:
            return task_util.TaskState.TASK_RUNNING

        if stdout.find("Waiting") != -1:
            return task_util.TaskState.TASK_RUNNING

        if stdout.find("Ready") != -1:
            return task_util.TaskState.TASK_RUNNING

        self._add_error_log(stdout)
        if stdout.find("Terminated") != -1:
            return task_util.TaskState.TASK_SUCCEED
        self.__get_failed_log()
        return task_util.TaskState.TASK_FAILED

    def __recurrence_replace_run_json_param(self, json_obj):
        json_keys = json_obj.keys()
        for json_key in json_keys:
            if json_key == "Name":
                if self.__use_config_user:
                    self.__job_name = json_obj[json_key].strip()
                else:
                    json_obj[json_key] = "job_new_%s" % self._schedule_id
            elif json_key == "Priority":
                if not self.__use_config_user:
                    json_obj[json_key] = 1106
            elif json_key == "User":
                if not self.__use_config_user:
                    json_obj[json_key] = \
                            task_util.CONSTANTS.APSARA_JOB_USER_NAME
                else:
                    self.__user = json_obj[json_key].strip()
            elif json_key == 'Tasks':
                tasks = json_obj['Tasks']
                task_keys = tasks.keys()
                for task_key in task_keys:
                    task = tasks[task_key]
                    if not task.has_key("ResHardLimitRatio"):
                        task["ResHardLimitRatio"] = 1.0                    

                    if not task.has_key("ExecutableUri"):
                        continue
                    json_value = task["ExecutableUri"]
                    items = json_value.split("/")
                    items[2] =  "data_platform_processor_%s" % self._pid
                    task["ExecutableUri"] = '/'.join(items)
                continue
            elif type(json_obj[json_key]) is types.DictType:
                self.__recurrence_replace_run_json_param(json_obj[json_key])
            else:
                pass

    def __replace_run_json_param(self):
        json_path = os.path.join(
                self.__job_work_dir, 
                task_util.CONSTANTS.APSARA_JOB_TPL_OUT_CONFIG_NAME)
        ret, run_json_content = task_util.\
                StaticFunction.get_all_content_from_file(json_path)
        if ret != task_util.FileCommandRet.FILE_COMMAND_SUCC:
            err_log = ("get json file failed[%s]" % json_path)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        try:
            json_object = json.loads(run_json_content)
            self.__recurrence_replace_run_json_param(json_object)
            dump_json_object = json.dumps(
                    json_object, 
                    ensure_ascii=False, 
                    sort_keys=True, 
                    indent=4)
            if task_util.StaticFunction.write_content_to_file(
                    json_path, 
                    dump_json_object) != \
                    task_util.FileCommandRet.FILE_COMMAND_SUCC:
                return False

            if not self.__use_config_user:
                self.__user = task_util.CONSTANTS.APSARA_JOB_USER_NAME
                self.__job_name = "job_new_%s" % self._schedule_id
        except exceptions.Exception as ex:
            err_log = ("get json name and job_name failed!"
                    "[json:%s][ex:%s][trace:%s]" % (
                    run_json_content, str(ex), traceback.format_exc()))
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False
        return True

    # 清理job
    def __clear_task(self):
        cmd = ("%s stop %s %s %s" % (
                self.__job_tools_bin, 
                self.__user, 
                self.__job_name,
                self.__job_tools_user_key))
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                "stdout.log", 
                "stderr.log")
        self._add_error_log(cmd)
        if not status:
            return False
        return True

    def __get_full_status(self):
        cmd = ("%s --Server=nuwa://%s/%s/%s/JobMaster "
                " --Method=GetJobStatus --Parameter=a" % (
                self.__rpc_caller_clt, 
                self.__run_nuwa_addr, 
                self.__user, 
                self.__job_name))
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                "jstatus.log", 
                "jstatus.err")
        if not status:
            return None
        return stdout

    def __get_status_json_object(self, full_status_content):
        try:
            pos = full_status_content.find('{')
            full_status_str = full_status_content[pos:]
            status_json = simplejson.loads(full_status_str)
            return status_json
        except ValueError:
            err_log = ("exception:\n%s" % traceback.format_exc())
            self._log.error(err_log)
            self._add_error_log(err_log)
            return None
        except exceptions.Exception as ex:
            err_log = ("parse full status error:%s" % traceback.format_exc())
            self._log.error(err_log)
            self._add_error_log(err_log)
            return None

    def __get_instatnce_info(self):
        full_status_content = self.__get_full_status()
        if full_status_content is None:
            err_log = ("get full status failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return None

        status_file = os.path.join(self.__job_work_dir, "jstatus_stdout.log")
        if task_util.StaticFunction.write_content_to_file(
                status_file, 
                full_status_content) != \
                task_util.FileCommandRet.FILE_COMMAND_SUCC:
            err_log = ("write status [%s] failed!" % full_status_content)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return None

        status_json = self.__get_status_json_object(full_status_content)
        if status_json is None:
            err_log = ("parse full status failed! "
                    "status:%s" % full_status_content)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return None

        tasks = status_json['tasks']
        task_info_list = []
        for name, task in tasks.iteritems():
            instance_list = task['instances']
            for instance_name, instance_info in instance_list.iteritems():
                instance_item = {
                        'name': instance_name, 
                        'work_dir': '', 
                        'work_host': '', 
                        'status': "Unknown"}
                history_list = instance_info['history']
                if len(history_list) < 1:
                    continue

                history = history_list[0]
                if history['workerName']:
                    instance_item['work_dir'] = os.path.join(
                            '/apsara/tubo/TempRoot/', 
                            history['workerName'])

                if history['workerAddress']:
                    host_str = history['workerAddress']
                    reg_obj = re.search(r'\d+\.\d+\.\d+\.\d+', host_str)
                    if reg_obj is not None:
                        instance_item['work_host'] = reg_obj.group()

                if  history['progress']:
                    instance_item['status'] = history['progress']
                task_info_list.append(instance_item)
        return task_info_list

    # 任务失败后，需要获取相关失败日志，并写入工作目录
    def __get_failed_log(self):
        task_info_list = self.__get_instatnce_info()
        if task_info_list is None or len(task_info_list) <= 0:
            err_log = ("get instance info failed")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False

        work_host = None
        work_dir = None
        for item in task_info_list:
            if item['status']!= "Failed" \
                    and (not item['work_dir']) \
                    and (not item['work_host']):
                continue
            work_host = item['work_host']
            work_dir = item['work_dir']
            break

        if work_host is None or work_dir is None:
            err_log = ("no failed instatnce")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        cmd = "ssh %s ls %s " % (work_host, work_dir)
        file_list = self.__remote_sys_cmd.execute_cmd(cmd)
        log_file_list = []
        for item in file_list:
            search_obj = re.search(r'.*\.LOG$', item)
            if search_obj is not None:
                log_file_list.append(search_obj.group())

        if len(log_file_list) <= 0:
            err_log = ("can't find LOG file %s@%s" % (work_host, work_dir))
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False

        for item in log_file_list:
            cmd = "ssh %s cat %s/%s" % (
                    work_host, 
                    work_dir, 
                    item)
            content = self.__remote_sys_cmd.execute_cmd(cmd)
            if content is None or len(content) <= 0:
                return False
            content = ''.join(content)
            file_name = os.path.join(self.__job_work_dir, item)
            ret = task_util.StaticFunction.write_content_to_file(
                    file_name, 
                    content)
            if ret != task_util.FileCommandRet.FILE_COMMAND_SUCC:
                err_log = ("write file filed![ret:%d][%s][content:%s]" % (
                        ret, file_name, content))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False
        return True

if __name__ == "__main__":
    print("please run unit test in common/db_manager")
