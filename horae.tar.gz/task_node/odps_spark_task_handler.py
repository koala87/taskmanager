﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
odps-spark任务管理

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import ConfigParser
import datetime
import select
import subprocess
import threading
import traceback
import time
import exceptions
import logging

import horae.models

import task_handle_base
sys.path.append('../common')
import task_util
import node_sql_manager
import no_block_sys_cmd

class OdpsSparkTaskHandler(task_handle_base.TaskHandleBase):
    """
        启动odps-spark任务，非阻塞
        每一种任务都需要重新创建实例，线程不安全
    """
    def __init__(self, config):
        task_handle_base.TaskHandleBase.__init__(self, config)
        self.__odps_cmd = config.get("node", "odps_sql")
        self.__job_work_dir = None
        self.__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand()

    def run_task(self, task_info):
        self._job_status = task_util.TaskState.TASK_FAILED
        self._old_job_status = task_util.TaskState.TASK_READY
        while True:
            if not self._init_task(task_info):
                err_log = ("init task failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            if self._task_type != task_util.TaskType.ODPS_SPARK:
                err_log = (
                        "this is just for odps_sql[%d],but now[%d]" % \
                        (task_util.TaskType.ODPS_SPARK, self._task_type))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 准备工作路径
            self.__job_work_dir = self._prepair_work_dir()
            self._add_error_log("work_ip: %s\nwork_dir: %s\n" % (
                    task_util.StaticFunction.get_local_ip(), 
                    self.__job_work_dir))

            if not self._download_package(self.__job_work_dir):
                err_log = ("download job package failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 初始化，包括配置中的时间转化，盘古路径处理，
            if not self._init(self.__job_work_dir):
                err_log = ("odps spark task handle config failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # spark.conf.tpl转化为spark.conf
            tpl_in_file = os.path.join(
                    self.__job_work_dir, 
                    'conf',
                    task_util.CONSTANTS.ODPS_SPARK_TPL_CONF_NAME)
            if os.path.exists(tpl_in_file):
                spark_out_file = os.path.join(
                        self.__job_work_dir, 
                        'conf',
                        task_util.CONSTANTS.ODPS_SPARK_CONF_NAME)
                if not self._handle_tpl_files(tpl_in_file, spark_out_file):
                    err_log = ("write tpl file failed![%s]" % \
                            spark_out_file)
                    self._log.warn(err_log)
                    self._add_error_log(err_log)
                    break

            if not self.__replace_userjar():
                err_log = ("__replace_userjar failed![%s]" % str(task_info))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 执行odps-spark，非阻塞执行，需要定时获取执行状态
            if not self.__run_job():
                err_log = ("script run job failed![%s]" % str(task_info))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            self._job_status = task_util.TaskState.TASK_RUNNING
            break  # break for while True

        # 执行成功后，改写相关db数据
        # 如果写db失败了，这个时候可能导致用户数据和任务的运行情况不一致
        # 需要人工介入修改db状态
        if not self._write_task_status_to_db(
                self._job_status, 
                self._old_job_status,
                None,
                self.__job_work_dir):
            err_log = ("write_start_task_status_to_db failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            self._set_task_status_failed()

        if self.__job_work_dir is None:
            return False

        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return self._job_status == task_util.TaskState.TASK_RUNNING

    def stop_task(self, task_info):
        if not self._init_task(task_info):
            return False

        if not self._handle_config():
            return False

        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        ret = self.__stop_task(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_task_status(self, task_info):
        if not self._init_task(task_info):
            return task_util.TaskState.TASK_FAILED
 
        self._update_run_history_end_time(self._schedule_id)
        if not self._handle_config():
            return task_util.TaskState.TASK_FAILED

        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return task_util.TaskState.TASK_FAILED
        ret = self.__get_task_status(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_proceeding(self, task_info):
        if not self._init_task(task_info):
            return False
 
        if not self._handle_config():
            return False

        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        ret = self.__get_proceeding()
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def __get_proceeding(self):
        ret, instance_id = self.__get_instance_id()
        if not ret:
            err_log = ("__get_instance_id failed!")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return err_log

        if instance_id is None:
            return "get no instance!"

        status = self.__check_odps_instance_status(instance_id)
        result_map = {}
        result_map["instance"] = instance_id
        result_map["status"] = task_util.global_status_info_map[status]
        return str(result_map)

    def __get_task_status(self, task_info):
        try_count = 0
        ret = False
        instance = None
        while try_count < 60:
            if task_util.CONSTANTS.GLOBAL_STOP:
                return False

            ret, instance = self.__get_instance_id()
            if not ret:
                break

            if instance is not None:
                break
            try_count += 1
            time.sleep(10)

        if try_count >= 60:
            self._add_error_log('\nget none instnce in 600s')
            ret, instance = False, None

        status = task_util.TaskState.TASK_FAILED
        if ret:
            if instance is None:
                return task_util.TaskState.TASK_RUNNING

            status = self.__check_odps_instance_status(instance)

        if status == task_util.TaskState.TASK_RUNNING:
            return task_util.TaskState.TASK_RUNNING

        if not self._write_task_status_to_db(
                status, 
                task_util.TaskState.TASK_RUNNING):
            err_log = ("write_start_task_status_to_db failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            status = task_util.TaskState.TASK_FAILED
            self._set_task_status_failed()
        return status

    def __stop_task(self, task_info):
        task_handle_base.TaskHandleBase.stop_task(self)
        instance_list = []
        ret, instance = self.__get_instance_id()
        if instance is None:
            ret, instance = self.__get_broadcast_instance()
            if instance is None:
                return True

        cmd = task_util.CONSTANTS.ODPS_SQL_CMD_STR % (
                self.__odps_cmd, 
                self._config_map["_odps_project"],
                self._config_map["_odps_endpoint"],
                self._config_map["_priority"],
                self._config_map["_odps_access_id"],
                self._config_map["_odps_access_key"],
                "kill " + instance)
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                None, 
                None)
        self._add_error_log("%s\n%s\n%s\n%s" % (
                cmd, status, stdout, stderr))
        return True

    # TODO：确认下odps通过ret_code是否可以确定任务运行成功，
    #       如果可以则不用检查instance的status
    # odpscmd [OPTION]
    # 参数    说明
    # --help/-h                       显示odpscmd的帮助信息
    # --project=<prj_name>            指定登录odpscmd后进入的默认project
    # --endpoint=<http://host:port>   设置odpscmd访问的odps server的地址
    #                                 （仅用于debug）
    # -u <user_name> -p <password>    输入accessid(user_name)和
    #                                 accesskey(password)
    # -M  以CSV格式显示返回结果
    # -e <"command;[command;]...">    串行执行console、安全命令或是sql、
    #                                 DT、MR语句，执行结束后退出odpscmd。
    #                                 -e后面可以接多个命令，需要用”;”分割。
    #                                 当某个命令执行失败后会中止，
    #                                 不再执行后面的命令。
    # -f <"file_path;">               串行执行一个文本文件中的console、安全
    #                                 命令或是sql、DT、MR语句，执行结束后退出
    #                                 odpscmd。文本文件中可以包括多个命令，
    #                                 需要用”;”分割。当某个命令执行失败后会
    #                                 中止，不再执行后面的命令。
    def __run_job(self):
        if '_odps_spark_jar' not in self._config_map \
                or self._config_map['_odps_spark_jar'].strip() == '':
            err_log = ("get _odps_spark_jar failed![%s]")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        jar_name = self._config_map['_odps_spark_jar']

        param_index = 0
        param_list = []
        while not task_util.CONSTANTS.GLOBAL_STOP:
            param_index = param_index + 1
            odps_args_key = "_odps_spark_args_%s" % param_index

            if odps_args_key not in self._config_map:
                break

            if self._config_map[odps_args_key].strip() == '':
                continue
            param_list.append(self._config_map[odps_args_key].strip())

        args_param = ''
        if len(param_list) > 0:
            args_param = ' '.join(param_list)

        if '_odps_spark_mainclass' not in self._config_map \
                or self._config_map['_odps_spark_mainclass'].strip() == '':
            err_log = ("get _odps_spark_mainclass failed![%s]")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        main_class_param = self._config_map['_odps_spark_mainclass']

        cmd = "cd %s && java -cp %s/target/%s %s %s" % (
                self.__job_work_dir, 
                self.__job_work_dir, 
                jar_name, 
                main_class_param, 
                args_param)
        self._add_error_log(cmd)
        stdout_file = os.path.join(self.__job_work_dir, "stdout.log")
        stderr_file = os.path.join(self.__job_work_dir, "stderr.log")
        if self.__no_block_cmd.run_in_background(
                cmd, 
                stdout_file, 
                stderr_file) != 0:
            err_log = ("odps sql run cmd[%s] failed!" % cmd)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        return True

    def __get_instance_id(self):
        """ 
            moye was unable to load moyeLogProps
            Using Moye's default log4j profile: org/apache/spark/log4j-defaults.properties
            15/08/18 14:54:34 [1] INFO SparkConf: Load conf/spark.conf
            15/08/18 14:54:34 [1] INFO SparkConf: moye version:1
            15/08/18 14:54:36 [1] INFO BridgeAppRunner: instance:20150818065435749gftbm834
            15/08/18 14:54:47 [1] INFO BridgeAppRunner: applying resources...
            15/08/18 14:54:47 [1] INFO BridgeAppRunner: resources ok
            15/08/18 14:54:48 [1] INFO BridgeAppRunner: SparkConf to upload:
            15/08/18 14:54:55 [1] INFO ResourceBroadcast: broadcast instanceId:20150818065455519g80vj7sb1
            15/08/18 14:54:55 [1] INFO ResourceBroadcast: broadcasting...
            15/08/18 14:54:59 [1] INFO ResourceBroadcast: {"progress":0,"result":"init the job","status":"ready"}
            15/08/18 14:55:00 [1] INFO ResourceBroadcast: broadcasting...
            15/08/18 14:55:00 [1] INFO ResourceBroadcast: {"progress":100,"result":"broadcast success","status":"success"}
            15/08/18 14:55:00 [1] INFO ResourceBroadcast: broadcast ok
            15/08/18 14:55:02 [1] INFO SubmitJobUtil: {"progress":0,"result":"init the job","status":"ready"}
            15/08/18 14:55:03 [1] INFO SubmitJobUtil: getpartition size ok
            15/08/18 14:55:04 [1] INFO OdpsRDD: project=aliyun_searchlog,table=wc_in,partitionsize=1
            15/08/18 14:55:05 [1] INFO BridgeAppRunner: instance:20150818065505369grolrk64
            15/08/18 14:55:05 [1] INFO BridgeAppRunner: init the job
            15/08/18 14:55:09 [1] INFO BridgeAppRunner: now submit the job
            15/08/18 14:55:11 [1] INFO BridgeAppRunner: moye_0(0%)
            15/08/18 14:55:14 [1] INFO BridgeAppRunner: moye_0(50%)	stage_1_0(1/1)
            15/08/18 14:55:15 [1] INFO BridgeAppRunner: save table:aliyun_searchlog.wc_out
            15/08/18 14:55:17 [1] INFO SparkContext: Job finished: save at OdpsOps.scala:77, took 12.34334666 s
            15/08/18 14:55:17 [1] INFO BridgeAppRunner: stop resource ok        
        """
        stderr_file = os.path.join(self.__job_work_dir, "stderr.log")
        if not os.path.exists(stderr_file):
            err_log = ("std out file is not exists.[%s]" % stderr_file)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False, None
        stderr_read_fd = open(stderr_file, "r")
        try:
            finded_first_instance = False
            while not task_util.CONSTANTS.GLOBAL_STOP:
                line = stderr_read_fd.readline()
                if line is None or line == '':
                    break

                line = line.strip()
                if line == '':
                    continue

                if not self._stop_task:
                    if line.upper().find('FAILED') != -1 \
                            or line.upper().find('EXCEPTION') != -1:
                        return False, None

                if line.find("BridgeAppRunner: instance") != -1:
                    if not finded_first_instance:
                        finded_first_instance = True
                        continue
                    split_list = line.split(":")
                    return True, split_list[len(split_list) - 1].strip()
            return True, None
        except exceptions.Exception as ex:
            err_log = ("get instance id failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False, None
        finally:
            stderr_read_fd.close()

    def __get_broadcast_instance(self):
        stderr_file = os.path.join(self.__job_work_dir, "stderr.log")
        if not os.path.exists(stderr_file):
            err_log = ("std out file is not exists.[%s]" % stderr_file)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False, None
        stderr_read_fd = open(stderr_file, "r")
        try:
            while not task_util.CONSTANTS.GLOBAL_STOP:
                line = stderr_read_fd.readline()
                if line is None or line == '':
                    break

                line = line.strip()
                if line == '':
                    continue

                if not self._stop_task:
                    if line.upper().find('FAILED') != -1 \
                            or line.upper().find('EXCEPTION') != -1:
                        return False, None

                if line.find("ResourceBroadcast: broadcast instanceId") != -1:
                    split_list = line.split(":")
                    return True, split_list[len(split_list) - 1].strip()
            return True, None
        except exceptions.Exception as ex:
            err_log = ("get instance id failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False, None
        finally:
            stderr_read_fd.close()

    # 检查odps-sql的每一个instance是否success，如果有一个失败则失败
    def __check_odps_instance_status(self, instance):
        cmd = task_util.CONSTANTS.ODPS_SQL_CMD_STR % (
                self.__odps_cmd, 
                self._config_map["_odps_project"],
                self._config_map["_odps_endpoint"],
                self._config_map["_priority"],
                self._config_map["_odps_access_id"],
                self._config_map["_odps_access_key"],
                "status " + instance)
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                None, 
                None)
        if not status:
            return task_util.TaskState.TASK_FAILED

        if stdout.find("Running") != -1:
            return task_util.TaskState.TASK_RUNNING

        if stdout.find("Waiting") != -1:
            return task_util.TaskState.TASK_WAITING

        if stdout.find("Ready") != -1:
            return task_util.TaskState.TASK_READY

        if stdout.find("Success") != -1:
            return task_util.TaskState.TASK_SUCCEED

        if stdout.find("Failed") != -1:
            return task_util.TaskState.TASK_FAILED

        # 没有状态，则任务还在执行
        return task_util.TaskState.TASK_RUNNING

    def __replace_userjar(self):
        if '_odps_spark_jar' not in self._config_map:
            err_log = ("_odps_spark_jar not in _config_map")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        config_path = os.path.join(
                self.__job_work_dir, 
                'conf', 
                task_util.CONSTANTS.ODPS_SPARK_CONF_NAME)
        if not os.path.exists(config_path):
            err_log = ("file not exists %s" % config_path)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        data_fd = open(config_path, "r")
        line_list = []
        try:
            while True:
                line = data_fd.readline()
                if line is None or line == '':
                    break

                line = line.strip()
                if line == '':
                    continue

                if line.startswith("spark.run.userjar"):
                    jar_path = os.path.join(
                            self.__job_work_dir, 
                            'target', 
                            self._config_map['_odps_spark_jar'])

                    content = "spark.run.userjar=%s" % jar_path
                    line_list.append(content)
                    continue

                line_list.append(line)
        except exceptions.Exception as ex:
            err_log = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        finally:
            data_fd.close()

        tmp_file = os.path.join(
                self.__job_work_dir, 
                'conf', 
                'tmp.conf')
        tmp_file_fd = open(tmp_file, "w")
        write_str = '\n'.join(line_list)
        try:
            tmp_file_fd.write(write_str)
        except exceptions.Exception as ex:
            err_log = ("somthing failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        finally:
            tmp_file_fd.close()

        cmd = 'mv %s %s' % (tmp_file, config_path)
        self.__no_block_cmd.run_once(cmd)
        return True
