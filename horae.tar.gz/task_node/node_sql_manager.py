﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
node相关db操作

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import exceptions
import time
import traceback
import logging

from enum import Enum
import decorator
import MySQLdb

sys.path.append('../common')
import task_util

import django.db
import horae.models
import django.db.models
import django.core.exceptions
import dms.models
import ark_user.models
import common.models

class ConstantSql(Enum):
    ALL_READY_TASK_SQL = (
            "select d.id, d.pl_id, d.schedule_id, d.type, "
            "d.task_id, d.run_time, d.pid, d.config, "
            "e.template, d.priority, d.except_ret, d.over_time, "
            "d.status, d.task_handler, d.owner_id, d.work_dir, "
            "d.retried_count, d.retry_count "
            "from ( "
            "    select a.id, a.pl_id, a.schedule_id, a.type, a.run_time, "
            "    a.task_id, a.pid, a.status, a.task_handler, a.owner_id, "
            "    a.work_dir, a.retried_count, a.retry_count, "
            "    b.config, b.priority, b.except_ret, b.over_time from( "
            "        select "
            "           id, pl_id, schedule_id, type, run_time, "
            "           task_id, pid, status, task_handler, "
            "           owner_id, work_dir, retried_count, retry_count "
            "        from horae_readytask  "
            "        where run_server = %s and status in (%s, %s, %s) "
            "     ) a "
	        "    left outer join( "
	        "        select id, config, priority, except_ret, over_time "
            "        from horae_task "
	        "    )b on a.task_id = b.id where b.id is not null "
            ") d "
            "left outer join( "
            "    select id, template from horae_processor "
            ") e "
            "on d.pid = e.id where e.id is not null; ")
    ALL_READY_TASK_SQL_PARAM_NUM = 16  # 这个字段必须和
                                       # ALL_READY_TASK_SQL获取的字段数一致

    GET_READY_TASK_BY_SCHEDULE_ID_SQL = (
            "select a.id, a.pl_id, a.schedule_id, a.type, "
            "a.task_id, a.run_time, a.pid, b.config, "
            " '' as template, b.priority, b.except_ret, b.over_time, "
            "a.status, a.task_handler, a.owner_id, a.work_dir, "
            "0 as retried_count, 0 as retry_count from( "
            "    select id, pl_id, schedule_id, type, run_time, "
            "    task_id, 0 as pid, status, task_handler, "
            "    0 as owner_id, '%s' as work_dir "
            "    from horae_runhistory "
            "    where schedule_id = %s "
            ") a left outer join( "
	        "    select id, config, priority, except_ret, over_time "
            "    from horae_task "
	        ")b on a.task_id = b.id where b.id is not null;")
                    
    UPDATE_ALL_READY_TASK = ("update horae_readytask "
            "set status=%s where run_server=%s and status = %s;")

    OWNER_ID_LIST_SQL = ("select max(id) from common_permhistory where "
            "resource_type = 'pipeline' and resource_id = %d group by "
            "applicant_id;")

class SqlManager(object):
    def __init__(self):
        self.__log = logging

    # 从schedule，task表获取所有的可调用的任务
    def get_all_ready_tasks(self, local_ip):
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(
                    ConstantSql.ALL_READY_TASK_SQL, [
                    local_ip, 
                    task_util.TaskState.TASK_READY, 
                    task_util.TaskState.TASK_RUNNING,
                    task_util.TaskState.TASK_TIMEOUT]) 
            task_records = cursor.fetchall()
            if task_records is None or len(task_records) <= 0:
                return None
            return task_records
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    # 通过schedule_id获取任务信息
    def get_task_info_with_schedule_id(self, work_dir, schedule_id):
        tmp_sql = ConstantSql.GET_READY_TASK_BY_SCHEDULE_ID_SQL % (
                work_dir,
                schedule_id) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            task_records = cursor.fetchall()
            if task_records is None or len(task_records) <= 0:
                return None
            return task_records[0]
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    # 事务性执行多个sql命令
    @django.db.transaction.atomic
    def batch_execute_with_affect_one(
            self, 
            sql_save_list=None, 
            sql_del_list=None,
            sql_src_list=None):
        try:
            with django.db.transaction.atomic():
                if sql_save_list is not None:
                    for object in sql_save_list:
                        object.save()

                if sql_del_list is not None:
                    for object in sql_del_list:
                        object.delete()

                if sql_src_list is not None:
                    cursor = django.db.connection.cursor()
                    for sql in sql_src_list:
                        change_row = cursor.execute(sql)
                        if change_row != 1:
                            raise exceptions.Exception(
                                    "exe %s failed[changed row[%s]" % (
                                    sql, change_row))
                return True
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            sql_str_list = '';
            if sql_src_list is not None and len(sql_src_list) > 0:
                sql_str_list = '\n'.join(sql_src_list)
            self.__log.warn("execute sql failed![sql:%s][%s][trace:%s]!" % (
                    sql_str_list, str(ex), traceback.format_exc()))
            return False

    def update_all_ready_task_to_failed(self, local_ip):
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(
                    ConstantSql.UPDATE_ALL_READY_TASK, [
                            task_util.TaskState.TASK_FAILED, 
                            local_ip, 
                            task_util.TaskState.TASK_RUNNING]) 
            return True
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            tmp_sql = ConstantSql.UPDATE_ALL_READY_TASK
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return False

    def delete_user_stopped_task_with_id(self, id):
        try:
            horae.models.ReadyTask.objects.get(id=id).delete()
            return True
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            self.__log.error("delete_user_stopped_task_with_schedule_id"
                    " failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False

    def get_datapath_by_dataname(self, data_name, data_type):
        try:
            data_info = dms.models.Config.objects.get(
                    name=data_name,
                    type=data_type)
            if data_info is None:
                return None
            return data_info.path
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_odps_access_info_by_userid(self, user_id):
        try:
            ark_user_info = ark_user.models.Info.objects.get(user_id=user_id)
            return True, ark_user_info
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            time.sleep(10)  # 避免异常
            return self.get_odps_access_info_by_userid(user_id)
        except django.core.exceptions.ObjectDoesNotExist:
            return True, None
        except exceptions.Exception as ex:
            self.__log.error("get odps access failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            self.__close_old_connections(str(ex))
            return False, None

    def get_task_num_with_group_type(self):
        try:
            sql = (
                    "select type, count(id) from horae_readytask "
                    " where status = 1 and run_server = '%s' "
                    " group by type;" % task_util.StaticFunction.get_local_ip())
            cursor = django.db.connection.cursor()
            cursor.execute(sql) 
            rows = cursor.fetchall()
            len(rows)
            return rows
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_owner_task_num_with_type(self):
        try:
            sql = (
                    "select type, owner_id, count(id) from horae_readytask "
                    " where status = 1 and run_server = '%s' "
                    " group by type, owner_id;" % 
                    task_util.StaticFunction.get_local_ip())
            cursor = django.db.connection.cursor()
            cursor.execute(sql) 
            rows = cursor.fetchall()
            len(rows)
            return rows
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_owner_mail_list(self, pipeline_id, owner_id):
        tmp_sql = ConstantSql.OWNER_ID_LIST_SQL % pipeline_id
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            id_list = []
            for row in rows:
                id_list.append(int(row[0]))

            mail_list = []
            if len(id_list) > 0:
                perm_historys = common.models.PermHistory.objects.filter(
                        id__in=id_list,
                        permission=task_util.UserPermissionType.WRITE_STR,
                        status__in=(
                                task_util.AuthAction.CONFIRM_APPLY_AUTH, 
                                task_util.AuthAction.GRANT_AUTH_TO_OTHER))
                for perm in perm_historys:
                    if perm.applicant_id is None:
                        continue
                    user = django.contrib.auth.models.User.objects.get(
                            id=perm.applicant_id)
                    if user.email is not None and user.email.strip() != '':
                        mail_list.append(user.email.strip())

            user = django.contrib.auth.models.User.objects.get(
                    id=owner_id)
            if user.email is not None and user.email.strip() != '':
                mail_list.append(user.email.strip())

            if len(mail_list) <= 0:
                return None

            return ','.join(mail_list)
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    @django.db.transaction.atomic
    def stop_task_with_schedule_id(self, schedule_id):
        try:
            with django.db.transaction.atomic():
                schedule = horae.models.Schedule.objects.get(id=schedule_id)
                if schedule.status not in (
                        task_util.TaskState.TASK_READY, 
                        task_util.TaskState.TASK_RUNNING, 
                        task_util.TaskState.TASK_TIMEOUT, 
                        task_util.TaskState.TASK_WAITING):
                    return True

                schedule.status=task_util.TaskState.TASK_STOPED_BY_USER
                run_history = horae.models.RunHistory.objects.get(
                        task_id=schedule.task_id, 
                        run_time=schedule.run_time)
                run_history.status=task_util.TaskState.TASK_STOPED_BY_USER
                schedule.save()
                run_history.save()

                ready_tasks = horae.models.ReadyTask.objects.filter(
                        schedule_id=schedule_id)
                if len(ready_tasks) <= 0:
                    return True

                ready_task = ready_tasks[0]
                ready_task.delete()
            return True
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False

if __name__ == "__main__":
    sql_mgr = SqlManager("./conf/node_logger.conf")
    print(sql_mgr.get_all_ready_tasks('test'))