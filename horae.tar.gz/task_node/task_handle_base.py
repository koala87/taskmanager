﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
任务执行基类

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import ConfigParser
import datetime
import shutil
import re
import os
import exceptions
import traceback
import subprocess
import time
import logging
import statvfs
import tempfile

import horae.models
import MySQLdb
import django.db

sys.path.append('../common')
import task_util
import pangu_command
import no_block_sys_cmd
import linux_file_cmd
import node_sql_manager

class TaskHandleBase(object):
    """
        任务处理基类
    """
    def __init__(self, config):        
        self._log = logging
        self._config_map = {}
        self._conf_replace_pattern = '\$\{[^}]*\}'
        self._replace_pair_map = {}
        self._pangu_cmd = pangu_command.PanguCommand(config)
        self.__disks = config.get('node', 'disks').split(';')
        self._pangu_package_dir = config.get('apsara', 'pu_package_dir')
        self._sys_cmd = no_block_sys_cmd.NoBlockSysCommand()
        self._local_file_cmd = linux_file_cmd.LinuxFileCommand()
        self._sql_manager = node_sql_manager.SqlManager()
        self._job_status = task_util.TaskState.TASK_FAILED
        self._old_job_status = task_util.TaskState.TASK_FAILED
        self._stop_task = False
        self._error_list = []
        self._odps_project = config.get('odps', 'project')
        self._odps_endpoint = config.get('odps', 'endpoint')
        self._odps_access_id = config.get('odps', 'access_id')
        self._odps_access_key = config.get('odps', 'access_key')
        self._odps_default_priority = config.get('odps', 'odps_priority')
        self._sql_count = 0

    def stop_task(self):
        self._stop_task = True
        self._job_status = task_util.TaskState.TASK_STOPED_BY_USER
        return True

    def _append_default_config(self):
        if '_schedule_id' not in self._config_map:
            self._config_map['_schedule_id'] = str(self._schedule_id)

        if '_filecount' not in self._config_map:
            self._config_map['_filecount'] = str(
                    task_util.CONSTANTS.DEFAULT_INSTANCE_COUNT)

        if '_pocessor_id' not in self._config_map:
            self._config_map['_pocessor_id'] = str(self._pid)

        if '_odps_project' not in self._config_map \
                or self._config_map['_odps_project'].strip() == '':
            self._config_map['_odps_project'] = self._odps_project

        if '_odps_endpoint' not in self._config_map \
                or self._config_map['_odps_endpoint'].strip() == '':
            self._config_map['_odps_endpoint'] = self._odps_endpoint

        if '_priority' not in self._config_map \
                or self._config_map['_priority'].strip() == '':
            self._config_map['_priority'] = self._odps_default_priority

        """
        if '_odps_access_id' not in self._config_map \
                or self._config_map['_odps_access_id'].strip() == '':
            ret, ark_user = self._sql_manager.get_odps_access_info_by_userid(
                    self._owner_id)
            if not ret:
                err_log = ("get odps access info failed![owner_id:%s]" % \
                        self._owner_id)
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False

            if ark_user is not None \
                    and ark_user.odps_access_id is not None \
                    and ark_user.odps_access_key is not None:
                self._config_map['_odps_access_id'] = ark_user.odps_access_id
                self._config_map['_odps_access_key'] = ark_user.odps_access_key
        """

        if '_odps_access_id' not in self._config_map \
                or self._config_map['_odps_access_id'].strip() == '':
            self._config_map['_odps_access_id'] = self._odps_access_id

        if '_odps_access_key' not in self._config_map \
                or self._config_map['_odps_access_key'].strip() == '':
            self._config_map['_odps_access_key'] = self._odps_access_key

        return True

    def _init(self, work_dir):
        return self._handle_config() \
                and self._replace_path_with_pangu_data_node() \
                and self._replace_path_with_odps_data_node() \
                and self._config_replace_time_by_run_time(work_dir) \
                and self._handle_file_path()

    # 从配置中读取配置的kv对，并写入map
    def _handle_config(self):
        if self._config is None:
            self._config = ""

        config_list = self._config.split("\n")
        if len(config_list) <= 0:
            err_log = ("no more config info [ready_task_id:%s]" % \
                    self._ready_task_id)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return True

        for config in config_list:
            if config.strip() == '':
                continue

            find_pos = config.find('=')
            if find_pos == -1:
                err_log = ("%s %s error config info "
                        "[ready_task_id:%d][conf:%s]" % (
                        __file__, sys._getframe().f_lineno, 
                        self._ready_task_id, config))
                self._log.error(err_log)
                self._add_error_log(err_log)
                continue
            # 去除两端空格
            key = config[0: find_pos].strip()
            if key == '':
                continue
            value = config[find_pos + 1: len(config)].strip()
            if len(value) >= task_util.CONSTANTS.MAX_CONFIG_VALUE_LENGTH:
                err_log = ("config value [%s] extended max len[%s]" % (
                        value, 
                        task_util.CONSTANTS.MAX_CONFIG_VALUE_LENGTH))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False

            self._config_map[key] = value
        # 设置系统默认配置
        return self._append_default_config()

    # 根据odps配置节点名替换相关odps参数
    def _replace_path_with_odps_data_node(self):
        for config_key in self._config_map:
            data_node_pattern = '.*%(.*):(.*)%(.*)'
            regex_match = re.match(
                    data_node_pattern, 
                    self._config_map[config_key])
            if regex_match is None:
                continue

            data_part = regex_match.group(2).strip()
            if data_part != 'project' \
                    and data_part != 'table' \
                    and data_part != 'part':
                continue

            data_name = regex_match.group(1)
            data_path = self._sql_manager.get_datapath_by_dataname(
                    data_name, 
                    task_util.DataType.ODPS_DATA_TYPE)
            if data_path is None:
                err_log = ("get data path from db failed[%s][%s] " % (
                        data_name, self._config_map[config_key]))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False
             
            if len(data_path) <= len('odps://'):
                continue

            head_pos = len('odps://')
            tmp_path = data_path[head_pos:]
            point_pos = tmp_path.find('.')
            if point_pos == -1:
                if data_part == 'project':
                    continue
                point_pos = -1

            if data_part == 'project':
                self._config_map[config_key] = tmp_path[: point_pos]
            elif data_part == 'table':
                table_pos = tmp_path.find(':')
                if table_pos == -1:
                    continue
                self._config_map[config_key] = tmp_path[
                        point_pos + 1: table_pos]
            elif data_part == 'part':
                table_pos = tmp_path.find(':')
                if table_pos == -1:
                    continue
                self._config_map[config_key] = "%s%s" % (
                        tmp_path[table_pos + 1:], 
                        regex_match.group(3))
            else:
                self._log.warn("get odps path info failed![%s]" % \
                        self._config_map[config_key])
            
        return True

    # 根据数据节点名替换盘古路径
    def _replace_path_with_pangu_data_node(self):
        for config_key in self._config_map:
            data_node_pattern = '.*%(.*):file%.*'
            regex_match = re.match(
                    data_node_pattern, 
                    self._config_map[config_key])
            is_file = False
            data_name = None
            if regex_match is not None:
                is_file = True
                data_name = regex_match.group(1)
            else:
                data_node_pattern = '.*%(.*):dir%.*'
                regex_match = re.match(
                        data_node_pattern, 
                        self._config_map[config_key])
                if regex_match is None:
                    continue
                is_file = False
                data_name = regex_match.group(1)

            data_path = self._sql_manager.get_datapath_by_dataname(
                    data_name, 
                    task_util.DataType.PANGU_DATA_TYPE)
            if data_path is None:
                err_log = ("get data path from db failed[%s][%s] " % (
                        data_name, self._config_map[config_key]))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False

            if not is_file:
                rpos = data_path.rfind('/')
                if rpos == -1:
                    continue
                data_path = data_path[0: rpos + 1]

            pattern = "%.*:file%"
            if not is_file:
                pattern = "%.*:dir%"

            result, number = re.subn(
                    pattern, 
                    data_path, 
                    self._config_map[config_key]) 
            if number <= 0:
                err_log = ("replace data node failed[%s][%s] " % (
                        data_path, self._config_map[config_key]))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False
            self._config_map[config_key] = result
        return True

    def _get_replace_map(self, sub_day, sub_hour, sub_min, work_dir):
        timespan = datetime.timedelta(
                days=sub_day, 
                hours=sub_hour, 
                minutes=sub_min)
        tmp_run_time = (self.__run_time_datetime - timespan).strftime(
                "%Y%m%d%H%M")
        year = tmp_run_time[0 : 4]
        month = tmp_run_time[4 : 6]
        day = tmp_run_time[6 : 8]
        hour = tmp_run_time[8 : 10]
        minute = tmp_run_time[10 : 12]
        self._replace_pair_map = {
                '%year%': year,
                '%yyyy%': year,
                '%Y%': year,
                '%month%': month,
                '%mm%': month,
                '%m%': month,
                '%day%': day,
                '%dd%': day,
                '%d%': day,
                '%hour%': hour,
                '%hh%': hour,
                '%H%': hour,
                '%minute%': minute,
                '%MM%': minute,
                '%M%': minute,
                '%work_dir%': work_dir,
                '@-\d+day': '',
                '@-\d+hour': '',
                '@-\d+min': '',
            }

    # 将配置中的时间根据run_time进行替换
    # 比如date = %year%%month%%day%@-1day, run_time = '201505071130'
    # date将被替换为20150506
    # 注意：这个操作会将一个配置的值的时间全部统一替换
    # 例如 run_time = '201505071130'：
    # /home/%year%_%month%_%day%@-1day/%year%_%month%_%day%_%hour%@-1hour.log
    # 会被替换为
    # /home/2015_05_06/2015_05_06_10.log
    def _config_replace_time_by_run_time(self, work_dir):
        oper_day_pattern = '.*@-(\d+)day.*'
        oper_hour_pattern = '.*@-(\d+)hour.*'
        oper_min_pattern = '.*@-(\d+)min.*'
        for config_key in self._config_map:
            # 计算需要减去的天数和小时数
            sub_day = 0
            regex_match = re.match(
                    oper_day_pattern, 
                    self._config_map[config_key])
            if regex_match is not None:
                sub_day = int(regex_match.group(1))
            sub_hour = 0
            regex_match = re.match(
                    oper_hour_pattern, 
                    self._config_map[config_key])
            if regex_match is not None:
                sub_hour = int(regex_match.group(1))

            sub_min = 0
            regex_match = re.match(
                    oper_min_pattern, 
                    self._config_map[config_key])
            if regex_match is not None:
                sub_min = int(regex_match.group(1))

            self._get_replace_map(sub_day, sub_hour, sub_min, work_dir)

            for replace_key in self._replace_pair_map:
                # 替换对应的值
                replace_result, number = re.subn(
                        replace_key, 
                        self._replace_pair_map[replace_key], 
                        self._config_map[config_key]) 
                if number > 0:
                    self._config_map[config_key] = replace_result
        return True

    # 处理盘古路径
    # 注意：这里认为输出文件是不会有正则匹配的，
    # 也要求用户不能对输出文件做正则匹配，
    # 所以输出文件肯定是文件夹或者是固定的文件名，
    # 这个函数的处理，不会对输出文件造成影响
    # 故：不需要用户指明是盘古输入还是输出，只需保证输出文件或文件夹确定即可
    # 输出文件路径需要预先创建好，程序本身不负责创建
    def _handle_pangu_path(self, config_key):
        self.__replace_star_to_dot_star(config_key)
        try:
            return self._common_handle_file_path(
                    self._pangu_cmd, 
                    config_key, 
                    len(task_util.CONSTANTS.PATH_PANGU_START_WITH))
        except exceptions.Exception as ex:
            err_log = ("%s %s handle pangu path failed"
                    "[%s][error:%s][trace:%s]" % (
                    __file__, sys._getframe().f_lineno, 
                    self._config_map[config_key], 
                    str(ex), 
                    traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        except:
            return False

    def __replace_star_to_dot_star(self, config_key):
        src_str_list = list(self._config_map[config_key])
        tmp_str_list = []
        src_list_len = len(src_str_list)
        for i in range(src_list_len):
            if src_str_list[i] == '*':
                if i > 0 and src_str_list[i - 1] != '.':
                    tmp_str_list.append('.')
            tmp_str_list.append(src_str_list[i])
        self._config_map[config_key] = ''.join(tmp_str_list)

    def _common_handle_file_path(self, file_cmd, config_key, root_path_len):
        # 如果是文件夹，则认为是输出文件，是确定的文件路径，不处理
        original_path = self._config_map[config_key]
        if original_path.endswith('/'):
            return True

        if file_cmd.exist_dir(original_path):
            return True

        file_set = set()
        rfind_pos = original_path.rfind('/')
        if rfind_pos == -1:
            err_log = ("%s %s get pangu files failed![%s]" % (
                    __file__, sys._getframe().f_lineno, original_path))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        parent_path = original_path[0: rfind_pos + 1]
        try:
            if not self._recursive_file_path(
                    file_cmd,
                    parent_path, 
                    original_path, 
                    file_set,
                    root_path_len):
                err_log = ("%s %s get pangu files failed![%s]" % (
                        __file__, sys._getframe().f_lineno, original_path))
                self._log.warn(err_log)
                self._add_error_log(err_log)
                return True
        except exceptions.Exception as ex:
            err_log = ("%s %s _recursive_file_path [%s] "
                    "failed[reason:%s][trace:%s]" % (
                    __file__, sys._getframe().f_lineno, 
                    original_path, str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        # 没有搜索到任何文件则不修改配置的值，直接返回
        if len(file_set) <= 0:
            return True
        self._config_map[config_key] = ','.join(file_set)
        return True

    # 递归查找盘古所有的文件，如果有子文件夹，则遍历子文件夹
    # pangu://AY54/product/dataware_house
    # /data_backup/click_s_aliyun_com/2015_02_10/.*
    # 注意：需要保证文件路径的正确性
    def _recursive_file_path(
            self, 
            file_cmd, 
            parent_path, 
            original_path, 
            file_set, 
            root_path_len):
        # 如果全局退出，则直接返回false
        if task_util.CONSTANTS.GLOBAL_STOP:
            return False
        # 如果已经到了根目录，则错误
        if len(parent_path) <= root_path_len:
            err_log = ("%s %s pangu path has no files[%s]" % (
                    __file__, sys._getframe().f_lineno, parent_path))
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False

        if file_cmd.exist_dir(parent_path):
            dir_list_str = file_cmd.ls_dir(parent_path)
            if dir_list_str is None:
                # 空文件夹则直接返回
                return True

            if original_path == parent_path:
                original_path = os.path.join(original_path, ".*")
            regex_path = task_util.StaticFunction.get_path_sub_regex_pattern(
                    original_path, 
                    parent_path)
            if regex_path is None or regex_path.strip() == '':
                err_log = (
                        "%s %s get regex path failed![original_path:%s]"
                        "[parent_path:%s]" % (__file__, sys._getframe().f_lineno, 
                        original_path, parent_path))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False

            dir_list = dir_list_str.split('\n')
            for dir in dir_list:
                if dir is None or dir.strip() == '':
                    continue

                match_object = re.match(regex_path, dir)
                if match_object is not None:
                    # 保证是完全匹配
                    tmp_dir = match_object.group()
                    if dir.endswith("/") and not tmp_dir.endswith('/'):
                        tmp_dir += "/"

                    if tmp_dir != dir:  
                        continue
                    tmp_pangu_path = os.path.join(parent_path, dir)
                    # 如果是文件，则直接写入file_set
                    if tmp_pangu_path[-1] != '/':
                        if len(tmp_pangu_path) \
                                >= task_util.CONSTANTS.MAX_CONFIG_VALUE_LENGTH:
                            err_log = (
                                    "config value [%s] extend max len[%s]" % (
                                    value, 
                                    task_util.CONSTANTS.\
                                    MAX_CONFIG_VALUE_LENGTH))
                            self._log.error(err_log)
                            self._add_error_log(err_log)
                            return False

                        # 如果超过了盘古文件数限制，则直接返回false
                        if len(file_set) >= \
                                task_util.CONSTANTS.MAX_PANGU_FILES:
                            err_log = ("%s %s pangu files[%d] "
                                    "has exceeded max files[%d][original_path"
                                    ":%s]" % (
                                    __file__, sys._getframe().f_lineno, 
                                    len(file_set), 
                                    task_util.CONSTANTS.MAX_PANGU_FILES, 
                                    original_path))
                            self._log.error(err_log)
                            self._add_error_log(err_log)
                            return False

                        file_set.add(tmp_pangu_path)
                        continue

                    sub_path = original_path[len(regex_path) + \
                            len(parent_path) + 1 : len(original_path)]
                    tmp_original_path = os.path.join(tmp_pangu_path, sub_path)
                    if not self._recursive_file_path(
                            file_cmd,
                            tmp_pangu_path, 
                            tmp_original_path, 
                            file_set,
                            root_path_len):
                        return False
        else:
            if parent_path[-1] == '/':
                parent_path = parent_path[0: len(parent_path) - 1]
            rfind_pos = parent_path.rfind('/')
            if rfind_pos == -1:
                err_log = ("%s %s handle pangu path fail![%s][%s]" % (
                        __file__, sys._getframe().f_lineno, 
                        parent_path, original_path))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False
            parent_path = parent_path[0: rfind_pos + 1]
            return self._recursive_file_path(
                    file_cmd,
                    parent_path, 
                    original_path, 
                    file_set,
                    root_path_len)
        return True

    def _handle_odps_path(self, pangu_path):
        return True

    def _handle_local_path(self, config_key):
        self.__replace_star_to_dot_star(config_key)
        try:
            return self._common_handle_file_path(
                    self._local_file_cmd, 
                    config_key,
                    len(task_util.CONSTANTS.PATH_LOCAL_START_WITH))
        except exceptions.Exception as ex:
            err_log = ("%s %s handle local path failed[%s]"
                    "[error:%s][trace:%s]" % (
                    __file__, sys._getframe().f_lineno, 
                    self._config_map[config_key], 
                    str(ex), 
                    traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        except:
            return False

    # 处理配置中的路径信息，包括pangu，odps，本地路径，odps_mr，odps_xlib
    def _handle_file_path(self):
        for config_key in self._config_map:
            if self._config_map[config_key].strip() == '':
                continue

            if self._config_map[config_key].startswith(
                    task_util.CONSTANTS.PATH_PANGU_START_WITH):
                if not self._handle_pangu_path(config_key):
                    return False
            elif self._config_map[config_key].startswith(
                    task_util.CONSTANTS.PATH_ODPS_SQL_START_WITH):
                if not self._handle_odps_path(
                        self._config_map[config_key]):
                    return False
            elif self._config_map[config_key].startswith(
                    task_util.CONSTANTS.PATH_LOCAL_START_WITH):
                if not self._handle_local_path(config_key):
                    return False
            else:
                pass
        return True

    # 将tpl文件转化为配置文件
    def _handle_tpl_files(self, tpl_in_file, tpl_out_file):
        ret_val, tpl_src_content = task_util.StaticFunction.\
                get_all_content_from_file(tpl_in_file)
        if ret_val != task_util.FileCommandRet.FILE_COMMAND_SUCC:
            err_log = (
                    "%s %s get tpl content from file[%s] failed!" % (
                     __file__, sys._getframe().f_lineno, tpl_in_file))
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False
        # 替换tpl文件内容
        tpl_des_content = task_util.StaticFunction.replace_str_with_regex(
                tpl_src_content, 
                self._conf_replace_pattern, 
                self._config_map)
        if tpl_des_content is None:
            err_log = (
                    "%s %s replace tpl content[%s] failed!" % (
                    __file__, sys._getframe().f_lineno, tpl_src_content))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        
        if task_util.StaticFunction.write_content_to_file(
                tpl_out_file, 
                tpl_des_content) != task_util.FileCommandRet.FILE_COMMAND_SUCC:
            err_log = (
                    "%s %s write tpl content[%s] to file[%s] failed!" % (
                    __file__, sys._getframe().f_lineno, 
                    tpl_des_content, tpl_out_file_path))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        return True

    def _prepair_work_dir(self):
        choose = ''
        for disk in self.__disks:
            disk = disk.strip()
            if disk == '':
                continue
            try:
                vfs = os.statvfs(disk)
                available = vfs[statvfs.F_BAVAIL] * vfs[statvfs.F_BSIZE]
                if available > task_util.CONSTANTS.WORK_DIR_SPACE_VALID:
                    choose = disk
                    break
            except exceptions.Exception as ex:
                err_log = (
                        "get disk failed[%s][%s] failed!" % (
                        str(ex), traceback.format_exc()))
                self._log.error(err_log)
                self._add_error_log(err_log)
                continue

        # 如果磁盘不可用，则直接退出程序
        if choose == '':
            task_util.CONSTANTS.GLOBAL_STOP = True
            time.sleep(10)
            sys.exit(1)

        tmp_work_dir = "%s/data_platform/%s/" % (
                choose, 
                str(self._schedule_id))

        back_dir = "%s/data_platform/%s_bak" % (
                choose, 
                self._schedule_id)
        if os.path.exists(tmp_work_dir):
            if not os.path.exists(back_dir):
                os.makedirs(back_dir)

            mv_time = task_util.StaticFunction.get_now_format_time(
                    "%Y-%m-%d_%H:%M:%S")
            cmd = "rm -rf %s/bak*" % tmp_work_dir
            self._sys_cmd.run_once(cmd)

            cmd = "mv %s %s/bak_%s.%s" % (
                    tmp_work_dir, 
                    back_dir,
                    str(self._schedule_id),
                    mv_time)
            self._sys_cmd.run_once(cmd)
            if os.path.exists(tmp_work_dir):
                shutil.rmtree(tmp_work_dir)

        os.makedirs(tmp_work_dir)
        if os.path.exists(back_dir):
            cmd = "cp -rf %s/* %s/" % (
                    back_dir,
                    tmp_work_dir)
            self._sys_cmd.run_once(cmd)
        return tmp_work_dir

    def _get_work_dir(self):
        return self._work_dir

    # 从盘古下载工作包，放入工作目录，并解压
    def _download_package(self, work_dir):
        package_name = "%d.tar.gz" % self._pid
        package_file_path = os.path.join(
                self._pangu_package_dir, package_name)
        if not self._pangu_cmd.cp_file(package_file_path, work_dir):
            err_log = ("cp pangu package failed![pangu:%s][local:%s]" % \
                    (package_file_path, work_dir))
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False

        tar_cmd = "cd %s && tar -zxvf %s" % (work_dir, package_name)
        stdout, stderr, return_code = self._sys_cmd.run_once(tar_cmd)
        if return_code != 0:
            err_log = ("%s %s tar file failed[cmd:%s]" % (
                    __file__, sys._getframe().f_lineno, tar_cmd))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        return True

    # 调用这个方法，说明数据库的数据已经出现状态的紊乱，
    # （比如用户停止了相关的任务，但是因为时序不一致，状态不一致，
    #   这里比较难保证）
    # 所以直接将任务failed，由用户决定后续处理
    def _set_task_status_failed(self):
        # 直接改写为失败会有问题
        return
        sql_list = []
        now_format_time = task_util.StaticFunction.get_now_format_time(
                "%Y-%m-%d %H:%M:%S")
        try:
            # 写入ready_task,
            ready_task = horae.models.ReadyTask.objects.get(
                    id=self._ready_task_id)
            ready_task.update_time = now_format_time
            ready_task.status = task_util.TaskState.TASK_FAILED
            ready_task.save()
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self._log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            err_log = ("%s %s node db control failed"
                    "[reason:%s][trace:%s]" % (
                    __file__, sys._getframe().f_lineno, 
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)

        try:
            # 更新schedule
            update_schedule_obj = horae.models.Schedule.objects.get(
                    id=self._schedule_id)
            update_schedule_obj.status = task_util.TaskState.TASK_FAILED
            update_schedule_obj.end_time = now_format_time
            update_schedule_obj.save()
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self._log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            err_log = ("%s %s node db control failed"
                    "[reason:%s][trace:%s]" % (
                    __file__, sys._getframe().f_lineno, 
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
        try:
            # 写run_history
            run_history = horae.models.RunHistory.objects.get(
                    task_id=self._task_id, 
                    run_time=self._task_run_time, 
                    schedule_id=self._schedule_id)
            run_history.status = task_util.TaskState.TASK_FAILED
            run_history.end_time = now_format_time
            run_history.save()
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self._log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
        except exceptions.Exception as ex:
            err_log = ("%s %s node db control failed"
                    "[reason:%s][trace:%s]" % (
                    __file__, sys._getframe().f_lineno, 
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
        return True

    def _write_task_status_to_db(
            self, 
            task_status, 
            old_status, 
            task_handler=None, 
            work_dir=None,
            try_times=30,
            cpu=0,
            mem=0):
        # 这个函数调用十分重要，所以加上重试机制，防止网络抖动对业务的影响
        sql_list = []
        now_format_time = task_util.StaticFunction.get_now_format_time(
                "%Y-%m-%d %H:%M:%S")
        # 下面的sql都需要加上status=old_status，
        # 增强容错性
        # 写入ready_task,
        ready_task_sql = ''
        if work_dir is None:
            if task_handler is None or task_handler == '':
                ready_task_sql = ("update horae_readytask set status = %d, "
                        "update_time = '%s' "
                        " where id = %d and status = %d;" % (
                        task_status, 
                        now_format_time, 
                        self._ready_task_id, 
                        old_status))
            else:
                ready_task_sql = ("update horae_readytask set status = %d, "
                        "update_time = '%s', task_handler = '%s' "
                        " where id = %d and status = %d;" % (
                        task_status, 
                        now_format_time, 
                        task_handler,
                        self._ready_task_id, 
                        old_status))

        else:
            if task_handler is None or task_handler == '':
                ready_task_sql = ("update horae_readytask set status = %d, "
                        "update_time = '%s', work_dir = '%s' "
                        " where id = %d and status = %d;" % (
                        task_status, 
                        now_format_time, 
                        work_dir,
                        self._ready_task_id, 
                        old_status))
            else:
                ready_task_sql = ("update horae_readytask set status = %d, "
                        "update_time = '%s', task_handler = '%s', "
                        "work_dir = '%s' "
                        " where id = %d and status = %d;" % (
                        task_status, 
                        now_format_time, 
                        task_handler,
                        work_dir,
                        self._ready_task_id, 
                        old_status))

        sql_list.append(ready_task_sql)

        # 更新schedule
        schedule_sql = ("update horae_schedule set status = %d, "
                "end_time = '%s' where id = %d and status = %d;" % (
                task_status, 
                now_format_time,
                self._schedule_id, 
                old_status))
        sql_list.append(schedule_sql)

        # 写run_history
        if task_handler is None or task_handler == '':
            run_history_sql = ("update horae_runhistory set status = %d, "
                    "end_time = '%s', schedule_id = %d, cpu = %d, mem = %d "
                    " where task_id = '%s' "
                    "and status = %d and run_time = '%s' ;" % (
                    task_status, 
                    now_format_time,
                    self._schedule_id,
                    cpu,
                    mem,
                    self._task_id,
                    old_status,
                    self._task_run_time))
        else:
            run_history_sql = ("update horae_runhistory set status = %d, "
                    "end_time = '%s', schedule_id = %d, task_handler = '%s', "
                    "cpu = %d, mem = %d where task_id = '%s' "
                    "and status = %d and run_time = '%s' ;" % (
                    task_status, 
                    now_format_time,
                    self._schedule_id,
                    task_handler,
                    cpu,
                    mem,
                    self._task_id,
                    old_status,
                    self._task_run_time))

        sql_list.append(run_history_sql)

        tried_times = 0
        while tried_times < try_times:
            tried_times = tried_times + 1
            try:
                if not self._sql_manager.batch_execute_with_affect_one(
                        None, 
                        None, 
                        sql_list):
                    err_log = ("%s %s batch_execute_with_transaction "
                            "failed will retied:%d" % (
                            __file__, sys._getframe().f_lineno, tried_times))
                    self._log.warn(err_log)
                    self._add_error_log(err_log)
                    time.sleep(1)
                    continue
            except django.db.OperationalError as ex:
                django.db.close_old_connections()
                self._log.error("execute sql failed![ex:%s][trace:%s]!" % (
                        str(ex),
                        traceback.format_exc()))
                time.sleep(1)
                continue
            except exceptions.Exception as ex:
                self._log.error("execute sql failed![ex:%s][trace:%s]!" % (
                        str(ex), traceback.format_exc()))
                time.sleep(1)
                continue
            return True
        return False

    def _update_run_history_end_time(self, schedule_id):
        try:
            run_history = horae.models.RunHistory.objects.get(
                    schedule_id=schedule_id)
            run_history.end_time = \
                    task_util.StaticFunction.get_now_format_time(
                    "%Y-%m-%d %H:%M:%S")
            run_history.save()
            return True
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self._log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False
        except exceptions.Exception as ex:
            self._log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False

    def _init_task(self, task_info):
        self._error_list = []
        if len(task_info) < \
                node_sql_manager.ConstantSql.ALL_READY_TASK_SQL_PARAM_NUM:
            err_log = ("%s %s start task task_info must "
                    "has %d params,but now[%d]" % (
                    __file__, sys._getframe().f_lineno, 
                    node_sql_manager.ConstantSql.ALL_READY_TASK_SQL_PARAM_NUM, 
                    len(task_info)))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        self._ready_task_id = task_info[0]
        self._pipeline_id = task_info[1]
        self._schedule_id = task_info[2]
        self._task_type = task_info[3]
        self._task_id = task_info[4]
        self._task_run_time = task_info[5]
        self._pid = task_info[6]
        self._config = task_info[7]
        self._template = task_info[8]
        self._sql_count = 0
        if self._template is not None \
                and self._template.strip() != '':
            self._template = self._template.replace('\r', ' ')
            sql_temp = self._template.strip()
            if not sql_temp.endswith(';'):
                sql_temp = sql_temp + ';'
                self._template = sql_temp

            sql_list = sql_temp.split('\n')
            for sql in sql_list:
                sql = sql.strip()
                if sql != '' \
                        and sql.endswith(';') \
                        and not sql.startswith('set'):
                    self._sql_count = self._sql_count + 1

        self._priority = task_info[9]
        self._except_ret = task_info[10]
        self._over_time = int(task_info[11])
        self._task_status = int(task_info[12])
        self._task_handler = task_info[13]
        self._owner_id = task_info[14]
        if task_info[15] is None or task_info[15].strip() =='':
            self._work_dir = None
        else:
            self._work_dir = task_info[15]

        if self._task_run_time is None:
            return True

        if len(self._task_run_time) != task_util.CONSTANTS.RUN_TIME_LENTGH:
            return False

        # 经过测试，发现strptime这个方法有时会失败，暂不确定原因
        while not task_util.CONSTANTS.GLOBAL_STOP:
            try:
                self.__run_time_datetime = datetime.datetime.strptime(
                        self._task_run_time, 
                        "%Y%m%d%H%M")
            except exceptions.Exception as ex:
                err_log = ("%s %s datetime no strptime[%s][%s]" % (
                        __file__, sys._getframe().f_lineno, 
                        str(ex), traceback.format_exc()))
                self._log.error(err_log)
                self._add_error_log(err_log)
                time.sleep(1)
                continue
            break

        return True

    def _run_command(self, work_dir, cmd, stdout_file, stderr_file):
        stdout, stderr, retcode = self._sys_cmd.run_many(cmd)
        if stdout.strip() != '' and stdout_file is not None:
            stdout_file = os.path.join(
                    work_dir, 
                    stdout_file)
            ret = task_util.StaticFunction.write_content_to_file(
                    stdout_file, 
                    stdout, 
                    "a")
            if ret != task_util.FileCommandRet.FILE_COMMAND_SUCC:
                err_log = "write file failed![file:%s][content:%s]" % (
                        stdout_file, stdout)
                self._log.error(err_log)
                self._add_error_log(err_log)

        if stderr.strip() != '' and stderr_file is not None:
            stderr_file = os.path.join(
                    work_dir, 
                    stderr_file)
            ret = task_util.StaticFunction.write_content_to_file(
                    stderr_file, 
                    stderr, 
                    "a")
            if ret != task_util.FileCommandRet.FILE_COMMAND_SUCC:
                err_log = "write file failed![file:%s][content:%s]" % (
                        stderr_file, stderr)
                self._log.error(err_log)
                self._add_error_log(err_log)
        if retcode != self._except_ret:
            return False, stdout, stderr
        return True, stdout, stderr

    def _add_error_log(self, log_str):
        if log_str is not None and log_str != '':
            self._error_list.append(log_str)

    def _write_error_log_to_file(self, file_name):
        if len(self._error_list) > 0:
            error_log = '\n'.join(self._error_list)
            if task_util.StaticFunction.write_content_to_file(
                    file_name, 
                    error_log,
                    'a') != task_util.FileCommandRet.FILE_COMMAND_SUCC:
                return False
        return True

if __name__ == "__main__":
    # test for TaskHandleBase
    task_config = (
            "script_name = xl_test.py\n "
            "pre_script =\n "
            "post_script =\n "
            "args = xl_test.conf\n "
            "replace_confs = xl_test\n "
            "log_file = application.log\n "
            "check_data =\n "
            "_tpl = xl_test.conf.tpl\n "
            "_out = xl_test.conf\n "
            "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")
    task_info = (1, 2, 3, 4, 5, '201505071410', 6, task_config, '')
        
    config = ConfigParser.RawConfigParser()
    config.read("./conf/node.conf")

    test_base = TaskHandleBase(config)
    test_base._set_task_info(     
            ready_task_id=1, 
            pipeline_id=2, 
            schedule_id=3, 
            task_type=1, 
            task_id=1, 
            task_run_time='201505071410', 
            pid=1, 
            config=task_config, 
            template='',
            )
    print(test_base._config)
    print(test_base._handle_config())
    print(test_base._config_map)
    test_base._config_replace_time_by_run_time()
    print(test_base._config_map)

    pangu_path = ("pangu://AY54/product/dataware_house/"
            "data_backup/click_s_aliyun_com/2015_05_11/.*")
    print("test handle pangu dir: %s" % pangu_path)
    file_set = set()
    rfind_pos = pangu_path.rfind('/')
    parent_path = pangu_path[0 : rfind_pos + 1]
    pangu_cmd = pangu_command.PanguCommand(config)
    print(test_base._recursive_file_path(
            pangu_cmd, 
            parent_path, 
            pangu_path, 
            file_set,
            len(task_util.CONSTANTS.PATH_PANGU_START_WITH)))
    print(len(file_set))

    local_path = ("/apsarapangu/disk1/lei.xie/work/ark/"
            "data_platform/horae/task_node/.*\*.*.py")
    file_set = set()
    rfind_pos = local_path.rfind('/')
    parent_path = local_path[0 : rfind_pos + 1]
    local_cmd = linux_file_cmd.LinuxFileCommand()
    try:
        test_base._recursive_file_path(
                local_cmd, 
                parent_path, 
                local_path, 
                file_set,
                len(task_util.CONSTANTS.PATH_LOCAL_START_WITH))
    except exceptions.Exception as ex:
        print("handle local path failed[%s][error:%s]" % \
                (local_path, str(ex)))
    print(len(file_set))
    print(file_set)
