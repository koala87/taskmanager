﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
odps-mr任务管理

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import ConfigParser
import datetime
import select
import subprocess
import threading
import traceback
import time
import exceptions
import logging
import resource_performance

import horae.models

import task_handle_base
sys.path.append('../common')
import task_util
import node_sql_manager
import no_block_sys_cmd

class OdpsMapReducelTaskHandler(task_handle_base.TaskHandleBase):
    """
        启动odps-mr任务，非阻塞
        每一种任务都需要重新创建实例，线程不安全
    """
    def __init__(self, config):
        task_handle_base.TaskHandleBase.__init__(self, config)
        self.__odps_cmd = config.get("node", "odps_sql")
        self.__job_work_dir = None
        self.__odps_sql = None
        self.__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand()

    def run_task(self, task_info):
        self._job_status = task_util.TaskState.TASK_FAILED
        self._old_job_status = task_util.TaskState.TASK_READY
        while True:
            if not self._init_task(task_info):
                err_log = ("init task failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                self._job_status = task_util.TaskState.TASK_FAILED
                break

            if self._task_type != task_util.TaskType.ODPS_MAP_REDUCE:
                err_log = (
                        "this is just for odps_mr[%d],but now[%d]" % \
                        (task_util.TaskType.APSARA_JOB, self._task_type))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 准备工作路径
            self.__job_work_dir = self._prepair_work_dir()
            self._add_error_log("work_ip: %s\nwork_dir: %s\n" % (
                    task_util.StaticFunction.get_local_ip(), 
                    self.__job_work_dir))

            if not self._download_package(self.__job_work_dir):
                err_log = ("download job package failed!")
                self._log.warn(err_log)
                self._add_error_log(err_log)
                break

            # 初始化，包括配置中的时间转化，盘古路径处理，
            if not self._init(self.__job_work_dir):
                err_log = ("odps map reduce task handle config failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # run.conf.tpl转化为run.conf
            tpl_in_file = os.path.join(
                    self.__job_work_dir, 
                    task_util.CONSTANTS.SCRIPT_DEFSULT_TPL_CONF_NAME)
            if os.path.exists(tpl_in_file):
                run_json_out_file = os.path.join(
                        self.__job_work_dir, 
                        task_util.CONSTANTS.SCRIPT_DEFSULT_CONF_NAME)
                if not self._handle_tpl_files(tpl_in_file, run_json_out_file):
                    err_log = ("write tpl file failed![%s]" % \
                            run_json_out_file)
                    self._log.warn(err_log)
                    self._add_error_log(err_log)
                    break

            # 添加jar包到odps resources, 上传文件的时候add
            # if not self.__add_resources('_odps_mr_resources'):
            #     break
            # self.__add_resources('_odps_libjars')
            # 执行odps-sql任务
            if not self.__run_job():
                err_log = ("odps mapreduce run job failed![%s]" % \
                        str(task_info))
                self._log.warn(err_log)
                self._add_error_log(err_log)
                break
            self._job_status = task_util.TaskState.TASK_RUNNING
            break  # break for while True

        # 执行成功后，改写相关db数据
        # 如果写db失败了，这个时候可能导致用户数据和任务的运行情况不一致
        # 需要人工介入修改db状态
        if not self._write_task_status_to_db(
                self._job_status, 
                self._old_job_status,
                None,
                self.__job_work_dir):
            err_log = ("write_start_task_status_to_db failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            self._set_task_status_failed()

        if self.__job_work_dir is None:
            return False

        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return self._job_status == task_util.TaskState.TASK_RUNNING

    def stop_task(self, task_info):
        if not self._init_task(task_info):
            return False

        if not self._handle_config():
            return False

        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        ret = self.__stop_task(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_task_status(self, task_info):
        if not self._init_task(task_info):
            return task_util.TaskState.TASK_FAILED

        self._update_run_history_end_time(self._schedule_id)
        if not self._handle_config():
            return task_util.TaskState.TASK_FAILED

        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return task_util.TaskState.TASK_FAILED
        ret = self.__get_task_status(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_proceeding(self, task_info):
        if not self._init_task(task_info):
            return False

        if not self._handle_config():
            return False

        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        ret = self.__get_proceeding()
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def __get_proceeding(self):
        ret, instance = self.__get_instance_id()
        if not ret:
            err_log = ("__get_instance_id failed!")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return err_log

        if instance is None:
            return "no instance getted!"

        status = self.__check_odps_instances_status(instance)
        result_list = []
        result_map = {}
        result_map["instance"] = instance
        result_map["status"] = task_util.global_status_info_map[status]
        result_list.append(result_map)
        return str(result_list)

    def __get_task_status(self, task_info):
        try_count = 0
        ret = False
        instance_id = None
        while try_count < 60:
            if task_util.CONSTANTS.GLOBAL_STOP:
                return False

            ret, instance_id = self.__get_instance_id()
            if not ret:
                break

            if instance_id is not None:
                break
            try_count += 1
            time.sleep(10)

        if try_count >= 60:
            ret, instance_list = False, None
            self._add_error_log('\nget none instnce in 600s')

        status = task_util.TaskState.TASK_FAILED
        if ret:
            if instance_id is None:
                return task_util.TaskState.TASK_RUNNING

            status = self.__check_odps_instances_status(instance_id)
            if status == task_util.TaskState.TASK_RUNNING:
                return status

        total_cpu, total_mem = 0, 0
        jstatus_file = os.path.join(self.__job_work_dir, "stderr.log")
        self._add_error_log('\nget cpu and mem info begin![%s]' % jstatus_file)
        try:
            total_cpu, total_mem = \
                    resource_performance.ResourcePerformance.\
                    collect_odps_using(jstatus_file)
        except exceptions.Exception as ex:
            self._log.warn("get jstatus cpu and mem info failed!"
                    "[ex: %s][trace: %s]!" % (
                    str(ex), traceback.format_exc()))

        self._add_error_log('get cpu and mem info end![%s]' % jstatus_file)
        self._add_error_log('write status to db begin!')
        if not self._write_task_status_to_db(
                task_status=status, 
                old_status=task_util.TaskState.TASK_RUNNING,
                cpu=total_cpu,
                mem=total_mem):
            status = task_util.TaskState.TASK_FAILED
            err_log = ("write_start_task_status_to_db failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            self._set_task_status_failed()
        self._add_error_log('write status to db end!')
        return status

    def __stop_task(self, task_info):
        task_handle_base.TaskHandleBase.stop_task(self)
        ret, instance = self.__get_instance_id()
        if instance is None:
            err_log = ("get instance id failed![%s]" % str(task_info))
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False

        cmd = task_util.CONSTANTS.ODPS_SQL_CMD_STR % (
                self.__odps_cmd, 
                self._config_map["_odps_project"],
                self._config_map["_odps_endpoint"],
                self._config_map["_priority"],
                self._config_map["_odps_access_id"],
                self._config_map["_odps_access_key"],
                "kill " + instance)
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                None, 
                None)
        if not status:
            return False
        return True

    # Usage: jar [<GENERIC_OPTIONS>] <MAIN_CLASS> [ARGS]
    # -conf <configuration_file>         Specify an application 
    #                                    configuration file
    # -classpath <local_file_list>       classpaths used to run mainClass
    # -D <name>=<value>                  Property value pair, which will 
    #                                    be used to run mainClass
    # -local                             Run job in local mode
    # -resources <resource_name_list>    file/table resources used in 
    #                                    mapper or reducer, seperate by comma
    def __run_job(self):
        conf_param = ''
        if '_odps_mr_conf' in self._config_map \
                and self._config_map['_odps_mr_conf'].strip() != '':
            conf_param = "-conf %s/%s" % (
                    self.__job_work_dir, 
                    self._config_map['_odps_mr_conf'])

        libjars_param = ''
        if '_odps_libjars' in self._config_map \
                and self._config_map['_odps_libjars'].strip() != '':
            libjars_param = "-libjars %s " % \
                    self._config_map['_odps_libjars'].strip()

        resources_param = ''
        if '_odps_mr_resources' in self._config_map \
                and self._config_map['_odps_mr_resources'].strip() != '':
            resources_param = "-resources %s" % \
                    self._config_map['_odps_mr_resources'].strip()
        
        if '_odps_mr_classpath' not in self._config_map \
                or self._config_map['_odps_mr_classpath'].strip() == '':
            err_log = ("get _odps_mr_classpath failed![%s]")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False
        classpath_param = os.path.join(
                self.__job_work_dir, 
                self._config_map['_odps_mr_classpath'])

        param_index = 0
        param_list = []
        while not task_util.CONSTANTS.GLOBAL_STOP:
            param_index = param_index + 1
            odps_args_key = "_odps_mr_args_%s" % param_index

            if odps_args_key not in self._config_map:
                break

            if self._config_map[odps_args_key].strip() == '':
                continue
            param_list.append(self._config_map[odps_args_key].strip())

        args_param = ''
        if len(param_list) > 0:
            args_param = ' '.join(param_list)

        if '_odps_mr_mainclass' not in self._config_map \
                or self._config_map['_odps_mr_mainclass'].strip() == '':
            err_log = ("get _odps_mr_mainclass failed![%s]")
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        main_class_param = self._config_map['_odps_mr_mainclass']

        jar_sql = "jar %s %s %s -classpath %s %s %s " % (
                conf_param, 
                resources_param, 
                libjars_param,
                classpath_param, 
                main_class_param, 
                args_param)
        cmd = task_util.CONSTANTS.ODPS_SQL_CMD_STR % (
                self.__odps_cmd, 
                self._config_map["_odps_project"],
                self._config_map["_odps_endpoint"],
                self._config_map["_priority"],
                self._config_map["_odps_access_id"],
                self._config_map["_odps_access_key"],
                jar_sql)
        self._add_error_log(cmd)
        stdout_file = os.path.join(self.__job_work_dir, "stdout.log")
        stderr_file = os.path.join(self.__job_work_dir, "stderr.log")
        if self.__no_block_cmd.run_in_background(
                cmd, 
                stdout_file, 
                stderr_file) != 0:
            err_log = ("odps sql run cmd[%s] failed!" % cmd)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        
        return True

    # 只执行一个job，只有一个instance id
    def __get_instance_id(self):
        """ 
            odpscmd的返回数据：stderr.log
            Running job on old console.
            InstanceId: 20150515055525704g64kmmbb1
            http://webconsole.odps.aliyun-inc.com:8080/logview/?h=http://servi
            ce.odps.aliyun-inc.com/api&p=aliyun_searchlog&i=20150515055525704g
            64kmmbb1&token=OCyMjc0MTI1LHsiU3RhdGVtZW50IjpbeyJBY3Rpb24iOlsib2Rw
            czpSZWFkIl0sIkVmZmVjdCI6IkFsbG93IiwiUmVzb3VyY2UiOlsiYWNzOm9kcHM6Kj
            pwcm9qZWN0cy9hbGl5dW5fc2VhcmNobG9nnNpb24iOiIxIn0=

            获取ID是通过匹配 InstanceId: 
            并检查上一行的值为Running job on old console.
            返回结果不会与之冲突
        """
        stdout_file = os.path.join(self.__job_work_dir, "stderr.log")
        if not os.path.exists(stdout_file):
            err_log = ("std out file is not exists.[%s]" % stdout_file)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False, None
        stdout_read_fd = open(stdout_file, "r")
        try:
            INSTANCE_ID = "InstanceId:"
            instance_id = None
            while not task_util.CONSTANTS.GLOBAL_STOP:
                line = stdout_read_fd.readline()
                if line is None or line == '':
                    break

                line = line.strip()
                if line == '':
                    continue

                if not self._stop_task:
                    if line.upper().find('FAILED') != -1 \
                            or line.upper().find('EXCEPTION') != -1:
                        return False, None

                if line.startswith(INSTANCE_ID):
                    instance_id = line.split(':')[1].strip()
            return True, instance_id
        except exceptions.Exception as ex:
            err_log = ("get instance list failed![ex:%s][trace:%s]" % (
                    str(ex), traceback.format_exc()))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False, None
        finally:
            stdout_read_fd.close()

    # 检查odps-mr的每一个instance是否success，如果有一个失败则失败
    def __check_odps_instances_status(self, instance):
        cmd = task_util.CONSTANTS.ODPS_SQL_CMD_STR % (
                self.__odps_cmd, 
                self._config_map["_odps_project"],
                self._config_map["_odps_endpoint"],
                self._config_map["_priority"],
                self._config_map["_odps_access_id"],
                self._config_map["_odps_access_key"],
                "status " + instance)
        status, stdout, stderr = self._run_command(
                self.__job_work_dir,
                cmd, 
                None, 
                None)
        if not status:
            err_log = ("get instance status failed![stderr:%s][stdout:%s]" % (
                    stderr, stdout))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return task_util.TaskState.TASK_RUNNING

        if stdout.find("Running") != -1:
            return task_util.TaskState.TASK_RUNNING

        if stdout.find("Waiting") != -1:
            return task_util.TaskState.TASK_WAITING

        if stdout.find("Ready") != -1:
            return task_util.TaskState.TASK_READY

        if stdout.find("Success") != -1:
            return task_util.TaskState.TASK_SUCCEED

        if stdout.find("Failed") != -1:
            return task_util.TaskState.TASK_FAILED
        return task_util.TaskState.TASK_RUNNING

    def __add_resources(self, add_tag):
        if add_tag not in self._config_map \
                or self._config_map[add_tag].strip() == '':
            err_log = "get _odps_mr_resources failed![%s]" % add_tag
            self._log.warn(err_log)
            self._add_error_log(err_log)
            return False
        resources_param = self._config_map[add_tag].strip()
        resources_list = resources_param.split(',')
        for resources in resources_list:
            package_path = os.path.join(self.__job_work_dir, resources.strip())
            if not os.path.exists(package_path):
                continue

            jar_sql = "add file %s -f" % package_path
            if resources.endswith("jar"):
                jar_sql = "add jar %s -f" % package_path
            cmd = task_util.CONSTANTS.ODPS_SQL_CMD_STR % (
                    self.__odps_cmd, 
                    self._config_map["_odps_project"],
                    self._config_map["_odps_endpoint"],
                    self._config_map["_priority"],
                    self._config_map["_odps_access_id"],
                    self._config_map["_odps_access_key"],
                    jar_sql)

            status, stdout, stderr = self._run_command(
                    self.__job_work_dir,
                    cmd, 
                    None, 
                    None)
            if not status:
                err_log = ("add package failed[%s][stdout: %s][stderr:%s]!" % (
                        cmd, stdout, stderr))
                self._log.error(err_log)
                self._add_error_log(err_log)
                return False

            if stderr.find("OK:") != -1:
                continue
            err_log = ("add package failed[%s][stdout: %s][stderr: %s]!" % (
                    cmd, stdout, stderr))
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        return True

if __name__ == "__main__":
    print("please run unit test in common/db_manabger")
