﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
node 端http服务实现，解决实时命令请求

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import logging

import tornado.httpserver
import tornado.web
import tornado.ioloop
import horae.models
import django.db

sys.path.append('../common')
import task_util
import handle_ready_tasks
import linux_file_cmd
import node_sql_manager
import apsara_job_task_handler
import script_task_handler
import odps_sql_task_handler
import odps_map_reduce_task_handler
import odps_spark_task_handler
import http_msg_queue

class NodeHttpServer(object):
    '''
        node的http服务 
    '''
    def __init__(self, config, handle_ready_tasks):
        self.__config = config
        self.__node_http_port = config.get("node", "node_http_port")
        self.__handle_ready_task = handle_ready_tasks
        self.__disks = config.get('node', 'disks').split(';')
        self.__http_param = HttpHandlerParams(
                self.__handle_ready_task,
                self.__disks,
                self.__config)
        
    def start(self):
        self.__app = tornado.web.Application(handlers=[
                (r"/list_work_dir", ListWorkDirHandler),
                (r"/get_file_content", GetFileContentHandler),
                (r"/get_proceeding", GetProceeding),
                (r"/get_file_tail", GetFileTailHandler),
                (r"/stop_task", StopTaskHandler),
            ])

        self.__httpserver = tornado.httpserver.HTTPServer(self.__app)
        self.__httpserver.listen(self.__node_http_port)
        self.__httpserver.start()
        tornado.ioloop.IOLoop.instance().start()

    def stop(self):
        self.__httpserver.stop()
        tornado.ioloop.IOLoop.instance().stop()
        logging.info("admin httpserver bind[%s:%s] stopped!" % (
                task_util.StaticFunction.get_local_ip(), 
                self.__node_http_port))

class HttpHandlerParams(task_util.Singleton):
    def __init__(self, handle_ready_task=None, disks=None, config=None):
        if not hasattr(self, "a"):
            if handle_ready_task is None or disks is None:
                raise EnvironmentError("none:base_work_dir, handle_ready_task")

            self.handle_ready_task = handle_ready_task
            self.disks = disks
            self.config = config
            self.a = "a"  # 必须在后面
            self.http_msg_queue = http_msg_queue.HttpRequestManager(config)
            self.http_msg_queue.start()

    def get_file_path_with_schedule_id(self, schedule_id):
        path_list = []
        last_modify_path = None
        max_modify_time = 0
        for disk in self.disks:
            file_path = "%s/data_platform/%s/" % (disk, schedule_id)
            if os.path.exists(file_path):
                path_list.append(file_path)
                modify_time = os.path.getctime(file_path)
                if modify_time > max_modify_time:
                    max_modify_time = modify_time
                    last_modify_path = file_path

        return last_modify_path

    def get_task_handler(self, task_type):
        if task_type == task_util.TaskType.APSARA_JOB:
            return apsara_job_task_handler.ApsaraJobTaskHandler(
                    HttpHandlerParams().config)
        elif task_type == task_util.TaskType.SCRIPT_TYPE:
            return script_task_handler.ScriptTaskHandler(
                    HttpHandlerParams().config)
        elif task_type == task_util.TaskType.ODPS_SQL:
            return odps_sql_task_handler.OdpsSqlTaskHandler(
                    HttpHandlerParams().config)
        elif task_type == task_util.TaskType.ODPS_MAP_REDUCE:
            return odps_map_reduce_task_handler.\
                    OdpsMapReducelTaskHandler(
                    HttpHandlerParams().config)
        elif task_type == task_util.TaskType.ODPS_XLAB_SCRIPT:
            return script_task_handler.ScriptTaskHandler(
                    HttpHandlerParams().config)
        elif task_type == task_util.TaskType.ODPS_SPARK:
            return odps_spark_task_handler.OdpsSparkTaskHandler(
                    HttpHandlerParams().config)
        else:
            pass
        return None

class GetProceeding(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            unique_id = self.get_argument("unique_id", "").strip()
            if unique_id == '':
                self.write("error:unique_id is none")
                return

            schedule_id = self.get_argument("schedule_id", "").strip()
            if not schedule_id:
                self.write("error:schedule_id is none")
                return

            HttpHandlerParams().http_msg_queue.add_request_to_queue_map(
                    unique_id, 
                    [schedule_id,], 
                    self.__proceeding_callback)
            
            response = HttpHandlerParams().http_msg_queue.get_response_from_map(
                            unique_id)
            self.write(response)
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("error:%s" % traceback.format_exc())
        except exceptions.Exception as ex:
            logging.error(traceback.format_exc())
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

    def __proceeding_callback(self, param_list):
        try:
            if len(param_list) <= 0:
                return "error: handle param_list failed!"

            schedule_id = int(param_list[0])
            schedule = horae.models.Schedule.objects.get(id=schedule_id)
            task = horae.models.Task.objects.get(id=schedule.task_id)
            processor = horae.models.Processor.objects.get(id=task.pid)
            task_hanlder = HttpHandlerParams().get_task_handler(processor.type)
            if task_hanlder is None:
                raise exceptions.Exception(
                        "wrong task type:%s" % processor.type)
            sql_manager = node_sql_manager.SqlManager()
            task_info = sql_manager.get_task_info_with_schedule_id(
                    HttpHandlerParams().get_file_path_with_schedule_id(
                            schedule_id), 
                    schedule_id)
            if task_info is None:
                self.write("error:get task info form db error!")
                return
            proceding = task_hanlder.get_proceeding(task_info)
            return proceding
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            return task_util.CONSTANTS.HTTP_RETRY_MSG
        except exceptions.Exception as ex:
            logging.error(traceback.format_exc())
            return "error:%s" % traceback.format_exc()

class ListWorkDirHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            self.__file_cmd = linux_file_cmd.LinuxFileCommand()
            schedule_id = self.get_argument("schedule_id", "").strip()
            if not schedule_id:
                self.write("error:schedule_id is none")
                return
            work_dir = HttpHandlerParams().get_file_path_with_schedule_id(
                    schedule_id)
            if work_dir is None:
                self.write("error:this node has no work dir")
                return
            path = self.get_argument("path", "").strip()
            if path != '':
                work_dir = os.path.join(work_dir, path)
            self.write(self.__file_cmd.ls_dir(work_dir))
        except exceptions.Exception as ex:
            logging.error(traceback.format_exc())
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

class GetFileContentHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            schedule_id = self.get_argument("schedule_id", "").strip()
            file_name = self.get_argument("file", "").strip()
            start = int(self.get_argument("start", "0").strip())
            if start >= task_util.CONSTANTS.MAX_FILE_DOWNLOAD_SIZE:
                self.write("download ended! max 1G.")
                return

            len = int(self.get_argument("len", "10240").strip())
            if schedule_id.strip() == '' or file_name.strip() == '':
                self.write("error:schedule_id or file_name required")
                return
            work_dir = HttpHandlerParams().get_file_path_with_schedule_id(
                    schedule_id)
            if work_dir is None or work_dir.strip() == "":
                self.write("error:this node has no work dir")
                return

            file_path = os.path.join(
                    work_dir, 
                    file_name)
            ret, content = task_util.StaticFunction.\
                    get_file_content_with_start_and_len(file_path, start, len)
            if ret != task_util.FileCommandRet.FILE_COMMAND_SUCC:
                self.write("error:read file failed %s" % file_path)
                return
            self.write(content)
        except exceptions.Exception as ex:
            logging.error(traceback.format_exc())
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

class GetFileTailHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            schedule_id = self.get_argument("schedule_id", "").strip()
            file_name = self.get_argument("file", "").strip()
            if schedule_id.strip() == '' or file_name.strip() == '':
                self.write("error:schedule_id or file_name required")
                return
            work_dir = HttpHandlerParams().get_file_path_with_schedule_id(
                    schedule_id)
            if work_dir is None:
                self.write("error:this node has no work dir")
                return

            file_path = os.path.join(
                    work_dir, 
                    file_name)
            content = linux_file_cmd.LinuxFileCommand().file_tail(file_path)
            if content is None:
                self.write("error:read file failed %s" % file_path)
                return

            self.write(content)
        except exceptions.Exception as ex:
            logging.error(traceback.format_exc())
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

class StopTaskHandler(tornado.web.RequestHandler):
    @tornado.web.asynchronous
    def get(self):
        try:
            unique_id = self.get_argument("unique_id", "").strip()
            if unique_id == '':
                self.write("error:unique_id is none")
                return

            schedule_id = self.get_argument("schedule_id", "").strip()
            if not schedule_id:
                self.write("error:schedule_id is none")
                return
            HttpHandlerParams().http_msg_queue.add_request_to_queue_map(
                    unique_id, 
                    [schedule_id,], 
                    self.__stop_task_call_back)
            
            response = HttpHandlerParams().http_msg_queue.get_response_from_map(
                            unique_id)
            self.write(response)
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.write("error:%s" % traceback.format_exc())
        except exceptions.Exception as ex:
            logging.error(traceback.format_exc())
            self.write("error:%s" % traceback.format_exc())
        finally:
            self.finish()

    def __stop_task_call_back(self, param_list):
        try:
            schedule_id = param_list[0].strip()
            if not schedule_id:
                return "error:schedule_id is none"
            schedule = horae.models.Schedule.objects.get(id=schedule_id)
            task = horae.models.Task.objects.get(id=schedule.task_id)
            processor = horae.models.Processor.objects.get(id=task.pid)
            task_hanlder = HttpHandlerParams().get_task_handler(processor.type)
            if task_hanlder is None:
                return "wrong task type:%s" % processor.type
            sql_manager = node_sql_manager.SqlManager()
            task_info = sql_manager.get_task_info_with_schedule_id(
                    HttpHandlerParams().get_file_path_with_schedule_id(
                            schedule_id), 
                    schedule_id)
            if task_info is None:
                return "error:get task info form db error!"

            if not task_hanlder.stop_task(task_info):
                return "error: stop task failed!"

            if not sql_manager.stop_task_with_schedule_id(
                    int(schedule_id)):
                return 'error: stop task write db error: %s' % schedule_id

            return "OK"
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            return task_util.CONSTANTS.HTTP_RETRY_MSG
        except exceptions.Exception as ex:
            logging.error(traceback.format_exc())
            return "error:%s" % traceback.format_exc()

if __name__ == "__main__":
    server = HttpServer()
    server.start()
