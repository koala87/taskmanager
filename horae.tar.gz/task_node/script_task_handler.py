﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
script任务管理

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import ConfigParser
import datetime
import select
import threading
import traceback
import exceptions
import time
import urllib2

import horae.models

import task_handle_base
sys.path.append('../common')
import task_util
import node_sql_manager
import no_block_sys_cmd

class ScriptTaskHandler(task_handle_base.TaskHandleBase):
    """
        启动script任务，非阻塞
        每一种任务都需要重新创建实例，线程不安全
    """
    def __init__(self, config):
        task_handle_base.TaskHandleBase.__init__(self, config)
        self.__daemon_port = config.get("node", "daemon_port")
        self.__local_ip = task_util.StaticFunction.get_local_ip()
        self.__python_cmd = config.get("node", "python")
        self.__odps_xlib_cmd = config.get("node", "odps_xlib")
        self.__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand()

    def run_task(self, task_info):
        self._job_status = task_util.TaskState.TASK_FAILED
        self._old_job_status = task_util.TaskState.TASK_READY
        while True:
            if not self._init_task(task_info):
                err_log = ("init task failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            if self._task_type != task_util.TaskType.SCRIPT_TYPE\
                    and self._task_type != task_util.TaskType.ODPS_XLAB_SCRIPT:
                err_log = (
                        "this is just for script or xlib [%d],but now[%d]" % \
                        (task_util.TaskType.APSARA_JOB, self._task_type))
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 准备工作路径
            self.__job_work_dir = self._prepair_work_dir()
            self._add_error_log("work_ip: %s\nwork_dir: %s\n" % (
                    task_util.StaticFunction.get_local_ip(), 
                    self.__job_work_dir))
            if not self._download_package(self.__job_work_dir):
                err_log = ("download job package failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # 初始化，包括配置中的时间转化，盘古路径处理，下载运行包，
            if not self._init(self.__job_work_dir):
                err_log = ("script job handle config failed!")
                self._log.error(err_log)
                self._add_error_log(err_log)
                break

            # run.conf.tpl转化为run.conf
            if not self.__handle_run_conf():
                break

            self.__handle_run_py()

            # 先停止之前的任务
            self.__stop_task(task_info)

            ret = self.__run_job()
            # 此时表示线程退出，不要修改db状态
            if ret is None:
                return True
            
            if not ret:
                break

            self._job_status = task_util.TaskState.TASK_RUNNING
            break  # break for while True

        # 执行成功后，改写相关db数据
        # 如果写db失败了，这个时候可能导致用户数据和任务的运行情况不一致
        # 需要人工介入修改db状态
        if not self._write_task_status_to_db(
                self._job_status, 
                self._old_job_status,
                None,
                self.__job_work_dir):
            err_log = ("write_start_task_status_to_db failed!")
            self._log.warn(err_log)
            self._add_error_log(err_log)
            self._set_task_status_failed()

        if self.__job_work_dir is None:
            return False

        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return self._job_status == task_util.TaskState.TASK_RUNNING

    def stop_task(self, task_info):
        if not self._init_task(task_info):
            return False
        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        task_handle_base.TaskHandleBase.stop_task(self)
        ret = self.__stop_task(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_task_status(self, task_info):
        if not self._init_task(task_info):
            return task_util.TaskState.TASK_FAILED
        self._update_run_history_end_time(self._schedule_id)
        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return task_util.TaskState.TASK_FAILED
        ret = self.__get_task_status(task_info)
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def get_proceeding(self, task_info):
        if not self._init_task(task_info):
            return False
        self.__job_work_dir = self._get_work_dir()
        if self.__job_work_dir is None:
            return False
        ret = self.__get_proceeding()
        err_log_file = os.path.join(
                self.__job_work_dir, 
                "trace.log")
        self._write_error_log_to_file(err_log_file)
        return ret

    def __handle_run_py(self):
        if 'script_name' in self._config_map \
                and self._config_map['script_name'].strip() != '' \
                and self._config_map['script_name'].strip() != \
                task_util.CONSTANTS.SCRIPT_DEFSULT_PYTHON_FILE:
            cmd = 'mv %s/%s %s/%s' % (
                    self.__job_work_dir, 
                    self._config_map['script_name'].strip(), 
                    self.__job_work_dir, 
                    task_util.CONSTANTS.SCRIPT_DEFSULT_PYTHON_FILE)
            self.__no_block_cmd.run_once(cmd)

        if '_out' in self._config_map \
                and self._config_map['_out'].strip() != '':
            cmd = 'mv %s/%s %s/%s' % (
                    self.__job_work_dir, 
                    'run.conf', 
                    self.__job_work_dir, 
                    self._config_map['_out'].strip())
            self.__no_block_cmd.run_once(cmd)

    def __get_proceeding(self):
        return "script no proceeding."

    def __handle_run_conf(self):
        # run.conf.tpl转化为run.conf
        tpl_in_file = os.path.join(
                self.__job_work_dir, 
                task_util.CONSTANTS.SCRIPT_DEFSULT_TPL_CONF_NAME)
        if not os.path.exists(tpl_in_file):
            if task_util.CONSTANTS.TPL_CONFIG_NAME in self._config_map \
                    and self._config_map[
                        task_util.CONSTANTS.TPL_CONFIG_NAME].strip() != '':
                tpl_file = os.path.join(
                        self.__job_work_dir, 
                        self._config_map[
                                task_util.CONSTANTS.TPL_CONFIG_NAME].strip())
                if os.path.exists(tpl_file):
                    cmd = 'mv %s %s' % (
                            tpl_file, 
                            tpl_in_file)
                    self.__no_block_cmd.run_once(cmd)

        run_json_out_file = os.path.join(
                self.__job_work_dir, 
                task_util.CONSTANTS.SCRIPT_DEFSULT_CONF_NAME)
        if os.path.exists(tpl_in_file):
            if not self._handle_tpl_files(tpl_in_file, run_json_out_file):
                err_log = ("write tpl file failed![%s]" % \
                        run_json_out_file)
                self._log.warn(err_log)
                self._add_error_log(err_log)
                return False
            return True

        default_conf_content = '[run]\n'
        for key in self._config_map:
            default_conf_content += "%s = %s\n" % (key, self._config_map[key])

        if default_conf_content == '':
            return True

        if task_util.StaticFunction.write_content_to_file(
                run_json_out_file, 
                default_conf_content) != \
                task_util.FileCommandRet.FILE_COMMAND_SUCC:
            err_log = ("write tpl file failed![%s]" % \
                    run_json_out_file)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        return True

    def __stop_task(self, task_info):
        daemon_req_url = ("http://%s:%s/stop_task?schedule_id=%s" % (
                self.__local_ip, 
                self.__daemon_port, 
                self._schedule_id))
        try:
            http_res = urllib2.urlopen(daemon_req_url).read()
        except exceptions.Exception as ex:
            err_log = ("daemon server failed[%s]" % daemon_req_url)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False

        if http_res != 'OK':
            return False
        return True

    def __get_task_status(self, task_info):
        daemon_req_url = ("http://%s:%s/get_task_status?schedule_id=%s" % (
                self.__local_ip, 
                self.__daemon_port, 
                self._schedule_id))
        http_res = "error"
        try:
            http_res = urllib2.urlopen(daemon_req_url).read()
        except exceptions.Exception as ex:
            err_log = ("daemon server failed[%s]" % daemon_req_url)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return task_util.TaskState.TASK_RUNNING

        status = task_util.TaskState.TASK_FAILED
        if http_res.startswith("error"):
            err_log = ("run task failed:%s[res:%s]" % (
                    daemon_req_url, http_res))
            self._log.error(err_log)
            self._add_error_log(err_log)
        else:
            status = int(http_res)

        if status == task_util.TaskState.TASK_TIMEOUT:
            err_log = ("task time out[%s]" % str(task_info))
            self._log.info(err_log)
            self._add_error_log(err_log)
            return task_util.TaskState.TASK_TIMEOUT

        if status in (
                task_util.TaskState.TASK_FAILED, 
                task_util.TaskState.TASK_SUCCEED):
            if not self._write_task_status_to_db(
                    status, 
                    task_util.TaskState.TASK_RUNNING):
                err_log = ("write_start_task_status_to_db failed!")
                self._log.warn(err_log)
                self._add_error_log(err_log)
                status = task_util.TaskState.TASK_FAILED
                self._set_task_status_failed()
        return status

    def __run_job(self):
        if self._task_type != task_util.TaskType.SCRIPT_TYPE \
                and self._task_type != task_util.TaskType.ODPS_XLAB_SCRIPT:
            err_log = ("wrong script type:%d] " % self._task_type)
            self._log.error(err_log)
            self._add_error_log(err_log)
            return False
        cmd = None
        if self._task_type == task_util.TaskType.SCRIPT_TYPE:
            cmd = "cd %s && %s %s" % (
                    self.__job_work_dir,
                    self.__python_cmd, 
                    task_util.CONSTANTS.SCRIPT_DEFSULT_PYTHON_FILE)
        elif self._task_type == task_util.TaskType.ODPS_XLAB_SCRIPT:
            tmp_cmd = task_util.CONSTANTS.ODPS_XLIB_CMD_STR % (
                    self.__odps_xlib_cmd, 
                    self._config_map["_odps_project"],
                    self._config_map["_odps_endpoint"],
                    self._config_map["_odps_access_id"],
                    self._config_map["_odps_access_key"],
                    task_util.CONSTANTS.SCRIPT_DEFSULT_PYTHON_FILE)
            cmd = "cd %s && %s" % (self.__job_work_dir, tmp_cmd)

        else:
            self.write("wrong script type:%d] " % self._task_type)
            return False
        self._add_error_log(cmd)

        stdout_file = os.path.join(self.__job_work_dir, "stdout.log")
        stderr_file = os.path.join(self.__job_work_dir, "stderr.log")

        cmd_base64 = urllib2.base64.b64encode(cmd)
        daemon_req_url = ("http://%s:%s/run_task?"
                "schedule_id=%s&cmd=%s&stdout=%s&"
                "stderr=%s&expret=%d&over_time=%d" % (
                self.__local_ip, 
                self.__daemon_port, 
                self._schedule_id, 
                cmd_base64,
                stdout_file, 
                stderr_file,
                int(self._except_ret),
                int(self._over_time)))
        # 等待直到可以访问daemon服务
        while True:
            if task_util.CONSTANTS.GLOBAL_STOP:
                # 直接退出线程，不做额外处理
                return None

            try:
                http_res = urllib2.urlopen(daemon_req_url).read()
                if http_res != 'OK':
                    self._log.error("run task failed:%s[res:%s]" % (
                            daemon_req_url, http_res))
                    err_log = ("run task failed:%s" % daemon_req_url)
                    self._log.error(err_log)
                    self._add_error_log(err_log)
                    return False
                return True
            except exceptions.Exception as ex:
                err_log = ("daemon server fail[%s][ex:%s][trace:%s]" % (
                        daemon_req_url, str(ex), traceback.format_exc()))
                self._log.error(err_log)
                self._add_error_log(err_log)
                time.sleep(1)
                continue

        return True

if __name__ == "__main__":
    print("please run unit test in common/db_manabger")
