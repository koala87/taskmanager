﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket

import django.test

sys.path.append('../')
import task_util
import common_logger

class TestCommonTaskUtil(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__lock = threading.Lock()

    def test_auto_lock(self):
        task_util.AutoLock(self.__lock)

    def test_static_function(self):
        self.assertEqual(
                task_util.StaticFunction.strip_with_one_space(
                        "test \n   space    "), 
                "test \n space")
        self.assertEqual(
                task_util.StaticFunction.get_local_ip(), 
                socket.gethostbyname(socket.gethostname()))
        read_content = ''
        self.assertEqual(
                task_util.StaticFunction.write_content_to_file(
                        "./out/test.log", 
                        "Hello!"), 
                task_util.FileCommandRet.FILE_COMMAND_SUCC)
        self.assertEqual(
                task_util.StaticFunction.get_all_content_from_file(
                        "./out/test.log"), 
                (task_util.FileCommandRet.FILE_COMMAND_SUCC, "Hello!"))
        src_content = (
                """ { """
                """ "part": "${part}", """
                """ "sep": "${sep}", """ 
                """ "/SetLimit/core": "unlimited", """ 
                """ "/SetEnv/LD_LIBRARY_PATH": "/usr/ali/java/jre/", """ 
                """ "table": "${table}", """ 
                """ } """ )
        pattern = '\$\{[^}]*\}'
        kv_pair_map = {
            "part" : "test_part",
            "sep" : "test_sep",
        }
        self.assertEqual(
                task_util.StaticFunction.replace_str_with_regex(
                        src_content, 
                        pattern, 
                        kv_pair_map),
                """ { """
                """ "part": "test_part", """
                """ "sep": "test_sep", """ 
                """ "/SetLimit/core": "unlimited", """ 
                """ "/SetEnv/LD_LIBRARY_PATH": "/usr/ali/java/jre/", """ 
                """ "table": "", """ 
                """ } """ )
        self.assertEqual(
                task_util.StaticFunction.get_path_sub_regex_pattern(
                        "/home/work/hello", 
                        "/home/work/"), 
                "hello")

        self.assertEqual(task_util.StaticFunction.get_file_content_with_start_and_len(
                "./out/test_read.log", 0, 15), 
                (task_util.FileCommandRet.FILE_COMMAND_SUCC, 'asdgasdfadg\nadf'))
        self.assertEqual(task_util.StaticFunction.get_file_content_with_start_and_len(
                "./out/test_read.log", 1, 14), 
                (task_util.FileCommandRet.FILE_COMMAND_SUCC, 'sdgasdfadg\nadf'))
        