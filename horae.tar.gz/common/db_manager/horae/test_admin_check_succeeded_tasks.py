﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime

import django.test
import horae.models
import mock

sys.path.append('../../task_admin')
sys.path.append('../')
import schedule_creator
import task_dispacher
import task_util
import check_succeeded_tasks
import task_node_manager
import zk_manager
import common_logger

class TestAdminCheckSucceededTasks(django.test.TestCase):
    """
        1 -> 2 -> 3

        4     7     8     9
        |\    /     /     /
        | \ /-------------
        5  6
    """
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__schedule = schedule_creator.ScheduleCreator()

        zk = zk_manager.ZookeeperManager(
                hosts=config.get("zk", "hosts"))

        self.__check_succ = check_succeeded_tasks.CheckSucceededTasks(
                task_node_manager.TaskNodeManager(config, zk))

        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)

        self.__config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=2,
                name="2", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=3,
                name="3", 
                owner_id=1, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=4,
                name="4", 
                owner_id=1, 
                ct_time='8 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=5,
                name="5", 
                owner_id=1, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Task.objects.create(
                id=4,
                pl_id=2,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='task_4',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=5,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4',
                over_time=12,
                name='task_5',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=7,
                pl_id=3,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_7',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=8,
                pl_id=4,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_8',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=9,
                pl_id=5,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_9',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

    def test_create_graph(self):
        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue('1' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('2' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('3' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('4' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('5' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('6' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('7' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('8' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('9' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue(1 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(2 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(3 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(4 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(5 in self.__schedule._ScheduleCreator__pipeline_map)

    def test_call_successor_tasks(self):
        task6 = horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9,10',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        task10 = horae.models.Task.objects.create(
                id=10,
                pl_id=2,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_10',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        self.__schedule._ScheduleCreator__init_time = datetime.datetime(
                2014, 5, 18, 15, 11, 10)
        self.assertTrue(self.__schedule._ScheduleCreator__create_schedule())
        self.__check_succ._CheckSucceededTasks__task_map, \
        self.__check_succ._CheckSucceededTasks__pipeline_map, \
        self.__check_succ._CheckSucceededTasks__sub_graph_list, \
        self.__check_succ._CheckSucceededTasks__graph = \
                self.__check_succ._get_task_info_copy()       
        self.__check_succ.\
                _CheckSucceededTasks__task_node_manager.get_valid_ip = \
                mock.MagicMock(return_value='127.0.0.1')

        all_schedule = horae.models.Schedule.objects.all()
        for schedule in all_schedule:
            if schedule.task_id in(1, 7, 8, 9):
                horae.models.ReadyTask.objects.create(
                        pl_id=schedule.pl_id,
                        schedule_id=schedule.id,
                        status=task_util.TaskState.TASK_SUCCEED,
                        type=1,
                        run_time=schedule.run_time,
                        server_tag='ALL',
                        task_id=schedule.task_id,
                        pid=1,
                        owner_id=1,
                        run_server='1.1.1.1')
                schedule.status = task_util.TaskState.TASK_SUCCEED
                schedule.save()
                run_his = horae.models.RunHistory.objects.get(
                        task_id=schedule.task_id, 
                        run_time=schedule.run_time)
                run_his.status = task_util.TaskState.TASK_SUCCEED
                run_his.save()

            elif schedule.task_id == 4:
                horae.models.ReadyTask.objects.create(
                        id=10000000,
                        pl_id=schedule.pl_id,
                        schedule_id=schedule.id,
                        status=task_util.TaskState.TASK_RUNNING,
                        type=1,
                        run_time=schedule.run_time,
                        server_tag='ALL',
                        task_id=schedule.task_id,
                        pid=1,
                        owner_id=1,
                        run_server='1.1.1.1')
                schedule.status = task_util.TaskState.TASK_RUNNING
                schedule.save()
                run_his = horae.models.RunHistory.objects.get(
                        task_id=schedule.task_id, 
                        run_time=schedule.run_time)
                run_his.status = task_util.TaskState.TASK_RUNNING
                run_his.save()
            elif schedule.task_id == 10:
                horae.models.ReadyTask.objects.create(
                        id=10000001,
                        pl_id=schedule.pl_id,
                        schedule_id=schedule.id,
                        status=task_util.TaskState.TASK_RUNNING,
                        type=1,
                        run_time=schedule.run_time,
                        server_tag='ALL',
                        task_id=schedule.task_id,
                        pid=1,
                        owner_id=1,
                        run_server='1.1.1.1')
                schedule.status = task_util.TaskState.TASK_RUNNING
                schedule.save()
                run_his = horae.models.RunHistory.objects.get(
                        task_id=schedule.task_id, 
                        run_time=schedule.run_time)
                run_his.status = task_util.TaskState.TASK_RUNNING
                run_his.save()
        self.assertTrue(
                self.__check_succ._CheckSucceededTasks__call_succeeded_tasks())
        all_tasks = horae.models.ReadyTask.objects.all()
        self.assertEqual(len(all_tasks), 3)
        for task in all_tasks:
            if task.task_id not in (2, 4, 10):
                self.assertTrue(False)

        all_schedule = horae.models.Schedule.objects.all()
        for schedule in all_schedule:
            if schedule.task_id == 4:
                task = horae.models.ReadyTask.objects.get(id=10000000)
                task.status = task_util.TaskState.TASK_SUCCEED
                task.save()
                schedule.status = task_util.TaskState.TASK_SUCCEED
                schedule.save()

                horae.models.RunHistory.objects.create(
                        task_id=schedule.task_id,
                        run_time=schedule.run_time,
                        pl_id=schedule.pl_id,
                        status=task_util.TaskState.TASK_SUCCEED,
                        schedule_id=schedule.id,
                        type=1)
            if schedule.task_id == 10:
                task = horae.models.ReadyTask.objects.get(id=10000001)
                task.status = task_util.TaskState.TASK_SUCCEED
                task.save()
                schedule.status = task_util.TaskState.TASK_SUCCEED
                schedule.save()

                horae.models.RunHistory.objects.create(
                        task_id=schedule.task_id,
                        run_time=schedule.run_time,
                        pl_id=schedule.pl_id,
                        status=task_util.TaskState.TASK_SUCCEED,
                        schedule_id=schedule.id,
                        type=1)
            if schedule.task_id == 9:
                run_time = datetime.datetime(
                    int(schedule.run_time[0: 4]), 
                    int(schedule.run_time[4: 6]), 
                    int(schedule.run_time[6: 8]), 
                    int(schedule.run_time[8: 10]), 
                    int(schedule.run_time[10: 12]), 
                    0) - datetime.timedelta(days=30)
                run_time = run_time.strftime("%Y%m%d%H%M")
                horae.models.ReadyTask.objects.create(
                        id=99999,
                        pl_id=schedule.pl_id,
                        schedule_id=schedule.id,
                        status=task_util.TaskState.TASK_RUNNING,
                        type=1,
                        run_time=run_time,
                        server_tag='ALL',
                        task_id=schedule.task_id,
                        pid=1,
                        owner_id=1,
                        run_server='1.1.1.1')
                run_history = horae.models.RunHistory.objects.get(
                        task_id=schedule.task_id, 
                        run_time=schedule.run_time)
                run_history.run_time = run_time
                run_history.save()
                schedule.status = task_util.TaskState.TASK_RUNNING
                schedule.run_time = run_time
                schedule.save()

        all_tasks = horae.models.ReadyTask.objects.all()
        self.assertEqual(len(all_tasks), 4)
        all_tasks = horae.models.ReadyTask.objects.all()
        self.assertTrue(
                self.__check_succ._CheckSucceededTasks__call_succeeded_tasks())
        all_tasks = horae.models.ReadyTask.objects.all()
        all_tasks = horae.models.ReadyTask.objects.all()    

        self.assertEqual(len(all_tasks), 4)
        for task in all_tasks:
            if task.task_id not in (9, 2, 10, 5):
                self.assertTrue(False)

        for schedule in all_schedule:
            if schedule.task_id in (9, 2, 5):
                task = horae.models.ReadyTask.objects.get(task_id=schedule.task_id)
                task.status = task_util.TaskState.TASK_SUCCEED
                task.save()
                schedule.status = task_util.TaskState.TASK_SUCCEED
                schedule.save()
            if schedule.task_id == 4:
                horae.models.ReadyTask.objects.create(
                        id=199999,
                        pl_id=schedule.pl_id,
                        schedule_id=schedule.id,
                        status=task_util.TaskState.TASK_SUCCEED,
                        type=1,
                        run_time=schedule.run_time,
                        server_tag='ALL',
                        task_id=schedule.task_id,
                        pid=1,
                        owner_id=1,
                        run_server='1.1.1.1')
                schedule.status = task_util.TaskState.TASK_SUCCEED
                schedule.save()

        run_hiss = horae.models.RunHistory.objects.all()
        self.assertTrue(
                self.__check_succ._CheckSucceededTasks__call_succeeded_tasks())
        all_tasks = horae.models.ReadyTask.objects.all()
        self.assertEqual(len(all_tasks), 2)
        for task in all_tasks:
            if task.task_id not in (6, 3):
                self.assertTrue(False)

    def test_prev_status(self):
        """
        4     7     8     9
        |\    /     /     /
        | \ /-------------
        3  6
          /  \
        10   11
          \  /
           12

        """
        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',10,11',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=10,
                pl_id=2,
                pid=1,
                next_task_ids=',12',
                prev_task_ids=',6',
                over_time=12,
                name='task_10',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=11,
                pl_id=2,
                pid=1,
                next_task_ids=',12',
                prev_task_ids=',6',
                over_time=12,
                name='task_11',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=12,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',10,11',
                over_time=12,
                name='task_12',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        self.__schedule._ScheduleCreator__init_time = datetime.datetime(
                2014, 5, 18, 15, 11, 10)
        self.assertTrue(self.__schedule._ScheduleCreator__create_schedule())
        self.__check_succ._CheckSucceededTasks__task_map, \
        self.__check_succ._CheckSucceededTasks__pipeline_map, \
        self.__check_succ._CheckSucceededTasks__sub_graph_list, \
        self.__check_succ._CheckSucceededTasks__graph = \
                self.__check_succ._get_task_info_copy()       

        self.__check_succ.\
                _CheckSucceededTasks__task_node_manager.get_valid_ip = \
                mock.MagicMock(return_value='127.0.0.1')

        all_schedule = horae.models.Schedule.objects.all()
        for schedule in all_schedule:
            if schedule.task_id == 9:
                run_time = datetime.datetime(
                    int(schedule.run_time[0: 4]), 
                    int(schedule.run_time[4: 6]), 
                    int(schedule.run_time[6: 8]), 
                    int(schedule.run_time[8: 10]), 
                    int(schedule.run_time[10: 12]), 
                    0) - datetime.timedelta(days=30)
                run_time = run_time.strftime("%Y%m%d%H%M")

                schedule.status = task_util.TaskState.TASK_FAILED
                run_his = horae.models.RunHistory.objects.get(
                        task_id=schedule.task_id, 
                        run_time=schedule.run_time)
                run_his.status = task_util.TaskState.TASK_FAILED
                run_his.run_time = run_time
                run_his.save()
                schedule.run_time = run_time
                schedule.save()

            elif schedule.task_id in(1, 7, 8, 4):
                horae.models.ReadyTask.objects.create(
                        pl_id=schedule.pl_id,
                        schedule_id=schedule.id,
                        status=task_util.TaskState.TASK_SUCCEED,
                        type=1,
                        run_time=schedule.run_time,
                        server_tag='ALL',
                        task_id=schedule.task_id,
                        pid=1,
                        owner_id=1,
                        run_server='1.1.1.1')
                schedule.status = task_util.TaskState.TASK_SUCCEED
                schedule.save()
                run_his = horae.models.RunHistory.objects.get(
                        task_id=schedule.task_id, 
                        run_time=schedule.run_time)
                run_his.status = task_util.TaskState.TASK_SUCCEED
                run_his.save()

        all_tasks = horae.models.Schedule.objects.all()
        self.assertTrue(
                self.__check_succ._CheckSucceededTasks__call_succeeded_tasks())
        all_tasks = horae.models.Schedule.objects.all()
        for task in all_tasks:
            if task.task_id in(6, 10, 11, 12):
                self.assertEqual(
                        task.status, 
                        task_util.TaskState.TASK_WAITING)

        all_tasks = horae.models.ReadyTask.objects.all()
        for task in all_tasks:
            if task.task_id not in(4, 2, 5):
                self.assertTrue(False)
        self.assertEqual(len(all_tasks), 3)