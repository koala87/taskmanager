﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import urllib2
import json

import django.test
import horae.models
import mock
import tornado.httpserver
import tornado.web
import tornado.ioloop

sys.path.append('../../task_admin')
sys.path.append('../')
import task_util
import admin_http_server
import schedule_creator
import task_dispacher
import zk_manager
import task_node_manager
import admin_sql_manager
import common_logger

class ThreadHttpServer(threading.Thread):
    def __init__(self, task_dispacher):
        threading.Thread.__init__(self)
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__admin_http_server = admin_http_server.AdminHttpServer(
                config, 
                task_dispacher)

    def stop(self):
        self.__admin_http_server.stop()

    def run(self):
        self.__admin_http_server.start()

class TestAdminCheckSucceededTasks(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")
        self.__sql_manager = admin_sql_manager.SqlManager()

        self.__schedule = schedule_creator.ScheduleCreator()
        self.__admin_ip = task_util.StaticFunction.get_local_ip()
        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)
        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        db_config = (
            "script_name = xl_test.py\n "
            "pre_script =\n "
            "post_script =\n "
            "args = xl_test.conf\n "
            "replace_confs = xl_test\n "
            "log_file = application.log\n "
            "check_data =\n "
            "_tpl = xl_test.conf.tpl\n "
            "_out = xl_test.conf\n "
            "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')

    def test_admin_stop_pipeline(self):
        try:
            url = "http://%s:%s/stop_pipeline?pl_id=%s&run_time=%s" % (
                    self.__admin_ip, 
                    8791, 
                    4646, 
                    '201505211040')
            url_stream = urllib2.urlopen(url).read()
            print(url_stream)
        except:
            pass

    def test_admin_stop_task(self):
        try:
            node_req_url = "http://%s:%s/stop_task?schedule_id=%s" % (
                    self.__admin_ip, 8791, 1)
            url_stream = urllib2.urlopen(node_req_url).read()
            print(url_stream)
        except:
            pass

    def test_get_file_list(self):
        try:
            node_req_url = "http://%s:%s/list_work_dir?schedule_id=%s" % (
                    self.__admin_ip, 8791, 21338)
            url_stream = urllib2.urlopen(node_req_url).read()
            print(url_stream)
        except:
            pass

    def test_get_file_content(self):
        try:
            node_req_url = ("http://%s:%s/get_file_content?"
                    "schedule_id=%s&file=%s&start=0&len=10240" % (
                    self.__admin_ip, 8791, 21338, "run.conf"))
            url_stream = urllib2.urlopen(node_req_url).read()
            print(url_stream)
        except:
            pass

    def test_restart_task(self):
        try:
            req_map = {}
            req_task_list = []
            task_id_list = [6069, 6070, 6071, 6072, 6074, 6077, 6078, 6079, 6080]
            for task_id in task_id_list:
                task_map = {}
                task_map["task_id"] = str(task_id)
                task_map["run_time"] = '201506011745'
                req_task_list.append(task_map)

            req_map["task_pair_list"] = req_task_list
            req_json = json.dumps(req_map)
            # 编码， 用于发送请求
            req_json = urllib2.quote(req_json.encode('gbk'))
            node_req_url = ("http://%s:%s/restart_task?"
                    "task_pair_json=%s" % (
                    task_util.StaticFunction.get_local_ip(), 
                    8791, 
                    req_json))
            url_stream = urllib2.urlopen(node_req_url).read()
            print(url_stream)
        except:
            pass
