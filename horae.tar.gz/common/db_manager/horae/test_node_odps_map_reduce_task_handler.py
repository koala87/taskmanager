﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock

import django.test
import horae.models

sys.path.append('../../task_node')
sys.path.append('../')
import odps_map_reduce_task_handler
import task_util
import linux_file_cmd
import common_logger
import node_sql_manager

class TestNodeOdpsMapReduceTaskHandler(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__config = ConfigParser.RawConfigParser()
        self.__config.read("./conf/test.conf")
               
        self.__odsp_sql_job = odps_map_reduce_task_handler.\
                OdpsMapReducelTaskHandler(self.__config)
        self.__file_cmd = linux_file_cmd.LinuxFileCommand()
        config = (
                "_odps_mr_resources = odps-mapred-examples.jar \n" 
                "_odps_mr_classpath = odps-mapred-examples.jar \n"
                "_odps_mr_mainclass = com.shenma.odps.odps_sdk_test.WordCount \n"
                "_odps_mr_args_1 = xl_test_map_reduce_in \n"
                "_odps_mr_args_2 = xl_test_map_reduce_out \n"
                "table_in = xl_test_map_reduce_in \n"
                "table_out = xl_test_map_reduce_out \n"
                "class_path = com.shenma.odps.odps_sdk_test.WordCount \n"
                "_jar = odps-mapred-examples.jar")
        self.__task_info = (
                1, 
                1, 
                2, 
                task_util.TaskType.ODPS_MAP_REDUCE, 
                1, 
                '201505120100', 
                70, 
                config, 
                "jar -resources ${_jar} -classpath ${_jar} "
                "${class_path} ${table_in} ${table_out}", 
                10,
                0,
                0,
                0,
                '',
                1999,
                './out/2/')
        horae.models.ReadyTask.objects.create(
                id=1,
                pl_id=1,
                schedule_id=2,
                status=task_util.TaskState.TASK_READY,
                type=task_util.TaskType.ODPS_MAP_REDUCE,
                run_time='201505120100',
                server_tag='ALL',
                task_id=1,
                pid=1,
                owner_id=1,
                run_server='1.1.1.1')
        horae.models.Schedule.objects.create(
                id=2,
                task_id=1,
                run_time='201505120100',
                status=task_util.TaskState.TASK_READY,
                pl_id=1,
                start_time='2015-05-12 01:00:00')
    
        horae.models.RunHistory.objects.create(
                id=1,
                task_id=1,
                run_time='201505120100',
                pl_id=1,
                status=task_util.TaskState.TASK_READY,
                schedule_id=2,
                type=task_util.TaskType.ODPS_MAP_REDUCE)
        node_sql_manager.SqlManager.\
                get_odps_access_info_by_userid = mock.MagicMock(
                        return_value=(True, None))

    def test_start_task(self):
        self.assertTrue(self.__odsp_sql_job.run_task(self.__task_info))

    def test_init_task(self):
        self.assertTrue(self.__odsp_sql_job._init_task(
                self.__task_info))

    def test_write_task_status_to_db(self):
        self.assertTrue(self.__odsp_sql_job._init_task(
                self.__task_info))
        self.assertTrue(self.__odsp_sql_job._write_task_status_to_db(2, 5))

    def test_timeout_task(self):
        config = (
                "_odps_mr_resources = odps-mapred-examples.jar \n" 
                "_odps_mr_classpath = odps-mapred-examples.jar \n"
                "_odps_mr_mainclass = com.shenma.odps.odps_sdk_test.WordCount \n"
                "_odps_mr_args_1 = xl_test_map_reduce_in \n"
                "_odps_mr_args_2 = xl_test_map_reduce_out \n"
                "table_in = xl_test_map_reduce_in \n"
                "table_out = xl_test_map_reduce_out \n"
                "class_path = com.shenma.odps.odps_sdk_test.WordCount \n"
                "_jar = odps-mapred-examples.jar")
        self.__task_info = (
                1, 
                1, 
                2, 
                task_util.TaskType.ODPS_MAP_REDUCE, 
                1, 
                '201505120100', 
                70, 
                config, 
                "jar -resources ${_jar} -classpath ${_jar} "
                "${class_path} ${table_in} ${table_out}", 
                10,
                0,
                0,
                0,
                '',
                1999,
                './out/2/')
        self.assertTrue(self.__odsp_sql_job.run_task(self.__task_info))

    def test_stop_task(self):
        config = (
                "_odps_mr_resources = odps-mapred-examples.jar \n" 
                "_odps_mr_classpath = odps-mapred-examples.jar \n"
                "_odps_mr_mainclass = com.shenma.odps.odps_sdk_test.WordCount \n"
                "_odps_mr_args_1 = xl_test_map_reduce_in \n"
                "_odps_mr_args_2 = xl_test_map_reduce_out \n"
                "table_in = xl_test_map_reduce_in \n"
                "table_out = xl_test_map_reduce_out \n"
                "class_path = com.shenma.odps.odps_sdk_test.WordCount \n"
                "_jar = odps-mapred-examples.jar")
        self.__task_info = (
                1, 
                1, 
                2, 
                task_util.TaskType.ODPS_MAP_REDUCE, 
                1, 
                '201505120100', 
                70, 
                config, 
                "jar -resources ${_jar} -classpath ${_jar} "
                "${class_path} ${table_in} ${table_out}", 
                10,
                0,
                0,
                0,
                '',
                1999,
                './out/2/')

        self.assertTrue(self.__odsp_sql_job.run_task(self.__task_info))
        run_history = horae.models.RunHistory.objects.get(id=1)
        self.assertEqual(
                run_history.status, 
                task_util.TaskState.TASK_RUNNING)

    def test_one_fail_cmd_task(self):
        config = (
                "_odps_mr_resources = odps-mapred-examples.jar \n" 
                "_odps_mr_classpath = odps-mapred-examples.jar \n"
                "_odps_mr_mainclass = com.shenma.odps.odps_sdk_test.WordCount \n"
                "_odps_mr_args_1 = xl_test_map_reduce_in \n"
                "_odps_mr_args_2 = xl_test_map_reduce_out \n"
                "table_in = xl_test_map_reduce_in \n"
                "table_out = xl_test_map_reduce_out \n"
                "class_path = com.shenma.odps.odps_sdk_test.WodCount \n"
                "_jar = odps-mapred-examples.jar")
        self.__task_info = (
                1, 
                1, 
                2, 
                task_util.TaskType.ODPS_MAP_REDUCE, 
                1, 
                '201505120100', 
                70, 
                config, 
                "jar -resources ${_jar} -classpath ${_jar} "
                "${class_path} ${table_in} ${table_out}", 
                10,
                0,
                0,
                0,
                '',
                1999,
                './out/2/')
        self.assertTrue(self.__odsp_sql_job.run_task(self.__task_info))
        run_history = horae.models.RunHistory.objects.get(id=1)
        self.assertEqual(
                run_history.status, 
                task_util.TaskState.TASK_RUNNING)
