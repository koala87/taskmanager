﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime

import django.test
import horae.models
import mock

sys.path.append('../../task_node')
sys.path.append('../')
import handle_ready_tasks
import task_util
import node_sql_manager
import apsara_job_task_handler
import common_logger

class TestNodeHandleReadyTasks(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__config = ConfigParser.RawConfigParser()
        self.__config.read("./conf/test.conf")
        self.__handle_ready_tasks = handle_ready_tasks.ReadyTasksCreator(
                self.__config)

        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.ReadyTask.objects.create(
                id=1, 
                pl_id=1,
                schedule_id=1,
                status=task_util.TaskState.TASK_READY,
                type=task_util.TaskType.APSARA_JOB,
                run_time='201505131000',
                server_tag='ALL',
                task_id=1,
                pid=1,
                owner_id=1,
                run_server=task_util.StaticFunction.get_local_ip())

        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)

        config = (
            "script_name = xl_test.py\n "
            "pre_script =\n "
            "post_script =\n "
            "args = xl_test.conf\n "
            "replace_confs = xl_test\n "
            "log_file = application.log\n "
            "check_data =\n "
            "_tpl = test_job_task.json.tpl\n "
            "_out = xl_test.conf\n "
            "input_file = pangu://AY54/product/dataware_house/"
            "data_backup/click_s_aliyun_com/2015_05_11/.*\n "
            "output_dir = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Schedule.objects.create(
                id=1,
                task_id=1,
                run_time='201505131000',
                status=task_util.TaskState.TASK_READY,
                pl_id=1,
                end_time='2015-05-11 10:00:00',
                start_time='2015-05-11 10:00:00',
                init_time='2015-05-11 10:00:00')

        horae.models.RunHistory.objects.create(
                id=1,
                task_id=1,
                run_time='201505131000',
                pl_id=1,
                status=task_util.TaskState.TASK_READY,
                schedule_id=1,
                type=task_util.TaskType.APSARA_JOB)

    def test_get_one_task_from_queue_map(self):
        self.__handle_ready_tasks._ReadyTasksCreator__handle_all_ready_tasks()
        task_info = self.__handle_ready_tasks.get_one_task_from_queue_map()

    def test_del_one_task_from_set(self):
        self.__handle_ready_tasks._ReadyTasksCreator__handle_all_ready_tasks()
        self.assertTrue(1 in 
                self.__handle_ready_tasks._ReadyTasksCreator__ready_task_set)
        self.__handle_ready_tasks.del_one_task_from_set(1)
        self.assertTrue(1 not in 
                self.__handle_ready_tasks._ReadyTasksCreator__ready_task_set)

    def test_add_one_task_into_set(self):
        self.assertTrue(self.__handle_ready_tasks.\
                _ReadyTasksCreator__add_one_task_into_set(1))
        self.assertTrue(1 in 
                self.__handle_ready_tasks._ReadyTasksCreator__ready_task_set)

    def test_add_one_task_into_queue_map(self):
        task_info = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
        self.__handle_ready_tasks.\
                _ReadyTasksCreator__add_one_task_into_queue_map(task_info)
        self.assertEqual(
                task_info, 
                self.__handle_ready_tasks.\
                _ReadyTasksCreator__priority_queue_map[10].get())

    def test_init_priority_queue(self):
        self.__handle_ready_tasks._ReadyTasksCreator__priority_queue_map = {}
        self.__handle_ready_tasks._ReadyTasksCreator__init_priority_queue()
        for priority_num in range(
                task_util.CONSTANTS.TASK_PRIORITY_MIN, 
                task_util.CONSTANTS.TASK_PRIORITY_MAX + 1):
            self.assertTrue(priority_num in self.__handle_ready_tasks.\
                    _ReadyTasksCreator__priority_queue_map)

    def test_ready_task_handler(self):
        ready_task_handler = handle_ready_tasks.ReadyTaskHandler(
                self.__config, 
                self.__handle_ready_tasks,
                1)
        self.__handle_ready_tasks._ReadyTasksCreator__handle_all_ready_tasks()
        task_info = self.__handle_ready_tasks.get_one_task_from_queue_map()
        apsara_job_task_handler.ApsaraJobTaskHandler.\
                _ApsaraJobTaskHandler__run_job = mock.MagicMock(
                        return_value=True)
        apsara_job_task_handler.ApsaraJobTaskHandler.\
                _ApsaraJobTaskHandler__check_package = mock.MagicMock(
                        return_value=True)
        self.assertFalse(ready_task_handler.\
                _ReadyTaskHandler__handle_ready_task(task_info))
