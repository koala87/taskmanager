﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime

import django.test
import horae.models

sys.path.append('../../task_admin')
sys.path.append('../')
import schedule_creator
import task_dispacher
import task_util
import common_logger

class TestAdminScheduleCreator(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__schedule = schedule_creator.ScheduleCreator()
        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)

        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        self.__schedule._ScheduleCreator__init_time = \
                datetime.datetime(2015, 05, 13, 1, 0, 0)

    def test_create_graph(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue('1' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('2' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('3' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue(1 in self.__schedule._ScheduleCreator__pipeline_map)

    def test_get_all_sub_graph(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(self.__schedule._ScheduleCreator__create_pipeline_graph_list())
        self.assertEqual(
                len(self.__schedule._ScheduleCreator__sub_graph_list), 
                1)
        self.assertTrue(
                ('1', '2') in 
                self.__schedule._ScheduleCreator__sub_graph_list[0].edges())
        self.assertTrue(
                ('2', '3') in 
                self.__schedule._ScheduleCreator__sub_graph_list[0].edges())

    def test_get_no_dep_nodes(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(self.__schedule._ScheduleCreator__create_pipeline_graph_list())
        no_prev_node_list = self.__schedule._get_no_dep_nodes(
                self.__schedule._ScheduleCreator__sub_graph_list)
        self.assertEqual(len(no_prev_node_list), 1)
        self.assertEqual(no_prev_node_list[0], '1')

    def test_get_crontab_iter(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(1 in self.__schedule._ScheduleCreator__pipeline_map)
        task_info = [1,1,1,1,1]
        self.__schedule._ScheduleCreator__init_time = \
                datetime.datetime(2015, 05, 13, 1, 0, 0)
        cron_iter = self.__schedule._ScheduleCreator__get_crontab_iter(
                task_info)
        self.assertNotEqual(cron_iter, None)
        self.assertEqual(
                cron_iter.get_prev().strftime(
                        task_util.CONSTANTS.RUN_TIME_FORMAT), 
                "201505120100")
        self.assertEqual(
                cron_iter.get_prev().strftime(
                        task_util.CONSTANTS.RUN_TIME_FORMAT), 
                "201505110100")
        self.assertEqual(
                cron_iter.get_next().strftime(
                        task_util.CONSTANTS.RUN_TIME_FORMAT), 
                "201505120100")

    def test_keep_all_insert_values(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(
                self.__schedule._ScheduleCreator__create_pipeline_graph_list())
        self.assertTrue(
                self.__schedule._ScheduleCreator__keep_all_insert_values(
                        '1', 
                        '201505110101'))

    def test_check_and_insert_to_schedule(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(
                self.__schedule._ScheduleCreator__create_pipeline_graph_list())
        self.assertTrue(
                self.__schedule._ScheduleCreator__check_and_insert_to_schedule(
                        '2', 
                        '201505110101'))

    def test_insert_all_values_into_schedule(self):
        self.__schedule._ScheduleCreator__sql_list.append(
                horae.models.Schedule(
                        task_id = 1, 
                        run_time = '201501010101', 
                        status = 1, 
                        pl_id = 1))
        self.assertTrue(
                self.__schedule\
                ._ScheduleCreator__insert_all_values_into_schedule())

    def test_handle_all_ct_time_by_task(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        task_info = [1,1,1,1,1]
        self.__schedule._ScheduleCreator__init_time = \
                datetime.datetime.utcnow() + \
                datetime.timedelta(hours=8)
        cron_iter = self.__schedule._ScheduleCreator__get_crontab_iter(
                task_info)
        self.assertNotEqual(cron_iter, None)
        self.assertTrue(
                self.__schedule._ScheduleCreator__handle_all_ct_time_by_task(
                        cron_iter, 
                        '1'))

    def test_put_valid_task_into_schedule(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(
                self.__schedule._ScheduleCreator__create_pipeline_graph_list())
        self.assertTrue(
                self.__schedule.\
                _ScheduleCreator__put_valid_task_into_schedule())

    def test_mul_prev_task(self):
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Pipeline.objects.create(
                id=2,
                name="2", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=3,
                name="3", 
                owner_id=1, 
                ct_time='1 2 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=4,
                name="4", 
                owner_id=1, 
                ct_time='1 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=5,
                name="5", 
                owner_id=1, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Task.objects.create(
                id=4,
                pl_id=2,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='task_4',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=5,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4',
                over_time=12,
                name='task_5',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=7,
                pl_id=3,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_7',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=8,
                pl_id=4,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_8',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=9,
                pl_id=5,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_9',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        self.__schedule._ScheduleCreator__init_time = datetime.datetime(
                2014, 5, 18, 15, 11, 10)
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(
                self.__schedule._ScheduleCreator__create_pipeline_graph_list())
        self.assertTrue(
                self.__schedule.\
                _ScheduleCreator__put_valid_task_into_schedule())
        self.assertTrue(self.__schedule.\
                _ScheduleCreator__insert_all_values_into_schedule())
        tmp_map = self.__schedule._ScheduleCreator__task_ct_time_map
        all_schedule = horae.models.Schedule.objects.all()
        for item in all_schedule:
            if item.task_id == 4:
                self.assertEqual(item.run_time, "201405030201")
            if item.task_id == 6:
                self.assertEqual(item.run_time, "201405030201")
            if item.task_id == 9:
                self.assertEqual(item.run_time, "201405181505")

    def test_mul_prev_and_skip_ct_time(self):
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Pipeline.objects.create(
                id=2,
                name="2", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=3,
                name="3", 
                owner_id=1, 
                ct_time='1 2 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=4,
                name="4", 
                owner_id=1, 
                ct_time='1 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=5,
                name="5", 
                owner_id=1, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Task.objects.create(
                id=4,
                pl_id=2,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='task_4',
                config=config,
                retry_count=3,
                last_run_time='201005030201',
                description='')

        horae.models.Task.objects.create(
                id=5,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4',
                over_time=12,
                name='task_5',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=7,
                pl_id=3,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_7',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=8,
                pl_id=4,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_8',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=9,
                pl_id=5,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_9',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        self.__schedule._ScheduleCreator__init_time = datetime.datetime(
                2014, 5, 18, 15, 11, 10)
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue(
                self.__schedule._ScheduleCreator__create_pipeline_graph_list())
        self.assertTrue(
                self.__schedule.\
                _ScheduleCreator__put_valid_task_into_schedule())
        self.assertTrue(self.__schedule.\
                _ScheduleCreator__insert_all_values_into_schedule())
        tmp_map = self.__schedule._ScheduleCreator__task_ct_time_map
        all_schedule = horae.models.Schedule.objects.all()
        tmp_str1 = ''
        for item in all_schedule:
            if item.task_id == 4:
                tmp_str1 = tmp_str1 + "," + item.run_time
            if item.task_id == 6:
                tmp_str1 = tmp_str1 + "," + item.run_time
            if item.task_id == 9:
                self.assertEqual(item.run_time, "201405181505")

        self.assertEqual(tmp_str1, ',201405030201,201404030201,201403030201,20'
                '1402030201,201401030201,201312030201,201311030201,20131003020'
                '1,201309030201,201308030201,201307030201,201306030201,2013050'
                '30201,201304030201,201303030201,201302030201,201301030201,201'
                '212030201,201211030201,201210030201,201209030201,201208030201'
                ',201207030201,201206030201,201205030201,201204030201,20120303'
                '0201,201202030201,201201030201,201112030201,201111030201,2011'
                '10030201,201109030201,201108030201,201107030201,201106030201,'
                '201105030201,201104030201,201103030201,201102030201,201101030'
                '201,201012030201,201011030201,201010030201,201009030201,20100'
                '8030201,201007030201,201006030201,201405030201,201404030201,2'
                '01403030201,201402030201,201401030201,201312030201,2013110302'
                '01,201310030201,201309030201,201308030201,201307030201,201306'
                '030201,201305030201,201304030201,201303030201,201302030201,20'
                '1301030201,201212030201,201211030201,201210030201,20120903020'
                '1,201208030201,201207030201,201206030201,201205030201,2012040'
                '30201,201203030201,201202030201,201201030201,201112030201,201'
                '111030201,201110030201,201109030201,201108030201,201107030201'
                ',201106030201,201105030201,201104030201,201103030201,20110203'
                '0201,201101030201,201012030201,201011030201,201010030201,2010'
                '09030201,201008030201,201007030201,201006030201')