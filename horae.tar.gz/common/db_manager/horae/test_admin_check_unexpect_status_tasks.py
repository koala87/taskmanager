﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime

import django.test
import horae.models
import mock

sys.path.append('../../task_admin')
sys.path.append('../')
import schedule_creator
import task_dispacher
import task_util
import check_unexpect_status_tasks
import task_node_manager
import zk_manager
import common_logger

class TestAdminCheckUnexpectStatusTasks(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__schedule = schedule_creator.ScheduleCreator()

        zk = zk_manager.ZookeeperManager(
                hosts=config.get("zk", "hosts"))

        self.__check_unexp = check_unexpect_status_tasks.\
                CheckUnexpectStatusTasks(
                task_node_manager.TaskNodeManager(config, zk))

        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)

        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=2,
                name="2", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=3,
                name="3", 
                owner_id=1, 
                ct_time='1 2 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=4,
                name="4", 
                owner_id=1, 
                ct_time='1 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Pipeline.objects.create(
                id=5,
                name="5", 
                owner_id=1, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)

        horae.models.Task.objects.create(
                id=4,
                pl_id=2,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='task_4',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=5,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4',
                over_time=12,
                name='task_5',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=7,
                pl_id=3,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_7',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=8,
                pl_id=4,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_8',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=9,
                pl_id=5,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_9',
                config=config,
                retry_count=3,
                last_run_time='',
                description='')

    def test_create_graph(self):
        self.assertTrue(self.__schedule._ScheduleCreator__create_graph())
        self.assertTrue('1' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('2' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('3' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('4' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('5' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('6' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('7' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('8' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue('9' in self.__schedule._ScheduleCreator__task_map)
        self.assertTrue(1 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(2 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(3 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(4 in self.__schedule._ScheduleCreator__pipeline_map)
        self.assertTrue(5 in self.__schedule._ScheduleCreator__pipeline_map)

    def test_call_successor_tasks(self):
        self.__schedule._ScheduleCreator__init_time = datetime.datetime(
                2014, 5, 18, 15, 11, 10)
        self.assertTrue(self.__schedule._ScheduleCreator__create_schedule())
        self.__check_unexp._CheckUnexpectStatusTasks__task_map, \
        self.__check_unexp._CheckUnexpectStatusTasks__pipeline_map, \
        self.__check_unexp._CheckUnexpectStatusTasks__sub_graph_list, \
        self.__check_unexp._CheckUnexpectStatusTasks__graph = \
                self.__check_unexp._get_task_info_copy()       

        all_schedule = horae.models.Schedule.objects.all()
        for schedule in all_schedule:
            if schedule.task_id == 1:
                task = horae.models.Task.objects.get(id=schedule.task_id)
                task.retry_count = 0
                task.save()
                horae.models.ReadyTask.objects.create(
                        pl_id=schedule.pl_id,
                        schedule_id=schedule.id,
                        status=task_util.TaskState.TASK_FAILED,
                        type=1,
                        run_time=schedule.run_time,
                        update_time='2015-08-25 10:10:00',
                        server_tag='ALL',
                        task_id=schedule.task_id,
                        pid=1,
                        owner_id=1,
                        run_server='1.1.1.1')
                schedule.status = task_util.TaskState.TASK_FAILED
                schedule.save()

            elif schedule.task_id in (2, 3):
                schedule.status = task_util.TaskState.TASK_RUNNING
                schedule.save()

        self.assertTrue(
                self.__check_unexp.\
                _CheckUnexpectStatusTasks__handle_unexp_tasks())
        all_tasks = horae.models.ReadyTask.objects.all()
        self.assertTrue(len(all_tasks) == 0)

        all_schedule = horae.models.Schedule.objects.all()
        for schedule in all_schedule:
            if schedule.task_id in (2, 3):
                self.assertEqual(
                        schedule.status, 
                        task_util.TaskState.TASK_RUNNING)
