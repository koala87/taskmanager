﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock

import django.test
import horae.models

sys.path.append('../../task_admin')
sys.path.append('../')
import schedule_creator
import task_dispacher
import task_util
import task_node_manager
import zk_manager
import common_logger
import admin_task_base

class TestAdminTaskDispacher(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__schedule = schedule_creator.ScheduleCreator()
        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)
        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        db_config = (
            "script_name = xl_test.py\n "
            "pre_script =\n "
            "post_script =\n "
            "args = xl_test.conf\n "
            "replace_confs = xl_test\n "
            "log_file = application.log\n "
            "check_data =\n "
            "_tpl = xl_test.conf.tpl\n "
            "_out = xl_test.conf\n "
            "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        self.assertTrue(self.__schedule._ScheduleCreator__create_schedule())
        zk = zk_manager.ZookeeperManager(hosts=config.get("zk", "hosts"))
        self.__task_dispacher = task_dispacher.TaskDispatcher(
                task_node_manager.TaskNodeManager(config, zk))
        self.__task_dispacher.\
                _TaskDispatcher__task_node_manager.get_valid_ip = \
                mock.MagicMock(return_value='127.0.0.1')
        self.__task_dispacher._TaskDispatcher__task_map, \
        self.__task_dispacher._TaskDispatcher__pipeline_map, \
        self.__task_dispacher._TaskDispatcher__sub_graph_list, \
        self.__task_dispacher._TaskDispatcher__graph = \
                self.__task_dispacher._get_task_info_copy()

    def test_get_no_dep_nodes(self):
        node_list = self.__task_dispacher._get_no_dep_nodes(
                self.__schedule._ScheduleCreator__sub_graph_list)
        self.assertEqual(node_list[0], '1')

    def test_is_task_can_run_task_num(self):
        self.assertTrue(
                self.__task_dispacher._check_limit_num_can_run(
                1, task_util.TaskType.SCRIPT_TYPE))
        task_util.global_task_limit_map[
                task_util.TaskType.SCRIPT_TYPE] = 1
        task_util.global_task_limit_map[
                task_util.TaskType.APSARA_JOB] = 1
        task_util.global_task_limit_map[
                task_util.TaskType.ODPS_SQL] = 1
        task_util.global_task_limit_map[
                task_util.TaskType.ODPS_MAP_REDUCE] = 1
        task_util.global_task_limit_map[
                task_util.TaskType.ODPS_XLAB_SCRIPT] = 1
        self.assertTrue(
                self.__task_dispacher._check_limit_num_can_run(
                1, task_util.TaskType.SCRIPT_TYPE))

    def test_new_task_update_db(self):
        task_util.global_task_limit_map[
                task_util.TaskType.SCRIPT_TYPE] = 10000
        task_util.global_task_limit_map[
                task_util.TaskType.APSARA_JOB] = 10000
        task_util.global_task_limit_map[
                task_util.TaskType.ODPS_SQL] = 10000
        task_util.global_task_limit_map[
                task_util.TaskType.ODPS_MAP_REDUCE] = 10000
        task_util.global_task_limit_map[
                task_util.TaskType.ODPS_XLAB_SCRIPT] = 10000
        task_util.global_each_user_task_limit_map[
                task_util.TaskType.SCRIPT_TYPE] = 10000
        task_util.global_each_user_task_limit_map[
                task_util.TaskType.APSARA_JOB] = 10000
        task_util.global_each_user_task_limit_map[
                task_util.TaskType.ODPS_SQL] = 10000
        task_util.global_each_user_task_limit_map[
                task_util.TaskType.ODPS_MAP_REDUCE] = 10000
        task_util.global_each_user_task_limit_map[
                task_util.TaskType.ODPS_XLAB_SCRIPT] = 10000

        schedule_info = horae.models.Schedule.objects.create(
                id=1,
                task_id=1,
                run_time='201505110511',
                status=0,
                pl_id=1,
                end_time='2015-05-11 10:00:00',
                start_time='2015-05-11 10:00:00',
                init_time='2015-05-11 10:00:00')
        horae.models.RunHistory.objects.create(
                task_id=1,
                run_time='201505110511',
                status=0,
                pl_id=1,
                type=1,
                schedule_id=1)
        self.assertTrue(
                self.__task_dispacher._TaskDispatcher__new_task_update_db(
                        schedule_info))
