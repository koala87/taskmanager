﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock

import django.test
import horae.models

sys.path.append('../../task_node')
sys.path.append('../')
import apsara_job_task_handler
import task_util
import common_logger
import node_sql_manager

class TestNodeTaskHandleBase(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__config = ConfigParser.RawConfigParser()
        self.__config.read("./conf/test.conf")
               
        self.__apsara_job = apsara_job_task_handler.ApsaraJobTaskHandler(
                self.__config)
        config = (
                "_tpl = test_job_task.json.tpl\n "
                "input_file = pangu://AY54/product/dataware_house/data_backup/"
                "click_s_aliyun_com/%year%_%month%_%day%/%year%_%month%_%day%_"
                "09_00.*\n"
                "output_dir = pangu://AY54/product/dataware_house/data_backup/"
                "xielei_test/%year%_%month%_%day%/")

        run_time = datetime.datetime.now() - datetime.timedelta(days=1)
        run_time = run_time.strftime("%Y%m%d%H%M")
        self.__task_info = (
                1, 2, 1, 2, 1, run_time, 
                1211, config, '', 10, 0, 0, 0, 'data_platform/job_new_1', 1, './out/')
        horae.models.ReadyTask.objects.create(
                id=1,
                pl_id=1,
                schedule_id=1,
                status=task_util.TaskState.TASK_READY,
                type=2,
                run_time=run_time,
                server_tag='ALL',
                task_id=1,
                pid=1,
                owner_id=1,
                run_server='1.1.1.1')
        horae.models.Schedule.objects.create(
                id=1,
                task_id=1,
                run_time=run_time,
                status=task_util.TaskState.TASK_READY,
                pl_id=1,
                start_time='2015-05-12 01:00:00')
    
        horae.models.RunHistory.objects.create(
                id=1,
                task_id=1,
                run_time=run_time,
                pl_id=1,
                status=task_util.TaskState.TASK_READY,
                schedule_id=1,
                type=2)
        node_sql_manager.SqlManager.\
                get_odps_access_info_by_userid = mock.MagicMock(
                        return_value=(True, None))
    def test_run_task(self):
        try:
            self.__apsara_job.run_task(self.__task_info)
            model_obj = horae.models.ReadyTask.objects.get(id=1)
            self.assertEqual(model_obj.status, task_util.TaskState.TASK_RUNNING)
            model_obj = horae.models.Schedule.objects.get(id=1)
            self.assertEqual(model_obj.status, task_util.TaskState.TASK_RUNNING)
            model_obj = horae.models.RunHistory.objects.get(id=1)
            self.assertEqual(model_obj.status, task_util.TaskState.TASK_RUNNING)

            while True:
                ret = self.__apsara_job.get_task_status(self.__task_info)
                print(ret)
                print(self.__apsara_job.get_proceeding(self.__task_info))
                self.__apsara_job._init_task(self.__task_info)
                print(self.__apsara_job._ApsaraJobTaskHandler__get_failed_log())
                if ret == task_util.TaskState.TASK_FAILED:
                    break

                if ret == task_util.TaskState.TASK_SUCCEED:
                    print("succ")
                    break
                break
                time.sleep(10)
        except:
            pass

