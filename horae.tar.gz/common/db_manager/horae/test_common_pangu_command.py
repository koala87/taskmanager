﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser

import django.test

sys.path.append('../')
import pangu_command
import common_logger

class TestCommonPanguCommand(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")
        self.pangu_cmd = pangu_command.PanguCommand(config)

    def test_exist_dir(self):
        pangu_dir = ('pangu://AY54/product/dataware_house/'
                'data_backup/click_s_aliyun_com/')
        self.assertTrue(self.pangu_cmd.exist_dir(pangu_dir))
        pangu_dir = ('pangu://AY54/product/dataware_house/'
                'data_backup/click_s_aliyun_com/nononono')
        self.assertFalse(self.pangu_cmd.exist_dir(pangu_dir))

    def test_exist_file(self):
        pangu_file = ('pangu://AY54/product/dataware_house/data_backup/'
                'click_s_aliyun_com/2015_02_18/2015_02_18_19_00.23')
        self.assertFalse(self.pangu_cmd.exist_file(pangu_file))
        pangu_file = ('pangu://AY54/product/dataware_house/data_backup/'
                'click_s_aliyun_com/201ddddd5_02_18/2015_02_18_19_00.23')
        self.assertFalse(self.pangu_cmd.exist_file(pangu_file))

    def test_ls_dir(self):
        pangu_dir = ('pangu://AY54/product/dataware_house/'
                'data_backup/')
        self.assertTrue(len(self.pangu_cmd.ls_dir(pangu_dir)) > 0)

    def test_read_file_lines(self):
        pangu_file = ('pangu://AY54/product/dataware_house/data_backup/'
                'click_s_aliyun_com/2015_02_18/2015_02_18_19_00.23')
        self.assertTrue(len(self.pangu_cmd.read_file_lines(pangu_file, 1)) > 0)


