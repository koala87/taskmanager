﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock
import os

import django.test
import dms.models

sys.path.append('../../task_node')
sys.path.append('../')
import task_handle_base
import linux_file_cmd
import node_sql_manager
import common_logger

class TestNodeTaskHandleBase(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__config = ConfigParser.RawConfigParser()
        self.__config.read("./conf/test.conf")
               
        self.__task_handle_base = task_handle_base.TaskHandleBase(
                self.__config)
        self.__file_cmd = linux_file_cmd.LinuxFileCommand()
        node_sql_manager.SqlManager.\
                get_odps_access_info_by_userid = mock.MagicMock(
                        return_value=(True, None))
    def test_set_task_info(self):
        task_info = (
                1, 2, 3, 1, 2, '201505010101', 
                1, '', '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))

        self.assertFalse(self.__task_handle_base._init_task(
                (1, 2, 3, 1, 2, '20150501001', 1, '', '', 
                10, 0, 0, 0, '', 1, './out/3')))

    def test_handle_config(self):
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./*/%year%_%month%_%day%_"
                "%hour%_00@-1hour/*.log")
        task_info = (1, 2, 3, 1, 2, '201505010111', 1, 
                config, '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))
        self.assertTrue(self.__task_handle_base._handle_config())

    def test_config_replace_time_by_run_time(self):
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./*/%year%_%month%_%day"
                "%_%hour%_00@-1hour/*.log")
        task_info = (1, 2, 3, 1, 2, '201505101036', 1, 
                config, '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))
        self.assertTrue(self.__task_handle_base._handle_config())
        self.assertTrue(self.__task_handle_base.\
                _config_replace_time_by_run_time('./'))
        self.assertEqual(
                self.__task_handle_base._config_map['output_file'], 
                './*/2015_05_10_09_00/*.log')

    def test_handle_pangu_path(self):
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "input_file = pangu://AY54/product/dataware_house/data_backup"
                "/click_s_aliyun_com/2015_07_23/2015_07_23_09_00.*\n"
                "output_file = ./*/%year%_%month%_%day%_%hour%@-1hour/*.log")
        task_info = (1, 2, 3, 1, 2, '201505101036', 
                1, config, '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))
        self.assertTrue(self.__task_handle_base._handle_config())
        self.assertTrue(self.__task_handle_base.\
                _config_replace_time_by_run_time('./'))
        self.assertTrue(self.__task_handle_base.\
                _handle_pangu_path('input_file'))
        print(self.__task_handle_base._config_map['input_file'])

    def test_handle_tpl_files(self):
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "input_file =  pangu://AY54/product/dataware_house/"
                "data_backup/click_s_aliyun_com/%year%_%month%/*\n "
                "output_file = ./*/%year%_%month%_%day%_%hour%@-1hour/*.log")
        task_info = (1, 2, 3, 1, 2, '201505101036', 
                1, config, '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))
        self.assertTrue(self.__task_handle_base._handle_config())
        self.assertTrue(self.__task_handle_base.\
                _config_replace_time_by_run_time('./'))
        self.assertTrue(self.__task_handle_base.\
                _handle_pangu_path('input_file'))
        tpl_in_file = "./out/test.json.tpl"
        tpl_out_file = "./out/run.json"
        self.assertTrue(self.__task_handle_base.\
                _handle_tpl_files(tpl_in_file, tpl_out_file))

    def test_prepair_work_dir(self):
        self.__task_handle_base._base_work_dir = "./out"
        self.__task_handle_base._schedule_id = 10

    def test_download_package(self):
        self.__task_handle_base._pid = 6
        self.assertTrue(self.__task_handle_base._download_package('./out/10/'))

    def test_handle_local_path(self):
        local_path = self.__file_cmd.cur_file_dir()
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "input_file = {0}/*.py\n "
                "output_file = ./*/%year%_%"
                "month%_%day%_%hour%@-1hour/*.log".format(local_path))
        task_info = (1, 2, 3, 1, 2, '201505101036', 1, 
                config, '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))
        self.assertTrue(self.__task_handle_base._handle_config())
        self.assertTrue(self.__task_handle_base.\
                _config_replace_time_by_run_time('./'))
        self.assertTrue(self.__task_handle_base.\
                _handle_local_path('input_file'))
    
    def test_replace_path_with_data_node(self):
        local_path = self.__file_cmd.cur_file_dir()
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "input_file = %test_pangu_path:file%@-1day\n "
                "output_file = ./*/%year%_%"
                "month%_%day%_%hour%@-1hour/*.log")
        task_info = (1, 2, 3, 1, 2, '201505101036', 1, 
                config, '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))
        self.assertTrue(self.__task_handle_base._handle_config())

        node_sql_manager.SqlManager.\
                get_datapath_by_dataname = mock.MagicMock(
                        return_value="pangu://AY54/product/dataware_house/"
                "data_backup/click_s_aliyun_com/%year%_%month%_%day%/*")

        self.assertTrue(self.__task_handle_base._replace_path_with_pangu_data_node())
        self.assertTrue(self.__task_handle_base.\
                _config_replace_time_by_run_time('./'))
        self.assertTrue(self.__task_handle_base.\
                _handle_pangu_path('input_file'))

    def test_replace_path_with_data_node(self):
        local_path = self.__file_cmd.cur_file_dir()
        config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "input_file = %test_pangu_path:file%@-1day\n "
                "input_file2 = %test_pangu_path:dir%@-1day\n "
                "output_file = ./*/%year%_%"
                "month%_%day%_%hour%@-1hour/*.log")
        task_info = (1, 2, 3, 1, 2, '201505101036', 1, 
                config, '', 10, 0, 0, 0, '', 1999, './out/3')
        self.assertTrue(self.__task_handle_base._init_task(task_info))
        self.assertTrue(self.__task_handle_base._handle_config())

        node_sql_manager.SqlManager.\
                get_datapath_by_dataname = mock.MagicMock(
                        return_value="pangu://AY54/product/dataware_house/"
                "data_backup/click_s_aliyun_com/%year%_%month%_%day%/*")

        self.assertTrue(self.__task_handle_base._replace_path_with_pangu_data_node())
        self.assertEqual(
                self.__task_handle_base._config_map['input_file'],
                """pangu://AY54/product/dataware_house/data_backup/click_s_a"""
                """liyun_com/%year%_%month%_%day%/*@-1day""")
        self.assertEqual(
                self.__task_handle_base._config_map['input_file2'],
                """pangu://AY54/product/dataware_house/data_backup/click_s_a"""
                """liyun_com/%year%_%month%_%day%/@-1day""")
