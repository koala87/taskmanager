﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock

import django.test
import horae.models

sys.path.append('../../task_node')
sys.path.append('../')
import script_task_handler
import task_util
import linux_file_cmd
import common_logger
import node_sql_manager

class TestNodeScriptTaskHandle(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__config = ConfigParser.RawConfigParser()
        self.__config.read("./conf/test.conf")
               
        self.__script_job = script_task_handler.ScriptTaskHandler(
                self.__config)
        self.__file_cmd = linux_file_cmd.LinuxFileCommand()
        local_path = self.__file_cmd.cur_file_dir()
        config = (
                "inpurt_file = {0}/*.py \n"
                "output_file = ./*/%year%_%mont"
                "h%_%day%_%hour%@-1hour/*.log".format(local_path))
        self.__task_info = (
                1, 
                1, 
                2, 
                task_util.TaskType.SCRIPT_TYPE, 
                1, 
                '201505120100', 
                60, 
                config, 
                '', 
                10,
                0,
                0,
                0,
                '',
                1999,
                './out/2/')
        horae.models.ReadyTask.objects.create(
                id=1,
                pl_id=1,
                schedule_id=2,
                status=task_util.TaskState.TASK_READY,
                type=task_util.TaskType.SCRIPT_TYPE,
                run_time='201505120100',
                server_tag='ALL',
                task_id=1,
                pid=1,
                owner_id=1,
                run_server='1.1.1.1')
        horae.models.Schedule.objects.create(
                id=2,
                task_id=1,
                run_time='201505120100',
                status=task_util.TaskState.TASK_READY,
                pl_id=1,
                start_time='2015-05-12 01:00:00')
    
        horae.models.RunHistory.objects.create(
                id=1,
                task_id=1,
                run_time='201505120100',
                pl_id=1,
                status=task_util.TaskState.TASK_READY,
                schedule_id=2,
                type=task_util.TaskType.SCRIPT_TYPE)

        self.__script_job._ScriptTaskHandler__run_job = mock.MagicMock(
                return_value=True)
        node_sql_manager.SqlManager.\
                get_odps_access_info_by_userid = mock.MagicMock(
                        return_value=(True, None))

    def test_start_task(self):
        self.assertTrue(self.__script_job.run_task(self.__task_info))
        run_history = horae.models.RunHistory.objects.get(id=1)
        self.assertEqual(
                run_history.status, 
                task_util.TaskState.TASK_RUNNING)

    def test_init_task(self):
        self.assertTrue(self.__script_job._init_task(
                self.__task_info))

    def test_write_task_status_to_db(self):
        self.assertTrue(self.__script_job._init_task(
                self.__task_info))
        self.assertTrue(self.__script_job._write_task_status_to_db(2, 5))

    def test_stop_task(self):
        self.__script_job.stop_task(self.__task_info)
        self.assertTrue(self.__script_job.run_task(self.__task_info))
        run_history = horae.models.RunHistory.objects.get(id=1)
        self.assertEqual(
                run_history.status, 
                task_util.TaskState.TASK_RUNNING)

    def test_timeout_task(self):
        local_path = self.__file_cmd.cur_file_dir()
        config = (
                "inpurt_file = {0}/*.py \n"
                "output_file = ./*/%year%_%mont"
                "h%_%day%_%hour%@-1hour/*.log".format(local_path))
        self.__task_info = (
                1, 
                1, 
                2, 
                task_util.TaskType.SCRIPT_TYPE, 
                1, 
                '201505120100', 
                60, 
                config, 
                '', 
                10,
                0,
                2,
                0,
                '',
                1999,
                './out/2/')
        self.assertTrue(self.__script_job.run_task(self.__task_info))
        run_history = horae.models.RunHistory.objects.get(id=1)
        self.assertEqual(
                run_history.status, 
                task_util.TaskState.TASK_RUNNING)

    def test_odps_xlib(self):
        local_path = self.__file_cmd.cur_file_dir()
        config = (
                "inpurt_file = {0}/*.py \n"
                "output_file = ./*/%year%_%mont"
                "h%_%day%_%hour%@-1hour/*.log".format(local_path))
        self.__task_info = (
                1, 
                1, 
                2, 
                task_util.TaskType.ODPS_XLAB_SCRIPT, 
                1, 
                '201505120100', 
                10, 
                config, 
                '', 
                10,
                0,
                2,
                0,
                '',
                1999,
                './out/2/')
        self.assertTrue(self.__script_job.run_task(self.__task_info))
        run_history = horae.models.RunHistory.objects.get(id=1)
        self.assertEqual(
                run_history.status, 
                task_util.TaskState.TASK_RUNNING)