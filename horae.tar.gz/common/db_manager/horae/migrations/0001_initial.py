# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Pipeline',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=50)),
                ('owner_id', models.IntegerField(default=0, db_index=True)),
                ('ct_time', models.CharField(max_length=250)),
                ('update_time', models.DateTimeField(verbose_name=b'date published')),
                ('enable', models.IntegerField(default=0, db_index=True)),
                ('type', models.IntegerField(default=0, db_index=True)),
                ('email_to', models.CharField(max_length=1024, null=True)),
                ('description', models.CharField(max_length=1024, null=True)),
                ('sms_to', models.CharField(max_length=1024, null=True)),
                ('tag', models.CharField(max_length=1024)),
                ('life_cycle', models.CharField(max_length=50)),
                ('monitor_way', models.IntegerField(default=0)),
                ('private', models.IntegerField(default=0)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Processor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=50)),
                ('type', models.IntegerField(default=0, db_index=True)),
                ('template', models.CharField(max_length=10240, null=True)),
                ('update_time', models.DateTimeField(verbose_name=b'update_time')),
                ('description', models.CharField(max_length=1024)),
                ('config', models.CharField(max_length=10240, null=True)),
                ('owner_id', models.IntegerField(default=0, db_index=True)),
                ('private', models.IntegerField(default=0, null=True, db_index=True)),
                ('ap', models.IntegerField(default=0, null=True, db_index=True)),
                ('tag', models.CharField(max_length=1024, null=True)),
                ('tpl_files', models.CharField(max_length=1024, null=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='ReadyTask',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('pl_id', models.IntegerField(default=0, db_index=True)),
                ('schedule_id', models.IntegerField(default=0, db_index=True)),
                ('status', models.IntegerField(default=0)),
                ('update_time', models.DateTimeField(null=True, verbose_name=b'date published')),
                ('type', models.IntegerField(default=0)),
                ('init_time', models.DateTimeField(null=True, verbose_name=b'task called time')),
                ('retry_count', models.IntegerField(default=0, null=True)),
                ('retried_count', models.IntegerField(default=0, null=True)),
                ('run_time', models.CharField(max_length=20, db_index=True)),
                ('server_tag', models.CharField(max_length=50, null=True)),
                ('task_id', models.IntegerField(default=0, db_index=True)),
                ('pid', models.IntegerField(default=0, db_index=True)),
                ('owner_id', models.IntegerField(default=0, db_index=True)),
                ('run_server', models.CharField(default=b'', max_length=20, null=True)),
                ('task_handler', models.CharField(default=b'', max_length=4096, null=True)),
                ('is_trigger', models.IntegerField(default=0)),
                ('next_task_ids', models.CharField(default=b',', max_length=200, null=True)),
                ('prev_task_ids', models.CharField(default=b',', max_length=200, null=True)),
                ('work_dir', models.CharField(default=b'', max_length=1024, null=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='RunHistory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('task_id', models.IntegerField(default=0, db_index=True)),
                ('run_time', models.CharField(max_length=20, db_index=True)),
                ('pl_id', models.IntegerField(default=0, db_index=True)),
                ('start_time', models.DateTimeField(default=b'2000-01-01 00:00:00', null=True, verbose_name=b'task start time')),
                ('end_time', models.DateTimeField(default=b'2000-01-01 00:00:00', null=True, verbose_name=b'task terminate time')),
                ('status', models.IntegerField(default=0, db_index=True)),
                ('schedule_id', models.IntegerField(default=0, db_index=True)),
                ('tag', models.IntegerField(default=0, null=True)),
                ('type', models.IntegerField(default=0)),
                ('task_handler', models.CharField(max_length=4096, null=True)),
                ('run_server', models.CharField(max_length=20, null=True)),
                ('server_tag', models.CharField(default=b'ALL', max_length=50)),
                ('pl_name', models.CharField(max_length=1024)),
                ('task_name', models.CharField(max_length=1024)),
                ('cpu', models.IntegerField(default=0, null=True)),
                ('mem', models.IntegerField(default=0, null=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Schedule',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('task_id', models.IntegerField(default=0, db_index=True)),
                ('run_time', models.CharField(max_length=20, db_index=True)),
                ('status', models.IntegerField(default=0)),
                ('pl_id', models.IntegerField(default=0, db_index=True)),
                ('end_time', models.DateTimeField(default=b'2000-01-01 00:00:00', null=True, verbose_name=b'task terminate time')),
                ('start_time', models.DateTimeField(default=b'2000-01-01 00:00:00', verbose_name=b'task start time')),
                ('init_time', models.DateTimeField(default=b'2000-01-01 00:00:00', null=True, verbose_name=b'task called time')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Task',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('pl_id', models.IntegerField(default=0, db_index=True)),
                ('pid', models.IntegerField(default=0, db_index=True)),
                ('next_task_ids', models.CharField(default=b',', max_length=200, null=True)),
                ('prev_task_ids', models.CharField(default=b',', max_length=200, null=True)),
                ('over_time', models.IntegerField(default=0)),
                ('name', models.CharField(max_length=50)),
                ('config', models.CharField(max_length=4096, null=True)),
                ('retry_count', models.IntegerField(default=0, null=True)),
                ('last_run_time', models.CharField(max_length=50, null=True)),
                ('priority', models.IntegerField(default=6)),
                ('except_ret', models.IntegerField(default=0)),
                ('description', models.CharField(max_length=1024, null=True)),
                ('server_tag', models.CharField(default=b'ALL', max_length=50)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='UploadHistory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('processor_id', models.IntegerField(default=0, db_index=True)),
                ('status', models.IntegerField(default=0)),
                ('update_time', models.DateTimeField(null=True, verbose_name=b'date published')),
                ('upload_time', models.DateTimeField(null=True, verbose_name=b'date published')),
                ('upload_user_id', models.IntegerField(default=0, db_index=True)),
                ('version', models.CharField(unique=True, max_length=250)),
                ('description', models.CharField(default=b'', max_length=1024, null=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
