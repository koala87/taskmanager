﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock

import django.test
import horae.models

sys.path.append('../../task_node')
sys.path.append('../')
import zookeeper_path_manager
import zk_manager
import common_logger

class TestNodeZookeeperPathManager(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__config = ConfigParser.RawConfigParser()
        self.__config.read("./conf/test.conf")
               
        zk = zk_manager.ZookeeperManager(
                hosts=self.__config.get("zk", "hosts"))
