﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock

import django.test
import horae.models

sys.path.append('../../task_admin')
sys.path.append('../')
import schedule_creator
import task_controled_by_user
import task_util
import task_node_manager
import zk_manager
import common_logger
import admin_task_base

class TestAdminTaskControledByUser(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__schedule = schedule_creator.ScheduleCreator()
        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)
        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        db_config = (
            "script_name = xl_test.py\n "
            "pre_script =\n "
            "post_script =\n "
            "args = xl_test.conf\n "
            "replace_confs = xl_test\n "
            "log_file = application.log\n "
            "check_data =\n "
            "_tpl = xl_test.conf.tpl\n "
            "_out = xl_test.conf\n "
            "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        self.assertTrue(self.__schedule._ScheduleCreator__create_schedule())
        zk = zk_manager.ZookeeperManager(hosts=config.get("zk", "hosts"))
        self.__task_controled_by_user = task_controled_by_user.TaskControledByUser()

    def test_restart_tasks(self):
        task_pair_list = []
        task_pair_list.append((str(1), '201506261010')) 
        task_pair_list.append((str(2), '201506261010')) 
        task_pair_list.append((str(3), '201506261010')) 
        self.assertEqual(
                self.__task_controled_by_user.restart_tasks(task_pair_list), 
                "OK")
        schedules = horae.models.Schedule.objects.filter(
                task_id__in=(1,2,3), 
                run_time='201506261010')
        historys = horae.models.RunHistory.objects.filter(
                task_id__in=(1,2,3), 
                run_time='201506261010')
        ready_tasks = horae.models.ReadyTask.objects.filter(
                task_id__in=(1,2,3), 
                run_time='201506261010')
        self.assertEqual(len(schedules), 3)
        self.assertEqual(len(historys), 3)
        self.assertEqual(len(ready_tasks), 0)

        task_pair_list = []
        task_pair_list.append((str(12), '201506261011')) 
        task_pair_list.append((str(2), '201506261011')) 
        task_pair_list.append((str(3), '201506261011')) 
        self.assertEqual(
                self.__task_controled_by_user.restart_tasks(task_pair_list), 
                "task id[12] error, not exist!")
        schedules = horae.models.Schedule.objects.filter(
                task_id__in=(1,2,3), 
                run_time='201506261011')
        historys = horae.models.RunHistory.objects.filter(
                task_id__in=(1,2,3), 
                run_time='201506261011')
        ready_tasks = horae.models.ReadyTask.objects.filter(
                task_id__in=(1,2,3), 
                run_time='201506261011')
        self.assertEqual(len(schedules), 0)
        self.assertEqual(len(historys), 0)
        self.assertEqual(len(ready_tasks), 0)

