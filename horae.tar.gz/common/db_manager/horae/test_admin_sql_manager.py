﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import mock

import django.test
import horae.models

sys.path.append('../../task_admin')
sys.path.append('../')
import admin_sql_manager
import task_util
import common_logger

class TestAdminSqlManager(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__sql_manager = admin_sql_manager.SqlManager()
        now_time = task_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1)
        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        db_config = (
            "script_name = xl_test.py\n "
            "pre_script =\n "
            "post_script =\n "
            "args = xl_test.conf\n "
            "replace_confs = xl_test\n "
            "log_file = application.log\n "
            "check_data =\n "
            "_tpl = xl_test.conf.tpl\n "
            "_out = xl_test.conf\n "
            "output_file = ./*/%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=db_config,
                retry_count=3,
                last_run_time='',
                description='')

    def test_get_all_tasks(self):
        task_map = {}
        pipeline_map = {}
        pipe_task_map = {}
        self.assertTrue(
                self.__sql_manager.get_all_tasks(
                        task_map, 
                        pipeline_map, 
                        pipe_task_map))
        self.assertTrue('1' in task_map)
        self.assertTrue('2' in task_map)
        self.assertTrue('3' in task_map)
        self.assertTrue(1 in pipeline_map)

    def test_task_has_inserted_to_schedule(self):
        self.assertFalse(
                self.__sql_manager.task_has_inserted_to_schedule(
                        1111, 
                        '201505110101'))
        horae.models.Schedule.objects.create(
                id=1,
                task_id=1111,
                run_time='201505110101',
                status=1,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        self.assertTrue(
                self.__sql_manager.task_has_inserted_to_schedule(
                        1111, 
                        '201505110101'))

    def test_batch_execute_with_transaction(self):
        sql_list = []
        sql_list.append(horae.models.Pipeline(
                id=1111,
                name="a1111", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1))
        sql_list.append(horae.models.Processor(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1))
        self.assertTrue(
                self.__sql_manager.batch_execute_with_affect_one(sql_list))

    def test_get_all_begin_node_task_from_schedule(self):
        task_id_list = ['1', '2', '3']
        self.assertNotEqual(
                self.__sql_manager.get_all_begin_node_task_from_schedule(
                        task_id_list), None)

    def test_get_last_task_run_time(self):
        self.assertNotEqual(self.__sql_manager.get_last_task_run_time('1'), None)

    def test_get_task_num_with_group_type(self):
        tasks = self.__sql_manager.get_task_num_with_group_type()
        self.assertNotEqual(tasks, None)

    def test_get_owner_task_num_with_type(self):
        tasks = self.__sql_manager.get_owner_task_num_with_type()
        self.assertNotEqual(tasks, None)

    def test_check_all_task_succeeded(self):
        horae.models.Schedule.objects.create(
                id=1,
                task_id=1,
                run_time='201505110101',
                status=task_util.TaskState.TASK_RUNNING,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        horae.models.Schedule.objects.create(
                id=2,
                task_id=2,
                run_time='201505110101',
                status=task_util.TaskState.TASK_WAITING,
                start_time='2015-05-11 10:00:00',
                pl_id=1)

        horae.models.Schedule.objects.create(
                id=3,
                task_id=3,
                run_time='201505110101',
                status=task_util.TaskState.TASK_FAILED,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        horae.models.Schedule.objects.create(
                id=4,
                task_id=4,
                run_time='201505110101',
                status=task_util.TaskState.TASK_PREV_FAILED,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        horae.models.Schedule.objects.create(
                id=5,
                task_id=5,
                run_time='201505110101',
                status=task_util.TaskState.TASK_READY,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        horae.models.Schedule.objects.create(
                id=6,
                task_id=6,
                run_time='201505110101',
                status=task_util.TaskState.TASK_STOPED_BY_USER,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        horae.models.Schedule.objects.create(
                id=7,
                task_id=7,
                run_time='201505110101',
                status=task_util.TaskState.TASK_SUCCEED,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        horae.models.Schedule.objects.create(
                id=8,
                task_id=8,
                run_time='201505110101',
                status=task_util.TaskState.TASK_TIMEOUT,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        task_id_list = [1, 2, 3, 4, 5, 6, 7, 8]
        begin_time = '201505110100'
        end_time = '201505110102'
        schedules = self.__sql_manager.check_all_task_succeeded(
                task_id_list, 
                begin_time, 
                end_time)
        self.assertFalse(schedules)

    def test_connection(self):
        schedule = horae.models.Schedule.objects.create(
                id=7,
                task_id=7,
                run_time='201505110101',
                status=task_util.TaskState.TASK_SUCCEED,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        horae.models.Schedule.objects.create(
                id=8,
                task_id=8,
                run_time='201505110101',
                status=task_util.TaskState.TASK_TIMEOUT,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        schedule.delete()
        ready_task = horae.models.ReadyTask.objects.create(
                pl_id=1,
                schedule_id=1,
                status=task_util.TaskState.TASK_READY,
                update_time="2015-05-01 10:00:00",
                run_server="127.0.0.1",
                type=1,
                init_time="2015-05-01 10:00:00",
                run_time="201505190000",
                task_id=1,
                task_handler='',
                retry_count=1,
                retried_count=0,
                server_tag='ALL',
                pid=1)
        ready_task.delete()

    def test_limit(self):
        for i in range(0, 10000):
            horae.models.Schedule.objects.create(
                task_id=i,
                run_time=task_util.StaticFunction.get_now_format_time(
                        "%Y%m%d%H%M%S"),
                status=task_util.TaskState.TASK_WAITING,
                start_time='2015-05-11 10:00:00',
                pl_id=1)
        begin_time = time.time()
        schedules = horae.models.Schedule.objects.filter(
                    status=task_util.TaskState.TASK_WAITING).order_by('run_time')
        print("%s:%s" % (len(schedules), time.time() - begin_time))
        begin_time = time.time()
        schedules = horae.models.Schedule.objects.filter(
                    status=task_util.TaskState.TASK_WAITING).order_by('run_time')[:100]
        print("%s:%s" % (len(schedules), time.time() - begin_time))

    def test_cursor(self):
        cursor = django.db.connection.cursor()
        sql = "update horae_pipeline set name = 'xielei_test11111' where id = 1;"
        print(cursor.execute(sql))
        pipe_line = horae.models.Pipeline.objects.get(id=1)
        print("sdfasdfas")
        print(pipe_line.name)

