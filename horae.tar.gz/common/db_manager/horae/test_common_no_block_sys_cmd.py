﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging

import django.test

sys.path.append('../')
import no_block_sys_cmd
import common_logger

class TestCommonNoBlockSysCmd(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        logging.basicConfig(
            level=logging.DEBUG, 
            format='%(asctime)s %(filename)'
                's[line:%(lineno)d] --%(levelname)s-- : %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S', 
            filename="./log/test.log")

        self.__sys_cmd = no_block_sys_cmd.NoBlockSysCommand()

    def test_run_many(self):
        cmd = "echo 'Hello World!'"
        stdout, stderr, ret_code = self.__sys_cmd.run_many(cmd)
        self.assertEqual(stdout, "Hello World!\n")
        self.assertEqual(ret_code, 0)

    def test_run_once(self):
        cmd = "echo 'Hello World!'"
        stdout, stderr, ret_code = self.__sys_cmd.run_once(cmd)
        self.assertEqual(stdout, "Hello World!\n")
        self.assertEqual(ret_code, 0)



