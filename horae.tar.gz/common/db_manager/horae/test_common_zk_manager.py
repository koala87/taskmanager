﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time

import django.test

sys.path.append('../')
import zk_manager
import common_logger

class TestCommonZkManager(django.test.TestCase):
    """description of class"""
    def setUp(self):
        common_logger.init_log("./log/test")
        self.__zk = zk_manager.ZookeeperManager(
                hosts=(
                        '10.182.0.175:2181,10.182.1.84:2181,10.182.2.55:'
                        '2181,10.181.255.90:2181,10.181.255.99:2181'), 
                log_conf='./conf/admin_logger.conf')
        if self.__zk.exists("/my/my_path") is None:
            self.assertNotEqual(self.__zk.create(
                    path="/my/my_path", 
                    makepath=True), None)

    def test_exists(self):
        self.assertNotEqual(self.__zk.exists("/my/my_path"), None)

    def test_create(self):
        self.assertNotEqual(self.__zk.create("/my/my_path/create"), None)

    def test_delete(self):
        self.assertNotEqual(self.__zk.delete("/my/my_path/create"), None)

    def test_get_and_set(self):
        self.assertNotEqual(self.__zk.set("/my/my_path", "Hello!"), None)
        self.assertEqual(self.__zk.get("/my/my_path")[0], "Hello!")

    def test_get_children(self):
        self.assertTrue('my_path' in self.__zk.get_children("/my"))

    def test_watch_children(self):
        if self.__zk.exists("/my/my_path/watch_child/1") is not None:
            self.assertNotEqual(
                    self.__zk.delete("/my/my_path/watch_child/1"), 
                    None)
        if self.__zk.exists("/my/my_path/watch_child") is not None:
            self.assertNotEqual(
                    self.__zk.delete("/my/my_path/watch_child", recursive=True), 
                    None)
        self.assertNotEqual(
                self.__zk.create("/my/my_path/watch_child"), 
                None)
        self.assertNotEqual(
                self.__zk.exists("/my/my_path/watch_child"), 
                None)

        self.assertNotEqual(
                self.__zk.watch_children(
                        "/my/my_path/watch_child", 
                        zk_manager.watch_children),
                None)
        self.assertNotEqual(
                self.__zk.create("/my/my_path/watch_child/1"), 
                None)
        time.sleep(1)
        self.assertNotEqual(
                self.__zk.delete("/my/my_path/watch_child/1"), 
                None)
        self.assertNotEqual(
                self.__zk.delete("/my/my_path/watch_child"), 
                None)

    def test_watch_node(self):
        if self.__zk.exists("/my/my_path/watch_node") is not None:
            self.assertNotEqual(
                    self.__zk.delete("/my/my_path/watch_node"), 
                    None)
        self.assertNotEqual(
                self.__zk.create("/my/my_path/watch_node"), 
                None)

        self.assertNotEqual(
                self.__zk.watch_node(
                        "/my/my_path/watch_node", 
                        zk_manager.watch_node),
                None)
        self.assertNotEqual(
                self.__zk.set("/my/my_path/watch_node", b"1"), 
                None)
        time.sleep(1)
        self.assertNotEqual(
                self.__zk.delete("/my/my_path/watch_node"), 
                None)

    def test_zk_lock(self):
        test_lock = self.__zk.create_lock("/my/my_path/lock")
        self.assertNotEqual(test_lock, None)
        self.assertTrue(self.__zk.aquire_lock(test_lock, False))
        self.assertNotEqual(self.__zk.release_lock(test_lock), False)

    def test_restart(self):
        zk = self.__zk._ZookeeperManager__zk
        zk.stop()
        zk.restart()
        print("test :")
        print(self.__zk.exists("/my/my_path"))
        if self.__zk.exists("/my/my_path") is None:
            self.assertNotEqual(self.__zk.create("/my/my_path"), None)

