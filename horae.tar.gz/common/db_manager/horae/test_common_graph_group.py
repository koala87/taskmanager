﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys

import django.test

sys.path.append('../')
import graph_group
import common_logger

class TestCommonGraphGroup(django.test.TestCase):
    def setUp(self):
        common_logger.init_log("./log/test")
        self.graph_group = graph_group.GraphGroup()

    def test_add_page(self):
        self.assertTrue(self.graph_group.add_eage(1, 2))
        self.assertTrue(self.graph_group.add_eage(1, 3))
        self.assertTrue(self.graph_group.add_eage(2, 7))
        self.assertTrue(self.graph_group.add_eage(2, 4))
        self.assertTrue(self.graph_group.add_eage(3, 5))
        self.assertTrue(self.graph_group.add_eage(3, 6))
        self.assertFalse(self.graph_group.add_eage(3, 6))
        self.assertFalse(self.graph_group.add_eage(6, 3))
        self.assertFalse(self.graph_group.add_eage(1, 1))
        self.assertFalse(self.graph_group.add_eage(5, 1, True))

    def test_get_sub_graphs(self):
        self.assertTrue(self.graph_group.add_eage(1, 2))
        self.assertTrue(self.graph_group.add_eage(1, 3))
        self.assertTrue(self.graph_group.add_eage(2, 7))
        self.assertTrue(self.graph_group.add_eage(2, 4))
        self.assertTrue(self.graph_group.add_eage(12, 14))
        self.assertTrue(self.graph_group.add_eage(12, 24))
        self.assertTrue(self.graph_group.add_node(33))
        self.assertFalse(self.graph_group.add_node(33))
        self.assertTrue(self.graph_group.add_node(35))
        graph_list = []
        self.graph_group.get_sub_graphs(graph_list)
        self.assertEqual(len(graph_list), 4)


        
