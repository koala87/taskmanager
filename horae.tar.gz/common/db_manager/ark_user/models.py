from django.db import models

class Info(models.Model):
    user_id = models.IntegerField(default=0, db_index=True)
    odps_access_id = models.CharField(max_length=16, null=True)
    odps_access_key = models.CharField(max_length=30, null=True)
    odps_dxp_account = models.CharField(max_length=80, null=True)
    odps_biz_id = models.CharField(max_length=50, null=True)
    job_user_key = models.CharField(max_length=32, null=True)
    phone = models.CharField(max_length=11, null=True)
    ali_username = models.CharField(max_length=50)
    ali_name = models.CharField(max_length=10, null=True)
    ali_mail = models.EmailField(max_length=254)
    ali_wangwang = models.CharField(max_length=50, null=True)
    ali_monitor = models.CharField(
            max_length=50, 
            null=True,
            help_text = 'ali_monitor_groupname')
