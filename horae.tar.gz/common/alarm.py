#! /bin/env python
#encoding:utf-8
import urllib
import os,sys
import no_block_sys_cmd
import sys
reload(sys)
sys.setdefaultencoding("utf-8")

ALARM_CRITICAL = 2
ALARM_WARN = 1

class Alarm(object):
    httpAlarmAddress = "http://127.0.0.1:15776/passive"
    alarmGroup = "task_schedule"
    alarmOn = True
    alarmDTGroup = "smlog_dt_server"
    
    @staticmethod
    def dtWarn(msg):
       return Alarm.httpAlarm(ALARM_WARN,Alarm.alarmDTGroup,msg)

    @staticmethod
    def critical(alarmStr):
        return Alarm.httpAlarm(ALARM_CRITICAL, alarmStr)

    @staticmethod
    def warn(alarmStr, user_group=''):
        if not user_group:
            user_group = Alarm.alarmGroup
        return Alarm.httpAlarm(ALARM_WARN,user_group,alarmStr)

    @staticmethod
    def httpAlarm(alarmLevel,group_name,msg):
        if Alarm.alarmOn:
            #msg not support space ,filter space by _
            msg = msg.replace(" ","-")
            msg = str(msg)
            msgEncode = urllib.quote(msg)
            curlString = Alarm.httpAlarmAddress+"?name="+group_name+"&msg=1234%09+status="+str(alarmLevel)+"+output="+msgEncode
            alarmCmd = 'curl \"%s\"' % curlString
            stdout,stderr,code = no_block_sys_cmd.NoBlockSysCommand.run_many(alarmCmd)
            if code !=0:
                return False
            return True
        return False
            #os.system(alarmCmd)

if __name__ == "__main__":
    httpAddress = "http://127.0.0.1:15776/passive"
    Alarm.dtWarn("datatunnel server error!")


