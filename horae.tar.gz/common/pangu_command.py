﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
盘古相关操作命令封装

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import tempfile
import ConfigParser
import logging

import no_block_sys_cmd
import task_util

class PanguCommand(object):
    """
        pangu相关操作命令
    """
    def __init__(self, config, log_path = ''):
        self.__log = logging
        self.__pu_exe = config.get("pangu", "pu_exe")
        self.__sys_exec = no_block_sys_cmd.NoBlockSysCommand()

    def exist_dir(self, dir_path, run_once=True):
        cmd = '%s dirmeta %s' % (self.__pu_exe, dir_path)
        if run_once:
            stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        else:
            stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn("pangu exec cmd[%s] failed!" % cmd)
            return False
        return True

    def exist_file(self, file_path, run_once=True):
        cmd = '%s meta %s' % (self.__pu_exe, file_path)
        if run_once:
            stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        else:
            stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn("pangu exec cmd[%s] failed!" % cmd)
            return False
        return True

    def read_file(self, file_path, run_once=False):
        cmd = '%s cat %s' % (self.__pu_exe, file_path)
        if run_once:
            stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        else:
            stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn("pangu exec cmd[%s] failed!" % cmd)
            return None
        return stdout

    def read_file_lines(self, file_path, lines):
        cmd = '%s cat %s |head -n%s' % (self.__pu_exe, file_path, lines)
        stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        return (retcode == 0, stdout,stderr)

    def write_atomic_file(self, file_path, content):
        tmp_pangu_file_path = file_path + '.temp'
        tmp_dir = tempfile.mktemp()
        cmd = 'mkdir -p %s' % tmp_dir
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            return False

        tmp_local_file = tmp_dir + '/tmp'
        f = open(tmp_local_file, 'w')
        f.write(content)
        f.close()

        cmd = '%s cp %s %s' % \
                (self.__pu_exe, tmp_local_file, tmp_pangu_file_path)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False

        cmd = '%s rm %s' % (self.__pu_exe, file_path)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        return mv_file(tmp_pangu_file_path, file_path)

    def mk_dir(self, pangu_dir, run_once=False):
        cmd = '%s mkdir %s' % (self.__pu_exe, pangu_dir)
        if run_once:
            stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        else:
            stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        return stdout, stderr, retcode

    def mv_file(self, src_file, dest_file):
        if exist_file(dest_file):
            rm_file(dest_file)
        cmd = '%s mv %s %s' % (self.__pu_exe, src_file, dest_file)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False
        return True

    def mv_dir(self, src_dir, dest_dir):
        process = no_block_process.Process()
        cmd = '%s mvdir %s %s'  % (self.__pu_exe, src_dir, dest_dir)

        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False
        return True

    def cp_file(self, src_file, dest_file, run_once=True):
        cmd = '%s cp %s %s'  % (self.__pu_exe, src_file, dest_file)
        if run_once:
            stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        else:
            stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False
        return True

    def cp_dir(self, src_dir, dest_dir):
        cmd = '%s cpdir %s %s'  % (self.__pu_exe, src_dir, dest_dir)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False
        return True

    def rm_file(self, file_name, run_once=False):
        cmd = '%s rm %s' % (self.__pu_exe, file_name)
        if run_once:
            stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        else:
            stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False
        return True

    def rm_dir(self, dir_name, run_once=False):
        cmd = '%s rmdir -f %s' % (self.__pu_exe, dir_name)
        if run_once:
            stdout, stderr, retcode = self.__sys_exec.run_once(cmd)
        else:
            stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False
        return True

    def ls_dir(self, dir_name):
        cmd = '%s ls %s' % (self.__pu_exe, dir_name)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stderr[%s], retcode[%s]' % \
                    (cmd, stderr, retcode))
            return None
        return stdout

    def select_nth_dir(self, dir_name, nth, sort_descend = True):
        '''
        select the n-th dir listed below dir_name
        dir_name:  string type, pangu dir
        nth     :  int type, value scope is [1, x], x is 
                    the count of sub-dir under dir dir_name
        return  :  True/False, nth_dir_full_path
        '''
        sort_cmd = " sort "
        if sort_descend:
            sort_cmd = sort_cmd + " -r "
        cmd = '%s ls %s | %s' % (self.__pu_exe, dir_name, sort_cmd)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.error('run[%s] failed. stderr[%s], retcode[%s]' % \
                    (cmd, stderr, retcode))
            return False, ''

        tokens = stdout.strip().split('\n')
        dir_list = []
        for idx in range(len(tokens)):
            if tokens[idx].endswith('/'):
                dir_list.append(tokens[idx])
        if nth >= 1 and nth <= len(dir_list):
            nth_dir = dir_name + dir_list[nth - 1]
            self.__log.warn('The nth dir is :[%s]' % nth_dir)
            return True, nth_dir
        else:
            self.__log.warn('nth: [%d] is not in range [1, %d]' % \
                    (nth, len(dir_list)))
            return False, ''

    def list_dir(self, file_path):
        cmd = '%s ls %s' % (self.__pu_exe, file_path)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return False, ''
        tokens = stdout.strip().split('\n')
        if len(tokens) != 1:
            self.__log.warn('Sub directory size error. sub dirs')
            return False, ''
        return True, tokens[0]

    def list_dir_absolute_path(self, file_path):
        cmd = '%s ls %s' % (self.__pu_exe, file_path)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return ''
        tokens = stdout.strip().split('\n')
        for i in range(len(tokens)):
            if tokens[i][-1] == '/':
                tokens[i] = ''
            else:
                tokens[i] = join_path(file_path, tokens[i])
        return ';'.join(tokens)

    def download_dir_to_tmp(self, dir_path):
        if dir_path[-1] != '/':
            dir_path += '/'

        tmp_dir = tempfile.mktemp()
        cmd = 'mkdir -p %(tmp_dir)s' % {'tmp_dir': tmp_dir}
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)

        if retcode != 0:
            self.__log.warn('run cmd:%s error:%s' % stderr)
            return ''

        cmd = '%s cpdir %s %s' % {self.__pu_exe, dir_path, tmp_dir}
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run cmd:%s error:%s' % stderr)
            return ''

        tokens = dir_path.split('/')
        local_tmp_dir = tmp_dir + '/' + tokens[-2] + '/'
        return local_tmp_dir

    def dir_meta(self, dir_path):
        if dir_path[-1] != '/':
            dir_path += '/'

        cmd = '%s dirmeta %s' % (self.__pu_exe, dir_path)
        stdout, stderr, retcode = self.__sys_exec.run_many(cmd)
        if retcode != 0:
            self.__log.warn('run[%s] failed. stdout[%s], stderr[%s], '
                    'retcode[%s]' % (cmd, stdout, stderr, retcode))
            return ''
        return stdout

if __name__ == '__main__':
    config = ConfigParser.RawConfigParser()
    config.read("./conf/test.conf")
    main_log = log_manager.root_log
    pangu_cmd = PanguCommand(config, './conf/logger.conf')

    pangu_dir = ('pangu://AY54/product/dataware_house/'
            'data_backup/click_s_aliyun_com/')
    print("pangu_cmd.exist_dir")
    print(pangu_cmd.exist_dir(pangu_dir))

    pangu_file = ('pangu://AY54/product/dataware_house/data_backup/'
            'click_s_aliyun_com/2015_02_18/2015_02_18_19_00.23')
    print("pangu_cmd.exist_file")
    print(pangu_cmd.exist_file(pangu_file))
    print("pangu_cmd.read_file")
#    print(pangu_cmd.read_file(pangu_file))
    print("pangu_cmd.read_file_lines")
    print(pangu_cmd.read_file_lines(pangu_file, 1))
    print("pangu_cmd.cp_file")
    print(pangu_cmd.cp_file(pangu_file, './test/pangu_test.log'))

    pangu_dir = ('pangu://AY54/product/dataware_house/'
            'data_backup/')
    print("pangu_cmd.ls_dir")
    print(pangu_cmd.ls_dir(pangu_dir))
    print("pangu_cmd.list_dir")
    print(pangu_cmd.list_dir(pangu_dir))

    pangu_dir = ('pangu://AY54/product/dataware_house/'
            'data_backup/click_s_aliyun_com/')
    print("pangu_cmd.list_dir_absolute_path")
    print(pangu_cmd.list_dir_absolute_path(pangu_dir))