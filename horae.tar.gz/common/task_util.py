###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
常量，静态方法等

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import exceptions
import string
import re
import socket
import datetime

import enum

# 任务状态
class TaskState(enum.Enum):
    TASK_WAITING = 0  # 等待中
    TASK_RUNNING = 1  # 正在执行
    TASK_SUCCEED = 2  # 执行成功
    TASK_FAILED = 3  # 执行失败
    TASK_TIMEOUT = 4  # 任务超时
    TASK_READY = 5  # 任务已经写入ready_task，等待调度
    TASK_STOPED_BY_USER = 6  # 任务被用户停止
    TASK_PREV_FAILED = 7  # 上游任务失败

# 任务类型
class TaskType(enum.Enum):
    SCRIPT_TYPE = 1
    APSARA_JOB = 2
    ODPS_SQL = 3
    ODPS_MAP_REDUCE = 4
    ODPS_XLAB_SCRIPT = 5
    ODPS_SPARK = 6

# 数据类型
class DataType(enum.Enum):
    ODPS_DATA_TYPE = 0
    PANGU_DATA_TYPE = 1

# 每种任务最大执行数
class MaxTaskNum(enum.Enum):
    MAX_SCRIPT_TASK_NUM = 30
    MAX_APSARA_JOB_NUM = 60
    MAX_ODPS_SQL_NUM = 60
    MAX_ODPS_JOB_NUM = 30
    MAX_ODPS_XLAB_SCRIPT_NUM = 30
    MAX_ODPS_SPARK_NUM = 30

class EachUserTaskLimitNum(enum.Enum):
    SCRIPT_TASK_NUM = 10  # 每个用户最大执行任务数
    APSARA_JOB_TASK_NUM = 10
    ODPS_SQL_TASK_NUM = 30
    ODPS_MAP_TASK_NUM = 10
    ODPS_XLAB_TASK_NUM = 10
    ODPS_SPARK_TASK_NUM = 10

class PipelineType(enum.Enum):
    CREATE_BY_ARK_TOOLS = 0  # 在前端工具创建
    CREATE_BY_AUTO_WORK = 1  # 后端动态创建

class FileCommandRet(enum.Enum):
    FILE_COMMAND_SUCC = 0  # 操作文件成功
    FILE_IS_NOT_EXISTS = 1  # 文件不存在
    FILE_PATH_IS_NOT_EXISTS = 2  # 文件路径不存在（不包括文件名）
    FILE_READ_ERROR = 3  # 读取文件失败
    FILE_WRITE_ERROR = 4  # 写文件失败

class UserPermissionType(enum.Enum):
    NO_AUTH = 0
    READ = 1
    WRITE = 2
    CONFIRMING = 3  # 申请权限确认中
    READ_STR = "read"
    WRITE_STR = "write"

# 权限操作动作类型
class AuthAction(enum.Enum):
    GRANT_AUTH_TO_OTHER = 0  # 授予权限给其他用户
    CONFIRM_APPLY_AUTH = 1  # 用户确认其他用户的权限申请
    REJECT_APPLY_AUTH = 2  # 用户拒绝其他用户的权限申请
    APPLY_AUTH = 3  # 用户申请权限
    TAKE_BACK_AUTH = 4  # 用户收回授予的权限

# 全局变量（注意，此处的enum.Enum和C不同，
# 不是常量，而是可改变常量，需要用户保证其正确性）
class CONSTANTS(enum.Enum):
    GLOBAL_STOP = False  # 全局停止标志
    HOLD_FOR_ZOOKEEPER_LOCK = True  # 获取zookeeper权限标志
    RUN_TIME_FORMAT = "%Y%m%d%H%M"
    TPL_CONFIG_NAME = "_tpl"  # tpl输入文件名
    USER_KEY_CONFIG_NAME = "_user_key"  # 飞天job user key
    RUN_TIME_LENTGH = 12  # 运行时间格式长度，统一为YYYYmmddHHMM的格式
    PATH_PANGU_START_WITH = 'pangu:/'
    PATH_ODPS_SQL_START_WITH = 'odps:/'
    PATH_LOCAL_START_WITH = '/'  # 本地路径只支持绝对路径，不支持相对路径
    MAX_PANGU_FILES = 100000  # 盘古任务每次最多处理的文件数
                            # 如果文件数超过这个限制，则任务失败，不做处理
    APSARA_JOB_TPL_OUT_CONFIG_NAME = "run.json"
    DEFAULT_INSTANCE_COUNT = 24  # 默认处理实例数
    NUWA_ADDRESS_HEAD = "nuwa://"  # 女娲地址默认开头部分
    TASK_PRIORITY_MIN = 5  # 最小优先级
    TASK_PRIORITY_MAX = 10  # 最大优先级
    SCRIPT_DEFSULT_TPL_CONF_NAME = "run.conf.tpl"  # script默认配置tpl
    SCRIPT_DEFSULT_CONF_NAME = "run.conf"  # script默认配置文件名
    SCRIPT_DEFSULT_PYTHON_FILE = "run.py"  # python默认执行文件名

    ODPS_MAP_REDUCE_JAR_CONF_NAME = '_jar'  # odps-mr任务的jar包名配置
    CT_TIME_SPLIT_NUM = 5

    ODPS_SQL_CMD_STR = (""" %s --project=%s --endpoint=%s """
                       """--instance-priority=%s -u %s -p %s -e"%s" """)
    ODPS_XLIB_CMD_STR = (""" %s --project %s --endpoint %s  """
                        """ --access-id %s --access-key """
                        """ %s xlib "execfile('%s')" """)
    ODPS_SQL_CMD_FILE_STR = (""" %s --project=%s --endpoint=%s """
                       """--instance-priority=%s -u %s -p %s -f %s """)
    ODPS_SQL_FILE_NAME = "odps.sql"

    APSARA_JOB_USER_NAME = "data_platform"
    MAX_RANDOM_TASKID_MIN = 2000000000
    MAX_RANDOM_TASKID_MAX = 2147483647
    WORK_DIR_SPACE_VALID = 1024 * 1024 * 1024
    TASK_RETRY_MAX_TIME_PERIOD = 3 * 60 * 60  # 重试最大时间间隔
    TASK_RETRY_STEP_INC_TIME = 200  # 每次重试递增休眠时间60s
    TASK_RETRY_STEP_INC_RATIO = 3  # 每次重试递增休眠时间系数,
                                     # 即此次休眠时间是上次休眠的1.5倍
    MAX_CONFIG_VALUE_LENGTH = 4096
    ODPS_SPARK_TPL_CONF_NAME = "spark.conf.tpl"  # odps_spark默认配置tpl
    ODPS_SPARK_CONF_NAME = "spark.conf"  # odps_spark默认配置tpl

    HTTP_RESPONSE_WAIT = 'WAIT'
    HTTP_RETRY_MSG = 'RETRY'
    TASK_DISPATCHER_IS_RUNNING = False

    MAX_FILE_DOWNLOAD_SIZE = 1024 * 1024 * 1024  # 下载文件最大size，1G

# 任务类型与任务限制数对应
global_task_limit_map = {
        TaskType.SCRIPT_TYPE: MaxTaskNum.MAX_SCRIPT_TASK_NUM,
        TaskType.APSARA_JOB: MaxTaskNum.MAX_APSARA_JOB_NUM,
        TaskType.ODPS_SQL: MaxTaskNum.MAX_ODPS_SQL_NUM,
        TaskType.ODPS_MAP_REDUCE: MaxTaskNum.MAX_ODPS_JOB_NUM,
        TaskType.ODPS_XLAB_SCRIPT: MaxTaskNum.MAX_ODPS_XLAB_SCRIPT_NUM,
        TaskType.ODPS_SPARK: MaxTaskNum.MAX_ODPS_SPARK_NUM
    }

# 每个用户最大任务类型与任务限制数对应
global_each_user_task_limit_map = {
        TaskType.SCRIPT_TYPE: EachUserTaskLimitNum.SCRIPT_TASK_NUM,
        TaskType.APSARA_JOB: EachUserTaskLimitNum.APSARA_JOB_TASK_NUM,
        TaskType.ODPS_SQL: EachUserTaskLimitNum.ODPS_SQL_TASK_NUM,
        TaskType.ODPS_MAP_REDUCE: EachUserTaskLimitNum.ODPS_MAP_TASK_NUM,
        TaskType.ODPS_XLAB_SCRIPT: EachUserTaskLimitNum.ODPS_XLAB_TASK_NUM,
        TaskType.ODPS_SPARK: EachUserTaskLimitNum.ODPS_SPARK_TASK_NUM
    }

global_status_info_map = {
        TaskState.TASK_WAITING: "TASK_WAITING",
        TaskState.TASK_RUNNING: "TASK_RUNNING",
        TaskState.TASK_SUCCEED: "TASK_SUCCEED",
        TaskState.TASK_FAILED: "TASK_FAILED",
        TaskState.TASK_TIMEOUT: "TASK_TIMEOUT",
        TaskState.TASK_READY: "TASK_READY",
        TaskState.TASK_STOPED_BY_USER: "TASK_STOPED_BY_USER",
        TaskState.TASK_PREV_FAILED: "TASK_PREV_FAILED"
    }

# 配置中支持的时间格式
global_time_format_list = [
        '%year%',
        '%yyyy%',
        '%Y%',
        '%month%',
        '%mm%',
        '%m%',
        '%day%',
        '%dd%',
        '%d%',
        '%hour%',
        '%hh%',
        '%H%',
        '%minute%',
        '%MM%',
        '%M%',
    ]

class Singleton(object):
    def __new__(cls, *args, **kw):
        if not hasattr(cls, "_instance"):
            orig = super(Singleton,cls)
            cls._instance = orig.__new__(cls, *args, **kw)

        return cls._instance

class AutoLock(object):
    def __init__(self, lock):
        self.__lock = lock
        self.__lock.acquire()

    def __del__(self):
        self.__lock.release()

class StaticFunction(object):
    @staticmethod
    def strip_with_one_space(in_str):
        """
            将字符串中的\t以及多余空格全部替换为一个空格间隔
        """
        return ' '.join(filter(lambda x: x, in_str.split(' ')))

    @staticmethod
    def strip_with_nothing(in_str):
        """
            将字符串中的\t以及多余空格全部去除
        """
        return ''.join(filter(lambda x: x, in_str.split(' ')))

    @staticmethod
    def get_local_ip():
        """
            获取本地ip地址
        """
        return socket.gethostbyname(socket.gethostname())

    @staticmethod
    def get_all_content_from_file(file_path, param="r"):
        """
            读取文件，并返回所有数据
            file_path： 需要读取的文件路径
            param： 读文件参数
            return: 失败 None 成功：文件内容
        """
        if not os.path.exists(file_path):
            return FileCommandRet.FILE_PATH_IS_NOT_EXISTS, ''

        fd = open(file_path, param)
        try:
            return FileCommandRet.FILE_COMMAND_SUCC, fd.read()
        except exceptions.Exception as ex:
            return FileCommandRet.FILE_WRITE_ERROR, ''
        finally:
            fd.close()

    @staticmethod
    def get_file_content_with_start_and_len(file_path, start, len, param="r"):
        if not os.path.exists(file_path):
            return FileCommandRet.FILE_PATH_IS_NOT_EXISTS, ''

        fd = open(file_path, param)
        try:
            fd.seek(start)
            return FileCommandRet.FILE_COMMAND_SUCC, fd.read(len)
        except exceptions.Exception as ex:
            return FileCommandRet.FILE_WRITE_ERROR, ''
        finally:
            fd.close()

    @staticmethod
    def write_content_to_file(file_path, content, param="w"):
        """
            将内容写入文件
            content： 写入内容
            file_path： 文件路径
            param： 写文件参数
            return: FileCommandRet
        """
        path = os.path.dirname(os.path.abspath(file_path))
        if not os.path.exists(path):
            return FileCommandRet.FILE_PATH_IS_NOT_EXISTS
        
        fd = open(file_path, param)
        try:
            fd.write(content)
            return FileCommandRet.FILE_COMMAND_SUCC
        except exceptions.Exception as ex:
            return FileCommandRet.FILE_WRITE_ERROR
        finally:
            fd.close()

    @staticmethod
    def replace_str_with_regex(src_content, pattern, kv_pair_map):
        """
            通过正则表达式pattern，将输入内容按照kv_pair_map，替换关键字内容
            src_content: 需要替换的源字符串
            pattern: 匹配的正则表达式
            kv_pair_map: 替换kv对map
            return: 失败: None, 成功：正确替换内容

            Basic Example:
                src_content = 
                    " {
                        "part": "${part}",
                        "sep": "${sep}",
                        "/SetLimit/core": "unlimited",
                        "/SetEnv/LD_LIBRARY_PATH": "/usr/ali/java/jre/",
                        "table": "${table}",
                       }
                    "
                pattern = '\$\{[^}]*\}'
                kv_pair_map = {
                    "part" : "test_part",
                    "sep" : "test_sep",
                }

                print(task_util.StaticFunction.replace_str_with_regex(
                        src_content, 
                        pattern, 
                        kv_pair_map))
                输出：
                    " {
                        "part": "test_part",
                        "sep": "test_sep",
                        "/SetLimit/core": "unlimited",
                        "/SetEnv/LD_LIBRARY_PATH": "/usr/ali/java/jre/",
                        "table": "",  # 如果kv_pair_map中没有此关键字，替换为空
                       }
                    "
        """
        try:
            template = string.Template(src_content)
            tmp_content = template.safe_substitute(kv_pair_map)
            regex_object = re.compile(pattern)
            return regex_object.sub("", tmp_content)
        except exceptions.Exception as ex:
            return None

    @staticmethod
    def get_path_sub_regex_pattern(full_path, parent_dir):
        if len(full_path) <= len(parent_dir):
            return None
        if parent_dir[-1] != '/':
            parent_dir = parent_dir + '/'
        find_pos = full_path.find("/", len(parent_dir))
        if find_pos == -1:
            return full_path[len(parent_dir): len(full_path)]
        return full_path[len(parent_dir): find_pos]

    @staticmethod
    def get_now_format_time(format):
        now_time = datetime.datetime.utcnow() + datetime.timedelta(hours=8)
        return now_time.strftime(format)

    @staticmethod
    def remove_empty_file(file_path):
        if not os.path.exists(file_path):
            return False

        if os.path.isdir(file_path):
            return False

        if os.path.getsize(file_path) <= 0:
            os.remove(file_path)
        return True
    
if __name__ == "__main__":
    # test StaticFunction
    print(StaticFunction.strip_with_one_space("test \n   space    "))
    print(StaticFunction.get_local_ip())
    read_content = ''
    print(StaticFunction.get_all_content_from_file("./test/test.log"))
    print(read_content)
    src_content = (
            """ { """
            """ "part": "${part}", """
            """ "sep": "${sep}", """ 
            """ "/SetLimit/core": "unlimited", """ 
            """ "/SetEnv/LD_LIBRARY_PATH": "/usr/ali/java/jre/", """ 
            """ "table": "${table}", """ 
            """ } """ )
    pattern = '\$\{[^}]*\}'
    kv_pair_map = {
        "part" : "test_part",
        "sep" : "test_sep",
    }
    print(StaticFunction.replace_str_with_regex(
            src_content, 
            pattern, 
            kv_pair_map))
    print(StaticFunction.write_content_to_file("./test/write.log", "test"))
    print(StaticFunction.write_content_to_file("./teas/write.log", "test"))