#encoding:utf-8

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import json
import time
import exceptions
import urllib2
import traceback
import re
import string
import logging
import logging.config
import subprocess
import tempfile
import select

class NoBlockSysCommand(object):
    def __init__(self):
        self.__log = logging

    def run_many(self, cmd, retry_times=5):
        stdout = None
        stderr = None
        return_code = -1
        for i in range(retry_times):
            stdout, stderr, return_code = self.run_once(cmd)
            if return_code != 0:
                self.__log.warn('[ERROR]. run cmd [%s] failed! retry %s.' % \
                        (cmd, i + 1))
                time.sleep(1)
            else:
                return stdout, stderr, return_code
        return stdout, stderr, return_code
            
    def run_once(self, cmd):
        stdout_file = tempfile.NamedTemporaryFile()
        stderr_file = tempfile.NamedTemporaryFile()
        cmd = '%(cmd)s 1>>%(out)s 2>>%(err)s' % {
                'cmd': cmd, 
                'out': stdout_file.name, 
                'err': stderr_file.name
            }
        return_code = os.system(cmd)
        # the returnCode of os.system() is encoded by the wait(),
        # it is a 16-bit number, the higher byte is the exit code of the cmd
        # and the lower byte is the signal number to kill the process
        stdout = stdout_file.read()
        stderr = stderr_file.read()
        stdout_file.close()
        stderr_file.close()
        return stdout, stderr, return_code

if __name__ == "__main__":
    cmd = sys.argv[1]
    NoBlockSysCommand().run_once(cmd) 
