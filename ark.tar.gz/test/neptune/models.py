#encoding:utf-8
from django.db import models

class TagConf(models.Model):
    data_type = models.IntegerField(default=0, db_index=True)
    user_name = models.CharField(max_length=50,db_index=True)
    app_name = models.CharField(max_length=1024)
    category_type = models.CharField(max_length=1024)
    update_cycle = models.IntegerField(default=0)
    crontab_conf = models.CharField(max_length=250)
    overtime = models.IntegerField(default=0)
    test_time = models.DateTimeField('test_time', null= True)
    #test_time = models.IntegerField(null=True)
    protect_level = models.IntegerField(default=0, null=False)
    version = models.CharField(max_length=1024,null=True)
    status = models.IntegerField(default=0)
    schema_file = models.CharField(max_length=1024)
    description = models.CharField(max_length=1024, null=True)
    data_config = models.CharField(max_length=4096, null=True)
    raw_odps_table = models.CharField(max_length=1024)
    algin_odps_table = models.CharField(max_length=1024)
    ots_table = models.CharField(max_length=1024)
    pipeline_name = models.CharField(max_length=1024)
    create_time = models.DateTimeField('create_time',auto_now = True)
    update_time = models.DateTimeField('update_time')

class Publication(models.Model):
    user_name = models.CharField(max_length=50,db_index=True)
    app_name = models.CharField(max_length=1024)
    data_type = models.IntegerField(default=0, db_index=True)
    create_time = models.DateTimeField('create_time',auto_now = True)
    version = models.CharField(max_length=1024,null=True)
    publication_time = models.DateTimeField('publish time')
    
class Statistic(models.Model):
    user_name = models.CharField(max_length=50,db_index=True)
    app_name = models.CharField(max_length=1024)
    uv = models.BigIntegerField(default=0)
    data_size = models.BigIntegerField(default=0)
    category_type = models.CharField(max_length=1024)
    date_time = models.DateTimeField('date_time')
    update_time = models.DateTimeField('update_time')

class Relation(models.Model):
    user_name = models.CharField(max_length=50,db_index=True)
    owner_name = models.CharField(max_length=50,db_index=True)
    app_name = models.CharField(max_length=1024)
    status = models.IntegerField(default=0)
    algin_odps_table = models.CharField(max_length=1024,null=True)
    ots_table = models.CharField(max_length=1024,null=True)
    ots_priviliege = models.IntegerField(default=0)
    odps_priviliege = models.IntegerField(default=0)
    update_time = models.DateTimeField('update_time')

class AllowOnlineTable(models.Model):
    user_name = models.CharField(max_length=1024, db_index=True)
    app_name = models.CharField(max_length=1024)
    status = models.IntegerField(default=0)
    time = models.DateTimeField('request_time')


class ProcessConfTable(models.Model):
    action= models.CharField(max_length=1024)
    conf_str = models.CharField(max_length=10240)

