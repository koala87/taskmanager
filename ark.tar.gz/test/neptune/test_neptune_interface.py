﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: ronghang.rh(hang.rong@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import json
import datetime
import copy
import random

import django.test
import neptune.models
import common.models
import dms.models

import exceptions
import neptune_interface
import neptune_manager
import pipeline_process
import neptune_odps_processs
import neptune_ots_process
import django.contrib.auth.models
from horae import common_logger
from  common.models import Message
#import horae.common_logger


class TestNeptuneInterface(django.test.TestCase):
    """
        测试neptune接口
    """

    def setUp(self):
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        self.__neptune_logger = common_logger.get_logger(
                "common", 
                "./log/neptune")
        self.__neptune_interface = neptune_interface.NeptuneInterface(
                self.__neptune_logger)
        self.__neptune_mgr = neptune_manager.NeptuneManager(self.__neptune_logger)
        self.__p = pipeline_process.PipelineProcess('xiangyu.liu', 'ting0310', '10.181.204.100', '9999', self.__neptune_logger)
        cmd_path = "/home/xiangyu.liu/xiangyu.liuxy/scripts/odps/bin/odpscmd"
        user = "JEtRWGlRrEPkqNpw"
        pwd = "NzrPjfMseoTJ4UoZKw5858aRtUcNk9"
        project = "aliyun_searchlog"
        endpoint = "http://service.odps.aliyun-inc.com/api"
        timeout = 3600
        self.__odps = neptune_odps_processs.OdpsProcessor(cmd_path, user, pwd, project, endpoint, timeout, self.__neptune_logger)

        ots_console_path = '/home/xiangyu.liu/xiangyu.liuxy/dev/dev/ots_console'
        ots_endpoint = "http://sm-searchlog.ali-cn-shanghai.ots.aliyuncs.com"
        ots_access_id = "H8Dbi0rvLOPEJxSz"
        ots_access_secret = "WGHiplLIReH33RskKXFQuvginTka46"
        instance = "sm-searchlog"
        self.ots_processor = neptune_ots_process.OtsProccessor(ots_console_path, ots_endpoint, ots_access_id, ots_access_secret, instance, self.__neptune_logger)




        #auth.models
        django.contrib.auth.models.User.objects.create(
                id=300,
                password="ting0310",
                last_login="2015-09-29 15:47:00",
                is_superuser = 1,
                username="xiangyu.liu",
                first_name = "xiangyu",
                last_name = "liu",
                email = "xiangyu.liu@alibaba-inc.com",
                is_staff = 0,
                is_active = 1,
                date_joined = "2015-09-29 15:47:00"
                )
         
        django.contrib.auth.models.User.objects.create(
                id=301,
                password="ting0310",
                last_login="2015-09-29 15:47:00",
                is_superuser = 1,
                username="zhiting.xie",
                first_name = "zhiting",
                last_name = "xie",
                email = "xiangyu.liu@alibaba-inc.com",
                is_staff = 0,
                is_active = 1,
                date_joined = "2015-09-29 15:47:00"
                )

        django.contrib.auth.models.User.objects.create(
                id=303,
                password="ting0310",
                last_login="2015-09-29 15:47:00",
                is_superuser = 1,
                username="test_user1",
                first_name = "zhiting",
                last_name = "xie",
                email = "xiangyu.liu@alibaba-inc.com",
                is_staff = 0,
                is_active = 1,
                date_joined = "2015-09-29 15:47:00"
                )
        
        django.contrib.auth.models.User.objects.create(
                id=304,
                password="ting0310",
                last_login="2015-09-29 15:47:00",
                is_superuser = 1,
                username="test_user2",
                first_name = "zhiting",
                last_name = "xie",
                email = "xiangyu.liu@alibaba-inc.com",
                is_staff = 0,
                is_active = 1,
                date_joined = "2015-09-29 15:47:00"
                )

        #tagconf
        neptune.models.TagConf.objects.create(
                id=101,
                data_type=0,
                user_name='xiangyu.liu',
                app_name='neptune_app',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time='2015-09-29 15:47:00',
                protect_level=0,
                version='1.0',
                status=2,
                schema_file='pangu://test',
                description='test1这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table',
                ots_table='test_ots_table',
                pipeline_name='user_tag_platform_processor_test',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')
        
        neptune.models.TagConf.objects.create(
                id=103,
                data_type=0,
                user_name='xiangyu.liu',
                app_name='neptune_app3',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time='2015-09-29 15:47:00',
                protect_level=0,
                version='1.0',
                status=2,
                schema_file='pangu://test',
                description='test1这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table2',
                ots_table='test_ots_table2',
                pipeline_name='user_tag_platform_processor_test2',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')
        
        neptune.models.TagConf.objects.create(
                id=104,
                data_type=0,
                user_name='zhiting.xiezt',
                app_name='neptune_app5',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time='2015-09-29 15:47:00',
                protect_level=0,
                version='1.0',
                status=0,
                schema_file='pangu://test',
                description='test1这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table2',
                ots_table='test_ots_table2',
                pipeline_name='user_tag_platform_processor_test2',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')
        
        neptune.models.TagConf.objects.create(
                id=105,
                data_type=0,
                user_name='zhiting.xiezt',
                app_name='neptune_app6',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time='2015-09-29 15:47:00',
                protect_level=0,
                version='1.0',
                status=1,
                schema_file='pangu://test',
                description='test1这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table2',
                ots_table='test_ots_table2',
                pipeline_name='user_tag_platform_processor_test2',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')
        
        neptune.models.TagConf.objects.create(
                id=106,
                data_type=0,
                user_name='zhiting.xiezt',
                app_name='neptune_app7',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time='2015-09-29 15:47:00',
                protect_level=0,
                version='1.0',
                status=2,
                schema_file='pangu://test',
                description='test1这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table2',
                ots_table='test_ots_table2',
                pipeline_name='user_tag_platform_processor_test2',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')
        
        neptune.models.TagConf.objects.create(
                id=107,
                data_type=0,
                user_name='zhiting.xiezt',
                app_name='neptune_app8',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time='2015-09-29 15:47:00',
                protect_level=0,
                version='1.0',
                status=3,
                schema_file='pangu://test',
                description='test1这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table2',
                ots_table='test_ots_table2',
                pipeline_name='user_tag_platform_processor_test2',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')
        
        conf_parse =''' 
        {"schema_file": "", 
        "test_time": "201510201655", 
        "app_name": "\u6570\u636e\u540d\u79f0", 
        "description": "\u63cf\u8ff0",
         "crontab_conf": "* * * * *", 
         "update_cycle": "0",
         "overtime": "300", 
         "category_type": "\u57fa\u672c\u5c5e\u6027", 
         "version": "1",
         "user_name": "zhiting.xie",
         "protect_level": "1",
        "data_config":{
                "data_source":"odps",
                "pu_path":"",
                "sep":"", 
                "project":"aliyun_searchlog",
                "table":"ark_dev_global_003",
                "partition":"day=%year%%month%%day%@-1day",
                "columns":[["0", "snid", "uid"],["1", "base_column", "tag"]]
                }
        }'''
        d_c = {}
        d_c['conf_str'] = conf_parse

        #ProcessConfTable
        #neptune.models.ProcessConfTable.objects.create(
        #        id = 1,
        #        action = 'create',
        #        conf_str = json.dumps(d_c))
        #
        #neptune.models.ProcessConfTable.objects.create(
        #        id = 2,
        #        action = 'recreate',
        #        conf_str = json.dumps(d_c))
        # 
        #d_d = {'user_name':"zhiting.xie", 'app_name':"\u6570\u636e\u540d\u79f0"}

        #neptune.models.ProcessConfTable.objects.create(
        #        id = 3,
        #        action = 'delete',
        #        conf_str = json.dumps(d_d))



        neptune.models.TagConf.objects.create(
                id=1,
                data_type=0,
                user_name='rongh',
                app_name='test_app1',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time='2015-09-29 15:47:00',
                protect_level=0,
                version='1.0',
                status=2,
                schema_file='pangu://test',
                description='test1这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table',
                ots_table='test_ots_table',
                pipeline_name='pipe_test',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')

        neptune.models.TagConf.objects.create(
                id=4,
                data_type=0,
                user_name='rongh',
                app_name='test_app4',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time="2015-09-29 15:47:00",
                protect_level=0,
                version='1.0',
                status=3,
                schema_file='pangu://test4',
                description='test4这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table',
                ots_table='test_ots_table',
                pipeline_name='pipe_test',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-18 09:00:00')


        neptune.models.TagConf.objects.create(
                id=2,
                data_type=0,
                user_name='jianf',
                app_name='test_app2',
                category_type='app',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time="2015-09-29 15:47:00",
                protect_level=0,
                version='1.0',
                status=2,
                schema_file='pangu://test',
                description='test2这是描述',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table',
                ots_table='test_ots_table',
                pipeline_name='pipe_test',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')

        neptune.models.TagConf.objects.create(
                id=3,
                data_type=0,
                user_name='xiangyu',
                app_name='test_app3',
                category_type='app2',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time="2015-09-29 15:47:00",
                protect_level=0,
                version='1.0',
                status=2,
                schema_file='pangu://test',
                description='',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table',
                ots_table='test_ots_table',
                pipeline_name='pipe_test',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')

        #Statistic
        neptune.models.Statistic.objects.create(
                id=1,
                user_name="rongh", 
                app_name ="test_app1",
                uv=450,
                data_size = 500,
                category_type="category_type1,category_type2",
                date_time='2015-08-24 09:00:00',
                update_time='2015-08-27 10:00:00')

        neptune.models.Statistic.objects.create(
                id=2,
                user_name="rongh", 
                app_name ="test_app2",
                uv=350,
                data_size = 650,
                category_type="category_type3,category_type4",
                date_time='2015-08-29 09:00:00',
                update_time='2015-09-01 10:00:00')

        neptune.models.Statistic.objects.create(
                id=3,
                user_name="rongh", 
                app_name ="test_app3",
                uv=250,
                data_size = 150,
                category_type="category_type5,category_type6",
                date_time='2015-08-29 09:00:00',
                update_time='2015-09-01 10:00:00')

        #relation
        neptune.models.Relation.objects.create(
                id=100,
                user_name = 'xiangyu.liu',
                owner_name = 'xiangyu.liu',
                app_name = 'neptune_app',
                status = 3,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
        neptune.models.Relation.objects.create(
                id=101,
                user_name = 'rongh',
                owner_name = 'xiangyu.liu',
                app_name = 'neptune_app',
                status = 2,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
        neptune.models.Relation.objects.create(
                id=102,
                user_name = 'rongh1',
                owner_name = 'xiangyu.liu',
                app_name = 'neptune_app',
                status = 2,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
        neptune.models.Relation.objects.create(
                id=1,
                user_name = 'rongh',
                owner_name = 'rongh',
                app_name = 'test_app1',
                status = 3,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
                
        neptune.models.Relation.objects.create(
                id=2,
                user_name = 'jianf',
                owner_name = 'rongh',
                app_name = 'test_app1',
                status = 2,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 0,
                odps_priviliege = 0,
                update_time='2015-09-01 10:00:00')


        neptune.models.Relation.objects.create(
                id=5,
                user_name = 'wei.guow1',
                owner_name = 'rongh',
                app_name = 'test_app1',
                status = 1,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 0,
                odps_priviliege = 0,
                update_time='2015-09-01 10:00:00')


        neptune.models.Relation.objects.create(
                id=3,
                user_name = 'jianf',
                owner_name = 'rongh',
                app_name = 'test_app3',
                status = 2,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table2',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')

        neptune.models.Relation.objects.create(
                id=4,
                user_name = 'xiangyu.liu',
                owner_name = 'rongh',
                app_name = 'test_app1',
                status = 2,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table2',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
        
        neptune.models.Relation.objects.create(
                id=105,
                user_name = 'as',
                owner_name = 'xiangyu.liu',
                app_name = 'neptune_app3',
                status = 2,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
 
        neptune.models.Relation.objects.create(
                id=106,
                user_name = 'ad',
                owner_name = 'xiangyu.liu',
                app_name = 'neptune_app3',
                status = 1,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
        
        neptune.models.Relation.objects.create(
                id=107,
                user_name = 'zhiting.xiezt',
                owner_name = 'zhiting.xiezt',
                app_name = 'test_pub_count',
                status = 3,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
        
        neptune.models.Relation.objects.create(
                id=108,
                user_name = 'zhiting.xiezt',
                owner_name = 'zhiting.xiezt',
                app_name = 'test_pub_count2',
                status = 3,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')
        
        neptune.models.Relation.objects.create(
                id=109,
                user_name = 'zhiting.xiezt',
                owner_name = 'zhiting.xie',
                app_name = 'neptune_app3',
                status = 2,
                algin_odps_table = 'odps_table1',
                ots_table = 'ots_table1',
                ots_priviliege = 1,
                odps_priviliege = 1,
                update_time='2015-09-01 10:00:00')

    
    def test_message_sender(self):
        lxy_id = self.__neptune_mgr.get_user_obj("xiangyu.liu").id
        print "lxy_id=%s" % lxy_id
        xzt_id = self.__neptune_mgr.get_user_obj("zhiting.xie").id
        print "xzt_id=%s" % xzt_id
        self.__neptune_mgr.send_msg("xiangyu.liu", "zhiting.xie", 6, "I love you")
        self.__neptune_mgr.send_msg("zhiting.xie", "xiangyu.liu", 7, "me too")
        msg_obj = common.models.Message.objects.get(receiver_id = lxy_id)
        print "msg: %s" % msg_obj.content
        msg_obj = common.models.Message.objects.get(receiver_id = xzt_id)
        print "msg: %s" % msg_obj.content

    def test_user_contact_info(self):
        #print self.__neptune_interface.get_user_contact_info("xiangyu.liu")
        pass

    def test_get_appplied_users(self):
        #print self.__neptune_interface.get_all_applied_users('rongh', 'test_app1')
        pass
    
    def test_get_authorited_users(self):
        #print self.__neptune_interface.get_authorited_users("rongh", "test_app1")
        pass

    def test_except_users(self):
        #print self.__neptune_interface.get_except_users("rongh", "test_app1")
        pass

    def test_get_user_id(self):
        #print self.__neptune_mgr.get_user_id("xiangyu.liu")
        pass
    
    def test_owner_data_operate(self):
        #print self.__neptune_mgr.owner_data_operate('neptune_app', "xiangyu.liu", 0, '201509292200')
        l = neptune.models.Relation.objects.filter(owner_name='xiangyu.liu', app_name = 'neptune_app')
        tagConf = neptune.models.TagConf.objects.get(user_name='xiangyu.liu', app_name = 'neptune_app')
        print "status=%s" %  tagConf.status
        print "list len=%s" % len(l)
        print self.__neptune_mgr.owner_data_operate('neptune_app', "xiangyu.liu", 1, '')
        l = neptune.models.Relation.objects.filter(owner_name='xiangyu.liu', app_name = 'neptune_app');
        print "list len=%s" % len(l)
        tagConf = neptune.models.TagConf.objects.get(user_name='xiangyu.liu', app_name = 'neptune_app')
        print "status=%s" % tagConf.status
        pass
        
    def test_online_apply(self):
        neptune.models.TagConf.objects.create(
                id=31,
                data_type=0,
                user_name='test_user_name',
                app_name='test_app_name',
                category_type='app2',
                update_cycle=0,
                crontab_conf='',
                overtime=10,
                test_time="2015-09-29 15:47:00",
                protect_level=0,
                version='1.0',
                status=2,
                schema_file='pangu://test',
                description='',
                data_config='',
                raw_odps_table='',
                algin_odps_table='test_odps_table',
                ots_table='test_ots_table',
                pipeline_name='pipe_test',
                create_time='2015-08-24 09:00:00',
                update_time='2015-09-09 09:00:00')

        self.assertEqual(self.__neptune_interface.online_apply(
                "test_user_name", 
                "test_app_name"), """{"status": 0, "info": "OK!"}""")
        online_info = neptune.models.AllowOnlineTable.objects.get(
                user_name='test_user_name', 
                app_name='test_app_name')

        print(self.__neptune_interface.get_all_online_infos())
        self.assertEqual(self.__neptune_interface.confirm_apply(
                "test_user_name", 
                "test_app_name"), """{"status": 0, "info": "OK!"}""")
        self.assertEqual(self.__neptune_interface.online_apply(
                "test_user_name", 
                "test_app_name"), """{"status": 0, "info": "OK!"}""")
        self.assertEqual(self.__neptune_interface.reject_apply(
                "test_user_name", 
                "test_app_name"), """{"status": 0, "info": "OK!"}""")

    #def test_delete_user_app(self):
    #    print "delete user app -----------------------"
    #    #chuangjian pipeline
    #    print "create pipe"
    #    print self.__p.create_pipeline('user_tag_platform_processor_test2', '1 2 * * *', 0)
    #    #check pipeline
    #    print "check pipeline"
    #    print self.__p.check_pipeline('user_tag_platform_processor_test2')
    #    #chuangjian odps table
    #    print "create odps"
    #    print self.__odps.create_table("test_odps_table2", [("sm_id", "string"), ("data_str", "string")] , [("day", "string"), ("hour", "string")] )
    #    #chuangjian ots table
    #    print "create ots"
    #    print self.ots_processor.create_ots_table("test_ots_table2", [("primary_key", "STRING")])
    #    #check tag conf
    #    l = neptune.models.TagConf.objects.filter(user_name='xiangyu.liu', app_name = 'neptune_app3');
    #    print "conf list len=%s" % len(l)
    #    #check relation
    #    l = neptune.models.Relation.objects.filter(owner_name='xiangyu.liu', app_name = 'neptune_app3');
    #    print "relation list len=%s" % len(l)
    #    #test delete
    #    print "delete"
    #    print self.__neptune_interface.delete_user_app('xiangyu.liu', 'neptune_app3')
    #    #check pipeline
    #    print "check pipeline"
    #    print self.__p.check_pipeline('user_tag_platform_processor_test2')
    #    #check tag conf
    #    l = neptune.models.TagConf.objects.filter(user_name='xiangyu.liu', app_name = 'neptune_app3');
    #    print "conf list len=%s" % len(l)
    #    #check relation
    #    l = neptune.models.Relation.objects.filter(owner_name='xiangyu.liu', app_name = 'neptune_app3');
    #    print "relation list len=%s" % len(l)
    #    print "delete user app -----------------------



    def test_run_create_pipeline(self):
        conf_parse = """
        {"schema_file": "", 
        "test_time": "201510201655", 
        "app_name": "neptune_first", 
        "description": "for a real test",
         "crontab_conf": "30 8 * * *", 
         "update_cycle": "0",
         "overtime": "300", 
         "category_type": "标签数据", 
         "version": "1",
         "user_name": "xiangyu.liu",
         "protect_level": "1",
        "data_config":{
                "data_source":"odps",
                "pu_path":"",
                "sep":"", 
                "project":"aliyun_searchlog",
                "table":"ark_dev_global_003",
                "partition":"day=%year%%month%%d%@-1day",
                "columns":[["0", "snid", "uid"],["1", "base_column", "tag"]]
                }
        }"""
        conf_dict =  self.__neptune_mgr.parse_user_conf(conf_parse)
        d =  self.__neptune_mgr.generate_all_fileds(conf_dict)
        print self.__p.delete_pipeline(d['pipeline_name'])
        print "dumps:%s" % json.dumps(d)
        print "create:%s" % self.__neptune_mgr.create_user_app(conf_parse)
        print self.__neptune_mgr.process_all_user_app_action()
        print 'pipeline name:%s' % d['pipeline_name']
        print 'run:%s, %s' % self.__p.run_pipe(d['pipeline_name'], '201510240830')
        print "delete:%s" % self.__neptune_mgr.delete_user_app('xiangyu.liu', 'neptune_first')
        print self.__neptune_mgr.process_all_user_app_action()

    def test_run_pu(self):
        conf_parse = """
        {"schema_file": "", 
        "test_time": "201510201655", 
        "app_name": "auto_tag", 
        "description": "for a real test",
         "crontab_conf": "30 8 * * *", 
         "update_cycle": "0",
         "overtime": "300", 
         "category_type": "通用标签数据", 
         "version": "1",
         "user_name": "xiangyu.liu",
         "protect_level": "1",
        "data_config":{
                "data_source":"pangu",
                "pu_path":" pangu://AY54/sm_user_profile/final_user_tag/%year%%month%%d%/auto_processor/@-1day",
                "sep":"\\t", 
                "project":"",
                "pu_file_num":"2048",
                "table":"",
                "partition":"",
                "columns":[["0", "snid", "uid"],["1", "base_column", "tag"]]
                }
        }"""
        conf_dict =  self.__neptune_mgr.parse_user_conf(conf_parse)
        d =  self.__neptune_mgr.generate_all_fileds(conf_dict)
        print self.__p.stop_pipe(d['pipeline_name'])
        print self.__p.delete_pipeline(d['pipeline_name'])
        print "dumps:%s" % json.dumps(d)
        print "create:%s" % self.__neptune_mgr.create_user_app(conf_parse)
        print self.__neptune_mgr.process_all_user_app_action()
        print 'pipeline name:%s' % d['pipeline_name']
        print 'run:%s, %s' % self.__p.run_pipe(d['pipeline_name'], '201510270830')
        print "delete:%s" % self.__neptune_mgr.delete_user_app('xiangyu.liu', 'auto_tag')
        print self.__neptune_mgr.process_all_user_app_action()




    
    def test_parse_user_conf(self):
        conf_parse = """
        {"schema_file": "", 
        "test_time": "201510201655", 
        "app_name": "test app", 
        "description": "\u63cf\u8ff0",
         "crontab_conf": "* * * * *", 
         "update_cycle": "0",
         "overtime": "300", 
         "category_type": "\u57fa\u672c\u5c5e\u6027", 
         "version": "1",
         "user_name": "zhiting.xie",
         "protect_level": "1",
        "data_config":{
                "data_source":"odps",
                "pu_path":"",
                "sep":"", 
                "project":"aliyun_searchlog",
                "table":"ark_dev_global_003",
                "partition":'day=%year%%month%%day%@-1day',
                "columns":[["0", "snid", "uid"],["1", "base_column", "tag"]]
                }
        }"""
        conf_dict =  self.__neptune_mgr.parse_user_conf(conf_parse)
        d =  self.__neptune_mgr.generate_all_fileds(conf_dict)
        print json.dumps(d)
        print "create:%s" % self.__neptune_mgr.create_user_app(conf_parse)
        print "recreate:%s" % self.__neptune_mgr.recreate_user_app(conf_parse)
        print self.__neptune_mgr.process_all_user_app_action()
        print "delete:%s" % self.__neptune_mgr.delete_user_app('zhiting.xie', 'test app')
        obj = neptune.models.TagConf.objects.get(user_name='zhiting.xie', app_name = 'test app')
        print "after delete status=%s" % obj.status
        print self.__neptune_mgr.process_all_user_app_action()
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "check_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "create_odps_part")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "import_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "statistic_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "aligment_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "dump_to_ots_task")
        r_l = neptune.models.Relation.objects.filter(owner_name='zhiting.xie')
        for l in r_l:
            print "%s, %s, %s, , %s, %s, %s, %s, %s, %s" % (l.user_name, l.owner_name, l.app_name, l.status, l.algin_odps_table, l.ots_table, l.ots_priviliege, l.odps_priviliege, l.update_time)
        r_l =  neptune.models.AllowOnlineTable.objects.filter(user_name = 'zhiting.xie')
        for l in r_l:
            print "online:%s %s %s %s" % (l.user_name, l.app_name, l.status, l.time)
        msg_obj_list = common.models.Message.objects.filter(receiver_id = 301)
        for obj in msg_obj_list:
            print "--------msg:%s" % obj.content
        print "stop:%s, %s" %  self.__p.stop_pipe(d["pipeline_name"])
        print self.__p.delete_pipeline(d["pipeline_name"])
        print "delete table %s" % d['odps_raw_table_name']
        print  self.__odps.drop_table(d['odps_raw_table_name'])
        print "delete table %s" % d['odps_aligne_table_name']
        print  self.__odps.drop_table(d['odps_aligne_table_name'])
        print "delete table %s" % d['ots_table_name']
        print  self.ots_processor.delete_ots_table(d['ots_table_name'])

    def test_user_conf_str_transform(self):
        raw_str = """
        {"schema_file": "", 
        "test_time": "201510201655", 
        "app_name": "test app", 
        "description": "\u63cf\u8ff0",
         "crontab_conf": "1 1 * * *", 
         "update_cycle": "0",
         "overtime": "300", 
         "category_type": "\u57fa\u672c\u5c5e\u6027", 
         "version": "1",
         "user_name": "zhiting.xie",
         "protect_level": "1",
        "data_config":{
                "data_source":"odps",
                "pu_path":"",
                "sep":"", 
                "project":"aliyun_searchlog",
                "table":"ark_dev_global_003",
                "partition":"day=%year%%month%%day%@-1day",
                "columns":[["0", "snid", "uid"],["1", "base_column", "tag"]]
                }
        }"""
        conf_str = json.dumps(json.loads(raw_str))
        self.__neptune_mgr.save_user_app_conf(conf_str)
        obj = neptune.models.TagConf.objects.get(user_name='zhiting.xie')
        result_str = self.__neptune_mgr.trans_tagconf_obj_to_conf_str(obj)
        self.assertTrue(conf_str == result_str)
        print self.__neptune_mgr.apply_public_operation("zhiting.xie",  "test app")
        print self.__neptune_mgr.process_all_user_app_action()
        conf_dict =  self.__neptune_mgr.parse_user_conf(conf_str)
        d =  self.__neptune_mgr.generate_all_fileds(conf_dict)
        print json.dumps(d)
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "check_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "create_odps_part")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "import_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "statistic_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "aligment_task")
        print self.__p.get_pipeline_task_info(d["pipeline_name"], "dump_to_ots_task")
        r_l = neptune.models.Relation.objects.filter(owner_name='zhiting.xie')
        for l in r_l:
            print "%s, %s, %s, , %s, %s, %s, %s, %s, %s" % (l.user_name, l.owner_name, l.app_name, l.status, l.algin_odps_table, l.ots_table, l.ots_priviliege, l.odps_priviliege, l.update_time)
        r_l =  neptune.models.AllowOnlineTable.objects.filter(user_name = 'zhiting.xie')
        for l in r_l:
            print "online:%s %s %s %s" % (l.user_name, l.app_name, l.status, l.time)
        msg_obj_list = common.models.Message.objects.filter(receiver_id = 301)
        for obj in msg_obj_list:
            print "--------msg:%s" % obj.content
        print self.__p.stop_pipe(d['pipeline_name'])
        print self.__p.delete_pipeline(d["pipeline_name"])
        print "delete table %s" % d['odps_raw_table_name']
        print  self.__odps.drop_table(d['odps_raw_table_name'])
        print "delete table %s" % d['odps_aligne_table_name']
        print  self.__odps.drop_table(d['odps_aligne_table_name'])
        print "delete table %s" % d['ots_table_name']
        print  self.ots_processor.delete_ots_table(d['ots_table_name'])


    def test_get_user_public_and_buy_data_count(self):
        user_name = "zhiting.xiezt"
        print self.__neptune_interface.get_user_public_and_buy_data_count("zhiting.xiezt")
        print self.__neptune_interface.get_user_public_and_buy_data_count("zhiting.xie")

    def test_get_all_user_process_data_count(self):
        user_name = 'zhiting.xiezt'
        print self.__neptune_interface.get_all_user_process_data_count(user_name)

    def test_create_tagconf_auth_send_msg(self):
        lxy_id = self.__neptune_mgr.get_user_obj("xiangyu.liu").id
        print "lxy_id=%s" % lxy_id
        xzt_id = self.__neptune_mgr.get_user_obj("zhiting.xie").id
        print "xzt_id=%s" % xzt_id
        self.__neptune_mgr.create_tagconf_auth_send_msg("xiangyu.liu", "zhiting.xie", "data_1")
        self.__neptune_mgr.create_tagconf_auth_send_msg("zhiting.xie", "xiangyu.liu", "data_2")
        msg_list = common.models.Message.objects.filter(receiver_id = lxy_id)
        for obj in msg_list:
            print "%s\t%s\t%s\t%s" % (obj.sender, obj.receiver, obj.content, obj.create_time)

        self.__neptune_mgr.grant_tagconf_auth_send_msg(["test_user1", "test_user2"], "zhiting.xie", "data_3");
        self.__neptune_mgr.apply_tagconf_auth_send_msg("test_user1", "test_user2", "data_4")
        self.__neptune_mgr.confirm_tagconf_auth_send_msg("test_user1", "test_user2", "data_5")
        self.__neptune_mgr.reject_tagconf_auth_send_msg("test_user2", "test_user1", "data_6")
        self.__neptune_mgr.take_back_tagconf_auth_send_msg("test_user2", "test_user1", "data_6")
        test_id1 = self.__neptune_mgr.get_user_obj("test_user1").id
        msg_list = common.models.Message.objects.filter(receiver_id = test_id1)
        for obj in msg_list:
            print "%s\t%s\t%s\t%s" % (obj.sender, obj.receiver, obj.content, obj.create_time)
        test_id2 = self.__neptune_mgr.get_user_obj("test_user2").id
        msg_list = common.models.Message.objects.filter(receiver_id = test_id2)
        for obj in msg_list:
            print "%s\t%s\t%s\t%s" % (obj.sender, obj.receiver, obj.content, obj.create_time)
        msg_list = common.models.Message.objects.filter(receiver_id = xzt_id)
        for obj in msg_list:
            print "%s\t%s\t%s\t%s" % (obj.sender, obj.receiver, obj.content, obj.create_time)






       

    #def test_publish_tagconf_history(self):
    #    self.assertEqual(
    #            self.__neptune_interface.publish_tagconf_history(
    #                owner_name = "'rongh'",
    #                page_min = 0,
    #                page_max = 20),
    #                '''"status": 0, "info": "OK"}'''
    #            )
    #    
    #def test_insert_data_statistic_info(self):
    #    self.assertEqual(
    #            self.__neptune_interface.insert_data_statistic_info(
    #                user_name = 'rongh',
    #                app_name = 'app5',
    #                category_type="category_type5",
    #                uv=250,
    #                data_size = 150,
    #                date_time='2015-08-29 09:00:00'),
    #            '''{"status": 0, "info": "OK"}'''
    #            )














