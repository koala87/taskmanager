#coding=utf-8
import logging
import sys
sys.setrecursionlimit(10000)
import os
import json
import time
import random
import hashlib  
import no_block_sys_cmd
import urllib2
from urllib import quote
from django.contrib.auth import authenticate
from django.conf import settings
from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core import serializers
from common.http_helper import *
from common.odps import Odps
from common.odps import OdpsPrivilege
from common.models import PermHistory,Message
from common.convert_time import *
from common.models import PermHistory
from common.ark_perm import UserPerm
from ark_user.models import Info
from dms.models import Config

from neptune_interface import *
#from tools_util import StaticFunction
from models import *
#from horae_interface import *
from horae import common_logger

UPLOAD_FILES_PATH = 'neptune_upload_files/file/'

# Create your views here.
#logger = logging.getLogger(settings.PROJECT_NAME)
neptune_interface = NeptuneInterface()

__log = common_logger.get_logger(
        "xlin_log",
        "./log/xlin_log")
__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand(__log)

login_url='/neptune/tag_login/'
def tag_login(request):
    return render(request,'neptune_login.html',{'page_title':'登录页'});

def tag_introduction(request):
    #res = neptune_interface.test_ots();
    #return
    user = request.user
    is_super = is_super_user(user) 
    
    return render(request,'neptune_index.html',{'user': user.username,'page_index':1,
            'is_super':is_super,
            'page_title':'首页'})

@login_required(login_url=login_url)
def tag_index(request):
    user = request.user
    is_super = is_super_user(user)

    return render(request,'neptune_tag.html',{'user': user.username,'page_index':2,
            'is_super':is_super,
            'page_title':'标签市场'})

#标签页列表
def tag_list(request):
    
    user = request.user
    category_type, sort_key, sort_type, tag_name,  index_min, index_max = list_query(request)
    search_map = {}
    search_map["app_name"]=tag_name.strip()
    if category_type != None:
        search_map["category_type"]=category_type
    data = neptune_interface.show_tagconf_info(user.username, index_min, index_max, sort_key, sort_type, search_map)
    data = json.loads(data)
    data['index_min'] = index_min
    data['index_max'] = index_max
    return HttpResponse(
            json.dumps(data), content_type='application/json')

def list_query(request):
    condition = {}
    category_type = request.POST.get('category_type')
    sort_type = request.POST.get('sort_type', '4')
    if sort_type == '1':
        sort_key = 'publication_time'
        sort_type = 'desc'
    if sort_type == '2':
        sort_key = 'publication_time'
        sort_type = 'asc'
    if sort_type == '3':
        sort_key = 'update_time'
        sort_type = 'asc'
    if sort_type == '4':
        sort_key = 'update_time'
        sort_type = 'desc'
    if sort_type == '5':
        sort_key = 'use_count'
        sort_type = 'asc'
    if sort_type == '6':
        sort_key = 'use_count'
        sort_type = 'desc'
    tag_name = request.POST.get('tag_name')
    page = request.POST.get('page')
    page_size = request.POST.get('page_size')
    if page == '':
        page = 1
    if page_size == '':
        page_size = 6
    page = int(page);
    page_size = int(page_size);
    index_min = page_size*(page-1)+1
    index_max = page_size*page
    
    return category_type, sort_key, sort_type, tag_name,  index_min, index_max

def tag_rank_num(request):
#    data = '{["tag_name":"name1", "num":100000]}'
#    data = json.loads(data)
    data = neptune_interface.label_use_ranking()
    return HttpResponse(
            data, content_type='application/json')

def tag_rank_pub(request):
    data = neptune_interface.latest_publish_ranking()
    return HttpResponse(
            data, content_type='application/json')
#    data = '{["tag_name":"name1", "productor":"somebody"]}'
#    data = json.loads(data)
#    return HttpResponse(
#            '{"status":0,"data":[{"tag_name":"name1","productor":"somebody1"},{"tag_name":"name2","productor":"somebody2"}]}', content_type='application/json')

def is_super_user(user):
    is_super = 0
    if user.is_superuser == 1:
        is_super = 1
    else:
        is_super = 0
    return is_super

#def tag_category(request):
##    data = '{["tag_name":"name1", "productor":"somebody"]}'
##    data = json.loads(data)
#    return HttpResponse(
#            '{"status":0,"data":[{"tag_cate_name":"name1","category_id":1},{"tag_cate_name":"name2","category_id":2},{"tag_cate_name":"name3","category_id":3},{"tag_cate_name":"name4","category_id":4},{"tag_name":"name5","productor":"somebody5"},{"tag_name":"name6","productor":"somebody6"}]}', content_type='application/json')

@login_required(login_url=login_url)
def tag_person(request):
    user = request.user
    is_super = is_super_user(user)
    tag_name = request.GET.get('tag_name')
    owner_name = request.GET.get('owner_name')
    tag_info = neptune_interface.get_tagconf_info(owner_name, tag_name)
    __log.info("tag_info"+tag_info)
    tag_info = json.loads(tag_info)
    tag_info['tagconf']['data_config'] = json.loads(tag_info['tagconf']['data_config'])
    tag_info['tagconf']['crontab_conf_display'] = ''
    cron_conf_list = tag_info['tagconf']['crontab_conf'].split()
    if type(cron_conf_list[1]) == type(1):
        tag_info['tagconf']['crontab_conf_display'] = "每小时"+cron_conf_list[0]+"分"
    else:
        tag_info['tagconf']['crontab_conf_display'] = "每天"+cron_conf_list[1]+"时"+cron_conf_list[0]+"分"

    auth_info = neptune_interface.get_user_tagconf_auth(user.username, tag_info['tagconf']['user_name'], tag_name)
    __log.info("auth_info"+auth_info)
    auth_info = json.loads(auth_info)
    
    owner_contact = neptune_interface.get_user_contact_info(tag_info['tagconf']['user_name'])
    category_map = ['未知', '人群自然属性', '搜索兴趣偏好', '购物人群偏好', '阅读兴趣偏好', 'LBS兴趣偏好', '未知', '视频兴趣偏好']
    category_val = tag_info['tagconf']['category_type']
    __log.info(category_val)
    tag_info['tagconf']['overtime']  = tag_info['tagconf']['overtime']/60;
    return render(request,'neptune_person_tag.html',{'user': user.username,'owner_contact':owner_contact,'page_index':2,
            'is_super':is_super, 'auth_info':auth_info , 'tag_info':tag_info,'category_display':category_map[int(category_val)],
            'page_title':'个人数据详情'})

#用于获取所有申请过owner_name产出的名为 app_name的数据用户
def get_all_applied_users(request):
    user = request.user
    is_super = is_super_user(user)
    owner_name = request.POST.get('owner_name')
    tag_name = request.POST.get('tag_name')
    res = {}
    res['status'] = 0
    res['data'] = neptune_interface.get_all_applied_users(owner_name, tag_name)
    return HttpResponse(json.dumps(res), content_type='application/json')

#用于获取所有已经获取了owner_name产出的名为 app_name的数据用户
def get_authorited_users(request):
    user = request.user
    is_super = is_super_user(user)
    owner_name = request.POST.get('owner_name')
    tag_name = request.POST.get('tag_name')
    res = {}
    res['status'] = 0
    res['data'] = neptune_interface.get_authorited_users(owner_name, tag_name)
    return HttpResponse(json.dumps(res), content_type='application/json')


#所有用户，但是不包括已经申请和授权的用户
def get_except_users(request):
    user = request.user
    is_super = is_super_user(user)
    owner_name = request.POST.get('owner_name')
    tag_name = request.POST.get('tag_name')
    res = {}
    res['status'] = 0
    res['data'] = neptune_interface.get_except_users(owner_name, tag_name)
    return HttpResponse(json.dumps(res), content_type='application/json')


def update_tagconf_info(request):
    user = request.user
    is_super = is_super_user(user)
    tag_id = request.POST.get('tag_id')
    update_map = {
        request.POST.get('update_key'):request.POST.get('update_val')
    }
    res = neptune_interface.update_tagconf_data(tag_id, user.username, update_map)
    return HttpResponse(res, content_type='application/json')

def get_tag_statistic_info(request):
    user = request.user
    is_super = is_super_user(user)
    tag_name = request.POST.get('tag_name')
    time_distance = request.POST.get('time_distance')
    cur_date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
    res = neptune_interface.get_statistic_by_time_distance(user.username, tag_name, cur_date, time_distance)
    return HttpResponse(res, content_type='application/json')

def insert_data_statistic_info(request):
    user_name = request.POST.get('user_name')
    app_name = request.POST.get('app_name')
    category_type = request.POST.get('category_type')
    uv = request.POST.get('uv')
    data_size = request.POST.get('data_size')
    date_time = request.POST.get('date_time')

    ret = neptune_interface.insert_data_statistic_info(
            user_name,
            app_name,
            category_type,
            uv,
            data_size,
            date_time)

    return HttpResponse(ret, content_type='application/json')


def auth_tagconf(request):
    user = request.user
    is_super = is_super_user(user)
    tag_name = request.POST.get('tag_name')
    owner_name = request.POST.get('owner_name')
    user_name = request.POST.get('user_name')
    #op_code具体为：0 添加 1 同意 2 拒绝 3 申请 4 收回 5 添加数据添加权限
    op_code = request.POST.get('op')
    if op_code == '0':
        user_name = [user_name]
    res = neptune_interface.tagconf_auth(user_name, owner_name, tag_name, op_code)
    return HttpResponse(res, content_type='application/json')


@login_required(login_url=login_url)
def tag_mydata(request):
    user = request.user
    is_super = is_super_user(user) 
    count_stat = neptune_interface.get_user_public_and_buy_data_count(user.username)
    count_stat = json.loads(count_stat)
    return render(request,'neptune_mydata.html',{'user': user.username,'page_index':3,
            'is_super':is_super,'count_stat':count_stat,
            'page_title':'我的数据'})

def list_center(request):
    user = request.user
    is_super = is_super_user(user)
    process_status = request.POST.get('status')

    page = request.POST.get('page')
    page_size = request.POST.get('page_size')
    if page == '':
        page = 1
    if page_size == '':
        page_size = 6
    page = int(page);
    page_size = int(page_size);
    index_min = page_size*(page-1)+1
    index_max = page_size*page

    data = neptune_interface.processing_center_info(user.username, int(process_status), index_min, index_max)
    data = json.loads(data)
    data['index_min'] = index_min
    data['index_max'] = index_max
    no=int(index_min)
    for i in range(0, len(data['data_list'])):
        data['data_list'][i]['no'] = no
        no=no+1
    return HttpResponse(
            json.dumps(data), content_type='application/json')

def list_pub_history(request):
    user = request.user
    is_super = is_super_user(user)
    owner_name = request.POST.get('owner_name')

    page = request.POST.get('page')
    page_size = request.POST.get('page_size')
    if page == '':
        page = 1
    if page_size == '':
        page_size = 6
    page = int(page);
    page_size = int(page_size);
    index_min = page_size*(page-1)+1
    index_max = page_size*page

    data = neptune_interface.publish_tagconf_history(owner_name, index_min, index_max)
    data = json.loads(data)
    data['index_min'] = index_min
    data['index_max'] = index_max
    no=int(index_min)
    for i in range(0, len(data['history_list'])):
        data['history_list'][i]['no'] = no
        no=no+1
    return HttpResponse(
            json.dumps(data), content_type='application/json')


def data_operate(request):
    user = request.user
    is_super = is_super_user(user)
    tag_name = request.POST.get('tag_name')
    owner_name = request.POST.get('owner_name')
    rollback_time = request.POST.get('back_time')
    #action取值 0 回滚 1 下线
    action = int(request.POST.get('action'))
    res = neptune_interface.owner_data_operate(tag_name, owner_name, action, rollback_time)
    return HttpResponse(res, content_type='application/json')



def list_mydata(request):
    user = request.user
    is_super = is_super_user(user)
    #2表示订阅，3表示owner数据
    is_owner = request.POST.get('is_owner')
    is_owner = int(is_owner)
    owner_name = request.POST.get('owner_name')

    page = request.POST.get('page')
    page_size = request.POST.get('page_size')
    if page == '':
        page = 1
    if page_size == '':
        page_size = 6
    page = int(page);
    page_size = int(page_size);
    index_min = page_size*(page-1)+1
    index_max = page_size*page

    data = neptune_interface.get_owner_subscribe_data(is_owner, owner_name, index_min, index_max)
    data = json.loads(data)
    data['index_min'] = index_min
    data['index_max'] = index_max
    no=int(index_min)
    for i in range(0, len(data['data_list'])):
        data['data_list'][i]['no'] = no
        no=no+1
    return HttpResponse(
            json.dumps(data), content_type='application/json')

@login_required(login_url=login_url)
def tag_center(request):
    user = request.user
    is_super = is_super_user(user)
    count_stat = neptune_interface.get_all_user_process_data_count(user.username)
    count_stat = json.loads(count_stat)

    return render(request,'neptune_tag_center.html',{'user': user.username,'page_index':4,
            'is_super':is_super,'count_stat':count_stat,
            'page_title':'处理中心'})


def tag_publicate_apply(request):
    user = request.user
    tag_name = request.POST.get('tag_name')
    data = neptune_interface.apply_public_operation(user.username, tag_name)
    return HttpResponse(
            data, content_type='application/json')

def delete_user_tag(request):
    user = request.user
    tag_name = request.POST.get('tag_name')
    data = neptune_interface.delete_user_app(user.username, tag_name)
    return HttpResponse(
            data, content_type='application/json')

@login_required(login_url=login_url)
def tag_norelease(request):
    user = request.user
    is_super = is_super_user(user)

    return render(request,'neptune_norelease.html',{'user': user.username,'page_index':4,
            'is_super':is_super,
            'page_title':'查看数据'})

@login_required(login_url=login_url)
def tag_senddata(request):
    user = request.user
    is_super = is_super_user(user)

    return render(request,'neptune_senddata.html',{'user': user.username,'page_index':4,
            'is_super':is_super,
            'page_title':'发布数据'})



@login_required(login_url=login_url)
def tag_senddata_update(request):
    user = request.user
    is_super = is_super_user(user)

    tag_name = request.GET.get('tag_name')
    owner_name = request.GET.get('owner_name')
    tag_info = neptune_interface.get_tagconf_info(user.username, tag_name)
    __log.info(tag_info)
    tag_info = json.loads(tag_info)
    tag_info['tagconf']['data_config'] = json.loads(tag_info['tagconf']['data_config'])
    tag_info['tagconf']['crontab_conf_hour'] = tag_info['tagconf']['crontab_conf'].split()[1]
    tag_info['tagconf']['crontab_conf_minute'] = tag_info['tagconf']['crontab_conf'].split()[0]
    return render(request,'neptune_senddata_update.html',{'user': user.username,'page_index':4,
            'is_super':is_super,'tag_info':tag_info,
            'page_title':'发布数据'})

def publish_tagconf_data(request):
    user_name           = request.POST.get('user_name')
    app_name            = request.POST.get('app_name')
    category_type       = request.POST.get('category_type')
    update_cycle        = request.POST.get('update_cycle')
    crontab_conf        = request.POST.get('crontab_conf')
    test_time           = request.POST.get('test_time')
    overtime            = request.POST.get('overtime')
    protect_level       = request.POST.get('protect_level')
    version             = request.POST.get('version')
    schema_file         = request.POST.get('uploadfile')
    description         = request.POST.get('description')
    data_config         = request.POST.get('data_config')
    data_config         = json.loads(data_config)

    scheme_file = {'code':1}
    try:
        schema_file = handle_uploaded_file(request.FILES['data_schema'])
        scheme_file = json.loads(schema_file)
        __log.info(schema_file)
    except Exception, ex:
        __log.info("file not uploaded")
    scheme_fileurl = ''
    if scheme_file["code"] == 0:
        scheme_fileurl = scheme_file["msg"]
    else:
        scheme_fileurl = request.POST.get('old_scheme_file_url', '')
    conf_info = {}
    conf_info['user_name'] = user_name
    conf_info['app_name'] = app_name
    conf_info['category_type'] = category_type
    conf_info['update_cycle'] = update_cycle
    conf_info['crontab_conf'] = crontab_conf
    conf_info['test_time'] = test_time
    conf_info['overtime'] = overtime
    conf_info['protect_level'] = protect_level
    conf_info['version'] = version
    conf_info['schema_file'] = scheme_fileurl
    conf_info['description'] = description
    conf_info['data_config'] = data_config
    __log.info(json.dumps(conf_info))
    action = request.POST.get('action')
    if action == '1':
        data = neptune_interface.create_user_app(json.dumps(conf_info))
        __log.info("action:1")
    elif action == '2':
        data = neptune_interface.save_user_app_conf(json.dumps(conf_info))
        __log.info("action:2")
    else:
        data = neptune_interface.recreate_user_app(json.dumps(conf_info))
        __log.info("action:else")
    return HttpResponse(
            data, content_type='application/json')



@login_required(login_url=login_url)
def tag_approval(request):
    user = request.user
    is_super = is_super_user(user)

    return render(request,'neptune_approval.html',{'user': user.username,'page_index':5,
            'is_super':is_super,
            'page_title':'审批'})

def tag_list_approval(request):
    data = neptune_interface.get_all_online_infos()
    return HttpResponse(
            data, content_type='application/json')

def confirm_approval_apply(request):
    user = request.user
    tag_name = request.POST.get('tag_name')
    owner_name = request.POST.get('owner_name')
    data = neptune_interface.confirm_apply(owner_name, tag_name)
    return HttpResponse(
            data, content_type='application/json')

def reject_approval_apply(request):
    user = request.user
    tag_name = request.POST.get('tag_name')
    owner_name = request.POST.get('owner_name')
    data = neptune_interface.reject_apply(owner_name, tag_name)
    return HttpResponse(
            data, content_type='application/json')

@login_required(login_url=login_url)
def tag_approval_data(request):
    user = request.user
    is_super = is_super_user(user)

    tag_name = request.GET.get('tag_name')
    tag_info = neptune_interface.get_tagconf_info(user.username, tag_name)
    tag_info = json.loads(tag_info)
    owner_contact = neptune_interface.get_user_contact_info(tag_info['tagconf']['user_name'])
    return render(request,'neptune_approval_data.html',{'user': user.username,'page_index':5,'owner_contact':owner_contact,
            'is_super':is_super,'tag_info':tag_info,
            'page_title':'审批数据'})

@login_required(login_url=login_url)
def tag_message(request):
    user = request.user
    is_super = is_super_user(user)

    return render(request,'neptune_message.html',{'user': user.username,'page_index':6,
            'is_super':is_super,
            'page_title':'消息中心'})


@login_required(login_url=login_url)
def person_message(request):
    user = request.user
    is_super = is_super_user(user)

    return render(request,'neptune_person_message.html',{'user': user.username,
            'is_super':is_super,
            'page_title':'消息中心'})

#上传文件
def handle_uploaded_file(file):
    try:
        m2 = hashlib.md5()
        m2.update('seed.')
        path = UPLOAD_FILES_PATH + m2.hexdigest() +'/'
        if not os.path.exists(path):
            os.makedirs(path)
        file_name = path + file.name
        file_name_single = file.name
        file_name_single = file_name_single[0:file_name_single.index('.')]
        destination = open(file_name, 'wb+')
        __log.info(file_name)
        for chunk in file.chunks():
            destination.write(chunk)
        destination.close()
        cmd_upload = "curl -F 'uploadfile=@"+file_name+"' -F 'action=upload' -F 'filename="+file_name_single+"' http://boss.m.sm.cn/internalapi/OssFile.php"
        __log.info(cmd_upload)
        stdout, stderr, retcode = __no_block_cmd.run_once(cmd_upload)
        return stdout

    except Exception, e:
        print e
    cmd_del = "rm -rf " + file_name
    __no_block_cmd.run_once(cmd_del)

    __log.info(stdout)
    return stdout


def down_load(request):
    ori_url = request.GET.get('url')
    tmp = ori_url[::-1]
    filename = tmp[0:tmp.index('/')][::-1]
    f = urllib2.urlopen(ori_url)
    data = f.read()
    #response = HttpResponse(data,mimetype='application/octet-stream') 
    response = HttpResponse(data) 
    response['Content-Disposition'] = 'attachment; filename=%s' %filename
    return response
