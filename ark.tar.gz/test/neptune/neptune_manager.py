﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
neptune前端工具接口实现manager

Authors: ronghang.rh(hang.rong@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import json
import time
import logging
import exceptions
import datetime
import md5
import thread
import traceback

import django.db
import neptune.models
import django.db.models
import django.core.exceptions
import enum
import crontab
import ark_tools.settings

from horae import tools_util
from common import message_manager 
from  common.models import Message
import neptune_sql_manager
import neptune.tools_utils
import pipeline_process
import neptune_odps_processs
import neptune_ots_process


CHAR_TRANS_DICT  = {"\x01":"\u0001","\x02":"\u0002","\x03":"\u0003","\x04":"\u0004",\
        "\x05":"\u0005","\x06":"\u0006","\x07":"\u0007","\x08":"\u0008","\x09":"\u0009"}

OTS_PREFIX = "utp_ots_"
ODPS_PREFIX = "utp_odps_"
NOAH_PREFIX = "utp_noah_"
RAW_TABLE_POSTFIX = "_r"
ALIGN_TABLE_POSTFIX = "_a"
OTS_POSTFIX = "_tbl"
PIPELINE_PREFIX = 'usertag_platform_auto_'
PIPELINE_POSTFIX = "_pl"
IDENTIFY_COL = "0"
DATA_COL = 1
DAY_PIPE = 0
USER_TAG_DATA = 0
HIGHE_QUALITY_DATA = 1
HOUR_PIPE = "1" 
STAR_STR = "*"
PANGU_SRC = "pangu"
INNER_PART_NAME = "dt"
ODPS_SRC = "odps"
STRING_TYPE = "string"
SUPER_USER_NAME = 'xiangyu.liu'
UPDATE_SATISTIC_URL = "http://42.120.168.86:9999/neptune/insert_statistic/"

timeformat_transform = lambda input_str : datetime.datetime.strptime(input_str, '%Y%m%d%H%M').strftime("%Y-%m-%d %H:%M:%S")
class NeptuneManager():
    """
        数据标签管理接口实现
    """
    def __init__(self,neptune_logger):
        self.__log = neptune_logger
        self.__sql_manager = neptune_sql_manager.SqlManager(neptune_logger)
        self.__pipeline_processor = pipeline_process.PipelineProcess(SUPER_USER_NAME, "ting0310", "10.181.204.100", "9999", neptune_logger)
        cmd_path = "/home/xiangyu.liu/xiangyu.liuxy/scripts/odps/bin/odpscmd"
        user = "JEtRWGlRrEPkqNpw"
        pwd = "NzrPjfMseoTJ4UoZKw5858aRtUcNk9"
        project = "aliyun_searchlog"
        endpoint = "http://service.odps.aliyun-inc.com/api"
        timeout = 3600
        self.__odps = neptune_odps_processs.OdpsProcessor(cmd_path, user, pwd, project, endpoint, timeout, self.__log)
        ots_console_path = '/home/xiangyu.liu/xiangyu.liuxy/dev/dev/ots_console'
        ots_endpoint = "http://sm-searchlog.ali-cn-shanghai.ots.aliyuncs.com"
        ots_access_id = "H8Dbi0rvLOPEJxSz"
        ots_access_secret = "WGHiplLIReH33RskKXFQuvginTka46"
        instance = "sm-searchlog"
        self.__ots = neptune_ots_process.OtsProccessor(ots_console_path, ots_endpoint, ots_access_id, ots_access_secret, instance, self.__log)
        

    def get_all_authority_users(self, owner_name, app_name, status):
        return self.__sql_manager.get_all_authority_users(owner_name, app_name, status)

    def get_all_ark_users(self):
        return self.__sql_manager.get_all_ark_users()

    def get_user_obj(self, user_name):
        try:
            user_obj = django.contrib.auth.models.User.objects.get(
                                        username=user_name)
            return user_obj
        except  exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return None 

    def send_msg(self, sender_name, receiver_name, msg_type, content):
        sender = self.get_user_obj(sender_name)
        receiver = self.get_user_obj(receiver_name)
        if not sender or not receiver:
            return 1, "sender:%s or reciever:%s is not exists!" % (sender_name, receiver_name)
        Message.objects.send(sender, receiver, content, msg_type = msg_type)
        return 0, "send success"

    def get_statistic_by_catetype(
            self,
            category_type,
            date_time):

        condition = {}
        condition['category_type'] = category_type
        condition['date_time'] = '= '+date_time

        where_content = ''
        tmp_content = self.__create_where_content(condition)
        if tmp_content.strip() != '':
            where_content = "and %s" % tmp_content

        data_size,uv = self.__sql_manager.get_statistic_by_catetype(
                where_content)
        return self.__create_statistic_ret(data_size,uv)

    def get_statistic_by_time_distance(
            self,
            user_name, 
            app_name,
            date_time,
            time_distance):

        condition = {}
        condition['user_name'] ='= "' + user_name +'"'
        condition['app_name'] = '= "' + app_name +'"'

        condition_list = []
        condition_list.append(('date_time','<= "' + date_time +'"'))
        condition_list.append(('date_time','>= "' + self.__time_convert(date_time,time_distance)+'"'))

        where_content = ''
        tmp_content = self.__create_where_content(condition)+' and '+\
                      self.__create_where_content_by_list(condition_list)
        if tmp_content.strip() != '':
            where_content = "and %s" % tmp_content

        statistic_list = self.__sql_manager.get_statistic_by_time_distance(
                where_content)
        return self.__create_statistic_list_ret(statistic_list)


    def insert_data_statistic_info(
            self,
            user_name, 
            app_name,
            category_type,
            uv,
            data_size,
            date_time):

        status, info = self.__sql_manager.insert_data_statistic_info(
                user_name,
                app_name,
                category_type,
                uv,
                data_size,
                date_time)
        return self.__get_default_ret_map(status, info)


    def update_data_statistic_info(
            self,
            user_name, 
            app_name,
            category_type,
            uv,
            data_size,
            date_time):

        status, info = self.__sql_manager.update_data_statistic_info(
                user_name,
                app_name,
                category_type,
                uv,
                data_size,
                date_time)
        return self.__get_default_ret_map(status, info)

    def delete_data_statistic_info(
            self,
            user_name,
            app_name):

        status, info = self.__sql_manager.delete_data_statistic_info(
                user_name,
                app_name)

        return self.__get_default_ret_map(status, info)

    def label_use_ranking(self):
        rank_list = self.__sql_manager.label_use_ranking()
        return self.__create_rank_list_ret(rank_list)

    def latest_publish_ranking(self):
        rank_list = self.__sql_manager.latest_publish_ranking()
        return self.__create_publish_rank_list_ret(rank_list)


    def create_tagconf_auth_send_msg(self, user_name, owner_name, app_name):
        msg = "the authority of data %s has been created to user %s by owner %s." % (app_name, user_name, owner_name)
        sender_name = SUPER_USER_NAME
        receiver_name = user_name
        msg_type = 6
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        receiver_name = owner_name
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        return

    def grant_tagconf_auth_send_msg(self, user_names, owner_name, app_name):
        for user_name in user_names:
            self.create_tagconf_auth_send_msg(user_name,  owner_name, app_name)
        return

    def apply_tagconf_auth_send_msg(self, user_name, owner_name, app_name):
        msg = "%s has applied data named %s whitch created by %s" % (app_name, user_name, owner_name)
        sender_name = SUPER_USER_NAME
        receiver_name = user_name
        msg_type = 6
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        receiver_name = owner_name
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        return

    def confirm_tagconf_auth_send_msg(self, user_name, owner_name, app_name):
        self.create_tagconf_auth_send_msg(user_name, owner_name, app_name)

    def reject_tagconf_auth_send_msg(self, user_name, owner_name, app_name):
        msg = "%s applied data %s authority has been rejected by owner %s" % (user_name, app_name, owner_name)
        sender_name = SUPER_USER_NAME
        receiver_name = user_name
        msg_type = 6
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        receiver_name = owner_name
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        return

    def take_back_tagconf_auth_send_msg(self, user_name, owner_name, app_name):
        msg = "%s\'s authority of data %s has been taken back by owner %s" % (user_name, app_name, owner_name)
        sender_name = SUPER_USER_NAME
        receiver_name = user_name
        msg_type = 6
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        receiver_name = owner_name
        self.send_msg(sender_name, receiver_name, msg_type, msg)
        return

    
    #授权
    def tagconf_auth(
            self,
            user_names,
            owner_name,
            app_name,
            action):
        if user_names is None \
            or owner_name is None \
            or app_name is None \
            or app_name == '' \
            or action is None:
            return self.__get_default_ret_map(
                    1, 
                    "param error! some param is None!")

        status = 0
        info = ''
        action = int(action)
        msg_tpl = "%s %s %s, owner is %s"
        if action == neptune.tools_utils.AuthAction.CREATE_CONF_AUTH:
            status,info = self.__sql_manager.create_tagconf_auth(
                    user_names,owner_name,app_name)
            self.create_tagconf_auth_send_msg(user_names,owner_name,app_name)
        elif action == neptune.tools_utils.AuthAction.GRANT_AUTH_TO_OTHER:
            status,info = self.__sql_manager.grant_tagconf_auth(
                    user_names,owner_name,app_name)
            self.grant_tagconf_auth_send_msg(user_names,owner_name,app_name)
        elif action == neptune.tools_utils.AuthAction.APPLY_AUTH:
            status,info = self.__sql_manager.apply_tagconf_auth(
                    user_names,owner_name,app_name)
            self.apply_tagconf_auth_send_msg(user_names,owner_name,app_name)
        elif action == neptune.tools_utils.AuthAction.CONFIRM_APPLY_AUTH:
            status,info = self.__sql_manager.confirm_tagconf_auth(
                    user_names,owner_name,app_name)
            self.confirm_tagconf_auth_send_msg(user_names,owner_name,app_name)
        elif action == neptune.tools_utils.AuthAction.REJECT_APPLY_AUTH:
            status,info = self.__sql_manager.reject_tagconf_auth(
                    user_names,owner_name,app_name)
            self.reject_tagconf_auth_send_msg(user_names,owner_name,app_name)
        elif action == neptune.tools_utils.AuthAction.TAKE_BACK_AUTH:
            status,info = self.__sql_manager.take_back_tagconf_auth(
                    user_names,owner_name,app_name)
            self.take_back_tagconf_auth_send_msg(user_names,owner_name,app_name)
        return self.__get_default_ret_map(status, info)
         
    #获取ots表和用户对应关系
    def get_all_ots_user_relation(self):
        ots_user_relation = self.__sql_manager.get_all_ots_user_relation()
        return self.__get_ots_user_ret(ots_user_relation)

    #查询用户与数据权限关系
    def get_user_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):

        if user_name is None \
            or owner_name is None \
            or app_name is None \
            or user_name.strip() == '' \
            or owner_name.strip() == '' \
            or app_name.strip() == '':
            return self.__get_default_ret_map(
                    1, 
                    "param error! some param is None!")

        auth = self.__sql_manager.get_user_tagconf_auth(
                user_name,
                owner_name,
                app_name)
        return self.__create_user_tagconf_auth_ret(auth)


    #获取数据列表信息
    def show_tagconf_info(
            self,
            owner_name,
            page_min,
            page_max,
            order_field,
            sort_order,
            search_map=None):
        
        self.__log.info("show_pipeline_info  owner_name: %s, "
                "page_min: %s, page_max: %s, order_field: %s, "
                "sort_order: %s, search_str: %s" % (
                owner_name, page_min, page_max, order_field, 
                sort_order, search_map))

        where_content = ''
        if search_map is not None:
            tmp_content = self.__create_where_content(search_map)
            if tmp_content.strip() != '':
                where_content = "and %s" % tmp_content
            self.__log.info("where_content: %s" % where_content)

        count, tagconfs = self.__sql_manager.show_tagconf_info(
                owner_name,
                page_min, 
                page_max, 
                order_field, 
                sort_order,
                where_content)
        return self.__create_show_tagconf_ret(count, tagconfs)

    def get_all_category_type(self):
        category_types = self.__sql_manager.get_all_category_type()
        return self.__get_all_category_type_ret(category_types)


    def get_tagconf_info(self,user_name,app_name):

        self.__log.info("app_name:"+app_name)

        tagconf,relation_list,use_count,apply_list = \
                    self.__sql_manager.get_tagconf_info(user_name,app_name)
        if tagconf is None:
            return self.__get_default_ret_map(1, "db error!")

        tagconf_map = {}
        tagconf_map["id"] = tagconf.id
        tagconf_map["use_count"] = use_count
        tagconf_map["data_type"] = tagconf.data_type
        tagconf_map["user_name"] = tagconf.user_name
        tagconf_map["app_name"] = tagconf.app_name
        tagconf_map["category_type"] = tagconf.category_type
        tagconf_map["update_cycle"] = tagconf.update_cycle
        tagconf_map["crontab_conf"] = tagconf.crontab_conf
        tagconf_map["overtime"] = tagconf.overtime
        tagconf_map["test_time"] = tagconf.test_time.strftime("%Y-%m-%d %H:%M")
        tagconf_map["protect_level"] = tagconf.protect_level
        tagconf_map["version"] = tagconf.version
        tagconf_map["status"] = tagconf.status
        tagconf_map["schema_file"] = tagconf.schema_file
        tagconf_map["description"] = tagconf.description
        tagconf_map["data_config"] = tagconf.data_config
        tagconf_map["raw_odps_table"] = tagconf.raw_odps_table
        tagconf_map["algin_odps_table"] = tagconf.algin_odps_table
        tagconf_map["ots_table"] = tagconf.ots_table
        tagconf_map["pipeline_name"] = tagconf.pipeline_name
        tagconf_map["create_time"] = tagconf.create_time.strftime(
                "%Y-%m-%d %H:%M:%S")
        tagconf_map["update_time"] = tagconf.update_time.strftime(
                "%Y-%m-%d %H:%M:%S")

        owner_list = []
        for relation in relation_list:
            owner_list.append(relation.user_name)

        app_list = []
        for app in apply_list:
            app_list.append(app.user_name)

        tagconf_map["owner_list"] = owner_list
        tagconf_map["apply_list"] = app_list

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["tagconf"] = tagconf_map
        return json.dumps(ret_map)

    def get_tagconf_owner_apply_list(
            self,
            app_name,
            type):

        relation_list = self.__sql_manager.get_tagconf_owner_apply_list(app_name,type)
        if relation_list is None:
            return self.__get_default_ret_map(1, "db error!")

        user_list = []
        for relation in relation_list:
            user_list.append(relation.user_name)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        if type == 0:
            ret_map["owner_list"] = user_list
        if type == 1:
            ret_map["apply_list"] = user_list
        return json.dumps(ret_map)


    def get_owner_subscribe_data(
            self,
            is_owner,
            owner_name,
            page_min,
            page_max):

        count, datas = self.__sql_manager.get_owner_subscribe_data(
                is_owner,
                owner_name,
                page_min, 
                page_max) 
        return self.__create_show_owner_data_ret(count, datas)

    def get_pipeline_name(self, user_name, app_name):
        try:
            tag_conf = neptune.models.TagConf.objects.get(user_name = user_name, app_name = app_name)
            return tag_conf.pipeline_name
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return ""
    
    def updata_app_data_status(self, user_name, app_name):
        try:
            tag_conf = neptune.models.TagConf.objects.get(user_name = user_name, app_name = app_name)
            tag_conf.status = 0
            tag_conf.save()
            return 0, "success"
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return 1, str(ex)

    def rollback_app(self, user_name, app_name, time_str):
        try:
            #get pipeline name
            pipeline_name = self.get_pipeline_name(user_name, app_name)
            #stop pipeline
            self.__pipeline_processor.stop_pipe(pipeline_name)
            #run pipeline
            ret, status = self.__pipeline_processor.run_pipe(pipeline_name, time_str)
            if not ret or 0 != status:
                return 1, "roll back failed"
            return 0, "success"
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return 1, ("\"%s\"" % str(ex))

    def delete_app_relation(self, owner_name, app_name):
        try:
            neptune.models.Relation.objects.filter(owner_name = owner_name, app_name = app_name).delete()
            return 0, "success"
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return 1, ("\"%s\"" % str(ex))

    def make_app_offline(self, user_name, app_name):
        try:
            #get pipeline name
            pipeline_name = self.get_pipeline_name(user_name, app_name)
            #cancel pipeline auto run
            ret, status = self.__pipeline_processor.update_pipe(pipeline_name, 0, None, None, None, None, None)
            if not ret or 0 != status:
                return 1, "roll back failed"
            #修改tagconf中的status
            status, info = self.updata_app_data_status(user_name, app_name)
            if 0 != status:
                return status, info
            #删除对应的relation中的数据
            status, info = self.delete_app_relation(user_name, app_name)
            if 0 != status:
                return status, info
            return 0, "success"
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return 1, ("\"%s\"" % str(ex))

    def owner_data_operate(
            self,
            app_name,
            owner_name,
            action,
            time_str):
        #TODO根据action去做相应的操作0, x回滚， 1 下线
        if 0 == action:
            status, info = self.rollback_app(owner_name, app_name, time_str)
            self.__get_default_ret_map(status, info)
            self.__log.info('roll back user = %s, app = %s, status = %s, info = %s' % (owner_name, app_name, status, info))
            return self.__get_default_ret_map(status, info)
        if 1 == action:
            status, info = self.make_app_offline(owner_name, app_name)
            return self.__get_default_ret_map(status, info)
        return self.__get_default_ret_map(1, "action code is invalid")


    def process_delete_user_app(self, user_name, app_name):
        try:
            #get tagConf
            tag_conf = neptune.models.TagConf.objects.get(user_name = user_name, app_name = app_name)
            #stop pipeline
            self.__pipeline_processor.stop_pipe(tag_conf.pipeline_name)
            #delete pipeline
            self.__pipeline_processor.delete_pipeline(tag_conf.pipeline_name)
            #delete odps table
            raw_odps_table = tag_conf.raw_odps_table
            algin_odps_table = tag_conf.algin_odps_table
            self.__odps.drop_table(raw_odps_table)
            self.__odps.drop_table(algin_odps_table)
            #delete ots table
            ots_table = tag_conf.ots_table
            self.__ots.delete_ots_table(ots_table)
            #delete user data in tagconf
            neptune.models.TagConf.objects.filter(user_name = user_name, app_name = app_name).delete()
            #delete relation data
            neptune.models.Relation.objects.filter(owner_name = user_name, app_name = app_name).delete()
            msg = "delete user_name = %s, app_name = %s success" %  (user_name, app_name)
            self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
            return self.__get_default_ret_map(0, "success")
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            msg = "delete user_name = %s, app_name = %s exeception:\n%s" % str(ex)
            self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))

    def parse_user_conf(self, conf_str):
        conf_dict = json.loads(conf_str)
        self.__log.info("parsed conf dict:\n%s" % conf_dict)
        return conf_dict

    def md5_str(self, d_str):
        m = md5.new()
        m.update(d_str)
        return m.hexdigest().upper()

    #这个方法特别的丑陋 恶心自己了 需要重构！
    def construct_odps_cols(self, columns):
        flag = False
        aligne_cols = []
        raw_cols = []
        identify_type = ''
        identify_name = ''
        col_name_list = []
        col_aligne_name_list = []
        for sub in columns:
            if len(sub) < 3:
                continue
            col_name_list.append(sub[2])
            if IDENTIFY_COL == sub[0] :
                flag = True
                aligne_cols.append((sub[1], STRING_TYPE))
                identify_type = sub[1]
                identify_name = sub[2]
                col_aligne_name_list.append(identify_type)
            else:
                aligne_cols.append((sub[2], STRING_TYPE))
                col_aligne_name_list.append(sub[2])
            raw_cols.append((sub[2], STRING_TYPE))
        if not flag:
            return None, None, None, None, None, None
        return raw_cols, aligne_cols, identify_type, identify_name, col_name_list, ','.join(col_aligne_name_list)

    def construc_odps_part_tpl(self, update_cycle):
        if HOUR_PIPE == type:
            return "dt=%year%%month%%d%%hour%@-1hour"
        return "dt=%year%%month%%d%@-1day"

    def check_day_or_hour_pipeline(self, c_str):
        l = c_str.split(" ")
        r = []
        for i in l:
            if i:
                r.append(i)
        clean_crontab_conf = ' '.join(r)
        schedule_level = HOUR_PIPE
        if len(r) < 5 or STAR_STR != r[1]:
           schedule_level = DAY_PIPE
        return schedule_level, clean_crontab_conf

    def construct_column_fields(self, col_name_list):
        col_name_str = ",".join(col_name_list)
        left_col_name_list = ['l.%s' % s for s in col_name_list]
        left_col_name_str = ','.join(left_col_name_list)
        return col_name_str, left_col_name_str
    
    def generate_all_fileds(self, conf_dict):
        d = {}
        user_name = conf_dict['user_name']
        d['user_name'] = user_name
        app_name = conf_dict['app_name']
        d['app_name'] = app_name
        uniq_str = self.md5_str("%s_%s" % (user_name, app_name))
        odps_raw_table_name = ODPS_PREFIX + uniq_str + RAW_TABLE_POSTFIX
        odps_aligne_table_name = ODPS_PREFIX + uniq_str + ALIGN_TABLE_POSTFIX
        ots_table_name = OTS_PREFIX + uniq_str + OTS_POSTFIX
        pipeline_name = PIPELINE_PREFIX + uniq_str + PIPELINE_POSTFIX
        d['odps_raw_table_name'] = odps_raw_table_name
        d['odps_aligne_table_name'] = odps_aligne_table_name
        d['ots_table_name'] = ots_table_name
        d['pipeline_name'] = pipeline_name
        d_config = conf_dict['data_config']
        col_list = d_config['columns']
        raw_cols, align_cols, identify_type, identify_name, col_name_list, col_aligne_name_list_str = self.construct_odps_cols(col_list)
        d['identify_name'] = identify_name
        d['identify_type'] = identify_type
        col_name_str, left_col_name_str = self.construct_column_fields(col_name_list)
        d['col_name_list_str'] = col_name_str
        d['aligne_name_list_str'] = col_aligne_name_list_str
        if not raw_cols or not align_cols:
            raise exceptions.Exception("colums config error")
        d['left_col_name_list_str'] = left_col_name_str
        d['raw_cols'] = raw_cols
        d['align_cols'] = align_cols
        d['inner_part_cols'] = [(INNER_PART_NAME, STRING_TYPE)]
        d['ots_primary_cols'] = [(identify_type, STRING_TYPE)]
        update_cycle, clean_crontab_conf = self.check_day_or_hour_pipeline(conf_dict['crontab_conf'])
        d['crontab_conf'] = clean_crontab_conf
        conf_dict['update_cycle'] = update_cycle
        inner_odps_part_tpl = self.construc_odps_part_tpl(conf_dict['update_cycle'])
        d['inner_odps_part_tpl'] = inner_odps_part_tpl
        d['update_cycle'] = update_cycle
        d['category_type'] = conf_dict['category_type']
        d['test_time'] = conf_dict['test_time']
        d['overtime'] = int(conf_dict['overtime'])
        d['protect_level'] = conf_dict['protect_level']
        d['version'] = conf_dict['version']
        d['schema_file'] = conf_dict['schema_file']
        d['description'] = conf_dict['description']
        d['data_config'] = json.dumps(conf_dict['data_config'])
        return d

    def check_user_and_app_uniqe(self, user_name, app_name):
        l = neptune.models.TagConf.objects.filter(user_name = user_name, app_name = app_name)
        if len(l) > 0:
            raise exceptions.Exception("user_name=%s, app_name=%s has been created, please contact the admin to process" % (user_name, app_name))

    #@django.db.transaction.atomic
    def save_tagconf_obj(self, f_dict, status = 2):
        try:
            t_l = neptune.models.TagConf.objects.filter(user_name =  f_dict['user_name'], app_name = f_dict['app_name'])
            if len(t_l) > 0:
                for obj in t_l:
                    obj.delete()
            tagconf = neptune.models.TagConf(
                    data_type = USER_TAG_DATA,
                    user_name = f_dict['user_name'],
                    app_name = f_dict['app_name'],
                    category_type = f_dict['category_type'],
                    update_cycle = f_dict['update_cycle'],
                    crontab_conf = f_dict['crontab_conf'],
                    overtime = f_dict['overtime'],
                    test_time = timeformat_transform(f_dict['test_time']),
                    protect_level = f_dict['protect_level'],
                    version = f_dict['version'],
                    status = status,
                    schema_file = f_dict['schema_file'],
                    description = f_dict['description'],
                    data_config = f_dict['data_config'],
                    raw_odps_table = f_dict['odps_raw_table_name'],
                    algin_odps_table = f_dict['odps_aligne_table_name'], 
                    ots_table = f_dict['ots_table_name'],
                    create_time = tools_util.StaticFunction.get_now_format_time(
                         "%Y-%m-%d %H:%M:%S"), 
                    update_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S"),
                    pipeline_name =f_dict['pipeline_name']
                    )
            tagconf.save()
            return 0, "success"
        except exceptions.Exception as ex:  
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return 1, str(ex)


    #@django.db.transaction.atomic
    def create_process_conf_obj(self, action, conf_str):
        try:
            process_conf_obj =  neptune.models.ProcessConfTable(\
                    action = action,
                    conf_str = conf_str)
            process_conf_obj.save()
            return 0
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % ( str(ex), traceback.format_exc()))
            return 1


    #TODO要考虑容错问题 考虑各种失败的情况
    def create_all_tables(self, f_dict):
        self.__odps.create_table(f_dict['odps_raw_table_name'], f_dict['raw_cols'], f_dict['inner_part_cols'])
        self.__log.info("after create table:%s" % f_dict['odps_raw_table_name'])
        self.__odps.create_table(f_dict['odps_aligne_table_name'], f_dict['align_cols'], f_dict['inner_part_cols'])
        self.__log.info("after create table:%s" % f_dict['odps_aligne_table_name'])
        self.__ots.create_ots_table(f_dict['ots_table_name'], f_dict['ots_primary_cols'])
        self.__log.info("after create ots table:%s"  % f_dict['ots_table_name'])


    #后续需要走单独配置
    def generate_check_task_config(self, f_dict, task_name = 'check_task'):
        data_config = json.loads(f_dict['data_config'])
        if PANGU_SRC == data_config['data_source']:
            config_str = 'check_path=%s\nis_directory=true\novertime=86400' % data_config['pu_path']
            task_config_dict = {'name':task_name, 'script_name':'run.py', 'log_file':'processor.log',\
                    '_tpl':'run.conf.tpl', '_out':'run.conf', 'config':config_str,\
                    'processor_name':'check_pangu_file_exists', 'priority': 6}
            return task_config_dict 
        
        if ODPS_SRC == data_config['data_source']:
            config_str = 'odpscmd_path=/home/admin/data_platform/odps/odps_clt/bin/odpscmd\nodps_user=JEtRWGlRrEPkqNpw\nodps_pw=NzrPjfMseoTJ4UoZKw5858aRtUcNk9\nodps_project=%s\nodps_timeout=3600\ntable_name=%s\npartition_str=%s\nendpoint_str=http://service.odps.aliyun-inc.com/api'\
                    % (data_config['project'], data_config['table'], data_config['partition'])
                    #% (data_config['project'], data_config['table'], "day=%year%%month%%\day%@-1day")
            task_config_dict = {'name':task_name, 'script_name':'run.py', 'log_file':'processor.log',\
                    '_tpl':'run.conf.tpl', '_out':'run.conf',\
                    'processor_name':'check_partition_exists_processor',\
                    'priority': 6,'config':config_str}
            return task_config_dict
    
    def generate_create_odps_part_task_config(self, f_dict, task_name = 'create_odps_part'):
        config_str = 'table_name=%s\npart_desc=%s\n_tpl= create_odps_part.odps.tpl\n_out=create_odps_part.odps'\
                % (f_dict['odps_raw_table_name'], f_dict['inner_odps_part_tpl'])
        task_config_dict = {'name':task_name,'config':config_str,  'processor_name':'create_odps_part'}
        return task_config_dict

    def generate_import_task_config(self, f_dict, task_name='import_task'):
        data_config = json.loads(f_dict['data_config'])
                
        if PANGU_SRC == data_config['data_source']:
            raw_set = data_config['sep']
            sep = ''
            for c in raw_set:
                if CHAR_TRANS_DICT.has_key(c):
                    sep = sep + CHAR_TRANS_DICT[c]
                else:
                    sep = sep + c
            data_config['sep'] = sep
            print data_config
            r_pu_path = data_config['pu_path']
            item_list = r_pu_path.split("@")
            pu_path = ''
            if len(item_list) < 2:
                pu_path = r_pu_path + "/.*"
            else:
                pu_path = "@".join(item_list[:len(item_list) - 1]) + "/.*@" + item_list[-1]

            fileCount = data_config['pu_file_num']
            config_str = '_tpl=import_odps.json.tpl\n_out=\nimport_odps.json\nsep=%s\n\
                    access_id=JEtRWGlRrEPkqNpw\naccess_key=NzrPjfMseoTJ4UoZKw5858aRtUcNk9\n\
                    project=aliyun_searchlog\npart=%s\ntable=%s\ninput_file=%s\n_filecount=%s'%\
                    (data_config['sep'], f_dict['inner_odps_part_tpl'], f_dict['odps_raw_table_name'],\
                    pu_path, fileCount)
            task_config_dict = {'name':task_name, 'processor_name':'import_odps_processor',\
                    'config':config_str, 'server_tag':'AY54'} #此处需要重新修改，配置文件数据要从前端传入
            return task_config_dict
        if  ODPS_SRC == data_config['data_source']:
            config_str = 'out_table=%s\nout_part=%s\ninput_table=%s\nfields=%s\ninput_part=%s' %\
                    (f_dict['odps_raw_table_name'], f_dict['inner_odps_part_tpl'],\
                    data_config['table'], f_dict['col_name_list_str'], data_config['partition'])
            task_config_dict = {'name':task_name, 'processor_name':'just_copy',\
                    'config':config_str}
            return task_config_dict

    def generate_statistic_task_config(self, f_dict, task_name = 'statistic_task'):
        config_str = 'odpscmd_path=/home/admin/data_platform/odps/odps_clt/bin/odpscmd\n\
                odps_access_id=JEtRWGlRrEPkqNpw\nodps_access_key=NzrPjfMseoTJ4UoZKw5858aRtUcNk9\n\
                odps_project=aliyun_searchlog\nodps_endpoint=http://service.odps.aliyun-inc.com/api\nodps_table=%s\nodps_partition=%s\nuser_name=%s\napp_name=%s\ncategory_type=%s\nupdate_url=%s' \
                % (f_dict['odps_raw_table_name'], f_dict['inner_odps_part_tpl'], f_dict['user_name'], f_dict['app_name'], f_dict['category_type'], UPDATE_SATISTIC_URL)

        task_config_dict = {'name':task_name, 'processor_name':'usertag_platform_statistic_processor',\
                            'config':config_str}
                
        return task_config_dict

    #暂时使用justcopy的配置
    def generate_aligment_task(self, f_dict, task_name = 'aligment_task'):
        data_config = json.loads(f_dict['data_config'])
        config_str = 'out_table=%s\nout_part=%s\ninput_table=%s\nfields=%s\ninput_part=%s' % \
                (f_dict['odps_aligne_table_name'], f_dict['inner_odps_part_tpl'],\
                f_dict['odps_raw_table_name'], f_dict['col_name_list_str'],\
                f_dict['inner_odps_part_tpl'])
        task_config_dict = {'name':task_name, 'processor_name':'just_copy', 'config':config_str}
        return task_config_dict

    def generate_dump_to_ots_task(self, f_dict, task_name = 'dump_to_ots_task'):
        tmp_list = f_dict['aligne_name_list_str'].split(',')
        identify_type = f_dict['identify_type']
        r_list = []
        for item  in tmp_list:
            if item != identify_type:
                r_list.append(item)
        fields_str = ','.join(r_list)
        config_str = 'output_instance_count= 128\nodps_id=JEtRWGlRrEPkqNpw\n\
                odps_key=NzrPjfMseoTJ4UoZKw5858aRtUcNk9\nodps_project=aliyun_searchlog\n\
                table=%s\npart=%s\nfields=%s\nots_primary_key=%s\nost_table_name=%s\n\
                ots_endpoint=http://sm-searchlog.ali-cn-shanghai.ots.aliyuncs.com\n\
                ots_accesskeyid=H8Dbi0rvLOPEJxSz\nots_accesskeysecret=WGHiplLIReH33RskKXFQuvginTka46\n\
                ots_instancename=sm-searchlog\nbatch_count=200\nmax_batch_count=250\n_tpl=dump_to_ots.json.tpl' % \
                (f_dict['odps_aligne_table_name'], f_dict['inner_odps_part_tpl'],fields_str, f_dict['identify_type'], f_dict['ots_table_name'])
        task_config_dict = {'name':task_name, 'processor_name':'dump_odps_to_ots', 'server_tag':'AY54', 'config':config_str}
        return task_config_dict

    def create_pipeline(self, f_dict):
        pipeline_name = f_dict['pipeline_name']
        user_name = f_dict['user_name']
        app_name = f_dict['app_name']
        desc = "user_name:%s, app_name:%s" % (user_name, app_name)
        try:
            ret, status = self.__pipeline_processor.create_pipeline(pipeline_name, f_dict['crontab_conf'], desc)
            if not ret or 0 != status:
                return 1, "create pipeline failed"
            check_task_config = self.generate_check_task_config(f_dict, 'check_task')
            self.__log.info("check_task_config:\n%s" % check_task_config)
            self.__pipeline_processor.add_task(pipeline_name, check_task_config)
            create_odps_part_task_config = self.generate_create_odps_part_task_config(f_dict, 'create_odps_part')
            self.__log.info("create_odps_part_task_config:\n%s" % create_odps_part_task_config)
            self.__pipeline_processor.add_task(pipeline_name, create_odps_part_task_config)
            import_task_config = self.generate_import_task_config(f_dict, 'import_task')
            self.__log.info("import_task_config:\n%s" % import_task_config)
            self.__pipeline_processor.add_task(pipeline_name, import_task_config)
            statistic_task_config = self.generate_statistic_task_config(f_dict, 'statistic_task')
            self.__log.info("statistic_task_config:\n%s" % statistic_task_config)
            self.__pipeline_processor.add_task(pipeline_name, statistic_task_config)
            aligment_task_config = self.generate_aligment_task(f_dict, 'aligment_task')
            self.__log.info("aligment_task_config:\n%s" % aligment_task_config)
            self.__pipeline_processor.add_task(pipeline_name, aligment_task_config)
            dump_to_ots_task_config = self.generate_dump_to_ots_task(f_dict, 'dump_to_ots_task')
            self.__pipeline_processor.add_task(pipeline_name, dump_to_ots_task_config)
            self.__pipeline_processor.add_edge(pipeline_name, 'check_task', pipeline_name,  'create_odps_part')
            self.__pipeline_processor.add_edge(pipeline_name, 'create_odps_part', pipeline_name,  'import_task')
            self.__pipeline_processor.add_edge(pipeline_name, 'import_task', pipeline_name, 'aligment_task')
            self.__pipeline_processor.add_edge(pipeline_name, 'import_task', pipeline_name, 'statistic_task')
            self.__pipeline_processor.add_edge(pipeline_name, 'aligment_task', pipeline_name, 'dump_to_ots_task')
            self.__pipeline_processor.run_pipe(pipeline_name, f_dict['test_time'])
        except exceptions.Exception as ex:
            self.__log.error("exception in create_pipeline:\n%s" % str(ex))
            return 1, str(ex)
        return 0, "create pipeline success"


    #@django.db.transaction.atomic
    def create_relation_obj(self, run_dict):
        try:
            tagconf_relation = neptune.models.Relation(
                    user_name = run_dict['user_name'],
                    owner_name = run_dict['user_name'],
                    app_name = run_dict['app_name'],
                    status = 3,
                    algin_odps_table = run_dict['odps_aligne_table_name'],
                    ots_table = run_dict['ots_table_name'],
                    ots_priviliege = 1,
                    odps_priviliege = 1,
                    update_time = tools_util.StaticFunction.get_now_format_time("%Y-%m-%d %H:%M:%S"))
            tagconf_relation.save()
            return 0, "success" 
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return 1, str(ex)


    #@django.db.transaction.atomic
    def create_allow_online_obj(self, user_name, app_name, status = 0):
        try:
            obj_l = neptune.models.AllowOnlineTable.objects.filter(user_name = user_name, app_name = app_name, status = status)
            if len(obj_l) > 0:
                for obj in obj_l:
                    obj.delete()
            obj = neptune.models.AllowOnlineTable(
                    user_name = user_name,
                    app_name = app_name,
                    status = status,
                    time = tools_util.StaticFunction.get_now_format_time("%Y-%m-%d %H:%M:%S"))
            obj.save()
            msg = "app_name = %s created by %s apply to online" % (user_name, app_name)
            self.send_msg(SUPER_USER_NAME, SUPER_USER_NAME, 7, msg)
            return 0, "success"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def trans_tagconf_obj_to_conf_str(self, obj):
        try:
            d = {}
            d['schema_file'] = obj.schema_file
            d['test_time'] = obj.test_time.strftime("%Y%m%d%H%M")
            d['app_name'] = obj.app_name
            d['description'] = obj.description
            d['crontab_conf'] = obj.crontab_conf
            d['update_cycle'] = str(obj.update_cycle)
            d['overtime'] = str(obj.overtime)
            d['category_type'] = obj.category_type
            d['version'] = obj.version
            d['user_name'] = obj.user_name
            d['protect_level'] = str(obj.protect_level)
            d['data_config'] = json.loads(obj.data_config)
            return json.dumps(d)
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return ''

    #@django.db.transaction.atomic
    def save_user_app_conf(self, conf_str, status = 0):
        conf_dict = self.parse_user_conf(conf_str)
        user_name = conf_dict['user_name']
        app_name = conf_dict['app_name']
        f_dict = self.generate_all_fileds(conf_dict)
        try:
            tagconf = neptune.models.TagConf(
                    user_name = f_dict['user_name'],
                    app_name = f_dict['app_name'],
                    category_type = f_dict['category_type'],
                    update_cycle = f_dict['update_cycle'],
                    crontab_conf = f_dict['crontab_conf'],
                    overtime = f_dict['overtime'],
                    test_time = timeformat_transform(f_dict['test_time']),
                    protect_level = f_dict['protect_level'],
                    version = f_dict['version'],
                    status = status,
                    schema_file = f_dict['schema_file'],
                    description = f_dict['description'],
                    data_config = f_dict['data_config'],
                    raw_odps_table = f_dict['odps_raw_table_name'],
                    algin_odps_table = f_dict['odps_aligne_table_name'], 
                    ots_table = f_dict['ots_table_name'],
                    create_time = tools_util.StaticFunction.get_now_format_time(
                         "%Y-%m-%d %H:%M:%S"), 
                    update_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S"),
                    pipeline_name =f_dict['pipeline_name']
                    )
            t_l = neptune.models.TagConf.objects.filter(user_name = f_dict['user_name'], app_name = f_dict['app_name'])
            if 0 == len(t_l):
                tagconf.save()
            else:
                for obj in t_l:
                    obj.user_name = tagconf.user_name
                    obj.app_name = tagconf.app_name
                    obj.category_type = tagconf.category_type
                    obj.update_cycle = tagconf.update_cycle
                    obj.crontab_conf = tagconf.crontab_conf
                    obj.overtime = tagconf.overtime
                    obj.test_time = tagconf.test_time
                    obj.protect_level = tagconf.protect_level
                    obj.version = tagconf.version
                    obj.status = tagconf.status
                    obj.schema_file = tagconf.schema_file
                    obj.description = tagconf.description
                    obj.data_config = tagconf.data_config
                    obj.raw_odps_table = tagconf.raw_odps_table
                    obj.algin_odps_table = tagconf.algin_odps_table
                    obj.ots_table = tagconf.ots_table 
                    obj.create_time = tagconf.create_time
                    obj.update_time = tagconf.update_time
                    obj.pipeline_name = tagconf.pipeline_name
                    obj.save()
            self.__log.info("save tag conf")
            return self.__get_default_ret_map(0, "success")
        except exceptions.Exception as ex:  
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))

    def process_create_user_app(self, conf_str):
        conf_dict = self.parse_user_conf(conf_str)
        user_name = conf_dict['user_name']
        app_name = conf_dict['app_name']
        try:
            #self.check_user_and_app_uniqe(user_name, app_name)
            run_dict = self.generate_all_fileds(conf_dict)
            self.__log.info("generate_all_fileds process finish")
            #创建odps表
            #创建ots表
            #考虑增加错误判断机制
            self.create_all_tables(run_dict)
            #创建pipeline
            self.__log.info("odps table create finish")
            status, msg = self.create_pipeline(run_dict)
            self.__log.info("after create_pipeline")
            if 0 != status:
                #TODO 修改为失败后发送消息
                err_msg = "user = %s ,app_name=%s input failed! \nconf:%s\nexc:\n%s" % (user_name, app_name, conf_str, msg) 
                self.__log.error("%s" %  err_msg)
                return self.__get_default_ret_map(status, ("\"%s\"" % err_msg))
            #构造数据库对象
            status, info = self.save_tagconf_obj(run_dict)
            self.__log.info("after save_tagconf_obj")
            if 0 != status:
                msg = "user_name=%s, app_name = %s, save tag conf exception:\n%s" % (user_name, app_name, info)
                self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
            #status, info = self.create_relation_obj(run_dict)
            #TODO 修改relation表
            #if 0 != status:
            #    msg = "user_name=%s, app_name = %s, save relation exception:\n%s" % (user_name, app_name, info)
            #    self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
            #TODO 提交申请
            status, info = self.create_allow_online_obj(user_name, app_name)
            self.__log.info("after create_allow_online_obj")
            #TODO 成功后发送消息
            msg = 'user_name = %s\tapp_name = %s\n input success' % (user_name, app_name)
            self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
            self.__log.info("after send msg")
            return self.__get_default_ret_map(0, "success")
        except exceptions.Exception as ex:  
            self.__log.error('ex: %s' % str(ex))
            #TODO 发送失败消息
            err_msg = "user = %s ,app_name=%s input failed! \nconf:%s\nexc:\n%s" % (user_name, app_name, conf_str, str(ex))
            self.send_msg(SUPER_USER_NAME, user_name, 7, err_msg)
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))
    
    def process_recreate_user_app(self, conf_str):
        try:
            conf_dict = self.parse_user_conf(conf_str) 
            user_name = conf_dict['user_name']
            app_name = conf_dict['app_name']
            result_dict = self.process_delete_user_app(user_name, app_name)
            self.__log.info("delete user_name=%s, app_name=%s, result:%s" % (user_name, app_name, result_dict))
            if 0 != json.loads(result_dict)['status']:
                msg = 'recreate: user_name=%s, app_name=%s delete failed\n%s' % (user_name, app_name, result_dict)
                self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
                return result_dict
            result_dict = self.process_create_user_app(conf_str)
            self.__log.info("after create user_app:%s" % result_dict)
            d = json.loads(result_dict)
            if 0 != d['status']:
                msg = 'recreate: user_name=%s, app_name=%s create failed\n%s' % (user_name, app_name, d['info'])
                self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
                return  self.__get_default_ret_map(1, d['info'])
            msg = "recreate: user_name=%s, app_name=%s success!" % (user_name, app_name)
            self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
            return result_dict
        except exceptions.Exception as ex:  
            self.__log.error('ex: %s' % str(ex))
            msg = 'recreate: user_name=%s, app_name=%s  exceptionL\n%s' % (user_name, app_name, str(ex))
            self.send_msg(SUPER_USER_NAME, user_name, 7, msg)
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))

    #@django.db.transaction.atomic
    def delete_user_app(self, user_name, app_name):
        try:
            #修改tagconf中的status状态，把status改为5，这样返回和统计的接口就找不到该app了，前端则不会展示该字段
            tag_conf_obj = neptune.models.TagConf.objects.get(user_name = user_name, app_name = app_name)
            tag_conf_obj.status = 5
            tag_conf_obj.save()
            conf_d = {'user_name':user_name, 'app_name':app_name}
            conf_str = json.dumps(conf_d)
            action = 'delete_user_app'
            ret = self.create_process_conf_obj(action, conf_str)
            if 0 != ret:
                self.err_log("insert delete_user_app conf_str failed")
                return self.__get_default_ret_map(1, "insert delete_user_app conf_str failed")
            return self.__get_default_ret_map(0, "success")
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))
    
    def recreate_user_app(self, conf_str):
        try:
             action = 'recreate_user_app'
             ret = self.create_process_conf_obj(action, conf_str)
             if 0 != ret:
                 self.err_log("insert recreate_user_app conf_str failed")
                 return self.__get_default_ret_map(1, "insert recreate_user_app conf_str failed")
             return self.__get_default_ret_map(0, "success")
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))

    def create_user_app(self, conf_str):
        try:
            self.save_user_app_conf(conf_str, 2)
            action = 'create_user_app'
            ret = self.create_process_conf_obj(action, conf_str)
            self.__log.info("after create_process_conf_obj")
            if 0 != ret:
                self.err_log("insert create_user_app conf_str failed")
                return self.__get_default_ret_map(1, "insert create_user_app conf_str failed")
            self.__log.info("create_user_app success")
            return self.__get_default_ret_map(0, "success")
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))

    def get_user_public_and_buy_data_count(self, user_name):
        #get user buy data count relation中user_name = user_name && status = 2
        buy_ret, buy_count = self.__sql_manager.get_user_buy_data_count(user_name)
        #get user public data count relation中 owner_name = user_name && status = 3
        public_ret, public_count = self.__sql_manager.get_user_public_data_count(user_name)
        ret_dict = {"status": 0, "user_name": user_name, "info":"success",  "public":public_count, "buy":buy_count}
        ret_str = json.dumps(ret_dict)
        self.__log.info("resturn result:\n%s" % ret_str)
        return ret_str

    def get_all_user_process_data_count(self, user_name):
        #staus = 0 count
        ret, unpublic_count = self.__sql_manager.get_user_process_data_by_status(user_name, 0)
        #status = 1 count
        ret, public_failed_count = self.__sql_manager.get_user_process_data_by_status(user_name, 1)
        #status = 2 count
        ret, publicing_count = self.__sql_manager.get_user_process_data_by_status(user_name, 2)
        #status = 3 count
        ret, published_count = self.__sql_manager.get_user_process_data_by_status(user_name, 3)
        #all
        all_count = unpublic_count + public_failed_count + publicing_count + published_count
        ret_dict  = {"status":0, "info":"success", "user_name": user_name, "unpublish":unpublic_count,\
                'publish_failed':public_failed_count, 'publishing':publicing_count,\
                'published':published_count, 'all_count':all_count}
        return json.dumps(ret_dict)


    #@django.db.transaction.atomic
    def apply_public_operation(self, user_name, app_name):
        try:
            #获取对象
            obj = neptune.models.TagConf.objects.get(user_name =  user_name, app_name = app_name)
            self.__log.info("apply_public_operation get obj finish")
            #构造confstr
            conf_str = self.trans_tagconf_obj_to_conf_str(obj)
            obj.delete()
            #调用create
            self.create_user_app(conf_str)
            return self.__get_default_ret_map(0, "apply_public_operation success")
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))

    def execute_action(self, action, conf_str):
        s = set(['create_user_app', 'recreate_user_app', 'delete_user_app'])
        if action not in s:
            self.__log.error('action=%s is invalid action' % action)
            return 2
        try:
            r = ''
            if 'create_user_app' == action:
                r = self.process_create_user_app(conf_str)
            if 'recreate_user_app' == action:
                r =  self.process_recreate_user_app(conf_str)
            if 'delete_user_app' == action:
                conf_d = json.loads(conf_str)
                r = self.process_delete_user_app(conf_d['user_name'], conf_d['app_name'])
            r_d = json.loads(r)
            self.__log.info('result=%s, action=%s, conf_str = %s' % (r, action, conf_str))
            if 0 != r_d['status']:
                return 1
            return 0
        except exceptions.Exception as ex:
            self.__log.error('aciton:%s, con_str = %s\nex: %s' % (action, conf_str, str(ex)))
            return 1

    #@django.db.transaction.atomic
    def process_all_user_app_action(self):
        try:
            total_len = 10
            obj_list = neptune.models.ProcessConfTable.objects.all()[:total_len]
            success_len = 0
            total_len = len(obj_list)
            for obj in obj_list:
                action = obj.action
                conf_str = obj.conf_str
                ret = self.execute_action(action, conf_str)
                if 0 == ret:
                    success_len += 1
                obj.delete()
            return self.__get_default_ret_map(0, "%s process_all_user_app_action succes,total_len = %s, success_len = %s, failed_len = %s" % \
                    (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), total_len, success_len, total_len - success_len))
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return self.__get_default_ret_map(1, ("\"%s\"" % str(ex)))

    def processing_center_info(
            self,
            user_name,
            process_status,
            page_min,
            page_max):

        count, datas = self.__sql_manager.processing_center_info(
                user_name,
                process_status,
                page_min,
                page_max)
        return self.__show_processing_center_data_ret(count, datas)

    def publish_tagconf_data(self,tagconf):
        status, info = self.__sql_manager.publish_tagconf_data(tagconf)
        return self.__get_default_ret_map(status, info)

    def publish_tagconf_history(
            self,
            owner_name,
            page_min,
            page_max):

        count, datas = self.__sql_manager.publish_tagconf_history(
                owner_name,
                page_min,
                page_max)
        return self.__show_publish_tagconf_history_ret(count, datas)

    def update_tagconf_data(self,tagconf_id,user_name,update_map):
        try:
            status, info = self.__sql_manager.update_tagconf_data(
                    tagconf_id,
                    user_name,
                    update_map)
            if status != 0:
                return self.__get_default_ret_map(status, info)

            crontab_conf = None
            for key in update_map:
                if key == 'crontab_conf':
                    crontab_conf = update_map[key]
                
            tagconf = neptune.models.TagConf.objects.get(id=tagconf_id)

            self.__pipeline_processor.update_pipe(
                    pipe_name=tagconf.pipeline_name, 
                    ct_time=crontab_conf)
            return self.__get_default_ret_map(status, info)
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return self.__get_default_ret_map(1, str(ex))

    def update_tagconf_config(
            self,
            tagconf_id,
            user_name,
            tagconf):
        status, info = self.__sql_manager.update_tagconf_config(
                tagconf_id,user_name,tagconf)
        return self.__get_default_ret_map(status, info)



























    """
    工具方法
    """
    #求date_time之前的time_distance天的日期
    def __time_convert(self,date_time,time_distance):
        try:
            self.__log.info('1date_time=%s' % date_time)
            time_array = time.strptime(date_time, "%Y-%m-%d %H:%M:%S")
            self.__log.info('2date_time=%s' % date_time)
            #求之前的time_distance天
            end_date_time = datetime.datetime(
                    time_array.tm_year, 
                    time_array.tm_mon, 
                    time_array.tm_mday, 
                    time_array.tm_hour, 
                    time_array.tm_min, 
                    time_array.tm_sec)
            self.__log.info('3date_time=%s' % date_time)
            start_date_time = end_date_time - datetime.timedelta(days=int(time_distance))
            self.__log.info('4date_time=%s' % date_time)
            start_time = start_date_time.strftime("%Y-%m-%d %H:%M:%S")
            self.__log.info('start_time=%s' % start_time)
            return start_time
        except exceptions.Exception as ex:
            self.__log.error('ex: %s' % str(ex))
            return None

    #获取所有的标签类型
    def __get_all_category_type_ret(self,category_types):
        if category_types is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["category_types"] = category_types
        return json.dumps(ret_map)




    #组装ots_table和用户关系
    def __get_ots_user_ret(self,ots_user_relation):
        if ots_user_relation is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["relation"] = ots_user_relation
        return json.dumps(ret_map)
            
    #用户与数据权限关系查询
    def __create_user_tagconf_auth_ret(self,auth):
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["auth"] = auth
        return json.dumps(ret_map)


    def __create_statistic_ret(self,data_size,uv):
        if data_size is None or uv is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["data_size"] = data_size
        ret_map["uv"] = uv
        return json.dumps(ret_map)

    #组装统计结果
    def __create_statistic_list_ret(self,statistic_list):
        if statistic_list is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        stat_list = []
        for statistic in statistic_list:
            stat_map = {}
            stat_map["user_name"] = statistic[0]
            stat_map["app_name"] = statistic[1]
            stat_map["data_size"] = statistic[2]
            stat_map["uv"] = statistic[3]
            stat_map["date_time"] = statistic[4].strftime("%Y-%m-%d %H:%M:%S")
            stat_list.append(stat_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["statistic_list"] = stat_list
        return json.dumps(ret_map)
        
    #标签使用排行
    def __create_rank_list_ret(self,rank_list):
        if rank_list is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        ranker_list = []
        for item in rank_list:
            rank_map = {}
            rank_map["app_name"] = item[0]
            rank_map["count"] = item[1]
            rank_map["user_name"] = item[2]
            ranker_list.append(rank_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["rank_list"] = ranker_list
        return json.dumps(ret_map)
        
    #标签最新发布排行
    def __create_publish_rank_list_ret(self,rank_list):
        if rank_list is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        ranker_list = []
        for item in rank_list:
            rank_map = {}
            rank_map["app_name"] = item[0]
            rank_map["user_name"] = item[1]
            ranker_list.append(rank_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["rank_list"] = ranker_list
        return json.dumps(ret_map)


    #构造sql条件(map)
    def __create_where_content(self, search_map):
        if search_map is None:
            return ""

        content_list = []
        for key in search_map:
            value = search_map[key]
            if value == '': 
                continue

            if str(value).startswith('=') \
                    or str(value).startswith('>') \
                    or str(value).startswith('<') \
                    or str(value).startswith('!'):
                content_list.append("%s %s" % (key, value))
                continue
            content_list.append("%s like '%c%s%c' " % (key, '%', value, '%'))
        if len(content_list) <= 0:
            return ''

        where_content = " and ".join(content_list)
        return where_content

    #构建sql语句where条件(list)
    def __create_where_content_by_list(self, search_list):
        if search_list is None:
            return ""

        content_list = []
        for item in search_list:
            key = item[0]
            value = item[1]
            if value == '':
                continue
            
            if str(value).startswith('=') \
                    or str(value).startswith('>') \
                    or str(value).startswith('<') \
                    or str(value).startswith('!'):
                content_list.append("%s %s" % (key, value))
                continue
            content_list.append("%s like '%c%s%c' " % (key, '%', value, '%'))
        if len(content_list) <= 0:
            return ''

        where_content = " and ".join(content_list)
        return where_content


    def __get_default_ret_map(self, status, info):
        ret_map = {}
        ret_map["status"] = status
        ret_map["info"] = info
        return json.dumps(ret_map)


    def __create_show_tagconf_ret(self, count, tagconfs):
        if tagconfs is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        tagconf_list = []
        for tagconf in tagconfs:
            tagconf_map = {}
            tagconf_map["use_count"] = tagconf[0]
            tagconf_map["id"] = tagconf[1]
            tagconf_map["data_type"] = tagconf[2]
            tagconf_map["user_name"] = tagconf[3]
            tagconf_map["app_name"] = tagconf[4]
            tagconf_map["category_type"] = tagconf[5]
            tagconf_map["update_cycle"] = tagconf[6]
            tagconf_map["description"] = tagconf[7]
            tagconf_map["create_time"] = tagconf[8].strftime("%Y-%m-%d %H:%M:%S")
            tagconf_map["update_time"] = tagconf[9].strftime("%Y-%m-%d %H:%M:%S")
            tagconf_list.append(tagconf_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["count"] = count
        ret_map["data_list"] = tagconf_list
        return json.dumps(ret_map)


    def __create_show_owner_data_ret(self, count, datas):
        if datas is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        data_list = []
        for data in datas:
            data_map = {}
            data_map["id"] = data[0]
            data_map["app_name"] = data[1]
            data_map["user_name"] = data[2]
            data_map["owner_name"] = data[3]
            data_map["status"] = data[4]
            data_map["update_time"] = data[5].strftime("%Y-%m-%d %H:%M:%S")
            data_list.append(data_map)

        #data_list基于 update_time逆序排序
        data_list.sort(key=lambda k : k['update_time'], reverse = True)
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["count"] = count
        ret_map["data_list"] = data_list
        return json.dumps(ret_map)

    def __show_processing_center_data_ret(self, count, datas):
        if datas is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        data_list = []
        for data in datas:
            data_map = {}
            data_map["id"] = data[0]
            data_map["app_name"] = data[1]
            data_map["status"] = data[2]
            data_map["update_time"] = data[3].strftime("%Y-%m-%d %H:%M:%S")
            data_list.append(data_map)
  
        #data_list基于 update_time逆序排序
        data_list.sort(key=lambda k : k['update_time'], reverse = True)
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["count"] = count
        ret_map["data_list"] = data_list
        return json.dumps(ret_map)

    def __show_publish_tagconf_history_ret(self, count, datas):
        if datas is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        data_list = []
        for data in datas:
            data_map = {}
            data_map["id"] = data[0]
            data_map["app_name"] = data[1]
            data_map["version"] = data[2]
            data_map["update_time"] = data[3].strftime("%Y-%m-%d %H:%M:%S")
            data_map["create_time"] = data[4].strftime("%Y-%m-%d %H:%M:%S")
            data_list.append(data_map)
        
        #data_list基于 update_time逆序排序
        data_list.sort(key=lambda k : k['update_time'], reverse = True)
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["count"] = count
        ret_map["history_list"] = data_list
        return json.dumps(ret_map)

    def online_apply(self, user_name, app_name):
        if not self.__sql_manager.online_apply(user_name, app_name):
            return self.__get_default_ret_map(1, "write db failed!")

        return self.__get_default_ret_map(0, "OK!")

    def get_all_online_infos(self):
        online_infos = self.__sql_manager.get_all_online_infos()
        if online_infos is None:
            return self.__get_default_ret_map(1, "get online info failed!")

        online_info_list = []
        for info in online_infos:
            tmp_map = {}
            tmp_map["user_name"] = info.user_name
            tmp_map["app_name"] = info.app_name
            tmp_map["time"] = info.time.strftime("%Y-%m-%d %H:%M:%S")
            tmp_map["status"] = info.status
            online_info_list.append(tmp_map)

        #data_list基于 update_time逆序排序
        online_info_list.sort(key=lambda k : k['time'], reverse = True)
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["online_list"] = online_info_list
        return json.dumps(ret_map)

    def confirm_apply(self, user_name, app_name):
        if not self.__sql_manager.confirm_apply(user_name, app_name):
            return self.__get_default_ret_map(1, "write db failed!")
        try:
            tagConf = neptune.models.TagConf.objects.get(user_name=user_name, app_name = app_name)
            pipeline_name = tagConf.pipeline_name
            self.__log.info("user_name:%s, app_name:%s, status=%s" % (user_name, app_name, tagConf.status))
            self.__pipeline_processor.update_pipe(pipeline_name, 1)
        except  exceptions.Exception as ex:
            self.__log.error("ex\n%s", str(ex))
            return self.__get_default_ret_map(1, "update pipeline failed")
        return self.__get_default_ret_map(0, "OK!")

    def reject_apply(self, user_name, app_name):
        if not self.__sql_manager.reject_apply(user_name, app_name):
            return self.__get_default_ret_map(1, "write db failed!")
        return self.__get_default_ret_map(0, "OK!")
