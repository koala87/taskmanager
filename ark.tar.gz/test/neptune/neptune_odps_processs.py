# -*- coding: utf8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import json
import time
import exceptions
import urllib2
import traceback
import re
import string
import tempfile
import logging
import logging.config
import subprocess
import select

import django.contrib.auth.models
from models import TagConf,Publication,Statistic,Relation
from horae import common_logger
import neptune_manager


class OdpsProcessor():
    def __init__(self, cmd_path, user, pwd, project, endpoint, timeout, logger):
        self.__logger = logger
        if logger:
            self.__logger = logger
        else:
            self.__logger = common_logger.get_logger(
                    "user_log",
                    "./log/user_log")

        self.cmd_path = cmd_path
        self.__logger.info("cmd_path=%s" % cmd_path)
        self.user = user
        self.__logger.info("user=%s" % user)
        self.pwd = pwd
        self.__logger.info("pwd=%s" % pwd)
        self.project = project
        self.__logger.info("project=%s" % project)
        self.endpoint = endpoint
        self.__logger.info("endpoint=%s" % endpoint)
        self.timeout = timeout
        self.__logger.info("timeout=%s" % timeout)
        self.param = """%s -u %s -p %s --project=%s --endpoint=%s -M -e """ % (self.cmd_path, self.user, self.pwd, self.project, self.endpoint)
        self.__logger.info("self.param=%s" % self.param)
        self.cmd_tpl = self.param + """ " %s "  2>  %s ;"""
        self.__logger.info("self.cmd_tpl=%s" % self.cmd_tpl)
        return

    def __execute(self, odps_sql):
        stderr_file = tempfile.NamedTemporaryFile()        
        out_file_name = "./%s" % stderr_file.name.split("/")[-1]
        cmd_str = self.cmd_tpl % (odps_sql, out_file_name)
        self.__logger.info("cmd_str = %s" % cmd_str)
        try:
            ret = os.system(cmd_str)
            if 0 != ret:
                os.system("rm -f %s " % out_file_name)
                return False
            error_pattern = re.compile("FAILED:")
            fin = open(out_file_name)
            err = fin.read()
            self.__logger.info("err=%s" % err)
            fin.close()
            os.system("rm -f %s " % out_file_name)
            if error_pattern.search(err):
                return False
        except Exception as e:
            self.__logger.error("exception:%s" % str(e))
            return False
        return True

    def drop_table(self, table_name):
        odps_sql = "drop table %s;" % table_name
        ret = self.__execute(odps_sql)
        return ret

    #创建odps表
    #@param table_name odps table
    #@param column_list 创建的列配置，[(clumn_name, clumn_type),]
    #@param partion_list 创建的partition 配置[(partition_name, partition_list)]
    #@param lifecycle 生命周期
    def create_table(self, table_name, column_list, partition_list, lifecycle = 7):
        column_str_list = []
        for kv in column_list:
            if len(kv) < 2:
                continue
            column_str_list.append('%s %s' % (kv[0], kv[1]))
        column_config_str = ",".join(column_str_list)
        partition_str_list = []
        for kv in partition_list:
            if len(kv) < 2:
                continue
            partition_str_list.append('%s %s' % (kv[0], kv[1]))
        partition_config_str = ",".join(partition_str_list)
        create_table_sql = "create table %s ( %s ) partitioned by ( %s ) lifecycle %s ;" % (table_name, column_config_str, partition_config_str, lifecycle)
        self.__logger.info("create odps table sql:%s" % create_table_sql)
        return self.__execute(create_table_sql)


