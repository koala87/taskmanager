#encoding:utf-8

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import json
import time
import exceptions
import urllib2
import traceback
import re
import string
import logging
import logging.config
import subprocess
import tempfile
import select

import django.contrib.auth.models
from models import TagConf,Publication,Statistic,Relation
from horae import common_logger
import neptune_manager


class OtsProccessor():
    def __init__(self, console_path, endpoint, access_id, access_secret, instance, logger = None, timeout=3600):
        self.__logger = logger
        if logger:
            self.__logger = logger
        else:
            self.__logger = common_logger.get_logger(
                    "user_log",
                    "./log/user_log")
        self.console_path = "java -jar %s" % console_path
        self.__logger.info("console_path=%s" % self.console_path)
        self.endpoint = endpoint
        self.__logger.info("endpoint=%s" % self.endpoint)
        self.access_id = access_id
        self.__logger.info("access_id=%s" % self.access_id)
        self.access_secret = access_secret
        self.__logger.info("self.access_secret=%s", self.access_secret)
        self.instance = instance
        self.__logger.info("self.instance=%s", self.instance)
        self.ots_cmd_tpl = " %s "
        self.timeout = timeout
        self.__logger.info("timeout=%s", self.timeout)
        #self.__env_init()
        return

    def __execute_ots_cmd(self, cmd_str):
        stdout_file = tempfile.NamedTemporaryFile()
        out_file_name = "./%s" % stdout_file.name.split("/")[-1]
        cmd_str = cmd_str + " > %s " % out_file_name 
        cmd_str = "./ots_cmd/my_ots_client  %s" % cmd_str
        self.__logger.info("execute_ots_cmd:%s" % cmd_str)
        try:
            ret = os.system(cmd_str)
            self.__logger.info("os.system(cmd_str):ret=%s" % ret)
            if 0 != ret:
                return False
            self.__logger.info("out file name:%s" % out_file_name)
            fin =  open(out_file_name, 'r')
            res = fin.read().strip()
            self.__logger.info("__execute_ots_cmd res:%s" % res)
            fin.close()
            os.system("rm -f %s" % out_file_name)
            self.__logger.info("execute res:%s" % res)
            success_pattern = re.compile("SUCCESS")
            if success_pattern.search(res):
                self.__logger.info("execute ots cmd success")
                return True
            self.__logger.error("execute ots cmd failed")
            return False
        except Exception as e:
            self.__logger.error("exception:%s" % e.message)
            return False
        return False

    
    #@param table_name  table_name
    #@param  primary_key_pair_list [(primary_key_name, primary_key_type]
    def create_ots_table(self, table_name, primary_key_pair_list, ttl = 192800, max_version = 1, readReserve=5000, writeReserve=5000):
        l = []
        for primary_key_pair in primary_key_pair_list:
            if len(primary_key_pair) < 2:
                return False
            #l.append('\"%s\":%s' % (primary_key_pair[0], primary_key_pair[1]))
            l.append(primary_key_pair[0])
        kv_str = ",".join(l)
        cmd_str = "ct %s %s %s %s" % (table_name, kv_str,  max_version,  ttl)
        execute_cmd_str =  self.ots_cmd_tpl  % cmd_str
        ret = self.__execute_ots_cmd(execute_cmd_str)
        self.__logger.info("create ret result=%s" % ret)
        return ret


    def delete_ots_table(self, table_name):
        cmd_str = 'dt %s' % table_name
        execute_cmd_str = self.ots_cmd_tpl  % cmd_str
        ret = self.__execute_ots_cmd(execute_cmd_str)
        self.__logger.info("delete table result=%s" % ret)
        return ret

