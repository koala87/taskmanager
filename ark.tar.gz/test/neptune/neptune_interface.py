﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
neptune前端工具接口

Authors: ronghang.rh(hang.rong@shenma-inc.com)
"""


import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import json
import time
import exceptions
import logging

import django.contrib.auth.models
from models import TagConf,Publication,Statistic,Relation
from horae import common_logger

import neptune_manager
import neptune_ots_process

#log/user_log
__log = common_logger.get_logger(
        "rh_log",
        "./log/rh_log")

class NeptuneInterface():
    """
        数据标签前端工具接口
    """
    def __init__(self,logger=None):
        neptune_logger = None
        if logger is not None:
            neptune_logger = logger
        else:
            neptune_logger = common_logger.get_logger(
                    "common", 
                    "./log/neptune")

        self.__neptune_mgr = neptune_manager.NeptuneManager(
                neptune_logger)
        self.__log = common_logger.get_logger(
                "user_log",
                "./log/user_log")


    def get_statistic_by_catetype(self,category_type,date_time):

        """
        根据category_type获取指定时间的data_size、uv指标

        Args:
            category_type: string 数据的标签类型，
                                用户接入时选择的数据对应的类型
            date_time: string 数据对应的日期

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "data_size": 200,  # data_size
                "uv": 100  $uv总数
            }

        Raises:
            No.
        """

        ret = self.__neptune_mgr.get_statistic_by_catetype(
                category_type,
                date_time)
        self.__log.info('get_statistic_by_catetype is start')
        return ret


    def get_statistic_by_time_distance(
            self,
            user_name, 
            app_name,
            date_time,
            time_distance):
        """
        获取一段时间的data_size、uv波动统计
        Args:
            user_name: string 接入数据的用户名
            app_name: string 接入的数据名
            date_time: string 数据对应的日期
            time_distance int 时间区间（1天,7天,30天可选）
            
        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "statistic_list": [
                    {
                        "user_name": "rongh", 
                        "app_name": "爱好",
                        "data_size": 100, 
                        "uv": 200,
                        "date_time": "2015-05-19 10:00:00", 
                    }, 
                ]
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.get_statistic_by_time_distance(
                user_name,
                app_name,
                date_time,
                time_distance)

        self.__log.info('get_statistic_by_time_distance is start')
        return ret


    def insert_data_statistic_info(
            self,
            user_name,
            app_name,
            category_type,
            uv,
            data_size,
            date_time):
        """
        接入数据统计信息
        Args:
            user_name: string 接入数据的用户名
            app_name: string 接入的数据名
            category_type: string 数据的标签类型，
                                用户接入时选择的数据对应的类型
            uv: int uv
            data_size: int 数据大小
            date_time: "2015-05-19 10:00:00" string 数据对应的日期

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.insert_data_statistic_info(
                user_name,
                app_name,
                category_type,
                uv,
                data_size,
                date_time)
        self.__log.info('insert_data_statistic_info is start')
        return ret


    def update_data_statistic_info(
            self,
            user_name,
            app_name,
            category_type,
            uv,
            data_size,
            date_time):
        """
        更新数据统计信息
        Args:
            user_name: string 接入数据的用户名
            app_name: string 接入的数据名
            category_type: string 数据的标签类型，
                                用户接入时选择的数据对应的类型
            uv: int uv
            data_size: int 数据大小
            update_time: "2015-05-19 10:00:00" string 更新时间

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.update_data_statistic_info(
                user_name,
                app_name,
                category_type,
                uv,
                data_size,
                date_time)
        self.__log.info('update_data_statistic_info is start')
        return ret

    def delete_data_statistic_info(
            self,
            user_name,
            app_name):
        """
        删除指定的user_name，app_name的统计数据
        Args:
            user_name: string 接入数据的用户名
            app_name: string 接入的数据名
        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """

        ret = self.__neptune_mgr.delete_data_statistic_info(
                user_name,
                app_name)

        self.__log.info('delete_data_statistic_info is start')
        return ret

    def label_use_ranking(self):
        """
        标签使用排行(前十)

        Args:
            None.
        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "rank_list": [
                    {
                        "app_name": "ali_searchlog_NBA",
                        "count": 235,
                    },
                    {
                        "app_name": "ali_searchlog_people",
                        "count": 350,
                    },
                ]
            }

        """
        ret = self.__neptune_mgr.label_use_ranking()
        self.__log.info('label_use_ranking is start')
        return ret


    def latest_publish_ranking(self):
        """
        最新发布排行(前十)
        Args:
            None.
        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "rank_list": [
                    {
                        "app_name": "ali_searchlog_NBA",
                        "user_name": "rongh",
                    },
                    {
                        "app_name": "ali_searchlog_people",
                        "user_name": "rongh",
                    },
                ]
            }
        """
        ret = self.__neptune_mgr.latest_publish_ranking()
        self.__log.info('latest_publish_ranking is start')
        return ret
        

    def tagconf_auth(
            self,
            user_names,
            owner_name,
            app_name,
            action):
        """
        数据标签权限管理

        Args:
            user_names: string 授予权限的用户(授予权限时，是list,其他操作就是user_name字符串)
            owner_name: string 应用标签的持有者
            app_name: string 标签名称
            action: int 动作，参见AuthAction

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.tagconf_auth(
                user_names,
                owner_name,
                app_name,
                action)
        self.__log.info('grant_perm is start,(user_names: %s, owner_name: %s, app_name: %s, action: %s, ret%s)' % (user_names, owner_name, app_name, action, ret))
        return ret
        
    def get_all_ots_user_relation(self):
        """
        获取ots表对应的用户关系
        Args:
            None.

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "relation":{
                    "ots_table1":["user1", "user2"],
                    "ots_table2":["user2", "user3"]
                    ... 
                }
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.get_all_ots_user_relation()
        self.__log.info('get_all_ots_user_relation is start')
        return ret

    def get_user_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):
        """
        查询用户与数据权限关系

        Args:
            user_name: string 用户名
            owner_name: string 应用标签的持有者
            app_name: string 标签名称

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "auth" : 1 #参见RelationStatus
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.get_user_tagconf_auth(
                user_name,
                owner_name,
                app_name)
        self.__log.info('get_user_tagconf_auth is start(user_name: %s, owner_name: %s, app_name: %s, ret: %s)' % (user_name, owner_name, app_name, ret))
        return ret

    
    #标签数据列表
    def show_tagconf_info(
            self,
            owner_name,
            page_min,
            page_max,
            order_field,
            sort_order,
            search_map):
        """
        获取数据标签列表，支持排序，翻页，搜索

        Args:
            owner_name: string 用户名
            page_min: int 翻页最小索引
            page_max：int 翻页最大索引
            order_field: string 排序字段
                (限为publication_time,update_time,use_count)

            sort_order: string 排序方式 'desc'降序 'asc'升序
            search_map: 搜索框内容 需要搜索的字段map.

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "count": 2,  # 总数
                "data_list": [
                    {
                        "use_count":200, #使用次数
                        "data_type": 0, #标签数据or高质量数据
                        "user_name": "rongh", #用户名
                        "app_name": "test_app1", #应用名
                        "category_type": "category",#标签类型
                        "update_cycle": 0, #数据更新周期，天级or小时级
                        "crontab_conf": "8 * * * *", 定时启动时间配置
                        "overtime": 20, #超时时间
                        "test_time": 20, #初次运行测试时间
                        "protect_level": 0, #数据保护级别
                        "version": 0, #数据版本
                        "status": 0, #0未发布，1发布失败，2发布成功
                        "schema_file": "path", #用户上传的数据schema的文档路径
                        "description": "", #描述
                        "data_config": "", #数据配置信息
                        "raw_odps_table": "", #接入后的odps表名
                        "algin_odps_table": "", #id对齐后的odps表名
                        "ots_table": "", #对应ots表名
                        "create_time": "2015-05-19 10:00:00", #创建时间
                        "update_time": "2015-05-19 10:00:00", #更新时间
                        "id": 1, 
                    }, 
                ]
            }
            列表长度最大为page_max - page_min，
            并按照order_field排序

        Raises:
            No.
        """
        page_min = page_min - 1
        ret = ''
        self.__log.info("show_pipeline_info  owner_name: %s, "
                "page_min: %s, page_max: %s, order_field: %s, "
                "sort_order: %s, search_str: %s" % (
                owner_name, page_min, page_max, order_field, 
                sort_order, search_map))
        ret = self.__neptune_mgr.show_tagconf_info(
                owner_name, 
                page_min, 
                page_max, 
                order_field, 
                sort_order,
                search_map)
        self.__log.info("show_pipeline_info  owner_name: %s, "
                "page_min: %s, page_max: %s, order_field: %s, "
                "sort_order: %s, search_str: %s, ret:%s" % (
                owner_name, page_min, page_max, order_field, 
                sort_order, search_map, ret))

        return ret


    #获取所有标签分类
    def get_all_category_type(self):
        """
        获取所有标签分类
        Args:
            None.

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "category_types":[
                    {
                        "category_type":"category_type1",
                        "count":15   #当前category_type下的标签数
                    }
                
                ]
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.get_all_category_type()
        self.__log.info('get_all_category_type is start')
        return ret
    
    #获取标签详细信息
    def get_tagconf_info(self,user_name,app_name):
        """
        通过app_name获取数据标签的信息

        Args:
            app_name: string app_name

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "tagconf":
                {       
                    "use_count":200, #使用次数
                    "data_type": 0, #标签数据or高质量数据
                    "user_name": "rongh", #用户名
                    "app_name": "test_app1", #应用名
                    "category_type": "category",#标签类型
                    "update_cycle": 0, #数据更新周期，天级or小时级
                    "crontab_conf": "8 * * * *", 定时启动时间配置
                    "overtime": 20, #超时时间
                    "test_time": 20, #初次运行测试时间
                    "protect_level": 0, #数据保护级别
                    "version": 0, #数据版本
                    "status": 0, #0未发布，1发布失败，2发布成功
                    "schema_file": "path", #用户上传的数据schema的文档路径
                    "description": "", #描述
                    "data_config": "", #数据配置信息
                    "raw_odps_table": "", #接入后的odps表名
                    "algin_odps_table": "", #id对齐后的odps表名
                    "ots_table": "", #对应ots表名
                    "create_time": "2015-05-19 10:00:00", #创建时间
                    "update_time": "2015-05-19 10:00:00", #更新时间
                    "id": 1, 
                    "owner_list": ["user_name1","user_name2"...]
                    "apply_list": ["user_name1","user_name2"...]
                } 
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.get_tagconf_info(user_name,app_name)
        self.__log.info('get_tagconf_info is start')
        return ret

    #获取数据标签owner_list/apply_list
    def get_tagconf_owner_apply_list(self,app_name,type):
        """
        通过app_name获取数据标签应用方

        Args:
            app_name: string app_name
            type:int 0:应用方; 1:权限申请列表

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "owner_list": ["user_name1","user_name2"...] / "apply_list": ["user_name1","user_name2"...]
            } 

        """
        ret = self.__neptune_mgr.get_tagconf_owner_apply_list(app_name,type)
        self.__log.info('get_tagconf_info is start')
        return ret


    #获取我的数据/订阅数据
    def get_owner_subscribe_data(
            self,
            is_owner,
            owner_name,
            page_min,
            page_max):
        """
        获取我的数据/订阅数据

        Args: 
            is_owner：int 2表示订阅，3表示owner数据 参见RelationStatus
            owner_name: string 用户名
            page_min: int 翻页最小索引
            page_max：int 翻页最大索引
             
        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "count": 2,  # 总数
                "data_list": [
                    {
                        "id":1,
                        "app_name":"test_app1", #应用名
                        "user_name":"rongh" #用户名
                        "owner_name":"rongh" #产出方
                        "status":2  订阅状态
                        "update_time": "2015-05-19 10:00:00", #更新时间
                    },
                    {
                        ...
                    }
                ]
            }
        Raises:
            No.
        """
        page_min = page_min - 1
        ret = self.__neptune_mgr.get_owner_subscribe_data(
                is_owner,
                owner_name,
                page_min,
                page_max)
        self.__log.info('get_owner_subscribe_data is start')
        return ret

    #我的数据操作
    def owner_data_operate(
            self,
            app_name,
            owner_name,
            action,
            time_str):
        """
        我的数据操作（回滚，下线）
        Args:
            app_name: string 应用名
            owner_name: string 用户名
            action : 0表示回滚，1表示下线
            time_str:回滚的时间,如果是下线可以放空,格式为201509290101

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """

        ret = self.__neptune_mgr.owner_data_operate(
                app_name,
                owner_name,
                action,
                time_str)
        self.__log.info('owner_data_operate is start')
        return ret
    
    #处理中心
    def processing_center_info(
            self,
            user_name,
            process_status,
            page_min,
            page_max):
        """
        获取处理中心数据（全部、处理中、发布失败、未发布）

        Args:
            user_name: string 当前用户名
            process_status: int (0,1,2,3,4 分别对应：未发布、发布失败、处理中、发布成功、全部)
            page_min: int 翻页最小索引
            page_max：int 翻页最大索引

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "count": 2,  # 总数
                "data_list": [
                    {
                        "id":1,
                        "app_name":"test_app1", #应用名
                        "status":2  (0,1,2,3 对应：未发布、发布失败、处理中、发布成功)
                        "update_time": "2015-05-19 10:00:00", #更新时间
                    },
                    {
                        ...
                    }
                ]
            }
        Raises:
            No.
        """
        page_min = page_min - 1
        ret = self.__neptune_mgr.processing_center_info(
                user_name,
                process_status,
                page_min,
                page_max)
        self.__log.info('processing_center_info is start')
        return ret

    def publish_tagconf_data(self,tagconf):
        """
        处理中心 发布数据

        Args:
            tagconf：一个TagConf实例(详见neptune/models.py)

        Returns:
            返回一个状态，以及一个字符串，
            状态为0表示成功，其他失败
            字符串表示失败原因，成功则为‘OK’
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.publish_tagconf_data(tagconf)
        self.__log.info('publish_tagconf_data is start')
        return ret

    def publish_tagconf_history(
            self,
            owner_name,
            page_min,
            page_max):
        """
        获取发布历史

        Args:
            owner_name: string 当前用户名
            page_min: int 翻页最小索引
            page_max：int 翻页最大索引

        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "count": 2,  # 总数
                "history_list":[
                    {
                        "id":1,
                        "app_name":"test_app1", #应用名
                        "version":"1.0.1", #版本号
                        "update_time": "2015-09-19 10:00:00", #更新时间
                        "create_time": "2015-05-19 10:00:00", #发布时间
                    },
                    {
                        ...
                    }
                ]
            }
        Raises:
            No.
        """
        page_min = page_min - 1
        ret = self.__neptune_mgr.publish_tagconf_history(
                owner_name,
                page_min,
                page_max)
        self.__log.info('publish_tagconf_history is start')
        return ret

    def update_tagconf_data(
            self,
            tagconf_id,
            user_name,
            update_map):
        """
        查看个人数据详情页   修改数据

        Args:
            tagconf_id: int tagconf id
            user_name : string 当前用户名
            update_map：修改tagconf的map 如{"name":"test","update_cycle":0,...}

        Returns:
            返回一个状态，以及一个字符串，
            状态为0表示成功，其他失败
            字符串表示失败原因，成功则为‘OK’
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.update_tagconf_data(tagconf_id,user_name,update_map)
        self.__log.info('update_tagconf_data is start')
        return ret

    def update_tagconf_config(
            self,
            tagconf_id,
            user_name,
            tagconf):
        """
        编辑未发布数据

        Args:
            tagconf_id: int tagconf id
            user_name : string 当前用户名
            tagconf：一个TagConf实例(详见neptune/models.py)

        Returns:
            返回一个状态，以及一个字符串，
            状态为0表示成功，其他失败
            字符串表示失败原因，成功则为‘OK’
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.update_tagconf_config(
                tagconf_id,user_name,tagconf)
        self.__log.info('update_tagconf_config is start')
        return ret

    def get_user_contact_info(
            self, 
            user_name):
        """
        传入用户名，获取用户对应的联系方式，
        Args:
            user_name: string 当前用户名
        Returns:
            return {"user":user_name, "email":""}
        """
        try:
            user_info = django.contrib.auth.models.User.objects.get(
                                        username=user_name)
            return {"user_name":user_name, "email":user_info.email}
        except  exceptions.Exception as ex:
            print "ex: %s"  % str(ex)
            self.__log.error('ex: %s' % str(ex))
            return {"user_name":user_name, "email":""}


    def get_all_applied_users(self, owner_name, app_name):
        """
        输出所有申请过的用户的数据
        """
        user_list = self.__neptune_mgr.get_all_authority_users(owner_name, app_name, 1)
        return user_list

    def get_authorited_users(self, owner_name, app_name):
        """ 
        输出所有被授权的用户的数据
        """
        user_list = self.__neptune_mgr.get_all_authority_users(owner_name, app_name, 2)
        return user_list

    def get_except_users(self, owner_name, app_name):
        """
        输出所有用户的数据
        """
        except_set = set()
        applied_set = set(self.get_all_applied_users(owner_name, app_name))
        athorized_set = set(self.get_authorited_users(owner_name, app_name))
        owner_set = set([owner_name])
        except_set = except_set.union(applied_set)
        except_set = except_set.union(athorized_set)
        except_set = except_set.union(owner_set)
        all_user = self.__neptune_mgr.get_all_ark_users()
        user_list = []
        for user in all_user:
            if user not in except_set:
                user_list.append(user)
        return user_list

    #用户直接接入并请求上线的逻辑
    def save_user_app_conf(self, conf_str):
        return self.__neptune_mgr.save_user_app_conf(conf_str)

    #用户未发布数据点击发布按钮后的逻辑`
    def apply_public_operation(self, user_name, app_name):
        return self.__neptune_mgr.apply_public_operation(user_name, app_name)

    def create_user_app(self, conf_str):
        return self.__neptune_mgr.create_user_app(conf_str)

    def get_user_public_and_buy_data_count(self, user_name):
        return self.__neptune_mgr.get_user_public_and_buy_data_count(user_name)

    def get_all_user_process_data_count(self, user_name):
        return self.__neptune_mgr.get_all_user_process_data_count(user_name)

    def delete_user_app(self, user_name, app_name):
        return self.__neptune_mgr.delete_user_app(user_name, app_name)

    def modify_user_app(self, user_name, app_name, action, value):
        pass

    def recreate_user_app(self, conf):
        return self.__neptune_mgr.recreate_user_app(conf)

    def online_apply(self, user_name, app_name):
        """
        用户申请上线

        Args:
            user_name: string 用户名
            app_name : string 请求上线的app名字

        Returns:
            返回一个状态，以及一个字符串，
            状态为0表示成功，其他失败
            字符串表示失败原因，成功则为‘OK’
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.online_apply(user_name, app_name)
        self.__log.info(
                'online_request:(user_name: %s, '
                'app_name: %s, ret: %s)' % (
                user_name, app_name, ret))
        return ret

    def get_all_online_infos(self):
        """
        获取所有的上线信息

        Args:
            
        Returns:
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
                "online_list":[
                    {
                        "id":1,
                        "user_name":"test_app1", # 请求上线的用户名
                        "app_name":"1.0.1", # 请求上线的app名字
                        "status": 0, # 0代表请求上线，1同意
                        "time": "2015-05-19 10:00:00", #发布时间
                    },
                    {
                        ...
                    }
                ]
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.get_all_online_infos()
        self.__log.info('get_all_online_infos:(ret: %s)' % ret)
        return ret

    def confirm_apply(self, user_name, app_name):
        """
        确认用户申请上线

        Args:
            user_name: string 用户名
            app_name : string 请求上线的app名字

        Returns:
            返回一个状态，以及一个字符串，
            状态为0表示成功，其他失败
            字符串表示失败原因，成功则为‘OK’
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.confirm_apply(user_name, app_name)
        self.__log.info(
                'confirm_apply:(user_name: %s, '
                'app_name: %s, ret: %s)' % (
                user_name, app_name, ret))
        return ret

    def reject_apply(self, user_name, app_name):
        """
        拒绝用户申请上线

        Args:
            user_name: string 用户名
            app_name : string 请求上线的app名字

        Returns:
            返回一个状态，以及一个字符串，
            状态为0表示成功，其他失败
            字符串表示失败原因，成功则为‘OK’
            {
                "status": 0,  # 0 成功，其他失败
                "info": "OK",  # 失败原因
            }

        Raises:
            No.
        """
        ret = self.__neptune_mgr.reject_apply(user_name, app_name)
        self.__log.info(
                'reject_apply:(user_name: %s, '
                'app_name: %s, ret: %s)' % (
                user_name, app_name, ret))
        return ret

    def test_ots(self):
        #just for test
        ots_console_path = '/home/xiangyu.liu/xiangyu.liuxy/dev/dev/ots_console'
        ots_endpoint = "http://sm-searchlog.ali-cn-shanghai.ots.aliyuncs.com"
        ots_access_id = "H8Dbi0rvLOPEJxSz"
        ots_access_secret = "WGHiplLIReH33RskKXFQuvginTka46"
        instance = "sm-searchlog"
        ots = neptune_ots_process.OtsProccessor(ots_console_path, ots_endpoint, ots_access_id, ots_access_secret, instance, self.__log)
        ots.create_ots_table("ods_sm_id_relationship_private_test", [("primary_key", "STRING")])
        ots.delete_ots_table('ods_sm_id_relationship_private_test')
        





























