#coding=utf-8
from common.models import Message
from django.contrib.auth.decorators import login_required
from common.http_helper import JsonHttpResponse
from horae import common_logger
logger = common_logger.get_logger('neptune_message', './log/neptune_message')

login_url='/tag_login/'
NEPTUNE_MSG_TYPES = [Message.TYPE_NEPTUNE_PERM, Message.TYPE_NEPTUNE_ONLINE]

@login_required(login_url=login_url)
def delete(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'info': '支持post请求'})

    id = request.POST.getlist('id[]')
    try:
        Message.objects.delete(id = id)
    except Exception, ex:
        logger.error('delete message fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'info': str(ex)})

    return JsonHttpResponse({'status': 0, 'info': 'OK'})


@login_required(login_url=login_url)
def read(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'info': '支持post请求'})

    id = request.POST.getlist('id[]')
    try:
        Message.objects.read(id = id, receiver = request.user)
    except Exception, ex:
        logger.error('read message fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'info': str(ex)})

    return JsonHttpResponse({'status': 0, 'info': 'OK'})


@login_required(login_url=login_url)
def get_unread_num(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'info': '支持post请求'})

    try:
        messages = Message.objects.list(request.user, False)
        messages = messages.filter(type__in = NEPTUNE_MSG_TYPES)
        return JsonHttpResponse({'status': 0, 'count': messages.count()})
    except Exception, ex:
        logger.error('get unread num fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'info': str(ex)})


@login_required(login_url=login_url)
def get_each_type_num(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'info': '支持post请求'})

    try:
        messages = Message.objects.list(request.user)
        messages = messages.filter(type__in = NEPTUNE_MSG_TYPES)

        nums = {'total': messages.count(),
                'perm': messages.filter(type = Message.TYPE_NEPTUNE_PERM).count(),
                'online': messages.filter(type = Message.TYPE_NEPTUNE_ONLINE).count(),}

        return JsonHttpResponse({'status': 0, 'data': nums})
    except Exception, ex:
        logger.error('get unread num fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'info': str(ex)})


def gen_message_data(messages):
    data = []
    for message in messages:
        data.append({
                'id': message.id,
                'content': message.content,
                'create_time': str(message.create_time),
                'read': message.read,
                'type': message.type,
                })
    return data

@login_required(login_url=login_url)
def list(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'info': '支持post请求'})

    try:
        page = request.POST.get('page')
        page_size = request.POST.get('page_size')
        if page == '':
            page = 1
        if page_size == '':
            page_size = 6
        page = int(page);
        page_size = int(page_size);
        start_idx = page_size*(page-1)
        end_idx = page_size*page

        messages = Message.objects.list(request.user)
        #start_idx = request.POST.get('index_min', 0)
        #end_idx = request.POST.get('index_max', start_idx + 10)

        type = request.POST.get('type')
        try:
            type = long(type)
        except:
            type = None
        if type is not None:
            messages = messages.filter(type = type)
        else:
            messages = messages.filter(type__in = NEPTUNE_MSG_TYPES)
        message_data = gen_message_data(messages[start_idx:end_idx])
        pagination = {}
        pagination['index_min'] = start_idx
        pagination['index_max'] = end_idx

        return JsonHttpResponse(
            {'status': 0, 
             'info': 'OK',
             'data': message_data,
             'pagination': pagination,
             'count': messages.count(),
             })
    except Exception, ex:
        logger.error('list message fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'info': str(ex)})

    return JsonHttpResponse({'status': 0, 'info': 'OK'})
