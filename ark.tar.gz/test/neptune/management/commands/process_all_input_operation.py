import logging
import time
import traceback
from django.conf import settings
from horae import common_logger 
logger = logging.getLogger(settings.PROJECT_NAME)
from django.core.management.base import BaseCommand, CommandError
from ark_user.admin import alarm
from neptune.neptune_manager import NeptuneManager

class Command(BaseCommand):
    def handle(self, *args, **options):
        neptune_logger = common_logger.get_logger(\
                "common",
                "./log/neptune")
        neptune_manager = NeptuneManager(neptune_logger)
        while(True):
            print neptune_manager.process_all_user_app_action()
            time.sleep(60)



