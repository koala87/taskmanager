﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: ronghang.rh(hang.rong@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import copy
import random

import django.test
import neptune.models
import common.models
import dms.models

import exceptions
import neptune_interface
import neptune_manager
import pipeline_process
import neptune_odps_processs
import neptune_ots_process
import django.contrib.auth.models
from horae import common_logger
#import horae.common_logger

class TestPipelineProcess(django.test.TestCase): 
    """
    测试PipelineProcess
    """
    
    def setUp(self):
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")
        self.__neptune_logger = common_logger.get_logger(
                "common", 
                "./log/neptune")
        self.__p = pipeline_process.PipelineProcess('xiangyu.liu', 'ting0310', '10.181.204.100', '9999', self.__neptune_logger)
        cmd_path = "/home/xiangyu.liu/xiangyu.liuxy/scripts/odps/bin/odpscmd"
        user = "JEtRWGlRrEPkqNpw"
        pwd = "NzrPjfMseoTJ4UoZKw5858aRtUcNk9"
        project = "aliyun_searchlog"
        endpoint = "http://service.odps.aliyun-inc.com/api"
        timeout = 3600
        self.__odps = neptune_odps_processs.OdpsProcessor(cmd_path, user, pwd, project, endpoint, timeout, self.__neptune_logger)

        ots_console_path = '/home/xiangyu.liu/xiangyu.liuxy/dev/dev/ots_console'
        ots_endpoint = "http://sm-searchlog.ali-cn-shanghai.ots.aliyuncs.com"
        ots_access_id = "H8Dbi0rvLOPEJxSz"
        ots_access_secret = "WGHiplLIReH33RskKXFQuvginTka46"
        instance = "sm-searchlog"
        self.ots_processor = neptune_ots_process.OtsProccessor(ots_console_path, ots_endpoint, ots_access_id, ots_access_secret, instance, self.__neptune_logger)



    def testPipelineProcess(self):
        print "test pipeline"
        print self.__p.create_pipeline('neptune_test_001', '1 2 * * *', 0)
        print self.__p.check_pipeline('neptune_test_001')
        check_partition_task_dict = {'name':'check_partition', 'over_time':'36000', 'processor_name':'check_partition_exists_processor', 'log_file':'check_partition_log', \
                'odpscmd_path':'/home/admin/ha_pe_work/log_analysis/ucweblog/clt/bin/odpscmd', 'odps_user':'', 'odps_pw':'', 'odps_project':'', 'table_name':'', 'partition_str':'', \
                'endpoint_str':''}
        print self.__p.add_task('neptune_test_001', check_partition_task_dict)
        check_partition_task_dict2 = {'name':'check_partition2', 'over_time':'36000', 'processor_name':'check_partition_exists_processor', 'log_file':'check_partition_log', \
                'odpscmd_path':'/home/admin/ha_pe_work/log_analysis/ucweblog/clt/bin/odpscmd', 'odps_user':'', 'odps_pw':'', 'odps_project':'', 'table_name':'', 'partition_str':'', \
                'endpoint_str':''}
        print self.__p.add_task('neptune_test_001', check_partition_task_dict2)
        print self.__p.add_edge('neptune_test_001', 'check_partition', 'neptune_test_001','check_partition2') 
        print self.__p.delete_pipeline('neptune_test_001')

    def testRmPipe(self):
         print self.__p.stop_pipe("usertag_platform_auto_29008CB4552800CF44FB89D0A2B7BA4F_pl")
         print self.__p.delete_pipeline("usertag_platform_auto_29008CB4552800CF44FB89D0A2B7BA4F_pl")

    def testRunPipe(self):
        #print self.__p.run_pipe('usertag_platform_auto_60450E685D88CC932E349BF667244110_pl', '201511031753')
        print self.__p.create_pipeline('usertag_platform_auto_29008CB4552800CF44FB89D0A2B7BA4F_pl', '1 2 * * *', 0)

    def testOdps(self):
        column_list = [("sm_id", "string"), ("data_str", "string")]
        partition_list = [("day", "string"), ("hour", "string")]
        print "test odps"
        print self.__odps.create_table("odps_processor_lxy_test", column_list, partition_list, 10)
        print self.__odps.drop_table("odps_processor_lxy_test")

    def testOts(self):
        print "test ots"
        print self.ots_processor.create_ots_table("ods_sm_id_relationship_private_test", [("primary_key", "STRING")])
        print self.ots_processor.delete_ots_table('ods_sm_id_relationship_private_test')




        
