﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
neptune db操作

Authors: ronghang.rh(hang.rong@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import exceptions
import time
import traceback
import logging
import copy

import enum
import django.db
import neptune.models
import django.db.models
import django.core.exceptions
import django.contrib.auth.models
from horae import tools_util
import neptune.tools_utils

from common.odps import OdpsPrivilege
from dms.odps_data import OdpsData, SITE_ACCESS_ID, SITE_ACCESS_KEY

class ConstantSql(enum.Enum):
    SHOW_ALL_TAGCONF_INFO_ALL_COUNT = (
                       "select count(id) from neptune_tagconf "
                                  "where data_type = 0 %s;")

    SHOW_TAGCONF_INFO_ALL1 = (
            "select a1.*,b1.use_count from ("
            "   select * from neptune_tagconf where data_type=0 %s"
            "   order by %s %s limit %s, %s )a1 "
            "   left outer join( "
            "       select app_name,count(user_name) as use_count"
            "       from neptune_relation where status = 2 group by app_name)b1"
            "   on a1.app_name = b1.app_name")

    SHOW_TAGCONF_INFO_ALL = (
            "select b1.use_count, a1.id, a1.data_type, a1.user_name, "
            "a1.app_name, a1.category_type, a1.update_cycle, "
            "a1.description, a1.update_time, a1.create_time "
            "from( "
            "   select * from neptune_tagconf "
            "   where status = 3 and data_type = 0 %s  "
            ")a1 "
            "left outer join ( "
            "   select app_name,count(user_name) as use_count from neptune_relation "
            "   where status = 2 group by app_name)b1 "
            "   on a1.app_name = b1.app_name  order by a1.%s %s limit %s, %s ;")

    SHOW_TAGCONF_INFO_ORDER_BY_PUBLISH_TIME = (
            "select b1.use_count, a1.id, a1.data_type, a1.user_name, "
            "a1.app_name, a1.category_type, a1.update_cycle, "
            "a1.description, a1.update_time, a1.create_time "
            "from( "
            "   select * from neptune_tagconf "
            "   where status = 3 and data_type = 0 %s  "
            ")a1 "
            "left outer join ( "
            "   select app_name,count(user_name) as use_count from neptune_relation "
            "   where status = 2 group by app_name)b1 "
            "   on a1.app_name = b1.app_name  order by a1.create_time %s limit %s, %s ;")


    SHOW_TAGCONF_INFO_ORDER_BY_USE_COUNT = (

            "select b1.use_count, a1.id, a1.data_type, a1.user_name, "
            "a1.app_name, a1.category_type, a1.update_cycle, "
            "a1.description, a1.update_time, a1.create_time "
            "from( "
            "   select * from neptune_tagconf "
            "   where status = 3 and data_type = 0 %s "
            ")a1 "
            "left outer join ( "
            "   select app_name,count(user_name) as use_count from neptune_relation "
            "   where status = 2 group by app_name )b1  on b1.app_name=a1.app_name order by b1.%s %s limit %s, %s ;")

  

    GET_USER_SUPER_USERIFIEDS = (
            "select is_superuser from auth_user where username= \'%s\';")


    GET_USER_BUY_DATA_COUNT = (
            "select count(distinct owner_name, app_name) from neptune_relation where user_name=\'%s\' and status=2;"
            )

    GET_USER_PUBLIC_DATA_COUNT = (
            "select count(distinct app_name) from  neptune_relation where owner_name=\'%s\' and status=3;"
            )

    GET_USER_PROCESS_DATA_COUNT_BY_STATUS = (
            "select count(distinct app_name) from neptune_tagconf where user_name = \'%s\' and status=%s;"
            )

    GET_STATISTIC_DATA = (
        "select sum(data_size),sum(uv) from "
        "neptune_statistic where 1=1 %s;")

    GET_STATISTIC_BY_TIME_DISTANCE = (
        "select user_name,app_name,data_size,uv,date_time "
        "from neptune_statistic where 1=1 %s;")

    GET_LABEL_USE_RANK = (
        "select app_name,count(user_name) as num, owner_name as user_name "
        "from neptune_relation where status = 2 "
        "group  by owner_name, app_name order by num DESC limit 10;")

    GET_LABEL_PUBLISH_RANK = (
        "select app_name,user_name from neptune_tagconf"
        " order by create_time DESC limit 10;")

    GET_ALL_AUTHORITY_USER = (
            "select distinct user_name from neptune_relation where owner_name=\'%s\' and app_name=\'%s\' and  status=%s  ;")

    GET_ALL_ARK_USER = (
            "select username from auth_user limit 5000;")

    GET_OTS_USER_RELATION = (
        "select ots_table,user_name from neptune_relation"
        " where (status = 2 or status = 3) and ots_priviliege = 1;")

    GET_ALL_CATEGORY_TYPE = (
        "select category_type,count(id) as count from "
        "neptune_tagconf group by category_type;")

    GET_OWNER_SUBSCRIBE_DATA = (
        "select id,app_name,user_name,owner_name,status,update_time"
        " from neptune_relation where status %s and "
        "user_name = \'%s\' limit %s, %s;")

    GET_OWNER_SUBSCRIBE_DATA_COUNT = (
        "select count(id) from neptune_relation where status %s and "
        "user_name = \'%s\' ;")

    GET_PROCESSING_CENTER_INFO = (
        "select id,app_name,status,update_time from neptune_tagconf "
        "where status %s and user_name = \'%s\' limit %s, %s;") 
    GET_PROCESSING_CENTER_INFO_COUNT = (
        "select count(distinct app_name) from neptune_tagconf " 
        "where status %s and user_name = \'%s\';")
    GET_PUBLISH_HISTORY = (
        "select id,app_name,version,update_time,create_time"
        " from neptune_tagconf where status %s and user_name = \'%s\' "
        " limit %s, %s;")

    GET_PUBLISH_HISTORY_COUNT = (
        "select count(distinct app_name)"
        " from neptune_tagconf where status %s and user_name = \'%s\' ")


class SqlManager(object):
    def __init__(self, logger):
        self.__log = logger
        self.grantTag = 0
        self.revokeTag = 1

    #根据category_type 获取date_size和uv
    def get_statistic_by_catetype(
            self,
            where_content):

        tmp_sql = ConstantSql.GET_STATISTIC_DATA % (
                where_content)
        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))

            data_size = int(rows[0][0])
            uv = int(rows[0][1])

            return data_size,uv
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    #获取一段时间的data_size、uv波动统计
    def get_statistic_by_time_distance(
            self,
            where_content):

        tmp_sql = ConstantSql.GET_STATISTIC_BY_TIME_DISTANCE % (
                where_content)
        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            
            row_list = []
            for row in rows:
                tmp_row = list(row)
                row_list.append(tmp_row)

            self.__log.info('row_list = %s' % str(row_list))

            return row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None


    #接入数据统计信息
    @django.db.transaction.atomic
    def insert_data_statistic_info(
            self,
            user_name,
            app_name,
            category_type,
            uv,
            data_size,
            date_time):
        try:
            with django.db.transaction.atomic():
                if user_name is None or app_name is None \
                    or category_type is None or uv is None \
                    or data_size is None:
                    return 1,"param can not be None!"

                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")

                statistic = neptune.models.Statistic(
                        user_name = user_name,
                        app_name = app_name,
                        uv = uv,
                        data_size = data_size,
                        category_type = category_type,
                        date_time = date_time,
                        update_time = now_time)

                statistic.save()
                tag_conf = neptune.models.TagConf.objects.get(
                        user_name=user_name,
                        app_name=app_name)
                tag_conf.update_time = now_time
                tag_conf.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)



    #更新数据统计信息
    @django.db.transaction.atomic
    def update_data_statistic_info(
            self,
            user_name,
            app_name,
            category_type,
            uv,
            data_size,
            date_time):
        try:
            now_time = tools_util.StaticFunction.get_now_format_time(
                    "%Y-%m-%d %H:%M:%S")
            with django.db.transaction.atomic():
                statistic_info = neptune.models.Statistic.objects.filter(
                        user_name = user_name,app_name = app_name,
                        date_time = date_time)
                
                if len(statistic_info) > 0:
                    if category_type is not None:
                        statistic_info[0].category_type = category_type

                    if uv is not None:
                        statistic_info[0].uv = uv

                    if data_size is not None:
                        statistic_info[0].data_size = data_size

                    statistic_info[0].update_time = now_time
                    statistic_info[0].save()

                #TODO 查不到的话，new一条记录
                else:
                    statistic_new = neptune.models.Statistic(
                            user_name = user_name,
                            app_name = app_name,
                            uv = uv,
                            data_size = data_size,
                            category_type = category_type,
                            date_time = date_time,
                            update_time = now_time)

                    statistic_new.save()
                return 0, "OK"

        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #删除统计数据
    @django.db.transaction.atomic
    def delete_data_statistic_info(
            self,
            user_name,
            app_name):
        try:
            with django.db.transaction.atomic():
                statistics = neptune.models.Statistic.objects.filter(
                        user_name = user_name,app_name = app_name)

                if len(statistics) > 0:
                    for statistic in statistics:
                        statistic.delete()
                    return 0, "OK"
                else:
                    return 1, "there has no statistics!"

        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #标签使用排行(前十)
    def label_use_ranking(self):
        tmp_sql = ConstantSql.GET_LABEL_USE_RANK
        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))

            row_list = []
            for row in rows:
                tmp_row = list(row)
                row_list.append(tmp_row)

            self.__log.info('row_list = %s' % str(row_list))
            return row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    #标签最新发布排行(前十)
    def latest_publish_ranking(self):
        tmp_sql = ConstantSql.GET_LABEL_PUBLISH_RANK
        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))

            row_list = []
            for row in rows:
                tmp_row = list(row)
                row_list.append(tmp_row)

            self.__log.info('row_list = %s' % str(row_list))
            return row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None


    #创建数据，添加权限记录
    def create_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):
        try:
            algin_odps_table,ots_table = self.find_ots_odps_table(
                    user_name,
                    app_name)
            self.grant_revoke_odps_table_auth(self.grantTag,user_name,algin_odps_table)

            return self.add_new_relation(
                    user_name,
                    owner_name,
                    app_name,
                    neptune.tools_utils.RelationStatus.STATUS_AUTH,
                    algin_odps_table,
                    ots_table,
                    neptune.tools_utils.UserPermissionType.HAS_AUTH,
                    neptune.tools_utils.UserPermissionType.HAS_AUTH)

        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #授予odps表权限
    def grant_revoke_odps_table_auth(
            self,
            action,  #0:grant,1:revoke
            user_name,
            algin_odps_table):

        try:
            user = django.contrib.auth.models.User.objects.get(
                    username=user_name)
            info = Info.objects.get(user = user)
            account = info.odps_dxp_account
            if not account:
                return 1,'授权失败！请完善个人信息,填写odps_dxp_account!'
            project = settings.ODPS_PROJECTS[0]
            if action == self.grantTag:
                OdpsPrivilege.grant(project,algin_odps_table,account,\
                        SITE_ACCESS_ID,SITE_ACCESS_KEY)
            else:
                OdpsPrivilege.revoke(project,algin_odps_table,account,\
                        SITE_ACCESS_ID,SITE_ACCESS_KEY)
                
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #tagconf授权
    @django.db.transaction.atomic
    def grant_tagconf_auth(
            self,
            user_names,
            owner_name,
            app_name):
        try:
            with django.db.transaction.atomic():
                if self.check_tagconf_auth(
                        owner_name,
                        app_name) != neptune.tools_utils.RelationStatus.STATUS_AUTH:
                    return 1, "this owener has no auth to grant permission"

                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")

                algin_odps_table,ots_table = self.find_ots_odps_table(
                        owner_name,
                        app_name)

                for user_name in user_names:
                    old_relation = neptune.models.Relation.objects.filter(
                            user_name = user_name,
                            app_name = app_name)

                    if len(old_relation)>0:
                        self.grant_revoke_odps_table_auth(self.grantTag,user_name,algin_odps_table)
                        self.update_relation(
                                user_name,
                                app_name,
                                neptune.tools_utils.RelationStatus.STATUS_APPLYED,
                                neptune.tools_utils.UserPermissionType.HAS_AUTH,
                                neptune.tools_utils.UserPermissionType.HAS_AUTH)
                        continue

                    self.grant_revoke_odps_table_auth(self.grantTag,user_name,algin_odps_table)
                    self.add_new_relation(
                            user_name,
                            owner_name,
                            app_name,
                            neptune.tools_utils.RelationStatus.STATUS_APPLYED,
                            algin_odps_table,
                            ots_table,
                            neptune.tools_utils.UserPermissionType.HAS_AUTH,
                            neptune.tools_utils.UserPermissionType.HAS_AUTH)
                return 0,"OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)
                                

    #权限申请
    def apply_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):
        self.__log.info("hello: %s, %s, %s" % (user_name, owner_name, app_name))
        try:
            algin_odps_table,ots_table = self.find_ots_odps_table(
                    user_name,
                    app_name)

            #TODO 若已申请过，不作处理
            old_relation = neptune.models.Relation.objects.filter(
                    user_name = user_name,
                    app_name = app_name)
            if len(old_relation)>0:
                pass
            else:
                self.add_new_relation(
                        user_name,
                        owner_name,
                        app_name,
                        neptune.tools_utils.RelationStatus.STATUS_APLLYING,
                        algin_odps_table,
                        ots_table,
                        neptune.tools_utils.UserPermissionType.HAS_NO_AUTH,
                        neptune.tools_utils.UserPermissionType.HAS_NO_AUTH)
            return 0,"OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #同意权限申请
    def confirm_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):
        try:
            if self.check_tagconf_auth(
                    owner_name,
                    app_name) != neptune.tools_utils.RelationStatus.STATUS_AUTH:
                return 1, "this owener has no auth to grant permission"

            #self.__log.info('aaaaaaaaaaaa')
            algin_odps_table,ots_table = self.find_ots_odps_table(
                    owner_name,
                    app_name)
            self.grant_revoke_odps_table_auth(self.grantTag,user_name,algin_odps_table)

            self.update_relation(
                    user_name,
                    app_name,
                    neptune.tools_utils.RelationStatus.STATUS_APPLYED,
                    neptune.tools_utils.UserPermissionType.HAS_AUTH,
                    neptune.tools_utils.UserPermissionType.HAS_AUTH,
                    )
            return 0,"OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #回绝权限申请
    @django.db.transaction.atomic
    def reject_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):
        try:
            with django.db.transaction.atomic():
                if self.check_tagconf_auth(
                        owner_name,
                        app_name) != neptune.tools_utils.RelationStatus.STATUS_AUTH:
                    return 1, "this owener has no auth to grant permission"

                old_relation = neptune.models.Relation.objects.get(
                        user_name = user_name,
                        app_name = app_name)
                old_relation.delete()
            return 0,"OK"

        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #收回权限
    @django.db.transaction.atomic
    def take_back_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):
        try:
            with django.db.transaction.atomic():
                if self.check_tagconf_auth(
                        owner_name,
                        app_name) != neptune.tools_utils.RelationStatus.STATUS_AUTH:
                    return 1, "this owener has no auth to grant permission"

                algin_odps_table,ots_table = self.find_ots_odps_table(
                        owner_name,
                        app_name)
                #还需收回odps和ots权限（指令）
                self.grant_revoke_odps_table_auth(self.revokeTag,user_name,algin_odps_table)

                old_relation = neptune.models.Relation.objects.get(
                        user_name = user_name,
                        app_name = app_name)

                self.__log.info(old_relation.user_name)
                old_relation.delete()
            return 0,"OK"

        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    #获取所有ots表格对应的用户关系
    def get_all_ots_user_relation(self):
        tmp_sql = ConstantSql.GET_OTS_USER_RELATION
        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            
            row_list = {}
            for row in rows:
                self.__log.info(str(row))
                row = list(row)
                row1 = str(row[0])
                row2 = str(row[1])

                if row_list.has_key(row1):
                    row_list[row1].append(row2)
                else:
                    row_list[row1] = [row2]

            self.__log.info('row_list = %s' % str(row_list))
            return row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None


    #获取用户对标签数据的权限
    def get_user_tagconf_auth(
            self,
            user_name,
            owner_name,
            app_name):

        try:
            relation = neptune.models.Relation.objects.filter(
                    user_name = user_name,
                    owner_name = owner_name,
                    app_name = app_name)
            if len(relation) > 0:
                auth = relation[0].status
            else:
                auth = neptune.tools_utils.RelationStatus.STATUS_NO_AUTH

            return auth
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None
                

    #获取数据标签list
    def show_tagconf_info(
            self,
            owner_name,
            page_min,
            page_max,
            order_field,
            sort_order,
            where_content):
        page_max = page_max - page_min
        tmp_sql = ''
        if order_field == 'publication_time':
            tmp_sql = ConstantSql.SHOW_TAGCONF_INFO_ORDER_BY_PUBLISH_TIME % (
                    where_content,
                    sort_order,
                    page_min,
                    page_max)
            self.__log.info('pulication_time execute sql:%s' % tmp_sql)

        if order_field == 'use_count':
            tmp_sql = ConstantSql.SHOW_TAGCONF_INFO_ORDER_BY_USE_COUNT % (
                    where_content,
                    order_field,
                    sort_order,
                    page_min,
                    page_max)
            self.__log.info('use_count execute sql:%s' % tmp_sql)
        
        if order_field == 'update_time':
            tmp_sql = ConstantSql.SHOW_TAGCONF_INFO_ALL % (
                    where_content,
                    order_field,
                    sort_order,
                    page_min,
                    page_max) 
            self.__log.info('update_time execute sql:%s' % tmp_sql)

        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            
            row_list = []
            for row in rows:
                self.__log.info(str(row))
                row = list(row)

                if row[0] == None:
                    row[0] = 0

                row_list.append(row)
            
            all_count = self.__get_all_tagconf_count(where_content)
            self.__log.info('row_list = %s' % str(row_list))
            return all_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None


    #获取所有标签类型
    def get_all_category_type(self):
        tmp_sql = ConstantSql.GET_ALL_CATEGORY_TYPE
        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            
            row_list = []
            for row in rows:
                row_dict = {}
                self.__log.info(str(row))
                row = list(row)
                row1 = str(row[0])
                row2 = int(row[1])
                row_dict['category_type'] = row1
                row_dict['count'] = row2
                row_list.append(row_dict)

            self.__log.info('row_list = %s' % str(row_list))
            return row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None
        
    #获取数据标签信息
    def get_tagconf_info(self,user_name,app_name):
        try:
            self.__log.info("user_name:%s, app_name:%s" % (user_name, app_name))
            tagconf = neptune.models.TagConf.objects.get(user_name = user_name,app_name = app_name)
            relation_list = neptune.models.Relation.objects.filter(app_name = app_name,\
                    status = neptune.tools_utils.RelationStatus.STATUS_APPLYED)
            apply_list = neptune.models.Relation.objects.filter(app_name = app_name,\
                    status = neptune.tools_utils.RelationStatus.STATUS_APLLYING)
            use_count = relation_list.count()

            return tagconf,relation_list,use_count,apply_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None, None, None, None

    #获取数据标签owner_list/apply_list
    def get_tagconf_owner_apply_list(self,app_name,type):
        try:
            if type == 0:
                relation_list = neptune.models.Relation.objects.filter(app_name = app_name,\
                        status = neptune.tools_utils.RelationStatus.STATUS_APPLYED)
            if type == 1:
                relation_list = neptune.models.Relation.objects.filter(app_name = app_name,\
                        status = neptune.tools_utils.RelationStatus.STATUS_APLLYING)
            return relation_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_owner_subscribe_data_count(self, is_owner, owner_name):
        if is_owner == neptune.tools_utils.RelationStatus.STATUS_APPLYED:
            is_owner = '=2 '
        else:
            is_owner = '=3'

        tmp_sql = ConstantSql.GET_OWNER_SUBSCRIBE_DATA_COUNT % (
                is_owner,
                owner_name)

        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            count = int(rows[0][0])
            self.__log.info('result = %s' % count)
            return count
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return 0


    #获取我的数据/订阅数据
    def get_owner_subscribe_data(
            self,
            is_owner,
            owner_name,
            page_min,
            page_max):

        page_max = page_max - page_min
        raw_is_owner = is_owner
        if is_owner == neptune.tools_utils.RelationStatus.STATUS_APPLYED:
            is_owner = '=2 '
        else:
            is_owner = '=3'

        tmp_sql = ConstantSql.GET_OWNER_SUBSCRIBE_DATA % (
                is_owner,
                owner_name,
                page_min,
                page_max) 

        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            
            row_list = []
            for row in rows:
                self.__log.info(str(row))
                row = list(row)
                row_list.append(row)
            
            all_count = self.get_owner_subscribe_data_count(raw_is_owner, owner_name)
            self.__log.info('row_list = %s' % str(row_list))
            return all_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    #我的数据回滚/下线操作
    def owner_data_operate(
            self,
            app_name,
            owner_name,
            action):
        pass


    def processing_center_info_count(
            self,
            user_name,
            process_status):
        
        if process_status == neptune.tools_utils.TagProcessStatus.STATUS_ALL:
            process_status = '<4'
        else:
            process_status = '='+str(process_status)

        tmp_sql = ConstantSql.GET_PROCESSING_CENTER_INFO_COUNT % (
                process_status,
                user_name)
        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return 0

    #获取处理中心数据
    def processing_center_info(
            self,
            user_name,
            process_status,
            page_min,
            page_max):

        page_max = page_max - page_min
        raw_status = process_status

        if process_status == neptune.tools_utils.TagProcessStatus.STATUS_ALL:
            process_status = '<4'
        else:
            process_status = '='+str(process_status)

        tmp_sql = ConstantSql.GET_PROCESSING_CENTER_INFO % (
                process_status,
                user_name,
                page_min,
                page_max) 

        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            
            row_list = []
            for row in rows:
                self.__log.info(str(row))
                row = list(row)
                row_list.append(row)
            
            all_count = self.processing_center_info_count(user_name, raw_status)
            self.__log.info('row_list = %s' % str(row_list))
            return all_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None


    #发布新数据
    @django.db.transaction.atomic
    def publish_tagconf_data(self,tagconf):
        try:
            with django.db.transaction.atomic():
                tagconf.save()
                return 0, 'OK'
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)


    def publish_tagconf_history_count(
            self,
            owner_name):

        status = neptune.tools_utils.TagProcessStatus.STATUS_SUCCESS_SUBSCRIB
        status_str = '='+str(status)

        tmp_sql = ConstantSql.GET_PUBLISH_HISTORY_COUNT % (
                status_str,
                owner_name)

        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return 0




    #获取发布历史
    def publish_tagconf_history(
            self,
            owner_name,
            page_min,
            page_max):

        page_max = page_max - page_min
        status = neptune.tools_utils.TagProcessStatus.STATUS_SUCCESS_SUBSCRIB
        status_str = '='+str(status)

        tmp_sql = ConstantSql.GET_PUBLISH_HISTORY % (
                status_str,
                owner_name,
                page_min,
                page_max) 

        self.__log.info('execute sql:%s' % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            
            row_list = []
            for row in rows:
                self.__log.info(str(row))
                row = list(row)
                row_list.append(row)
            
            all_count = self.publish_tagconf_history_count(owner_name)
            self.__log.info('row_list = %s' % str(row_list))
            return all_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None


    #更新数据基本信息
    @django.db.transaction.atomic
    def update_tagconf_data(self,tagconf_id,user_name,update_map):
        try:
            with django.db.transaction.atomic():
                tagconf = neptune.models.TagConf.objects.get(id = tagconf_id)
                if update_map is None:
                    return 1,"update_map can not be None!"
                if tagconf.user_name != user_name:
                    return 1, "this user has no auth to update data!"

                for key in update_map:
                    if key == 'update_cycle':
                        tagconf.update_cycle = update_map[key]
                    if key == 'category_type':
                        tagconf.category_type = update_map[key]
                    if key == 'crontab_conf':
                        tagconf.crontab_conf = update_map[key]
                    if key == 'overtime':
                        tagconf.overtime = update_map[key]
                
                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                tagconf.update_time = now_time
                tagconf.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)


    #编辑修改未发布数据
    @django.db.transaction.atomic
    def update_tagconf_config(self,tagconf):
        try:
            with django.db.transaction.atomic():
                #修改流程和odps表的操作
                tagconf.update()
                return 0, 'OK'
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)





















    #更新已有的relation
    @django.db.transaction.atomic
    def update_relation(
            self,
            user_name,
            app_name,
            status,
            ots_priviliege,
            odps_priviliege):

        now_time = tools_util.StaticFunction.get_now_format_time(
                "%Y-%m-%d %H:%M:%S")
        try:
            with django.db.transaction.atomic():
                old_relation = neptune.models.Relation.objects.filter(
                        user_name = user_name,
                        app_name = app_name)
                if len(old_relation)>0:
                    old_relation[0].status = status
                    old_relation[0].update_time = now_time
                    old_relation[0].ots_priviliege = ots_priviliege
                    old_relation[0].odps_priviliege = odps_priviliege
                    old_relation[0].save()

        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)


    #新建relation的公共方法
    @django.db.transaction.atomic
    def add_new_relation(
            self,
            user_name,
            owner_name,
            app_name,
            status,
            algin_odps_table,
            ots_table,
            ots_priviliege,
            odps_priviliege):

        try:
            with django.db.transaction.atomic():
                update_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")

                tagconf_relation = neptune.models.Relation(
                        user_name = user_name,
                        owner_name = owner_name,
                        app_name = app_name,
                        status = status,
                        algin_odps_table = algin_odps_table,
                        ots_table = ots_table,
                        ots_priviliege = ots_priviliege,
                        odps_priviliege = odps_priviliege,
                        update_time = update_time)

                tagconf_relation.save()
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))


    #查找algin_odps_table和ots_table
    def find_ots_odps_table(
            self,
            user_name,
            app_name):
        algin_odps_table = ''
        ots_table = ''
        try:
            tagconf = neptune.models.TagConf.objects.filter(
                    user_name = user_name,
                    app_name = app_name)
            if len(tagconf)>0:
                algin_odps_table = tagconf[0].algin_odps_table
                ots_table = tagconf[0].ots_table
            return algin_odps_table,ots_table

        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return algin_odps_table,ots_table


    def get_all_authority_users(self, owner_name, app_name, status):
        tmp_sql = ConstantSql.GET_ALL_AUTHORITY_USER % (owner_name, app_name, status)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('tmpsql = %s, result = %s' % (tmp_sql,str(rows)))
            row_list = []
            for row in rows:
                self.__log.info(str(row))
                if len(row) > 0:
                    row_list.append(row[0])
            self.__log.info('list:%s' % row_list)
            return row_list 
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return [] 

    def get_all_ark_users(self):
        tmp_sql = ConstantSql.GET_ALL_ARK_USER
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            self.__log.info('result = %s' % str(rows))
            row_list = []
            for row in rows:
                self.__log.info(str(row))
                if len(row) > 0:
                    row_list.append(row[0])
            return row_list 
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return [] 

    def check_tagconf_auth(self, owner_name, app_name):
        try:
            '''
            user_info = django.contrib.auth.models.User.objects.get(
                    username=owner_name)
            if user_info.is_superuser == 1:
                return neptune.tools_utils.RelationStatus.STATUS_AUTH
            '''

            relation = neptune.models.Relation.objects.filter(
                    owner_name = owner_name,
                    app_name = app_name)

            if len(relation)>0:
                return relation[0].status
            else:
                return neptune.tools_utils.RelationStatus.STATUS_NO_AUTH
            
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return neptune.tools_utils.RelationStatus.STATUS_NO_AUTH

    #求count
    def __get_all_tagconf_count(self, where_content):
        tmp_sql = ConstantSql.SHOW_ALL_TAGCONF_INFO_ALL_COUNT % (
                where_content) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def online_apply(self, user_name, app_name):
        try:
            online_info = neptune.models.AllowOnlineTable(
                    user_name=user_name,
                    app_name=app_name,
                    time=tools_util.StaticFunction.get_now_format_time(
                            "%Y-%m-%d %H:%M:%S"),
                    status=0)
            online_info.save()
            return True
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False

    def get_user_buy_data_count(self, user_name):
        tmp_sql = ConstantSql.GET_USER_BUY_DATA_COUNT % user_name
        self.__log.info("get_user_buy_data_count sql: %s" % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            count = int(rows[0][0])
            self.__log.info("get_user_buy_data_count return count = %s" % count)
            return True, count
        except exceptions.Exception as ex: 
            self.__log.error("get_user_buy_data_count execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return False, 0

    def get_user_public_data_count(self, user_name):
        tmp_sql = ConstantSql.GET_USER_PUBLIC_DATA_COUNT % user_name
        self.__log.info("get_uowner_name, ser_public_data_count sql: %s" % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            count = int(rows[0][0])
            self.__log.info("get_user_public_data_count return count = %s" % count)
            return True, count
        except exceptions.Exception as ex: 
            self.__log.error("get_user_public_data_count execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return False, 0

    def get_user_process_data_by_status(self, user_name, status):
        tmp_sql = ConstantSql.GET_USER_PROCESS_DATA_COUNT_BY_STATUS % (user_name, status)
        self.__log.info("get_user_process_data_by_status sql: %s" % tmp_sql)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            count = int(rows[0][0])
            return True, count
        except exceptions.Exception as ex: 
            self.__log.error("get_user_process_data_by_status sql execute sql failed![ex:%s][trace:%s]!" % (\
                    str(ex), traceback.format_exc()))
            return False, 0


    def get_all_online_infos(self):
        try:
            online_infos = neptune.models.AllowOnlineTable.objects.all()
            len(online_infos)
            return online_infos
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False

    #@django.db.transaction.atomic
    def confirm_apply(self, user_name, app_name):
        try:
            self.__log.info("user_name:%s, app_name:%s" % (user_name, app_name))
            with django.db.transaction.atomic():
                now_time =tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                online_info = neptune.models.AllowOnlineTable.objects.get(
                        user_name=user_name,
                        app_name=app_name)
                online_info.delete()
                tag_conf = neptune.models.TagConf.objects.get(
                        user_name=user_name,
                        app_name=app_name)
                tag_conf.status = 3 
                tag_conf.create_time = now_time
                tag_conf.save()
                self.__log.info("user_name:%s, app_name:%s, status changed to 3" % (user_name, app_name))
                relation = neptune.models.Relation(
                        user_name=user_name,
                        owner_name=user_name,
                        app_name=app_name,
                        status=3,
                        algin_odps_table=tag_conf.algin_odps_table,
                        ots_table=tag_conf.ots_table,
                        ots_priviliege =1,
                        odps_priviliege =1,
                        update_time=now_time)
                relation.save()

                publication = neptune.models.Publication(
                        user_name=user_name,
                        app_name=app_name,
                        data_type=tag_conf.data_type,
                        create_time=now_time,
                        version=tag_conf.version,
                        publication_time=now_time)
                publication.save()
                publication = neptune.models.Publication.objects.get(
                        user_name=user_name,
                        app_name=app_name,
                        data_type=tag_conf.data_type,
                        create_time=now_time,
                        version=tag_conf.version,
                        publication_time=now_time)
                self.__log.info("get publication info in confirm apply success")
                return True
        except exceptions.Exception as ex:
            self.__log.error("confirm_apply execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False

    def reject_apply(self, user_name, app_name):
        try:
            with django.db.transaction.atomic():
                online_info = neptune.models.AllowOnlineTable.objects.get(
                        user_name=user_name,
                        app_name=app_name)
                online_info.delete()
                tag_conf = neptune.models.TagConf.objects.get(
                        user_name=user_name,
                        app_name=app_name)
                tag_conf.status = 1
                tag_conf.save()
                return True
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False


