# -*- coding: utf8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import json
import time
import exceptions
import logging
import logging.config
import urllib2
import traceback

import django.contrib.auth.models
from models import TagConf,Publication,Statistic,Relation
from horae import common_logger
import neptune_manager


class PipelineProcess():
    def __init__(self, user_id, user_pwd, ip, port, logger = None):
        self.__user_id = user_id
        self.__user_pwd = user_pwd
        self.__ip = ip
        self.__port = port
        self.__logger = logger
        if logger:
            self.__logger = logger
        else:
            self.__logger = common_logger.get_logger(
                    "user_log",
                    "./log/user_log")
        self.__http_tpl = "http://%s:%s/api/pipeline/auto_pipeline/" % (self.__ip, self.__port) + "%s/"
        self.__logger.info('user:%s, pw:%s, ip:%s, port:%s, http_tpl:%s' % (self.__user_id, self.__user_pwd, self.__ip, self.__port, self.__http_tpl))

    def __construct_request(self, req_dict):
        req_package = json.dumps(req_dict)
        self.__logger.info('raw req json:%s' % req_package)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        self.__logger.info('gbk request:\n%s'  % enquote_req_packge)
        return self.__http_tpl % enquote_req_packge

    def __request_process(self, raw_request, retry_times = 2, sleep_time = 1):
        conect_times = retry_times + 1
        if retry_times <= 0:
            conect_times = 1
        err_flag = False
        lines = ''
        for i in range(conect_times):
            try:
                lines = urllib2.urlopen(raw_request).readlines()
                err_flag = False
                self.__logger.info("lines:%s" % ''.join(lines))
                break
            except urllib2.URLError, e:
                err_flag = True
                self.__logger.info("urllib2 connect get request:%s error" % (raw_request, traceback.format_exc()))
                sleep(sleep_time)
        return (not err_flag, lines)

    def check_pipeline(self, pipe_name):
        '''
        返回两个值，一个是代表当前request是否正常发送，一个是pipeline是否存在。
        正常request返回true，否则false；pipeline存在则返回0，否则返回1
        '''
        req_dict = {"username":self.__user_id, "password":self.__user_pwd, "cmd":"get_pipeline", "name":pipe_name}
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1

    def get_pipeline_task_info(self, pipe_name, task_name):
        req_dict = {"username":self.__user_id, "password":self.__user_pwd, "cmd":"get_task", \
                "tasks":[{"pipeline_name":pipe_name, 'task_name': task_name}]}
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        return content

    def delete_pipeline(self, pipe_name):
        '''
        返回两个值，一个是代表当前request是否正常发送，一个是删除是否成功。
        正常request，返回true，否则返回false，删除成功返回0，否则返回1
        '''
        req_dict = {'username':self.__user_id, 'password':self.__user_pwd, 'cmd':'delete_pipeline', 'name':pipe_name} 
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        print "delete content:%s" % content
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1

    def create_pipeline(self, pipe_name, schedule_time, enable = 0, desc = ''):
        '''
        返回两个值，一个是代表当前request是否正常发送，一个是删除是否成功。
        正常request，返回true，否则返回false，删除成功返回0，否则返回1
        '''
        req_dict = {'username':self.__user_id, 'password':self.__user_pwd, 'cmd':'create_pipeline', 'name':pipe_name, 'type':1, 'ct_time':schedule_time, 'enable':enable, 'description':desc, 'tag':'', 'monitor_way': 0, 'owners_name':'xiangyu.liu'}
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1 

    def add_task(self, pipe_name, task_config):
        '''
        返回两个值，一个是代表当前request是否正常发送，一个是添加是否成功。
        正常request，返回true，否则返回false，添加成功返回0，否则返回1
        '''
        req_dict = {'username':self.__user_id, 'password':self.__user_pwd, 'cmd':'add_task', 'pipeline_name':pipe_name, 'task':task_config}
        self.__logger.info("task config:\n%s" % req_dict)
        
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1 

    def add_edge(self, from_pipe, from_task, to_pipe, to_task):
        '''
        返回两个值，一个是代表当前request是否正常发送，一个是添加是否成功。
        正常request，返回true，否则返回false，添加成功返回0，否则返回1
        '''
        req_dict = {'username':self.__user_id, 'password':self.__user_pwd, 'cmd':'add_edge', 'from_task':{'pipeline_name':from_pipe, 'task_name':from_task},\
                'to_task':{'pipeline_name':to_pipe, 'task_name':to_task}}
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1

    def run_pipe(self, pipe_name, time_str):
        '''
        返回两个值，一个是代表当前request是否正常发送，一个是正常运行
        正常request，返回true，否则返回false，正常运行返回0，否则返回1
        '''
        req_dict = {'username':self.__user_id, 'password':self.__user_pwd, 'pipeline_name': pipe_name, 'cmd':'run_pipeline', 'run_time':time_str}
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1

    def stop_pipe(self, pipe_name, time_str = ''):
        '''
        返回两个值，一个是代表当前request是否正常发送，一个是正常停止
        正常request，返回true，否则返回false，正常停止返回0，否则返回1
        '''
        req_dict = {'username':self.__user_id, 'password':self.__user_pwd, 'cmd':'stop_pipeline', 'pipeline_name': pipe_name, 'time':time_str}
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1

    def update_pipe(self, pipe_name, enable = None, ct_time = None, desc = None, tag = None, type = None, monitor_way = None, owner_name = None):
        req_dict = {'username':self.__user_id, 'password':self.__user_pwd, 'cmd':'update_pipeline', 'name':pipe_name}
        if enable:
            req_dict['enable'] = enable
        if ct_time:
            req_dict['ct_time'] = ct_time
        if desc:
            req_dict['description'] = desc
        if tag:
            req_dict['tag'] = tag
        if type:
            req_dict['type'] = type
        if monitor_way:
            req_dict['monitor_way'] = monitor_way
        if owner_name:
            req_dict['owner_name'] = owner_name
        raw_request = self.__construct_request(req_dict)
        status, content = self.__request_process(raw_request)
        if status:
            d = json.loads(json.loads("".join(content)))
            return status, d['status']
        return status, 1

if '__main__' == __name__:
    logger = logging.getLogger()
    handler = logging.handlers.RotatingFileHandler("./processor.log",maxBytes = 1024*1024*500,backupCount = 10)
    formatter = logging.Formatter('[%(asctime)s] %(levelname)s %(filename)s[line:%(lineno)d] %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.NOTSET)
    #p = PipelineProcess('xiangyu.liu', 'ting0310', '140.205.216.134', '9999', logger)
    p = PipelineProcess('xiangyu.liu', 'ting0310', '10.181.204.100', '9999', logger)
    print p.create_pipeline('neptune_test_001', '1 2 * * *', 0)
    print p.check_pipeline('neptune_test_001')
    check_partition_task_dict = {'name':'check_partition', 'over_time':'36000', 'processor_name':'check_partition_exists_processor', 'log_file':'check_partition_log', \
            'odpscmd_path':'/home/admin/ha_pe_work/log_analysis/ucweblog/clt/bin/odpscmd', 'odps_user':'', 'odps_pw':'', 'odps_project':'', 'table_name':'', 'partition_str':'', \
            'endpoint_str':''}
    print p.add_task('neptune_test_001', check_partition_task_dict)
    check_partition_task_dict2 = {'name':'check_partition2', 'over_time':'36000', 'processor_name':'check_partition_exists_processor', 'log_file':'check_partition_log', \
            'odpscmd_path':'/home/admin/ha_pe_work/log_analysis/ucweblog/clt/bin/odpscmd', 'odps_user':'', 'odps_pw':'', 'odps_project':'', 'table_name':'', 'partition_str':'', \
            'endpoint_str':''}
    print p.add_task('neptune_test_001', check_partition_task_dict2)
    print p.add_edge('neptune_test_001', 'check_partition', 'neptune_test_001','check_partition2') 
    
    print p.delete_pipeline('neptune_test_001')

