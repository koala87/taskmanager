###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
常量，静态方法等

Authors: ronghang.rh(hang.rong@shenma-inc.com)
"""

import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import string
import enum


# 权限操作动作类型
class AuthAction(enum.Enum):
    GRANT_AUTH_TO_OTHER = 0  # 授予权限给其他用户
    CONFIRM_APPLY_AUTH = 1  # 用户确认其他用户的权限申请
    REJECT_APPLY_AUTH = 2  # 用户拒绝其他用户的权限申请
    APPLY_AUTH = 3  # 用户申请权限
    TAKE_BACK_AUTH = 4  # 用户收回授予的权限
    CREATE_CONF_AUTH = 5 #创建数据，添加权限

#用户是否有权限
class UserPermissionType(enum.Enum):
    HAS_NO_AUTH = 0
    HAS_AUTH = 1

#relation status用户数据关系
class RelationStatus(enum.Enum):
    STATUS_NO_AUTH = 0  #无权限
    STATUS_APLLYING = 1 #申请中
    STATUS_APPLYED = 2  #已订阅
    STATUS_AUTH = 3     #用户产出数据

#我的数据/订阅数据
class OwnerSubscribStatus(enum.Enum):
    STATUS_AUTH = 3
    STATUS_APPLYED = 2

#数据处理状态
class TagProcessStatus(enum.Enum):
    STATUS_NOT_SUBSCRIB = 0   #未发布
    STATUS_FAIL_SUBSCRIB = 1  #发布失败
    STATUS_PROCESSING = 2     #处理中
    STATUS_SUCCESS_SUBSCRIB = 3 #发布成功
    STATUS_ALL = 4  #全部














