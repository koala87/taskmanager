#coding=utf-8
from django.test import TestCase
from django.contrib.auth.models import User
from django.conf import settings

from models import Channel
from models import ChannelUrl
from common.ark_perm import UserPerm

# Create your tests here.
class ChannelTest(TestCase):

    def setUp(self):
        self.user1 = User.objects.create(
            username = 'user1', email = 'jianfeng.liujf1@alibaba-inc.com')
        self.user2 = User.objects.create(username = 'user2')
        self.user3 = User.objects.create(username = 'user3')

        self.ark_admin = User.objects.create(
            username = 'ark_admin',
            email = 'jianfeng.liujf1@alibaba-inc.com')
        self.channel = Channel.objects.create(
            creator = self.user1,
            random_id = 1,
            tag = 'wa000001',
            name = 'test_channel',
            type = ['hot', 'search'],
            owner_name = 'jianfeng.liujf1',
            description = 'desc')

        self.url1 = 'baidu.com'
        self.channel_url1 = ChannelUrl.objects.create(
            channel = self.channel,
            url = self.url1)

    def test_make_type_str(self):
        types = ['哈哈', 'a']
        type_str = Channel.TYPE_SEP.join(types)
        self.assertEqual(type_str, Channel.make_type_str(types))

        types = ['哈哈', 'a', '']
        self.assertEqual(type_str, Channel.make_type_str(types))

    def test_create_one(self):
        print 'test_create_one'
        self.assertEqual(1, Channel.objects.all().count())
        self.assertEqual(1, ChannelUrl.objects.all().count())
        
        urls = ['baidu.com', 'sm.cn']
        users = [self.user2, self.user3]

        from forms import ChannelForm
        form = ChannelForm(
            {'name': 'test1',
            'owner_name': 'jianfeng.liujf1',
            'type': 'hot,search', 
            'description': 'desc',})

        self.assertTrue(form.is_valid())
        channel = Channel.objects.create_one(self.user1, form, urls, users)
        
        self.assertEqual(2, Channel.objects.all().count())
        self.assertEqual(3, ChannelUrl.objects.all().count())
        for url in urls:
            self.assertEqual(1, ChannelUrl.objects.filter(
                    channel = channel,
                    url = url).count())
            
        for user in users:
            self.assertTrue(UserPerm.has_read_perm(user, channel))

    def test_update_one(self):
        print 'test_update_one'
        self.assertEqual(1, Channel.objects.all().count())
        self.assertEqual(1, ChannelUrl.objects.all().count())
        
        from forms import ChannelForm
        tag = 'test_update_one'
        urls = ['url1', 'url2']
        users = [self.user2]

        form = ChannelForm(
            {'name': tag,
            'owner_name': tag,
            'type': tag,
            'description': tag,}, instance = self.channel)

        self.assertTrue(form.is_valid())
        channel = Channel.objects.update_one(form, urls, users, [])
        
        self.assertEqual(1, Channel.objects.all().count())
        self.assertEqual(2, ChannelUrl.objects.all().count())
        for url in urls:
            self.assertEqual(1, ChannelUrl.objects.filter(
                    channel = self.channel,
                    url = url).count())
            
        for user in users:
            self.assertTrue(UserPerm.has_read_perm(user, self.channel))

    def test_gen_random_id(self):
        print 'gen_random_id'
        ids = []
        for i in range(1000):
            random_id = Channel.gen_random_id()
            self.assertNotIn(random_id, ids)
            Channel.objects.create(
                creator = self.user1, 
                random_id = random_id,
                tag = Channel.CHANNEL_PREFIX + str(random_id),
                name = 'test' + str(random_id),
                owner_name = 'owenr')
            ids.append(random_id)
        self.assertGreater(min(ids), 0)
        self.assertLessEqual(max(ids), Channel.MAX_RANDOM_ID)
        self.assertLessEqual(len(ids), len(set(ids)))

    def test_gen_tag(self):
        prefix = Channel.CHANNEL_PREFIX

        min_tag = prefix + '000001'
        max_tag = prefix + str(Channel.MAX_RANDOM_ID)
        random_id, tag = Channel.gen_tag()
        self.assertTrue(tag.startswith(prefix))
        self.assertGreaterEqual(tag, min_tag)
        self.assertLessEqual(tag, max_tag)
        
        expect_tag = prefix + str(random_id).zfill(Channel.MAX_RANDOM_LEN)
        self.assertEqual(tag, expect_tag)

    def test_get_allow_channels(self):
        channels = Channel.get_allow_channels(self.user2)
        self.assertFalse(channels)
        
        channel = Channel.objects.create(
            creator = self.user1,
            random_id = 2,
            tag = 'wa000002',
            name = 'test_channel2',
            type = ['hot', 'search'],
            owner_name = 'jianfeng.liujf1',
            description = 'desc')
        UserPerm.grant(self.user1, self.user2, self.channel)
        UserPerm.grant(self.user1, self.user2, channel)

        channels = Channel.get_allow_channels(self.user2)
        self.assertListEqual(list(channels), [self.channel, channel])

    def test_update_url(self):
        self.assertEqual(1, Channel.objects.all().count())

        new_url = 'a' + self.url1
        urls = [self.url1, new_url]
        self.channel.update_url(urls)
        self.assertEqual(2, ChannelUrl.objects.all().count())
        self.assertEqual(1, ChannelUrl.objects.filter(url = new_url).count())

        self.channel.update_url([self.url1])
        self.assertEqual(1, ChannelUrl.objects.all().count())
        self.assertEqual(1, ChannelUrl.objects.filter(url = self.url1).count())
        self.assertEqual(0, ChannelUrl.objects.filter(url = new_url).count())

    def test_update_access(self):
        self.assertFalse(UserPerm.has_read_perm(self.user2, self.channel))
        self.assertFalse(UserPerm.has_read_perm(self.user3, self.channel))

        self.channel.update_access([self.user2, self.user3])
        self.assertTrue(UserPerm.has_read_perm(self.user2, self.channel))
        self.assertTrue(UserPerm.has_read_perm(self.user3, self.channel))

        self.channel.update_access([self.user3])
        self.assertFalse(UserPerm.has_read_perm(self.user2, self.channel))
        self.assertTrue(UserPerm.has_read_perm(self.user3, self.channel))

    def test_update_info(self):
        tag = '__test'
        new_name = tag
        new_type = [tag, tag]
        new_owner_name = tag
        new_description = tag
        new_urls = [tag]
        new_users = [self.user2]

        self.assertFalse(UserPerm.has_read_perm(self.user2, self.channel))
        self.assertEqual(0, ChannelUrl.objects.filter(
                channel = self.channel,
                url = tag).count())

        self.channel.update_info(
            new_name, new_type, new_owner_name, new_description,
            new_urls, new_users)
        self.assertTrue(self.channel.name.startswith(tag))
        self.assertTrue(UserPerm.has_read_perm(self.user2, self.channel))
        self.assertEqual(1, ChannelUrl.objects.filter(
                channel = self.channel,
                url = tag).count())

    def test_get_access_users(self):
        UserPerm.grant(self.user1, self.user2, self.channel)
        users = self.channel.get_access_users()
        self.assertListEqual(users, [self.user2])

        UserPerm.grant(self.user1, self.user3, self.channel)
        users = self.channel.get_access_users()
        self.assertListEqual(users, [self.user2, self.user3])

    def test_get_access_info(self):
        UserPerm.grant(self.user1, self.user2, self.channel)
        info = self.channel.get_access_info()
        self.assertDictEqual(info, {self.user2.id: self.user2.username})

        UserPerm.grant(self.user1, self.user3, self.channel)
        info = self.channel.get_access_info()
        self.assertDictEqual(info, {self.user2.id: self.user2.username,
                                    self.user3.id: self.user3.username})

    def test_get_info(self):
        expect_info = {'owner_name': 'jianfeng.liujf1', 
                       'creator': 'user1', 
                       'name': 'test_channel', 
                       'url': [u'baidu.com',], 
                       'access': {}, 
                       'tag': 'wa000001', 
                       'type': ['hot', 'search'], 
                       'description': 'desc'}
        info = self.channel.get_info()
        self.assertEqual(info, expect_info)
        
        UserPerm.grant(self.user1, self.user2, self.channel)
        expect_info['access'] = {self.user2.id: self.user2.username}
        info = self.channel.get_info()
        self.assertEqual(info, expect_info)

    def test_delete_one(self):
        self.assertEqual(0, self.channel.deleted)
        self.channel.delete_one()
        self.assertEqual(1, self.channel.deleted)
