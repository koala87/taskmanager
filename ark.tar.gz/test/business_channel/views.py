#coding=utf-8
import json
import logging
from datetime import datetime
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)
from django.db.models import Q
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout as auth_logout
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth import authenticate
from django.http import HttpResponseRedirect
from common.http_helper import JsonHttpResponse
from common.ark_time import ArkTime, TIME_FORMAT_8
from django.contrib.auth.models import User
from models import Channel
from models import ChannelValidator
from models import ChannelFeat
from models import OuterUser
from forms import ChannelForm
from forms import UpdateUserForm
from ark_user.logics import login_validate
from ark_user.forms import CaptchaRegisterForm as RegisterForm
from ark_user.forms import CaptchaLoginForm as LoginForm
from ark_user.forms import CaptchaResetPasswordForm as ResetPasswordForm
from ark_user.logics import reset_and_notice
from common.ark_captcha import Captcha

login_url='/business_channel/login/'

def login(request):

    if not request.POST:
        form = LoginForm()
        return render(request, 'business_channel_login.html', 
                      {'form': form})

    form = LoginForm(request.POST)
    if not form.is_valid():
        captcha_key, captcha_img = Captcha.generate()
        return JsonHttpResponse(
            {'status':1, 'msg':form.errors.items(),
             'captcha': {'key': captcha_key, 'img': captcha_img}})

    data = form.cleaned_data
    username = data.get('username', '')
    password = data.get('password', '')
    if login_validate(request,username,password):
        return JsonHttpResponse(
            {'status':0,'msg':'登陆成功'})
    else:
        captcha_key, captcha_img = Captcha.generate()
        return JsonHttpResponse(
            {'status':1,'msg':'账号密码不匹配',
             'captcha': {'key': captcha_key, 'img': captcha_img}})

def logout(request):
    auth_logout(request)
    return HttpResponseRedirect('/business_channel/login')

def reset_password(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'msg': '支持post请求'})
    
    form = ResetPasswordForm(request.POST)
    if not form.is_valid():
        captcha_key, captcha_img = Captcha.generate()
        return JsonHttpResponse(
            {'status':1, 'msg':form.errors.items(),
             'captcha': {'key': captcha_key, 'img': captcha_img}})

    captcha_key, captcha_img = Captcha.generate()
    try:
        username = form.cleaned_data['username']
        email = form.cleaned_data['email']
        user = User.objects.all().filter(
            username = username, email = email)
        if user:
            try:
                reset_and_notice(user[0])
            except Exception, ex:
                return JsonHttpResponse(
                    {'status':1,'msg':'error:' + str(ex),
                     'captcha': {'key': captcha_key, 'img': captcha_img}})
            return JsonHttpResponse(
                {'status':0,'msg':'重置密码成功，请查收邮箱！'})
        else:
            return JsonHttpResponse(
                {'status':1, 'msg':'用户邮箱不一致！',
                 'captcha': {'key': captcha_key, 'img': captcha_img}})

    except Exception, ex:
        logger.error('reset password fail, msg:(%s)' % str(ex))
        return JsonHttpResponse(
            {'status': 1, 'msg': str(ex),
             'captcha': {'key': captcha_key, 'img': captcha_img}})


def register(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'msg': '支持post请求'})
    
    form = RegisterForm(request.POST)
    if not form.is_valid():
        captcha_key, captcha_img = Captcha.generate()
        return JsonHttpResponse(
            {'status':1, 'msg':form.errors.items(),
             'captcha': {'key': captcha_key, 'img': captcha_img}})

    try:
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        email = form.cleaned_data['email']
        OuterUser.create(username, password, email)
    except Exception, ex:
        logger.error('create outer user fail, msg:(%s)' % str(ex))
        captcha_key, captcha_img = Captcha.generate()
        return JsonHttpResponse(
            {'status': 1, 'msg': str(ex),
             'captcha': {'key': captcha_key, 'img': captcha_img}})

    login_validate(request,username,password)
    return JsonHttpResponse({'status': 0})


@login_required(login_url=login_url)
def update_user(request):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'msg': '支持post请求'})
    
    form = UpdateUserForm(request.POST)
    if not form.is_valid():
        return JsonHttpResponse(
            {'status':1,
             'msg':form.errors.items()})
    
    try:
        password = form.cleaned_data['password']
        email = form.cleaned_data['email']
        OuterUser.update(request.user, password, email)
    except Exception, ex:
        logger.error('update outer user fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})

    return JsonHttpResponse({'status': 0})


# Create your views here.
@login_required(login_url=login_url)
def create(request):

    # 只允许内部用户创建
    if not request.user.is_staff:
        return JsonHttpResponse({'status': 1, 'msg': '只有内部用户可以创建'})

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'msg': '支持post请求'})

    if not request.POST:
        return render(request, 'update_channel.html', 
                      {'channel_info': {}, 'channel_id': 0})

    form = ChannelForm(request.POST)
    if not form.is_valid():
        return JsonHttpResponse(
            {'status':1,
             'msg':form.errors.items()})

    urls = request.POST.getlist('urls')
    user_ids = request.POST.getlist('user_ids')
    types = request.POST.getlist('types')
    try:
        ChannelValidator.check_urls(urls)
        users = ChannelValidator.check_user_ids(user_ids)
        channel = Channel.objects.create_one(
            request.user, form, urls, users, types)
    except Exception, ex:
        logger.error('create channel fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})

    return JsonHttpResponse({'status': 0, 'data': {'tag': channel.tag}})


@login_required(login_url=login_url)
def update(request, channel_id):

    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'msg': '支持post请求'})

    try:
        channel = Channel.objects.get(id = channel_id)
    except Exception, ex:
        logger.error('get channel fail, id:(%s)' % str(channel_id))
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '获取渠道信息失败，id:(%s)' % str(channel_id)})

    if not channel.is_creator(request.user):
        logger.error(
            'only creator can delete the channel, id:(%s)' % str(channel_id))
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '无此权限，渠道号:(%s)' % channel.tag})

    if not request.POST:
        info = channel.get_info()
        return render(request, 'update_channel.html', 
                      {'channel_info': info, 'channel_id': channel_id})

    form = ChannelForm(request.POST, instance = channel)
    if not form.is_valid():
        return JsonHttpResponse(
            {'status':1,
             'msg':form.errors.items()})

    urls = request.POST.getlist('urls')
    user_ids = request.POST.getlist('user_ids')
    types = request.POST.getlist('types')
    try:
        ChannelValidator.check_urls(urls)
        users = ChannelValidator.check_user_ids(user_ids)
        logger.info('to update')
        Channel.objects.update_one(form, urls, users, types)
    except Exception, ex:
        logger.error('update channel fail, msg:(%s)' % str(ex))
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})

    return JsonHttpResponse({'status': 0})


@login_required(login_url=login_url)
def delete(request, channel_id):

    try:
        channel = Channel.objects.get(id = channel_id)
    except Exception, ex:
        logger.error('get channel fail, id:(%s)' % str(channel_id))
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '获取渠道信息失败，id:(%s)' % str(channel_id)})

    if not channel.is_creator(request.user):
        logger.error(
            'only creator can delete the channel, id:(%s)' % str(channel_id))
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '无此权限，渠道号:(%s)' % channel.tag})
    
    try:
        channel.delete_one()
    except Exception, ex:
        logger.error('delete channel fail, id:(%d)' % channel.id)
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '删除渠道失败，id:(%d)' % channel.id})

    return JsonHttpResponse({'status': 0})

@login_required(login_url=login_url)
def get_info(request, channel_id):

    try:
        channel = Channel.objects.get(id = channel_id)
    except Exception, ex:
        logger.error('get channel fail, id:(%s)' % str(channel_id))
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '获取渠道信息失败，id:(%s)' % str(channel_id)})

    if not channel.has_read_perm(request.user):
        logger.error(
            'not allowed, user:(%s), id:(%s)' \
                % (request.user.username, str(channel_id)))
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '无此权限，渠道号:(%s)' % channel.tag})

    info = channel.get_info()
    has_update_perm = channel.has_update_perm(request.user)
    has_delete_perm = channel.has_delete_perm(request.user)
    return render(request, 'view_channel.html', 
                  {'channel_info': info, 
                   'channel_id': channel_id,
                   'is_creator': channel.creator == request.user,
                   'has_update_perm': has_update_perm,
                   'has_delete_perm': has_delete_perm
                   })
    # return JsonHttpResponse(
        # {'status': 0, 'data': info})

@login_required(login_url='/business_channel/login/')
def index(request):
    yesterday = ArkTime.get_time(
        datetime.now(), offset = -1, str_result = True, cut_str = True)

    all_users = User.objects.filter(id__gt = 0)
    user_list = [{'id': user.id, 'name': user.username} for user in all_users]
    return render(request, 'channel_index.html', 
                  {'user': request.user, 'feat_date': yesterday,
                   'user_list': user_list})

def filter_channel(request, channels):

    filter_value = request.POST.get('search[value]', '')
    if filter_value:
        channels = channels.filter(
            Q(tag__contains = filter_value) | Q(name__contains = filter_value))

    filter_count = total_count = channels.count()

    draw = request.POST.get('draw')
    start = request.POST.get('start')
    length = request.POST.get('length')
    page = int(start) / int(length) + 1

    paginator = Paginator(channels, int(length))
    return paginator, page, draw, total_count, filter_count

def custom_table(request_user, channels, feats, draw, total_count, filter_count):
    result = {
        "draw":draw,
        "recordsTotal": total_count,
        "recordsFiltered": filter_count}
    
    channel_data = {}
    channel_name = {}

    datas = []
    feat_dict = {}
    for feat in feats:
        id, time, tag, sm_pv, sm_uv, channel_pv, channel_uv = feat
        feat_dict[tag] = {
            'sm_pv': sm_pv,
            'sm_uv': sm_uv,
            'channel_pv': channel_pv,
            'channel_uv': channel_uv,}
    
    for channel in channels:
        data = {}
        tag = channel.tag
        channel_data[tag] = channel.get_info()
        data['id'] = channel.id
        data['tag'] = channel.tag
        data['name'] = channel.name
        data['type'] = channel.type
        data['has_update_perm'] = channel.creator == request_user
        data['has_delete_perm'] = channel.creator == request_user
        for key in ('sm_pv', 'sm_uv', 'channel_pv', 'channel_uv'):
            data[key] = feat_dict.get(tag, {}).get(key, 0)
        datas.append(data)
    
    result['data'] = datas
    result['channel_data'] = channel_data
    return result

def query_yesterday_feats(channels):
    if not channels:
        return ()

    yesterday = ArkTime.get_time(
        datetime.now(), offset = -1, str_result = True, cut_str = True)
    feats = ChannelFeat.query(channels, yesterday)
    return feats

@login_required(login_url=login_url)
def list(request):
    
    allow_channels = Channel.get_allow_channels(request.user)
    allow_ids = [channel.id for channel in allow_channels]

    channels = Channel.objects.filter(
        Q(creator = request.user) | Q(id__in = allow_ids))\
        .exclude(deleted = True)
    
    paginator, page, draw, total_count, filter_count = \
        filter_channel(request, channels)
    try:
        channels = paginator.page(page)
    except PageNotAnInteger:
        channels = paginator.page(1)
    except EmptyPage:
        channels = paginator.page(paginator.num_pages)

    feats = query_yesterday_feats(channels)

    result = custom_table(request.user, channels, feats, int(draw), total_count, filter_count)
    return JsonHttpResponse(result)


@login_required(login_url=login_url)
def query_feat(request, channel_id):
    
    if not request.method == 'POST':
        return JsonHttpResponse({'status': 1, 'msg': '支持post请求'})

    try:
        channel = Channel.objects.get(id = channel_id)
    except Exception, ex:
        logger.error('get channel fail, id:(%s)' % str(channel_id))
        return JsonHttpResponse(
            {'status': 1, 
             'msg': '获取渠道信息失败，id:(%s)' % str(channel_id)})

    end_time = request.POST.get('end_time', None)
    yesterday = ArkTime.get_time(
        datetime.now(), offset = -1, str_result = True, cut_str = True)

    if not end_time:
        end_time = yesterday

    last_week = ArkTime.get_pre_week(
        yesterday, str_result = True, cut_str = True)
    start_time = request.POST.get('start_time', last_week)
    if not start_time:
        start_time = last_week
    
    feats = ChannelFeat.query([channel], start_time, end_time)

    if not feats:
        return JsonHttpResponse({'status': 1, 'msg': '该时段无指标数据', 'data': feats})
    else:
        return JsonHttpResponse({'status': 0, 'data': feats})
    
