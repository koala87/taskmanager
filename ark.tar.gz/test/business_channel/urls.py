from django.conf.urls import patterns, url
from business_channel import views
from business_channel import captcha_views

urlpatterns = patterns('',
    url(r'^$',views.index),
    url(r'^login/$',views.login),
    url(r'^logout/$',views.logout),
    url(r'^index/$',views.index),
    url(r'^register/$',views.register),
    url(r'^reset_password/$',views.reset_password),
    url(r'^update_user/$',views.update_user),
    url(r'^create/$',views.create),
    url(r'^update/(?P<channel_id>\d+)/?$',views.update),
    url(r'^delete/(?P<channel_id>\d+)/?$',views.delete),
    url(r'^get_info/(?P<channel_id>\d+)/?$',views.get_info),
    url(r'^list/$',views.list),
    url(r'^query_feat/(?P<channel_id>\d+)/?$', views.query_feat),

    url(r'^captcha/$',captcha_views.code),
)
