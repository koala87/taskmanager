#encoding:utf-8
import sys
import random
import re
import logging
from django.core.validators import MaxLengthValidator
from django.core.validators import RegexValidator
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)
from common.perm_defines import PERM_TYPE_READ
from common.ark_perm import UserPerm
from common.models import FeatTable
from channel_manager import ChannelManager
from common.models import Config

class Channel(models.Model):

    # 有权限访问全部渠道的用户列表
    ALLOW_USERS_CONFIG_KEY = 'business_channel_reader'

    class Meta:
        permissions = (
            (PERM_TYPE_READ, 'read'),)

    creator = models.ForeignKey(User, related_name = 'channel_creator')

    random_id = models.PositiveIntegerField(unique = True)
    # 提供给合作方的渠道标识，由特定前缀+6位随机数组成
    tag = models.CharField(max_length = 16, unique = True)
    name = models.CharField(
        max_length = 128, unique = True,
        validators = [
            MaxLengthValidator,
            RegexValidator(
                regex = u'^[a-zA-Z0-9_\u4e00-\u9fa5]+$',
                message = '名称必须由字母数字下划线和中文组成')
            ])

    # hot:热词 search:搜索框 其他值:其他类型
    # hot与search可以共现，其他值与hot和search互斥
    type = models.CharField(
        max_length = 32, default = '',
        validators = [
            MaxLengthValidator,
            RegexValidator(
                regex = u'^[a-zA-Z0-9_\u4e00-\u9fa5]+$',
                message = '名称必须由字母数字下划线和中文组成')
            ])

    # 负责人人名
    owner_name = models.CharField(
        max_length = 32,
        validators = [
            MaxLengthValidator
            ])
    description = models.CharField(
        max_length = 1024, blank = True, default = '',
        validators = [
            MaxLengthValidator
            ])

    deleted = models.BooleanField(default = 0)

    create_time = models.DateTimeField(auto_now_add = True)
    update_time = models.DateTimeField(auto_now = True)

    CHANNEL_PREFIX = 'wa'
    MAX_RANDOM_ID = 999999
    MAX_RANDOM_LEN = 6
    TYPE_SEP = ','
    @staticmethod
    def make_type_str(type):
        items = []
        if isinstance(type, list):
            for item in type:
                item = item.strip()
                if not item:
                    continue
                items.append(item)
            type = Channel.TYPE_SEP.join(items)
        return type
    @staticmethod
    def parse_type_str(type):
        if isinstance(type, basestring):
            type = type.split(Channel.TYPE_SEP)
        return type

    @staticmethod
    def name_exists(name, instance = None):
        channels = Channel.objects.filter(name = name)
        if instance:
            channels = channels.exclude(id = instance.id)
        return channels.exists()

    @staticmethod
    # 生成一个与现有不重的随机数
    # 已有随机数排序；获取所有大于1的区间；随机选择一个区间；随机选择一个数
    def gen_random_id():
        random_ids = Channel.objects.values_list('random_id', flat = True)\
            .order_by('random_id')
        random_ids = list(random_ids)

        ranges = []
        last_id = 0
        for id in random_ids:
            if id - last_id > 1:
                ranges.append([last_id, id])
            last_id = id
            
        if Channel.MAX_RANDOM_ID - last_id > 1:
            ranges.append([last_id, Channel.MAX_RANDOM_ID])
        
        if not ranges:
            raise Exception('渠道已达上限')

        idx = random.randint(0, len(ranges) - 1)
        start, end = ranges[idx]
        random_id = random.randint(start + 1, end - 1)
        
        return random_id

    @staticmethod
    def gen_tag():
        random_id = Channel.gen_random_id()
        tag = Channel.CHANNEL_PREFIX \
            + str(random_id).zfill(Channel.MAX_RANDOM_LEN)
        return random_id, tag

    @staticmethod
    def get_configed_users():

        usernames = []
        try:
            users_config = Config.objects.get_value(Channel.ALLOW_USERS_CONFIG_KEY)
            usernames = users_config.split(',')
            usernames = [v.strip() for v in usernames]
        except Exception, ex:
            logger.error("get allow users config fail: (%s)" % str(ex))
        return usernames

    @staticmethod
    def get_allow_channels(user):
        channels = []
        try:
            usernames = Channel.get_configed_users()
            if user.username in usernames:
                channels = Channel.objects.all()

        except Exception, ex:
            logger.error("get allow users config fail: (%s)" % str(ex))

        if not channels:
            channels = UserPerm.get_objs_for_user(
                user, app = Channel._meta.app_label, 
                perms = [PERM_TYPE_READ])

        return channels

    def has_read_perm(self, user):
        usernames = Channel.get_configed_users()
        return self.is_creator(user) \
            or UserPerm.has_read_perm(user, self) \
            or user.username in usernames

    def has_delete_perm(self, user):
        return self.is_creator(user)
    def has_update_perm(self, user):
        return self.is_creator(user)

    def is_creator(self, user):
        return self.creator == user

    def update_url(self, urls, new_channel = False):
        if new_channel:
            old_urls = []
        else:
            old_urls = self.channel_url.values_list('url', flat = True)
            old_urls = list(old_urls)

        to_delete = list(set(old_urls) - set(urls))
        to_add = list(set(urls) - set(old_urls))
        for url in to_delete:
            self.channel_url.filter(url = url).delete()
        for url in to_add:
            self.channel_url.create(url = url)

    # user_ids: [user_id1, user_id2]
    def update_access(self, users, new_channel = False):

        if new_channel:
            old_users = []
        else:
            old_users = UserPerm.get_allowed_users(self)

        to_delete = list(set(old_users) - set(users))
        to_add = list(set(users) - set(old_users))
        for user in to_delete:
            UserPerm.revoke(self.creator, user, self)
        for user in to_add:
            UserPerm.grant(self.creator, user, self)

    def update_info(self, name, type, owner_name, description,
                    urls, user_ids):
        self.name = name
        self.type = Channel.make_type_str(type)
        self.owner_name = owner_name
        self.description = description
        self.save()
        
        self.update_url(urls)
        self.update_access(user_ids)

    def delete_one(self):
        self.name = self.name + '_delete_' + str(self.id)
        self.deleted = True
        self.save()

    def get_access_users(self):
        users = UserPerm.get_allowed_users(self)
        return users.keys()

    def get_access_info(self):
        users = self.get_access_users()
        info = {}
        for user in users:
            info[user.id] = user.username
        return info

    def to_dict(self):
        return model_to_dict(self)

    # 
    def get_info(self):
        urls = list(self.channel_url.values_list('url', flat = True))
        access_info = self.get_access_info()
        
        info = {'creator': self.creator.username,
                'name': self.name,
                'type': Channel.parse_type_str(self.type),
                'owner_name': self.owner_name,
                'description': self.description,
                'tag': self.tag,
                'url': urls,
                'access': access_info}
        return info

    objects = ChannelManager()


class ChannelUrl(models.Model):
    channel = models.ForeignKey(Channel, related_name = 'channel_url')
    url = models.CharField(max_length = 256)

    url_pattern = '^(?=^.{3,255}$)[a-zA-Z0-9][-a-zA-Z0-9]{0,62}'\
        '(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+$$'
    @staticmethod
    def is_valid(url):
        return re.match(ChannelUrl.url_pattern, url)


class ChannelValidator():
    
    @staticmethod
    def check_urls(urls):
        if not urls:
            raise Exception('至少指定一个域名')

        for url in urls:
            if not isinstance(url, basestring) or not ChannelUrl.is_valid(url):
                logger.error('invalid url:(%s)' % str(url))
                raise Exception('无效的域名:(%s)' % str(url))

    @staticmethod
    def check_user_ids(user_ids):
        users = []
        for user_id in user_ids:
            if not user_id:
                continue
            try:
                user = User.objects.get(pk = user_id)
                users.append(user)
            except Exception, ex:
                logger.error('get user fail, id:(%s), msg:(%s)' \
                                 % (str(user_id), str(ex)))
                raise Exception('获取用户信息失败，id:(%s)' % str(user_id))
        return users


class ChannelFeat():
    table = 'business_channel_feat'
    time_column = 'time'

    dsp_tag_time = '时间'
    dsp_tag_sm_pv = '神马输出流量'
    dsp_tag_sm_uv = '神马输出用户'
    dsp_tag_channel_pv = '站点导入流量'
    dsp_tag_channel_uv = '站点导入用户'

    @staticmethod
    def query(channels, start_time, end_time = None):
        if not channels:
            return ()

        if not end_time:
            end_time = start_time

        tags = ["'%s'" % channel.tag for channel in channels]
        tag_in_str = ','.join(tags)

        day_format = '%%Y%%m%%d'
        sql = "select id, date_format(time, '%s') as time, channel_tag, "\
            "sm_pv, sm_uv, channel_pv, channel_uv from %s where "\
            "%s >= '%s' and %s <= '%s' and channel_tag in (%s) order by %s" \
            % (day_format,
               ChannelFeat.table,
               ChannelFeat.time_column,
               start_time,
               ChannelFeat.time_column,
               end_time, 
               tag_in_str, 
               ChannelFeat.time_column)

        logger.info('query feat, sql: (%s)' % sql)
        result = FeatTable.execute(sql)
        return result

class OuterUser():
    @staticmethod
    def create(username, password, email):
        try:
            user = User.objects.create_user(
                username, email, password)
            user.is_staff = False
            user.save()
        except Exception, ex:
            logger.error('create outer user fail: (%s)' % str(ex))
            raise Exception('注册用户出错，请联系管理员')

    @staticmethod
    def update(user, password, email):
        try:
            if password:
                user.set_password(password)
            if email:
                user.email = email
            user.save()
        except Exception, ex:
            logger.error('update outer user fail: (%s)' % str(ex))
            raise Exception('修改用户信息出错，请联系管理员')        

    @staticmethod
    def is_inner_user(user):
        return user.is_staff
        
