import os
from django.test import TestCase
from django.contrib.auth.models import User
from django.conf import settings

from common.models import FeatTable
from models import Channel
from models import ChannelFeat

# Create your tests here.
class ChannelFeatTest(TestCase):

    def setUp(self):
        self.user1 = User.objects.create(
            username = 'user1', email = 'jianfeng.liujf1@alibaba-inc.com')
        self.user2 = User.objects.create(username = 'user2')
        self.user3 = User.objects.create(username = 'user3')

        self.ark_admin = User.objects.create(
            username = 'ark_admin',
            email = 'jianfeng.liujf1@alibaba-inc.com')
        self.channel1 = Channel.objects.create(
            creator = self.user1,
            random_id = 1,
            tag = 'wa000001',
            name = 'test_channel1',
            type = ['hot', 'search'],
            owner_name = 'jianfeng.liujf1',
            description = 'desc')

        self.channel2 = Channel.objects.create(
            creator = self.user1,
            random_id = 2,
            tag = 'wa000002',
            name = 'test_channel2',
            type = ['hot', 'search'],
            owner_name = 'jianfeng.liujf1',
            description = 'desc)')

        db_name = 'ark_feature'
        feat_tb_name = ChannelFeat.table
        sql = 'create table %s like %s.%s' % (
            feat_tb_name, db_name, feat_tb_name)
        FeatTable.execute(sql)

        data_file = os.path.dirname(__file__) + '/test_feat_data'
        FeatTable.execute(
            "load data local infile '%s' into table %s "\
                "(time, channel_tag, sm_pv, sm_uv, channel_pv, channel_uv)"\
                %  (data_file, feat_tb_name))


    def test_query(self):
        channels = [self.channel1, self.channel2]
        result = ChannelFeat.query(channels, '20150908')
        self.assertEqual(len(result), 2)

        result = ChannelFeat.query(channels, '20150908', '20150909')
        self.assertEqual(len(result), 4)

        result = ChannelFeat.query([self.channel1], '20150908')
        print result
        self.assertEqual(len(result), 1)
        
