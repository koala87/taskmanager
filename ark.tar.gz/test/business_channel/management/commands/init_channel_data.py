import logging
import traceback
from optparse import make_option
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)
from django.core.management.base import BaseCommand, CommandError
from business_channel.models import Channel, ChannelUrl
from django.contrib.auth.models import User

class Command(BaseCommand):

    option_list = BaseCommand.option_list + (
        make_option('--init',
                    dest='init',
                    default=0,
                    type='int',
                    help='if clean old data first'),
        make_option('--file',
                    dest='data_file',
                    help='channel data file'),
        make_option('--username',
                    dest='username',
                    help='username'),
        )

    def clean_channel(self):
        ChannelUrl.objects.all().delete()
        Channel.objects.all().delete()

    def handle(self, *args, **options):
        init = options.get('init', 0)
        data_file = options.get('data_file', '')
        username = options.get('username', '')

        if not data_file:
            raise Exception('data file required')
        if not username:
            raise Exception('username required')

        logger.info('Run init_channel_data... init:%d, data_file:%s' %
                    (init, data_file))
        
        try:
            creator = User.objects.get(username = username)
        except Exception, ex:
            logger.error('invalid user: (%s)' % username)
            raise ex

        try:

            if init:
                self.clean_channel()

            f = open(data_file, 'r')
            for line in f:
                line = line.strip()
                items = line.split('`')
                if len(items) != 5:
                    logger.error('invalid line: (%s), len: (%d)' % (line, len(items)))
                    continue
                name, tag, url, type, owner_name = items
                
                random_id = 0
                try:
                    random_id = int(tag[2:])
                except Exception, ex:
                    logger.error('invalid random_id: (%s)' % tag[2:])
                    continue

                channel = Channel()
                channel.name = name
                channel.tag = tag
                channel.creator = creator
                channel.random_id = random_id
                channel.type = type.replace('+', ',').replace('/', ',')
                channel.owner_name = owner_name
                channel.save()

                logger.info('add channel: (%s)' % line)
                
                channel_url = ChannelUrl()
                channel_url.channel = channel
                channel_url.url = url
                channel_url.save()
                logger.info('add channel url: (%s)' % url)

        except Exception, ex:
            logger.error('open file %s fail, msg: (%s)' % (data_file, str(ex)))
            raise ex


