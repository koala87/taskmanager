#coding=utf-8
import json
import logging
from datetime import datetime
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)
from common.http_helper import JsonHttpResponse
from common.ark_captcha import Captcha

def code(request):
    captcha_key, captcha_img = Captcha.generate()
    return JsonHttpResponse(
        {'status':0, 'msg':'ok',
         'captcha': {'key': captcha_key, 'img': captcha_img}})

