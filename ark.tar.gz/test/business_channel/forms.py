#coding=utf-8
import re
from django import forms
from django.forms import ModelForm, Textarea
from models import Channel

email_errors = {
    'required':'邮箱不能为空！',
    'duplicate_email': '此邮箱已注册！',
    'invalid': '邮箱格式不正确！'
}
password_errors = {
    'required':'密码不能为空！',
}

class ChannelForm(ModelForm):

    name = forms.CharField(
        label='名称',
        widget = forms.TextInput(
            attrs={'class':'form-control',
                   'placeholder':'中文、字母、数字、下划线'
                   }),
        error_messages={
            'required':'不能为空',
            'unique':'已存在同名渠道',
            'invalid': '含有非法字符'}
        )

    owner_name = forms.CharField(
        label='负责人',
        widget = forms.TextInput(
            attrs={'class':'form-control',
                   'placeholder':'中文、字母、数字、下划线'
                   }),
        error_messages={
            'required':'不能为空',
            'invalid': '含有非法字符'}
        )

    description = forms.CharField(
        label='描述',
        widget = forms.Textarea(
            attrs={'class':'form-control',
                   'cols': 80, 'rows': 5,
                   'placeholder': '描述信息'
                   }),
        required=False) 

    class Meta: 
        model = Channel
        fields = ('name', 'owner_name', 'description')


class UpdateUserForm(forms.Form):
    password = forms.CharField(label='密码',widget=forms.PasswordInput(
                attrs={'class':'form-control'}),
                required=False,
                error_messages=password_errors
                )
    email = forms.EmailField(label='邮箱',widget=forms.TextInput(
                attrs={'class':'form-control'}),error_messages=email_errors)








