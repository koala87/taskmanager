#encoding:utf-8
import sys
reload(sys)  
sys.setdefaultencoding('utf-8')
import logging
from django.db import models
from django.db.models import Avg
from django.conf import settings
import traceback

logger = logging.getLogger(settings.PROJECT_NAME)

class ChannelManager(models.Manager):

    def create_one(self, creator, form, urls = [], users = [], types = []):

        try:
            random_id, tag = self.model.gen_tag()
        except Exception, ex:
            logger.error('generate channel_id fail: (%s)' % str(ex))
            raise Exception('生成渠道号出错')

        channel = None
        try:
            channel = form.save(commit = False)
            channel.random_id = random_id
            channel.tag = tag
            type = self.model.make_type_str(types)
            channel.type = type
            logger.info(types)
            logger.info(channel.type)
            channel.creator = creator
            channel.save()

            channel.update_url(urls, new_channel = True)
            channel.update_access(users, new_channel = True)
        except Exception, ex:
            logger.error('create channel fail: (%s)' % str(ex))
            print traceback.format_exc()
            raise Exception('创建渠道号出错')

        return channel        


    def update_one(self, form, urls, users, types):

        try:
            channel = form.save(commit = False)
            type = self.model.make_type_str(types)
            channel.type = type
            channel.save()

            channel.update_url(urls, new_channel = False)
            channel.update_access(users, new_channel = False)
        except Exception, ex:
            logger.error('update channel fail: (%s)' % str(ex))
            raise Exception('更新渠道号出错')

        return channel        








