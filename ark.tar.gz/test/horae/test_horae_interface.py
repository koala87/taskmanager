﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import copy
import random

import django.test
import horae.models
import common.models
import mock
import dms.models

import horae_interface
import tools_util
import django.contrib.auth.models
import graph_manager
import common_logger

class TestHoraeInterface(django.test.TestCase):
    """
        测试horae接口
    """
    def setUp(self):
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        tools_util.CONSTANTS.GLOBAL_STOP = True
        self.__horae_logger = common_logger.get_logger(
                "common", 
                "./log/horae")
        self.__horae_interface = horae_interface.HoraeInterface(
                self.__horae_logger)
        self.__horae_interface._HoraeInterface__pipeline_mgr.\
                _PipelineManager__admin_port = 6271

        now_time = tools_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                project_id=0,
                private=1)

        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        self.__user1 = django.contrib.auth.models.User.objects.create(
                id=1,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        django.contrib.auth.models.User.objects.create(
                id=2,
                password='sdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user2',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        self.__config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=2,
                name="2", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                project_id=0,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=3,
                name="3", 
                owner_id=1, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                project_id=0,
                monitor_way=1,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=4,
                name="4", 
                owner_id=1, 
                ct_time='8 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                project_id=0,
                enable=1,
                private=0)

        horae.models.Pipeline.objects.create(
                id=5,
                name="5", 
                owner_id=1, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                project_id=0,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=6,
                name="test_2_1", 
                owner_id=2, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                project_id=0,
                monitor_way=1,
                enable=1,
                private=1)

        common.models.PermHistory.objects.create(
                id=1,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=6,
                permission='read',
                applicant_id=1,
                grantor_id=2,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')

        common.models.PermHistory.objects.create(
                id=2,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=5,
                permission='read',
                applicant_id=1,
                grantor_id=2,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')

        horae.models.Pipeline.objects.create(
                id=7,
                name="test_2_2", 
                owner_id=2, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                project_id=0,
                enable=1,
                private=0)

        horae.models.Task.objects.create(
                id=4,
                pl_id=2,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='task_4',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=5,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4',
                over_time=12,
                name='task_5',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=7,
                pl_id=3,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_7',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=8,
                pl_id=4,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_8',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=9,
                pl_id=5,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_9',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        graph_mgr._GraphGroup__graph.clear()
        graph_mgr._GraphGroup__sub_graph_list = []
        graph_mgr._GraphGroup__create_graph()
    def test_show_pipeline(self):
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=0,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None), 
            """{"status": 0, "info": "OK", "count": 7, "pipe_list": [{"username":"""
            """ "test_user2", "update_time": "2015-05-05 10:00:00","""
            """ "enable": 1, "name": "test_2_2", "permission": 0, "tag":"""
            """ "", "ct_time": "1,2,3,4,5 * * * *", "id": 7}, {"username":"""
            """ "test_user2", "update_time": "2015-05-05 10:00:00", "enable": 1,"""
            """ "name": "test_2_1", "permission": 1, "tag": "", "ct_time":"""
            """ "1,2,3,4,5 * * * *", "id": 6}, {"username": "test_user","""
            """ "update_time": "2015-05-05 10:00:00", "enable": 1, "name":"""
            """ "a", "permission": 2, "tag": "", "ct_time": "0 1 * * *","""
            """ "id": 1}, {"username": "test_user", "update_time":"""
            """ "2015-05-05 10:00:00", "enable": 1, "name": "5", "permission":"""
            """ 2, "tag": "", "ct_time": "1,2,3,4,5 * * * *", "id": 5},"""
            """ {"username": "test_user", "update_time": "2015-05-05 10:00:00","""
            """ "enable": 1, "name": "4", "permission": 2, "tag": "","""
            """ "ct_time": "8 * * * *", "id": 4}, {"username": "test_user","""
            """ "update_time": "2015-05-05 10:00:00", "enable": 1, "name":"""
            """ "3", "permission": 2, "tag": "", "ct_time": "1 5 * * *", "id":"""
            """ 3}, {"username": "test_user", "update_time": "2015-05-05"""
            """ 10:00:00", "enable": 1, "name": "2", "permission": 2,"""
            """ "tag": "", "ct_time": "1 2 3 * *", "id": 2}]}""")
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=1,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None),
            """{"status": 0, "info": "OK", "count": 5, "pipe_list": [{"username":"""
            """ "test_user", "update_time": "2015-05-05 10:00:00", "enable":"""
            """ 1, "name": "a", "permission": 2, "tag": "", "ct_time":"""
            """ "0 1 * * *", "id": 1}, {"username": "test_user","""
            """ "update_time": "2015-05-05 10:00:00", "enable": 1, "name":"""
            """ "5", "permission": 2, "tag": "","""
            """ "ct_time": "1,2,3,4,5 * * * *","""
            """ "id": 5}, {"username": "test_user", "update_time":"""
            """ "2015-05-05 10:00:00", "enable": 1, "name": "4","""
            """ "permission":"""
            """ 2, "tag": "", "ct_time": "8 * * * *", "id": 4}, {"username":"""
            """ "test_user", "update_time": "2015-05-05 10:00:00", "enable":"""
            """ 1, "name": "3", "permission": 2, "tag": "", "ct_time":"""
            """ "1 5 * * *", "id": 3}, {"username": "test_user","""
            """ "update_time":"""
            """ "2015-05-05 10:00:00", "enable": 1, "name": "2","""
            """ "permission": 2,"""
            """ "tag": "", "ct_time": "1 2 3 * *", "id": 2}]}""")
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=2,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None),
            """{"status": 0, "info": "OK", "count": 1, "pipe_list":"""
            """ [{"username": "test_user2", "update_time": "2015-05-05"""
            """ 10:00:00", "enable": 1, "name": "test_2_1","""
            """ "permission": 1, "tag": "", "ct_time": "1,2,3,4,5"""
            """ * * * *", "id": 6}]}""")
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=3,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None),
            """{"status": 0, "info": "OK", "count": 1, "pipe_list":"""
            """ [{"username": "test_user2", "update_time": "2015-05-05"""
            """ 10:00:00", "enable": 1, "name": "test_2_2", "permission":"""
            """ 0, "tag": "", "ct_time": "1,2,3,4,5 * * * *", "id": 7}]}""")
    
        self.__user1.is_superuser = 1
        self.__user1.save()
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=0,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None), 
            """{"status": 0, "info": "OK", "count": 7, "pipe_list": [{"username":"""
            """ "test_user2", "update_time": "2015-05-05 10:00:00","""
            """ "enable": 1, "name": "test_2_2", "permission": 2, "tag":"""
            """ "", "ct_time": "1,2,3,4,5 * * * *", "id": 7}, {"username":"""
            """ "test_user2", "update_time": "2015-05-05 10:00:00", "enable": 1,"""
            """ "name": "test_2_1", "permission": 2, "tag": "", "ct_time":"""
            """ "1,2,3,4,5 * * * *", "id": 6}, {"username": "test_user","""
            """ "update_time": "2015-05-05 10:00:00", "enable": 1, "name":"""
            """ "a", "permission": 2, "tag": "", "ct_time": "0 1 * * *","""
            """ "id": 1}, {"username": "test_user", "update_time":"""
            """ "2015-05-05 10:00:00", "enable": 1, "name": "5", "permission":"""
            """ 2, "tag": "", "ct_time": "1,2,3,4,5 * * * *", "id": 5},"""
            """ {"username": "test_user", "update_time": "2015-05-05 10:00:00","""
            """ "enable": 1, "name": "4", "permission": 2, "tag": "","""
            """ "ct_time": "8 * * * *", "id": 4}, {"username": "test_user","""
            """ "update_time": "2015-05-05 10:00:00", "enable": 1, "name":"""
            """ "3", "permission": 2, "tag": "", "ct_time": "1 5 * * *", "id":"""
            """ 3}, {"username": "test_user", "update_time": "2015-05-05"""
            """ 10:00:00", "enable": 1, "name": "2", "permission": 2,"""
            """ "tag": "", "ct_time": "1 2 3 * *", "id": 2}]}""")
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=1,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None),
            """{"status": 0, "info": "OK", "count": 5, "pipe_list": [{"username":"""
            """ "test_user", "update_time": "2015-05-05 10:00:00", "enable":"""
            """ 1, "name": "a", "permission": 2, "tag": "", "ct_time":"""
            """ "0 1 * * *", "id": 1}, {"username": "test_user","""
            """ "update_time": "2015-05-05 10:00:00", "enable": 1, "name":"""
            """ "5", "permission": 2, "tag": "","""
            """ "ct_time": "1,2,3,4,5 * * * *","""
            """ "id": 5}, {"username": "test_user", "update_time":"""
            """ "2015-05-05 10:00:00", "enable": 1, "name": "4","""
            """ "permission":"""
            """ 2, "tag": "", "ct_time": "8 * * * *", "id": 4}, {"username":"""
            """ "test_user", "update_time": "2015-05-05 10:00:00", "enable":"""
            """ 1, "name": "3", "permission": 2, "tag": "", "ct_time":"""
            """ "1 5 * * *", "id": 3}, {"username": "test_user","""
            """ "update_time":"""
            """ "2015-05-05 10:00:00", "enable": 1, "name": "2","""
            """ "permission": 2,"""
            """ "tag": "", "ct_time": "1 2 3 * *", "id": 2}]}""")
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=2,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None),
            """{"status": 0, "info": "OK", "count": 1, "pipe_list":"""
            """ [{"username": "test_user2", "update_time": "2015-05-05"""
            """ 10:00:00", "enable": 1, "name": "test_2_1","""
            """ "permission": 2, "tag": "", "ct_time": "1,2,3,4,5"""
            """ * * * *", "id": 6}]}""")
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=3,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None),
            """{"status": 0, "info": "OK", "count": 1, "pipe_list":"""
            """ [{"username": "test_user2", "update_time": "2015-05-05"""
            """ 10:00:00", "enable": 1, "name": "test_2_2", "permission":"""
            """ 2, "tag": "", "ct_time": "1,2,3,4,5 * * * *", "id": 7}]}""")
    def test_get_pipeline_info(self):
        common.models.PermHistory.objects.create(
                id=3,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=1,
                permission=tools_util.UserPermissionType.WRITE_STR,
                applicant_id=2,
                grantor_id=1,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        self.assertEqual(
                self.__horae_interface.get_pipeline_info(1),
                """{"status": 0, "info": "OK", "pipeline": {"update_time":"""
                """ "2015-05-05 10:00:00", "enable": 1, "name": "a","""
                """ "life_cycle": "12", "type": 0, "description": "hello","""
                """ "monitor_way": 1, "private": 1, "sms_to": "123123123","""
                """ "tag": "", "email_to": "xielei@shenma-inc.com","""
                """ "owner_list": [{"username": "test_user", "id": 1},"""
                """ {"username": "test_user2", "id": 2}], "project_id": 0, "ct_time":"""
                """ "0 1 * * *", "id": 1, "owner_id": 1}}""")

    def test_get_all_user_info(self):
        self.assertEqual(
                self.__horae_interface.get_all_user_info(),
                """{"status": 0, "info": "OK", "users": [{"username":"""
                """ "test_user", "id": 1}, {"username": "test_user2","""
                """ "id": 2}]}""")

    def test_delete_pipeline(self):
        horae.models.Pipeline.objects.create(
                id=7999,
                name="test_delete_2", 
                owner_id=3, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=0)
        django.contrib.auth.models.User.objects.create(
                id=3,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user3',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        self.assertEqual(
                self.__horae_interface.delete_pipeline(3, 7999),
                """{"status": 0, "info": "OK"}""")
        horae.models.Pipeline.objects.create(
                id=79998,
                name="test_delete_2", 
                owner_id=3, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=0)
        self.assertEqual(
                self.__horae_interface.delete_pipeline(2, 79998),
                """{"status": 1, "info": "owner id """
                """has no auth to delete data!"}""")
        common.models.PermHistory.objects.create(
                id=7999,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=79998,
                permission='write',
                applicant_id=2,
                grantor_id=2,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        self.assertEqual(
                self.__horae_interface.delete_pipeline(2, 79998),
                """{"status": 0, "info": "OK"}""")

    def test_update_pipeline(self):
        horae.models.Pipeline.objects.create(
                id=7999,
                name="test_delete_2", 
                owner_id=3, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=0)
        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=3, 
                name="test_delete_3", 
                manager_id_list='6,4,5'),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(id=7999)
        self.assertEqual(pipeline.name, """test_delete_3""")
        perm_his = common.models.PermHistory.objects.filter(
                grantor_id=3, 
                applicant_id__in=(6, 4, 5))
        self.assertEqual(len(perm_his), 3)

        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=6, 
                name="test_delete_4", 
                manager_id_list='6, 5'),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(id=7999)
        self.assertEqual(pipeline.name, """test_delete_4""")
        perm_his = common.models.PermHistory.objects.filter(
                resource_id=7999,
                grantor_id=3, 
                applicant_id__in=(6, 4, 5))
        for perm in perm_his:
            if perm.applicant_id == 4 and perm.grantor_id == 6:
                self.assertEqual(
                        perm.status,
                        tools_util.AuthAction.TAKE_BACK_AUTH)
            else:
                self.assertEqual(
                        perm.status,
                        tools_util.AuthAction.GRANT_AUTH_TO_OTHER)

        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=6, 
                name="test_delete_19", 
                manager_id_list='6, 5'),
                """{"status": 0, "info": "OK"}""")
        perm_his = common.models.PermHistory.objects.filter(
                resource_id=7999,
                grantor_id=3, 
                applicant_id__in=(6, 4, 5))

        pipeline = horae.models.Pipeline.objects.get(id=7999)
        self.assertEqual(pipeline.name, """test_delete_19""")

        self.assertEqual(
                self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=60, 
                name="test_delete_19", 
                manager_id_list='6, 5'),
                """{"status": 1, "info":"""
                """ "owner id has no auth to update data!"}""")

    def test_create_new_pipeline(self):
        django.contrib.auth.models.User.objects.create(
                id=10,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user3',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        self.assertEqual(
                self.__horae_interface.create_new_pipeline(
                name='new_pipe', 
                ct_time='1 * * * *', 
                owner_id=10, 
                manager_id_list='71,81,91', 
                monitor_way=2, 
                tag='a,b,c,d', 
                description='no no'),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(name='new_pipe')
        perm_his = common.models.PermHistory.objects.filter(
                grantor_id=10, 
                applicant_id__in=(71, 81, 91))
        self.assertEqual(len(perm_his), 3)

    def test_pipeline_off_or_on_line(self):
        horae.models.Pipeline.objects.create(
                id=7999,
                name="test_delete_2", 
                owner_id=3, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=0,
                private=1)
        django.contrib.auth.models.User.objects.create(
                id=3,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user3',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        django.contrib.auth.models.User.objects.create(
                id=71,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user71',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        django.contrib.auth.models.User.objects.create(
                id=88,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=1,
                username='test_user88',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        self.assertEqual(self.__horae_interface.pipeline_off_or_on_line(
                owner_id=3, 
                pipeline_id=7999, 
                on_line=1,
                reason='test'),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(id=7999)
        self.assertEqual(pipeline.enable, 2)
        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=3, 
                manager_id_list='71, 72'),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(self.__horae_interface.pipeline_off_or_on_line(
                owner_id=71, 
                pipeline_id=7999, 
                on_line=0,
                reason="no"),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(id=7999)
        self.assertEqual(pipeline.enable, 0)
        self.assertEqual(self.__horae_interface.pipeline_off_or_on_line(
                owner_id=100, 
                pipeline_id=7999, 
                on_line=1,
                reason="no"),
                """{"status": 1, "info":"""
                """ "owner id has no auth to update data!"}""")
        pipeline = horae.models.Pipeline.objects.get(id=7999)
        self.assertEqual(pipeline.enable, 0)

    def test_auth_grant_or_apply(self):
        self.assertEqual(self.__horae_interface.auth_grant_or_apply(
                action=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                resource_type=tools_util.CONSTANTS.PIPELINE, 
                resource_id=13, 
                granter_id=12, 
                acquirer_id_list=[1,2,3], 
                perm_level=tools_util.UserPermissionType.READ,
                reason="I like!"),
                """{"status": 1, "info":"""
                """ "this owener has no auth to grant permission"}""")
        self.assertEqual(self.__horae_interface.auth_grant_or_apply(
                action=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                resource_type=tools_util.CONSTANTS.PIPELINE, 
                resource_id=3, 
                granter_id=1, 
                acquirer_id_list=[2,3], 
                perm_level=tools_util.UserPermissionType.READ,
                reason="I like!"),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(self.__horae_interface.auth_grant_or_apply(
                action=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                resource_type=tools_util.CONSTANTS.PIPELINE, 
                resource_id=3, 
                granter_id=1, 
                acquirer_id_list=[4,3], 
                perm_level=tools_util.UserPermissionType.READ,
                reason="I like!"),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(self.__horae_interface.auth_grant_or_apply(
                action=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                resource_type=tools_util.CONSTANTS.PIPELINE, 
                resource_id=3, 
                granter_id=1, 
                acquirer_id_list=[4,3], 
                perm_level=tools_util.UserPermissionType.READ,
                reason="I like!"),
                """{"status": 0, "info": "OK"}""")

        perm_history = common.models.PermHistory.objects.filter(
                            resource_type=tools_util.CONSTANTS.PIPELINE,
                            resource_id=3,
                            applicant_id=3).latest('id')

    def test_get_tasks_by_pipeline_id(self):
        self.assertEqual(self.__horae_interface.get_tasks_by_pipeline_id(2), 
                """{"status": 1, "info": "OK", "tasks": [{"name": "task_4","""
                """ "except_ret": 0, "description": "", "proc_name": "a", "p"""
                """id": 1, "priority": 6, "retry_count": 3, "over_time": 12,"""
                """ "last_run_time": "", "server_tag": "ALL", "pl_id": 2, "n"""
                """ext_task_ids": "5,6", "config": "script_name = xl_test.py"""
                """\\n pre_script =\\n post_script =\\n args = xl_test.conf"""
                """\\n replace_confs = xl_test\\n log_file = application.log"""
                """\\n check_data =\\n _tpl = xl_test.conf.tpl\\n _out = xl_"""
                """test.conf\\n output_file = ./%year%_%month%_%day%_%hour%_"""
                """00@-1hour/*.log", "id": 4, "prev_task_ids": ","}, {"nam"""
                """e": "task_5", "except_ret": 0, "description": "", "proc_n"""
                """ame": "a", "pid": 1, "priority": 6, "retry_count": 3, "ov"""
                """er_time": 12, "last_run_time": "", "server_tag": "ALL","""
                """ "pl_id": 2, "next_task_ids": ",", "config": "script_name"""
                """ = xl_test.py\\n pre_script =\\n post_script =\\n args = """
                """xl_test.conf\\n replace_confs = xl_test\\n log_file = app"""
                """lication.log\\n check_data =\\n _tpl = xl_test.conf.tpl"""
                """\\n _out = xl_test.conf\\n output_file = ./%year%_%month%"""
                """_%day%_%hour%_00@-1hour/*.log", "id": 5, "prev_task_ids":"""
                """ ",4"}]}""")

    def test_get_task_info(self):
        self.assertEqual(self.__horae_interface.get_task_info(4), 
                """{"status": 0, "info": "OK", "task": {"name": "task_4", "e"""
                """xcept_ret": 0, "description": "", "proc_name": "a", "pi"""
                """d": 1, "priority": 6, "retry_count": 3, "over_time": 12"""
                """, "last_run_time": "", "server_tag": "ALL", "pl_id": 2"""
                """, "next_task_ids": "5,6", "config": "script_name = xl_tes"""
                """t.py\\n pre_script =\\n post_script =\\n args = xl_test.c"""
                """onf\\n replace_confs = xl_test\\n log_file = application."""
                """log\\n check_data =\\n _tpl = xl_test.conf.tpl\\n _out = """
                """xl_test.conf\\n output_file = ./%year%_%month%_%day%_%hou"""
                """r%_00@-1hour/*.log", "id": 4, "prev_task_ids": ","}}""")
        self.assertEqual(self.__horae_interface.get_task_info(4232), 
                """{"status": 1, "info": "visit mysql """
                """failed! please check db!"}""")

    def test_add_new_task_to_pipeline(self):
        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)      
        task = horae.models.Task.objects.get(name="task_14", pl_id=2)
        self.assertEqual(
                self.__horae_interface.add_new_task_to_pipeline(22, task),
                """{"status": 1, "info": "\\u521b\\u5efa\\u4efb\\u52a1\\u5931\\u8d25\\uff01reason[this owener has no auth to add new task]"}""")

    def test_add_new_task_to_pipeline_with_processor(self):
        processor = horae.models.Processor(
                name="test_new_proc", 
                type=1,
                update_time='2015-05-05 10:00:00',
                config=self.__config,
                owner_id=1)

        task = horae.models.Task(
                pl_id=2,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_proc_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(
                1, task, processor)  
        task = horae.models.Task.objects.get(name="task_proc_14", pl_id=2)
        self.assertEqual(
                self.__horae_interface.add_new_task_to_pipeline(22, task),
                """{"status": 1, "info": "\\u521b\\u5efa\\u4efb\\u52a1\\u5931\\u8d25\\uff01reason[this owener has no auth to add new task]"}""")

    def test_update_tasks(self):
        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)     
        task = horae.models.Task.objects.get(name="task_14", pl_id=2)
        self.__horae_interface.update_tasks(1, task)    
        self.assertEqual(self.__horae_interface.update_tasks(2, task),
                """{"status": 1, "info":"""
                """ "this owener has no auth to update task"}""")
        old_task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        task.next_task_ids = '1,2,3'
        self.__horae_interface.update_tasks(1, task, old_task)
        task = horae.models.Task.objects.get(name="task_14", pl_id=2)
        task.next_task_ids = '7,8,9'
        old_task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids='4,5',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.update_tasks(1, task, old_task)

    def test_delete_task_info(self):
        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)  
        task = horae.models.Task.objects.get(pl_id=2, name='task_14')
        self.assertEqual(self.__horae_interface.delete_task_info(1, task.id),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(self.__horae_interface.delete_task_info(1, task.id),
                """{"status": 1, "info":"""
                """ "Task matching query does not exist."}""")
        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)
        task = horae.models.Task.objects.get(pl_id=2, name='task_14')
        self.assertEqual(self.__horae_interface.delete_task_info(2, task.id),
                """{"status": 1, "info":"""
                """ "this owener has no auth to delete task"}""")

    def test_add_edge(self):
        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        graph_mgr._GraphGroup__graph.clear()
        graph_mgr._GraphGroup__sub_graph_list = []
        graph_mgr._GraphGroup__create_graph()
        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)    
        from_task = horae.models.Task.objects.get(name="task_14", pl_id=2)
        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_15',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)
        to_task = horae.models.Task.objects.get(name="task_15", pl_id=2)
        self.assertEqual(
                self.__horae_interface.add_edge(1, from_task.id, to_task.id),
                """{"status": 0, "info": "OK"}""")
        from_task = horae.models.Task.objects.get(name="task_14", pl_id=2)
        to_task = horae.models.Task.objects.get(name="task_15", pl_id=2)
        self.assertTrue(from_task.next_task_ids.find(str(to_task.id)) != -1)
        self.assertTrue(to_task.prev_task_ids.find(str(from_task.id)) != -1)

        self.assertEqual(
                self.__horae_interface.add_edge(1, from_task.id, to_task.id),
                """{"status": 0, "info": "OK"}""")
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        sub_graph_list = graph_mgr._GraphGroup__sub_graph_list
        edge_list = []
        for graph in sub_graph_list:
            for edge in graph.edges():
                edge_list.append(edge)
        
        self.assertTrue((str(from_task.id), str(to_task.id)) in edge_list)

    def test_delete_edge(self):
        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        graph_mgr._GraphGroup__graph.clear()
        graph_mgr._GraphGroup__sub_graph_list = []
        graph_mgr._GraphGroup__create_graph()

        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_14',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)

        from_task = horae.models.Task.objects.get(name="task_14", pl_id=2)
        task = horae.models.Task(
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_15',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='test add')
        self.__horae_interface.add_new_task_to_pipeline(1, task)
        to_task = horae.models.Task.objects.get(name="task_15", pl_id=2)
        self.assertEqual(
                self.__horae_interface.add_edge(1, from_task.id, to_task.id),
                """{"status": 0, "info": "OK"}""")
        from_task = horae.models.Task.objects.get(name="task_14", pl_id=2)
        to_task = horae.models.Task.objects.get(name="task_15", pl_id=2)
        self.assertTrue(from_task.next_task_ids.find(str(to_task.id)) != -1)
        self.assertTrue(to_task.prev_task_ids.find(str(from_task.id)) != -1)

        self.assertEqual(
                self.__horae_interface.delete_edge(1, from_task.id, to_task.id),
                """{"status": 0, "info": "OK"}""")
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        sub_graph_list = graph_mgr._GraphGroup__sub_graph_list
        edge_list = []
        for graph in sub_graph_list:
            for edge in graph.edges():
                edge_list.append(edge)
        
        self.assertTrue((str(from_task.id), str(to_task.id)) not in edge_list)

    def test_get_all_authed_processor(self):
        horae.models.Processor.objects.create(
                id=2,
                name="a1", 
                type=1,
                update_time='2015-05-05 10:00:00',
                private=1,
                owner_id=99)

        horae.models.Processor.objects.create(
                id=3,
                name="a3", 
                type=1,
                update_time='2015-05-05 10:00:00',
                private=1,
                owner_id=199)

        horae.models.Processor.objects.create(
                id=4,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                private=0,
                owner_id=199)

        horae.models.Processor.objects.create(
                id=5,
                name="a5", 
                type=1,
                update_time='2015-05-05 10:00:00',
                private=0,
                owner_id=999)
        self.assertEqual(
                self.__horae_interface.get_all_authed_processor(99, 1),
                """{"status": 0, "info": "OK", "processors": [{"id": 1,"""
                """ "name": "a"}, {"id": 2, "name": "a1"}, {"id": 4,"""
                """ "name": "a4"}, {"id": 5, "name": "a5"}]}""")

    def test_get_pipeline_owner_list(self):
        django.contrib.auth.models.User.objects.create(
                id=3,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user12',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        django.contrib.auth.models.User.objects.create(
                id=4,
                password='sdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user212',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        common.models.PermHistory.objects.create(
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=6,
                permission='read',
                applicant_id=3,
                grantor_id=2,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        common.models.PermHistory.objects.create(
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=6,
                permission='write',
                applicant_id=4,
                grantor_id=2,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        self.assertEqual(
                self.__horae_interface.get_pipeline_owner_list(6),
                """{"status": 0, "info": "OK", "users": [{"pernission":"""
                """ 1, "id": 1, "name": "test_user"}, {"pernission": 1,"""
                """ "id": 3, "name": "test_user12"}, {"pernission": 2,"""
                """ "id": 4, "name": "test_user212"}]}""")

    def test_get_apply_list(self):
        django.contrib.auth.models.User.objects.create(
                id=3,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user12',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        django.contrib.auth.models.User.objects.create(
                id=4,
                password='sdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user212',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        common.models.PermHistory.objects.create(
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=6,
                permission='read',
                applicant_id=3,
                grantor_id=2,
                status=tools_util.AuthAction.APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        common.models.PermHistory.objects.create(
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=6,
                permission='write',
                applicant_id=4,
                grantor_id=2,
                status=tools_util.AuthAction.APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        # print(self.__horae_interface.get_apply_list(2, 6))

    def test_update_pipeline(self):
        django.contrib.auth.models.User.objects.create(
                id=3,
                password='sdf3',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user3',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        horae.models.Pipeline.objects.create(
                id=7999,
                name="test_delete_2", 
                owner_id=3, 
                ct_time='5    * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=0)
        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=3, 
                ct_time='5  * * * *', 
                name="test_delete_3", 
                manager_id_list='6,4,5'),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=3, 
                ct_time='5 *  * *', 
                name="test_delete_3", 
                manager_id_list='6,4,5'),
                """{"status": 1, "info": "\\u6d41\\u7a0b\\u8c03\\u5ea6\\u65f"""
                """6\\u95f4\\u683c\\u5f0f\\u9519\\u8bef!"}""")
        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=7999, 
                owner_id=3, 
                ct_time='*/5 * * * *', 
                name="test_delete_3", 
                manager_id_list='6,4,5'),
                """{"status": 1, "info": "\\u6d41\\u7a0b\\u8c03\\u5ea6\\u65f"""
                """6\\u95f4\\u683c\\u5f0f\\u9519\\u8bef!"}""")

    def test_show_processor(self):
        horae.models.Processor.objects.create(
                id=2,
                name="a1", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                private=1,
                owner_id=2)
        horae.models.Processor.objects.create(
                id=3,
                name="a2", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                owner_id=2)
        horae.models.Processor.objects.create(
                id=4,
                name="a3", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                owner_id=2)
        horae.models.Processor.objects.create(
                id=5,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                owner_id=2)
        self.assertEqual(self.__horae_interface.show_processor(
                auth_tag=0,
                owner_id=2, 
                page_min=0, 
                page_max=20, 
                order_field='name', 
                sort_order='desc',
                search_map=None),
                """{"status": 0, "info": "OK", "count": 5, "processors": ["""
                """{"update_time": "2015-05-05 10:00:00", "description": "t"""
                """est", "config": null, "private": 0, "tag": null, "templa"""
                """te": null, "tpl_files": null, "owner_id": 2, "type": 1,"""
                """ "id": 5, "name": "a4"}, {"update_time": "2015-05-05 10:"""
                """00:00", "description": "test", "config": null, "private":"""
                """ 0, "tag": null, "template": null, "tpl_files": null, "o"""
                """wner_id": 2, "type": 1, "id": 4, "name": "a3"}, {"update"""
                """_time": "2015-05-05 10:00:00", "description": "test", "c"""
                """onfig": null, "private": 0, "tag": null, "template": nul"""
                """l, "tpl_files": null, "owner_id": 2, "type": 1, "id": 3,"""
                """ "name": "a2"}, {"update_time": "2015-05-05 10:00:00","""
                """ "description": "test", "config": null, "private": 1,"""
                """ "tag": null, "template": null, "tpl_files": null, "own"""
                """er_id": 2, "type": 1, "id": 2, "name": "a1"}, {"update_t"""
                """ime": "2015-05-05 10:00:00", "description": "", "config":"""
                """ null, "private": 2, "tag": null, "template": null, "tpl"""
                """_files": null, "owner_id": 1, "type": 1, "id": 1, "nam"""
                """e": "a"}]}""")
        self.assertEqual(self.__horae_interface.show_processor(
                auth_tag=1,
                owner_id=2, 
                page_min=0, 
                page_max=20, 
                order_field='name', 
                sort_order='desc',
                search_map=None),
                """{"status": 0, "info": "OK", "count": 1, "processors": ["""
                """{"update_time": "2015-05-05 10:00:00", "description": "t"""
                """est", "config": null, "private": 1, "tag": null, "templa"""
                """te": null, "tpl_files": null, "owner_id": 2, "type": 1,"""
                """ "id": 2, "name": "a1"}]}""")
        self.assertEqual(self.__horae_interface.show_processor(
                auth_tag=2,
                owner_id=2, 
                page_min=0, 
                page_max=20, 
                order_field='name', 
                sort_order='desc',
                search_map=None),
                """{"status": 0, "info": "OK", "count": 3, "processors": ["""
                """{"update_time": "2015-05-05 10:00:00", "description": "t"""
                """est", "config": null, "private": 0, "tag": null, "templ"""
                """ate": null, "tpl_files": null, "owner_id": 2, "type": 1,"""
                """ "id": 5, "name": "a4"}, {"update_time": "2015-05-05 10:"""
                """00:00", "description": "test", "config": null, "private":"""
                """ 0, "tag": null, "template": null, "tpl_files": null, "ow"""
                """ner_id": 2, "type": 1, "id": 4, "name": "a3"}, {"update_t"""
                """ime": "2015-05-05 10:00:00", "description": "test", "conf"""
                """ig": null, "private": 0, "tag": null, "template": null,"""
                """ "tpl_files": null, "owner_id": 2, "type": 1, "id": 3,"""
                """ "name": "a2"}]}""")
        self.assertEqual(self.__horae_interface.show_processor(
                auth_tag=3,
                owner_id=2, 
                page_min=0, 
                page_max=20, 
                order_field='name', 
                sort_order='desc',
                search_map=None),
                """{"status": 0, "info": "OK", "count": 1, "processors": ["""
                """{"update_time": "2015-05-05 10:00:00", "description": "","""
                """ "config": null, "private": 2, "tag": null, "template": n"""
                """ull, "tpl_files": null, "owner_id": 1, "type": 1, "id": 1"""
                """, "name": "a"}]}""")

    def test_create_processor(self):
        processor = horae.models.Processor(
                id=5,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                template='it \n is \n test \n for you\n',
                owner_id=2)
        self.assertEqual(
                self.__horae_interface.create_processor(processor),
                """{"status": 0, "info": "OK"}""")
        processor = horae.models.Processor.objects.get(id=5)
        print(processor.template)

    def test_update_processor(self):
        processor = horae.models.Processor.objects.create(
                id=5,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                owner_id=2)
        processor.description = "sfasdf"
        self.assertEqual(
                self.__horae_interface.update_processor(processor),
                """{"status": 0, "info": "OK"}""")

    def test_update_processor_with_task(self):
        processor = horae.models.Processor.objects.create(
                id=5,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                config=self.__config,
                description='test',
                owner_id=2)
        horae.models.Task.objects.create(
                id=99995,
                pl_id=2,
                pid=5,
                next_task_ids=',',
                prev_task_ids=',4',
                over_time=12,
                name='task_99995',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        processor.config = "%s\ntest_config=123"
        self.assertEqual(
                self.__horae_interface.update_processor(processor),
                """{"status": 0, "info": "OK"}""")
        task = horae.models.Task.objects.get(id=99995)
        self.assertNotEqual(task.config.find("test_config="), -1)

    def test_delete_processor(self):
        processor = horae.models.Processor.objects.create(
                id=5,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                owner_id=2)
        self.assertEqual(
                self.__horae_interface.delete_processor(5),
                """{"status": 0, "info": "OK"}""")

    def test_get_processor(self):
        processor = horae.models.Processor.objects.create(
                id=5,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                owner_id=2)
        self.assertEqual(
                self.__horae_interface.get_processor_info(5),
                """{"status": 0, "info": "OK", "processor": {"update_time":"""
                """ "2015-05-05 10:00:00", "description": "test", "config":"""
                """ null, "private": 0, "tag": null, "template": null, "tpl"""
                """_files": null, "owner_id": 2, "type": 1, "id": 5, "name":"""
                """ "a4"}}""")
    
    def test_public_processor(self):
        processor = horae.models.Processor.objects.create(
                id=5,
                name="a4", 
                type=1,
                update_time='2015-05-05 10:00:00',
                description='test',
                private=1,
                owner_id=2)
        self.assertEqual(
                self.__horae_interface.public_processor(5),
                """{"status": 0, "info": "OK"}""")
        processor=horae.models.Processor.objects.get(id=5)
        self.assertEqual(processor.private, 0)

    def test_run_pipeline(self):
        self.assertEqual(
                self.__horae_interface.run_pipeline(1, 1, "20150510-20150515"),
                """{"status": 1, "info": "restart task failed! <urlopen error [Errno 111] Connection refused>"}""")        
        self.assertEqual(
                self.__horae_interface.run_pipeline(1, 1, "20150510,20150610"),
                """{"status": 1, "info": "restart task failed! <urlopen error [Errno 111] Connection refused>"}""")        
        self.assertEqual(
                self.__horae_interface.run_pipeline(2, 1, "20150510-20150515"),
                """{"status": 1, "info": "this owner has"""
                """ no auth to run pipeline"}""")        
        self.assertEqual(
                self.__horae_interface.run_pipeline(1, 1, "20110510-20150610"),
                """{"status": 1, "info": "restart task extend max num[500]"}""")

    def test_run_task_with_all_successors(self):
        horae.models.Task.objects.create(
                id=6,
                pl_id=5,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        graph_mgr._GraphGroup__graph.clear()
        graph_mgr._GraphGroup__sub_graph_list = []
        graph_mgr._GraphGroup__create_graph()

        self.assertEqual(
                self.__horae_interface.run_task_with_all_successors(
                        1, 4, '201505161010'),
                """{"status": 1, "info": "restart task failed! <urlopen er"""
                """ror [Errno 111] Connection refused>"}""")

    def test_run_tasks(self):
        horae.models.Task.objects.create(
                id=6,
                pl_id=6,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        self.assertEqual(
                self.__horae_interface.run_tasks(
                1, [1, 2, 3, 4, 5], "20150510-20150515"),
                """{"status": 1, "info": "\\u6267\\u884c\\u4efb\\u52a1\\u5931\\u8d25\\uff0c\\u8be6\\u60c5[<urlopen error [Errno 111] Connection refused>]"}""")
        self.assertEqual(
                self.__horae_interface.run_tasks(
                1, [1, 2, 3, 4, 5, 6], "20150510-20150515"),
                """{"status": 1, "info": "\\u5bf9\\u4e0d\\u8d77\\uff0c\\u4f60\\u6ca1\\u6709\\u6743\\u9650\\u542f\\u52a8\\u8fd9\\u4e2a\\u6d41\\u7a0b\\u7684\\u4efb\\u52a1\\uff01"}""")

    def test_run_one_by_one_task(self):
        pair_list = []
        pair_list.append((4, '201503141010'))
        pair_list.append((3, '201503141010'))
        self.assertEqual(
                self.__horae_interface.run_one_by_one_task(1, pair_list),
                """{"status": 1, "info": "\\u6267\\u884c\\u4efb\\u52a1\\u5931\\u8d25\\uff0c\\u8be6\\u60c5[<urlopen error [Errno 111] Connection refused>]"}""")
        horae.models.Task.objects.create(
                id=6,
                pl_id=6,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        pair_list.append((6, '201503141010'))
        self.assertEqual(
                self.__horae_interface.run_one_by_one_task(1, pair_list),
                """{"status": 1, "info": "\\u5bf9\\u4e0d\\u8d77\\uff0c\\u4f60\\u6ca1\\u6709\\u6743\\u9650\\u542f\\u52a8\\u8fd9\\u4e2a\\u6d41\\u7a0b\\u7684\\u4efb\\u52a1\\uff01"}""")
        pair_list = []
        pair_list.append((61, '201503141010'))
        self.assertEqual(
                self.__horae_interface.run_one_by_one_task(1, pair_list),
                """{"status": 1, "info": "task is not exists!"}""")

    def test_get_processor_quote_list(self):
        print(self.__horae_interface.get_processor_quote_list(1))
        pass

    def test_show_run_history_task(self):
        user_1098 = django.contrib.auth.models.User.objects.create(
                id=1098,
                password='sdfsdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user1098',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        user_1097 = django.contrib.auth.models.User.objects.create(
                id=1097,
                password='sdfsdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user1097',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        user_1099 = django.contrib.auth.models.User.objects.create(
                id=1099,
                password='sdfsdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user1099',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        horae.models.Pipeline.objects.create(
                id=92,
                name="run_his92", 
                owner_id=1098, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)
        task_95 = horae.models.Task.objects.create(
                id=95,
                pl_id=92,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',96',
                over_time=12,
                name='run_his_task_95',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        task_96 = horae.models.Task.objects.create(
                id=96,
                pl_id=92,
                pid=1,
                next_task_ids=',95',
                prev_task_ids=',',
                over_time=12,
                name='run_his_task_96',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=93,
                name="run_his93", 
                owner_id=1097, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        task_97 = horae.models.Task.objects.create(
                id=97,
                pl_id=93,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',98',
                over_time=12,
                name='run_his_task_97',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        task_98 = horae.models.Task.objects.create(
                id=98,
                pl_id=93,
                pid=1,
                next_task_ids=',97',
                prev_task_ids=',',
                over_time=12,
                name='run_his_task_98',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=94,
                name="run_his94", 
                owner_id=1099, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        task_99 = horae.models.Task.objects.create(
                id=99,
                pl_id=94,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',100',
                over_time=12,
                name='run_his_task_99',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        task_100 = horae.models.Task.objects.create(
                id=100,
                pl_id=94,
                pid=1,
                next_task_ids=',99',
                prev_task_ids=',',
                over_time=12,
                name='run_his_task_100',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        run_his95 = horae.models.RunHistory.objects.create(
                id=2,
                task_id=95,
                run_time='201507061310',
                pl_id=92,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_RUNNING,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='',
                pl_name='run_his92',
                task_name='run_his_task_95')
        run_his96 = horae.models.RunHistory.objects.create(
                id=3,
                task_id=96,
                run_time='201507061310',
                pl_id=92,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='',
                pl_name='run_his92',
                task_name='run_his_task_96')

        horae.models.RunHistory.objects.create(
                id=4,
                task_id=97,
                run_time='201507061310',
                pl_id=93,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='',
                pl_name='run_his93',
                task_name='run_his_task_97')
        horae.models.RunHistory.objects.create(
                id=5,
                task_id=98,
                run_time='201507061310',
                pl_id=93,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='',
                pl_name='run_his93',
                task_name='run_his_task_98')

        horae.models.RunHistory.objects.create(
                id=6,
                task_id=99,
                run_time='201507061310',
                pl_id=94,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_FAILED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='',
                pl_name='run_his94',
                task_name='run_his_task_99')
        horae.models.RunHistory.objects.create(
                id=7,
                task_id=100,
                run_time='201507061310',
                pl_id=94,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='',
                pl_name='run_his94',
                task_name='run_his_task_100')

        search_map = {}
        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=1,
                owner_id=1098, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 1, "runhistory_lis"""
                """t": [{"status": 1, "task_id": 95, "mem": 0, "start_tim"""
                """e": "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000,"""
                """ "schedule_id": 0, "run_time": "201507061310", "task_na"""
                """me": "", "pl_id": 92, "pl_name": "run_his92", "id": 2}]}""")
        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=0,
                owner_id=1098, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 2, "runhistory_lis"""
                """t": [{"status": 1, "task_id": 95, "mem": 0, "start_tim"""
                """e": "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000"""
                """, "schedule_id": 0, "run_time": "201507061310", "task_nam"""
                """e": "run_his_task_95", "pl_name": "run_his92", "pl_id": 9"""
                """2, "id": 2}, {"status": 2, "task_id": 96, "mem": 0, "star"""
                """t_time": "2015-06-15 10:00:00", "cpu": 0, "use_time": 360"""
                """00, "schedule_id": 0, "run_time": "201507061310", "task_n"""
                """ame": "run_his_task_96", "pl_name": "run_his92", "pl_id":"""
                """ 92, "id": 3}]}""")

        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=1,
                owner_id=1097, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 1, "runhistory_lis"""
                """t": [{"status": 2, "task_id": 97, "mem": 0, "start_time":"""
                """ "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000, "sch"""
                """edule_id": 0, "run_time": "201507061310", "task_name":"""
                """ "", "pl_id": 93, "pl_name": "run_his93", "id": 4}]}""")
        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=1,
                owner_id=1099, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 1, "runhistory_lis"""
                """t": [{"status": 3, "task_id": 99, "mem": 0, "start_tim"""
                """e": "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000"""
                """, "schedule_id": 0, "run_time": "201507061310", "task_nam"""
                """e": "", "pl_id": 94, "pl_name": "run_his94", "id": 6}]}""")
        common.models.PermHistory.objects.create(
                id=91,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=93,
                permission='read',
                applicant_id=1098,
                grantor_id=1097,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')

        common.models.PermHistory.objects.create(
                id=92,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=94,
                permission='write',
                applicant_id=1098,
                grantor_id=1099,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        self.assertEqual(
                self.__horae_interface.get_all_authed_pipeline_info(1098),
                """{"status": 0, "info": "OK", "pipelines": [{"id": 1, "name": "a"}, {"id": 2, "name": "2"}, {"id": 3, "name": "3"}, {"id": 4, "name": "4"}, {"id": 5, "name": "5"}, {"id": 6, "name": "test_2_1"}, {"id": 7, "name": "test_2_2"}, {"id": 92, "name": "run_his92"}, {"id": 93, "name": "run_his93"}, {"id": 94, "name": "run_his94"}]}""")
        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=1,
                owner_id=1098, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 3, "runhistory_lis"""
                """t": [{"status": 1, "task_id": 95, "mem": 0, "start_time":"""
                """ "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000, "sch"""
                """edule_id": 0, "run_time": "201507061310", "task_name":"""
                """ "", "pl_id": 92, "pl_name": "run_his92", "id": 2}, {"sta"""
                """tus": 2, "task_id": 97, "mem": 0, "start_time": "2015-06-"""
                """15 10:00:00", "cpu": 0, "use_time": 36000, "schedule_id":"""
                """ 0, "run_time": "201507061310", "task_name": "", "pl_id":"""
                """ 93, "pl_name": "run_his93", "id": 4}, {"status": 3, "tas"""
                """k_id": 99, "mem": 0, "start_time": "2015-06-15 10:00:00","""
                """ "cpu": 0, "use_time": 36000, "schedule_id": 0, "run_tim"""
                """e": "201507061310", "task_name": "", "pl_id": 94, "pl_nam"""
                """e": "run_his94", "id": 6}]}""")
        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=0,
                owner_id=1098, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 6, "runhistory_lis"""
                """t": [{"status": 1, "task_id": 95, "mem": 0, "start_time":"""
                """ "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000, "sch"""
                """edule_id": 0, "run_time": "201507061310", "task_name": "r"""
                """un_his_task_95", "pl_name": "run_his92", "pl_id": 92, "i"""
                """d": 2}, {"status": 2, "task_id": 96, "mem": 0, "start_tim"""
                """e": "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000,"""
                """ "schedule_id": 0, "run_time": "201507061310", "task_nam"""
                """e": "run_his_task_96", "pl_name": "run_his92", "pl_id": 9"""
                """2, "id": 3}, {"status": 2, "task_id": 97, "mem": 0, "star"""
                """t_time": "2015-06-15 10:00:00", "cpu": 0, "use_time": 360"""
                """00, "schedule_id": 0, "run_time": "201507061310", "task_n"""
                """ame": "run_his_task_97", "pl_name": "run_his93", "pl_id":"""
                """ 93, "id": 4}, {"status": 2, "task_id": 98, "mem": 0, "st"""
                """art_time": "2015-06-15 10:00:00", "cpu": 0, "use_time": 3"""
                """6000, "schedule_id": 0, "run_time": "201507061310", "task"""
                """_name": "run_his_task_98", "pl_name": "run_his93", "pl_i"""
                """d": 93, "id": 5}, {"status": 3, "task_id": 99, "mem": 0,"""
                """ "start_time": "2015-06-15 10:00:00", "cpu": 0, "use_tim"""
                """e": 36000, "schedule_id": 0, "run_time": "201507061310","""
                """ "task_name": "run_his_task_99", "pl_name": "run_his94","""
                """ "pl_id": 94, "id": 6}, {"status": 2, "task_id": 100, "me"""
                """m": 0, "start_time": "2015-06-15 10:00:00", "cpu": 0, "us"""
                """e_time": 36000, "schedule_id": 0, "run_time": "2015070613"""
                """10", "task_name": "run_his_task_100", "pl_name": "run_his"""
                """94", "pl_id": 94, "id": 7}]}""")

        self.assertEqual(
                self.__horae_interface.get_task_history_by_pipe(
                        92, 
                        201507061310),
                """{"status": 0, "info": "OK", "count": 0, "runhistory_lis"""
                """t": [{"status": 1, "task_id": 95, "mem": 0, "start_time":"""
                """ "2015-06-15 10:00:00", "cpu": ",96", "use_time": 36000,"""
                """ "schedule_id": 0, "run_time": "201507061310", "task_nam"""
                """e": "run_his_task_95", "pl_name": "run_his92", "pl_id": 9"""
                """2, "id": ","}, {"status": 2, "task_id": 96, "mem": 0, "st"""
                """art_time": "2015-06-15 10:00:00", "cpu": ",", "use_time":"""
                """ 36000, "schedule_id": 0, "run_time": "201507061310", "ta"""
                """sk_name": "run_his_task_96", "pl_name": "run_his92", "pl_"""
                """id": 92, "id": ",95"}]}""")
        task_97.next_task_ids = ',96'
        task_97.save()
        task_99.next_task_ids = ',96'
        task_99.save()
        task_96.prev_task_ids = '97, 99'
        task_96.save()
        run_his95.status = tools_util.TaskState.TASK_WAITING
        run_his95.save()
        run_his96.status = tools_util.TaskState.TASK_WAITING
        run_his96.save()
                
        graph_mgr = graph_manager.GraphGroup(None)
        graph_mgr._GraphGroup__create_graph()
        self.assertEqual(
                self.__horae_interface.run_history_show_graph(
                        92, 
                        '201507061310'),
                """{"status": 0, "info": "OK", "runhistory_list": [{"statu"""
                """s": 0, "un_succ_run_tasks": [], "manager_list": [["test_u"""
                """ser1098", "lei.xie@shenma-inc.com"]], "task_name": "run_h"""
                """is_task_95", "task_id": 95, "schedule_id": 0, "run_time":"""
                """ "201507061310", "pl_name": "run_his92", "begin_time": "2"""
                """015-06-15 10:00:00", "pl_id": 92, "retried_count": 0, "ne"""
                """xt_task_ids": "", "prev_task_ids": ",96"}, {"status": 0,"""
                """ "un_succ_run_tasks": [], "manager_list": [["test_user109"""
                """8", "lei.xie@shenma-inc.com"]], "task_name": "run_his_tas"""
                """k_96", "task_id": 96, "schedule_id": 0, "run_time": "2015"""
                """07061310", "pl_name": "run_his92", "begin_time": "2015-06"""
                """-15 10:00:00", "pl_id": 92, "retried_count": 0, "next_tas"""
                """k_ids": "95", "prev_task_ids": "97, 99"}, {"status": 2,"""
                """ "un_succ_run_tasks": [], "manager_list": [["test_user109"""
                """7", "lei.xie@shenma-inc.com"]], "task_name": "run_his_tas"""
                """k_97", "task_id": 97, "schedule_id": -1, "run_time": "","""
                """ "pl_name": "run_his93", "begin_time": "", "pl_id": 93,"""
                """ "retried_count": 3, "next_task_ids": "96", "prev_task_id"""
                """s": ",98"}, {"status": 2, "un_succ_run_tasks": [], "manag"""
                """er_list": [["test_user1097", "lei.xie@shenma-inc.com"]],"""
                """ "task_name": "run_his_task_98", "task_id": 98, "schedul"""
                """e_id": -1, "run_time": "", "pl_name": "run_his93", "begi"""
                """n_time": "", "pl_id": 93, "retried_count": 3, "next_task"""
                """_ids": "97", "prev_task_ids": ","}, {"status": 3, "un_su"""
                """cc_run_tasks": [{"status": 3, "run_time": "201507061310"}"""
                """], "manager_list": [["test_user1098", "lei.xie@shenma-inc"""
                """.com"], ["test_user1099", "lei.xie@shenma-inc.com"]], "ta"""
                """sk_name": "run_his_task_99", "task_id": 99, "schedule_i"""
                """d": -1, "run_time": "", "pl_name": "run_his94", "begin_ti"""
                """me": "", "pl_id": 94, "retried_count": 3, "next_task_id"""
                """s": "96", "prev_task_ids": ",100"}, {"status": 2, "un_suc"""
                """c_run_tasks": [], "manager_list": [["test_user1098", "lei"""
                """.xie@shenma-inc.com"], ["test_user1099", "lei.xie@shenma-"""
                """inc.com"]], "task_name": "run_his_task_100", "task_id": 1"""
                """00, "schedule_id": -1, "run_time": "", "pl_name": "run_hi"""
                """s94", "begin_time": "", "pl_id": 94, "retried_count": 3,"""
                """ "next_task_ids": "99", "prev_task_ids": ","}]}""")
        run_his96.schedule_id = 7
        run_his96.save()
        schedule = horae.models.Schedule.objects.create(
                id=7,
                task_id=96,
                run_time='201507061310',
                pl_id=94,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                init_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED)
        self.assertEqual(
                self.__horae_interface.get_task_run_status_info(
                        96, '201507061310'),
                """{"status": 0, "info": "OK", "prev_info": {"3": [{"manager"""
                """_list": [["test_user1098", "lei.xie@shenma-inc.com"], ["t"""
                """est_user1099", "lei.xie@shenma-inc.com"]], "task_id": 99,"""
                """ "start_time": "2015-06-15 10:00:00", "run_time": "201507"""
                """061310", "task_name": "run_his_task_99", "pl_id": 94, "i"""
                """d": 6, "pipeline_name": "run_his94"}]}}""")
        schedule.status = tools_util.TaskState.TASK_RUNNING
        schedule.save()
        run_his96.status = tools_util.TaskState.TASK_RUNNING
        run_his96.save()
        self.__horae_interface._HoraeInterface__pipeline_mgr.\
                _PipelineManager__admin_port = 8791

        print(self.__horae_interface.get_task_run_status_info(
                96, '201507061310'))

        user_1098.is_superuser = 1
        user_1098.save()
        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=1,
                owner_id=1098, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 3, "runhistory_lis"""
                """t": [{"status": 1, "task_id": 95, "mem": 0, "start_tim"""
                """e": "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000"""
                """, "schedule_id": 0, "run_time": "201507061310", "task_nam"""
                """e": "", "pl_id": 92, "pl_name": "run_his92", "id": 2}, """
                """{"status": 2, "task_id": 97, "mem": 0, "start_time": "201"""
                """5-06-15 10:00:00", "cpu": 0, "use_time": 36000, "schedule"""
                """_id": 0, "run_time": "201507061310", "task_name": "", "pl"""
                """_id": 93, "pl_name": "run_his93", "id": 4}, {"status": 3,"""
                """ "task_id": 99, "mem": 0, "start_time": "2015-06-15 10:00"""
                """:00", "cpu": 0, "use_time": 36000, "schedule_id": 0, "run"""
                """_time": "201507061310", "task_name": "", "pl_id": 94, "pl"""
                """_name": "run_his94", "id": 6}]}""")
        self.assertEqual(self.__horae_interface.show_run_history(
                show_tag=0,
                owner_id=1098, 
                page_min=0, 
                page_max=10, 
                order_field='run_time', 
                sort_order='desc',
                search_map=search_map),
                """{"status": 0, "info": "OK", "count": 6, "runhistory_lis"""
                """t": [{"status": 0, "task_id": 95, "mem": 0, "start_time":"""
                """ "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000, "sch"""
                """edule_id": 0, "run_time": "201507061310", "task_name": "r"""
                """un_his_task_95", "pl_name": "run_his92", "pl_id": 92, "i"""
                """d": 2}, {"status": 1, "task_id": 96, "mem": 0, "start_tim"""
                """e": "2015-06-15 10:00:00", "cpu": 0, "use_time": 36000,"""
                """ "schedule_id": 7, "run_time": "201507061310", "task_nam"""
                """e": "run_his_task_96", "pl_name": "run_his92", "pl_id": 9"""
                """2, "id": 3}, {"status": 2, "task_id": 97, "mem": 0, "star"""
                """t_time": "2015-06-15 10:00:00", "cpu": 0, "use_time": 360"""
                """00, "schedule_id": 0, "run_time": "201507061310", "task_n"""
                """ame": "run_his_task_97", "pl_name": "run_his93", "pl_id":"""
                """ 93, "id": 4}, {"status": 2, "task_id": 98, "mem": 0, "st"""
                """art_time": "2015-06-15 10:00:00", "cpu": 0, "use_time": 3"""
                """6000, "schedule_id": 0, "run_time": "201507061310", "task"""
                """_name": "run_his_task_98", "pl_name": "run_his93", "pl_i"""
                """d": 93, "id": 5}, {"status": 3, "task_id": 99, "mem": 0,"""
                """ "start_time": "2015-06-15 10:00:00", "cpu": 0, "use_tim"""
                """e": 36000, "schedule_id": 0, "run_time": "201507061310","""
                """ "task_name": "run_his_task_99", "pl_name": "run_his94","""
                """ "pl_id": 94, "id": 6}, {"status": 2, "task_id": 100, "me"""
                """m": 0, "start_time": "2015-06-15 10:00:00", "cpu": 0, "us"""
                """e_time": 36000, "schedule_id": 0, "run_time": "2015070613"""
                """10", "task_name": "run_his_task_100", "pl_name": "run_his"""
                """94", "pl_id": 94, "id": 7}]}""")

    def test_get_task_run_logs(self):
        # self.__horae_interface._HoraeInterface__pipeline_mgr.\
        #         _PipelineManager__admin_port = 8791
        # print(self.__horae_interface.get_task_run_logs(104515))
        # print(self.__horae_interface.get_task_log_content(104515, 'run.py', 0, 10))
        # print(self.__horae_interface.get_task_log_content(104515, 'run.py', 10, 10))
        # print(self.__horae_interface.get_task_log_content(104515, 'run.py', 20, 10))
        # print(self.__horae_interface.get_task_log_content(104515, 'run.py', 30, 10))
        pass

    def test_add_new_task_ex(self):
        task = horae.models.Task(
                id=1798,
                pl_id=1,
                pid=1,
                over_time=12,
                prev_task_ids=',2',
                name='task_1789',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        print(self.__horae_interface.add_new_task_to_pipeline(1, task))
        task = horae.models.Task.objects.get(pl_id=1, name='task_1789')
        print(task.prev_task_ids, task.next_task_ids, task.name)
        task = horae.models.Task(
                id=1798,
                pl_id=1,
                pid=1,
                over_time=12,
                prev_task_ids=',2',
                name='task_17899',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        print(self.__horae_interface.add_new_task_to_pipeline(1, task))
        task = horae.models.Task.objects.get(pl_id=1, name='task_17899')
        print(task.prev_task_ids, task.next_task_ids, task.name)

    def test_show_pipeline_apply(self):
        common.models.PermHistory.objects.create(
                id=109,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=7,
                permission='read',
                applicant_id=1,
                grantor_id=2,
                status=tools_util.AuthAction.APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        horae.models.Pipeline.objects.create(
                id=199,
                name="a_199", 
                owner_id=2, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        perm_history = common.models.PermHistory.objects.get(id=109)
        self.assertEqual(self.__horae_interface.show_pipeline_info(
            owner_id=1, 
            auth_tag=0,
            page_min=0, 
            page_max=20, 
            order_field='name', 
            sort_order='desc',
            search_map=None), 
            """{"status": 0, "info": "OK", "count": 8, "pipe_list": [{"username": "test_user2", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "test_2_2", "permission": 3, "project_name": "", "tag": "", "project_id": 0, "ct_time": "1,2,3,4,5 * * * *", "id": 7}, {"username": "test_user2", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "test_2_1", "permission": 1, "project_name": "", "tag": "", "project_id": 0, "ct_time": "1,2,3,4,5 * * * *", "id": 6}, {"username": "test_user2", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "a_199", "permission": 0, "project_name": "", "tag": "", "project_id": 0, "ct_time": "0 1 * * *", "id": 199}, {"username": "test_user", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "a", "permission": 2, "project_name": "", "tag": "", "project_id": 0, "ct_time": "0 1 * * *", "id": 1}, {"username": "test_user", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "5", "permission": 2, "project_name": "", "tag": "", "project_id": 0, "ct_time": "1,2,3,4,5 * * * *", "id": 5}, {"username": "test_user", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "4", "permission": 2, "project_name": "", "tag": "", "project_id": 0, "ct_time": "8 * * * *", "id": 4}, {"username": "test_user", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "3", "permission": 2, "project_name": "", "tag": "", "project_id": 0, "ct_time": "1 5 * * *", "id": 3}, {"username": "test_user", "update_time": "2015-05-05 10:00:00", "enable": 1, "name": "2", "permission": 2, "project_name": "", "tag": "", "project_id": 0, "ct_time": "1 2 3 * *", "id": 2}]}""")

    def test_get_run_history_info(self):
        horae.models.RunHistory.objects.create(
                id=99,
                task_id=99,
                run_time='201507061310',
                pl_id=94,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_FAILED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')
        self.assertEqual(self.__horae_interface.get_run_history_info(99),
                """{"status": 0, "info": "OK", "runhistory": {"status": 3"""
                """, "task_name": "", "task_id": 99, "schedule_id": 0, "run_"""
                """time": "201507061310", "pl_name": "", "begin_time": "2015"""
                """-06-15 10:00:00", "pl_id": 94, "id": 99, "end_time": "201"""
                """5-06-15 20:00:00"}}""")

    def test_stop_task(self):
        task = horae.models.Task.objects.create(
                id=6075,
                pl_id=1,
                pid=1,
                over_time=12,
                prev_task_ids=',2',
                name='task_1789',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        schedule = horae.models.Schedule.objects.create(
                id=113456,
                task_id=6075,
                run_time='201507151301',
                init_time='2015-05-16 10:10:00',
                status=tools_util.TaskState.TASK_WAITING,
                pl_id=1)
        #self.__horae_interface._HoraeInterface__pipeline_mgr.\
        #        _PipelineManager__admin_port = 8791

        #print(self.__horae_interface.stop_task(1, 6075, '201507151301'))
        #print(self.__horae_interface.get_log_content_tail(118230, "stdout.log"))

    def test_get_pipeline_abstract_info(self):
        horae.models.RunHistory.objects.create(
                id=99,
                task_id=99,
                run_time='2015070270510',
                pl_id=1,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_FAILED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')

        self.assertEqual(
                self.__horae_interface.get_pipeline_abstract_info(1),
                """{"status": 0, "info": "OK", "owned_pipeline_num": 5"""
                """, "pipeline_num": 7, "failed_pipeline_num": 0, "succ"""
                """_pipeline_num": 0, "stoped_pipeline_num": 0}""")

    def test_get_data_info(self):
        dms.models.Config.objects.create(
                id=1,
                name="test",
                description="test",
                type=0,
                path="test_path",
                format='test',
                life_cycle=109,
                generation_cycle='hour-1',
                update_time='2015-04-03 07:09:11',
                fluctuation=0,
                owner_id=1,
                update_user_id=1,
                wiki='test',
                send_mail=1,
                send_sms=1)
        self.assertEqual(self.__horae_interface.get_data_info(0),
                """{"status": 0, "info": "OK", "data_list":"""
                """ [{"id": 1, "name": "test"}]}""")

    def test_get_processor_package_history(self):
        horae.models.Processor.objects.create(
                id=2,
                name="a_test", 
                type=2,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        horae.models.Processor.objects.create(
                id=3,
                name="a_test3", 
                type=4,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        print(self.__horae_interface.get_processor_package_history(1))

        self.assertEqual(self.__horae_interface.upload_pacakge(
                1, 
                1, 
                '/apsarapangu/disk1/lei.xie/work/ark'
                '/data_platform/test_upload/12345/'),
                """{"status": 0, "info": "OK"}""",
                False)
        self.assertEqual(self.__horae_interface.upload_pacakge(
                2, 
                1, 
                '/apsarapangu/disk1/lei.xie/work/ark'
                '/data_platform/test_upload/12345/'),
                """{"status": 1, "info": "hand pangu package failed!"}""",
                False)
        self.assertEqual(self.__horae_interface.upload_pacakge(
                3, 
                1, 
                '/apsarapangu/disk1/lei.xie/work/ark'
                '/data_platform/test_upload/12345/'),
                """{"status": 0, "info": "OK"}""",
                False)

        print(self.__horae_interface.get_processor_package_history(1))

    def test_use_processor_package(self):
        return
        horae.models.Processor.objects.create(
                id=2,
                name="a2", 
                type=2,
                update_time='2015-05-05 10:00:00',
                owner_id=1)

        horae.models.UploadHistory.objects.create(
                id=4,
                processor_id=2,
                status=0,
                update_time="2015-06-26 10:00:00",
                upload_time="2015-06-26 10:00:00",
                upload_user_id=1,
                version='20150721170315.66619610')
        print(
                self.__horae_interface.use_processor_package(4),
                """{"status": 0, "info": "OK"}""")
        his1 = horae.models.UploadHistory.objects.get(id=4)
        print(his1.status, 1)

        horae.models.Processor.objects.create(
                id=3,
                name="a3", 
                type=tools_util.TaskType.ODPS_MAP_REDUCE,
                update_time='2015-05-05 10:00:00',
                owner_id=1)

        horae.models.UploadHistory.objects.create(
                id=5,
                processor_id=3,
                status=0,
                update_time="2015-06-26 10:00:00",
                upload_time="2015-06-26 10:00:00",
                upload_user_id=1,
                version='20150721170315.66619619')
        print(
                self.__horae_interface.use_processor_package(5),
                """{"status": 0, "info": "OK"}""")
        his1 = horae.models.UploadHistory.objects.get(id=5)
        self.assertEqual(his1.status, 0)

    def test_get_server_tag(self):
        self.assertEqual(
                self.__horae_interface.get_server_tag(
                        tools_util.TaskType.APSARA_JOB),
                """{"status": 0, "info": "OK", "server_tags":"""
                """ "AY54,AY500"}""")

    def test_get_app_group_list(self):
        horae.models.Pipeline.objects.create(
                id=21,
                name="21", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag='xl_test,xl_test1',
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=31,
                name="31", 
                owner_id=1, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag='xl_test1,xl_test3',
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=41,
                name="41", 
                owner_id=1, 
                ct_time='8 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag='xl_test',
                enable=1,
                private=0)

        horae.models.Pipeline.objects.create(
                id=51,
                name="51", 
                owner_id=1, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag='xl_test',
                enable=1,
                private=1)
        print(self.__horae_interface.get_app_group_list())

    def test_get_prev_pipeline_info(self):
        print(self.__horae_interface.get_prev_pipeline_info(2))

    def test_get_project_list(self):
        horae.models.Project.objects.create(
                id=1,
                name="测试项目1", 
                owner_id=1,
                is_default=False)
        horae.models.Project.objects.create(
                id=2,
                name="测试项目2", 
                owner_id=1,
                is_default=False)
        horae.models.Project.objects.create(
                id=3,
                name="测试项目3", 
                owner_id=2,
                is_default=False)
        horae.models.Pipeline.objects.create(
                id=21,
                name="21", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag=1,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=31,
                name="31", 
                owner_id=1, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag=2,
                enable=1,
                private=1)
        self.assertEqual(
                self.__horae_interface.get_project_list(1, 0),
                """{"status": 0, "info": "OK", "projects": [{"pipe_num": 1"""
                """, "description": "", "writer_list": "", "name": "\u6d4b"""
                """\u8bd5\u9879\u76ee1", "is_default": 0, "id": 1, "owner_"""
                """id": 1}, {"pipe_num": 1, "description": "", "writer_lis"""
                """t": "", "name": "\u6d4b\u8bd5\u9879\u76ee2", "is_defaul"""
                """t": 0, "id": 2, "owner_id": 1}]}""")
        self.assertEqual(
                self.__horae_interface.get_project_list(1, 1),
                """{"status": 0, "info": "OK", "projects": [{"pipe_num": """
                """0, "description": "", "writer_list": "", "name": "\u6d"""
                """4b\u8bd5\u9879\u76ee3", "is_default": 0, "id": 3, "own"""
                """er_id": 2}]}""")

        self.assertEqual(
                self.__horae_interface.get_project_list(1, 2),
                """{"status": 0, "info": "OK", "projects": [{"pipe_num": 1"""
                """, "description": "", "writer_list": "", "name": "\u6d4b"""
                """\u8bd5\u9879\u76ee1", "is_default": 0, "id": 1, "owner_"""
                """id": 1}, {"pipe_num": 1, "description": "", "writer_lis"""
                """t": "", "name": "\u6d4b\u8bd5\u9879\u76ee2", "is_defaul"""
                """t": 0, "id": 2, "owner_id": 1}, {"pipe_num": 0, "descri"""
                """ption": "", "writer_list": "", "name": "\u6d4b\u8bd5\u9"""
                """879\u76ee3", "is_default": 0, "id": 3, "owner_id": 2}]}""")

        self.assertEqual(
                self.__horae_interface.delete_project(1, 1),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(
                self.__horae_interface.delete_project(1, 3),
                """{"status": 1, "info": "\u4f60\u6ca1\u6709\u8fd9\u4e2a"""
                """\u9879\u76ee\u7684\u6743\u9650!"}""")
        common.models.PermHistory.objects.create(
                id=91,
                resource_type=tools_util.CONSTANTS.PROJECT,
                resource_id=1,
                permission='write',
                applicant_id=2,
                grantor_id=1,
                status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        common.models.PermHistory.objects.create(
                id=92,
                resource_type=tools_util.CONSTANTS.PROJECT,
                resource_id=3,
                permission='write',
                applicant_id=1,
                grantor_id=2,
                status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        self.assertEqual(
                self.__horae_interface.delete_project(1, 3),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(
                self.__horae_interface.get_project_list(2, 0),
                """{"status": 0, "info": "OK", "projects": []}""")

    def test_add_new_project(self):
        self.assertEqual(
                self.__horae_interface.add_new_project(
                        1, "test_project", "2", 'test add project'),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(
                self.__horae_interface.get_project_list(1, 0),
                """{"status": 0, "info": "OK", "projects": [{"pipe_num": 0"""
                """, "description": "test add project", "writer_list": "2","""
                """ "name": "test_project", "is_default": 0, "id": 1, "own"""
                """er_id": 1}]}""")

    def test_update_project(self):
        horae.models.Project.objects.create(
                id=1,
                name="测试项目1", 
                owner_id=1,
                is_default=False,
                description="测试项目1")
        horae.models.Project.objects.create(
                id=2,
                name="测试项目2", 
                owner_id=1,
                is_default=False,
                description="测试项目1")

        horae.models.Pipeline.objects.create(
                id=21,
                name="21", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag=1,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=31,
                name="31", 
                owner_id=1, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag=2,
                enable=1,
                private=1)
        self.assertEqual(
                self.__horae_interface.update_project(
                        1, 1, 'test_project_update', '3,4', 'hello update'),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(
                self.__horae_interface.get_project_list(1, 0),
                """{"status": 0, "info": "OK", "projects": [{"pipe_num": 1"""
                """, "description": "hello update", "writer_list": "3,4","""
                """ "name": "test_project_update", "is_default": 0, "id": 1"""
                """, "owner_id": 1}, {"pipe_num": 1, "description": "\\u6d4"""
                """b\\u8bd5\\u9879\\u76ee1", "writer_list": "", "name": "\\u"""
                """6d4b\\u8bd5\\u9879\\u76ee2", "is_default": 0, "id": 2, "o"""
                """wner_id": 1}]}""")

        self.assertEqual(
                self.__horae_interface.update_project(
                        1, 1, 'test_project_update', '2', 'hello update2'),
                """{"status": 0, "info": "OK"}""")
        self.assertEqual(
                self.__horae_interface.get_project_list(1, 0),
                """{"status": 0, "info": "OK", "projects": [{"pipe_num": 1,"""
                """ "description": "hello update2", "writer_list": "2", "na"""
                """me": "test_project_update", "is_default": 0, "id": 1, "o"""
                """wner_id": 1}, {"pipe_num": 1, "description": "\\u6d4b\\u"""
                """8bd5\\u9879\\u76ee1", "writer_list": "", "name": "\\u6d4"""
                """b\\u8bd5\\u9879\\u76ee2", "is_default": 0, "id": 2, "own"""
                """er_id": 1}]}""")

    def test_show_pipeline(self):
        django.contrib.auth.models.User.objects.create(
                id=1999,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user3',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        django.contrib.auth.models.User.objects.create(
                id=2999,
                password='sdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user4',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        horae.models.Project.objects.create(
                id=1,
                name="测试项目1", 
                owner_id=1999,
                is_default=False)
        horae.models.Project.objects.create(
                id=2,
                name="测试项目2", 
                owner_id=1999,
                is_default=False)
        horae.models.Project.objects.create(
                id=3,
                name="测试项目3", 
                owner_id=2999,
                is_default=False)

        horae.models.Pipeline.objects.create(
                id=21,
                name="21", 
                owner_id=1999, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag="test",
                enable=1,
                private=1,
                project_id=1)

        horae.models.Pipeline.objects.create(
                id=31,
                name="31", 
                owner_id=1999, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag="test",
                enable=1,
                private=1,
                project_id=2)
        horae.models.Pipeline.objects.create(
                id=41,
                name="41", 
                owner_id=2999, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                tag="test",
                enable=1,
                private=1,
                project_id=3)

        common.models.PermHistory.objects.create(
                id=91,
                resource_type=tools_util.CONSTANTS.PROJECT,
                resource_id=1,
                permission='write',
                applicant_id=2999,
                grantor_id=1999,
                status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        common.models.PermHistory.objects.create(
                id=92,
                resource_type=tools_util.CONSTANTS.PROJECT,
                resource_id=3,
                permission='write',
                applicant_id=1999,
                grantor_id=2999,
                status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')

        search_map = {}
        search_map["project_id"] = -2
        print self.__horae_interface.show_pipeline_info(
                owner_id=1999, 
                auth_tag=0,
                page_min=0, 
                page_max=20, 
                order_field='name', 
                sort_order='desc',
                search_map=search_map)

        search_map = {}
        search_map["project_id"] = 1
        print self.__horae_interface.show_pipeline_info(
                owner_id=1999, 
                auth_tag=0,
                page_min=0, 
                page_max=20, 
                order_field='name', 
                sort_order='desc',
                search_map=search_map)

        search_map = {}
        search_map["project_id"] = -1
        print self.__horae_interface.show_pipeline_info(
                owner_id=1999, 
                auth_tag=0,
                page_min=0, 
                page_max=20, 
                order_field='name', 
                sort_order='desc',
                search_map=search_map)

    def test_create_new_pipeline_ex(self):
        django.contrib.auth.models.User.objects.create(
                id=10,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user3',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        horae.models.Project.objects.create(
                id=1,
                name="测试项目1", 
                owner_id=10,
                is_default=False)

        self.assertEqual(
                self.__horae_interface.create_new_pipeline(
                name='new_pipe', 
                ct_time='1 * * * *', 
                owner_id=10, 
                manager_id_list='71,81,91', 
                monitor_way=2, 
                tag='a,b,c,d', 
                description='no no',
                project_id=1),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(name='new_pipe')
        self.assertEqual(pipeline.project_id, 1)

        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=pipeline.id, 
                owner_id=10, 
                name="test_delete_3", 
                manager_id_list='6,4,5',
                project_id=1),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(name='test_delete_3')
        self.assertEqual(pipeline.project_id, 1)

        horae.models.Project.objects.create(
                id=2,
                name="测试项目2", 
                owner_id=2999,
                is_default=False)
        self.assertEqual(
                self.__horae_interface.create_new_pipeline(
                name='new_pipe2', 
                ct_time='1 * * * *', 
                owner_id=10, 
                manager_id_list='71,81,91', 
                monitor_way=2, 
                tag='a,b,c,d', 
                description='no no',
                project_id=2),
                """{"status": 1, "info": "\u4f60\u6ca1\u6709\u9879\u76ee\u"""
                """7684\u6743\u9650\uff0c\u65e0\u6cd5\u52a0\u5165\u9879\u7"""
                """6ee!"}""")
        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=pipeline.id, 
                owner_id=10, 
                name="test_delete_3", 
                manager_id_list='6,4,5',
                project_id=2),
                """{"status": 1, "info": "\u4f60\u6ca1\u6709\u9879\u76ee\u"""
                """7684\u6743\u9650\uff0c\u65e0\u6cd5\u52a0\u5165\u9879\u7"""
                """6ee!"}""")
        common.models.PermHistory.objects.create(
                id=92,
                resource_type=tools_util.CONSTANTS.PROJECT,
                resource_id=2,
                permission='write',
                applicant_id=10,
                grantor_id=2999,
                status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')
        self.assertEqual(
                self.__horae_interface.create_new_pipeline(
                name='new_pipe2', 
                ct_time='1 * * * *', 
                owner_id=10, 
                manager_id_list='71,81,91', 
                monitor_way=2, 
                tag='a,b,c,d', 
                description='no no',
                project_id=2),
                """{"status": 0, "info": "OK"}""")
        pipeline = horae.models.Pipeline.objects.get(name='new_pipe2')
        self.assertEqual(pipeline.project_id, 2)
        self.assertEqual(self.__horae_interface.update_pipeline(
                pipeline_id=pipeline.id, 
                owner_id=10, 
                name="test_update", 
                manager_id_list='6,4,5',
                project_id=2),
                """{"status": 0, "info": "OK"}""")

        self.assertEqual(
                self.__horae_interface.create_new_pipeline(
                name='new_pipe21', 
                ct_time='1 * * * *', 
                owner_id=10, 
                manager_id_list='71,81,91', 
                monitor_way=2, 
                tag='a,b,c,d', 
                description='no no'),
                """{"status": 0, "info": "OK"}""")
        project = horae.models.Project.objects.get(owner_id=10, is_default=1)
        self.assertEqual(project.name, "test_user3_默认项目")
