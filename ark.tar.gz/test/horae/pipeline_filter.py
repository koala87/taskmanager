#coding=utf-8
import logging
from django.db import models
from django.conf import settings
from models import Pipeline

logger = logging.getLogger(settings.PROJECT_NAME)

def get_filter_option(filter_options, idx):
    
    key = 'columns[%d][data]' % idx
    search_column = filter_options.get(key, '')
    
    regex_key = 'columns[%d][search][regex]' % idx
    regex = filter_options.get(regex_key, '')

    value_key = 'columns[%d][search][value]' % idx
    value = filter_options.get(value_key, '')

    return search_column, value, regex


def filter_list(config_list, filter_options, current_user):
    MAX_COLUMN_NUM = 100
    for idx in range(MAX_COLUMN_NUM):
        search_column, value, regex = get_filter_option(filter_options, idx)

        if not search_column:
            break
        if not value:
            continue

        if search_column == 'name':
            config_list = config_list.filter(name__contains = value)
        elif search_column == 'type':
            config_list = config_list.filter(type__contains = value)
        elif search_column == 'description':
            config_list = config_list.filter(description__contains = value)
        elif search_column == 'owner':
            if value == str(0):
                # only owner
                config_list = config_list.filter(owner = current_user)
            else:
                # not owner
                config_list = config_list.exclude(owner = current_user)
                perm_objs = UserPerm.get_objs_for_user(
                    current_user, 
                    app = Config._meta.app_label,
                    perms = [PERM_TYPE_READ])

                ids = [c.id for c in perm_objs]
                if value == str(1):
                    # has no permission
                    config_list = config_list.exclude(id__in = ids)
                if value == str(2):
                    # has permission
                    config_list = config_list.filter(id__in = ids)
        elif search_column == 'fluctuation':
            if value == str(0):
                config_list = config_list.exclude(fluctuation = 0)
            if value == str(1):
                config_list = config_list.filter(fluctuation = 0)
                
    return config_list
