from django.conf.urls import patterns, url
from horae import views

urlpatterns = patterns('',
    url(r'^$',views.console_index),
    url(r'^index/$',views.console_index),

    url(r'^add_new_project/$',views.add_new_project),
    url(r'^update_project/$',views.update_project),
    url(r'^delete_project/$',views.delete_project),
)


