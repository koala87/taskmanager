﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
实时请求http服务实现，解决实时命令请求

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import time
import ConfigParser
import exceptions
import traceback
import urllib2
import json
import copy
import signal
import ConfigParser
import threading
import random

import horae.models
import django.contrib.auth
import tools_util
import horae_interface
import tools_sql_manager
import graph_manager
import common_logger

class AutoPipelineHandler(threading.Thread):
    mutex = threading.Lock()
    def __init__(self, horae_interface=None, logger=None):
        if not hasattr(self, "a"):
            tools_util.AutoLock(AutoPipelineHandler.mutex)
            if not hasattr(self, "a"):
                threading.Thread.__init__(self)
                self.__ip_lock = threading.Lock()
                self.__log = logger
                self.__horae_interface = horae_interface
                self.__task_type_conf_name = (
                    'script',
                    'apsara_job',
                    'odps_sql',
                    'odps_mr',
                    'odps_xlab',
                    'odps_spark'
                )

                self.__type_name_id_map = {
                    'script': tools_util.TaskType.SCRIPT_TYPE,
                    'apsara_job': tools_util.TaskType.APSARA_JOB,
                    'odps_sql': tools_util.TaskType.ODPS_SQL,
                    'odps_mr': tools_util.TaskType.ODPS_MAP_REDUCE,
                    'odps_xlab': tools_util.TaskType.ODPS_XLAB_SCRIPT,
                    'odps_spark': tools_util.TaskType.ODPS_SPARK
                }

                self.__task_type_with_server_tag_map = {}
                # self.__get_valid_ip_from_conf()
                self.start()
                self.a = "a"  # 必须在后面

    def __new__(cls, *args, **kw):
        if not hasattr(cls, "_instance"):
            orig = super(AutoPipelineHandler, cls)
            cls._instance = orig.__new__(cls, *args, **kw)

        return cls._instance

    def get_server_tag(self, task_type):
        if task_type in self.__task_type_with_server_tag_map:
            ret_map = {}
            ret_map["status"] = 0
            ret_map["info"] = "OK"
            ret_map["server_tags"] = \
                    self.__task_type_with_server_tag_map[task_type]
            return json.dumps(ret_map)
        ret_map = {}
        ret_map["status"] = 1
        ret_map["info"] = "just ALL!"
        return json.dumps(ret_map)

    def run(self):
        self.__log.info("AutoPipelineHandler thread starting...")
        while not tools_util.CONSTANTS.GLOBAL_STOP:
            try:
                begin_time = time.time()
                self.__log.info("AutoPipelineHandler handle data started")
                self.__get_valid_ip_from_conf()
                use_time = time.time() - begin_time
                self.__log.info("AutoPipelineHandler handle data "
                        "exit.use time[%f]" % use_time)
            except exceptions.Exception as ex:
                self.__log.error("thread error:%s" % str(ex))

            time.sleep(3600)
        self.__log.info("AutoPipelineHandler thread ended!")

    def handle_auto_pipeline(self, json_obj, ip):
        try:
            if ip is None or not self.__check_ip_valid(ip):
                return self.__get_ret_map(1, "ip address[%s] unvalid!" % ip)

            if not self.__check_user_valid(json_obj):
                return self.__get_ret_map(1, "uesrname or password unvalid!")

            ret = ''
            if json_obj["cmd"].strip() == "create_pipeline":
                ret = self.__handle_create_pipeline(json_obj)
            elif json_obj["cmd"].strip() == "get_pipeline":
                ret = self.__handle_get_pipeline(json_obj)
            elif json_obj["cmd"].strip() == "update_pipeline":
                ret = self.__handle_update_pipeline(json_obj)
            elif json_obj["cmd"].strip() == "delete_pipeline":
                ret = self.__handle_delete_pipeline(json_obj)
            elif json_obj["cmd"].strip() == "add_task":
                ret = self.__handle_add_task(json_obj)
            elif json_obj["cmd"].strip() == "get_task":
                ret = self.__handle_get_task(json_obj)
            elif json_obj["cmd"].strip() == "remove_task":
                ret = self.__handle_delete_task(json_obj)
            elif json_obj["cmd"].strip() == "update_task":
                ret = self.__handle_update_task(json_obj)
            elif json_obj["cmd"].strip() == "add_edge":
                ret = self.__handle_add_edge(json_obj)
            elif json_obj["cmd"].strip() == "remove_edge":
                ret = self.__handle_remove_edge(json_obj)
            elif json_obj["cmd"].strip() == "run_pipeline":
                ret = self.__handle_run_pipeline(json_obj)
            elif json_obj["cmd"].strip() == "run_task":
                ret = self.__handle_run_task(json_obj)
            elif json_obj["cmd"].strip() == "stop_pipeline":
                ret = self.__handle_stop_pipeline(json_obj)
            elif json_obj["cmd"].strip() == "stop_task":
                ret = self.__handle_stop_task(json_obj)
            elif json_obj["cmd"].strip() == "get_pipeline_last_status":
                ret = self.__handle_get_pipeline_last_status(json_obj)
            elif json_obj["cmd"].strip() == "create_processor":
                ret = self.__handle_create_processor(json_obj)
            elif json_obj["cmd"].strip() == "get_processor":
                ret = self.__handle_get_processor(json_obj)
            elif json_obj["cmd"].strip() == "update_processor":
                ret = self.__handle_update_processor(json_obj)
            elif json_obj["cmd"].strip() == "delete_processor":
                ret = self.__handle_delete_processor(json_obj)
            elif json_obj["cmd"].strip() == "get_pipe_status":
                ret = self.__handle_get_pipeline_status(json_obj)
            elif json_obj["cmd"].strip() == "get_all_pipelines":
                ret = self.__handle_get_all_pipelines(json_obj)
            elif json_obj["cmd"].strip() == "get_pipeline_tasks":
                ret = self.__handle_get_pipeline_tasks(json_obj)
            elif json_obj["cmd"].strip() == "copy_pipeline":
                ret = self.__handle_copy_pipeline(json_obj)
            elif json_obj["cmd"].strip() == "get_file_content":
                ret = self.__handle_get_file_content(json_obj)
            elif json_obj["cmd"].strip() == "get_task_run_status_info":
                ret = self.__handle_get_task_run_status_info(json_obj)
            elif json_obj["cmd"].strip() == "change_pipeline_owner":
                ret = self.__handle_change_pipeline_owner(json_obj)
            else:
                ret = self.__get_ret_map(
                        1, 
                        "unkown cmd:%s" % json_obj["cmd"].strip())
            ret_json = json.loads(ret)
            if ret_json["status"] != 0:
                raise exceptions.Exception(ret_json["info"])

            return ret
        except exceptions.Exception as ex:
            self.__log.warn(
                    "ex:%s, trace: %s" % (str(ex), traceback.format_exc()))
            str_ex = str(ex)
            if str_ex.find("Task matching query does not exist") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.TASK_NOT_EXISTS, 
                        str(ex))

            if str_ex.find("Processor matching query does not exist") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.PROCESSOR_NOT_EXISTS, 
                        str(ex))

            if str_ex.find("Pipeline matching query does not exist") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.PIPELINE_NOT_EXISTS, 
                        str(ex))

            if str_ex.find("task_unique_index") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.TASK_EXISTS, 
                        str(ex))
            
            if str_ex.find("copy new pipeline failed") >= 0 \
                    and str_ex.find("Duplicate entry") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.PIPELINE_EXISTS, 
                        str(ex))

            if str_ex.find("create_new_pipeline") >= 0 \
                    and str_ex.find("Duplicate entry") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.PIPELINE_EXISTS, 
                        str(ex))

            if str_ex.find("create_processor") >= 0 \
                    and str_ex.find("Duplicate entry") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.PROCESSOR_EXISTS, 
                        str(ex))

            if str_ex.find("权限") >= 0:
                return self.__get_ret_map(
                        tools_util.HttpStatus.AUTHORISATION_FAILED, 
                        str(ex))

            return self.__get_ret_map(1, "error:%s,%s" % (
                    str(ex), 
                    traceback.format_exc()))
         
    def __get_valid_ip_from_conf(self):
        config = ConfigParser.RawConfigParser()
        config.read("./conf/tools.conf")
        valid_ip = config.get("tools", "valid_ip").split(',')
        tools_util.AutoLock(self.__ip_lock)
        self.__valid_ip_set = set()
        for ip in valid_ip:
            if ip.strip() == '':
                continue
            self.__valid_ip_set.add(ip.strip())

        for config_key in self.__task_type_conf_name:
            if config.has_option("tools", config_key):
                server_tag = config.get("tools", config_key)
                if server_tag.strip() != '':
                    self.__task_type_with_server_tag_map[
                            self.__type_name_id_map[config_key]] = server_tag

    def __check_ip_valid(self, ip):
        return True
        tools_util.AutoLock(self.__ip_lock)
        return ip.strip() in self.__valid_ip_set
       
    def __check_user_valid(self, json_obj):
        user = django.contrib.auth.authenticate(
                username=json_obj["username"], 
                password=json_obj["password"])
        if user is None:
            return False
        
        if not user.is_active:
            return False

        return True

    def __handle_create_pipeline(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        managers = json_obj["owners_name"].split(',')
        manager_id_list = []
        for manager in managers:
            if manager.strip() == '':
                continue
            user = django.contrib.auth.models.User.objects.get(
                    username=manager.strip())
            manager_id_list.append(str(user.id))
        manager_list_str = ','.join(manager_id_list)
        monitor_way = 0
        if json_obj.has_key("monitor_way"):
            monitor_way = json_obj["monitor_way"]

        tag = ''
        if json_obj.has_key("tag"):
            tag = json_obj["tag"]

        description = ''
        if json_obj.has_key("description"):
            description = json_obj["description"]

        type = 1
        if json_obj.has_key("type"):
            type = json_obj["type"]

        if json_obj["username"].strip() == 'sm_scheduler':
            type = 9

        project_id = 0
        if json_obj.has_key("project_id"):
            project_id = int(json_obj["project_id"])

        ret = self.__horae_interface.create_new_pipeline(
                json_obj["name"].strip(),
                json_obj["ct_time"],
                owner_user.id,
                manager_list_str,
                monitor_way,
                tag,
                description,
                None,
                type,
                project_id)
        ret_json = json.loads(ret)
        if ret_json["status"] != 0:
            return ret

        if json_obj.has_key("enable") and json_obj["enable"] == 1:
            pipeline = horae.models.Pipeline.objects.get(
                    name=json_obj["name"].strip())

            user_info = django.contrib.auth.models.User.objects.filter(
                    is_superuser=1)

            ret = self.__horae_interface.pipeline_off_or_on_line(
                user_info[0].id,
                pipeline.id,
                json_obj["enable"],
                "auto pipeline")
        return ret

    def __handle_get_pipeline(self, json_obj):
        pl_name = None
        if json_obj.has_key("name") and json_obj["name"].strip() != '':
            pl_name = json_obj["name"].strip()

        pl_id = None
        if json_obj.has_key("id"):
            pl_id = json_obj["id"]

        if pl_id is None:
            if pl_name is None:
                return self.__get_ret_map(1, "pl_name and pl_id all None!")

            pipeline = horae.models.Pipeline.objects.get(name=pl_name)
            pl_id = pipeline.id

        return self.__horae_interface.get_pipeline_info(pl_id)

    def __handle_update_pipeline(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                    name=json_obj["name"].strip())
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        manager_list_str = None
        if json_obj.has_key("owners_name"):
            managers = json_obj["owners_name"].split(',')
            manager_id_list = []
            for manager in managers:
                if manager.strip() == '':
                    continue
                user = django.contrib.auth.models.User.objects.get(
                        username=manager.strip())
                manager_id_list.append(str(user.id))
            manager_list_str = ','.join(manager_id_list)
        monitor_way = 0
        if json_obj.has_key("monitor_way"):
            monitor_way = json_obj["monitor_way"]

        tag = ''
        if json_obj.has_key("tag"):
            tag = json_obj["tag"]

        description = ''
        if json_obj.has_key("description"):
            description = json_obj["description"]

        type = None
        if json_obj.has_key("type"):
            type = json_obj["type"]

        ct_time = None
        if json_obj.has_key("ct_time"):
            ct_time = json_obj["ct_time"]

        project_id = None
        if json_obj.has_key("project_id"):
            project_id = int(json_obj["project_id"])

        ret = self.__horae_interface.update_pipeline(
                pipeline.id,
                owner_user.id,
                0,
                json_obj["name"],
                ct_time,
                manager_list_str,
                monitor_way,
                tag,
                description,
                type,
                project_id)
        ret_json = json.loads(ret)
        if ret_json["status"] != 0:
            return ret

        if json_obj.has_key("enable"):
            user_info = django.contrib.auth.models.User.objects.filter(
                    is_superuser=1)

            ret = self.__horae_interface.pipeline_off_or_on_line(
                user_info[0].id,
                pipeline.id,
                json_obj["enable"],
                "auto pipeline")
        return ret

    def __handle_delete_pipeline(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                name=json_obj["name"].strip())
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        return self.__horae_interface.delete_pipeline(
                owner_user.id,
                pipeline.id)

    def __handle_add_task(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                    name=json_obj["pipeline_name"].strip())
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        task = json_obj["task"]
        processor = horae.models.Processor.objects.get(
                name=task["processor_name"])
        over_time = 0
        if task.has_key("over_time"):
            over_time = task["over_time"]

        config = ''
        if task.has_key("config"):
            config = task["config"]

        retry_count = 0
        if task.has_key("retry_count"):
            retry_count = task["retry_count"]

        description = ''
        if task.has_key("description"):
            description = task["description"]

        priority = 6
        if task.has_key("priority"):
            priority = task["priority"]

        server_tag = 'ALL'
        if task.has_key("server_tag"):
            server_tag = task["server_tag"]
	
        except_ret = 0
        if task.has_key("except_ret"):
            except_ret = int(task["except_ret"])
	if processor.type == 2 and server_tag == 'ALL':
            return self.__get_ret_map(1, "飞天job必须填写server_tag为AY54!")

        new_task = horae.models.Task(
            pl_id=pipeline.id,
            pid=processor.id,
            over_time=over_time,
            name=task["name"],
            config=config,
            retry_count=retry_count,
            description=description,
            priority=priority,
            server_tag=server_tag,
            except_ret=except_ret)
        return self.__horae_interface.add_new_task_to_pipeline(
                owner_user.id, 
                new_task)

    def __handle_get_task(self, json_obj):
        task_list = json_obj["tasks"]
        ret_task_list = []
        failed_id_list = []
        for task in task_list:
            get_task = None
            if task.has_key("id") and task["id"] != 0:
                id = task["id"]
                get_task = horae.models.Task.objects.get(id=id)
            else:
                pipeline = horae.models.Pipeline.objects.get(
                        name=task["pipeline_name"].strip())
                get_task = horae.models.Task.objects.get(
                        pl_id=pipeline.id,
                    name=task["task_name"].strip())

            ret = self.__horae_interface.get_task_info(get_task.id)
            json_ret = json.loads(ret)
            if json_ret["status"] == 0:
                ret_task_list.append(json_ret["task"])
            else:
                failed_id_list.append("error:%s" % (str(task)))

        ret_map = {}
        status = 0
        info = 'OK'
        if len(failed_id_list) > 0:
            status = 1
            info = "some task get failed:%s" % ','.join(failed_id_list)
        ret_map["status"] = status
        ret_map["info"] = info
        ret_map["tasks"] = ret_task_list
        return json.dumps(ret_map)

    def __handle_delete_task(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                name=json_obj["pipeline_name"].strip())
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        task = horae.models.Task.objects.get(
                pl_id=pipeline.id,
                name=json_obj["task_name"].strip())
        return self.__horae_interface.delete_task_info(
                owner_user.id,
                task.id)

    def __handle_update_task(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                name=json_obj["pipeline_name"].strip())
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        update_task = json_obj["task"]
        db_task = horae.models.Task.objects.get(
                pl_id=pipeline.id,
                name=update_task["name"].strip())
        old_db_task = copy.deepcopy(db_task)
        if update_task.has_key("processor_name"):
            processor = horae.models.Processor.objects.get(
                    name=update_task["processor_name"])
            db_task.pid = processor.id

        if update_task.has_key("over_time"):
            db_task.over_time = update_task["over_time"]

        if update_task.has_key("config"):
            db_task.config = update_task["config"]

        if update_task.has_key("retry_count"):
            db_task.retry_count = update_task["retry_count"]

        if update_task.has_key("description"):
            db_task.description = update_task["description"]

        if update_task.has_key("priority"):
            db_task.priority = update_task["priority"]

        if update_task.has_key("server_tag"):
            db_task.server_tag = update_task["server_tag"]

        if update_task.has_key("except_ret"):
            db_task.except_ret = int(update_task["except_ret"])

        return self.__horae_interface.update_tasks(
                owner_user.id,
                db_task,
                old_db_task)

    def __handle_add_edge(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())

        from_task_id = None
        if json_obj.has_key("from_task_id"):
            from_task_id = json_obj["from_task_id"]
        else:
            from_task = json_obj["from_task"]
            pipeline = horae.models.Pipeline.objects.get(
                    name=from_task["pipeline_name"].strip())
            from_db_task = horae.models.Task.objects.get(
                    pl_id=pipeline.id,
                    name=from_task["task_name"].strip())
            from_task_id = from_db_task.id

        to_task_id = None
        if json_obj.has_key("to_task_id"):
            to_task_id = json_obj["to_task_id"]
        else:
            to_task = json_obj["to_task"]
            pipeline = horae.models.Pipeline.objects.get(
                    name=to_task["pipeline_name"].strip())
            to_db_task = horae.models.Task.objects.get(
                    pl_id=pipeline.id,
                    name=to_task["task_name"].strip())
            to_task_id = to_db_task.id
        return self.__horae_interface.add_edge(
                owner_user.id, 
                from_task_id, 
                to_task_id)

    def __handle_remove_edge(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        from_task_id = None
        if json_obj.has_key("from_task_id"):
            from_task_id = json_obj["from_task_id"]
        else:
            from_task = json_obj["from_task"]
            pipeline = horae.models.Pipeline.objects.get(
                    name=from_task["pipeline_name"].strip())
            from_db_task = horae.models.Task.objects.get(
                    pl_id=pipeline.id,
                    name=from_task["task_name"].strip())
            from_task_id = from_db_task.id

        to_task_id = None
        if json_obj.has_key("to_task_id"):
            to_task_id = json_obj["to_task_id"]
        else:
            to_task = json_obj["to_task"]
            pipeline = horae.models.Pipeline.objects.get(
                    name=to_task["pipeline_name"].strip())
            to_db_task = horae.models.Task.objects.get(
                    pl_id=pipeline.id,
                    name=to_task["task_name"].strip())
            to_task_id = to_db_task.id
        return self.__horae_interface.delete_edge(
                owner_user.id, 
                from_task_id, 
                to_task_id)

    def __handle_run_pipeline(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                name=json_obj["pipeline_name"].strip())
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        run_time = json_obj["run_time"].strip()
        ordered_num = 0
        if json_obj.has_key("parallel_num"):
            ordered_num = int(json_obj["parallel_num"])

        return self.__horae_interface.run_pipeline(
                owner_user.id, 
                pipeline.id, 
                run_time,
                ordered_num)

    def __handle_run_task(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        ordered_num = 0
        if json_obj.has_key("parallel_num"):
            ordered_num = int(json_obj["parallel_num"])

        tasks = json_obj["tasks"]
        run_pair_list = []
        for task in tasks:
            pipeline = horae.models.Pipeline.objects.get(
                    name=task["pipeline_name"].strip())
            run_task = horae.models.Task.objects.get(
                    pl_id=pipeline.id,
                    name=task["task_name"].strip())
            run_time = task["run_time"].strip()
            run_pair_list.append((run_task.id, run_time))
        return self.__horae_interface.run_one_by_one_task(
                owner_user.id, 
                run_pair_list,
                ordered_num)

    def __handle_stop_pipeline(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                name=json_obj["pipeline_name"].strip())
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        if not json_obj.has_key("run_time") \
                or json_obj["run_time"].strip() == '':
            running_tasks = horae.models.Schedule.objects.filter(
                    pl_id=pipeline.id,
                    status__in=(
                    tools_util.TaskState.TASK_READY, 
                    tools_util.TaskState.TASK_RUNNING, 
                    tools_util.TaskState.TASK_TIMEOUT, 
                    tools_util.TaskState.TASK_WAITING))
            run_pair_list = []
            for run_task in running_tasks:
                ret = self.__horae_interface.stop_task(
                        owner_user.id, 
                        run_task.task_id, 
                        run_task.run_time)
                ret_json = json.loads(ret)
                if ret_json["status"] != 0:
                    return ret_json
            return self.__get_ret_map(0, "OK")

        run_time = json_obj["run_time"].strip()
        return self.__horae_interface.stop_pipeline(
                owner_user.id, 
                pipeline.id, 
                run_time)

    def __handle_stop_task(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                username=json_obj["username"].strip())
        tasks = json_obj["tasks"]
        for task in tasks:
            pipeline = horae.models.Pipeline.objects.get(
                    name=task["pipeline_name"].strip())
            run_task = horae.models.Task.objects.get(
                    pl_id=pipeline.id,
                    name=task["task_name"].strip())

            if not task.has_key("run_time") \
                    or task["run_time"].strip() == '':
                running_tasks = horae.models.Schedule.objects.filter(
                        task_id=run_task.id,
                        status__in=(
                        tools_util.TaskState.TASK_READY, 
                        tools_util.TaskState.TASK_RUNNING, 
                        tools_util.TaskState.TASK_TIMEOUT, 
                        tools_util.TaskState.TASK_WAITING))
                for tmp_task in running_tasks:
                    ret = self.__horae_interface.stop_task(
                            owner_user.id, 
                            tmp_task.task_id, 
                            tmp_task.run_time)
                    ret_json = json.loads(ret)
                    if ret_json["status"] != 0:
                        return ret_json
            else:
                run_time = task["run_time"].strip()
                ret = self.__horae_interface.stop_task(
                        owner_user.id, 
                        run_task.id, 
                        run_time)
                ret_json = json.loads(ret)
                if ret_json["status"] != 0:
                    return ret_json
        return self.__get_ret_map(0, "OK")

    def __handle_get_pipeline_last_status(self, json_obj):
        pipeline = horae.models.Pipeline.objects.get(
                name=json_obj["pipeline_name"].strip())
        run_time = ''
        if json_obj.has_key('run_time'):
            run_time = json_obj["run_time"].strip()

        run_historys = []
        if run_time == '':
            runhistory = horae.models.RunHistory.objects.filter(
                    pl_id=pipeline.id).latest('id')
            run_time = runhistory.run_time
            run_historys = horae.models.RunHistory.objects.filter(
                    pl_id=pipeline.id,
                    run_time=runhistory.run_time)
        else:
            if len(run_time) != tools_util.CONSTANTS.RUN_TIME_LENTGH:
                return self.__get_ret_map(
                        1, 
                        "run_time lenth[%s] need[%Y%m%d%H%M] error[%s]!" % (
                        len(run_time), run_time))

            run_historys = horae.models.RunHistory.objects.filter(
                    pl_id=pipeline.id,
                    run_time=run_time)

        task_list = []
        for run_history in run_historys:
            task = horae.models.Task.objects.get(id=run_history.task_id)
            task_map = {}
            task_map["task_name"] = task.name
            task_map["status"] = run_history.status
            task_list.append(task_map)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["task_list"] = task_list
        ret_map["run_time"] = run_time
        return json.dumps(ret_map)

    def __handle_create_processor(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        name = json_obj["name"].strip()
        type = json_obj["type"]
        odps_sql = ''
        if json_obj.has_key("odps_sql"):
            odps_sql = json_obj["odps_sql"].strip()

        description = ''
        if json_obj.has_key("description"):
            description = json_obj["description"].strip()

        config = ''
        if json_obj.has_key("config"):
            config = json_obj["config"].strip()

        private = 1
        if json_obj.has_key("private"):
            private = json_obj["private"]

        now_time = tools_util.StaticFunction.get_now_format_time(
                "%Y-%m-%d %H:%M:%S")
        processor = horae.models.Processor(
                name=name,
                type=type,
                template=odps_sql,
                update_time=now_time,
                description=description,
                config=config,
                owner_id=owner_user.id,
                private=private)

        return self.__horae_interface.create_processor(processor)

    def __handle_update_processor(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        processor = None
        if json_obj.has_key("id"):
            processor = horae.models.Processor.objects.get(
                    id=json_obj["id"])

        if json_obj.has_key("name"):
            name = json_obj["name"].strip()
            if processor is None:
                processor = horae.models.Processor.objects.get(
                        name=json_obj["name"])
            else:
                processor.name = name
        if json_obj.has_key("type"):
            processor.type = json_obj["type"]

        if json_obj.has_key("odps_sql"):
            processor.template = json_obj["odps_sql"].strip()

        if json_obj.has_key("description"):
            processor.description = json_obj["description"].strip()

        if json_obj.has_key("config"):
            processor.config = json_obj["config"].strip()

        if json_obj.has_key("private"):
            processor.private = json_obj["private"]

        return self.__horae_interface.update_processor(
                owner_user.id, 
                processor)
 
    def __handle_delete_processor(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        pid = None
        if json_obj.has_key("id"):
            pid = json_obj["id"]
        else:
            name = json_obj["name"].strip()
            processor = horae.models.Processor.objects.get(
                    name=json_obj["name"])
            pid = processor.id

        return self.__horae_interface.delete_processor(pid)

    def __handle_get_processor(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        pid = None
        if json_obj.has_key("id"):
            pid =json_obj["id"]
        else:
            name = json_obj["name"].strip()
            processor = horae.models.Processor.objects.get(
                    name=json_obj["name"])
            pid = processor.id
        return self.__horae_interface.get_processor_info(pid)

    def __handle_get_pipeline_status(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        pl_id = None
        if json_obj.has_key("id"):
            pl_id = json_obj["id"]
        else:
            pipeline = horae.models.Pipeline.objects.get(
                    name=json_obj["name"].strip())
            pl_id = pipeline.id
        run_time = ""
        if json_obj.has_key("run_time"):
            run_time = json_obj["run_time"].strip()

        num_limit = 1
        if json_obj.has_key("num_limit"):
            num_limit = int(json_obj["num_limit"])
            if num_limit <= 0:
                return self.__get_ret_map(1, "num_limit error must > 0!")

        if run_time.strip() == "":
            runhistorys = horae.models.RunHistory.objects.filter(
                    pl_id=pl_id).order_by('-run_time')[0: num_limit]
            run_time_list = []
            for run_history in runhistorys:
                run_time_list.append(run_history.run_time)
            run_time = ",".join(run_time_list)

        return self.__horae_interface.get_pipeline_status(
                owner_user.id,
                pl_id, 
                run_time)
 
    def __handle_get_all_pipelines(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        return self.__horae_interface.get_all_authed_pipeline_info(
                owner_user.id)

    def __handle_get_pipeline_tasks(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        pipeline = None
        if json_obj.has_key("id"):
            pipeline = horae.models.Pipeline.objects.get(
                    id=json_obj["id"])
        else:
            pipeline = horae.models.Pipeline.objects.get(
                    name=json_obj["name"].strip())

        return self.__horae_interface.get_tasks_by_pipeline_id(
                pipeline.id)
 
    def __handle_copy_pipeline(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        pipeline = None
        if json_obj.has_key("id"):
            pipeline = horae.models.Pipeline.objects.get(
                    id=json_obj["id"])
        else:
            pipeline = horae.models.Pipeline.objects.get(
                    name=json_obj["name"].strip())

        new_pl_name = json_obj["new_pl_name"].strip()
        project_id = 0
        if json_obj.has_key("project_id"):
            project_id = int(json_obj["project_id"])

        return self.__horae_interface.copy_pipeline(
                owner_user.id,
                pipeline.id,
                new_pl_name,
                project_id,
                True)

    def __handle_get_file_content(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        task_id = 0
        if json_obj.has_key("task_id"):
            task_id = int(json_obj["task_id"])
        elif json_obj.has_key("pipe_name"):
            pl_name = json_obj["pipe_name"].strip()
            pipeline = horae.models.Pipeline.objects.get(name=pl_name)
            if json_obj.has_key("task_name"):
                task_name = json_obj["task_name"].strip()
                task = horae.models.Task.objects.get(
                        name=task_name, 
                        pl_id=pipeline.id)
                task_id = task.id
            else:
                return self.__get_ret_map(1, "没有任务名!")
        else:
            return self.__get_ret_map(1, "没有流程名或者填写task_id!")

        run_time = json_obj["run_time"].strip()
        file_name = json_obj["file_name"].strip()
        start_pos = 0
        if json_obj.has_key("start_pos"):
            start_pos = int(json_obj["start_pos"])

        read_len = 10240
        if json_obj.has_key("read_len"):
            read_len = int(json_obj["read_len"])

        if read_len > 1024 * 1024:
            read_len = 1024 * 1024

        schedule = horae.models.Schedule.objects.get(
                task_id=task_id, 
                run_time=run_time)
        retried_times = 0
        while retried_times < 3:
            read_len += random.randint(3, 50)
            ret = self.__horae_interface.get_task_log_content(
                    schedule.id,
                    file_name,
                    start_pos,
                    read_len)
            if ret.find("\"status\": 1") <= 0:
                break
            retried_times += 1
        try:
            tmp_ret_map = json.loads(ret)
            if "status" in tmp_ret_map:
                if tmp_ret_map["status"] != 0:
                    return tmp_ret_map
        except:
            pass

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["file_content"] = ret
        return json.dumps(ret_map)

    def __handle_get_task_run_status_info(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        task_id = 0
        if json_obj.has_key("task_id"):
            task_id = int(json_obj["task_id"])
        elif json_obj.has_key("pipe_name"):
            pl_name = json_obj["pipe_name"].strip()
            pipeline = horae.models.Pipeline.objects.get(name=pl_name)
            if json_obj.has_key("task_name"):
                task_name = json_obj["task_name"].strip()
                task = horae.models.Task.objects.get(
                        name=task_name, 
                        pl_id=pipeline.id)
                task_id = task.id
            else:
                return self.__get_ret_map(1, "没有任务名!")
        else:
            return self.__get_ret_map(1, "没有流程名或者填写task_id!")

        run_time = json_obj["run_time"].strip()
        return self.__horae_interface.get_task_run_status_info(
                task_id,
                run_time)

    def __handle_change_pipeline_owner(self, json_obj):
        owner_user = django.contrib.auth.models.User.objects.get(
                    username=json_obj["username"].strip())
        new_owner = django.contrib.auth.models.User.objects.get(
                    username=json_obj["new_owner_name"].strip())
        pl_id = None
        if json_obj.has_key("pipe_id"):
            pl_id = int(json_obj["pipe_id"])
        elif json_obj.has_key("pipe_name"):
            pl_name = json_obj["pipe_name"].strip()
            pipeline = horae.models.Pipeline.objects.get(name=pl_name)
            pl_id = pipeline.id
        else:
            return self.__get_ret_map(1, "没有流程名或者填写pipe_id!")

        return self.__horae_interface.change_pipeline_owner(
                owner_user.id,
                pl_id,
                new_owner.id)

    def __get_ret_map(self, status, info):
        ret_map = {}
        ret_map["status"] = status
        ret_map["info"] = info
        return json.dumps(ret_map)
