from django.conf.urls import patterns, url
from horae import views

urlpatterns = patterns('',
    url(r'^$',views.processor_index),
    url(r'^index/$',views.processor_index),

    url(r'^list/$',views.list_processor),
    url(r'^create/$',views.create_processor),
    url(r'^update/(?P<processor_id>\d+)/$',views.update_processor),
    url(r'^delete/(?P<proc_id>\d+)/$',views.delete_processor),
    url(r'^(?P<proc_id>\d+)/$',views.processor_detail),
    url(r'^public_processor/$',views.public_processor),
    url(r'^viewHistory/(?P<proc_id>\d+)/$',views.view_processor_history),
    url(r'^viewQuote/(?P<proc_id>\d+)/$',views.view_quote),
    url(r'^reback/(?P<hist_id>\d+)/$',views.reback),

)


