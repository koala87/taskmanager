from django.conf.urls import patterns, url
from horae import views

urlpatterns = patterns('',
    url(r'^auto_pipeline/(?P<argv>.*)/$',views.auto_pipeline),
    url(r'^getUploadCmd/$',views.get_upload_cmd),
    url(r'^uploadProcessor/$',views.upload_processor),
    url(r'^auto_post_pipeline/$',views.auto_post_pipeline),

)


