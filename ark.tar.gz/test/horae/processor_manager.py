﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
前端工具流程管理相关接口实现

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import exceptions
import time
import traceback
import logging
import json
import ConfigParser
import shutil
import urllib2

import django.db
import horae.models
import django.db.models
import django.core.exceptions
import enum
import crontab

import tools_sql_manager
import common_logger
import tools_util
import graph_manager
import no_block_sys_cmd

class ProcessorManager(object):
    """
        流程管理接口实现
    """
    def __init__(self, logger):
        self.__log = logger
        self.__sql_manager = tools_sql_manager.SqlManager(logger)
        config = ConfigParser.RawConfigParser()
        config.read("./conf/tools.conf")
        self.__pu_cmd = config.get("tools", "pu_cmd")
        self.__pm_run = config.get("tools", "pm_run")
        self.__odps_cmd = config.get("tools", "odps_cmd")
        self.__work_dir = config.get("tools", "work_dir")
        if not self.__work_dir.endswith("/"):
            self.__work_dir += "/"

        self.__general_pangu_dir = config.get("tools", "general_pangu_dir")
        if not self.__general_pangu_dir.endswith("/"):
            self.__general_pangu_dir += "/"

        self.__job_pangu_dir = config.get("tools", "job_pangu_dir")
        if not self.__job_pangu_dir.endswith("/"):
            self.__job_pangu_dir += "/"

        tmp_resource_list = config.get(
                "tools", 
                "odps_source_suffix").split(",")
        self.__odps_resource_set = set()
        for source_fuffix in tmp_resource_list:
            if source_fuffix.strip() == '':
                continue
            self.__odps_resource_set.add(source_fuffix.strip())

        self.__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand(logger)

        add_apsara_package_http_list = config.get(
                "tools",
                "apsara_http").split(",")
        self.__apsara_package_http_list = []
        for http_htem in add_apsara_package_http_list:
            if http_htem.strip() == '':
                continue
            self.__apsara_package_http_list.append(http_htem.strip())

    # 插件管理
    def show_processor(
            self, 
            auth_tag,
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            search_map):
        where_content = ''
        if search_map is not None:
            tmp_content = self.__create_where_content(search_map)
            if tmp_content.strip() != '':
                where_content = "and %s" % tmp_content

        self.__log.error("auth_tag: %s" % auth_tag)
        count, processors = None, None
        if auth_tag == 0:
            count, processors = self.__sql_manager.show_processor_all(
                    owner_id, 
                    page_min, 
                    page_max, 
                    order_field, 
                    sort_order,
                    where_content)
        elif auth_tag == 1:
            count, processors = self.__sql_manager.show_processor_private(
                    owner_id, 
                    page_min, 
                    page_max, 
                    order_field, 
                    sort_order,
                    where_content)
        elif auth_tag == 2:
            count, processors = self.__sql_manager.show_processor_own_public(
                    owner_id, 
                    page_min, 
                    page_max, 
                    order_field, 
                    sort_order,
                    where_content)
        elif auth_tag == 3:
            count, processors = self.__sql_manager.show_processor_public(
                    owner_id, 
                    page_min, 
                    page_max, 
                    order_field, 
                    sort_order,
                    where_content)
        else:
            return self.__get_default_ret_map(
                    1, 
                    "unknown auth tag: %d" % auth_tag)
        return self.__create_show_processor_ret(count, processors)

    def create_processor(self, processor, user_id_list):
        status, info = self.__sql_manager.create_processor(
                processor, 
                user_id_list)
        return self.__get_default_ret_map(status, info)

    def update_processor(self, user_id, processor, user_id_list):
        status, info = self.__sql_manager.update_processor(
                user_id, 
                processor, 
                user_id_list)
        return self.__get_default_ret_map(status, info)

    def delete_processor(self, processor_id):
        status, info = self.__sql_manager.delete_processor(processor_id)
        return self.__get_default_ret_map(status, info)
    
    def get_processor_info(self, processor_id):
        processor = self.__sql_manager.get_proessor_info(processor_id)
        if processor is None:
            return self.__get_default_ret_map(1, "db error!")
        proc_map = {}
        proc_map["id"] = processor.id
        proc_map["name"] = processor.name
        proc_map["type"] = processor.type
        proc_map["template"] = processor.template
        proc_map["update_time"] = processor.update_time.strftime(
                "%Y-%m-%d %H:%M:%S")
        proc_map["description"] = processor.description
        proc_map["config"] = processor.config
        proc_map["owner_id"] = processor.owner_id
        proc_map["private"] = processor.private
        proc_map["tag"] = processor.tag
        proc_map["tpl_files"] = processor.tpl_files
        read_id_list, write_id_list = self.__sql_manager.get_owner_id_list(
                processor.id, 
                tools_util.CONSTANTS.PROCESSOR)
        user_name_list = []
        for user_id in read_id_list:
            user = self.__sql_manager.get_user_info_by_id(user_id)
            if user is not None:
                user_name_list.append(user.username)

        proc_map["user_list"] = ",".join(user_name_list)
        proc_map["userid_list"] = ",".join(read_id_list)

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["processor"] = proc_map

        return json.dumps(ret_map)

    def upload_pacakge(
            self, 
            processor_id, 
            owner_id, 
            file_path, 
            description=None,
            overwrite=False):
        now_time = "%.8f" % time.time()
        version_dot = int((float(now_time) - int(float(now_time))) * 100000000)
        version = "%s.%s" % (
                tools_util.StaticFunction.get_now_format_time("%Y%m%d%H%M%S"), 
                version_dot)
        processor = self.__sql_manager.get_proessor_info(processor_id)
        if processor is None:
            self.__log.error("get processor info failed!")
            return self.__get_default_ret_map(1, "get processor info failed!")

        if not self.__handle_genaral_package(
                processor.type, 
                processor_id, 
                version, 
                file_path,
                overwrite):
            self.__log.error("hand pangu package failed!")
            return self.__get_default_ret_map(1, "hand pangu package failed!")
        now_time = tools_util.StaticFunction.get_now_format_time(
                "%Y-%m-%d %H:%M:%S")
        if description is None:
            description = ''

        upload_history = horae.models.UploadHistory(
                processor_id=processor_id,
                status=1,
                update_time=now_time,
                upload_time=now_time,
                upload_user_id=owner_id,
                version=version,
                description=description)

        status, info = self.__sql_manager.upload_pacakge(upload_history)
        return self.__get_default_ret_map(status, info)

    def get_processor_package_history(self, processor_id):
        upload_historys = self.__sql_manager.get_processor_package_history(
                processor_id)
        if upload_historys is None:
            return self.__get_default_ret_map(1, "db error!")

        history_list = []
        for history in upload_historys:
            tmp_map = {}
            tmp_map["id"] = history[0]
            tmp_map["upload_time"] = history[1].strftime("%Y-%m-%d %H:%M:%S")
            tmp_map["upload_user_id"] = history[2]
            tmp_map["upload_user_name"] = history[3]
            tmp_map["version"] = history[4]
            tmp_map["status"] = history[5]
            tmp_map["description"] = history[6]
            history_list.append(tmp_map)
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["package_historys"] = history_list
        return json.dumps(ret_map)

    def use_processor_package(self, history_id):
        status, info = self.__sql_manager.use_processor_package(
                history_id, 
                self,
                self.__use_processor_package_callback)
        return self.__get_default_ret_map(status, info)

    def public_processor(self, processor_id):
        status, info = self.__sql_manager.public_processor(processor_id)
        return self.__get_default_ret_map(status, info)

    def get_processor_quote_list(self, processor_id):
        quote_list = self.__sql_manager.get_processor_quote_list(processor_id)
        if quote_list is None:
            return self.__get_default_ret_map(1, "db error!")
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["quote_list"] = quote_list
        return json.dumps(ret_map)

    def get_processor_quote_num(self, processor_id):
        quote_num = self.__sql_manager.get_processor_quote_num(processor_id)
        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["quote_num"] = quote_num
        return json.dumps(ret_map)

    def __prepair_work_dir(self, processor_id):
        tmp_work_dir = os.path.join(self.__work_dir, str(processor_id))
        if os.path.exists(tmp_work_dir):
            shutil.rmtree(tmp_work_dir)
        os.makedirs(tmp_work_dir)
        return tmp_work_dir

    def __download_package(
            self, 
            last_version, 
            processor_id, 
            work_dir):
        cmd = "%s cp %s/%s.tar.gz.%s %s/%s.tar.gz" % (
                self.__pu_cmd, 
                self.__general_pangu_dir, 
                processor_id, 
                last_version.version, 
                work_dir,
                processor_id)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            return False
        
        cmd = "cd %s && tar -zxvf %s.tar.gz" % (work_dir, processor_id)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            return False

        cmd = "rm -rf %s/%s.tar.gz" % (work_dir, processor_id)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            return False

        return True

    def __upload_apsara_package(self, work_dir, processor_id, version):
        file_path = "%s/%s.tar.gz" % (
                work_dir, 
                processor_id)
        if not os.path.exists(file_path):
            return True

        cmd = "%s rm %s/data_platform_processor_%s.tar.gz" % (
                self.__pu_cmd, 
                self.__job_pangu_dir, 
                processor_id)
        self.__no_block_cmd.run_many(cmd)

        cmd = ("%s cp %s/%s.tar.gz "
                "%s/data_platform_processor_%s.tar.gz" % (
                self.__pu_cmd, 
                work_dir,
                processor_id, 
                self.__job_pangu_dir,
                processor_id))
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("cp package to pangu failed![cmd:%s]" % cmd)
            return False

        cmd = ("%s cp %s/%s.tar.gz "
                "%s/data_platform_processor_%s.tar.gz.%s" % (
                self.__pu_cmd, 
                work_dir,
                processor_id, 
                self.__job_pangu_dir,
                processor_id,
                version))
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("cp package to pangu failed![cmd:%s]" % cmd)
            return False

        if not self.__add_pangu_pacakge(processor_id, work_dir):
            return False

        cmd = "rm -rf %s/%s.tar.gz" % (
                work_dir,
                processor_id)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("rm package failed![cmd:%s]" % cmd)
            return False
        return True

    def __handle_genaral_package(
            self, 
            task_type, 
            processor_id, 
            version, 
            file_path,
            overwrite):
        work_dir = self.__prepair_work_dir(processor_id)
        if not overwrite:
            ret, last_version = self.__sql_manager.get_processor_last_version(
                    processor_id)
            if not ret:
                self.__log.error("get processor last version db error!")
                return False

            if last_version is not None:
                if not self.__download_package(
                        last_version, 
                        processor_id,
                        work_dir):
                    self.__log.error("download_package last version pangu error!")

        cmd = "cp -rf %s/* %s" % (
                file_path, 
                work_dir)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("run cmd [%s] failed! stdout:%s, stderr:%s" % (cmd, stdout, stderr))
            return False

        package_path = "%s/%s.tar.gz" % (work_dir, processor_id)
        if os.path.exists(package_path) \
                and task_type != tools_util.TaskType.APSARA_JOB:
            cmd = "cd %s && tar -zxvf %s.tar.gz" % (
                    work_dir, 
                    processor_id)
            stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
            if retcode != 0:
                self.__log.error("run cmd [%s] failed!" % cmd)
                return False

            cmd = "rm -rf %s/%s.tar.gz" % (
                    work_dir, 
                    processor_id)
            stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
            if retcode != 0:
                self.__log.error("run cmd [%s] failed!" % cmd)
                return False

        if task_type == tools_util.TaskType.APSARA_JOB:
            if not self.__upload_apsara_package(
                    work_dir, 
                    processor_id, 
                    version):
                self.__log.error("__upload_apsara_package failed!")
                return False

        cmd = "cd %s && tar -zcvf %s.tar.gz ./*" % (
                work_dir, 
                processor_id)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("run cmd [%s] failed!" % cmd)
            return False

        cmd = "%s cp %s/%s.tar.gz %s/%s.tar.gz.%s" % (
                self.__pu_cmd, 
                work_dir,
                processor_id, 
                self.__general_pangu_dir,
                processor_id, 
                version)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("cp package to pangu failed![cmd:%s]" % cmd)
            return False

        # 用上传版本上线
        cmd = "%s rm %s/%s.tar.gz" % (
                self.__pu_cmd, 
                self.__general_pangu_dir,
                processor_id)
        self.__no_block_cmd.run_once(cmd)

        cmd = "%s cp %s/%s.tar.gz %s/%s.tar.gz" % (
                self.__pu_cmd, 
                work_dir,
                processor_id, 
                self.__general_pangu_dir,
                processor_id)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("upload work pacakge failed![%s]" % cmd)
            return False

        return True

    def __use_processor_package_callback(self, processor_id, version):
        processor = self.__sql_manager.get_proessor_info(processor_id)
        if processor is None:
            raise exceptions.Exception("get processor info failed!")

        work_dir = self.__prepair_work_dir(processor_id)
        if processor.type == tools_util.TaskType.APSARA_JOB:
            # 如果是盘古，需要重新AddPackage
            if not self.__add_pangu_pacakge(processor_id, work_dir):
                return False
        
        cmd = "%s rm %s/%s.tar.gz" % (
                self.__pu_cmd, 
                self.__general_pangu_dir,
                processor_id)
        self.__no_block_cmd.run_once(cmd)

        cmd = "%s cp %s/%s.tar.gz.%s %s/%s.tar.gz" % (
                self.__pu_cmd, 
                self.__general_pangu_dir,
                processor_id, 
                version,
                self.__general_pangu_dir,
                processor_id)
        stdout, stderr, retcode = self.__no_block_cmd.run_many(cmd)
        if retcode != 0:
            self.__log.error("change work pacakge failed![%s]" % cmd)
            return False
        return True

    def __add_pangu_pacakge(self, processor_id, work_dir):
        for http_item in self.__apsara_package_http_list:
            http_req_url = ("http://%s/upload?"
                    "package=data_platform_processor_%s.tar.gz" % (
                    http_item, 
                    processor_id))
            url_stream = "FAIL"
            try:
                url_stream = urllib2.urlopen(http_req_url).read()
            except exceptions.Exception as ex:
                self.__log.error(
                        "visit apsara http server "
                        "failed![%s][%s][%s]" % (
                        str(ex), traceback.format_exc(), http_req_url))
                return False
            
            if url_stream != "OK":
                self.__log.error(
                        "visit apsara http server "
                        "failed![%s][req: %s]" % 
                        (url_stream, http_req_url))
                return False
            
        return True

    def __get_processor_map(self, processor):
        proc_map = {}
        proc_map["id"] = processor[0]
        proc_map["name"] = processor[1]
        proc_map["type"] = processor[2]
        proc_map["template"] = processor[3]
        proc_map["update_time"] = processor[4].strftime("%Y-%m-%d %H:%M:%S")
        proc_map["description"] = processor[5]
        proc_map["config"] = processor[6]
        proc_map["owner_id"] = processor[7]
        proc_map["private"] = processor[8]
        proc_map["tag"] = processor[9]
        proc_map["tpl_files"] = processor[10]
        proc_map["quote_num"] = processor[11]
        return proc_map

    def __create_show_processor_ret(self, count, processors):
        if processors is None:
            ret_map = {}
            ret_map["status"] = 1
            ret_map["info"] = "visit mysql failed! please check db!"
            return json.dumps(ret_map)

        proc_list = []
        for processor in processors:
            proc_list.append(self.__get_processor_map(processor))

        if len(proc_list) > 0:
            proc_list = sorted(proc_list, key=lambda x: -x['quote_num'])

        ret_map = {}
        ret_map["status"] = 0
        ret_map["info"] = "OK"
        ret_map["count"] = count
        ret_map["processors"] = proc_list
        return json.dumps(ret_map)

    def __create_where_content(self, search_map):
        if search_map is None:
            return ""

        content_list = []
        for key in search_map:
            value = search_map[key]
            if value == '':
                continue

            if str(value).startswith('=') \
                    or str(value).startswith('>') \
                    or str(value).startswith('<') \
                    or str(value).startswith('!'):
                content_list.append("%s %s" % (key, value))
                continue
            content_list.append("%s like '%c%s%c' " % (key, '%', value, '%'))
        if len(content_list) <= 0:
            return ''

        where_content = " and ".join(content_list)
        return where_content

    def __get_default_ret_map(self, status, info):
        ret_map = {}
        ret_map["status"] = status
        ret_map["info"] = info
        return json.dumps(ret_map)

