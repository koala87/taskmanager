#coding=utf-8
import traceback
import logging
import django.db
from django.contrib.auth.decorators import login_required
from common.http_helper import JsonHttpResponse
from common.http_decorators import validate_params
from common.http_decorators import add_visit_record
from tools_util import TaskState
from models import Schedule
from models import ReadyTask
from models import RunHistory

logger = logging.getLogger('horae')

@login_required(login_url='/login/')
@validate_params(check_params = ['task_id', 'run_time'])
@django.db.transaction.atomic
@add_visit_record
def set_task_success(request):
    task_id = request.POST.get('task_id')
    run_time = request.POST.get('run_time')
    try:
        with django.db.transaction.atomic():
            ReadyTask.objects.filter(
                task_id = task_id, run_time = run_time).update(
                status = TaskState.TASK_SUCCEED)
            Schedule.objects.filter(
                task_id = task_id, run_time = run_time).update(
                status = TaskState.TASK_SUCCEED)
            RunHistory.objects.filter(
                task_id = task_id, run_time = run_time).update(
                status = TaskState.TASK_SUCCEED)
        return JsonHttpResponse({'status': 0, 'msg': '设置成功'})
    except Exception, ex:
        logger.error('set task success fail, %s' % traceback.format_exc())
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})
        

