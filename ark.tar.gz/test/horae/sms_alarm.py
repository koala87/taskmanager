#! /bin/env python
#encoding:utf-8

import urllib
import sys
import no_block_sys_cmd

ALARM_CRITICAL = 2
ALARM_WARN = 1

class SmsAlarm(object):
    @staticmethod
    def send_sms_msg(msg):
        msg = msg.replace(" ","-")
        msg = str(msg)
        encoded_msg = urllib.quote(msg)
        req_url = "http://10.206.32.22:7929/send_sms?msg=%s" % encoded_msg
        cmd = "curl %s" % req_url
        stdout, stderr, code = \
                no_block_sys_cmd.NoBlockSysCommand().run_many(cmd)
        print(stdout, stderr, code)
        if code !=0:
            return False
        return True

if __name__ == "__main__":
    SmsAlarm.send_sms_msg("test my msg 中文")

