﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import json
import urllib2

import django.test
import horae.models
import mock
import tornado.httpserver
import tornado.web
import tornado.ioloop
import django.contrib.auth
import simplejson

import tools_util
import horae_interface
import common_logger

class TestAutoPipelineHandler(django.test.TestCase):
    """description of class"""
    def setUp(self):
        tools_util.CONSTANTS.GLOBAL_STOP = True
        self.__user = django.contrib.auth.models.User.objects.create_user(
                'lei.xie', 
                "test@shenma-inc.com", 
                "sdf1")
        superuser = django.contrib.auth.models.User.objects.create_user(
                'ddlei.xie', 
                "test@shenma-inc.com", 
                "dd")
        superuser.is_superuser = 1
        superuser.save()
        horae.models.Processor.objects.create(
                id=1,
                name="xielei_test_script_proc", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)

        self.__horae_logger = common_logger.get_logger(
                "common", 
                "./log/horae")
        self.__horae_interface = horae_interface.HoraeInterface(
                self.__horae_logger)
        self.__horae_interface._HoraeInterface__pipeline_mgr.\
                _PipelineManager__admin_ip = \
                tools_util.StaticFunction.get_local_ip()
        #self.__horae_interface._HoraeInterface__pipeline_mgr.\
        #        _PipelineManager__admin_port = 6270
        self.__ip = "127.0.0.1"
        self.__config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./%year%_%month%_%day%_%hour%_00@-1hour/*.log")

    def __create_new_pipeline(self):
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "create_pipeline"
        req_map["name"] = "test_auto_pipeline1"
        req_map["ct_time"] = "10 * * * *"
        req_map["enable"] = 1
        req_map["description"] = "hello test auto pipeline"
        req_map["tag"] = "a,b,c,d"
        req_map["monitor_way"] = 2
        req_map["owners_name"] = ""

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

    def __delete_pipeline(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "delete_pipeline"
        req_map["name"] = "test_auto_pipeline1"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

    def ntest_update_pipeline(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "update_pipeline"
        req_map["name"] = "test_auto_pipeline1"
        req_map["ct_time"] = "11 * * * *"
        req_map["enable"] = 0
        req_map["description"] = "hello test auto pipeline"
        req_map["tag"] = "a,b,c,d"
        req_map["monitor_way"] = 2
        req_map["owners_name"] = ""

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

    def ntest_add_task(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test2"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        task_map["server_tag"] = 'ALL'
        task_map["except_ret"] = 0
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.__horae_interface.auto_pipeline_command(
        req_json, self.__ip)
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "get_task"
        tasks_list = []
        tmp_task_map = {}
        tmp_task_map["pipeline_name"] = "test_auto_pipeline1"
        tmp_task_map["task_name"] = "auto_task_test2"
        tasks_list.append(tmp_task_map)
        req_map["tasks"] = tasks_list
        req_map["pipeline_name"] = "test_auto_pipeline1"
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        # print(
        #        self.__horae_interface.auto_pipeline_command(
        #        req_json, self.__ip),
        #        """{"status": 0, "info": "OK", "tasks": [{"prev_task_i"""
        #        """ds": ",", "next_task_ids": ",", "name": "auto_task_"""
        #        """test2", "pid": 1, "priority": 6, "retry_count": 3,"""
        #        """ "over_time": 90, "pl_id": 80000, "last_run_time":"""
        #        """ "201506301810", "config": "input_file = pangu://A"""
        #        """Y500/test/test.* \\n output_file = pangu://AY500/te"""
        #        """st/test.log", "id": 20, "description": "xielei_tes"""
        #        """t_script_proc"}]}""")

    def ntest_delete_task(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test1"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.__horae_interface.auto_pipeline_command(
        req_json, self.__ip)
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "get_task"
        tasks_list = []
        tmp_task_map = {}
        tmp_task_map["pipeline_name"] = "test_auto_pipeline1"
        tmp_task_map["task_name"] = "auto_task_test1"
        tasks_list.append(tmp_task_map)
        req_map["tasks"] = tasks_list
        req_map["pipeline_name"] = "test_auto_pipeline1"
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        # print(
        #        self.__horae_interface.auto_pipeline_command(
        #                req_json, self.__ip),
        #        """{"status": 0, "info": "OK", "tasks": [{"prev_task_ids":"""
        #        """ ",", "next_task_ids": ",", "name": "auto_task_test1","""
        #        """ "pid": 1, "priority": 6, "retry_count": 3, "over_time":"""
        #        """ 90, "pl_id": 80001, "last_run_time": "201506301810","""
        #        """ "config": "input_file = pangu://AY500/test/test.* \\n"""
        #        """ output_file = pangu://AY500/test/test.log", "id": 21,"""
        #        """ "description": "xielei_test_script_proc"}]}""")

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "remove_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"
        req_map["task_name"] = "auto_task_test1"
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

    def ntest_update_task(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test3"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))

        self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip)
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "get_task"
        tasks_list = []
        tmp_task_map = {}
        tmp_task_map["id"] = "1"
        tmp_task_map["pipeline_name"] = "test_auto_pipeline1"
        tmp_task_map["task_name"] = "auto_task_test3"
        tasks_list.append(tmp_task_map)
        req_map["tasks"] = tasks_list
        req_map["pipeline_name"] = "test_auto_pipeline1"
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        print self.__horae_interface.auto_pipeline_command(
                       req_json, self.__ip)
        #        """{"status": 0, "info": "OK", "tasks": [{"prev_task_ids":"""
        #        """ ",", "next_task_ids": ",", "name": "auto_task_test3","""
        #        """ "pid": 1, "priority": 6, "retry_count": 3, "over_time":"""
        #        """ 90, "pl_id": 80006, "last_run_time": "201506301810","""
        #        """ "config": "input_file = pangu://AY500/test/test.* \\n"""
        #        """ output_file = pangu://AY500/test/test.log", "id": 26,"""
        #        """ "description": "xielei_test_script_proc"}]}""")

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "update_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"
            
        tmp_task_map = {}
        tmp_task_map["name"] = "auto_task_test3"
        tmp_task_map["description"] = "test_update_task"
        req_map["task"] = tmp_task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))

        self.__horae_interface.auto_pipeline_command(
                    req_json, self.__ip)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "get_task"
        tasks_list = []
        tmp_task_map = {}
        tmp_task_map["pipeline_name"] = "test_auto_pipeline1"
        tmp_task_map["task_name"] = "auto_task_test3"
        tasks_list.append(tmp_task_map)
        req_map["tasks"] = tasks_list
        req_map["pipeline_name"] = "test_auto_pipeline1"
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        # print(self.__horae_interface.auto_pipeline_command(
        #       req_json, self.__ip))

    def ntest_add_edge(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test4"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))

        self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test5"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))

        self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_edge"

        from_task = {}
        from_task["pipeline_name"] = "test_auto_pipeline1"
        from_task["task_name"] = "auto_task_test4"
        req_map["from_task"] = from_task
                        
        to_task = {}
        to_task["pipeline_name"] = "test_auto_pipeline1"
        to_task["task_name"] = "auto_task_test5"
        req_map["to_task"] = to_task
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "remove_edge"

        from_task = {}
        from_task["pipeline_name"] = "test_auto_pipeline1"
        from_task["task_name"] = "auto_task_test4"
        req_map["from_task"] = from_task
                        
        to_task = {}
        to_task["pipeline_name"] = "test_auto_pipeline1"
        to_task["task_name"] = "auto_task_test5"
        req_map["to_task"] = to_task
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

    def ntest_run_pipeline(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test4"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip)
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test5"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "run_pipeline"
        req_map["pipeline_name"] = "test_auto_pipeline1"
        req_map["run_time"] = "20150625"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        # self.assertEqual(
        #        self.__horae_interface.auto_pipeline_command(req_json, self.__ip),
        #        """{"status": 1, "info": "restart task failed! <urlopen"""
        #        """ error [Errno 111] Connection refused>, {\\"task_pair"""
        #        """_list\\": [{\\"run_time\\": \\"201506250000\\", \\"task_id"""
        #        """\\": \\"23\\"}, {\\"run_time\\": \\"201506250000\\", \\"task"""
        #        """_id\\": \\"24\\"}]}"}""")

    def ntest_run_task(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test4"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip)
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "add_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        task_map = {}
        task_map["processor_name"] = "xielei_test_script_proc"
        task_map["over_time"] = 90
        task_map["name"] = "auto_task_test5"
        task_map["config"] = ("input_file = pangu://AY500/test/test.* \n "
                                "output_file = pangu://AY500/test/test.log")
        task_map["retry_count"] = 3
        task_map["description"] = "xielei_test_script_proc"
        task_map["priority"] = 6
        req_map["task"] = task_map
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))

        self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "run_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        tasks_list = []
        tmp_task_map = {}
        tmp_task_map["pipeline_name"] = "test_auto_pipeline1"
        tmp_task_map["task_name"] = "auto_task_test4"
        tmp_task_map["run_time"] = "2015062510"
        tasks_list.append(tmp_task_map)
        req_map["tasks"] = tasks_list

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        # self.assertEqual(
        #        self.__horae_interface.auto_pipeline_command(req_json, self.__ip),
        #        """{"status": 1, "info": "restart task failed! <urlopen"""
        #        """ error [Errno 111] Connection refused>, {\\"task_pair"""
        #        """_list\\": [{\\"run_time\\": \\"201506251000\\", \\"task_id"""
        #        """\\": \\"25\\"}]}"}""")

    def ntest_check_ip_valid(self):
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "run_task"
        req_map["pipeline_name"] = "test_auto_pipeline1"

        tasks_list = []
        tmp_task_map = {}
        tmp_task_map["pipeline_name"] = "test_auto_pipeline1"
        tmp_task_map["task_name"] = "auto_task_test4"
        tmp_task_map["run_time"] = "2015062510"
        tasks_list.append(tmp_task_map)
        req_map["tasks"] = tasks_list

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.__ip = "111.111.111.111"
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip),
                """{"status": 1, "info": "ip"""
                """ address[111.111.111.111] unvalid!"}""")

    def ntest_stop_task(self):
        horae.models.Pipeline.objects.create(
                id=4708,
                name="xielei_test_pipe3", 
                owner_id=self.__user.id, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)
        horae.models.Task.objects.create(
                id=6075,
                pl_id=4708,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='xielei_test_pipe2_task_7',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        schedule = horae.models.Schedule.objects.create(
                id=122109,
                task_id=6075,
                run_time='201507231701',
                pl_id=4708,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                init_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "stop_task"
        tasks_map = {}
        tasks_map["pipeline_name"] = "xielei_test_pipe3"
        tasks_map["task_name"] = "xielei_test_pipe2_task_7"
        tasks_map["run_time"] = "201507231701"
        tasks_list = []
        tasks_list.append(tasks_map)
        req_map["tasks"] = tasks_list
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        print(
                self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

    def ntest_stop_pipeline(self):
        horae.models.Pipeline.objects.create(
                id=4708,
                name="xielei_test_pipe3", 
                owner_id=self.__user.id, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "stop_pipeline"
        req_map["pipeline_name"] = "xielei_test_pipe3"
        req_map["run_time"] = "201507231701"
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        print(
                self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip),
                """{"status": 0, "info": "OK"}""")

    def ntest_get_pipeline(self):
        self.__create_new_pipeline()
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_pipeline"
        req_map["name"] = "xielei_test_pipe2"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        self.assertEqual(ret_dict["status"], 0)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_pipeline"
        req_map["id"] = ret_dict["pipeline"]["id"]
        print(req_map)

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print(ret_dict)
        self.assertEqual(ret_dict["status"], 0)

    def ntest_stop_pipeline_with_no_run_time(self):
        horae.models.Pipeline.objects.create(
                id=4708,
                name="xielei_test_pipe3", 
                owner_id=self.__user.id, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        horae.models.Task.objects.create(
                id=6075,
                pl_id=4708,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='xielei_test_pipe2_task_7',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        schedule = horae.models.Schedule.objects.create(
                id=127290,
                task_id=6075,
                run_time='201507280901',
                pl_id=4708,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                init_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_RUNNING)
        schedule = horae.models.Schedule.objects.create(
                id=127244,
                task_id=6075,
                run_time='201507280801',
                pl_id=4708,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                init_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_WAITING)
        schedule = horae.models.Schedule.objects.create(
                id=127198,
                task_id=6075,
                run_time='201507280701',
                pl_id=4708,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                init_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_READY)
        schedule = horae.models.Schedule.objects.create(
                id=127152,
                task_id=6075,
                run_time='201507280601',
                pl_id=4708,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                init_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_RUNNING)

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "stop_task"
        tasks_map = {}
        tasks_map["pipeline_name"] = "xielei_test_pipe3"
        tasks_map["task_name"] = "xielei_test_pipe2_task_7"
        tasks_list = []
        tasks_list.append(tasks_map)
        req_map["tasks"] = tasks_list
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        print("test:", self.__horae_interface.auto_pipeline_command(
                req_json, self.__ip))
        print("test end")
        return
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "stop_task"
        req_map["pipeline_name"] = "xielei_test_pipe3"
        req_map["run_time"] = ""
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        print(self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip))

    def ntest_handle_get_pipeline_last_status(self):
        horae.models.Pipeline.objects.create(
                id=92,
                name="run_his92", 
                owner_id=1098, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)
        task_95 = horae.models.Task.objects.create(
                id=95,
                pl_id=92,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',96',
                over_time=12,
                name='run_his_task_95',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        task_96 = horae.models.Task.objects.create(
                id=96,
                pl_id=92,
                pid=1,
                next_task_ids=',95',
                prev_task_ids=',',
                over_time=12,
                name='run_his_task_96',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=93,
                name="run_his93", 
                owner_id=1097, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        task_97 = horae.models.Task.objects.create(
                id=97,
                pl_id=93,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',98',
                over_time=12,
                name='run_his_task_97',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        task_98 = horae.models.Task.objects.create(
                id=98,
                pl_id=93,
                pid=1,
                next_task_ids=',97',
                prev_task_ids=',',
                over_time=12,
                name='run_his_task_98',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=94,
                name="run_his94", 
                owner_id=1099, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        task_99 = horae.models.Task.objects.create(
                id=99,
                pl_id=94,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',100',
                over_time=12,
                name='run_his_task_99',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        task_100 = horae.models.Task.objects.create(
                id=100,
                pl_id=94,
                pid=1,
                next_task_ids=',99',
                prev_task_ids=',',
                over_time=12,
                name='run_his_task_100',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        run_his95 = horae.models.RunHistory.objects.create(
                id=2,
                task_id=95,
                run_time='201507061310',
                pl_id=92,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_RUNNING,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')
        run_his96 = horae.models.RunHistory.objects.create(
                id=3,
                task_id=96,
                run_time='201507061310',
                pl_id=92,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')

        horae.models.RunHistory.objects.create(
                id=4,
                task_id=97,
                run_time='201507061310',
                pl_id=93,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')
        horae.models.RunHistory.objects.create(
                id=5,
                task_id=98,
                run_time='201507061310',
                pl_id=93,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')

        horae.models.RunHistory.objects.create(
                id=6,
                task_id=99,
                run_time='201507061310',
                pl_id=94,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_FAILED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')
        horae.models.RunHistory.objects.create(
                id=7,
                task_id=100,
                run_time='201507061310',
                pl_id=94,
                start_time='2015-06-15 10:00:00',
                end_time='2015-06-15 20:00:00',
                status=tools_util.TaskState.TASK_SUCCEED,
                schedule_id=0,
                type=1,
                server_tag='ALL',
                task_handler='',
                run_server='')
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "sdf1"
        req_map["cmd"] = "get_pipeline_last_status"
        req_map["pipeline_name"] = "run_his94"
        req_map["run_time"] = ""
        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        self.assertEqual(
                self.__horae_interface.auto_pipeline_command(
                        req_json, self.__ip),
                """{"status": 0, "info": "OK", "task_list": [{"status": """
                """3, "task_name": "run_his_task_99"}, {"status": 2, "ta"""
                """sk_name": "run_his_task_100"}]}""")

    def ntest_create_processor(self):
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "create_processor"
        req_map["name"] = "xielei_test_proc1"
        req_map["type"] = tools_util.TaskType.ODPS_SQL
        req_map["odps_sql"] = "select * from xl_test;"
        req_map["description"] = "description"
        req_map["config"] = "a=b\nb=c\nc=d"
        req_map["private"] = 1

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "update_processor"
        req_map["name"] = "xielei_test_proc1"
        req_map["type"] = tools_util.TaskType.ODPS_SQL
        req_map["odps_sql"] = "select * from xl_test;"
        req_map["description"] = "description update"
        req_map["config"] = "a=b\nd=c\nc=d"
        req_map["private"] = 1

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_processor"
        req_map["name"] = "xielei_test_proc1"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "delete_processor"
        req_map["name"] = "xielei_test_proc1"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

    def ntest_get_pipe_status(self):
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_pipe_status"
        req_map["name"] = "xielei_test_pipe3"
        req_map["run_time"] = "20151010-20151117"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        self.assertEqual(
                ret_dict, 
                {
                    u'status': 1, 
                    u'info': u'\u6700\u591a\u83b7\u53d630\u5929\u7684\u6570\u636e\uff01'
                })

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_pipe_status"
        req_map["name"] = "xielei_test_pipe3"
        req_map["run_time"] = "20151010-20151109"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

    def ntest___handle_get_all_pipelines(self):
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_all_pipelines"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

    def ntest___handle_get_pipeline_tasks(self):
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_pipeline_tasks"
        req_map["id"] = 4708

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "get_pipeline_tasks"
        req_map["name"] = "xielei_test_pipe3"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict

    def test_change_pipeline_owner(self):
        req_map = {}
        req_map["username"] = "lei.xie"
        req_map["password"] = "123456"
        req_map["cmd"] = "change_pipeline_owner"
        req_map["new_owner_name"] = "lei.xie"
        req_map["pipe_name"] = "keywords_tools_c501c8552508bb07a4d8ab51b8aa7b48"

        req_json = json.dumps(req_map)
        # 编码， 用于发送请求
        req_json = urllib2.quote(req_json.encode('gbk'))
        node_req_url = ("http://10.99.16.60:10001/api/pipeline/auto_pipeline"
                "/%s/" % req_json)
        url_stream = urllib2.urlopen(node_req_url).read()

        json_str = json.loads(url_stream)
        ret_dict = simplejson.loads(json_str)
        print ret_dict
