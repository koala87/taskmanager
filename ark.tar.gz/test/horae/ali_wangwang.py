###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
阿里旺旺消息推送

"""

import os
import sys
import urllib2
import urllib
reload(sys)
sys.setdefaultencoding("utf-8")

import no_block_sys_cmd

class WangWang(object):
    @staticmethod
    def send_message(
            receiver, 
            submitter, 
            sub_title, 
            sub_link, 
            link_desc=None,
            message_status='success'):
        if link_desc is None:
            link_desc = "refer_link"

        tmp_sub_link = """<a+href%3d"{0}">{1}<a>""".format(
                sub_link, 
                link_desc)
        curl = (
                """http://10.181.204.100:8088/message_sender/sendMsg?"""
                """receiver={0}&&submitter={1}&sub_title={2}&"""
                """sub_link={3}&message_status={4}""".format(
                receiver, 
                submitter, 
                sub_title, 
                tmp_sub_link, 
                message_status))
        curl_cmd = """curl "%s" """ % curl
        stdout, stderr, return_code = \
                no_block_sys_cmd.NoBlockSysCommand().run_once(curl_cmd)
        return stdout, stderr, return_code

if __name__ == "__main__":
    print(WangWang.send_message(
            #"actantion1",
            "思舞飞扬1218", 
            "aa", 
            "中文aa", 
            "http://42.120.173.15:9999/pipeline/4711", 
            "abc"))

