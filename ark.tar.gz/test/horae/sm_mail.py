#!/bin/env python
#-*- coding: utf-8 -*-
import os
import sys 
import hashlib
import smtplib
from email.Header import Header
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.Utils import COMMASPACE, formatdate
from email import Encoders

USERNAME = 'shenma-log-reporter@alibaba-inc.com'
PASSWORD = 'shenma123456_'
MAIL_FROM = 'shenma-log-reporter@alibaba-inc.com'

'''
发送邮件
'''
def ex(mail_to):
    name = mail_to[:mail_to.find('<')]
    mail = mail_to[mail_to.find('<'):]
    mail_to = str(Header(name + mail, 'utf-8'))
    return mail_to

def make_mail_to(mail_to):
    mail_list = mail_to.split(',')
    mail_list = map(lambda x: ex(x), mail_list)
    return ','.join(mail_list)

def send(subject, content, mail_to, img_list):
    
    subject = Header(subject, 'utf-8')
    msg = MIMEMultipart()
    msg['From'] = USERNAME
    msg['To'] = make_mail_to(mail_to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    if len(content) > 0 : 
        msg_html = MIMEText(content, 'html', 'utf-8')
        msg.attach(msg_html)
        if img_list and isinstance(img_list, list):
            for img in img_list:
                if not img or not os.path.exists(img):
                    continue
                fp = open(img, 'rb')
                msg_img = MIMEImage(fp.read())
                fp.close()
                # 引用的时候以文件路径的md5值为id
                msg_img.add_header('Content-ID', hashlib.md5(os.path.basename(img)).hexdigest())
                msg.attach(msg_img)

    server = smtplib.SMTP_SSL("smtp.alibaba-inc.com", 465)
    #server.set_debuglevel(1)
    server.ehlo()
    server.login(USERNAME, PASSWORD)
    mail_to_list = mail_to.split(",")
    server.sendmail(USERNAME, mail_to_list, msg.as_string())
    server.quit

if __name__ == '__main__':
    send('testttttttttt', 'testttttttt', '谢磊<lei.xie@shenma-inc.com>', None)
