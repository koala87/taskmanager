#coding=utf-8
import traceback
import logging
import sys
sys.setrecursionlimit(10000)
import os
import json
import datetime
from django.contrib.auth import authenticate
from django.conf import settings
from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core import serializers
from common.http_helper import *
from common.odps import Odps
from common.odps import OdpsPrivilege
from common.models import PermHistory,Message
from common.convert_time import *
from common.models import PermHistory
from common.ark_perm import UserPerm
from common.ark_perm import is_admin
from common.http_decorators import add_visit_record
from ark_user.models import Info
from dms.models import Config

from pipeline_filter import *

from tools_util import StaticFunction
from models import Pipeline,Processor,Task
from horae.forms import PipelineForm,ProcessorForm,TaskForm,DocumentForm
from horae_interface import *
from tools_util import AuthAction
import common_logger
import no_block_sys_cmd
import ali_wangwang

ologger = logging.getLogger(settings.PROJECT_NAME)
horae_interface = HoraeInterface()

#log/user_log
__log = common_logger.get_logger(
        "rh_log",
        "./log/rh_log")

__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand(__log)

TAB_DATAINFO = 0
TAB_HISTORY = 1
TAB_PERMISSION = 2

HAS_NOT_OWNER_PERM = 0
HAS_OWNER_PERM = 1

READ_ONLY = 1
READ_WRITE = 2

MAX_COLUMN_NUM = 100
CUSTOM_TABLE_CUT = 150

DATA_MODE_DIR = 0
DATA_MODE_FILE = 1
DATA_MODE_PROJECT =2
DATA_MODE_TABLE = 3
DATA_MODE_PART = 4

NOT_RETRY = 1
ONE_TIME = 2
FIVE_TIME = 3
ALWAYS = 4

UPLOAD_FILES_PATH = 'upload_files/file/'
#WORK_PATH = '/home/admin/doc/rh_ark_tools/upload_files/file/'
WORK_PATH = settings.BASE_DIR + '/upload_files/file/'

CURRENT_URL = settings.SITE_URL

@login_required(login_url='/login/')
@add_visit_record
def home(request):
    user = request.user
    return render(request,'pipeline_home.html',{'user': user,'page_title':'主页'})

@login_required(login_url='/login/')
@add_visit_record
def index(request):
    user = request.user
    is_super = is_admin(user)
    try:
        abstract_info = horae_interface.get_pipeline_abstract_info(user.id)
        abstract_info = json.loads(abstract_info)

        #获取当前时间字符串
        today_time = datetime.datetime.utcnow() + \
                   datetime.timedelta(hours=8)
        today_time = today_time.strftime("%Y%m%d")
        res_projects = horae_interface.get_project_list(user.id, 0)
        res_projects = json.loads(res_projects)
        res_projects['projects'] = filter_default_project(res_projects['projects'], user.id)
        if res_projects['status'] == 0:
            project_list = res_projects['projects']
        else:
            project_list = []

    except Exception, ex:
        logger.error('get pipeline abstract info failed: <%s>' % str(ex))
        return JsonHttpResponse(
            {'status':1,'msg':str(ex)})

    return render(request,'pipeline_index.html',{'user': user,
            'abstract_info':abstract_info,'is_super':is_super,
            'today_time':today_time, 'page_title':'流程管理',
            'pipeline_model':1,'project_list':project_list,
            'page_index':2
            })

def search_equal(str):
    if str.startswith('='):
        str = "='"+str[1:]+"'"
    return str

def list_condition(request):

    user = request.user
    is_super = is_admin(user)

    condition = {}
    draw = request.POST.get('draw')
    start = request.POST.get('start')
    length = request.POST.get('length')
    
    page_min = int(start)
    page_max = int(start)+int(length)

    name = request.POST.get('columns[1][search][value]')
    project_id = request.POST.get('columns[2][search][value]')
    owner = request.POST.get('columns[3][search][value]')
    enable = request.POST.get('columns[4][search][value]')

    if name != '':
        name.encode()
        condition['name'] = search_equal(name)
    if project_id !='':
        condition['project_id'] = int(project_id)
    if enable != '':
        condition['enable'] = '='+enable.encode()
        
    if owner == '':
        if is_super == 1:
            owner = 0
        else:
            owner = 0
    return condition,int(owner),int(draw),page_min,page_max

def custom_table(user,pipe_list):
    is_super = is_admin(user)
    for pipe in pipe_list:
        pipeline = Pipeline.objects.get(id = pipe['id'])

        pipe['name'] = "<a href='/pipeline/task/"+str(pipe['id'])+\
                "/'>"+pipe['name']+"</a>"

        if pipe['enable'] == 0:
            pipe['enable'] = "<a title='点击上线'"+\
                " onclick='changeStatus("+str(pipe['id'])+",1,"+str(is_super)+")'"+\
                " href='javascript:void(0)' style='margin-left:14px' id='status_"+\
                str(pipe['id'])+"'><img style='width: 60px; height: 26px;' src=\"/static/images/offline_2.png\"></img></a>"
        if pipe['enable'] == 1:
            pipe['enable'] = "<a title='点击下线'"+\
                " onclick='changeStatus("+str(pipe['id'])+",0,"+str(is_super)+")'"+\
                " href='javascript:void(0)' style='margin-left:14px' id='status_"+\
                str(pipe['id'])+"'><img style='width: 60px; height: 26px;' src=\"/static/images/online_2.png\"></img></a>"

        if is_super == 1:
            if pipe['enable'] == 2:
                pipe['enable'] = "<a href='javascript:void(0)'"+\
                    " title='点击通过审批' onclick='changeStatus("+\
                    str(pipe['id'])+",1,"+str(is_super)+")'\
                    id='status_"+str(pipe['id'])+\
                    "'>同意</a>&nbsp;&nbsp;<a href='javascript:void(0)'"+\
                    " title='点击拒绝审批' onclick='changeStatus("+\
                    str(pipe['id'])+",0,"+str(is_super)+")'\
                    id='status_"+str(pipe['id'])+\
                    "'>拒绝</a>"
        else:
            if pipe['enable'] == 2:
                pipe['enable'] = "申请中"

    return pipe_list


def list(request):
    
    user = request.user
    condition,owner,draw,page_min,page_max = list_condition(request)

    pipelines = horae_interface.show_pipeline_info(user.id,owner,
            page_min,page_max,'update_time','desc',condition)

    pipelines = json.loads(pipelines)
    pipe_list = pipelines['pipe_list']

    no = int(page_min)
    for key in range(len(pipe_list)):
        no = no + 1
        pipe_list[key]['no'] = no
    pipe_count = pipelines['count']

    pipeline_total_count = pipe_count
    pipeline_filter_count = pipeline_total_count

    result = {"draw":draw,"recordsTotal": pipeline_total_count,
                "recordsFiltered": pipeline_filter_count}

    result['data'] = custom_table(user,pipe_list)

    return HttpResponse(json.dumps(result), content_type='application/json')

def status_msg(result):
    result = json.loads(result)
    status = result['status']
    msg = result['info']
    return status,msg

def mail_sms(send_mail,send_sms):
    mail_and_sms = send_mail and send_sms
    mail_or_sms = send_mail or send_sms
    if mail_and_sms:
        monitor_way = 3
    else:
        if not mail_or_sms:
            monitor_way = 0
        else:
            if send_mail:
                monitor_way = 2
            else:
                monitor_way = 1

    return monitor_way


@login_required(login_url='/login/')
@add_visit_record
def check_sms_phone(request):
    if request.method == 'POST' and request.is_ajax():
        phone = ''
        try:
            phone = request.user.user_info.phone
        except Exception, ex:
            logger.error("get user phone fail, %s" % traceback.format_exc())

        has_phone = phone is not None and phone.strip() != ""
        phone = str(phone)
        return JsonHttpResponse(
                {'status':int(not has_phone),'ali_monitor':phone})

def check_life_cycle(life_cycle):
    max_time = datetime.datetime.utcnow() + \
               datetime.timedelta(hours=8)+\
                datetime.timedelta(days=180)
    max_time_str = max_time.strftime("%Y%m%d")
    return max_time_str >= life_cycle


@login_required(login_url='/login/')
@add_visit_record
def create(request):
    error = []
    user = request.user
    is_super = is_admin(user)
    if request.method == 'POST' and request.is_ajax():
        form = PipelineForm(request.POST)
        if form.is_valid():
            try:
                name = form.cleaned_data['name']
                ct_time = form.cleaned_data['ct_time']
                principal = form.cleaned_data['principal']
                send_mail = form.cleaned_data['send_mail']
                send_sms = form.cleaned_data['send_sms']
                tag = form.cleaned_data['tag']
                project_group = form.cleaned_data['project_id']
                life_cycle = form.cleaned_data['life_cycle']
                description = form.cleaned_data['description']

                check_result = check_life_cycle(life_cycle)
                if not check_result:
                    raise Exception('生命周期设置不能超过6个月！')

                pipelines = Pipeline.objects.filter(name = name)
                if pipelines:
                    raise Exception('流程名重复！')

                if not project_group:
                    project_group = 0

                monitor_way = mail_sms(send_mail,send_sms)
                result = horae_interface.create_new_pipeline(name,ct_time,
                        user.id,principal,monitor_way,tag,description,
                        life_cycle,0,project_group)
                status,msg = status_msg(result)
                if status != 0:
                    raise Exception(msg)
            except Exception, ex:
                logger.error('create pipeline fail: <%s>' % str(ex))
                return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
            
            pipeline_id = Pipeline.objects.get(name=name).id
            return JsonHttpResponse(
                    {'status':status,'msg':msg,'pipeline_id':pipeline_id})
        else:
            return JsonHttpResponse({'status':1,'msg':form.errors.items()})
    else:  
        form = PipelineForm() 
    return render(request,'create_pipeline.html',{'form': form, 'page_title':'创建流程','pipeline_model':1, 'page_index':2,'is_super':is_super})

def get_pipeline_info(pipe_id):

    principal_name_list = ''
    principal_id_list = ''

    pipeline_info = horae_interface.get_pipeline_info(int(pipe_id))
    
    pipeline_info = json.loads(pipeline_info)
    pipeline_info = pipeline_info['pipeline']
    pipeline_principal_list = pipeline_info['owner_list']

    #获取有读写权限的用户list(负责人)
    for principal in pipeline_principal_list:
        principal_name_list += principal['username']+','
        principal_id_list += str(principal['id'])+','
    principal_name_list = principal_name_list[:-1]
    principal_id_list = principal_id_list[:-1]
    
    pipeline_info['principal_name_list'] = principal_name_list
    pipeline_info['principal_id_list'] = principal_id_list

    return pipeline_info


@login_required(login_url='/login/')
@add_visit_record
def update(request,pipe_id):
    pipeline = Pipeline.objects.get(id=pipe_id)
    user = request.user
    is_super = is_admin(user)
    if request.method == 'POST' and request.is_ajax():
        form = PipelineForm(request.POST, instance = pipeline)
        if form.is_valid():
            try:
                name = form.cleaned_data['name']
                ct_time = form.cleaned_data['ct_time']
                principal = form.cleaned_data['principal']
                send_mail = form.cleaned_data['send_mail']
                send_sms = form.cleaned_data['send_sms']
                tag = form.cleaned_data['tag']
                project_group = form.cleaned_data['project_id']
                life_cycle = form.cleaned_data['life_cycle']
                description = form.cleaned_data['description']

                check_result = check_life_cycle(life_cycle)
                if not check_result:
                    raise Exception('生命周期设置不能超过6个月！')

                pipelines = Pipeline.objects.filter(name = name)
                if pipelines:
                    if not pipeline in pipelines:
                        raise Exception('流程名重复！')

                if not project_group:
                    project_group = 0

                monitor_way = mail_sms(send_mail,send_sms)

                result = horae_interface.update_pipeline(int(pipe_id),user.id,
                        life_cycle,name,ct_time,principal,monitor_way,
                        tag,description,0,project_group)
                status,msg = status_msg(result)
            except Exception, ex:
                logger.error('update pipeline fail: <%s>' % str(ex))
                return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})

            return JsonHttpResponse(
                    {'status':status,'msg':msg})
        else:
            return JsonHttpResponse({'status':1,
                    'msg':form.errors.items()})
    else:
        user = request.user
        form = PipelineForm(instance = pipeline)
        pipeline_info = get_pipeline_info(pipe_id)
    return render(request,'update_pipeline.html',
            {'form': form,'pipeline':pipeline_info, 'is_super':is_super,'page_title':'修改流程','pipeline_model':1, 'page_index':2})


@login_required(login_url='/login/')
@add_visit_record
def delete(request,pipe_id):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        pipeline = Pipeline.objects.get(id=pipe_id)
        try:
            result = horae_interface.delete_pipeline(user.id,int(pipe_id))
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('delete pipeline fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse({'status':status,'msg':msg})

def get_app_group_list(request):
    if request.method == 'POST' and request.is_ajax():
        try:
            result = horae_interface.get_app_group_list()
            result = json.loads(result)
            status = result['status']
            msg = result['info']
            if result.has_key('app_list'):
                app_list = result['app_list']
            __log.info("app_list = " +app_list)

        except Exception,ex:
            logger.error('get app group fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg,'app_list':app_list})

@login_required(login_url='/login/')
@add_visit_record
def get_project_list(request):
    try:
        user = request.user
        auth_id = request.GET.get('auth', 0)
        result = horae_interface.get_project_list(request.user.id, int(auth_id))
        result = json.loads(result)
        result['projects'] = filter_default_project(result['projects'], user.id)
        status = result['status']
        msg = result['info']
        if result.has_key('projects'):
            project_list = result['projects']

    except Exception,ex:
        logger.error('get project list fail: <%s>' % str(ex))
        return JsonHttpResponse(
            {'status':1,'msg':'error:' + str(ex)})
    return JsonHttpResponse(
            {'status':status,'msg':msg,'project_list':project_list})


def monitor_dispaly(monitor_way):
    monitor_way_str = ''
    if monitor_way == 0:
        monitor_way_str = '无'
    elif monitor_way ==1:
        monitor_way_str = '短信'
    elif monitor_way ==2:
        monitor_way_str = '邮件'
    else:
        monitor_way_str = '邮件 短信'

    return monitor_way_str


#获取有权限的用户列表
def get_perm_user_list(pipe_id):
    #获取有权限用户列表
    users = horae_interface.get_pipeline_owner_list(pipe_id)
    users = json.loads(users)
    users = users['users']
    return users


#获取用户申请列表
def get_pipe_apply_list(owner_id, pipeline_id):
    applay_list = horae_interface.get_apply_list(owner_id,pipeline_id)
    applay_list = json.loads(applay_list)
    apply_list = applay_list['apply_list']
    if len(apply_list) > 0:
        i = 0
        for apply in apply_list:
            apply['pipe_id'] = pipeline_id
            apply['id'] = i
            i += 1
    return apply_list


@login_required(login_url='/login/')
@add_visit_record
def detail(request,pipe_id):
    pipeline = Pipeline.objects.get(id=pipe_id)
    user = request.user
    is_super = is_admin(user)

    monitor_way = pipeline.monitor_way
    monitor_way_str = monitor_dispaly(monitor_way)

    users = get_perm_user_list(int(pipe_id))
    #有读写权限的用户list
    pipeline_info = get_pipeline_info(int(pipe_id))
    pipeline_id_list = pipeline_info['principal_id_list']
    if str(user.id) in pipeline_id_list or is_super == 1:
        users = get_perm_user_list(int(pipe_id))
        apply_list = get_pipe_apply_list(user.id, int(pipe_id))
        return render(request,'pipeline_detail.html',
                {'pipeline': pipeline_info,'history_list':apply_list,
                'monitor_way_str':monitor_way_str,'tag':TAB_DATAINFO,
                'users':users,'perm_tag':HAS_OWNER_PERM,
                'is_super':is_super, 'page_title':'流程详情','pipeline_model':1,
                'page_index':2
                })
    else:
        return render(request,'pipeline_detail.html',
                {'pipeline': pipeline_info,'monitor_way_str':monitor_way_str,
                'tag':TAB_DATAINFO,'perm_tag':HAS_NOT_OWNER_PERM,
                'is_super':is_super,'page_title':'流程详情','pipeline_model':1,
                'page_index':2
                })


def get_user_list(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        try:
            all_users = horae_interface.get_all_user_info()
            all_users = json.loads(all_users)
            all_users = all_users['users']

            user_list = []
            for user in all_users:
                user_list.append({'id': user['id'], 'name': user['username']})
        except Exception, ex:
            logger.error('get user_list fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'user_list':user_list,'msg':'获取成功！'})

#流程上线
def on_line(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        pipe_id = request.POST.get("pipe_id")
        on_line = request.POST.get("on_line")
        reason = request.POST.get("reason")
        try:
            result = horae_interface.pipeline_off_or_on_line(user.id,
                    int(pipe_id), int(on_line), reason)
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('change status fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse({'status':status,'msg':msg})


def create_run_hist(pipe_hists):
    run_history = []
    cpu_history = []
    mem_history = []
    for pipe_hist in pipe_hists:
        run_history.append({"runtime":pipe_hist['run_time'],\
                "use_time":pipe_hist['use_time']})
        cpu_history.append({"runtime":pipe_hist['run_time'],\
                "cpu":pipe_hist['cpu']})
        mem_history.append({"runtime":pipe_hist['run_time'],\
                "mem":pipe_hist['mem']})
    return run_history,cpu_history,mem_history


#浏览历史，画图表
@login_required(login_url='/login/')
@add_visit_record
def view_history(request,pipe_id):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        time_start = request.POST.get('timeStart')
        time_end = request.POST.get('timeEnd')
        condition = {'pl_id':int(pipe_id)}
        search_list = [('run_time','>='+time_start),('run_time','<='+time_end)]

        run_history = []
        cpu_history = []
        mem_history = []
        try:
            result = {'runhistory_list':[]}
            index = 0
            step = 100
            while len(result['runhistory_list']) == step*index:
                res = horae_interface.show_run_history(1,user.id,index*step,(index+1)*step,\
                        'run_time','asc',search_map = condition,\
                        search_list = search_list)
                index = index+1
                res = json.loads(res)
                if  not result.has_key('runhistory_list'):
                    break;
                result['runhistory_list'].extend(res["runhistory_list"])

            if result.has_key('runhistory_list'):
                pipe_hists = result["runhistory_list"]
                if len(pipe_hists)>0:
                    run_history,cpu_history,mem_history = \
                            create_run_hist(pipe_hists)

        except Exception, ex:
            logger.error('view history fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'获取成功','run_history':run_history,
                'cpu_history':cpu_history,'mem_history':mem_history
                })


@login_required(login_url='/login/')
@add_visit_record
def permission(request,pipe_id):
    pipeline = Pipeline.objects.get(id=pipe_id)
    user = request.user
    is_super = is_admin(user)
    try:
        users = get_perm_user_list(int(pipe_id))
        apply_list = get_pipe_apply_list(user.id, int(pipe_id))
        pipeline_info = get_pipeline_info(int(pipe_id))
        monitor_way = pipeline.monitor_way
        monitor_way_str = monitor_dispaly(monitor_way)

    except Exception,ex:
        logger.error('view pipeline permission fail: <%s>' % str(ex))
        #raise Exception("查看权限错误！")
        return JsonHttpResponse(
            {'status':1,'msg':'has no permission!'})
    return render(request,'pipeline_detail.html',
            {'pipeline': pipeline_info,'users':users,
            'history_list':apply_list,'tag':TAB_PERMISSION,
            'monitor_way_str':monitor_way_str,'perm_tag':HAS_OWNER_PERM, 'is_super':is_super,'page_title':'流程详情','pipeline_model':1,
            'page_index':2
            })


@login_required(login_url='/login/')
@add_visit_record
def grant_permission(request):
    if request.method == 'POST' and request.is_ajax():
        user_ids = request.POST.get('userIds')
        pipe_id = request.POST.get('dataId')
        operator = request.user
        user_ids = user_ids.strip()
        user_ids = user_ids.strip(',')
        grant_users = user_ids.split(',')

        try:
            result = horae_interface.auth_grant_or_apply(\
                    AuthAction.GRANT_AUTH_TO_OTHER,'pipeline',
                    int(pipe_id),operator.id,grant_users,
                    READ_ONLY,'')
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('grant permission fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})
            

@login_required(login_url='/login/')
@add_visit_record
def revoke_permission(request):
    if request.method == 'POST' and request.is_ajax():
        user_id = request.POST.get('userId')
        pipe_id = request.POST.get('dataId')
        operator = request.user
        user_list = []
        user_list.append(int(user_id))
        try:
            result = horae_interface.auth_grant_or_apply(\
                    AuthAction.TAKE_BACK_AUTH,'pipeline',
                    int(pipe_id),operator.id,user_list,
                    READ_ONLY,'')
            status,msg = status_msg(result)

        except Exception, ex:
            logger.error('revoke permission fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})


@login_required(login_url='/login/')
@add_visit_record
def apply_permission(request,pipe_id):
    if request.method == 'POST' and request.is_ajax():
        reason = request.POST.get('reason')
        __log.info('reason: %s' % reason)

        user = request.user
        pipeline = Pipeline.objects.get(id=pipe_id)
        user_list = []
        user_list.append(user.id)
        try:
            grantor_id = pipeline.owner_id
            result = horae_interface.auth_grant_or_apply(\
                    AuthAction.APPLY_AUTH,'pipeline',
                    int(pipe_id),grantor_id,user_list,
                    READ_ONLY,reason)
            status,msg = status_msg(result)
            
            #申请权限，发送旺旺消息
            pipeline_info = get_pipeline_info(int(pipe_id))
            owner_list = pipeline_info['owner_list']
            for owner in owner_list:
                owner_user = User.objects.get(id=owner['id'])
                info = Info.objects.filter(user = owner_user)
                ali_wangwang_str = info[0].ali_wangwang

                if ali_wangwang_str:
                    stdout, stderr, retcode = \
                            ali_wangwang.WangWang.send_message(
                            ali_wangwang_str,
                            user.username,
                            '流程'+pipeline.name+'的权限', 
                            CURRENT_URL+'pipeline/permission/%s/' % pipe_id,
                            '审批')
        except Exception, ex:
            logger.error('apply permission fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})


@login_required(login_url='/login/')
@add_visit_record
def accept_permission(request):
    if request.method == 'POST' and request.is_ajax():
        pipe_id = request.POST.get('id')
        applicant_id = request.POST.get('applicant_id')
        operator = request.user
        user_list = []
        user_list.append(int(applicant_id))

        try:
            result = horae_interface.auth_grant_or_apply(\
                    AuthAction.CONFIRM_APPLY_AUTH,'pipeline',
                    int(pipe_id),operator.id,user_list,
                    READ_ONLY,'')
            status,msg = status_msg(result)

        except Exception, ex:
            logger.error('accept permission fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})


@login_required(login_url='/login/')
@add_visit_record
def deny_permission(request):
    if request.method == 'POST' and request.is_ajax():
        reason = request.POST.get('reason')
        pipe_id = request.POST.get('id')
        applicant_id = request.POST.get('applicant_id')
        operator = request.user
        user_list = []
        user_list.append(int(applicant_id))
        try:
            result = horae_interface.auth_grant_or_apply(\
                    AuthAction.REJECT_APPLY_AUTH,'pipeline',
                    int(pipe_id),operator.id,user_list,
                    READ_ONLY,reason)
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('deny permission fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})





#任务管理
@login_required(login_url='/login/')
@add_visit_record
def task_index(request,pipe_id):
    user = request.user
    is_super = is_admin(user)
    pipeline_info = get_pipeline_info(int(pipe_id))
    pipeline = Pipeline.objects.get(id = pipe_id)
    monitor_way = pipeline.monitor_way
    monitor_way_str = monitor_dispaly(monitor_way)

    permission_tag = HAS_NOT_OWNER_PERM
    pipeline_id_list = pipeline_info['principal_id_list']
    if str(user.id) in pipeline_id_list or is_super == 1:
        permission_tag = HAS_OWNER_PERM
    return render(request,'task_index.html',
            {'pipeline':pipeline_info, 'pipe_id':pipe_id, 'page_title':'查看任务', 'pipeline_name':pipeline.name,'permission_tag':permission_tag,
            'monitor_way_str':monitor_way_str,'pipeline_model':1,'page_index':2,'is_super':is_super
})
    
#获取任务详情
def get_task_info(task_id):
    task_info = horae_interface.get_task_info(int(task_id))
    task_info = json.loads(task_info)
    if task_info['status'] == 0:
        task_info = task_info['task']
        return task_info
    else:
        return ''


#获取机器标签
def get_server_tags(request):
    if request.method == 'POST' and request.is_ajax():
        task_type = request.POST.get('task_type')
        server_tags = ''
        try:
            result = horae_interface.get_server_tag(int(task_type))
            result = json.loads(result)
            status = result['status']
            msg = result['info']
            if result.has_key('server_tags'):
                server_tags = result['server_tags']

        except Exception,ex:
            logger.error('get server_tags fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg,'server_tags':server_tags})

def server_tag_db(server_tag):
    if server_tag == '':
        server_tag = 'ALL'
    return server_tag


def retry_count_num(retry_count):
    num = 0
    if retry_count == ONE_TIME:
        num = 1
    elif retry_count == FIVE_TIME:
        num = 5
    elif retry_count == ALWAYS:
        num = -1
    return num

#任务配置参数检查
def is_corrent_config(config):
    res = 0
    config_i = ''
    config = config.strip()
    if config:
        config_arr = config.split('\n')
        if len(config_arr)>1:
            for config_i in config_arr:
                config_i = config_i.strip()
                if config_i.find('=') >= 0:
                    res = 0
                else:
                    res = 1
                    break
        else:
            if config.find('=') >= 0:
                res = 0
            else:
                res = 1
    return res

#odps job任务参数必须有_tpl，且参数值不为空
def odps_job_tpl_check(config):
    res = 0
    count = 0
    config = config.strip()
    config_arr = config.split('\n')
    if len(config_arr) >= 1:
        for config_i in config_arr:
            config_i = config_i.strip()
            if config_i.startswith('_tpl'):
                count += 1
                if config_i.split('=')[1].strip() == '':
                    res = 1
                else:
                    res = 0
    else:
        config_tpl = config.split('=')
        if config_tpl[0] != '_tpl':
            res = 1
        elif config_tpl[1] == '':
            res = 1
        else:
            res = 0
    return res,count


@login_required(login_url='/login/')
@add_visit_record
def create_task(request,pipe_id):
    user = request.user
    is_super = is_admin(user)
    if request.method == 'POST' and request.is_ajax():
        form = TaskForm(request.POST)
        processor = None
        if form.is_valid():
            try:
                type = form.cleaned_data['type']
                name = form.cleaned_data['name']
                use_processor = form.cleaned_data['use_processor']
                processor_id = form.cleaned_data['processor_id']
                config = form.cleaned_data['config']
                template = form.cleaned_data['template']
                retry_count = form.cleaned_data['retry_count']
                over_time = form.cleaned_data['over_time']
                priority = form.cleaned_data['priority']
                prev_task_ids = form.cleaned_data['prev_task_ids']
                description = form.cleaned_data['description']
                server_tag = form.cleaned_data['server_tag']

                now_time = StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                retry_count = retry_count_num(int(retry_count))

                if is_corrent_config(config) == 1:
                    return JsonHttpResponse(
                        {'status':1,'msg':'参数配置key不能为空！'})

                elif type == '2':
                    res,count = odps_job_tpl_check(config)
                    if res == 1 or count == 0:
                        return JsonHttpResponse(
                            {'status':1,'msg':'飞天job配置参数必须含有_tpl，且参数值不为空！'})
                
                if prev_task_ids == 'null':
                    prev_task_ids = ''

                if prev_task_ids == 'null':
                    prev_task_ids = ''

                task = Task(
                        pl_id = int(pipe_id),
                        pid = int(processor_id),
                        next_task_ids = '',
                        prev_task_ids = prev_task_ids,
                        over_time = int(over_time),
                        name = name,
                        config = config,
                        retry_count = retry_count,
                        last_run_time = '',
                        priority = int(priority),
                        except_ret = 0,
                        server_tag = server_tag_db(server_tag),
                        description = description,
                        )

                if not use_processor:
                    processor = Processor(
                            name = 'proc_for_'+name,
                            type = int(type),
                            template = template,
                            update_time = now_time,
                            config = config,
                            owner_id = user.id, 
                            private = 1,
                            ap = 0,
                            )

                tasks = Task.objects.filter(pl_id = pipe_id,name = name)
                if tasks:
                    raise Exception('任务名重复！')

                result = horae_interface.add_new_task_to_pipeline(user.id,task,processor)
                __log.info(result)
                res = json.loads(result)
                status = res['status']
                msg = res['info']
                task = res['task']
            except Exception, ex:
                logger.error('create task fail: <%s>' % str(ex))
                return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})

            return JsonHttpResponse(
                    {'status':status,'msg':msg,'task':task})
        else:
            return JsonHttpResponse({'status':1,'msg':form.errors.items()})
    else:  
        form = TaskForm()
    pipeline = Pipeline.objects.get(id = pipe_id)
    return render(request,'create_task.html',{'form': form,'pipe_id':pipe_id, 'is_super':is_super,'page_title':'创建任务', 
                'pipe_name':pipeline.name,'pipeline_model':1,'page_index':2})


@login_required(login_url='/login/')
@add_visit_record
def update_task(request,task_id):
    user = request.user
    is_super = is_admin(user)
    task = Task.objects.get(id = task_id)
    if request.method == 'POST' and request.is_ajax():
        form = TaskForm(request.POST, instance = task)
        if form.is_valid():
            try:
                name = form.cleaned_data['name']
                config = form.cleaned_data['config']
                retry_count = form.cleaned_data['retry_count']
                over_time = form.cleaned_data['over_time']
                priority = form.cleaned_data['priority']
                prev_task_ids = form.cleaned_data['prev_task_ids']
                server_tag = form.cleaned_data['server_tag']
                description = form.cleaned_data['description']
                proc_template = form.cleaned_data['template']
                if proc_template == 'null':
                    proc_template = None
                
                if is_corrent_config(config) == 1:
                    return JsonHttpResponse(
                        {'status':1,'msg':'参数配置key不能为空！'})

                elif Processor.objects.get(id = task.pid).type == 2:
                    res,count = odps_job_tpl_check(config)
                    if res == 1 or count == 0:
                        return JsonHttpResponse(
                            {'status':1,'msg':'飞天job配置参数必须含有_tpl，且参数值不为空！'})
                task.name = name
                task.config = config
                task.retry_count = retry_count_num(int(retry_count))
                task.over_time = int(over_time)
                task.prev_task_ids = prev_task_ids
                task.description = description
                task.priority = priority
                task.server_tag = server_tag_db(server_tag)

                result = horae_interface.update_tasks(user.id, task, None, proc_template)
                res = json.loads(result)
                status = res['status']
                msg = res['info']
                task = {}
                if res.has_key('task'):
                    task = res['task']
            except Exception, ex:
                logger.error('update task fail: <%s>' % str(ex))
                return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})

            return JsonHttpResponse(
                    {'status':status,'msg':msg,'task':task})
        else:
            return JsonHttpResponse({'status':1,
                    'msg':form.errors.items()})
    else:  
        form = TaskForm(instance = task)
        task_info = get_task_info(task_id)
        pipe_id = task_info['pl_id']
        config = task_info['config']
        config_str = template_list(config)
        processor = get_processor_info(task_info['pid'])

        rely_tasks = ''
        prev_task_ids = task_info['prev_task_ids']
        if prev_task_ids != 'null' and prev_task_ids is not None:
            rely_tasks = get_rely_tasks(prev_task_ids)
            #dict转json串
            rely_tasks = json.dumps(rely_tasks)
        else:
            rely_tasks = json.dumps(rely_tasks)
        server_tag = Task.objects.get(id=int(task_id)).server_tag

        #获取插件上传包
        proc_name = processor['name']
        user = request.user
        username = user.username
        password = '<font color=red>${password}</font>';
        cmd = upload_cmd(request,username,password,proc_name)

    proc_quote_json = horae_interface.get_processor_quote_num(processor['id'])
    result = json.loads(proc_quote_json)
    status = result['status']
    quote_num = 0
    if status == 0:
        quote_num = result['quote_num']

    pipeline = Pipeline.objects.get(id = pipe_id)
    return render(request,'update_task.html',
            {'form': form,'task':task_info,
            'config':config_str,'pipe_id':pipe_id,'pipe_name':pipeline.name,
            'processor':processor,'rely_tasks':rely_tasks,
            'server_tag':server_tag,'cmd':cmd, 'page_title':'修改任务',
            'pipeline_model':1, 'quote_num': quote_num,'page_index':2,
            'is_super':is_super
            })

#获取依赖任务和相应流程list
def get_rely_tasks(prev_task_ids):
    rely_tasks = {}
    prev_task_ids = prev_task_ids.strip()
    prev_task_ids = prev_task_ids.strip(',')
    rely_task_list = prev_task_ids.split(',')
    if len(rely_task_list) > 0 and prev_task_ids != '':
        for task_id in rely_task_list:
            if get_task_info(task_id) != '':
                rely_tasks[task_id] = get_task_info(task_id)['pl_id']
    return rely_tasks


def get_pipelines(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        task_id = request.POST.get("task_id")
        try:
            pipelines = horae_interface.get_all_authed_pipeline_info(user.id, task_id)
            pipeline_list = json.loads(pipelines)['pipelines']

        except Exception, ex:
            logger.error('get pipelines fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':0,'pipeline_list':pipeline_list})
        

def get_processors(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        type = request.POST.get("type")
        config_str = ''
        template = ''
        try:
            processors = horae_interface.get_all_authed_processor(user.id,int(type))
            processor_list = json.loads(processors)['processors']

            #getParams
            if len(processor_list)>0:
                processor_id = processor_list[0]['id']
                processor = horae_interface.get_processor_info(int(processor_id))
                processor = json.loads(processor)['processor']
                template = processor['template']
                config = processor['config']
                config_str = template_list(config)

        except Exception, ex:
            logger.error('get pipelines fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':0,'processor_list':processor_list,\
                'config':config_str,'template':template})


def get_params(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        processor_id = request.POST.get("processor_id")
        config_str = ''
        template = ''
        try:
            processor = horae_interface.get_processor_info(int(processor_id))
            processor = json.loads(processor)['processor']
            template = processor['template']
            config = processor['config']
            config_str = template_list(config)
        except Exception, ex:
            logger.error('get param fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':0,'config':config_str,'template':template})



def get_tasks(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        pipeline_id = request.POST.get("pipeline_id")
        try:
            tasks = horae_interface.get_tasks_by_pipeline_id(int(pipeline_id))
            task_list = json.loads(tasks)['tasks']
        except Exception, ex:
            logger.error('get tasks fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':0,'task_list':task_list})


def link_task(request):
    if request.method == 'POST':
        user = request.user
        link_from  = request.POST.get('Link[from]')
        link_to  = request.POST.get('Link[to]')
        try:
            result = horae_interface.add_edge(user.id,int(link_from),int(link_to))
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('add edge fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})
            

def unlink_task(request):
    if request.method == 'POST':
        user = request.user
        link_from  = request.POST.get('Link[from]')
        link_to  = request.POST.get('Link[to]')
        try:
            result = horae_interface.delete_edge(user.id,int(link_from),int(link_to))
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('delete edge fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})


@login_required(login_url='/login/')
@add_visit_record
def delete_task(request,pipe_id):
    if request.method == 'POST':
        user = request.user
        task_id  = request.POST.get('Task[id]')
        logger.error(task_id)
        try:
            result = horae_interface.delete_task_info(user.id,int(task_id))
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('delete task fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})


@login_required(login_url='/login/')
@add_visit_record
def run_tasks(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        task_id_list = request.POST.get("task_id_list")
        run_time = request.POST.get("run_time")
        ordered_num = 0
        if request.POST.has_key("ordered_num"):
            ordered_num = int(request.POST.get("ordered_num"))
        task_id_list = task_id_list.split(',')
        try:
            result = horae_interface.run_tasks(user.id,task_id_list,run_time, ordered_num)
            status,msg = status_msg(result)
        except Exception,ex:
            logger.error('run task error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})


def get_data_express(request):
    if request.method == 'POST' and request.is_ajax():
        data_id = request.POST.get('data_id')
        data_mode = request.POST.get('data_mode')
        data_offset = request.POST.get('data_offset')
        config = Config.objects.get(id = int(data_id))
        data_mode = int(data_mode)
        res = '%'+config.name+':'
        if data_mode == DATA_MODE_DIR:
            res += 'dir'
        elif data_mode == DATA_MODE_FILE:
            res += 'file'
        elif data_mode == DATA_MODE_PROJECT:
            res += 'project'
        elif data_mode == DATA_MODE_TABLE:
            res += 'table'
        elif data_mode == DATA_MODE_PART:
            res += 'part'
        else:
            return JsonHttpResponse(
                    {'status':1,'msg':'未知数据类型'})
        res += '%'
        if data_offset != '':
            res += '@-'+data_offset
        return JsonHttpResponse(
                {'status':0,'data_express':res})

def get_datas(request):
    if request.method == 'POST' and request.is_ajax():
        data_type = request.POST.get('data_type')
        try:
            result = horae_interface.get_data_info(int(data_type))
            result = json.loads(result)
            data_list = result['data_list']
        except Exception,ex:
            logger.error("get datas failed! <%s>" % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':0,'data_list':data_list})
        


#插件管理processor
@login_required(login_url='/login/')
@add_visit_record
def processor_index(request):
    user = request.user
    is_super = is_admin(user)
    return render(request,'processor_index.html',{'user': user, 'page_title':'插件管理',
                'pipeline_model':1, 'page_index':4,'is_super':is_super})
    
def str_cut(str,cut_len):
    if(len(str)>cut_len):
        str = str[0:cut_len] + "..."
    return str

def processor_list_condition(request):
    condition = {}
    draw = request.POST.get('draw')
    start = request.POST.get('start')
    length = request.POST.get('length')
    
    page_min = int(start)
    page_max = int(start)+int(length)

    type = request.POST.get('columns[1][search][value]')
    name = request.POST.get('columns[2][search][value]')
    #临时占用update_time来支持table搜索
    private = request.POST.get('columns[5][search][value]')
    tag = request.POST.get('columns[4][search][value]')
    desc = request.POST.get('columns[3][search][value]')

    if type != '':
        condition['type'] = '='+type.encode()
    if name != '':
        name.encode()
        condition['name'] = search_equal(name)
    if tag !='':
        tag.encode()
        condition['tag'] = search_equal(tag)
    if desc !='':
        desc.encode()
        condition['description'] = search_equal(desc)
        
    if private == '':
        private = 3
    return condition,int(private),int(draw),page_min,page_max


def processor_type(type):
    type_str = ''
    if type == 1:
        type_str = 'script'
    elif type == 2:
        type_str = 'job'
    elif type == 3:
        type_str = 'odps_sql'
    elif type == 4:
        type_str = 'odps_mr'
    elif type == 5:
        type_str = 'odps_xlib'
    elif type == 6:
        type_str = 'odps_spark'
    return type_str

def private_str(private):
    private_str = ''
    if private == 0:
        private_str = '开放'
    elif private == 1:
        private_str = '私有'
    elif private == 2:
        private_str = '公共'
    return private_str


def custom_processor_table(user,proc_list):

    for proc in proc_list:
        proc['name'] = "<a href='/processor/"+str(proc['id'])+\
                "/'>"+proc['name']+"</a>"
        proc['type'] = processor_type(proc['type'])
        proc['private'] = private_str(proc['private'])
        proc['description'] = "<font title='"+proc['description']+"'>"+ \
            str_cut(proc['description'],CUSTOM_TABLE_CUT)+"</font>"

    return proc_list

def list_processor(request):

    user = request.user
    condition,owner,draw,page_min,page_max = processor_list_condition(request)

    processors = horae_interface.show_processor(owner,user.id,
            page_min,page_max,'quote_num','desc',condition)

    processors = json.loads(processors)
    proc_list = processors['processors']

    no=int(page_min)
    for key in range(len(proc_list)):
        no=no+1
        proc_list[key]['no']=no

    proc_count = processors['count']

    processors_total_count = proc_count
    processors_filter_count = processors_total_count

    result = {"draw":draw,"recordsTotal": processors_total_count,
                "recordsFiltered": processors_filter_count}

    result['data'] = custom_processor_table(user,proc_list)
    return HttpResponse(json.dumps(result), content_type='application/json')


@login_required(login_url='/login/')
@add_visit_record
def create_processor(request):
    user = request.user
    is_super = is_admin(user)
    error = []
    if request.method == 'POST' and request.is_ajax():
        form = ProcessorForm(request.POST)
        if form.is_valid():
            try:
                type = form.cleaned_data['type']
                name = form.cleaned_data['name']
                principal = form.cleaned_data['principal']
                template = form.cleaned_data['template']
                config = form.cleaned_data['config']
                tag = form.cleaned_data['tag']
                description = form.cleaned_data['description']

                now_time = StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")

                processor = Processor(
                        name = name,
                        type = int(type),
                        template = template,
                        update_time = now_time,
                        description = description,
                        config = config,
                        owner_id = user.id, 
                        private = 1,
                        ap = 0,
                        tag = tag,
                        tpl_files = '',
                        )

                processors = Processor.objects.filter(name = name)
                if processors:
                    raise Exception('插件名重复！')

                result = horae_interface.create_processor(processor, principal)
                status,msg = status_msg(result)
            except Exception, ex:
                logger.error('create processor fail: <%s>' % str(ex))
                return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})

            return JsonHttpResponse(
                    {'status':status,'msg':msg})
        else:
            return JsonHttpResponse({'status':1,'msg':form.errors.items()})
    else:  
        form = ProcessorForm()
    return render(request,'create_processor.html',{'form': form, 'page_title':'创建插件',
                    'pipeline_model':1,'page_index':4,'is_super':is_super})


#获取插件详情
def get_processor_info(proc_id):
    processor_info = horae_interface.get_processor_info(int(proc_id))
    processor_info = json.loads(processor_info)
    if processor_info.has_key('processor'):
        processor_info = processor_info['processor']
        return processor_info
    else:
        raise Exception('插件不存在！')
        #return JsonHttpResponse({'status':1,'msg':'插件不存在！'})

def template_list(template):
    template_str = ''
    if template != '' and template is not None:
        templates = template.split('\n')
        for temp in templates:
            if temp:
                template_str += temp.strip() + '\n'
    template_str = template_str.strip()
    return template_str


@login_required(login_url='/login/')
@add_visit_record
def update_processor(request,processor_id):
    processor = Processor.objects.get(id=processor_id)
    user = request.user
    is_super = is_admin(user)
    if request.method == 'POST' and request.is_ajax():
        form = ProcessorForm(request.POST, instance = processor)
        if form.is_valid():
            try:
                type = form.cleaned_data['type']
                name = form.cleaned_data['name']
                template = form.cleaned_data['template']
                principal = form.cleaned_data['principal']
                config = form.cleaned_data['config']
                tag = form.cleaned_data['tag']
                description = form.cleaned_data['description']
                now_time = StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")

                processors = Processor.objects.filter(name = name)
                if processors:
                    if not processor in processors:
                        raise Exception('插件名重复！')

                processor.name = name
                processor.type = int(type)
                processor.template = template
                processor.update_time = now_time
                processor.description = description
                processor.config = config
                processor.tag = tag

                result = horae_interface.update_processor(int(user.id), processor, principal)
                status,msg = status_msg(result)
            except Exception, ex:
                logger.error('update processor fail: <%s>' % str(ex))
                return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})

            return JsonHttpResponse(
                    {'status':status,'msg':msg})
        else:
            return JsonHttpResponse({'status':1,
                    'msg':form.errors.items()})
    else:
        form = ProcessorForm(instance = processor)
        processor_info = get_processor_info(processor_id)
        config = processor_info['config']
        config_str = template_list(config)
        
    return render(request,'update_processor.html',
            {'form': form,'processor':processor_info,
            'config_str':config_str, 'page_title':'修改插件','pipeline_model':1,
            'page_index':4,'is_super':is_super
            })


@login_required(login_url='/login/')
@add_visit_record
def delete_processor(request,proc_id):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        processor = Processor.objects.get(id=proc_id)
        try:
            result = horae_interface.delete_processor(int(proc_id))
            status,msg = status_msg(result)
        except Exception, ex:
            logger.error('delete processor fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        logger.info('delete processor : %s' % processor.name)
        return JsonHttpResponse({'status':status,'msg':msg})


@login_required(login_url='/login/')
@add_visit_record
def processor_detail(request,proc_id):
    user = request.user
    is_super = is_admin(user)
    processor_info = get_processor_info(proc_id)
    type = processor_info['type']
    private = processor_info['private']
    private_desc = ''
    type_str = ''
    is_owner = 0
    is_super = is_admin(user)
    owner_name = User.objects.get(id=processor_info['owner_id']).username
    
    type_str = processor_type(type)
    private_desc = private_str(private)
    if user.id == processor_info['owner_id'] or is_super == 1:
        is_owner = 1

    config = processor_info['config']
    config_str = template_list(config)
    return render(request,'processor_detail.html',
            {'processor': processor_info,
            'type_str':type_str,'private_str':private_desc,
            'is_owner':is_owner,'config_str':config_str,'is_super':is_super,
            'owner_name':owner_name, 'page_title':'插件详情','pipeline_model':1,
            'page_index':4
            })

def public_processor(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        proc_id = request.POST.get("id")
        try:
            result = horae_interface.public_processor(int(proc_id))
            status,msg = status_msg(result)

            #发布插件时，给管理员发旺旺通知
            stdout, stderr, retcode = \
                    ali_wangwang.WangWang.send_message(
                    'ark_admin',
                    user.username, 
                    '插件发布上线',
                    CURRENT_URL+'processor/%s' % proc_id,
                    '查看')

        except Exception, ex:
            logger.error('public processor fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse({'status':status,'msg':msg})


#获取上传包历史
def get_processor_upload_history(proc_id):
    result = horae_interface.get_processor_package_history(proc_id)
    result = json.loads(result)
    history_list = result['package_historys']
    return history_list


#浏览历史，画图表
@login_required(login_url='/login/')
@add_visit_record
def view_processor_history(request,proc_id):
    if request.method == 'POST' and request.is_ajax():
        try:
            history_list = get_processor_upload_history(int(proc_id))
        except Exception, ex:
            logger.error('view history fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'获取成功','history_list':history_list})


#获取引用
def get_processor_quote_list(proc_id):
    result = horae_interface.get_processor_quote_list(proc_id)
    result = json.loads(result)
    quote_list = result['quote_list']
    return quote_list



#引用信息
@login_required(login_url='/login/')
@add_visit_record
def view_quote(request,proc_id):
    if request.method == 'POST' and request.is_ajax():
        try:
            quote_list = get_processor_quote_list(int(proc_id))
        except Exception, ex:
            logger.error('view quote fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'获取成功','quote_list':quote_list})

#回滚
def reback(request,hist_id):
    if request.method == 'POST' and request.is_ajax():
        try:
            result = horae_interface.use_processor_package(int(hist_id))
            status,msg = status_msg(result)
        except Exception,ex:
            logger.error('reback processor fail:<%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':msg})



#API接口
#获取访问者ip地址
def get_client_ip(request):
    '''
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
    '''

    ip = request.META['REMOTE_ADDR']
    return ip

def upload_cmd(request,username,password,proc_name):
    cmd = ''
    cmd += 'curl "http://'+request.get_host() + '/api/pipeline/uploadProcessor/"'+\
           ' -F "user='+username+'" -F "pass='+password+'" -F "proc='+\
            proc_name+'" -F "tpl1=@<font color=red>${template_name1}</font>"'+\
            ' -F "tpl2=@<font color=red>${template_name2}</font>"'+\
            ' -F "package=@<font color=red>${package_name}</font>"'+\
            ' -F "overwrite=<font color=red>0</font>"'+\
            ' -F "description=<font color=red>${description}</font>"';
    return cmd


#获取上传包命令
def get_upload_cmd(request):
    if request.method == 'POST' and request.is_ajax():
        proc_name = request.POST.get("proc_name")
        user = request.user
        username = user.username
        password = '<font color=red>${password}</font>';
        cmd = upload_cmd(request,username,password,proc_name)
        return JsonHttpResponse({'cmd':cmd})


#下次上传前删除upload_files中的文件
def delete_upload_files(proc_id):
    cmd = "rm -rf %s" % (WORK_PATH + proc_id)
    stdout, stderr, retcode = __no_block_cmd.run_once(cmd)
    if retcode != 0:
        return False

def upload_processor(request):
    if request.method == 'POST':
        #delete_upload_files(str(processor[0].id))
        user_name = request.POST.get('user')
        
        #兼容
        #user = User.objects.get(username = user_name)
        status = 0
        msg = ''

        password = request.POST.get('pass')
        proc_name = request.POST.get('proc')
        description = request.POST.get('description')
        overwrite = False
        try:
            ow = request.POST.get('overwrite')
            if int(ow) != 0:
                overwrite = True
        except Exception as ex:
            overwrite = False
        #判断proc_name是否存在
        if proc_name != '':
            processor = Processor.objects.filter(
                    name=proc_name)
            if len(processor) == 0:
                return JsonHttpResponse(
                    {'status':1,'msg':'can not find processor.'})

        #判断用户密码是否正确
        user = authenticate(username=user_name,password=password)
        if user is None:
            return JsonHttpResponse(
                {'status':1,'msg':'The username and password were incorrect.'})
            
        try:
            for key in request.FILES:
                if key.startswith('tpl'):
                    tpl = request.FILES[key]
                    handle_uploaded_file(tpl,processor[0].id,0)
                elif key == 'package':
                    package = request.FILES[key]
                    handle_uploaded_file(package,processor[0].id,1)
                else:
                    return JsonHttpResponse(
                        {'status':1,'msg':'key is wrong!'})

            result = horae_interface.upload_pacakge(processor[0].id,user.id,\
                    WORK_PATH+str(processor[0].id)+'/', description, overwrite)
            status,msg = status_msg(result)
            #调完接口，删除临时文件
            if status == 0:
                delete_upload_files(str(processor[0].id))

        except Exception,ex:
            logger.error('upload processor package fail:<%s>' % str(ex))
            return JsonHttpResponse(
                {'status':status,'msg':'error:' + str(ex)})
        return JsonHttpResponse({"status":status,"msg":msg})
    else:
        return render_to_response('test.html',{"status":1,"msg":"hello..."})


#上传文件
def handle_uploaded_file(file,proc_id,is_package):
    file_name = ""
    try:
        path = UPLOAD_FILES_PATH + str(proc_id)+'/'
        if not os.path.exists(path):
            os.makedirs(path)
        file_name = path + file.name
        destination = open(file_name, 'wb+')
        for chunk in file.chunks():
            destination.write(chunk)
        destination.close()

        #mv package 成 proc_id.tar.gz
        if proc_id and is_package == 1:
            cmd = "mv %s %s.tar.gz" % (WORK_PATH + str(proc_id) +'/'+ file.name,\
                    WORK_PATH+str(proc_id)+'/'+str(proc_id))
            stdout, stderr, retcode = __no_block_cmd.run_once(cmd)
            if retcode != 0:
                return False
            
    except Exception, e:
        print e

    return file_name


#执行历史
@login_required(login_url='/login/')
@add_visit_record
def history(request):
    user = request.user
    is_super = is_admin(user)
    status=request.GET.get('status')
    runtime=request.GET.get('runtime')   
    
    pl_name=request.GET.get('pl_name')
    task_name=request.GET.get('task_name') 
    if status=="success":
       return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':'','status':'2','runtime':runtime,'pipeline_model':1,'page_index':3})
    elif status=="fail":
       return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':'','status':'3','runtime':runtime,'pipeline_model':1,'page_index':3})
    elif pl_name:
         return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':pl_name,'taskname':task_name,'status':'','runtime':runtime,'pipeline_model':1,'page_index':3})
    else:
       return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':'','status':'','runtime':'','pipeline_model':1,'page_index':3})



@login_required(login_url='/login/')
@add_visit_record
def historypipe(request,pipe_id):
    user = request.user
    is_super = is_admin(user)
    pipeline = Pipeline.objects.get(id = pipe_id)
    pipe_name = '=%s' % pipeline.name
    return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':pipe_name,'status':'','runtime':'','pipeline_model':1,'page_index':3})


@login_required(login_url='/login/')
@add_visit_record
def historypipe_by_name(request,pipe_name):
    user = request.user
    is_super = is_admin(user)
    return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':pipe_name,'status':'','runtime':'','pipeline_model':1,'page_index':3})

@login_required(login_url='/login/')
@add_visit_record
def historystatus(request,status):
    user = request.user
    is_super = is_admin(user)
    if status=="success":
       return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':'','status':'2','pipeline_model':1,'page_index':3})
    if status=="fail":
       return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':'','status':'3','pipeline_model':1,'page_index':3})
    if status=="stop":
       return render(request,'pipeline_history.html',{'is_super':is_super,'page_title':'执行历史', 'user': user,'pipename':'','status':'6','pipeline_model':1,'page_index':3})

#自动pipeline测试
def auto_pipeline(request,argv):
    client_address = get_client_ip(request)
    result = horae_interface.auto_pipeline_command(argv,client_address)
    return JsonHttpResponse(result)

def auto_post_pipeline(request):
    if request.method == 'POST':
        client_address = get_client_ip(request)
        req_package = request.POST.get('req_pkg')
        result = horae_interface.auto_pipeline_command(
                req_package, 
                client_address)
        return JsonHttpResponse(result)

def list_history_condition(request):
    condition = {}

    draw = request.POST.get('draw')
    #分页
    start = request.POST.get('start')
    length = request.POST.get('length')
    page_min = int(start)
    page_max = int(start)+int(length)

    #搜索条件
    '''
   start_time = request.POST.get('columns[0][search][value]');             #开始时间
    end_time = request.POST.get('etime')                #结束时间
    pipeline_name = request.POST.get('pipeline_name')   #流程名
    task_name = request.POST.get('task_name')           #任务名
    status = request.POST.get('status')                 #状态
    '''
    
    run_time = request.POST.get('columns[1][search][value]')
    pl_name = request.POST.get('columns[2][search][value]')
    task_name = request.POST.get('columns[3][search][value]')
    status = request.POST.get('columns[4][search][value]')
    start_time = request.POST.get('columns[5][search][value]')
    if run_time != '':
        run_time.encode()
        condition['run_time'] = search_equal(run_time)
    if pl_name != '':
        pl_name.encode()
        condition['pl_name'] = search_equal(pl_name)
    if task_name != '':
        task_name.encode()
        condition['task_name'] = search_equal(task_name)
    if status != '':
        condition['status']=status
    if start_time !='' : 
        start_time.encode()
        condition['start_time']=search_equal(start_time)
    return condition,int(draw),page_min,page_max

@login_required(login_url='/login/')
@add_visit_record
def history_list(request, order_info):
    
    user = request.user
    condition,draw,page_min,page_max = list_history_condition(request)
    order_name = 'start_time'
    order_tag_list = order_info.split('_')
    order_tag = int(order_tag_list[0])
    if order_tag == 0:
        order_name = 'run_time'
    elif order_tag == 1:
        order_name = 'pl_name'
    elif order_tag == 2:
        order_name = 'task_name'
    elif order_tag == 3:
        order_name = 'status'
    else:
        order_name = 'start_time'

    desc = int(order_tag_list[1])
    desc_name = "desc"
    if desc == 0:
        desc_name = "asc"

    pipelines = horae_interface.show_run_history(0,user.id,page_min,page_max,order_name,desc_name,condition)
#    pipelines = horae_interface.show_run_history_task(user.id,
#            page_min,page_max,'update_time','desc',condition)

    pipelines = json.loads(pipelines)
    pipe_list = pipelines["runhistory_list"]
    pipe_count = pipelines["count"]

    pipeline_total_count = pipe_count
    pipeline_filter_count = pipeline_total_count

    result = {"draw":draw,"recordsTotal": pipeline_total_count,
                "recordsFiltered": pipeline_filter_count}

    result['data'] = pipe_list

    return HttpResponse(json.dumps(result), content_type='application/json')

def pipeline_history(request):
    condition = {}
    draw = request.POST.get('draw')
    start = request.POST.get('start')
    length = request.POST.get('length')
    page_min = int(start)
    page_max = int(start)+int(length)
    run_time = request.POST.get('columns[0][search][value]')
    pl_name = request.POST.get('columns[1][search][value]')
    status = request.POST.get('columns[2][search][value]')
    start_time = request.POST.get('columns[3][search][value]')
    if run_time != '':
        run_time.encode()
        condition['run_time']=search_equal(run_time)
    if pl_name != '':
        pl_name.encode()
        condition['pl_name'] = search_equal(pl_name)
    if status != '':
        condition['status']=status
    if start_time !='':
        start_time.encode()
        condition['start_time'] = search_equal(start_time)
    return condition,int(draw),page_min,page_max

@login_required(login_url='/login/')
@add_visit_record
def pipeline_list(request):
    user=request.user
    condition,draw,page_min,page_max = pipeline_history(request)
    
    pipelineTask = horae_interface.show_run_history(1,user.id,
            page_min,page_max,'start_time','desc',condition)

    pipelineTask = json.loads(pipelineTask)
    proc_list = pipelineTask['runhistory_list']
    proc_count =pipelineTask['count']

    pipelineTask_total_count = proc_count
    pipelineTask_filter_count = pipelineTask_total_count

    result = {"draw":draw,"recordsTotal": pipelineTask_total_count,
                "recordsFiltered": pipelineTask_filter_count}

    result['data'] = proc_list

    return HttpResponse(json.dumps(result), content_type='application/json')


@login_required(login_url='/login/')
@add_visit_record
def get_task_information(request,id):
    user = request.user
    is_super = is_admin(user)
    run_log=horae_interface.get_run_history_info(id)
    run_log=json.loads(run_log)
    result=run_log['runhistory']
    return render(request,'pipeline_log.html',{'is_super':is_super,'page_title':'查看日志', 'user': user,'log':result,'pipeline_model':1,'page_index':3})

@login_required(login_url='/login')
@add_visit_record
def getOneTask(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        task_id_list = request.POST.get("task_id_list")
        run_time = request.POST.get("run_time")
        task_id_list= task_id_list.split(',')
        try:
            result = horae_interface.run_tasks(user.id,task_id_list,run_time)
            result=json.loads(result)
            status=result['status']
            info=result['info']
        except Exception,ex:
            logger.error('run tasks error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':info})


@login_required(login_url='/login/')
@add_visit_record
def run_all_pipeline(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        pl_id_list = request.POST.get("pl_id_list")
        run_time = request.POST.get("run_time")
        try:
            result = horae_interface.run_pipeline(user.id,pl_id_list,run_time)
            result=json.loads(result)
            status=result['status']
            info=result['info']
        except Exception,ex:
            logger.error('run pipeline error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':info})


@login_required(login_url='/login/')
@add_visit_record
def run_all_task(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        task_id_list = request.POST.get("task_id_list")
        run_time = request.POST.get("run_time")
        try:
            result = horae_interface.run_task_with_all_successors(user.id,task_id_list,run_time)
            result=json.loads(result)
            status=result['status']
            info=result['info']
        except Exception,ex:
            logger.error('run task error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':info})



@login_required(login_url='/login/')
@add_visit_record
def get_all_log_list(request):
    if request.method=="POST" and request.is_ajax():
        user=request.user
        schedule_id=request.POST.get('schedule_id')
        subpath=request.POST.get('subpath');
        list_log_arr=[]
        try:    
            list=horae_interface.get_task_run_logs(int(schedule_id),subpath)
            list=json.loads(list)
            list_log=list['log_file_list']
            list_log_arr=list_log.split('\n')
            stat=list['status']
            info=list['info']
        except Exception,ex:
            logger.error('get log list error:<%s>'%str(ex))
            return JsonHttpResponse({'list':"error"})
        return JsonHttpResponse({'list':list_log_arr,'status':stat,'info':info})


@login_required(login_url='/login/')
@add_visit_record
def get_log_content(request):
     if request.method == 'POST' and request.is_ajax():
        user = request.user
        schedule_id = request.POST.get("schedule_id")
        file_name=request.POST.get('file_name')
        try:
            log_content=horae_interface.get_task_log_content(schedule_id,file_name,0,10240)
            return JsonHttpResponse({'file_content':log_content,'status':0, 'len':len(log_content)})
        except Exception, ex:
            logger.error('get log content fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'filecontent':""})
@login_required(login_url='/login/')
@add_visit_record
def get_all_log_content(request):
     if request.method == 'POST' and request.is_ajax():
        user = request.user
        schedule_id = request.POST.get("schedule_id")
        file_name=request.POST.get('file_name')
        index=0
        try:
            log_content=horae_interface.get_task_log_content(schedule_id,file_name,0+10240*index,10240)
            log_content=json.loads(log_content);
            status=log_content['status']
            if status==0:
                 file_content=log_content['file_content']
                 while len(file_content)>=10240+10240*index:
                     index=index+1
                     log_content=horae_interface.get_task_log_content(schedule_id,file_name,0+10240*index,10240)
                     log_content=json.loads(log_content);
                     file_content=file_content+log_content['file_content']
                 return JsonHttpResponse({'file_content':file_content,'status':status, 'len':len(file_content)})
            if status==1:
                 info=log_content['info']
                 return JsonHttpResponse({'status':status,'info':info})
        except Exception, ex:
            logger.error('get log content fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'filecontent':""})
  


@login_required(login_url='/login/')
@add_visit_record
def getmessage(request):
     if request.method == 'POST' and request.is_ajax():
        user = request.user
        taskid=request.POST.get('taskid')
        run_time=request.POST.get('run_time')
        try:
            message=horae_interface.get_task_run_status_info(taskid,run_time)
            message=json.loads(message)
            previnfo=message['prev_info']
            info=message['info']
            boolcheck=0
            if previnfo:
                boolcheck=1
        except Exception, ex:
            logger.error('get prev_info fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'prev':"error"})
        return JsonHttpResponse({'prev':previnfo,'infomessage':info,'check':boolcheck})


@login_required(login_url='/login/')
@add_visit_record
def runsometask(request):
     if request.method == 'POST' and request.is_ajax():
        user = request.user
        task_id_list = request.POST.get("tasklist")
        run_time=request.POST.get('runtimelist')
        task_id_list = task_id_list.split(',')
        run_time=run_time.split(',')
        task_pair_list=[]
        for index in range(len(task_id_list)):
           tub=(task_id_list[index],run_time[index])
           task_pair_list.append(tub)
        try:
            result = horae_interface.run_one_by_one_task(user.id,task_pair_list)
            result=json.loads(result)
            status=result['status']
            info=result['info']
        except Exception,ex:
            logger.error('run some tasks error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':info})


def pipelineTaskListData(request):
    draw = request.POST.get('draw')
    #分页
    start = request.POST.get('start')
    length = request.POST.get('length')
    page_min = int(start)
    page_max = int(start)+int(length)
    pl_id=request.POST.get('pl_id')
    run_time=request.POST.get('run_time')
    return pl_id,run_time,int(draw),page_min,page_max

@login_required(login_url='/login/')
@add_visit_record
def pipelineTaskList(request):
    user = request.user
    pl_id,run_time,draw,page_min,page_max =pipelineTaskListData(request)
    tasks = horae_interface.get_task_history_by_pipe(pl_id,run_time)
    tasks = json.loads(tasks)
    task_list = tasks["runhistory_list"]
    task_count =10

    task_total_count = task_count
    task_filter_count = task_total_count

    result = {"draw":draw,"recordsTotal": task_total_count,
                "recordsFiltered": task_filter_count}

    result['data'] = task_list

    return HttpResponse(json.dumps(result), content_type='application/json')

@login_required(login_url='/login/')
@add_visit_record
def stoptask(request):
     if request.method == 'POST' and request.is_ajax():
        user = request.user
        task_id = request.POST.get("task_id")
        run_time=request.POST.get('run_time')
        try:
            result = horae_interface.stop_task(user.id,task_id,run_time)
            result=json.loads(result)
            status=result['status']
        except Exception,ex:
            logger.error('run some tasks error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':status,'msg':result['info']})

@login_required(login_url='/login/')
@add_visit_record
def gettaskphoto(request):
    user=request.user
    is_super = is_admin(user)
    pl_id=request.GET.get('pl_id')
    run_time=request.GET.get('runtime')
    task_name=request.GET.get('taskname')
    return render(request,'pipeline_taskphoto.html',{'is_super':is_super,'page_title':'任务执行历史', 'user': user,'pipelineid':pl_id,
                  'runtime':run_time,'task_name':task_name,'pipeline_model':1,'page_index':3
})


@login_required(login_url='/login/')
@add_visit_record
def gethistory(request,pl_name):
    user=request.user
    is_super = is_admin(user)
    return render(request,'pipeline_task_history.html',{'is_super':is_super,'page_title':'历史状态统计', 'user': user,
                    'plname':pl_name,'pipeline_model':1,'page_index':3})

@login_required(login_url='/login/')
@add_visit_record
def getdata(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        starttime = request.POST.get("starttime")
        lasttime=request.POST.get('lasttime')
        seacher=[('run_time',">="+starttime),('run_time',"<="+lasttime)]
        try:
            result = horae_interface.show_run_history(0,user.id,0,20,"run_time","asc",{},seacher)
            history=json.loads(result)
        except Exception,ex:
            logger.error('get history  error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':history['runhistory_list']})

@login_required(login_url='/login/')
@add_visit_record
def getplhistory(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        plname=request.POST.get('plname')
        seacher={'pl_name':plname}
        try:
            result = horae_interface.show_run_history(0,user.id,0,20,"run_time","asc",seacher)
            history=json.loads(result)
        except Exception,ex:
            logger.error('get history  error:<%s>' % str(ex))
            return JsonHttpResponse(
                    {'status':1,'msg':str(ex)})
        return JsonHttpResponse(
                {'status':history['runhistory_list']})
 



@login_required(login_url='/login/')
@add_visit_record
def getgraph(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       pipe_id=request.POST.get('pipe_id')
       run_time=request.POST.get('run_time')
       try:
           result = horae_interface.run_history_show_graph(pipe_id,run_time)
           history=json.loads(result)
           list=history['runhistory_list'] 
           for li in list:
              li['id']=li['task_id']
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg':str(ex)})
       return JsonHttpResponse({'res':list})



@login_required(login_url='/login/')
@add_visit_record
def gettail(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       schedule_id=request.POST.get('schedule_id')
       filename=request.POST.get('file_name')
       try:
           result = horae_interface.get_log_content_tail(schedule_id,filename)
           history=json.loads(result)
           list=history['file_content']
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg':str(ex)})
       return JsonHttpResponse({'res':list})

@login_required(login_url='/login/')
@add_visit_record
def copy_pipeline(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       pl_id = request.POST.get('pl_id')
       pl_name = request.POST.get('pl_name')
       project_id = request.POST.get('project_id')
       try:
           result = horae_interface.copy_pipeline(
                int(user.id), 
                int(pl_id), 
                pl_name, 
                int(project_id))
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res["info"]})
           return JsonHttpResponse({'status':0, 'msg': "OK", 'pl_id':res["pl_id"]})
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': str(ex)})
 
@login_required(login_url='/login/')
@add_visit_record
def copy_task(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       task_id = request.POST.get('task_id')
       dest_pl_id = request.POST.get('dest_pl_id')
       try:
           result = horae_interface.copy_task(user.id, task_id, dest_pl_id)
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res["info"]})
           return JsonHttpResponse({'status':0, 'msg': "OK", 'data':res["task"]})
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': str(ex)})
            
@login_required(login_url='/login/')
@add_visit_record
def get_project(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       tag = int(request.POST.get('tag'))

       try:
           result = horae_interface.get_project_list(int(user.id), tag)
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res["info"]})
           return JsonHttpResponse({'status':0, 'msg': "OK", 'project_list':res["projects"]})
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': str(ex)})

from django.http import StreamingHttpResponse
 
 
def file_iterator(schedule_id, file_name, chunk_size=512):
    try:
        index=0
        downed_len = 0
        while True:
            log_content=horae_interface.get_task_log_content(
                    schedule_id, file_name, downed_len, 1024 * 1024)
            try:
                res = json.loads(log_content)
                if res["status"] != 0:
                    break;
            except:
                pass

            index += 1
            content_len = len(log_content)
            downed_len += content_len

            if content_len <= 0:
                break
            yield log_content

            if index > 1024:
                break
    except Exception as ex:
        yield str(ex)
 
@login_required(login_url='/login/')
@add_visit_record
def big_file_download(request, args):
    # do something...
    arg_list = args.split('&')
    schedule_id = arg_list[0]
    file_name = arg_list[1]
    down_load_name = file_name.split('/')[-1]

    response = StreamingHttpResponse(file_iterator(int(schedule_id), file_name))
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Disposition'] = 'attachment;filename="{0}"'.format(down_load_name)
    return response

@login_required(login_url='/login/')
@add_visit_record
def console_index(request):
    user = request.user
    is_super = is_admin(user)
    try:
        #获取用户列表，用于user id到username映射
        all_users = horae_interface.get_all_user_info()
        all_users = json.loads(all_users)
        all_users = all_users['users']

        #获取有权限的项目列表
        res_projects_authed = horae_interface.get_project_list(user.id, 0)
        res_projects_authed = json.loads(res_projects_authed)
        if res_projects_authed['status'] == 0:
            project_list_authed = res_projects_authed['projects']
            for key in range(len(project_list_authed)):
                owner_name = ''
                for user_item in all_users:
                    if user_item['id'] == project_list_authed[key]['owner_id']:
                        owner_name = user_item['username']
                project_list_authed[key]['owner_name'] = owner_name
                if project_list_authed[key]['writer_list'] != '':
                    project_list_authed[key]['writer_num'] = len(project_list_authed[key]['writer_list'].split(','))
                    project_list_authed[key]['writer_arr'] = project_list_authed[key]['writer_list'].split(',')
                else:
                    project_list_authed[key]['writer_num'] = 0
                    project_list_authed[key]['writer_arr'] = 0
        else:
            project_list_authed = []

        #获取所有项目列表
        res_projects_all = horae_interface.get_project_list(user.id, 1)
        res_projects_all = json.loads(res_projects_all)
        if res_projects_all['status'] == 0:
            project_list_all = res_projects_all['projects']
            for key in range(len(project_list_all)):
                owner_name = ''
                for user_item in all_users:
                    if user_item['id'] == project_list_all[key]['owner_id']:
                        owner_name = user_item['username']
                project_list_all[key]['owner_name'] = owner_name
                if project_list_all[key]['writer_list'] != '':
                    project_list_all[key]['writer_num'] = len(project_list_all[key]['writer_list'].split(','))
                    project_list_all[key]['writer_arr'] = project_list_all[key]['writer_list'].split(',')
                else:
                    project_list_all[key]['writer_num'] = 0
                    project_list_all[key]['writer_arr'] = 0
        else:
            project_list_all = []

        #获取用户列表
        all_users = horae_interface.get_all_user_info()
        all_users = json.loads(all_users)
        all_users = all_users['users']

        user_list = []
        for user_item in all_users:
            user_list.append({'id': user_item['id'], 'name': user_item['username']})

    except Exception, ex:
        __log.info(traceback.format_exc())
        logger.error('get project list failed: <%s>' % str(ex))
        return JsonHttpResponse(
            {'status':1,'msg':'获取项目列表失败'})

    return render(request,'console_index.html',{'user': user,
            'is_super':is_super, 'page_title':'控制面板',
            'pipeline_model':1,'project_list_authed':project_list_authed,
            'project_list_all':project_list_all,'user_list':user_list,
            'page_index':5
            })

@login_required(login_url='/login/')
@add_visit_record
def add_new_project(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       project_name = request.POST.get('project_name')
       description = request.POST.get('description')
       try:
           result = horae_interface.add_new_project(user.id, project_name, '', description)
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res['info']})
           return JsonHttpResponse({'status':0, 'msg': "OK"})
       except Exception,ex:
           logger.error('create project failed:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': "创建项目失败"})
 
@login_required(login_url='/login/')
@add_visit_record
def update_project(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       project_id = request.POST.get('project_id')
       project_name = request.POST.get('project_name')
       description = request.POST.get('description')
       writer_list = request.POST.get('writer_list', '')
       #writer_list = ','.join(writer_arr)
       try:
           result = horae_interface.update_project(user.id, int(project_id), project_name, writer_list, description)
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res['info']})
           return JsonHttpResponse({'status':0, 'msg': "OK"})
       except Exception,ex:
           logger.error('create project failed:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': "修改项目失败"})
 
@login_required(login_url='/login/')
@add_visit_record
def delete_project(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       project_id = request.POST.get('project_id')
       try:
           result = horae_interface.delete_project(user.id, int(project_id))
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res['info']})
           return JsonHttpResponse({'status':0, 'msg': "OK"})
       except Exception,ex:
           logger.error('create project failed:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': "删除项目失败"})
 
def filter_default_project(ori_project_list, user_id):
    ret = ori_project_list[:]
    for i in range(len(ori_project_list)):
        if ori_project_list[i]['is_default'] == 1 and ori_project_list[i]['owner_id'] == user_id:
            ret.pop(i)
    return ret

@login_required(login_url='/login/')
@add_visit_record
def new_pipeline_by_proc(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       proc_id = request.POST.get('proc_id')
       pl_name = request.POST.get('pl_name')
       project_id = request.POST.get('project_id')
       try:
           result = horae_interface.new_pipeline_by_proc(
                int(user.id), 
                int(proc_id), 
                pl_name, 
                int(project_id))
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res["info"]})
           return JsonHttpResponse({'status':0, 'msg': "OK", 'pl_id':res["pl_id"]})
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': str(ex)})

@login_required(login_url='/login/')
@add_visit_record
def new_task_by_proc(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       proc_id = request.POST.get('proc_id')
       dest_pl_id = request.POST.get('dest_pl_id')
       try:
           result = horae_interface.new_task_by_proc(user.id, proc_id, dest_pl_id)
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res["info"]})
           return JsonHttpResponse({'status':0, 'msg': "OK", 'data':res["task"]})
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': str(ex)})

@login_required(login_url='/login/')
@add_visit_record
def get_task_next_tasks(request):
    if request.method == 'POST' and request.is_ajax():
       user = request.user
       task_id = request.POST.get('task_id')
       try:
           result = horae_interface.get_task_next_tasks(task_id)
           res = json.loads(result)
           if int(res["status"]) != 0:
               return JsonHttpResponse({'status':1,'msg': res["info"]})
           return JsonHttpResponse({'status':0, 'msg': "OK", 'tasks':res["tasks"]})
       except Exception,ex:
           logger.error('get graph  error:<%s>' % str(ex))
           return JsonHttpResponse({'status':1,'msg': str(ex)})


