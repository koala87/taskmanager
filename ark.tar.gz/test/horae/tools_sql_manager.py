﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
node相关db操作

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import exceptions
import time
import traceback
import logging
import random
import copy

import enum
import django.db
import horae.models
import django.db.models
import django.core.exceptions
import django.contrib.auth.models
import common.models
import dms.models
from common.ark_perm import is_admin

import tools_util
import common_logger
import graph_manager

class ConstantSql(enum.Enum):
    SHOW_PIPELINE_INFO_ALL = (
        	"   select a1.id, a1.name, a1.update_time, a1.enable, a1.tag, "
            "   a1.ct_time, a1.private, b1.username, "
            "   a1.owner_id, a1.project_id "
            "   from( "
	        "       select id, name, update_time, enable, tag, ct_time, "
            "       private, owner_id, project_id "
	        "       from horae_pipeline "
	        "       where type = 0 %s "
            "       order by %s %s limit %s, %s "
            "   )a1 "
            "   left outer join ( "
            "       select id, username from auth_user)b1 "
            "   on a1.owner_id = b1.id ")

    SHOW_OWNER_PIPELINE_INFO = (
        	"   select a1.id, a1.name, a1.update_time, a1.enable, a1.tag, "
            "   a1.ct_time, {0} as private, b1.username, a1.owner_id, "
            "   a1.project_id "
            "   from( "
	        "       select id, name, update_time, enable, tag, "
            "       ct_time, owner_id, project_id "
	        "       from horae_pipeline "
	        "       where owner_id = %s and type = 0 %s "
            "       order by %s %s limit %s, %s "
            "   )a1 "
            "   left outer join ( "
            "       select id, username from auth_user)b1 "
            "   on a1.owner_id = b1.id ".format(
            tools_util.UserPermissionType.WRITE))

    SHOW_AUTH_PIPELINE_INFO = (
        	"   select a1.id, a1.name, a1.update_time, a1.enable, a1.tag, "
            "   a1.ct_time, a1.private, b1.username, a1.owner_id, "
            "   a1.project_id "
            "   from( "
            "       select id, name, update_time, enable, tag, ct_time, "
            "       private, owner_id, project_id "
            "       from horae_pipeline where owner_id != %s "
            "       and type = 0 and id "
            "       in(%s) %s order by %s %s limit %s, %s "
            "   )a1 "
            "   left outer join ( "
            "       select id, username from auth_user)b1 "
            "   on a1.owner_id = b1.id ")

    SHOW_NO_AUTH_PIPELINE_INFO = (
        	"   select a1.id, a1.name, a1.update_time, a1.enable, a1.tag, "
            "   a1.ct_time, {0} as private, b1.username, a1.owner_id, "
            "   a1.project_id "
            "   from( "
            "       select id, name, update_time, enable, tag, ct_time, "
            "       private, owner_id, project_id "
            "       from horae_pipeline where owner_id != %s "
            "       and type = 0 and id "
            "       not in(%s) %s order by %s %s limit %s, %s "
            "   )a1 "
            "   left outer join ( "
            "       select id, username from auth_user)b1 "
            "   on a1.owner_id = b1.id ".format(
            tools_util.UserPermissionType.NO_AUTH))


    SHOW_ALL_PIPELINE_INFO_ALL_COUNT = (
	        "select count(id) from horae_pipeline "
	        "where type = 0 %s;")

    SHOW_OWNER_PIPELINE_INFO_ALL_COUNT = (
	        "select count(id) from horae_pipeline "
	        "where owner_id = %s and type = 0 %s;")

    SHOW_AUTH_PIPELINE_INFO_COUNT = (
            "select count(id) from horae_pipeline where owner_id != %s "
            "and type = 0 and id in(%s) %s; ")

    SHOW_NO_AUTH_PIPELINE_INFO_COUNT = (
            "select count(id) from horae_pipeline where owner_id != %s "
            "and type = 0 and  id not in(%s) %s; ")

    OWNER_ID_LIST_SQL = ("select max(id) from common_permhistory where "
            "resource_type = '%s' and resource_id = %d group by "
            "applicant_id;")

    RESOURCE_ID_LIST_SQL = ("select max(id) from common_permhistory where "
            "resource_type = '%s' and applicant_id = %d group by "
            "resource_id;")

    TASK_WITH_PIPEID_SQL = (
            "select a.id, a.pl_id, a.next_task_ids, "
            "a.prev_task_ids, a.pid, b.server_tag, b.type, a.retry_count "
            "from ( "
            "    select id, pl_id, next_task_ids, prev_task_ids, "
            "    pid, retry_count from horae_task where pl_id = %s "
            ")a "
            "left outer join ( "
            "    select id, type, server_tag from horae_processor "
            ") b "
            "on a.pid = b.id where b.type is not null;")

    GET_APPLY_PERM_LIST = (
            "select a.update_time, a.applicant_id, a.reason, "
            "a.permission, b.username from ( "
            "    select update_time, applicant_id, reason, permission "
            "    from common_permhistory where id in(%s) and status = %s "
            ")a left outer join ( "
            "    select id, username from auth_user "
            ")b on a.applicant_id = b.id; ")

    SUPER_USER_SHOW_ALL_PROC_SQL = (
        "select id, name, type, template, update_time, description, "
        "config, owner_id, private, tag, tpl_files from "
        "horae_processor %s order by %s %s limit %s, %s;")
    SUPER_USER_SHOW_ALL_PROC_COUNT = (
        "select count(id) from horae_processor %s;")

    SHOW_PROCESSOR_ALL_SQL = (
        "select id, name, type, template, update_time, description, "
        "config, owner_id, private, tag, tpl_files from "
        "horae_processor where (owner_id = %s %s )or "
        "(owner_id != %s and private = 0 %s) order by %s %s limit %s, %s;")
    SHOW_PROCESSOR_ALL_COUNT = (
        "select count(id) from "
        "horae_processor where (owner_id = %s %s )or "
        "(owner_id != %s and private = 0 %s);")

    SHOW_PRIVATE_SQL = (
        "select id, name, type, template, update_time, description, "
        "config, owner_id, private, tag, tpl_files, CASE WHEN quote_num is NULL THEN 0 ELSE quote_num END AS quote_num from( "
        "   select id, name, type, template, update_time, description, "
        "   config, owner_id, private, tag, tpl_files from "
        "   horae_processor where  owner_id = %s and private = 1 %s "
        ")t1 left outer join ( "
        "   select pid, count(id) as quote_num from horae_task group by pid "
        ")t2 on t1.id=t2.pid "
        "order by %s %s limit %s, %s;")

    SHOW_PRIVATE_COUNT = (
        "select count(id) from "
        "horae_processor where owner_id = %s and private = 1 %s;")

    SHOW_PUBLIC_SQL = (
        "select id, name, type, template, update_time, description, "
        "config, owner_id, 2 as private, tag, tpl_files, CASE WHEN quote_num is NULL THEN 0 ELSE quote_num END AS quote_num from( "
        "   select id, name, type, template, update_time, description, "
        "   config, owner_id, 2 as private, tag, tpl_files from "
        "   horae_processor where private = 0 %s "
        ")t1 left outer join ( "
        "   select pid, count(id) as quote_num from horae_task group by pid "
        ")t2 on t1.id=t2.pid "
        "order by %s %s limit %s, %s;")
    SHOW_PUBLIC_COUNT = (
        "select count(id) from "
        "horae_processor where private = 0 %s;")

    SHOW_OWN_PUBLIC_SQL = (
        "select id, name, type, template, update_time, description, "
        "config, owner_id, private, tag, tpl_files, CASE WHEN quote_num is NULL THEN 0 ELSE quote_num END AS quote_num from( "
        "   select id, name, type, template, update_time, description, "
        "   config, owner_id, private, tag, tpl_files from "
        "   horae_processor where  id in(%s) and private = 1 %s "
        ")t1 left outer join ( "
        "   select pid, count(id) as quote_num from horae_task group by pid "
        ")t2 on t1.id=t2.pid "
        "order by %s %s limit %s, %s;")
    SHOW_OWN_PUBLIC_COUNT = (
        "select count(id) from "
        "horae_processor where id in(%s) and private = 0 %s;")

    GET_PACKAGE_HISTORYS = (
        "select a.id, a.upload_time, a.upload_user_id, "
        "b.username, a.version, a.status, a.description from ( "
        "    select id, status, upload_time, upload_user_id, "
        "    version, description from horae_uploadhistory "
        "    where processor_id = %s order by id desc "
        ")a left outer join ( "
        "    select id, username from auth_user "
        ")b on a.upload_user_id = b.id;")

    SHOW_PIPELINE_RUN_HISTORY_SQL = (
        "select distinct pl_id, run_time "
        "from horae_runhistory where pl_id in(%s) %s "
        "order by %s %s limit %s, %s;")
    SHOW_PIPELINE_RUN_HISTORY_COUNT = (
        "select count(distinct pl_id, run_time) as count_his "
        "from horae_runhistory where pl_id in(%s) %s;")

    SHOW_TASK_RUN_HISTORY_SQL = (
        "select task_id, run_time, pl_id, start_time, "
        "end_time, status, schedule_id, pl_name, task_name, id, cpu, mem "
        "from horae_runhistory where pl_id in(%s) %s "
        "order by %s %s limit %s, %s; ")

    SHOW_TASK_RUN_HISTORY_SQL_TEST = (
        "select c.task_id, c.run_time, c.pl_id, c.start_time, "
        "c.end_time, c.status, c.schedule_id, c.pl_name, d.task_name, "
        "c.id, c.cpu, c.mem from( "
        "    select a.id, a.task_id, a.run_time, a.pl_id, a.start_time, "
        "    a.end_time, a.status, a.schedule_id, a.cpu, a.mem, "
        "    b.name as pl_name from ( "
        "        select id, task_id, run_time, pl_id, start_time, "
        "        end_time, status, schedule_id, cpu, mem "
        "        from horae_runhistory where pl_id in(%s) %s "
        "        order by %s %s limit %s, %s "
        "    )a left outer join ( "
        "        select id, name from horae_pipeline "
        "    )b on a.pl_id = b.id "
        ")c left outer join ( "
        "    select id, name as task_name from horae_task "
        ")d on c.task_id = d.id ;")
    SHOW_TASK_RUN_HISTORY_COUNT = (
        "select count(id) as count_his "
        "from horae_runhistory where pl_id in(%s) %s;")

    GET_TASK_BY_PIPELINE_ID = (
        "select c.task_id, c.run_time, c.pl_id, c.start_time, "
        "c.end_time, c.status, c.schedule_id, c.pl_name, d.task_name, "
        "d.next_task_ids, d.prev_task_ids, c.cpu, c.mem from( "
        "    select a.task_id, a.run_time, a.pl_id, a.start_time, "
        "    a.end_time, a.status, a.schedule_id, a.cpu, a.mem, "
        "    b.name as pl_name from ( "
        "        select task_id, run_time, pl_id, start_time, "
        "        end_time, status, schedule_id, cpu, mem "
        "        from horae_runhistory where pl_id = %s and run_time = %s "
        "    )a left outer join ( "
        "        select id, name from horae_pipeline "
        "    )b on a.pl_id = b.id "
        ")c left outer join ( "
        "    select id, name as task_name, next_task_ids, prev_task_ids "
        "    from horae_task "
        ")d on c.task_id = d.id ;")

    GET_TASK_INFO_WITH_PIPELINE_NAME = (
        "select a.id, a.pl_id, a.pid, a.next_task_ids, a.prev_task_ids, "
        "a.over_time, a.name, a.retry_count, b.name as pipeline_name from ( "
        "   select id, pl_id, pid, next_task_ids, prev_task_ids, over_time, "
        "   name, retry_count from horae_task where id in(%s) "
        ") a  left outer join ( "
        "   select id, name from horae_pipeline "
        ") b on a.pl_id = b.id;")

    PIPELINE_ABSTRACT_INFO = (
        "select count(distinct pl_id, run_time) "
        "from horae_runhistory where pl_id in (%s) and "
        "status in (%s) "
        "and run_time >= '%s' and run_time <= '%s';")

    TASK_SCHEDULED_COUNT_SQL = (
            "select count(a.id) from ("
            "select id, pl_id from horae_runhistory "
            "where status != %s and status != %s and status != %s "
            ") a left outer join("
            "select id from horae_pipeline "
            "where owner_id = %s"
            ") b on a.pl_id = b.id where b.id is not null;")

    GET_APP_LIST_SQL = (
            "select distinct(tag) from horae_pipeline "
            "where tag is not null and tag != '';")

    GET_CT_TIME_BY_TASK_ID_LIST = (
            "select a.id, b.ct_time from( "
            "    select pl_id, id from horae_task where id in(%s) "
            ") a left outer join ( "
            "    select id, ct_time from horae_pipeline "
            ") b on a.pl_id = b.id where b.id is not null;")
    GET_PROC_QUOTE_NUM = (
            "select count(id) from horae_task where pid = %s;")

    PIPE_OWNERS_GET = (
            "select owner_id from horae_pipeline where id in(select "
            "pl_id from horae_task where pid = %s);")

class SqlManager(object):
    def __init__(self, logger):
        self.__log = logger
        self.__graph_mgr = graph_manager.GraphGroup(logger)

    # 获取owenerid拥有权限的所有流程信息
    def get_all_pipelines(
            self,
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):

        page_max = page_max - page_min
        tmp_sql = ConstantSql.SHOW_PIPELINE_INFO_ALL % (
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()

            is_super = is_admin(owner_id)
            row_list = []
            for row in rows:
                tmp_row = list(row)
                if is_super:
                    tmp_row[6] = tools_util.UserPermissionType.WRITE
                else:
                    if tmp_row[8] == owner_id:
                        tmp_row[6] = tools_util.UserPermissionType.WRITE
                    else:
                        tmp_row[6] = self.check_pipeline_auth_valid(
                                row[0], 
                                owner_id)

                    if tmp_row[6] == tools_util.UserPermissionType.NO_AUTH:
                        try:
                            perm_history = common.models.PermHistory.objects.filter(
                                    resource_type=tools_util.CONSTANTS.PIPELINE,
                                    resource_id=tmp_row[0],
                                    applicant_id=owner_id).latest('id')
                            if perm_history.status == tools_util.AuthAction.APPLY_AUTH:
                                tmp_row[6] = tools_util.UserPermissionType.CONFIRMING
                        except django.core.exceptions.ObjectDoesNotExist:
                            pass
                        except django.core.exceptions.FieldDoesNotExist:
                            pass
                row_list.append(tmp_row)
            all_count = self.__get_all_pipeline_count(where_content)
            return all_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def get_owner_pipelines(
            self,
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):
        page_max = page_max - page_min
        tmp_sql = ConstantSql.SHOW_OWNER_PIPELINE_INFO % (
                owner_id,
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            owner_count = self.__get_owner_pipeline_count(
                    owner_id, 
                    where_content)
            return owner_count, rows
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def get_auth_pipelines(
            self,
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):
        page_max = page_max - page_min
        read_list, tmp_list = \
                self.get_pipeline_id_list_by_owner_id(owner_id)
        tmp_list.append('-1')  # 防止sql语法错误
        manager_id_list = ','.join(tmp_list)
        tmp_sql = ConstantSql.SHOW_AUTH_PIPELINE_INFO % (
                owner_id,
                manager_id_list,
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            is_super = is_admin(owner_id)
            row_list = []
            for row in rows:
                tmp_row = list(row)
                if is_super == 1:
                    tmp_row[6] = tools_util.UserPermissionType.WRITE
                else:
                    if tmp_row[8] == owner_id:
                        tmp_row[6] = tools_util.UserPermissionType.WRITE
                    else:
                        tmp_row[6] = self.check_pipeline_auth_valid(
                                row[0], 
                                owner_id)
                row_list.append(tmp_row)
            auth_count = self.__get_auth_pipeline_count(
                    owner_id,
                    where_content)
            return auth_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def get_no_auth_pipeline_info(
            self,
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):
        page_max = page_max - page_min
        read_list, tmp_list = \
                self.get_pipeline_id_list_by_owner_id(owner_id)
        tmp_list.append('-1')  # 防止sql语法错误
        manager_id_list = ','.join(tmp_list)
        tmp_sql = ConstantSql.SHOW_NO_AUTH_PIPELINE_INFO % (
                owner_id, 
                manager_id_list,
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()

            is_super = is_admin(owner_id)
            row_list = []
            for row in rows:
                tmp_row = list(row)
                if is_super == 1:
                    tmp_row[6] = tools_util.UserPermissionType.WRITE
                else:
                    try:
                        perm_history = common.models.PermHistory.objects.filter(
                                resource_type=tools_util.CONSTANTS.PIPELINE,
                                resource_id=tmp_row[0],
                                applicant_id=owner_id).latest('id')
                        if perm_history.status == tools_util.AuthAction.APPLY_AUTH:
                            tmp_row[6] = tools_util.UserPermissionType.CONFIRMING
                    except django.core.exceptions.ObjectDoesNotExist:
                        pass
                    except django.core.exceptions.FieldDoesNotExist:
                        pass
                row_list.append(tmp_row)
            no_auth_count = self.__get_no_auth_pipeline_count(
                    owner_id,
                    where_content)
            return no_auth_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def get_pipeline_info(self, pipeline_id):
        try:
            pipeline = horae.models.Pipeline.objects.get(
                    id=pipeline_id)
            read_id_list, write_id_list = self.get_owner_id_list(pipeline_id)
            write_id_list.append(pipeline.owner_id)
            owner_users = django.contrib.auth.models.User.objects.filter(
                    id__in=write_id_list)
            return owner_users, pipeline
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None, None

    def get_all_user_info(self):
        try:
            users = django.contrib.auth.models.User.objects.all()
            if len(users) <= 0:  # 防止惰性计算将异常传到外部
                return users
            return users
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    @django.db.transaction.atomic
    def delete_pipeline(self, owner_id, pipeline_id):
        try:
            with django.db.transaction.atomic():
                pipeline = horae.models.Pipeline.objects.get(
                        id=pipeline_id)
                if self.check_pipeline_auth_valid(
                        pipeline_id, 
                        owner_id) != tools_util.UserPermissionType.WRITE:
                    return 1, "对不起，你没有权限删除这个流程!"

                run_tasks = horae.models.Schedule.objects.filter(
                        pl_id=pipeline_id, 
                        status__in=(
                                tools_util.TaskState.TASK_READY, 
                                tools_util.TaskState.TASK_RUNNING, 
                                tools_util.TaskState.TASK_WAITING))
                if len(run_tasks) > 0:
                    return 1, "can't delete pipeline, there has task running!"

                tasks = horae.models.Task.objects.filter(
                        pl_id=pipeline_id)
                for task in tasks:
                    next_task_ids = task.next_task_ids.split(',')
                    other_dep_tasks = []
                    for tmp_task_id in next_task_ids:
                        if tmp_task_id.strip() == '':
                            continue

                        tmp_task = horae.models.Task.objects.get(id=int(tmp_task_id))
                        if tmp_task.pl_id != task.pl_id:
                            pipeline = horae.models.Pipeline.objects.get(id=tmp_task.pl_id)
                            other_dep_tasks.append("流程：%s\t任务：%s" % (pipeline.name, tmp_task.name))
                    if len(other_dep_tasks) > 0:
                        return 2, ("这个流程的任务被其他流程的任务依赖,"
                                   "请先解除依赖关系再删除。\n%s" % 
                                   '\n'.join(other_dep_tasks))

                delete_task_id_list = []
                for task in tasks:
                    delete_task_id_list.append(str(task.id))
                    task.delete()
                pipeline.delete()

                for remove_node in delete_task_id_list:
                    self.__graph_mgr.remove_node(remove_node)
                perm_historys = common.models.PermHistory.objects.filter(
                        resource_type=tools_util.CONSTANTS.PIPELINE,
                        resource_id=pipeline_id)
                for perm_his in perm_historys:
                    perm_his.delete()

                run_histories = horae.models.RunHistory.objects.filter(
                        pl_id=pipeline_id)
                for run_history in run_histories:
                    run_history.delete()

                schedules = horae.models.Schedule.objects.filter(
                        pl_id=pipeline_id)
                for schedule in schedules:
                    schedule.delete()

                ready_tasks = horae.models.ReadyTask.objects.filter(
                        pl_id=pipeline_id)
                for ready_task in ready_tasks:
                    ready_task.delete()

                ordered_tasks = horae.models.OrderdSchedule.objects.filter(
                        pl_id=pipeline_id)
                for ordered_task in ordered_tasks:
                    ordered_task.delete()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def update_pipeline(
            self, 
            pipeline_id,
            owner_id, 
            lifecycle=None,
            name=None, 
            ct_time=None, 
            manager_id_list=None, 
            monitor_way=None, 
            tag=None, 
            description=None,
            type=None,
            project_id=None):
        try:
            with django.db.transaction.atomic():
                pipeline = horae.models.Pipeline.objects.get(
                        id=pipeline_id)
                owner_id_valid = True
                if owner_id != pipeline.owner_id:
                    owner_id_valid = False
                read_id_list, write_id_list = self.get_owner_id_list(
                        pipeline_id)

                if self.check_pipeline_auth_valid(
                        pipeline_id, 
                        owner_id) != tools_util.UserPermissionType.WRITE:
                    return 1, "对不起，你没有权限修改这个流程!"

                if lifecycle is not None:
                    pipeline.life_cycle = lifecycle

                if name is not None:
                    pipeline.name = name

                if ct_time is not None:
                    pipeline.ct_time = ct_time

                if monitor_way is not None:
                    pipeline.monitor_way = monitor_way

                if tag is not None:
                    pipeline.tag = tag

                if description is not None:
                    pipeline.description = description

                if type is not None:
                    pipeline.type = type

                is_default_project = False
                if pipeline.project_id is not None \
                        and pipeline.project_id != 0 and \
                        (project_id is None or project_id ==0):
                    project = horae.models.Project.objects.get(
                            id=pipeline.project_id)
                    if project.is_default == 1:
                        project_id = project.id
                        is_default_project = True

                if project_id is not None and project_id != 0:
                    if not is_default_project:
                        if not self.__check_has_project_auth(
                                owner_id, 
                                project_id):
                            return 1, "你没有项目的权限，无法加入项目!"

                    pipeline.project_id = project_id
                else:                    
                    projects = horae.models.Project.objects.filter(
                            owner_id=owner_id, 
                            is_default=1)
                    if len(projects) <= 0:
                        user_info = django.contrib.auth.models.User.objects.get(
                                id=owner_id)
                        proj_name = "%s_%s" % (
                                user_info.username, 
                                tools_util.CONSTANTS.PROJECT_DEFAULT_NAME)
                        project = horae.models.Project(
                                name=proj_name,
                                owner_id=owner_id,
                                is_default=1)
                        project.save()
                        project_id = project.id
                    else:
                        project_id = projects[0].id

                    pipeline.project_id = project_id

                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                pipeline.update_time = now_time
                if manager_id_list is not None:
                    id_list = manager_id_list.split(',')
                    int_id_list = []
                    for id in id_list:
                        if id.strip() != '':
                            int_id_list.append(int(id))

                    for id in int_id_list:
                        if id == owner_id:
                            continue

                        if str(id) in write_id_list:
                            continue

                        perm_history = common.models.PermHistory(
                                resource_type=tools_util.CONSTANTS.PIPELINE,
                                resource_id=pipeline_id,
                                permission=\
                                    tools_util.UserPermissionType.WRITE_STR,
                                applicant_id=id,
                                grantor_id=owner_id,
                                status=\
                                    tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                                update_time=now_time,
                                create_time=now_time,
                                reason='add manager')
                        perm_history.save()

                    for id in write_id_list:
                        if int(id) == owner_id:
                            continue

                        if int(id) in int_id_list:
                            continue

                        perm_history = common.models.PermHistory(
                                resource_type=tools_util.CONSTANTS.PIPELINE,
                                resource_id=pipeline_id,
                                permission=\
                                    tools_util.UserPermissionType.WRITE_STR,
                                applicant_id=int(id),
                                grantor_id=owner_id,
                                status=tools_util.AuthAction.TAKE_BACK_AUTH,
                                update_time=now_time,
                                reason='take back auth')
                        perm_history.save()
                pipeline.save()

                if ct_time is not None:
                    tasks = horae.models.Task.objects.filter(pl_id=pipeline.id)
                    run_time = tools_util.StaticFunction.get_now_format_time(
                            "%Y%m%d%H%M")                 
                    for task in tasks:
                        task.last_run_time = run_time
                        task.save()
                return 0, "OK"            
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def create_new_pipeline(
            self, 
            name, 
            ct_time, 
            owner_id, 
            manager_id_list, 
            monitor_way, 
            tag, 
            description,
            life_cycle,
            type,
            project_id):
        try:
            with django.db.transaction.atomic():
                name = name.strip()
                if project_id is not None and project_id != 0:
                    if not self.__check_has_project_auth(owner_id, project_id):
                        return 1, "你没有项目的权限，无法加入项目!"
                else:
                    projects = horae.models.Project.objects.filter(
                            owner_id=owner_id, is_default=1)
                    if len(projects) <= 0:
                        user_info = django.contrib.auth.models.User.objects.get(
                                id=owner_id)
                        proj_name = "%s_%s" % (
                                user_info.username, 
                                tools_util.CONSTANTS.PROJECT_DEFAULT_NAME)
                        project = horae.models.Project(
                                name=proj_name,
                                owner_id=owner_id,
                                is_default=1)
                        project.save()
                        project_id = project.id
                    else:
                        project_id = projects[0].id

                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                pipeline = horae.models.Pipeline(
                        name=name, 
                        owner_id=owner_id, 
                        ct_time=ct_time, 
                        life_cycle=life_cycle,
                        update_time=now_time,
                        email_to="",
                        description=description,
                        sms_to="",
                        monitor_way=monitor_way,
                        enable=0,
                        tag=tag,
                        private=1,
                        type=type,
                        project_id=project_id)
                pipeline.save()
                if manager_id_list is None:
                    return 0, "OK"
        
                pipeline = horae.models.Pipeline.objects.get(name=name)
                id_list = manager_id_list.split(",")
                for id in id_list:
                    if id.strip() == '':
                        continue

                    if int(id) == owner_id:
                        continue

                    perm_history = common.models.PermHistory(
                            resource_type=tools_util.CONSTANTS.PIPELINE,
                            resource_id=pipeline.id,
                            permission=tools_util.UserPermissionType.WRITE_STR,
                            applicant_id=int(id),
                            grantor_id=owner_id,
                            status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                            update_time=now_time,
                            create_time=now_time,
                            reason='add manager')
                    perm_history.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def pipeline_off_or_on_line(self, owner_id, pipeline_id, on_line):
        """
            如果是下线，需要将正在运行中的任务全部标记为用户停止状态
        """
        try:
            with django.db.transaction.atomic():
                pipeline = horae.models.Pipeline.objects.get(
                        id=pipeline_id)
                if pipeline.enable == on_line:
                    return 1, (
                            'pipeline on line status[%s] '
                            'equal to gived: %s' % (pipeline.enable, on_line))

                if self.check_pipeline_auth_valid(
                        pipeline_id, 
                        owner_id) != tools_util.UserPermissionType.WRITE:
                    return 1, "对不起，你没有权限对这个流程进行上下线操作!"

                tasks = horae.models.Task.objects.filter(pl_id=pipeline_id)
                now_pipe_tasks = set()
                for task in tasks:
                    now_pipe_tasks.add(task.id)

                if on_line == 0:
                    '''
                    next_task_id_list = []
                    for task in tasks:
                        next_task_id_split = task.next_task_ids.split(',')
                        for next_task_id in next_task_id_split:
                            if next_task_id.strip() == '':
                                continue
                            try:
                                next_task_id = int(next_task_id.strip())
                            except:
                                continue

                            if next_task_id in now_pipe_tasks:
                                continue

                            next_task_id_list.append(str(next_task_id))

                    if len(next_task_id_list) > 0:
                        task_id_str = ','.join(next_task_id_list)
                        sql = (
                                "select id,name from horae_pipeline "
                                "where enable = 1 and id in( "
                                "select pl_id from horae_task "
                                "where id in (%s));" % task_id_str)
                        cursor = django.db.connection.cursor()
                        cursor.execute(sql) 
                        rows = cursor.fetchall()
                        if len(rows) > 0 and rows[0][0] != 'null':
                            return 1, (
                                "下游依赖流程：[%s]，还处于上线状态，"
                                "本流程无法完成下线！"  % rows[0][1])
                    '''         
                    schedules = horae.models.Schedule.objects.filter(
                            pl_id=pipeline_id, 
                            status__in=(
                                    tools_util.TaskState.TASK_READY, 
                                    tools_util.TaskState.TASK_RUNNING, 
                                    tools_util.TaskState.TASK_WAITING))
                    for schedule in schedules:
                        schedule.status = \
                                tools_util.TaskState.TASK_STOPED_BY_USER
                        schedule.save()

                    run_historys = horae.models.RunHistory.objects.filter(
                            pl_id=pipeline_id, 
                            status__in=(
                                    tools_util.TaskState.TASK_READY, 
                                    tools_util.TaskState.TASK_RUNNING, 
                                    tools_util.TaskState.TASK_WAITING))
                    for run_history in run_historys:
                        run_history.status = \
                                tools_util.TaskState.TASK_STOPED_BY_USER
                        run_history.save()

                    ready_tasks = horae.models.ReadyTask.objects.filter(
                            pl_id=pipeline_id, 
                            status__in=(
                                    tools_util.TaskState.TASK_READY, 
                                    tools_util.TaskState.TASK_RUNNING))
                    for ready_task in ready_tasks:
                        ready_task.status = \
                                tools_util.TaskState.TASK_STOPED_BY_USER
                        ready_task.save()

                    ready_tasks = horae.models.ReadyTask.objects.filter(
                            pl_id=pipeline_id, 
                            status=tools_util.TaskState.TASK_FAILED)
                    for ready_task in ready_tasks:
                        ready_task.status = \
                                tools_util.TaskState.TASK_STOPED_BY_USER
                        ready_task.save()
                        schedule = horae.models.Schedule.objects.get(
                                id=ready_task.schedule_id)
                        schedule.status = \
                                tools_util.TaskState.TASK_STOPED_BY_USER
                        schedule.save()
                        run_history = horae.models.RunHistory.objects.get(
                                schedule_id=ready_task.schedule_id)
                        run_history.status = \
                                tools_util.TaskState.TASK_STOPED_BY_USER
                        run_history.save()

                if on_line == 1:
                    '''
                    prev_task_id_list = []
                    for task in tasks:
                        prev_task_id_split = task.prev_task_ids.split(',')
                        for prev_task_id in prev_task_id_split:
                            if prev_task_id.strip() == '':
                                continue
                            try:
                                prev_task_id = int(prev_task_id.strip())
                            except:
                                continue

                            if prev_task_id in now_pipe_tasks:
                                continue

                            prev_task_id_list.append(str(prev_task_id))

                    if len(prev_task_id_list) > 0:
                        task_id_str = ','.join(prev_task_id_list)
                        sql = (
                                "select id,name from horae_pipeline "
                                "where enable in(0, 2) and id in( "
                                "select pl_id from horae_task "
                                "where id in (%s));" % task_id_str)
                        cursor = django.db.connection.cursor()
                        cursor.execute(sql) 
                        rows = cursor.fetchall()
                        if len(rows) > 0 and rows[0][0] != 'null':
                            return 1, (
                                "上游依赖流程：[%s]，还处于下线状态，"
                                "本流程无法完成上线！"  % rows[0][1])
                    '''
                    run_time = tools_util.StaticFunction.get_now_format_time(
                            "%Y%m%d%H%M")                 
                    for task in tasks:
                        task.last_run_time = run_time
                        task.save()

                pipeline.enable = on_line
                if on_line == 1:
                    is_super = is_admin(owner_id)
                    if is_super != 1:
                        pipeline.enable = 2

                pipeline.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def auth_grant_or_apply(
            self, 
            action,
            resource_type, 
            resource_id, 
            granter_id, 
            acquirer_id_list, 
            perm_level,
            reason):
        try:
            with django.db.transaction.atomic():
                if self.check_pipeline_auth_valid(
                        resource_id, 
                        granter_id) != tools_util.UserPermissionType.WRITE:
                    return 1, "this owener has no auth to grant permission"

                permission = tools_util.UserPermissionType.NO_AUTH
                if perm_level == tools_util.UserPermissionType.READ:
                    permission = tools_util.UserPermissionType.READ_STR
                elif perm_level == tools_util.UserPermissionType.WRITE:
                    permission = tools_util.UserPermissionType.WRITE_STR
                else:
                    return 1, "perm_level:%d is unvalid" % perm_level

                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                for acquirer_id in acquirer_id_list:
                    perm_historys = common.models.PermHistory.objects.filter(
                            resource_type=resource_type, 
                            resource_id=resource_id,
                            applicant_id=acquirer_id).order_by('-id')[: 1]
                    if len(perm_historys) > 0:
                        if perm_historys[0].status == action \
                                and permission == perm_historys[0].permission:
                            continue

                    perm_history = common.models.PermHistory(
                            resource_type=resource_type,
                            resource_id=resource_id,
                            permission=permission,
                            status=action,
                            update_time=now_time,
                            create_time=now_time,
                            reason=reason,
                            grantor_id=granter_id,
                            applicant_id=acquirer_id)
                    perm_history.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def get_tasks_by_pipeline_id(self, pipeline_id):
        try:
            tasks = horae.models.Task.objects.filter(
                    pl_id=pipeline_id).order_by("id")
            if len(tasks) <= 0:
                return tasks
            return tasks
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_task_info(self, task_id):
        try:
            return horae.models.Task.objects.get(id=task_id)
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    @django.db.transaction.atomic
    def add_new_task_to_pipeline(self, owner_id, task, processor):
        add_edge_list = []
        try:
            with django.db.transaction.atomic():
                if processor is not None:
                    processor.name = "%s_%s%s" % (
                            processor.name, 
                            task.pl_id, 
                            random.randint(1, 100))
                    processor.save()
                    processor = horae.models.Processor.objects.get(
                            name=processor.name)
                    task.pid = processor.id

                # 检查插件是否存在
                processor = horae.models.Processor.objects.get(
                            id=task.pid)
                pipeline = horae.models.Pipeline.objects.get(id=task.pl_id)
                if self.check_pipeline_auth_valid(
                        pipeline.id, 
                        owner_id) != tools_util.UserPermissionType.WRITE:
                    return 1, "对不起，你没有权限向这个流程添加任务！"

                task.last_run_time = \
                        tools_util.StaticFunction.get_now_format_time(
                        "%Y%m%d%H%M")

                if task.prev_task_ids is None:
                    task.prev_task_ids = ','

                if task.next_task_ids is None:
                    task.next_task_ids = ','

                prev_task_ids = copy.deepcopy(task.prev_task_ids)
                next_task_ids = copy.deepcopy(task.next_task_ids)
                task.prev_task_ids = ','
                task.next_task_ids = ','
                task.save()
                new_task = horae.models.Task.objects.get(
                        name=task.name, 
                        pl_id=task.pl_id)
                if next_task_ids is not None:
                    next_task_id_list = next_task_ids.split(",")
                    for next_id in next_task_id_list:
                        if next_id.strip() == '':
                            continue
                        self.add_edge(owner_id, new_task.id, int(next_id.strip()))
                        add_edge_list.append((new_task.id, int(next_id.strip())))

                if prev_task_ids is not None:
                    prev_task_id_list = prev_task_ids.split(",")
                    for prev_id in prev_task_id_list:
                        if prev_id.strip() == '':
                            continue
                        self.add_edge(owner_id, int(prev_id.strip()), new_task.id)
                        add_edge_list.append((int(prev_id.strip()), new_task.id))

                self.__graph_mgr.add_node(str(new_task.id))
                new_task = horae.models.Task.objects.get(
                        name=task.name, 
                        pl_id=task.pl_id)
                return 0, new_task
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            for add_edge in add_edge_list:
                self.__graph_mgr.remove_edge(add_edge[0], add_edge[1])
            return 1, str(ex)

    @django.db.transaction.atomic
    def update_tasks(self, owner_id, task, old_task, template):
        added_edges = []
        removed_edges = []
        try:
            with django.db.transaction.atomic():
                db_task = horae.models.Task.objects.get(id=task.id)
                task.pl_id = db_task.pl_id
                old_next_ids = db_task.next_task_ids
                old_prev_ids = db_task.prev_task_ids

                if self.check_pipeline_auth_valid(
                        task.pl_id, 
                        owner_id) != tools_util.UserPermissionType.WRITE:
                    return 1, "对不起，你没有权限修改这个流程的任务！"

                new_next_task_ids = task.next_task_ids
                new_prev_task_ids = task.prev_task_ids
                if task.next_task_ids == 'null':
                    task.next_task_ids = ','

                if task.prev_task_ids == 'null':
                    task.prev_task_ids = ','
                if new_next_task_ids is not None:
                    new_id_list = new_next_task_ids.split(',')
                    new_id_strip_list = []
                    for id in new_id_list:
                        if id.strip() == '' or id.strip() == 'null':
                            continue
                        try:
                            int(id)
                        except:
                            continue
                        new_id_strip_list.append(id.strip())
                    old_id_list = old_next_ids.split(',')
                    old_id_strip_list = []
                    for id in old_id_list:
                        if id.strip() == '' or id.strip() == 'null':
                            continue
                        old_id_strip_list.append(id.strip())
                        if id.strip() not in new_id_strip_list:
                            self.delete_edge(owner_id, task.id, int(id.strip()))
                            self.__graph_mgr.remove_edge(
                                    str(task.id), 
                                    id.strip())
                            removed_edges.append((str(task.id), id.strip()))
                    for id in new_id_strip_list:
                        if id not in old_id_strip_list:
                            self.add_edge(owner_id, task.id, int(id.strip()))
                            if not self.__graph_mgr.add_edge(str(task.id), id):
                                raise exceptions.Exception("add edge failed!")
                            added_edges.append((str(task.id), id))
                    task.next_task_ids = ','.join(new_id_strip_list)

                if new_prev_task_ids is not None:
                    new_id_list = new_prev_task_ids.split(',')
                    new_id_strip_list = []
                    for id in new_id_list:
                        if id.strip() == '' or id.strip() == 'null':
                            continue
                        try:
                            int(id)
                        except:
                            continue

                        new_id_strip_list.append(id.strip())
                    old_id_list = old_prev_ids.split(',')
                    old_id_strip_list = []
                    for id in old_id_list:
                        if id.strip() == ''  or id.strip() == 'null':
                            continue
                        old_id_strip_list.append(id.strip())
                        if id.strip() not in new_id_strip_list:
                            self.delete_edge(owner_id, int(id.strip()), task.id)
                            self.__graph_mgr.remove_edge(
                                    id.strip(),
                                    str(task.id))
                            removed_edges.append((id.strip(), str(task.id)))

                    for id in new_id_strip_list:
                        if id not in old_id_strip_list:
                            self.add_edge(owner_id, int(id.strip()), task.id)
                            if not self.__graph_mgr.add_edge(id, str(task.id)):
                                raise exceptions.Exception("add edge failed!")
                            added_edges.append((id, str(task.id)))
                    task.prev_task_ids = ','.join(new_id_strip_list)
                status, info = 0, "OK"
                # if old_task is not None:
                #    status, info = self.__update_task_by_check_old_status(
                #            task, 
                #            old_task)
                # else:

                if template is not None:
                    task_count = horae.models.Task.objects.filter(pid=task.pid).count()
                    if task_count == 1:
                        proc = horae.models.Processor.objects.get(id=task.pid)
                        proc.template = template
                        proc.save()
                task.save()
                return status, task
        except exceptions.Exception as ex:
            for edge in added_edges:
                self.__graph_mgr.remove_edge(edge[0], edge[1])

            for edge in removed_edges:
                self.__graph_mgr.add_edge(edge[0], edge[1])

            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def delete_task_info(self, owner_id, task_id):
        try:
            with django.db.transaction.atomic():
                db_task = horae.models.Task.objects.get(id=task_id)
                if self.check_pipeline_auth_valid(
                        db_task.pl_id, 
                        owner_id) != tools_util.UserPermissionType.WRITE:
                    return 1, "对不起，你没有权限删除这个流程的任务！"

                next_task_ids = db_task.next_task_ids.split(',')
                other_dep_tasks = []
                for tmp_task_id in next_task_ids:
                    if tmp_task_id.strip() == '':
                        continue

                    task = horae.models.Task.objects.get(id=int(tmp_task_id))
                    if task.pl_id != db_task.pl_id:
                        pipeline = horae.models.Pipeline.objects.get(id=task.pl_id)
                        other_dep_tasks.append("流程：%s\t任务：%s" % (pipeline.name, task.name))
                if len(other_dep_tasks) > 0:
                    return 2, ("这个任务被其他流程的任务依赖，"
                               "请先解除依赖关系再删除。\n%s" % 
                               '\n'.join(other_dep_tasks))

                run_tasks = horae.models.Schedule.objects.filter(
                        task_id=task_id, 
                        status__in=(
                                tools_util.TaskState.TASK_READY, 
                                tools_util.TaskState.TASK_RUNNING, 
                                tools_util.TaskState.TASK_WAITING))
                if len(run_tasks) > 0:
                    return 1, "can't delete task, it is running!"

                run_historys = horae.models.RunHistory.objects.filter(
                        task_id=task_id)
                for run_history in run_historys:
                    run_history.delete()

                schedules = horae.models.Schedule.objects.filter(
                        task_id=task_id)
                for schedule in schedules:
                    schedule.delete()

                ready_tasks = horae.models.ReadyTask.objects.filter(
                        task_id=task_id)
                for ready_task in ready_tasks:
                    ready_task.delete()

                ordered_tasks = horae.models.OrderdSchedule.objects.filter(
                        task_id=task_id)
                for ordered_task in ordered_tasks:
                    ordered_task.delete()



                for tmp_task_id in next_task_ids:
                    if tmp_task_id.strip() == '':
                        continue
                    self.delete_edge(owner_id, task_id, int(tmp_task_id))

                prev_task_ids = db_task.prev_task_ids.split(',')
                for tmp_task_id in prev_task_ids:
                    if tmp_task_id.strip() == '':
                        continue
                    self.delete_edge(owner_id, int(tmp_task_id), task_id)

                db_task.delete()
                self.__graph_mgr.remove_node(str(task_id))

                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def add_edge_with_transaction(self, owner_id, from_task_id, to_task_id):
        try:
            with django.db.transaction.atomic():
                return self.add_edge(owner_id, from_task_id, to_task_id)
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def add_edge(self, owner_id, from_task_id, to_task_id):
        from_db_task = horae.models.Task.objects.get(id=from_task_id)
        next_task_id_list = from_db_task.next_task_ids.split(',')
        tmp_next_list = []
        for tmp_id in next_task_id_list:
            if tmp_id.strip() == '':
                continue

            tmp_next_list.append(tmp_id.strip())


        if str(to_task_id) not in tmp_next_list:
            tmp_next_list.append(str(to_task_id))

        to_db_task = horae.models.Task.objects.get(id=to_task_id)

        prev_task_id_list = to_db_task.prev_task_ids.split(',')
        tmp_prev_list = []
        for tmp_id in prev_task_id_list:
            if tmp_id.strip() == '':
                continue

            tmp_prev_list.append(tmp_id.strip())

        if str(from_task_id) not in tmp_prev_list:
            tmp_prev_list.append(str(from_task_id))

        old_from_task = copy.deepcopy(from_db_task)
        sql = "update horae_task set next_task_ids='%s' where id=%s and next_task_ids='%s';" % (','.join(tmp_next_list), from_db_task.id, from_db_task.next_task_ids)
        cursor = django.db.connection.cursor()
        change_row = cursor.execute(sql)
        if change_row != 1:
            raise exceptions.Exception("exe %s failed, changed"
                    " rows[%d]" % (sql, change_row))
        #from_db_task.next_task_ids = ','.join(tmp_next_list)
        #from_db_task.save()
        # status, info = self.__update_task_by_check_old_status(
        #        from_db_task, 
        #        old_from_task)
        # if status != 0:
        #    raise exceptions.Exception(info)

        old_to_task = copy.deepcopy(to_db_task)
        sql = "update horae_task set prev_task_ids='%s' where id=%s and prev_task_ids='%s';" % (','.join(tmp_prev_list), to_db_task.id, to_db_task.prev_task_ids)
        cursor = django.db.connection.cursor()
        change_row = cursor.execute(sql)
        if change_row != 1:
            raise exceptions.Exception("exe %s failed, changed"
                    " rows[%d]" % (sql, change_row))

        #to_db_task.prev_task_ids = ','.join(tmp_prev_list)
        #to_db_task.save()
        # status, info = self.__update_task_by_check_old_status(
        #        to_db_task, 
        #        old_to_task)
        # if status != 0:
        #    raise exceptions.Exception(info)

        if not self.__graph_mgr.add_edge(
                str(from_task_id), 
                str(to_task_id)):
            raise exceptions.Exception("add edge failed!")

        return 0, "OK"

    @django.db.transaction.atomic
    def delete_edge_with_transaction(self, owner_id, from_task_id, to_task_id):
        try:
            with django.db.transaction.atomic():
                return self.delete_edge(owner_id, from_task_id, to_task_id)
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def delete_edge(self, owner_id, from_task_id, to_task_id):
        from_db_task = horae.models.Task.objects.get(id=from_task_id)
        to_db_task = horae.models.Task.objects.get(id=to_task_id)

        old_from_task = copy.deepcopy(from_db_task)
        from_next_id_list_tmp = from_db_task.next_task_ids.split(',')
        from_next_id_list = []
        finded = False
        for next_id in from_next_id_list_tmp:
            if next_id.strip() == '':
                continue

            if next_id.strip() == str(to_task_id):
                finded = True
                continue

            from_next_id_list.append(next_id.strip())

        sql = "update horae_task set next_task_ids='%s' where id=%s and next_task_ids='%s';" % (','.join(from_next_id_list), from_db_task.id, from_db_task.next_task_ids)
        cursor = django.db.connection.cursor()
        change_row = cursor.execute(sql)
        if change_row != 1:
            raise exceptions.Exception("exe %s failed, changed"
                    " rows[%d]" % (sql, change_row))
        #from_db_task.next_task_ids = ','.join(from_next_id_list)
        #from_db_task.save()
        # status, info = self.__update_task_by_check_old_status(
        #        from_db_task, 
        #        old_from_task)
        # if status != 0:
        #    raise exceptions.Exception("update error")

        old_to_task = copy.deepcopy(to_db_task)
        to_prev_id_list_tmp = to_db_task.prev_task_ids.split(',')
        to_prev_id_list = []
        finded = False
        for prev_id in to_prev_id_list_tmp:
            if prev_id.strip() == '':
                continue

            if prev_id.strip() == str(from_task_id):
                finded = True
                continue
            to_prev_id_list.append(prev_id.strip())

        sql = "update horae_task set prev_task_ids='%s' where id=%s and prev_task_ids='%s';" % (','.join(to_prev_id_list), to_db_task.id, to_db_task.prev_task_ids)
        cursor = django.db.connection.cursor()
        change_row = cursor.execute(sql)
        if change_row != 1:
            raise exceptions.Exception("exe %s failed, changed"
                    " rows[%d]" % (sql, change_row))
        #to_db_task.prev_task_ids = ','.join(to_prev_id_list)
        #to_db_task.save()
        # status, info = self.__update_task_by_check_old_status(
        #        to_db_task, 
        #        old_to_task)
        # if status != 0:
        #    raise exceptions.Exception("update error")

        if not self.__graph_mgr.remove_edge(
                str(from_task_id), 
                str(to_task_id)):
            raise exceptions.Exception("remove edge failed!")

        return 0, "OK"

    def get_all_authed_processor(self, owner_id, type):
        try:
            processors_pub = horae.models.Processor.objects.exclude(
                    owner_id=owner_id).filter(
                    private=0, 
                    type=type)
            processors_own = horae.models.Processor.objects.filter(
                    owner_id=owner_id, 
                    type=type)
            read_list, write_list = self.get_pipeline_id_list_by_owner_id(
                    owner_id, 
                    tools_util.CONSTANTS.PROCESSOR)
            processors_other = horae.models.Processor.objects.filter(
                    id__in=read_list)
            return processors_pub | processors_own | processors_other
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_pipeline_owner_list(self, pipeline_id):
        try:
            read_id_list, write_id_list = self.get_owner_id_list(
                    pipeline_id)
            read_users = []
            if read_id_list is not None and len(read_id_list) > 0:
                read_users = django.contrib.auth.models.User.objects.filter(
                        id__in=read_id_list)
                len(read_users)# 防止惰性计算将异常传到外部
            write_users = []
            if write_id_list is not None and len(write_id_list) > 0:
                write_users = django.contrib.auth.models.User.objects.filter(
                        id__in=write_id_list)
                len(write_users)# 防止惰性计算将异常传到外部
            return read_users, write_users
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def get_user_info(self, username):
        try:
            return django.contrib.auth.models.User.objects.get(
                    username=username)
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_user_info_by_id(self, user_id):
        try:
            return django.contrib.auth.models.User.objects.get(
                    id=user_id)
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_apply_list(self, owner_id, source_id, source_name='pipeline'):
        tmp_sql = ''
        try:
            if self.check_pipeline_auth_valid(
                    pipeline_id, 
                    owner_id) != tools_util.UserPermissionType.WRITE:
                return None

            tmp_sql = ConstantSql.OWNER_ID_LIST_SQL % (source_name, source_id)
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            id_list = []
            for row in rows:
                id_list.append(str(row[0]))

            if len(id_list) <= 0:
                return []
            
            id_list_str = ','.join(id_list)
            tmp_sql = ConstantSql.GET_APPLY_PERM_LIST % (
                    id_list_str, 
                    tools_util.AuthAction.APPLY_AUTH)
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            return cursor.fetchall()
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def show_processor_all(
            self, 
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):
        page_max = page_max - page_min

        is_super = is_admin(owner_id)
        tmp_sql = None
        if is_super == 1:
            if where_content is not None and where_content.strip() != '':
                where_content = "where 1 %s" % where_content

            tmp_sql = ConstantSql.SUPER_USER_SHOW_ALL_PROC_SQL % (
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max)         
        else:
            tmp_sql = ConstantSql.SHOW_PROCESSOR_ALL_SQL % (
                    owner_id,
                    where_content,
                    owner_id,
                    where_content,
                    order_field,
                    sort_order,
                    page_min,
                    page_max)         
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            processor_rows = cursor.fetchall()
            row_list = []
            for row in processor_rows:
                tmp_row = list(row)
                if tmp_row[7] != owner_id:
                    tmp_row[8] = 2
                row_list.append(tmp_row)

            if is_super == 1:
                tmp_sql = ConstantSql.SUPER_USER_SHOW_ALL_PROC_COUNT % \
                        where_content
            else:
                tmp_sql = ConstantSql.SHOW_PROCESSOR_ALL_COUNT % (
                        owner_id,
                        where_content,
                        owner_id,
                        where_content)
            cursor.execute(tmp_sql) 
            all_count_rows = cursor.fetchall()
            all_count = int(all_count_rows[0][0])
            return all_count, row_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def show_processor_private(
            self, 
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):
        page_max = page_max - page_min
        tmp_sql = ConstantSql.SHOW_PRIVATE_SQL % (
                owner_id,
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            private_rows = cursor.fetchall()

            tmp_sql = ConstantSql.SHOW_PRIVATE_COUNT % (
                    owner_id,
                    where_content)
            cursor.execute(tmp_sql) 
            count_rows = cursor.fetchall()
            private_count = int(count_rows[0][0])
            return private_count, private_rows
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def show_processor_own_public(
            self, 
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):

        read_list, write_list = self.get_pipeline_id_list_by_owner_id(
                owner_id, 
                tools_util.CONSTANTS.PROCESSOR)
        if len(read_list) <= 0:
            return 0, []
        read_id_str = ','.join(read_list)
        page_max = page_max - page_min
        tmp_sql = ConstantSql.SHOW_OWN_PUBLIC_SQL % (
                read_id_str,
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            own_pub_rows = cursor.fetchall()

            tmp_sql = ConstantSql.SHOW_OWN_PUBLIC_COUNT % (
                    read_id_str,
                    where_content)
            cursor.execute(tmp_sql) 
            count_rows = cursor.fetchall()
            count = int(count_rows[0][0])
            return count, own_pub_rows
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def show_processor_public(
            self, 
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):
        page_max = page_max - page_min
        tmp_sql = ConstantSql.SHOW_PUBLIC_SQL % (
                where_content,
                order_field,
                sort_order,
                page_min,
                page_max) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            public_rows = cursor.fetchall()

            tmp_sql = ConstantSql.SHOW_PUBLIC_COUNT % where_content
            cursor.execute(tmp_sql) 
            count_rows = cursor.fetchall()
            count = int(count_rows[0][0])
            return count, public_rows
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def create_processor(self, processor, user_id_list):
        try:
            with django.db.transaction.atomic():
                processor.save()
                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                read_id_list, write_id_list = self.get_owner_id_list(
                        processor.id, 
                        tools_util.CONSTANTS.PROCESSOR)
                if user_id_list is not None:
                    id_list = user_id_list.split(',')
                    int_id_list = []
                    for id in id_list:
                        if id.strip() != '':
                            int_id_list.append(int(id))

                    for id in int_id_list:
                        if id == processor.owner_id:
                            continue

                        if str(id) in read_id_list:
                            continue

                        perm_history = common.models.PermHistory(
                                resource_type=tools_util.CONSTANTS.PROCESSOR,
                                resource_id=processor.id,
                                permission=\
                                    tools_util.UserPermissionType.READ_STR,
                                applicant_id=id,
                                grantor_id=processor.owner_id,
                                status=\
                                    tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                                update_time=now_time,
                                create_time=now_time,
                                reason='add manager')
                        perm_history.save()

                    for id in read_id_list:
                        if int(id) == processor.owner_id:
                            continue

                        if int(id) in int_id_list:
                            continue

                        perm_history = common.models.PermHistory(
                                resource_type=tools_util.CONSTANTS.PROCESSOR,
                                resource_id=processor.id,
                                permission=\
                                    tools_util.UserPermissionType.READ_STR,
                                applicant_id=int(id),
                                grantor_id=processor.owner_id,
                                status=tools_util.AuthAction.TAKE_BACK_AUTH,
                                update_time=now_time,
                                reason='take back auth')
                        perm_history.save()
            return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def update_processor(self, user_id, processor, user_id_list):
        is_super = is_admin(user_id)
        try:
            with django.db.transaction.atomic():
                old_processor = horae.models.Processor.objects.get(
                        id=processor.id)
                    
                if old_processor.owner_id != user_id:
                    if is_super != 1:
                        return 1, "必须是插件的owner才能修改插件信息！"

                while processor.config is not None:
                    old_key_list = self.__get_config_key_list(old_processor.config)
                    new_key_list = self.__get_config_key_list(processor.config)
                    append_key_list = []
                    for new_key in new_key_list:
                        if new_key not in old_key_list:
                            append_key_list.append(new_key)

                    if len(append_key_list) <= 0:
                        break

                    tasks = horae.models.Task.objects.filter(pid=processor.id)
                    if len(tasks) <= 0:
                        break

                    for task in tasks:
                        append_list = []
                        task_key_list = self.__get_config_key_list(task.config)
                        for append_key in append_key_list:
                            if append_key not in task_key_list:
                                tmp_str = "%s=" % append_key
                                append_list.append(tmp_str)
                        if len(append_list) <= 0:
                            continue
                        append_str = '\n'.join(append_list)
                        task_config = "%s\n%s" % (task.config, append_str)
                        task.config = task_config
                        task.save() 
                    break  # break for while
                processor.save()

                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")

                read_id_list, write_id_list = self.get_owner_id_list(
                        processor.id, 
                        tools_util.CONSTANTS.PROCESSOR)
                if user_id_list is not None:
                    id_list = user_id_list.split(',')
                    int_id_list = []
                    for id in id_list:
                        if id.strip() != '':
                            int_id_list.append(int(id))

                    for id in int_id_list:
                        if id == user_id:
                            continue

                        if str(id) in read_id_list:
                            continue

                        perm_history = common.models.PermHistory(
                                resource_type=tools_util.CONSTANTS.PROCESSOR,
                                resource_id=processor.id,
                                permission=\
                                    tools_util.UserPermissionType.READ_STR,
                                applicant_id=id,
                                grantor_id=user_id,
                                status=\
                                    tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                                update_time=now_time,
                                create_time=now_time,
                                reason='add manager')
                        perm_history.save()

                    for id in read_id_list:
                        if int(id) == user_id:
                            continue

                        if int(id) in int_id_list:
                            continue

                        perm_history = common.models.PermHistory(
                                resource_type=tools_util.CONSTANTS.PROCESSOR,
                                resource_id=processor.id,
                                permission=\
                                    tools_util.UserPermissionType.READ_STR,
                                applicant_id=int(id),
                                grantor_id=user_id,
                                status=tools_util.AuthAction.TAKE_BACK_AUTH,
                                update_time=now_time,
                                reason='take back auth')
                        perm_history.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def delete_processor(self, processor_id):
        try:
            tasks = horae.models.Task.objects.filter(pid=processor_id)
            if len(tasks) > 0:
                return 1, "插件被其他任务依赖，不能直接删除插件！"
            processor = horae.models.Processor.objects.get(id=processor_id)
            perm_historys = common.models.PermHistory.objects.filter(
                    resource_type=tools_util.CONSTANTS.PROCESSOR, 
                    resource_id=processor.id)
            for perm_history in perm_historys:
                perm_history.delete()

            processor.delete()
            return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def get_proessor_info(self, processor_id):
        try:
            return horae.models.Processor.objects.get(id=processor_id)
        except exceptions.Exception as ex:
            self.__log.error(
                    "execute failed![ex:%s][proc_id:%s][trace:%s]!" % (
                    str(ex), processor_id, traceback.format_exc()))
            return None

    @django.db.transaction.atomic
    def upload_pacakge(self, upload_history):
        try:
            with django.db.transaction.atomic():
                used_list = horae.models.UploadHistory.objects.filter(
                        processor_id=upload_history.processor_id, 
                        status=1)
                for used in used_list:
                    used.status = 0
                    used.save()

                upload_history.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def get_processor_package_history(self, processor_id):
        tmp_sql = ConstantSql.GET_PACKAGE_HISTORYS % (processor_id)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return rows
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    @django.db.transaction.atomic
    def use_processor_package(self, history_id, obj, call_back_func):
        try:
            with django.db.transaction.atomic():
                history = horae.models.UploadHistory.objects.get(id=history_id)
                used_list = horae.models.UploadHistory.objects.filter(
                        processor_id=history.processor_id, 
                        status=1)
                for used in used_list:
                    used.status = 0
                    used.save()
                history.status = 1
                history.save()
                if not call_back_func(history.processor_id, history.version):
                    raise exceptions.Exception("handle pangu pacakge failed!")
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def public_processor(self, processor_id):
        try:
            processor = horae.models.Processor.objects.get(id=processor_id)
            if processor.private == 0:
                tmp_sql = ConstantSql.PIPE_OWNERS_GET % processor.id
                cursor = django.db.connection.cursor()
                cursor.execute(tmp_sql) 
                rows = cursor.fetchall()
                if len(rows) > 0:
                    read_id_list, write_id_list = self.get_owner_id_list(
                            processor.id, 
                            tools_util.CONSTANTS.PROCESSOR)
                    for row in rows:
                        if str(row[0]) not in read_id_list \
                                and row[0] != processor.owner_id:
                            user_info = self.get_user_info_by_id(row[0])
                            return 1, ("插件被没有使用权限的用户 【%s】"
                                    "使用中，无法收回公共权限！" % 
                                    user_info.username)
                processor.private = 1
            else:
                processor.private = 0
            processor.save()
            return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def get_all_authed_pipeline_info(self, owner_id, task_id=None):
        try:
            pipelines = horae.models.Pipeline.objects.filter(
                    type=0).values('id', 'name', 'type')
            len(pipelines)
            return pipelines
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return []

    def get_prev_pipeline_info(self, task_id):
        try:
            task = horae.models.Task.objects.get(id=task_id)
            prev_task_id_list_tmp = task.prev_task_ids.split(',')
            prev_task_id_list = []
            for prev_task_id in prev_task_id_list_tmp:
                if prev_task_id.strip() == '':
                    continue

                prev_task_id_list.append(prev_task_id.strip())

            if len(prev_task_id_list) <= 0:
                return []
            prev_task_ids = ','.join(prev_task_id_list)
            sql = ("select distinct pl_id from horae_task"
                    " where id in(%s);" % prev_task_ids)
            cursor = django.db.connection.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            owner_id_list = []
            for row in rows:
                owner_id_list.append(str(row[0]))
            if len(owner_id_list) <= 0:
                return []
            pipelines = horae.models.Pipeline.objects.filter(
                    id__in=owner_id_list).values('id', 'name', 'type')
            return pipelines
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return []

    def get_task_history_by_pipe(self, pipeline_id, run_time):
        try:
            sql = ConstantSql.GET_TASK_BY_PIPELINE_ID % (
                    pipeline_id,
                    run_time)
            cursor = django.db.connection.cursor()
            cursor.execute(sql) 
            rows = cursor.fetchall()
            return rows
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def show_pipeline_history(
            self,
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):

        try:
            tmp_list = []
            cursor = django.db.connection.cursor()
            is_super = is_admin(owner_id)
            if is_super:
                pipelines = horae.models.Pipeline.objects.all().values("id")
                for pipeline in pipelines:
                    tmp_list.append(str(pipeline["id"]))
            else:
                sql = ("select distinct id from horae_pipeline"
                        " where owner_id=%s;" % owner_id)
                cursor.execute(sql) 
                rows = cursor.fetchall()
                owner_id_list = []
                for row in rows:
                    owner_id_list.append(str(row[0]))
                tmp_list, write_res_id_list = \
                        self.get_pipeline_id_list_by_owner_id(owner_id)
                tmp_list.extend(write_res_id_list)
                tmp_list.extend(owner_id_list)

            if len(tmp_list) <= 0:
                return 0, []

            pipeline_id_list = ','.join(tmp_list)
            page_max = page_max - page_min
            sql = ConstantSql.SHOW_PIPELINE_RUN_HISTORY_SQL % (
                    pipeline_id_list,
                    where_content,
                    order_field,
                    sort_order,
                    page_min,
                    page_max)
            cursor.execute(sql) 
            rows = cursor.fetchall()
            run_history_list = []
            for row in rows:
                historys = horae.models.RunHistory.objects.filter(
                        pl_id=row[0], 
                        run_time=row[1])
                max_end_time = historys[0].end_time
                min_start_time = historys[0].start_time
                cpu = 0
                mem = 0
                status = tools_util.TaskState.TASK_SUCCEED
                for history in historys:
                    if max_end_time < history.end_time:
                        max_end_time = history.end_time

                    if min_start_time > history.start_time:
                        min_start_time = history.start_time
                     
                    if history.cpu is not None:
                        cpu += history.cpu

                    if history.mem is not None:
                        mem += history.mem

                    if history.status in (
                            tools_util.TaskState.TASK_FAILED,
                            tools_util.TaskState.TASK_PREV_FAILED,
                            tools_util.TaskState.TASK_STOPED_BY_USER):
                        status = history.status
                        break

                    if history.status in (
                            tools_util.TaskState.TASK_READY,
                            tools_util.TaskState.TASK_RUNNING,
                            tools_util.TaskState.TASK_TIMEOUT,
                            tools_util.TaskState.TASK_WAITING):
                        status = history.status
                        continue
                history = historys[0]
                history.status = status
                history.cpu = cpu
                history.mem = mem
                history.start_time = min_start_time
                history.end_time = max_end_time
                pipeline = horae.models.Pipeline.objects.get(id=history.pl_id)
                tmp_list = []
                tmp_list.append(history)
                tmp_list.append(pipeline.name)
                tmp_list.append('')
                run_history_list.append(tmp_list)

            sql = ConstantSql.SHOW_PIPELINE_RUN_HISTORY_COUNT % (
                    pipeline_id_list,
                    where_content)
            cursor.execute(sql) 
            count = cursor.fetchall()
            return count[0][0], run_history_list
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 0, None

    def show_task_history(
            self,
            owner_id, 
            page_min, 
            page_max, 
            order_field, 
            sort_order,
            where_content):
        try:
            tmp_list = []
            cursor = django.db.connection.cursor()
            is_super = is_admin(owner_id)
            if is_super == 1:
                pipelines = horae.models.Pipeline.objects.all().values("id")
                for pipeline in pipelines:
                    tmp_list.append(str(pipeline["id"]))
            else:
                sql = ("select distinct id from horae_pipeline"
                        " where owner_id=%s;" % owner_id)
                cursor.execute(sql) 
                rows = cursor.fetchall()
                owner_id_list = []
                for row in rows:
                    owner_id_list.append(str(row[0]))
                tmp_list, write_res_id_list = \
                        self.get_pipeline_id_list_by_owner_id(owner_id)
                tmp_list.extend(write_res_id_list)
                tmp_list.extend(owner_id_list)

            if len(tmp_list) <= 0:
                return 0, []

            pipeline_id_list = ','.join(tmp_list)
            page_max = page_max - page_min
            sql = ConstantSql.SHOW_TASK_RUN_HISTORY_SQL % (
                    pipeline_id_list,
                    where_content,
                    order_field,
                    sort_order,
                    page_min,
                    page_max)
            cursor.execute(sql) 
            rows = cursor.fetchall()
            sql = ConstantSql.SHOW_TASK_RUN_HISTORY_COUNT % (
                    pipeline_id_list,
                    where_content)
            cursor.execute(sql) 
            count = cursor.fetchall()
            return count[0][0], rows
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 0, None

    def get_run_history_info(self, run_history_id):
        try:
            return horae.models.RunHistory.objects.get(id=run_history_id)
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_tasks_by_task_ids(self, task_ids):
        sql = ConstantSql.GET_TASK_INFO_WITH_PIPELINE_NAME % task_ids
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(sql) 
            return cursor.fetchall()
        except exceptions.Exception as ex:
            self.__log.error("execute[%s] failed![ex:%s][trace:%s]!" % (
                    sql, str(ex), traceback.format_exc()))
            return None

    def __update_task_by_check_old_status(self, task, old_task):
        tmp_sql = ''
        try:
            set_list = []
            if task.pid is not None:
                set_list.append("pid = %s" % task.pid)

            if task.next_task_ids is not None:
                set_list.append("next_task_ids = '%s'" % task.next_task_ids)

            if task.prev_task_ids is not None:
                set_list.append("prev_task_ids = '%s'" % task.prev_task_ids)

            if task.over_time is not None:
                set_list.append("over_time = %s" % task.over_time)

            if task.name is not None:
                set_list.append("name = '%s'" % task.name)

            if task.config is not None:
                tmp_config = task.config.replace("'", "\\'")
                tmp_config = tmp_config.replace("\"", "\\\"")
                set_list.append("config = '%s'" % tmp_config)

            if task.retry_count is not None:
                set_list.append("retry_count = %s" % task.retry_count)

            if task.last_run_time is not None:
                set_list.append("last_run_time = '%s'" % task.last_run_time)

            if task.description is not None:
                tmp_des = task.description.replace("'", "\\'")
                tmp_des = tmp_des.replace("\"", "\\\"")
                set_list.append("description = '%s'" % tmp_des)

            if task.priority is not None:
                set_list.append("priority = %s" % task.priority)

            if task.except_ret is not None:
                set_list.append("except_ret = %s" % task.except_ret)
            
            if len(set_list) <=0:
                return 1, "nothing to update!"

            where_list = []
            where_list.append("id = %s" % task.id)
            if old_task.pid is not None:
                where_list.append("pid = %s" % old_task.pid)

            if old_task.next_task_ids is not None:
                where_list.append("next_task_ids = '%s'" % 
                        old_task.next_task_ids)

            if old_task.prev_task_ids is not None:
                where_list.append("prev_task_ids = '%s'" % 
                        old_task.prev_task_ids)

            if old_task.name is not None:
                where_list.append("name = '%s'" % old_task.name)

            sql = "update horae_task set %s where %s" % (
                    ", ".join(set_list), 
                    " and ".join(where_list))
            tmp_sql = sql
            cursor = django.db.connection.cursor()
            affect_row = cursor.execute(sql) 
            if affect_row != 1:
                return 1, 'update db error! please refresh page![sql: %s]' % tmp_sql
            return 0, "OK"
        except exceptions.Exception as ex:
            error_info = ("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            self.__log.error(error_info)
            return 1, error_info

    def check_pipeline_auth_valid(self, pipeline_id, owner_id):
        try:
            is_super = is_admin(owner_id)
            if is_super == 1:
                return tools_util.UserPermissionType.WRITE

            pipelines = horae.models.Pipeline.objects.filter(
                    id=pipeline_id, 
                    owner_id=owner_id)
            if len(pipelines) > 0:
                return tools_util.UserPermissionType.WRITE

            owners = common.models.PermHistory.objects.filter(
                    resource_type=tools_util.CONSTANTS.PIPELINE, 
                    resource_id=pipeline_id,
                    applicant_id=owner_id).order_by('-id')[: 1]
            if len(owners) <= 0:
                return tools_util.UserPermissionType.NO_AUTH

            if owners[0].status not in (
                    tools_util.AuthAction.CONFIRM_APPLY_AUTH, 
                    tools_util.AuthAction.GRANT_AUTH_TO_OTHER):
                return tools_util.UserPermissionType.NO_AUTH

            if owners[0].permission == tools_util.UserPermissionType.READ_STR:
                return tools_util.UserPermissionType.READ

            if owners[0].permission == tools_util.UserPermissionType.WRITE_STR:
                return tools_util.UserPermissionType.WRITE

            return tools_util.UserPermissionType.NO_AUTH
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return tools_util.UserPermissionType.NO_AUTH

    def get_run_history_with_task_ids(
            self, 
            task_id_list, 
            min_run_time, 
            max_run_time):
        try:
            tasks = horae.models.RunHistory.objects.exclude(
                    status=tools_util.TaskState.TASK_SUCCEED).filter( 
                    run_time__lte=max_run_time,
                    run_time__gte=min_run_time,
                    task_id__in=task_id_list)
            if len(tasks) <= 0:
                return tasks
            return tasks
        except exceptions.Exception as ex:
            self.__log.error("execute failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_processor_quote_list(self, processor_id):
        try:
            quote_list = []
            tasks = horae.models.Task.objects.filter(pid=processor_id)[0: 100]
            for task in tasks:
                quote_map = {}
                quote_map["task_id"] = task.id
                quote_map["task_name"] = task.name
                pipelines = horae.models.Pipeline.objects.filter(id=task.pl_id)
                if len(pipelines) <= 0:
                    continue
                pipeline = pipelines[0]
                quote_map["pipeline_id"] = task.pl_id
                quote_map["pipeline_name"] = pipeline.name
                owner_users = django.contrib.auth.models.User.objects.filter(
                        id=pipeline.owner_id)
                if len(owner_users) <= 0:
                    self.__log.warn(
                            "pipeline owner id not exits:pl_id: %d, owner_id: %d" % 
                            (pipeline.id, pipeline.owner_id))
                    continue
                owner_users = owner_users[0]
                quote_map["owner_id"] = owner_users.id
                quote_map["owner_name"] = owner_users.username
                quote_map["last_run_time"] = task.last_run_time
                quote_list.append(quote_map)
            return quote_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_processor_quote_num(self, processor_id):
        tmp_sql = ConstantSql.GET_PROC_QUOTE_NUM % processor_id
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return rows[0][0]
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return 1

    def get_pipeline_run_info(
            self, 
            status_list_str, 
            pl_ids_str, 
            min_run_time, 
            max_run_time):
        sql = ConstantSql.PIPELINE_ABSTRACT_INFO % (
                pl_ids_str, 
                status_list_str, 
                min_run_time, 
                max_run_time)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(sql) 
            row = cursor.fetchall()
            return row[0][0]
        except exceptions.Exception as ex:
            self.__log.error("execute[%s] failed![ex:%s][trace:%s]!" % (
                    sql, str(ex), traceback.format_exc()))
            return 0

    def get_data_info(self, data_type):
        try:
            datas = dms.models.Config.objects.filter(type=data_type)
            if len(datas) <= 0:
                return datas
            return datas
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_owner_id_list(self, source_id, source_name='pipeline'):
        tmp_sql = ConstantSql.OWNER_ID_LIST_SQL % (source_name, source_id)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            id_list = []
            for row in rows:
                id_list.append(int(row[0]))

            if len(id_list) <= 0:
                return [], []

            perm_historys = common.models.PermHistory.objects.filter(
                    id__in=id_list,
                    permission__in=(
                            tools_util.UserPermissionType.WRITE_STR, 
                            tools_util.UserPermissionType.READ_STR),
                    status__in=(
                            tools_util.AuthAction.CONFIRM_APPLY_AUTH, 
                            tools_util.AuthAction.GRANT_AUTH_TO_OTHER))
            read_res_id_list = []
            write_res_id_list = []
            for perm in perm_historys:
                if perm.applicant_id is None:
                    continue

                if perm.permission == tools_util.UserPermissionType.WRITE_STR:
                    write_res_id_list.append(str(perm.applicant_id))
                elif perm.permission == tools_util.UserPermissionType.READ_STR:
                    read_res_id_list.append(str(perm.applicant_id))
                else:
                    pass
            return read_res_id_list, write_res_id_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def get_manager_info_list(self, owner_list):
        try:
            users = django.contrib.auth.models.User.objects.filter(
                    id__in=owner_list)
            return users
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def get_pipeline_id_list_by_owner_id(self, owner_id, source_name='pipeline'):
        """
            获取每一个owener_id所有最后修改的权限信息相关的流程信息
            并返回有读写权限的流程
            (不包含自己创建的）
        """
        tmp_sql = ConstantSql.RESOURCE_ID_LIST_SQL % (source_name, owner_id)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            id_list = []
            for row in rows:
                id_list.append(int(row[0]))
            if len(id_list) <= 0:
                return [], []

            perm_historys = common.models.PermHistory.objects.filter(
                    id__in=id_list,
                    permission__in=(
                            tools_util.UserPermissionType.WRITE_STR, 
                            tools_util.UserPermissionType.READ_STR),
                    status__in=(
                            tools_util.AuthAction.CONFIRM_APPLY_AUTH, 
                            tools_util.AuthAction.GRANT_AUTH_TO_OTHER))
            read_res_id_list = []
            write_res_id_list = []
            for perm in perm_historys:
                if perm.permission == tools_util.UserPermissionType.WRITE_STR:
                    write_res_id_list.append(str(perm.resource_id))
                elif perm.permission == tools_util.UserPermissionType.READ_STR:
                    read_res_id_list.append(str(perm.resource_id))
                else:
                    pass
            return read_res_id_list, write_res_id_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None, None

    def get_processor_last_version(self, processor_id):
        try:
            last_version = horae.models.UploadHistory.objects.filter(
                    processor_id=processor_id).order_by('-id')[: 1]
            if len(last_version) <= 0:
                return True, None
            return True, last_version[0]
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return False, None

    def get_now_owner_scheduled_task_num(self, owner_id):
        try:
            sql = ConstantSql.TASK_SCHEDULED_COUNT_SQL % (
                    tools_util.TaskState.TASK_FAILED, 
                    tools_util.TaskState.TASK_SUCCEED, 
                    tools_util.TaskState.TASK_STOPED_BY_USER, 
                    owner_id)
            cursor = django.db.connection.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            return True, rows[0][0]
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return False, 0
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False, 0

    def get_app_group_list(self):
        try:
            sql = ConstantSql.GET_APP_LIST_SQL
            cursor = django.db.connection.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            app_set = set()
            for row in rows:
                if row[0].strip() == '':
                    continue

                split_list = row[0].split(',')
                for split_item in split_list:
                    if split_item.strip() == '':
                        continue
                    app_set.add(split_item.strip())
            return app_set
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_prev_nodes_info(self, prev_nodes):
        try:
            sql = ConstantSql.GET_CT_TIME_BY_TASK_ID_LIST % prev_nodes
            cursor = django.db.connection.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            len(rows)
            return rows
        except django.db.OperationalError as ex:
            django.db.close_old_connections()
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex),
                    traceback.format_exc()))
            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def __get_all_pipeline_count(self, where_content):
        tmp_sql = ConstantSql.SHOW_ALL_PIPELINE_INFO_ALL_COUNT % (
                where_content) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def __get_owner_pipeline_count(self, owner_id, where_content):
        tmp_sql = ConstantSql.SHOW_OWNER_PIPELINE_INFO_ALL_COUNT % (
                owner_id, 
                where_content) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def __get_auth_pipeline_count(
            self, 
            owner_id, 
            where_content):
        read_list, tmp_list = \
                self.get_pipeline_id_list_by_owner_id(owner_id)
        tmp_list.append('-1')  # 防止sql语法错误
        manager_id_list = ','.join(tmp_list)
        tmp_sql = ConstantSql.SHOW_AUTH_PIPELINE_INFO_COUNT % (
                owner_id,
                manager_id_list, 
                where_content) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def __get_no_auth_pipeline_count(
            self, 
            owner_id, 
            where_content):
        read_list, tmp_list = \
                self.get_pipeline_id_list_by_owner_id(owner_id)
        tmp_list.append('-1')  # 防止sql语法错误
        manager_id_list = ','.join(tmp_list)
        not_in_id_list_str = ','.join(tmp_list)
        tmp_sql = ConstantSql.SHOW_NO_AUTH_PIPELINE_INFO_COUNT % (
                owner_id,
                not_in_id_list_str,
                where_content) 
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def __get_config_key_list(self, config):
        key_list = []
        if config is None:
            return key_list

        config_list = config.split('\n')
        for config_item in config_list:
            if config_item.strip() == '':
                continue

            item_kv = config_item.split('=')
            if len(item_kv) < 2:
                continue

            if item_kv[0].strip() == '':
                continue

            key_list.append(item_kv[0].strip())

        return key_list

    def __check_has_project_auth(self, owner_id, project_id):
        try:
            project = horae.models.Project.objects.get(id=project_id)
            if project.owner_id == int(owner_id):
                return True

            tmp_sql = ("select max(id) from common_permhistory where "
                    "resource_type = 'project' and resource_id = %s and "
                    "applicant_id = %s;" % (project_id, owner_id))
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            if len(rows) <= 0:
                return False

            if rows[0][0] is None or str(rows[0][0]) == 'null':
                return False

            com_perm = common.models.PermHistory.objects.get(id=rows[0][0])
            if com_perm.status == tools_util.AuthAction.GRANT_AUTH_TO_OTHER \
                    and com_perm.permission == \
                    tools_util.UserPermissionType.WRITE_STR:
                return True
            return False
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return False

    def get_project_list(self, owner_id, tag=0):
        try:
            tag = int(tag)
            if tag == 2:
                projects = horae.models.Project.objects.all()
                len(projects)
                return projects

            owner_project_list = horae.models.Project.objects.filter(
                    owner_id=owner_id)
            project_list = []
            write_perm_list = self.__get_write_perm_project_list(owner_id)
            for owner_project in owner_project_list:
                write_perm_list.append(owner_project.id)

            if tag == 0:
                authed_project = horae.models.Project.objects.filter(
                        id__in=write_perm_list)
                for authed_proj in authed_project:
                    project_list.append(authed_proj)

                return project_list

            if tag == 1:
                no_authed_project = horae.models.Project.objects.exclude(
                        id__in=write_perm_list)
                len(no_authed_project)
                return no_authed_project

            return None
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_project_owner_list(self, project_id):
        tmp_sql = ("select max(id) from common_permhistory where "
                "resource_type = 'project' and resource_id = %d group by "
                "applicant_id;" % project_id)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            id_list = []
            for row in rows:
                id_list.append(int(row[0]))

            if len(id_list) <= 0:
                return []

            perm_historys = common.models.PermHistory.objects.filter(
                    id__in=id_list,
                    permission=tools_util.UserPermissionType.WRITE_STR,
                    status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER)
            write_user_id_list = []
            for perm in perm_historys:
                write_user_id_list.append(str(perm.applicant_id))
            return write_user_id_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def get_pipe_num_with_project(self, project_id):
        tmp_sql = ("select count(id) from horae_pipeline "
                   " where project_id = %s;" % project_id)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            return int(rows[0][0])
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    def __get_write_perm_project_list(self, owner_id):
        tmp_sql = ("select max(id) from common_permhistory where "
                "resource_type = 'project' and applicant_id = %d group by "
                "resource_id;" % owner_id)
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
            id_list = []
            for row in rows:
                id_list.append(int(row[0]))

            if len(id_list) <= 0:
                return []

            perm_historys = common.models.PermHistory.objects.filter(
                    id__in=id_list,
                    permission=tools_util.UserPermissionType.WRITE_STR,
                    status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER)
            write_res_id_list = []
            for perm in perm_historys:
                write_res_id_list.append(str(perm.resource_id))
            return write_res_id_list
        except exceptions.Exception as ex:
            self.__log.error("execute sql[%s] failed![ex:%s][trace:%s]!" % (
                    tmp_sql, str(ex), traceback.format_exc()))
            return None

    @django.db.transaction.atomic
    def add_new_project(self, owner_id, project_name, writer_list, description):
        try:
            with django.db.transaction.atomic():
                if project_name.find(
                        tools_util.CONSTANTS.PROJECT_DEFAULT_NAME) >= 0:
                    return 1, ("项目名中不能包含 '%s' 关键词！" % 
                            tools_util.CONSTANTS.PROJECT_DEFAULT_NAME)

                project = horae.models.Project(
                    name=project_name, 
                    owner_id=owner_id,
                    description=description,
                    is_default=False)

                project.save()
                if writer_list is None or writer_list.strip() == '':
                    return 0, "OK"
        
                project = horae.models.Project.objects.get(name=project_name)
                id_list = writer_list.split(",")
                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                for id in id_list:
                    if id.strip() == '':
                        continue

                    if int(id) == owner_id:
                        continue

                    perm_history = common.models.PermHistory(
                            resource_type=tools_util.CONSTANTS.PROJECT,
                            resource_id=project.id,
                            permission=tools_util.UserPermissionType.WRITE_STR,
                            applicant_id=int(id),
                            grantor_id=owner_id,
                            status=tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                            update_time=now_time,
                            create_time=now_time,
                            reason='add manager')
                    perm_history.save()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def update_project(
            self, 
            owner_id, 
            project_id, 
            project_name=None, 
            manager_id_list=None,
            description=None):  
        try:
            with django.db.transaction.atomic():
                project = horae.models.Project.objects.get(id=project_id)
                if not self.__check_has_project_auth(owner_id, project_id):
                    return 1, "你没有这个项目的权限!"

                if project_name is not None:
                    if project_name.find(
                            tools_util.CONSTANTS.PROJECT_DEFAULT_NAME) >= 0:
                        return 1, ("项目名中不能包含 '%s' 关键词！" % 
                                tools_util.CONSTANTS.PROJECT_DEFAULT_NAME)
                    project.name = project_name

                if description is not None:
                    project.description = description

                project.save()

                if manager_id_list is None:
                    return 0, "OK"

                if project.is_default == 1:
                    return 1, ("个人默认项目，不允许添加其他管理员！"
                            "请将相应流程移入新建项目，添加管理员！")

                write_id_list = self.get_project_owner_list(project_id)
                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y-%m-%d %H:%M:%S")
                id_list = manager_id_list.split(',')
                int_id_list = []
                for id in id_list:
                    if id.strip() != '':
                        int_id_list.append(int(id))

                for id in int_id_list:
                    if id == owner_id:
                        continue

                    if str(id) in write_id_list:
                        continue

                    perm_history = common.models.PermHistory(
                            resource_type=tools_util.CONSTANTS.PROJECT,
                            resource_id=project_id,
                            permission=\
                                tools_util.UserPermissionType.WRITE_STR,
                            applicant_id=id,
                            grantor_id=owner_id,
                            status=\
                                tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                            update_time=now_time,
                            create_time=now_time,
                            reason='add manager')
                    perm_history.save()

                for id in write_id_list:
                    if int(id) == owner_id:
                        continue

                    if int(id) in int_id_list:
                        continue

                    perm_history = common.models.PermHistory(
                            resource_type=tools_util.CONSTANTS.PROJECT,
                            resource_id=project_id,
                            permission=\
                                tools_util.UserPermissionType.WRITE_STR,
                            applicant_id=int(id),
                            grantor_id=owner_id,
                            status=tools_util.AuthAction.TAKE_BACK_AUTH,
                            update_time=now_time,
                            reason='take back auth')
                    perm_history.save()

                    pipelines = horae.models.Pipeline.objects.filter(
                            owner_id=id, 
                            project_id=project_id)
                    def_project = horae.models.Project.objects.filter(
                            owner_id=id,
                            is_default=1)
                    if len(def_project) <= 0:
                        continue

                    if project_id != def_project[0].id:
                        for pipeline in pipelines:
                            pipeline.project_id = def_project[0].id
                            pipeline.save()
            return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def delete_project(self, owner_id, project_id):  
        try:
            with django.db.transaction.atomic():
                project = horae.models.Project.objects.get(id=project_id)
                if not self.__check_has_project_auth(owner_id, project_id):
                    return 1, "你没有这个项目的权限!"

                pipelines = horae.models.Pipeline.objects.filter(
                        project_id=project_id)
                if len(pipelines) > 0:
                    return 1, "这个项目下还有流程，请先删除流程！"

                perm_list = common.models.PermHistory.objects.filter(
                        resource_type=tools_util.CONSTANTS.PROJECT,
                        resource_id=project_id)
                for perm in perm_list:
                    perm.delete()
                project.delete()
                return 0, "OK"
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def copy_pipeline(self, owner_id, src_pl_id, new_pl_name, project_id, use_type_src):
        try:
            with django.db.transaction.atomic():
                new_pl_name = new_pl_name.strip()
                new_pl_name = new_pl_name.replace('\r', '')
                new_pl_name = new_pl_name.replace('\n', '')
                pipeline = horae.models.Pipeline.objects.get(id=src_pl_id)
                if pipeline.name == new_pl_name:
                    return 1, "流程名重名"

                pipe_type = pipeline.type
                if not use_type_src:
                    pipe_type = 0

                status, info = self.create_new_pipeline(
                        name=new_pl_name, 
                        ct_time=pipeline.ct_time, 
                        owner_id=owner_id, 
                        manager_id_list='', 
                        monitor_way=pipeline.monitor_way, 
                        tag=pipeline.tag, 
                        description=pipeline.description,
                        life_cycle=pipeline.life_cycle,
                        type=pipe_type,
                        project_id=project_id)
                if status != 0:
                    raise exceptions.Exception(
                            "copy new pipeline failed![%s]" % info)

                new_pipeline = horae.models.Pipeline.objects.get(
                        name=new_pl_name)
                src_tasks = horae.models.Task.objects.filter(pl_id=src_pl_id)
                old_task_map = {}
                new_task_map = {}
                old_new_task_id_map = {}
                old_task_id_set = set()
                for src_task in src_tasks:
                    new_task = horae.models.Task(
                            pl_id=new_pipeline.id,
                            pid=src_task.pid,
                            next_task_ids='',
                            prev_task_ids='',
                            over_time=src_task.over_time,
                            name=src_task.name,
                            config=src_task.config,
                            retry_count=src_task.retry_count,
                            last_run_time=src_task.last_run_time,
                            description=src_task.description,
                            priority=src_task.priority,
                            except_ret=src_task.except_ret,
                            server_tag=src_task.server_tag)
                    status, add_task = self.add_new_task_to_pipeline(
                            owner_id, 
                            new_task, 
                            None)
                    if status != 0:
                        self.delete_pipeline(owner_id, new_pipeline.id)
                        raise exceptions.Exception(add_task)
                    new_task = horae.models.Task.objects.get(
                            pl_id=new_pipeline.id, 
                            name=src_task.name)
                    old_task_map[new_task.id] = src_task
                    new_task_map[new_task.id] = new_task
                    old_task_id_set.add(src_task.id)
                    old_new_task_id_map[src_task.id] = new_task.id

                for task_id in new_task_map:
                    prev_id_str = ''
                    if old_task_map[task_id].prev_task_ids is not None \
                            and old_task_map[task_id].prev_task_ids != '':
                        prev_id_list = []
                        old_prev_task_id_list = \
                            old_task_map[task_id].prev_task_ids.split(',')
                        for old_prev_id in old_prev_task_id_list:
                            if old_prev_id.strip() == "":
                                continue

                            if int(old_prev_id) not in old_task_id_set:
                                continue
                            prev_id_list.append(
                                    str(old_new_task_id_map[int(old_prev_id)]))

                        prev_id_str = ",".join(prev_id_list)

                    next_id_str = ''
                    if old_task_map[task_id].next_task_ids is not None \
                            and old_task_map[task_id].next_task_ids != '':
                        next_id_list = []
                        old_next_task_id_list = \
                            old_task_map[task_id].next_task_ids.split(',')
                        for old_next_id in old_next_task_id_list:
                            if old_next_id.strip() == "":
                                continue

                            if int(old_next_id) not in old_task_id_set:
                                continue
                            next_id_list.append(
                                    str(old_new_task_id_map[int(old_next_id)]))
                        next_id_str = ",".join(next_id_list)
                    new_task_map[task_id].prev_task_ids = prev_id_str
                    new_task_map[task_id].next_task_ids = next_id_str
                    new_task_map[task_id].save()
                return 0, new_pipeline.id
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def copy_task(self, owner_id, src_task_id, dest_pl_id):
        if self.check_pipeline_auth_valid(
                dest_pl_id, 
                owner_id) != tools_util.UserPermissionType.WRITE:
            return 1, "你没有权限将任务拷贝到目标流程！"
        try:
            src_task = horae.models.Task.objects.get(id=src_task_id)
            new_task_name = "%s_copy" % src_task.name
            new_task = horae.models.Task(
                    pl_id=dest_pl_id,
                    pid=src_task.pid,
                    next_task_ids='',
                    prev_task_ids='',
                    over_time=src_task.over_time,
                    name=new_task_name,
                    config=src_task.config,
                    retry_count=src_task.retry_count,
                    last_run_time=src_task.last_run_time,
                    description=src_task.description,
                    priority=src_task.priority,
                    except_ret=src_task.except_ret,
                    server_tag=src_task.server_tag)
            status, add_task = self.add_new_task_to_pipeline(
                    owner_id, 
                    new_task, 
                    None)
            if status != 0:
                return 1, add_task
            new_task = horae.models.Task.objects.get(
                    pl_id=dest_pl_id, 
                    name=new_task_name)
            return 0, new_task
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    @django.db.transaction.atomic
    def new_pipeline_by_proc(self, owner_id, proc_id, new_pl_name, project_id):
        try:
            with django.db.transaction.atomic():
                new_pl_name = new_pl_name.strip()
                new_pl_name = new_pl_name.replace('\r', '')
                new_pl_name = new_pl_name.replace('\n', '')

                pipelines = horae.models.Pipeline.objects.filter(name=new_pl_name)
                if len(pipelines) > 0:
                    return 1, "流程名重名"

                processor = horae.models.Processor.objects.get(id=proc_id)

                status, info = self.create_new_pipeline(
                        name=new_pl_name, 
                        ct_time='', 
                        owner_id=owner_id, 
                        manager_id_list='', 
                        monitor_way=0, 
                        tag='', 
                        description='通过插件自动创建',
                        life_cycle=0,
                        type=0,
                        project_id=project_id)
                if status != 0:
                    raise exceptions.Exception(
                            "create new pipeline failed![%s]" % info)
                now_time = tools_util.StaticFunction.get_now_format_time(
                        "%Y%m%d%H%M")
                new_pipeline = horae.models.Pipeline.objects.get(
                        name=new_pl_name)
                task_name = 'rely_on_%s' % processor.name
                server_tag = 'ALL'
                if processor.type == tools_util.TaskType.APSARA_JOB:
                    server_tag = 'AY54'

                task_config_list = processor.config.split('\n')
                tmp_task_config_list = []
                for config_val in task_config_list:
                    if config_val.strip() == '':
                        continue

                    value_split = config_val.split('\1100')
                    if value_split[0].strip() == '':
                        continue
                    tmp_task_config_list.append(value_split[0].strip())

                task_config_str = '\n'.join(tmp_task_config_list)

                new_task = horae.models.Task(
                        pl_id=new_pipeline.id,
                        pid=processor.id,
                        next_task_ids='',
                        prev_task_ids='',
                        over_time=0,
                        name=task_name,
                        config=task_config_str,
                        retry_count=0,
                        last_run_time=now_time,
                        description="通过插件自动创建",
                        priority=5,
                        except_ret=0,
                        server_tag=server_tag)
                status, add_task = self.add_new_task_to_pipeline(
                        owner_id, 
                        new_task, 
                        None)
                if status != 0:
                    self.delete_pipeline(owner_id, new_pipeline.id)
                    raise exceptions.Exception(add_task)

                return 0, new_pipeline.id
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            try:
                new_pipeline = horae.models.Pipeline.objects.get(
                        name=new_pl_name)
                new_pipeline.delete()
            except:
                pass
            return 1, str(ex)        

    def new_task_by_proc(self, owner_id, proc_id, dest_pl_id):
        if self.check_pipeline_auth_valid(
                dest_pl_id, 
                owner_id) != tools_util.UserPermissionType.WRITE:
            return 1, "你没有权限将任务创建到目标流程！"
        try:
            process = horae.models.Processor.objects.get(id=proc_id)
            new_task_name = "rely_on_%s" % process.name
            now_time = tools_util.StaticFunction.get_now_format_time(
                    "%Y%m%d%H%M")
            server_tag = 'ALL'
            if process.type == tools_util.TaskType.APSARA_JOB:
                server_tag = 'AY54'

            task_config_list = process.config.split('\n')
            tmp_task_config_list = []
            for config_val in task_config_list:
                if config_val.strip() == '':
                    continue

                value_split = config_val.split('\1100')
                if value_split[0].strip() == '':
                    continue
                tmp_task_config_list.append(value_split[0].strip())

            task_config_str = '\n'.join(tmp_task_config_list)

            new_task = horae.models.Task(
                    pl_id=dest_pl_id,
                    pid=process.id,
                    next_task_ids='',
                    prev_task_ids='',
                    over_time=0,
                    name=new_task_name,
                    config=task_config_str,
                    retry_count=0,
                    last_run_time=now_time,
                    description="通过插件自动创建",
                    priority=5,
                    except_ret=0,
                    server_tag=server_tag)
            status, add_task = self.add_new_task_to_pipeline(
                    owner_id, 
                    new_task, 
                    None)
            if status != 0:
                return 1, add_task
            new_task = horae.models.Task.objects.get(
                    pl_id=dest_pl_id, 
                    name=new_task_name)
            return 0, new_task
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)

    def change_pipeline_owner(self, user_id, pl_id, new_owner_id):
        try:
            new_owners = django.contrib.auth.models.User.objects.filter(
                    id=new_owner_id)
            if len(new_owners) <= 0:
                raise exceptions.Exception("需要授权的用户不存在！")

            pipeline = horae.models.Pipeline.objects.get(id=pl_id)
            if pipeline.owner_id != user_id:
                raise exceptions.Exception("你不是流程的owner，不能修改owner为其他用户！")
            pipeline.owner_id = new_owner_id

            with django.db.transaction.atomic():
                if user_id != new_owner_id:
                    now_time = tools_util.StaticFunction.get_now_format_time(
                            "%Y-%m-%d %H:%M:%S")
                    perm_history = common.models.PermHistory(
                            resource_type=tools_util.CONSTANTS.PIPELINE,
                            resource_id=pl_id,
                            permission=\
                                tools_util.UserPermissionType.WRITE_STR,
                            applicant_id=user_id,
                            grantor_id=new_owner_id,
                            status=\
                                tools_util.AuthAction.GRANT_AUTH_TO_OTHER,
                            update_time=now_time,
                            create_time=now_time,
                            reason='add manager')
                    perm_history.save()

                pipeline.save()
            return 0, 'OK'
        except exceptions.Exception as ex:
            self.__log.error("execute sql failed![ex:%s][trace:%s]!" % (
                    str(ex), traceback.format_exc()))
            return 1, str(ex)
