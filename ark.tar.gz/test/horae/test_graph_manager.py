﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
测试

Authors: xielei.xl(lei.xie@shenma-inc.com)
"""

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import copy

import django.test
import horae.models
import common.models
import mock

import graph_manager
import tools_util
import django.contrib.auth.models
import common_logger

class TestGraphManager(django.test.TestCase):
    """
        测试graph manager接口
    """
    def setUp(self):
        config = ConfigParser.RawConfigParser()
        config.read("./conf/test.conf")

        tools_util.CONSTANTS.GLOBAL_STOP = True

        now_time = tools_util.StaticFunction.get_now_format_time("%H%m%d%H%M")
        horae.models.Pipeline.objects.create(
                id=1,
                name="a", 
                owner_id=1, 
                ct_time='0 1 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        horae.models.Processor.objects.create(
                id=1,
                name="a", 
                type=1,
                update_time='2015-05-05 10:00:00',
                owner_id=1)
        django.contrib.auth.models.User.objects.create(
                id=1,
                password='sdf',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')
        django.contrib.auth.models.User.objects.create(
                id=2,
                password='sdf1',
                last_login='2015-05-05 10:00:00',
                is_superuser=0,
                username='test_user2',
                first_name='xie',
                last_name='lei',
                email='lei.xie@shenma-inc.com',
                is_staff=0,
                is_active=1,
                date_joined='2015-05-05 10:00:00')

        self.__config = (
                "script_name = xl_test.py\n "
                "pre_script =\n "
                "post_script =\n "
                "args = xl_test.conf\n "
                "replace_confs = xl_test\n "
                "log_file = application.log\n "
                "check_data =\n "
                "_tpl = xl_test.conf.tpl\n "
                "_out = xl_test.conf\n "
                "output_file = ./%year%_%month%_%day%_%hour%_00@-1hour/*.log")

        horae.models.Task.objects.create(
                id=1,
                pl_id=1,
                pid=1,
                next_task_ids=',2,',
                prev_task_ids=',',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=2,
                pl_id=1,
                pid=1,
                next_task_ids=',3,',
                prev_task_ids=',1,',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=3,
                pl_id=1,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',2,',
                over_time=12,
                name='task_1',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Pipeline.objects.create(
                id=2,
                name="2", 
                owner_id=1, 
                ct_time='1 2 3 * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=3,
                name="3", 
                owner_id=1, 
                ct_time='1 5 * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=4,
                name="4", 
                owner_id=1, 
                ct_time='8 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=0)

        horae.models.Pipeline.objects.create(
                id=5,
                name="5", 
                owner_id=1, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        horae.models.Pipeline.objects.create(
                id=6,
                name="test_2_1", 
                owner_id=2, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=1)

        common.models.PermHistory.objects.create(
                id=1,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=6,
                permission='read',
                applicant_id=1,
                grantor_id=2,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')

        common.models.PermHistory.objects.create(
                id=2,
                resource_type=tools_util.CONSTANTS.PIPELINE,
                resource_id=5,
                permission='read',
                applicant_id=1,
                grantor_id=2,
                status=tools_util.AuthAction.CONFIRM_APPLY_AUTH,
                update_time='2015-06-19 10:00:00',
                create_time='2015-06-19 10:00:00',
                reason='test')

        horae.models.Pipeline.objects.create(
                id=7,
                name="test_2_2", 
                owner_id=2, 
                ct_time='1,2,3,4,5 * * * *', 
                life_cycle=12,
                update_time='2015-05-05 10:00:00',
                email_to="xielei@shenma-inc.com",
                description='hello',
                sms_to="123123123",
                monitor_way=1,
                enable=1,
                private=0)

        horae.models.Task.objects.create(
                id=4,
                pl_id=2,
                pid=1,
                next_task_ids='5,6',
                prev_task_ids=',',
                over_time=12,
                name='task_4',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=5,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4',
                over_time=12,
                name='task_5',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=7,
                pl_id=3,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_7',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=8,
                pl_id=4,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_8',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=9,
                pl_id=5,
                pid=1,
                next_task_ids=',6',
                prev_task_ids=',',
                over_time=12,
                name='task_9',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        horae.models.Task.objects.create(
                id=6,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',4,7,8,9',
                over_time=12,
                name='task_6',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=60,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_60',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')

        horae.models.Task.objects.create(
                id=160,
                pl_id=2,
                pid=1,
                next_task_ids=',',
                prev_task_ids=',',
                over_time=12,
                name='task_160',
                config=self.__config,
                retry_count=3,
                last_run_time='',
                description='')
        self.__horae_logger = common_logger.get_logger(
                "common", 
                "./log/horae")
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        graph_mgr._GraphGroup__graph.clear()
        graph_mgr._GraphGroup__sub_graph_list = []
        graph_mgr._GraphGroup__create_graph()

    def test_graph_manager_init(self):
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        sub_graph_list = graph_mgr._GraphGroup__sub_graph_list
        for graph in sub_graph_list:
            if graph.has_node('1'):
                self.assertTrue(graph.has_edge('1', '2'))
                self.assertTrue(graph.has_edge('2', '3'))
            if graph.has_node('4'):
                self.assertTrue(graph.has_edge('4', '5'))
                self.assertTrue(graph.has_edge('4', '6'))
                self.assertTrue(graph.has_edge('7', '6'))
                self.assertTrue(graph.has_edge('8', '6'))
                self.assertTrue(graph.has_edge('9', '6'))

    def test_graph_add_edge(self):
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        self.assertTrue(graph_mgr.add_edge('3', '20'))
        self.assertTrue(graph_mgr.add_edge('30', '20'))
        self.assertTrue(graph_mgr.add_edge('50', '60'))
        self.assertTrue(graph_mgr.add_edge('3', '4'))
        sub_graph_list = graph_mgr._GraphGroup__sub_graph_list
        for graph in sub_graph_list:
            if graph.has_node('60'):
                self.assertTrue(graph.has_edge('50', '60'))
            if graph.has_node('4'):
                self.assertTrue(graph.has_edge('1', '2'))
                self.assertTrue(graph.has_edge('2', '3'))
                self.assertTrue(graph.has_edge('3', '4'))
                self.assertTrue(graph.has_edge('3', '20'))
                self.assertTrue(graph.has_edge('4', '5'))
                self.assertTrue(graph.has_edge('4', '6'))
                self.assertTrue(graph.has_edge('7', '6'))
                self.assertTrue(graph.has_edge('8', '6'))
                self.assertTrue(graph.has_edge('9', '6'))

        self.assertFalse(graph_mgr.add_edge('5', '1'))

    def test_remove_edge(self):
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        self.assertTrue(graph_mgr.remove_edge('1', '2'))
        self.assertTrue(graph_mgr.remove_edge('2', '3'))
        self.assertTrue(graph_mgr.remove_edge('4', '5'))

        sub_graph_list = graph_mgr._GraphGroup__sub_graph_list
        tmp_edge_list = []
        tmp_node_list = []
        for graph in sub_graph_list:
            for edge in graph.edges():
                tmp_edge_list.append(edge)

            for node in graph.nodes():
                tmp_node_list.append(node)

        self.assertTrue('1' in tmp_node_list)
        self.assertTrue('2' in tmp_node_list)
        self.assertTrue('3' in tmp_node_list)
        self.assertTrue('4' in tmp_node_list)
        self.assertTrue('5' in tmp_node_list)
        self.assertTrue('6' in tmp_node_list)
        self.assertTrue('7' in tmp_node_list)
        self.assertTrue('8' in tmp_node_list)
        self.assertTrue('9' in tmp_node_list)
        self.assertTrue(('9', '6') in tmp_edge_list)
        self.assertTrue(('8', '6') in tmp_edge_list)
        self.assertTrue(('4', '6') in tmp_edge_list)
        self.assertTrue(('7', '6') in tmp_edge_list)

    def test_add_node(self):
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        self.assertTrue(graph_mgr.add_node('90'))
        self.assertFalse(graph_mgr.add_node('90'))
        sub_graph_list = graph_mgr._GraphGroup__sub_graph_list
        tmp_node_list = []
        for graph in sub_graph_list:
            for node in graph.nodes():
                tmp_node_list.append(node)

        self.assertTrue('90' in tmp_node_list)

    def test_remove_node(self):
        graph_mgr = graph_manager.GraphGroup(self.__horae_logger)
        self.assertTrue(graph_mgr.add_node('90'))
        self.assertTrue(graph_mgr.remove_node('90'))
        sub_graph_list = graph_mgr._GraphGroup__sub_graph_list
        tmp_node_list = []
        for graph in sub_graph_list:
            for node in graph.nodes():
                tmp_node_list.append(node)

        self.assertTrue('90' not in tmp_node_list)

