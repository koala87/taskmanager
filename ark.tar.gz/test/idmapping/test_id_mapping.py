﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2015 shenma-inc.com, Inc. All Rights Reserved
#
###############################################################################

import sys
import logging
import ConfigParser
import threading
import socket
import time
import datetime
import copy
import random

import django.test
import django.contrib.auth.models
from horae import common_logger
from idmapping.models import *
from idmapping.pipeline_process import *

class TestIdMapping(django.test.TestCase):
    def setUp(self):
        pass

    def test_get_app_group_list(self):
        result = offline_id_batch_mapping("data_managment_platform", "id_map6", "aliyun_serachlog_dev", "id_mapping_input_test", "day=20150727", "id", "imei", "aliyun_serachlog_dev", "id_mapping_output_test", "sm_id", "day=20150727", "", "create", ARK_COUNT,ARK_COUNT_PWD, ARK_IP, ARK_PORT)
        print result
        result = offline_id_batch_mapping("data_managment_platform", "id_map7", "aliyun_serachlog_dev", "id_mapping_input_test", "day=20150727", "id", "imei", "aliyun_serachlog_dev", "id_mapping_output_test", "sm_id", "day=20150727", "", "create", ARK_COUNT,ARK_COUNT_PWD, ARK_IP, ARK_PORT)
        print result
        #result = delete_id_batch_mapping("test_count", "id_map")
        #print result
        #result = delete_id_batch_mapping("test_count", "id_map2")
        #print result
        #result = re_mapping("test_count", "id_map")
        #print result
        #result = get_userinfo("test_count", 0, 1)
        #print result
        #result = get_userinfo("test_count", 0, 10)
        #print result
        #p = PipelineOperate(ARK_COUNT, ARK_COUNT_PWD, ARK_IP, ARK_PORT)
        #result = p.get_task_status("test_count_id_map", ID_MAPING_TASK)
        #result = get_userapp_info("test_count", "id_map")
        #print result
        #result = offline_id_batch_mapping("test_count", "id_map2", "aliyun_serachlog_dev", "id_mapping_input_test", "day=20150727", "id", "imei", "aliyun_serachlog_dev", "id_mapping_output_test", "sm_id", "day=20150727", "", "update", ARK_COUNT,ARK_COUNT_PWD, ARK_IP, ARK_PORT)
        #print result
        #result = offline_id_batch_mapping("test_count", "id_map3", "aliyun_serachlog_dev", "id_mapping_input_test", "day=20150727", "id", "imei", "aliyun_serachlog_dev", "id_mapping_output_test", "sm_id", "day=20150727", "", "update", ARK_COUNT,ARK_COUNT_PWD, ARK_IP, ARK_PORT)
        #print result
        #p = PipelineOperate(ARK_COUNT, ARK_COUNT_PWD, ARK_IP, ARK_PORT)
        #p.get_pipeline_id("data_managment_platform_imsi_to_smid")

    
        
