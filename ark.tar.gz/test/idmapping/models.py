from django.db import models

# Create your models here.

class IdMappingOnlineDb(models.Model):
    user_app = models.CharField(max_length=250, unique=True)
    pipeline_name = models.CharField(max_length=250)
    ark_count = models.CharField(max_length=250)
    app_name = models.CharField(max_length=1024)
    input_project = models.CharField(max_length=1024)
    input_col = models.CharField(max_length=1024)
    input_table = models.CharField(max_length=1024)
    input_id_type = models.CharField(max_length=1024)
    input_part = models.CharField(max_length=1024)
    output_project = models.CharField(max_length=1024)
    out_table = models.CharField(max_length=1024)
    output_id_type = models.CharField(max_length=1024)
    out_part = models.CharField(max_length=1024)
    app_description = models.CharField(max_length=1024)
    runtime_str = models.CharField(max_length=1024)
    status = models.CharField(max_length=1024)
