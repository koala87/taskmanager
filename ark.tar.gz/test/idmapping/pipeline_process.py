# -*- coding: utf8 -*-
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ark_tools.settings")
import sys
import json
import urllib
import traceback
import urllib2
import time

sys.path.append(".")
import django
#django.setup()
import django.db
import django.db.models
import django.core.exceptions
from django.db import transaction
from idmapping.models import *
from horae import common_logger

logger = common_logger.get_logger(
                "id_mapping_log",
                "./log/id_mapping")

#ARK_COUNT = "ark_dev"
#ARK_COUNT_PWD = "ark_123456_dev"
ARK_COUNT = "data_managment_platform"
ARK_COUNT_PWD = "ting0310"
ARK_IP = "10.99.16.60"
ARK_PORT = "10001"
ID_MAPING_TASK = "id_mapping"

result_construct = lambda status, info: "{\"status\":\"%s\", \"info\":\"%s\"}" % (status, info)

#error_result_construct = lambda status, info, error: "{\"status\":\"%s\", \"info\":\"%s\", \"error\":\"%s\"}" % (status, info, error)

def error_result_construct(status, info, error):
    d = {"status":status, "info": info, "error": error}
    return json.dumps(d)

def request_process(raw_request, retry_times = 3, sleep_time = 1):
    lines = ''
    err_flag = False
    for i in range(retry_times):
        try:
            lines = urllib2.urlopen(raw_request).readlines()
            err_flag = False
            break
        except urllib2.URLError:
            err_flag = True
            time.sleep(sleep_time)
    if True == err_flag:
        return (False, "connection error")
    if len(lines) < 1:
        return (False, "request get empty")
    content = lines[0]
    if not content:
        return (False, "empty_request")
    ret_dict = json.loads(json.loads(content))
    if ret_dict.has_key("status"):
        if 0 == ret_dict["status"]:
            return (True, content)
        return (False, content)
    return (False, content)

def construct_id_map_task_config(name, input_project, input_col, input_table, input_id_type, input_part, output_project, out_table, output_id_type, out_part, description="", priority=6):
    config_str = "input_project=%s\ninput_col=%s\ninput_table=%s\ninput_id_type=%s\ninput_part=%s\noutput_project=%s\nout_table=%s\noutput_id_type=%s\nout_part=%s" % (input_project, input_col, input_table, input_id_type, input_part, output_project, out_table, output_id_type, out_part)
    return {"processor_name":"single_column_batch_id_mapping", "over_time":500, "name":name, "config":config_str, "retry_count":3, "description":description, "priority":priority}

class PipelineOperate():
    def __init__(self, user_id, user_pwd, ip, port):
        self.user_id = user_id
        self.user_pwd = user_pwd
        self.ip = ip
        self.port = port
        self.http_tpl = "http://%s:%s/api/pipeline/auto_pipeline/" % (ip, port) + "%s/"

    def check_pipeline(self, pipeline_name):
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd":"get_pipeline", "name":pipeline_name}
        req_package = json.dumps(req_dict)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        return request_process(raw_request)

    def get_pipeline_id(self, pipeline_name):
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd":"get_pipeline", "name":pipeline_name}
        req_package = json.dumps(req_dict)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        ret, info = request_process(raw_request)
        pipe_info = json.loads(json.loads(info))
        if ret:
            logger.info("pipeline_id:%s" %  pipe_info["pipeline"]["id"])
            return pipe_info["pipeline"]["id"] 
        else:
            return "-1"
        
    def add_task_to_pipeline(self, pipeline_name, task_config):
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd":"add_task", "pipeline_name":pipeline_name, "task":task_config}
        req_package = json.dumps(req_dict)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        return request_process(raw_request)
        
    def run_pipeline(self, pipeline_name, run_time_str):
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd": "run_pipeline", "pipeline_name":pipeline_name, "run_time":run_time_str}
        req_package = json.dumps(req_dict)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        return request_process(raw_request)
    
    def stop_pipeline(self, pipeline_name, run_time_str=''):
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd": "stop_pipeline", "pipeline_name":pipeline_name, "run_time":run_time_str}
        req_package = json.dumps(req_dict)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        return request_process(raw_request)
    
    def delete_pipeline(self, pipeline_name):
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd": "delete_pipeline", "name":pipeline_name}
        req_package = json.dumps(req_dict)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        return request_process(raw_request)

    def create_pipeline(self, pipeline_name, auto_run, owners_name_list, description = '', ct_time = '',  tag = '', monitor_way = 0):
        owners_name_str = ','.join(owners_name_list) 
        print "ownner user: %s" % owners_name_str
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd": "create_pipeline", "name":pipeline_name, "ct_time":ct_time, "enable":auto_run, "ct_time":ct_time, "monitor_way":monitor_way, "owners_name":owners_name_str, "description": description}
        req_package = json.dumps(req_dict)
        logger.info("create_pipeline_request:%s" % req_package)
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        return request_process(raw_request)

    def get_task_status(self, pipeline_name, task_name, run_time_str = ''):
        req_dict = {"username":self.user_id, "password":self.user_pwd, "cmd": "get_pipeline_last_status", "pipeline_name":pipeline_name}
        req_package = json.dumps(req_dict) 
        enquote_req_packge = urllib2.quote(req_package.encode("gbk"))
        raw_request = self.http_tpl % enquote_req_packge
        status, content = request_process(raw_request)
        ret_dict = json.loads(json.loads(content))
        if not status:
            return result_construct(1, "3")
        for task_info in ret_dict["task_list"]:
            if task_info["task_name"] == task_name:
                return result_construct(0, task_info["status"])
        return result_construct(1, "3")



@transaction.atomic
def offline_id_batch_mapping(ark_count, app_name, 
                             input_project, input_table,input_part,
                             input_col, input_id_type, 
                             output_project, out_table, 
                             output_id_type, out_part, 
                             app_description, action,
                             run_count = ARK_COUNT, run_pw = ARK_COUNT_PWD, 
                             ip = ARK_IP, port = ARK_PORT):
    try:
        if not ark_count or not app_name:
            logger.info("ark_count = %s, app_name  = %s" % (ark_count, app_name))
            return result_construct(1, "ark_count or app_name is empty")
        pipeline_name = "%s_%s" % (ark_count, app_name)
        p = PipelineOperate(run_count, run_pw, ip, port)
        #check pipeline wether exists, if exists, stop and delete
        ret, info = p.check_pipeline(pipeline_name)
        if ret:
            ret, info =  p.stop_pipeline(pipeline_name)
            logger.info("stop_pipeline:ret=%s,info=%s" % (ret, info))
            ret, info = p.delete_pipeline(pipeline_name)
            logger.info("delete_pipeline:%s,%s" % (ret, info))
            if not ret:
                logger.error("stop_pipeline:ret=%s,info=%s" % (ret, info))
                return result_construct(1, "pipeline %s has exists, but can not delete!" % pipeline_name)
        #create pipeline
        pipeline_description = "create offline batch id mapping pipeline %s for user:%s, app:%s" % (pipeline_name, ark_count, app_name)
        ret, info = p.create_pipeline(pipeline_name, 0, [ark_count, run_count], pipeline_description)
        if not ret:
            logger.error("create_pipeline:%s,%s" % (ret, info))
            return error_result_construct(1, "create pipeline %s failed!"% (pipeline_name), info)
        #add task to pipeline
        task_name = ID_MAPING_TASK
        task_config_dict = construct_id_map_task_config(task_name, input_project, input_col, input_table, input_id_type, input_part, output_project, out_table, output_id_type, out_part, description="id mapping", priority=6)
        ret, info = p.add_task_to_pipeline(pipeline_name, task_config_dict)
        logger.info("add_task:%s,%s" % (ret, info))
        if not ret:
            return error_result_construct(1, "add task %s to %s failed!" % (task_name, pipeline_name), task_config_dict)
        #run pipeline
        run_time_str = time.strftime("%Y%m%d%H%M%S", time.localtime())
        ret, info = p.run_pipeline(pipeline_name, run_time_str)
        logger.info("run_pipeline:%s,%s" % (ret, info))
        if not ret:
            return error_result_construct(1, "run pipeline %s by time %s failed!" % (pipeline_name, run_time_str), info)
        idmappingOnlineDb = IdMappingOnlineDb()
        if "update" == action:
            obj_set = IdMappingOnlineDb.objects.filter(user_app = "%s_%s" % (ark_count, app_name))
            if len(obj_set) > 0:
               idmappingOnlineDb = obj_set[0]
        idmappingOnlineDb.user_app = "%s_%s" % (ark_count, app_name)
        idmappingOnlineDb.pipeline_name = pipeline_name
        idmappingOnlineDb.ark_count = ark_count
        idmappingOnlineDb.app_name = app_name
        idmappingOnlineDb.input_project = input_project
        idmappingOnlineDb.input_col = input_col
        idmappingOnlineDb.input_table = input_table
        idmappingOnlineDb.input_id_type = input_id_type
        idmappingOnlineDb.input_part = input_part
        idmappingOnlineDb.output_project = output_project
        idmappingOnlineDb.out_table = out_table
        idmappingOnlineDb.output_id_type = output_id_type
        idmappingOnlineDb.out_part = out_part
        idmappingOnlineDb.app_description = app_description
        idmappingOnlineDb.runtime_str = run_time_str 
        idmappingOnlineDb.status = ''
        idmappingOnlineDb.save()
        if "update" == action:
            logger.info("update success")
        else:
            logger.info("create pipeline success")
        return result_construct(0, "success")
    except BaseException, e:
        info = traceback.format_exc()
        return result_construct(1, "pipeline has been created, app name duplicated!")

@transaction.atomic
def delete_id_batch_mapping(ark_count, app_name, run_count = ARK_COUNT, run_pw = ARK_COUNT_PWD, ip = ARK_IP, port = ARK_PORT):
    try:
        if not ark_count or not app_name:
            logger.info("ark_count = %s, app_name = %s" % (ark_count, app_name))
            return result_construct(1, "ark_count or app_name is empty")
        pipeline_name = "%s_%s" % (ark_count, app_name)
        p = PipelineOperate(run_count, run_pw, ip, port)
        ret, info = p.check_pipeline(pipeline_name)
        if ret:
            ret, info =  p.stop_pipeline(pipeline_name)
            logger.info("stop_pipeline:ret=%s,info=%s" % (ret, info))
            ret, info = p.delete_pipeline(pipeline_name)
            logger.info("delete_pipeline:%s,%s" % (ret, info))
            if not ret:
                logger.info("stop_pipeline:ret=%s,info=%s" % (ret, info))
                return result_construct(1, "pipeline %s has exists, but can not delete!" % pipeline_name)
        obj_set = IdMappingOnlineDb.objects.filter(user_app="%s_%s" % (ark_count, app_name), pipeline_name = pipeline_name, ark_count = ark_count)
        if len(obj_set) > 0:
            obj_set[0].delete()
        return result_construct(0, "delete %s, %s success" % (ark_count, app_name))
    except BaseException, e:
        info = traceback.format_exc()
        logger.error("delete exception:%s" % info)
        return result_construct(1, "delete exception")

@transaction.atomic
def re_mapping(ark_count, app_name, run_count = ARK_COUNT, run_pw = ARK_COUNT_PWD, ip = ARK_IP, port = ARK_PORT):
    try:
        if not ark_count or not app_name:
            return result_construct(1, "ark_count pr app_name is empty")
        pipeline_name = "%s_%s" % (ark_count, app_name)
        p = PipelineOperate(run_count, run_pw, ip, port)
        ret, info = p.check_pipeline(pipeline_name)
        if ret:
            ret, info =  p.stop_pipeline(pipeline_name)
            logger.info("stop_pipeline:ret=%s,info=%s" % (ret, info))
        run_time_str = time.strftime("%Y%m%d%H%M%S", time.localtime())
        ret, info = p.run_pipeline(pipeline_name, run_time_str)
        if ret:
            data_obj = IdMappingOnlineDb.objects.get(user_app = "%s_%s" % (ark_count, app_name), pipeline_name = pipeline_name, ark_count = ark_count)
            data_obj.runtime_str = run_time_str
            data_obj.save()
        else:
            return result_construct(1, "run task error!")
            logger.error("remapping failed")
        logger.info("remapping success")
        return result_construct(0, "re mapping ark_count=%s, app_name=%s, time=%s success" % (ark_count, app_name, run_time_str))
    except BaseException, e:
        info = traceback.format_exc()
        logger.error(info)
        return result_construct(1, "remapping exception")

def parse_idmappingonlinedb_obj(db_obj, task_name = ID_MAPING_TASK):
    result_dict = {}
    result_dict["user_app"] = db_obj.user_app 
    result_dict["pipeline_name"] = db_obj.pipeline_name
    result_dict["ark_count"] = db_obj.ark_count
    result_dict["app_name"] = db_obj.app_name
    result_dict["input_project"] = db_obj.input_project
    result_dict["input_col"] = db_obj.input_col
    result_dict["input_table"] = db_obj.input_table
    result_dict["input_id_type"] = db_obj.input_id_type
    result_dict["input_part"] = db_obj.input_part
    result_dict["output_project"] = db_obj.output_project
    result_dict["out_table"] = db_obj.out_table
    result_dict["output_id_type"] = db_obj.output_id_type
    result_dict["out_part"] =  db_obj.out_part
    result_dict["app_description"] = db_obj.app_description
    result_dict["runtime_str"] = db_obj.runtime_str 
    #TODO get status by lei.xie
    p = PipelineOperate(ARK_COUNT, ARK_COUNT_PWD, ARK_IP, ARK_PORT)
    pipeline_name = db_obj.user_app
    #result = p.get_task_status(pipeline_name, ID_MAPING_TASK)
    ret = p.get_task_status(pipeline_name, ID_MAPING_TASK)
    logger.info("run_satus:%s" % ret)
    ret_dict = json.loads(ret)
    if "0" == ret_dict["status"]:
        result_dict["status"] = ret_dict["info"]
    else:
        result_dict["status"] = "unknown"
    return result_dict

def get_n_result(data_list, start_index, num):
    data_len = len(data_list)
    offset = start_index + num
    if start_index < 0:
        return []
    if data_len >= offset:
        return data_list[start_index : offset]
    if start_index < data_len and data_len <= offset:
        return data_list[start_index : ]
    return []

#user_info_construct = lambda status, info, len: {"status":"%s", "info":%s\", \"len\": \"%s\"} % (status, info, len)
def user_info_construct(status, info, len):
    return json.dumps({"status" : status, "info": info, "len":len})


@transaction.atomic
def get_userinfo(ark_count, start = 0, limit = 10):
    if not ark_count:
        logger.info(result_construct(1, "ark_count is empty"))
        return result_construct(1, "ark_count is empty")
    try:
         data_list = IdMappingOnlineDb.objects.filter(ark_count=ark_count)
         result_list = []
         for db_obj in data_list:
             d = parse_idmappingonlinedb_obj(db_obj)
             result_list.append(d)
         result_list.sort(key = lambda v: v["runtime_str"], reverse = True)
         total_len = len(result_list)
         result_list = get_n_result(result_list, start, limit)
         #info_str = json.dumps(result_list)
         logger.info(user_info_construct(0, result_list, total_len))
         return user_info_construct(0, result_list, total_len)
    except BaseException, e:
        info = traceback.format_exc()
        logger.error(info)
        return result_construct(1, "get user info exception")

@transaction.atomic
def get_userapp_info(ark_count, app_name):
    try:
        if not ark_count or not app_name:
            return result_construct(1, "ark_count pr app_name is empty")
        user_app = "%s_%s" % (ark_count, app_name)
        logger.info("get info for: %s" % user_app)
        obj_set = IdMappingOnlineDb.objects.filter(user_app = user_app)
        if len(obj_set) > 0:
            result_dict = parse_idmappingonlinedb_obj(obj_set[0])
            #return result_construct(0, json.dumps(result_dict)) 
            return user_info_construct(0, result_dict, 1)
        return result_construct(1, "no info for user:%s , app:%s" % (ark_count, app_name))
    except BaseException, e:
        info = traceback.format_exc()
        logger.error(info)
        return result_construct(1, "get user_app_info error")

if "__main__" == __name__:
    pass
    #result = offline_id_batch_mapping("test_count", "id_map", "aliyun_serachlog_dev", "id_mapping_input_test", "day=20150727", "id", "imei", "aliyun_serachlog_dev", "id_mapping_output_test", "sm_id", "day=20150727", "", ARK_COUNT,ARK_COUNT_PWD, ARK_IP, ARK_PORT)
    #print result
    #result = offline_id_batch_mapping("test_count", "id_map2", "aliyun_serachlog_dev", "id_mapping_input_test", "day=20150727", "id", "imei", "aliyun_serachlog_dev", "id_mapping_output_test", "sm_id", "day=20150727", "", ARK_COUNT,ARK_COUNT_PWD, ARK_IP, ARK_PORT)
    #result = delete_id_batch_mapping("test_count", "id_map")
    #print result
    #result = delete_id_batch_mapping("test_count", "id_map2")
    #print result
    #result = re_mapping("test_count", "id_map")
    #print result
    #result = get_userinfo("test_count")
    #print result
    #p = PipelineOperate(ARK_COUNT, ARK_COUNT_PWD, ARK_IP, ARK_PORT)
    #result = p.get_task_status("test_count_id_map", ID_MAPING_TASK)

    
