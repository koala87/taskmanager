# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='IdMappingOnlineDb',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('user_app', models.CharField(unique=True, max_length=250)),
                ('pipeline_name', models.CharField(max_length=250)),
                ('ark_count', models.CharField(max_length=250)),
                ('app_name', models.CharField(max_length=1024)),
                ('input_project', models.CharField(max_length=1024)),
                ('input_col', models.CharField(max_length=1024)),
                ('input_table', models.CharField(max_length=1024)),
                ('input_id_type', models.CharField(max_length=1024)),
                ('input_part', models.CharField(max_length=1024)),
                ('output_project', models.CharField(max_length=1024)),
                ('out_table', models.CharField(max_length=1024)),
                ('output_id_type', models.CharField(max_length=1024)),
                ('out_part', models.CharField(max_length=1024)),
                ('app_description', models.CharField(max_length=1024)),
                ('runtime_str', models.CharField(max_length=1024)),
                ('status', models.CharField(max_length=1024)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
