import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ark_tools.settings")
import sys
cur_path = os.getcwd()
sys.path.append(cur_path)
import json
import datetime
from django.contrib.auth import authenticate
from django.conf import settings
from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core import serializers
from common.http_helper import *
from common.odps import Odps
from common.odps import OdpsPrivilege
from common.models import PermHistory,Message
from common.convert_time import *
from common.models import PermHistory
from common.ark_perm import UserPerm
from ark_user.models import Info
from django.contrib.auth.decorators import login_required
from idmapping import pipeline_process

#logger = logging.getLogger(settings.PROJECT_NAME)
from horae import common_logger

logger = common_logger.get_logger(
                "id_mapping_log",
                "./log/id_mapping")




@login_required(login_url='/login/')
def create_offline(request):
    #logger.info("create before post")
    if request.method == 'POST':
        ark_count = request.POST.get('ark_count')
        #logger.info(ark_count)
        app_name = request.POST.get('app_name')
        #logger.info(app_name)
        input_project = request.POST.get('input_project')
        #logger.info(input_project)
        input_table = request.POST.get('input_table')
        #logger.info(input_table)
        input_part = request.POST.get('input_part')
        #logger.info(input_part)
        input_col = request.POST.get('input_col')
        #logger.info(input_col)
        input_id_type = request.POST.get('input_id_type')
        #logger.info(input_id_type)
        output_project = request.POST.get('output_project')
        #logger.info(output_project)
        out_table = request.POST.get('out_table')
        #logger.info(out_table)
        output_id_type = request.POST.get('output_id_type')
        #logger.info(output_id_type)
        out_part = request.POST.get('out_part')
        #logger.info(out_part)
        app_description = request.POST.get('app_description')
        action = request.POST.get('action')
        #logger.info(app_description)
        #logger.info("create before call")
        result_str = pipeline_process.offline_id_batch_mapping(ark_count, app_name, 
                                 input_project, input_table,
                                 input_part, input_col, 
                                 input_id_type, output_project, 
                                 out_table, output_id_type,
                                 out_part, app_description,
                                 action)
        #logger.info(result_str)
        return HttpResponse(result_str)
    #logger.info("create out")
    return HttpResponse(json.dumps({'status':'1', 'info':'use post method'}))

@login_required(login_url='/login/')
def delete_offline(request):
    if request.method == 'POST':
        ark_count = request.POST.get('ark_count')
        app_name = request.POST.get('app_name')
        result = pipeline_process.delete_id_batch_mapping(ark_count, app_name)
        return HttpResponse(result)
    return HttpResponse(json.dumps({'status':'1', 'info':'use post method'}))

@login_required(login_url='/login/')
def re_mapping(request):
    if request.method == 'POST':
        ark_count = request.POST.get('ark_count')
        app_name = request.POST.get('app_name')
        result = pipeline_process.re_mapping(ark_count, app_name)
        return HttpResponse(result)
    return HttpResponse(json.dumps({'status':'1', 'info':'use post method'}))

@login_required(login_url='/login/')
def get_user_info(request):
    #logger.info("before post")
    if request.method == 'POST':
        ark_count = request.POST.get('ark_count')
        start_index = request.POST.get('start_index')
        get_number = request.POST.get('get_number')
        #logger.info(" %s %s %s" % (ark_count, start_index, get_number))
        result = pipeline_process.get_userinfo(ark_count, int(start_index), int(get_number))
        #logger.info("\n\n\n%s\n\n\n" % result)
        return HttpResponse(result)
    #logger.info("out")
    return HttpResponse(json.dumps({'status':'1', 'info':'use post method'}))


@login_required(login_url='/login/')
def get_user_app_info(request):
    logger.info("in get_user_app_info")
    if request.method == 'POST':
        logger.info("in get_user_app_info post")
        ark_count = request.POST.get('ark_count')
        app_name = request.POST.get('app_name')
        logger.info("%s_%s" % (ark_count, app_name))
        result = pipeline_process.get_userapp_info(ark_count, app_name)
        return HttpResponse(result)
    logger.info("out")
    return HttpResponse(json.dumps({'status':'1', 'info':'use post method'}))
