from django.conf.urls import patterns, url
from idmapping import views

urlpatterns = patterns('',
    url(r'^createoffline/$',views.create_offline),
    url(r'^deleteoffline/$',views.delete_offline),
    url(r'^remapping/$', views.re_mapping),
    url(r'^getuserinfo/$', views.get_user_info),
    url(r'^getuserappinfo/$', views.get_user_app_info),
)

