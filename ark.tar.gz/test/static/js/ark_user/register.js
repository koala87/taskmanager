$(function() {
    $("#id_email").change(function(){
        var arr = new Array();
        var email = $("#id_email").val();
        if(email != '' ) {
            var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            valid_result = filter.test(email)
            if (valid_result){
                arr = email.split("@");
                $("#id_username").val(arr[0]);
            }
        }
});
})
