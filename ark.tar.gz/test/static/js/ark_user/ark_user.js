$(function () {
    var change_password_modal = $("div[name=change_password_modal");

    window.Account = {
        register: function(btn_register) {
            var box = btn_register.parents("[name=register_box]").first();
            var items = ["email", "username", "password"];
            var data = {};
            for(var i = 0; i < items.length; i++) {
                var key = items[i];
                data[key] = box.find("input[name=" + key + "]").val();
            }
            data["bind_vpn"] = box.find("input[name=bind_vpn]").is(":checked");

            captcha = Captcha.get(box);
            for(key in captcha) {
                data[key] = captcha[key];
            }

            var url = "/ark_user/register/?next=" 
                + ($.urlParam("next") ? $.urlParam("next") : "")
                + "&user_info=" + $.urlParam("user_info");
            var result = makeAPost(url, data);
            ark_notify(result);
            if(result.status != 0) {
                Captcha.refresh(box.find("img.captcha"));
            } else {
                window.location = result.next ? result.next : $.urlParam("next") || "/";
            }
        },
        login: function(btn_login) {
            var box = btn_login.parents("[name=login_box]").first();
            var items = ["username", "password"];
            var data = {};
            for(var i = 0; i < items.length; i++) {
                var key = items[i];
                data[key] = box.find("input[name=" + key + "]").val();
            }
            data["bind_vpn"] = box.find("input[name=bind_vpn]").is(":checked");

            captcha = Captcha.get(box);
            for(key in captcha) {
                data[key] = captcha[key];
            }

            var url = "/ark_user/login/?next=" 
                + ($.urlParam("next") ? $.urlParam("next") : "")
                + "&user_info=" + $.urlParam("user_info");
            var result = makeAPost(url, data);
            ark_notify(result);
            if(result.status != 0) {
                Captcha.refresh(box.find("img.captcha"));
            } else {
                window.location = result.next ? result.next : $.urlParam("next") || "/";
            }
        },
        resetPassword: function(btn_reset) {
            var box = btn_reset.parents("[name=reset_password_box]").first();
            var items = ["email", "username"];
            var data = {};
            for(var i = 0; i < items.length; i++) {
                var key = items[i];
                data[key] = box.find("input[name=" + key + "]").val();
            }

            captcha = Captcha.get(box);
            for(key in captcha) {
                data[key] = captcha[key];
            }

            var url = "/ark_user/reset_password/";
            var result = makeAPost(url, data);
            ark_notify(result);
            if(result.status != 0) {
                Captcha.refresh(box.find("img.captcha"));
            } else {
                window.location = $.urlParam("next") ? $.urlParam("next") : "/login/?vpn_auto_login=0";
            }
        },
        beginChangePassword: function() {
            change_password_modal.modal().show();
        },
        changePassword: function(btn_change) {
            var modal = btn_change.parents("[name=change_password_modal]").first();
            var items = ["old_password", "new_password"];
            var data = {};
            for(var i = 0; i < items.length; i++) {
                var key = items[i];
                data[key] = modal.find("#" + key).val();
            }

            captcha = Captcha.get(modal);
            for(key in captcha) {
                data[key] = captcha[key];
            }

            var url = "/ark_user/change_password/";
            var result = makeAPost(url, data);
            ark_notify(result);
            if(result.status != 0) {
                Captcha.refresh(modal.find("img.captcha"));
            } else {
                modal.modal('toggle');
            }
        }
    }

    $("[name=register_box] [name=username]").focus(function(){
        if($(this).val()) {
            return;
        }

        var arr = new Array();
        var email = $("[name=register_box] [name=email]").val();
        if(email != '' ) {
            var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var valid_result = filter.test(email)
            if (valid_result){
                var arr = email.split("@");
                $(this).val(arr[0]);
            }
        }
    });
});

$(function() {
    $("img.captcha").each(
        function() {
            $(this).click(function() {
                Captcha.refresh($(this));
            });
        }
    );

    document.onkeydown = function(e){
        if(!e){
            e = window.event;
        }
        if((e.keyCode || e.which) == 13){
            console.log(window.location.pathname);
            if(window.location.pathname == '/login/') {
                Account.login($("[name=login_box] button"));
            } else if(window.location.pathname == '/register/') {
                Account.register($("[name=register_box] button"));
            } else if(window.location.pathname == '/resetpassword/') {
                Account.resetPassword($("[name=reset_password_box] button"));
            }
        }
    }

});
