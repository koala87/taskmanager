$(function() {
    $("#reset_pwd_btn").click(function(){
        var url = "/resetpassword/" ;
        var param = $("#reset_pwd_form").serialize();
        $("#reset_pwd_busy").show();
        $.ajax({
            type :'post',
            url : url,
            dataType:"json",
            data : param,
            success : function(result) {
                //console.log(result.status,result.msg);
                if(result.status){
                    //fail show red style
                    $("#dialog_content_css").removeClass("panel panel-green");
                    $("#dialog_content_css").addClass("panel panel-red");
                    $("#result_button").removeClass("btn btn-success");
                    $("#result_button").addClass("btn btn-danger");
                    $("#dialog_content").html(result.msg);
                    $("#reset_pwd_dialog").modal("show");
                }else{
                    //success  show normal style
                    $("#dialog_content_css").removeClass("panel panel-red");
                    $("#dialog_content_css").addClass("panel panel-green");
                    $("#result_button").removeClass("btn btn-danger");
                    $("#result_button").addClass("btn btn-success");
                    $("#dialog_content").html(result.msg);
                    $("#reset_pwd_dialog").modal("show");
                    //成功后返回登录页
                    $('#reset_pwd_dialog').on('hide.bs.modal', function () {
                            window.location.href="/login";
                        }
                    );
                }
                $("#reset_pwd_busy").hide();
            }
        });
    });
});
