$(function() {
    $("#id_username").attr("readonly","readonly");
    //$("#id_email").attr("readonly","readonly");
})
