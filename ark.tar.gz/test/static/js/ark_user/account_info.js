$(function() {
    var ele_view = $("div[name=basic_info_view]");
    var ele_edit = $("div[name=basic_info_edit]");
    var keys_can_update = ['username', 'email', 'odps_access_id', 'odps_access_key',
                           'odps_dxp_account', 'job_user_key', 'ali_monitor', 'odps_project', 'owner_projects'];
    window.AccountInfo = {
        update: function(info_data, callback_func, ele) {
            var url = "/ark_user/update_basic_info/";
            return makeAPost(url, info_data, true, callback_func, ele, info_data);
        },
    }
    
    window.AccountInfoUi = {
        collectData: function(ele, view_or_edit) {
            var info_data = {};
            for(var key of keys_can_update) {
                var item = ele.find("[name=" + key + "]");
                var value = view_or_edit == "view" ? item.html() : item.val();
                info_data[key] = value;
            }
            return info_data;
        },
        initData: function(ele, data, view_or_edit) {
            for(var key of keys_can_update) {
                var item = ele.find("[name=" + key + "]");
                if(view_or_edit == "view") {
                    item.html(data[key]);
                } else {
                    item.val(data[key]);
                }
            }
            if(view_or_edit == "view") {
                var ele_switch = ele.find("a[name=switch_access_key_dsp]");
                if(ele_switch.attr("value") == 1) {
                    ele_switch.trigger("click");
                }
            }
        },
        finishUpdate: function(result, ele, info_data) {
            ele.button('reset');
            if(result.status == 0) {
                AccountInfoUi.initData(ele_view, info_data, "view");
                ele_edit.hide();
                ele_view.show();
            }
            ark_notify(result);
        },
        save: function(btn) {
            var info_data = AccountInfoUi.collectData(ele_edit, "edit");
            if(!info_data) {
                return;
            }

            btn.button('loading');
            result = AccountInfo.update(info_data, AccountInfoUi.finishUpdate, btn);

        },
        cancel: function() {
            ele_edit.hide();
            ele_view.show();
        },
        edit: function() {
            info_data = AccountInfoUi.collectData(ele_view, "view");
            AccountInfoUi.initData(ele_edit, info_data, "edit")
            ele_edit.show();
            ele_view.hide();
        },
        switchAccessKeyDsp: function(switcher) {
            var value = switcher.attr("value");
            var ele_key_dsp = switcher.parent().find("[name=odps_access_key_dsp]");
            if(value == 0) {
                var ele_key = switcher.parent().find("[name=odps_access_key]");
                ele_key_dsp.html(ele_key.html());
                switcher.html("隐藏");
            } else {
                ele_key_dsp.html("******");
                switcher.html("显示");
            }
            switcher.attr("value", 1 ^ value);
        }
    }
    
    $("a[name=switch_access_key_dsp]").click(function() {
        AccountInfoUi.switchAccessKeyDsp($(this));
    });
});


