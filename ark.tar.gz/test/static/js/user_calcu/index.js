var table_task_list = null;
$(function(){
    get_task_list();
	setInterval( function(){refresh_table(false);}, 60000);
    $('#table_task_list').on('click', ' tbody td .row-details', function () {
        if($(this).hasClass('row-details-close'))
        {
            $(this).removeClass("row-details-close").addClass('row-details-open');
            $("#table_task_list_processing").show();
            display_calcu_res($(this));
        }
        else
        {
            $(this).removeClass("row-details-open").addClass('row-details-close');
            $(this).parent().parent().next().remove();
            $(this).parent().parent().next().remove();
            $(this).parent().parent().next().remove();
        }
    });
    $('#upsertTaskModal').on('show.bs.modal', function (e) {
        //if($("#s2id_source_data_name").length < 1)
        {
            var url = '/user_calcu/get_data_name_list/';
            var post_data = {};
            var callback = callback_append_data_select2;
            var args = {};
            makeAPost(url, post_data, true, callback, args);
        }
    });
    $('[data-toggle="tooltip"]').tooltip();
});
function callback_append_data_select2(result, args)
{
    //result = {status:0,'data_list':['aaa','bbb']};
    if(result.status == 0)
    {
        var data = [];
        for(i in result.data_list)
        {
            //$("#source_data_name").append('<option value="'+result.data_list[i]+'">'+result.data_list[i]+'</option>');
            //$("#dst_data_name").append('<option value="'+result.data_list[i]+'">'+result.data_list[i]+'</option>');
            data.push({'id':result.data_list[i], 'text':result.data_list[i]});
        }
        if($("#source_data_name").val().trim() != '' && result.data_list.indexOf($("#source_data_name").val().trim()) < 0)
        {
            data.push({'id':$("#source_data_name").val().trim(), 'text':$("#source_data_name").val().trim()});
        }
        if($("#dest_data_name").val().trim() != '' && result.data_list.indexOf($("#dest_data_name").val().trim()) < 0)
        {
            data.push({'id':$("#dest_data_name").val().trim(), 'text':$("#dest_data_name").val().trim()});
        }
        $("#source_data_name, #dest_data_name").select2({data: data,
            createSearchChoice:function(term, data) {
                if ($(data).filter(function() {
                    return this.text.localeCompare(term)===0;
                }).length===0) {
                    return {id:term, text:term};
                }
            }
        }).on('select2-open', function(e) {
                            var input = $(".select2-drop.select2-display-none.select2-with-searchbox.select2-drop-active input");
                            console.log(input);
                            input.val($(this).val());
                        });
        //$("#source_data_name").select2("val", empty_value);
    }
}

function get_task_list() {
    table_task_list = $('#table_task_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/user_calcu/list/",
            "type": "POST",
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "",
            bSortable: false
        }, {
            data: "data_name_src",
            bSortable: false
        }, {
            data: "data_name_dst",
            bSortable: false
        }, {
            data: "run_time",
            bSortable: false
        }, {
            data: "run_status",
            bSortable: false
        }, {
            data: "run_result",
            bSortable: false
        }, {
            data: "run_status",
            bSortable: false
        }],
                
        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    return '<span class="row-details row-details-close" action-data="'+full.id+'" style="width:100%"></span>';
                },
            },
            {
                "targets":[1,2],
                "render":function(data,type,full){
                    return '<span title="'+data+'">'+data+'</span';
                },
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    return show_status_dsp(full);
                 }
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    return data.result == undefined ? '暂无' : data.result;
                },
            },
            {
                "targets":[6],
                "render":function(data,type,full){
                    var ret = '';
                    if(data == 1)
                    {
                        ret = '<a href="javascript:" action-data=\''+JSON.stringify(full).replace(new RegExp(/\'/g), '\$')+'\' onclick="cancel_task(this)">取消</a>';
                    }
                    else
                    {
                        ret = '<a href="javascript:" action-data=\''+JSON.stringify(full).replace(new RegExp(/\'/g), '\$')+'\' onclick="rerun(this)">重新执行</a>';
                    }
                    if(is_admin)
                    {
                        ret += '<a class="a_pipeline_view" href="/pipeline/history/'+full.pl_name+'/" target="_blank">查看流程</a>';
                    }
                    return ret;
                },
            },
        ]

    });
}
function add_task()
{
    $("#source_data_name").val('');
    $("#source_data_name").select2('val', '');
    $("#dest_data_name").val(''); 
    $("#dest_data_name").select2('val', ''); 
    $("#source_partition").val('');
    $("#dest_partition").val(''); 
    $("#source_uid_col").val(''); 
    $("#dest_uid_col").val(''); 
    $("#source_user_type").val(''); 
    $("#dest_user_type").val(''); 

    //外部链入
    if(data_detail.name != undefined)
    {
        $("#source_data_name").val(data_detail.name);
        $("#source_partition").val(data_detail.path.split(':')[2] == undefined ? '' : data_detail.path.split(':')[2]);
        $("#source_uid_col").val(data_detail.uid_column == undefined ? '' : data_detail.uid_column);
        $("#source_user_type").val(data_detail.uid_type == undefined ? '' : data_detail.uid_type);
        var stateObject = {};
        var title = "重合度计算工具";
        var newUrl = location.origin+location.pathname;
        history.pushState(stateObject,title,newUrl);
        data_detail = {};
    }
    $("#upsertTaskModal").modal('show');
}
function display_calcu_res(obj)
{
    var url = '/user_calcu/detail/';
    var post_data = {id:obj.attr('action-data')};
    var callback = callback_display_calcu_res;
    var args = {obj:obj};
    makeAPost(url, post_data, true, callback, args);
}
function callback_display_calcu_res(result, args)
{
    $("#table_task_list_processing").hide();
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    var html = '<tr class="row_detail"><td></td>';
    html += '<td>partition: '+result.detail.partition_src+'</td>';
    html += '<td>partition: '+result.detail.partition_dst+'</td><td></td><td></td>';
    html += '<td>源数据用户: '+(result.detail.run_result.source_user_num == undefined ? '暂无' : result.detail.run_result.source_user_num)+'</td>';
    html += '</tr>';
    html += '<tr class="row_detail"><td></td>';
    html += '<td>用户标识列: '+result.detail.uid_col_src+'</td>';
    html += '<td>用户标识列: '+result.detail.uid_col_dst+'</td><td></td><td></td>';
    html += '<td>目标数据用户: '+(result.detail.run_result.dest_user_num == undefined ? '暂无' : result.detail.run_result.dest_user_num)+'</td>';
    html += '</tr>';
    html += '<tr class="row_detail"><td></td>';
    html += '<td>标识类型: '+result.detail.uid_type_src+'</td>';
    html += '<td>标识类型: '+result.detail.uid_type_dst+'</td><td></td><td></td>';
    html += '<td>重合用户: '+(result.detail.run_result.repeatabe_user_num == undefined ? '暂无' : result.detail.run_result.repeatabe_user_num)+'</td>';
    html += '</tr>';
    var tr_obj = args['obj'].parent().parent().after(html);
    args['obj'].parent().parent().find('td').eq(5).html(result.detail.run_result.result == undefined ? '暂无' : result.detail.run_result.result);
    args['obj'].parent().parent().find('td').eq(4).html(show_status_dsp(result.detail));
}
function create_task()
{
    var necessary_params = ['source_data_name', 'source_uid_col', 'source_user_type', 'dest_data_name', 'dest_uid_col', 'dest_user_type'];
    for(i in necessary_params)
    {
        if($('#'+necessary_params[i]).val().trim() == '')
        {
            ark_notify({status:1,msg:$('#'+necessary_params[i]).parents('.form_block').find(".form_title").html()+':'+$('#'+necessary_params[i]).parent().prev().html()+'不能为空'});
            return;
        }
    }
    var partition_empty_array = [];
    if($("#source_partition").val().trim() == '')
    {
        partition_empty_array.push('源数据'+$("#source_data_name").val().trim());
    }
    if($("#dest_partition").val().trim() == '')
    {
        partition_empty_array.push('目标数据'+$("#source_data_name").val().trim());
    }
    if(partition_empty_array.length > 0)
    {
        var html = '您的'+partition_empty_array.join('和')+'尚未配置partition!'
        $("#partitionConfirmModal #tip_msg").html(html);
        $("#partitionConfirmModal").modal('show');
    }
    else
    {
        do_create_task();
    }
}
function do_create_task()
{
    $("#btn_create_tast_ok").button('loading');
    var url = '/user_calcu/run/';
    var post_data = {};
    post_data['data_name_src'] = $("#source_data_name").val().trim();
    post_data['data_name_dst'] = $("#dest_data_name").val().trim(); 
    post_data['partition_src'] = $("#source_partition").val().trim(); 
    post_data['partition_dst'] = $("#dest_partition").val().trim(); 
    post_data['uid_col_src']   = $("#source_uid_col").val().trim(); 
    post_data['uid_col_dst']   = $("#dest_uid_col").val().trim(); 
    post_data['uid_type_src']  = $("#source_user_type").val().trim(); 
    post_data['uid_type_dst']  = $("#dest_user_type").val().trim(); 
    var callback = callback_do_create_task;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_create_task(result, args)
{
    $("#btn_create_tast_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#upsertTaskModal").modal('hide');
        table_task_list.ajax.reload();
    }
}
function rerun(obj)
{
    var task_detail = JSON.parse($(obj).attr('action-data').replace(new RegExp(/\$/g), '\''));
    $("#source_data_name").val(task_detail.data_name_src);
    //$("#source_data_name").select2('val', task_detail.data_name_src);
    $("#dest_data_name").val(task_detail.data_name_dst); 
    //$("#dest_data_name").select2('val', task_detail.data_name_dst); 
    $("#source_partition").val(task_detail.partition_src);
    $("#dest_partition").val(task_detail.partition_dst); 
    $("#source_uid_col").val(task_detail.uid_col_src); 
    $("#dest_uid_col").val(task_detail.uid_col_dst); 
    $("#source_user_type").val(task_detail.uid_type_src); 
    $("#dest_user_type").val(task_detail.uid_type_dst); 
    $("#upsertTaskModal").modal('show');
}
function cancel_task(obj)
{
    $("#cancelTaskConfirmModal #btn_cancel_tast_ok").off('click');
    $("#cancelTaskConfirmModal #btn_cancel_tast_ok").on('click', function(){
        do_cancel_task(obj);
    });
    $("#cancelTaskConfirmModal").modal('show');
}
function do_cancel_task(obj)
{
    $("#btn_cancel_tast_ok").button('loading');
    var task_detail = JSON.parse($(obj).attr('action-data'));
    var id = task_detail.id;
    var url = '/user_calcu/cancel_task/';
    var post_data = {id:id};
    var callback = callback_do_cancel_task;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_cancel_task(result, args)
{
    $("#btn_cancel_tast_ok").button('reset');
    if(result != 0)
    {
        ark_notify(result);
    }
    $("#cancelTaskConfirmModal").modal('hide');
    table_task_list.ajax.reload();
}
function show_run_log(id)
{
    var url = '/user_calcu/get_task_log/';
    var post_data = {id:id};
    var callback = callback_show_run_log;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
    $("#runLogModal .modal-body").html('<p>加载中...</p>');
    $("#runLogModal").modal('show');
}
function callback_show_run_log(result, args)
{
    var html = '';
    if(result.status == 0)
    {
        for(var i in result.res)
        {
            html += '<p>'+result.res[i].task_name+':<br/>'+result.res[i].log+'</p>';
        }
        html == '' ? html = '<p>暂无日志</p>' : '';
    }
    else
    {
        html = '<p style="color:red">获取运行日志失败</p>';
    }
    $("#runLogModal .modal-body").html(html);
}
function show_status_dsp(data)
{
                    if(data.run_status == 1)
                    {
                        return '执行中';
                    }
                    else if(data.run_status == 2)
                    {
                        return '<font color="green">成功</font>';
                    }
                    else if(data.run_status == 3)
                    {
                        return '<font style="cursor:pointer;color:red;" onclick="show_run_log('+data.id+')">失败<sup><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></sup></font>';
                    }
                    else if(data.run_status == 4)
                    {
                        return '<font style="cursor:pointer;color:red;" onclick="show_run_log('+data.id+')">被停止<sup><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></sup></font>';
                    }
}
function refresh_table(force)
{
    force = force ? true : false;
    if(table_task_list)
    {
        table_task_list.ajax.reload(null, force);
        //var oSettings = table_task_list.fnSettings();
        //var iPage = oSettings._iDisplayStart>0 ? oSettings._iDisplayStart/oSettings._iDisplayLength : 0;
        //table_task_list.fnPageChange(iPage, true);
    }
}