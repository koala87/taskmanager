
$(function(){
   $('#navright li').on('click',function(){
      var toggleSelect=$('#toggle-select');
       if(toggleSelect.is(':visible')) {
           toggleSelect.fadeOut();
       }else{
           toggleSelect.show();
       }
   });
    //切换种类
    $('.nav-choose li').on('click',function(){
        $(this).siblings().find('span').remove();
        $(this).css({
            'color':'#0099FF'
        }).siblings().css({
            'color':'#666666'
        })
        if($(this).index()==0){
            $('<span class="nav-choose-bg"></span>').prependTo($(this));
        }else{
            $('<span class="nav-choose-other"></span>').prependTo($(this));
        }

    });
    $('.search-input').on('focus',function(){
       $(this).css({
          "border":"0px !important"
       });
    }).on('keydown',function(e){
        var e=e||window.event;
        var enter= e.keyCode|| e.which;
        if(enter==13){
            console.log(1);
        }
    });
});
