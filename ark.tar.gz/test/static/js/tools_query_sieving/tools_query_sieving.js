var host_table = null;
var query_data_table;
var global_pl_id = 0;
var global_data_source = 0;

function showMessage(type,title,msg){
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg){
    showMessage("error","错误提示",msg);
}

function checkParam(){
    try{
        var time = $("#time_field").val();
        var count = parseInt($("#count").val(), 10);
        if (count > 500000) {
            showErrorMessage("抽取条数不能超过500000条!"); 
            return false;
        }
        time = time.replace(/-/g,"").replace(/ /g,"");
        time_arr = time.split("to");
        if(time_arr.length!=2){
            showErrorMessage("查询时间输入有误!"); 
            return false;
        }
        var startDate = new Date(Date.parse(time_arr[0].replace(/-/g, "/")));
        var endDate= new Date(Date.parse(time_arr[1].replace(/-/g, "/")));
        if(startDate>endDate){
            showErrorMessage("查询时间输入有误!");
            return false;
        } 
        if(isNaN(parseInt(count,10))){
            showErrorMessage("抽取数量输入有误!");
            return false;
        }
        //检测所有抽取条件的input是否有值
        if ($("#cond_mode").val() == '1') {
            var sql = $("#query_condition_sql_area").find("textarea").val();
            if (sql.replace(/(^\s*)|(\s*$)/g, "").length == 0){
                showErrorMessage("抽取条件[sql]配置参数输入有误!");
                return false;
            }
            return true;
        } else {
            var ret = true;
            $("#query_condition_mini_area").find("input").each(function(i){
                val = $(this).val();
                if (val.replace(/(^\s*)|(\s*$)/g, "").length == 0){
                    cond = $(this).parent().parent().find("select option:selected").eq(0).text();
                    showErrorMessage("抽取条件["+cond+"]配置参数输入有误!");
                    ret = false;
                    return false;
                } 
            }); 
            return ret;
        }
        return true;
    }catch(err){
        return false;
    } 
    return false;
}

function querySubmitAjax(){
    if(!checkParam()){
        query_action(false);
        return false;
    }
    var url = "/query_sieving/addTask/";
    var param = $("#query_tools_form").serialize();
    param += "&pl_id=" + global_pl_id;
    $.ajax({
        type :'post',
        url : url,
        dataType : "json",
        data : param,
        success : function(result) {
            if(result.status){
                showErrorMessage(result.msg); 
            }else{
                hideModal();
                var url = "/query_sieving/list/"
                showMessage('info', '成功', result.msg); 

                $('#sample_1_paginate ul.pagination li').each(function(){
                    if($(this).hasClass('active')){
                        activeindex=$(this).index();
                     
                    }
                });
                $('#sample_1_paginate ul.pagination li').each(function(){
                if($(this).index()==activeindex){
                    var that=$(this);
                        $(this).trigger('click',function(){
                            that.addClass('active');
                    });
                }
            });

            }
            query_action(false);
        }
    });
}

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10);
}

function addCondition(){
    var tpl;
    var max_num;
    var exist_sel;
    if (global_data_source == 0) {
        //检测条件个数是否超过最大数
        exist_sel = getCondList(); 
        max_num = $("#query_cond_tpl option").length;
        if(exist_sel.length==max_num){
            showErrorMessage("参数太多，请正确操作!");
            return;
        }

        tpl = $("#query_cond_tpl").clone();
        tpl.attr("id","");
        //下拉框默认选中一个未添加的条件
        exist_sel = getCondList(); 
        max_num = $("#query_cond_tpl option").length;
    } else {
        //检测条件个数是否超过最大数
        exist_sel = getCondList(); 
        max_num = $("#query_baidu_tpl option").length;
        if(exist_sel.length==max_num){
            showErrorMessage("参数太多，请正确操作!");
            return;
        }

        tpl = $("#query_baidu_tpl").clone();
        tpl.attr("id","");
        //下拉框默认选中一个未添加的条件
        exist_sel = getCondList(); 
        max_num = $("#query_baidu_tpl option").length;
    }

    //检测条件个数是否超过最大数
    if(exist_sel.length==max_num){
        showErrorMessage("参数太多，请正确操作!");
        return;
    }

    //下拉框默认选中一个未添加的条件
    exist_sel = getCondList(); 
    sel_val = "";
    tpl.find("option").each(function(index){
        val = $(this).val();
        for(var i=0;i<exist_sel.length;i++){
            if(val==exist_sel[i]){
                return;
            }
        } 
        sel_val = val;
        return false; 
    });
    tpl.find("select").eq(0).val(val);
    tpl.appendTo($("#query_condition_mini_area"));
    tpl.show();
    $("#cond_num_area").text(exist_sel.length+1);
    $("#cond_num").show()
    changeCondType($(tpl.find("select").eq(0)), "", "", "");
}

function getCondList(){
    var ret = new Array();
    $("#query_condition_mini_area").find("select").each(function(i){
        var type = $(this).attr("cond_type");
        if(type && type=="dropdown"){
            ret.push($(this).val());
        }
    });
    return ret;
}

function change_iner_outer() {
    val = $("#frm_select").val();
    if (val == "iner" || val == "outer") {
        $("#frm_val").val("内渠或者外渠，无需填写")
    } else {
        $("#frm_val").val("")
    }
}

function changeCondType(obj, cond_name, cond_op, cond_val){
    parent_div = $(obj).parent();
    //remove history
    var max_len = parent_div.parent().children().length;
    parent_div.parent().children().each(function(i){
        if($(this).is("div") && i>0 && i!= max_len-1){
            $(this).remove();
        }
    }); 
    //add new condition
    val = $(obj).val();
    if (cond_name != "") {
        val = cond_name;
    }

    if(val=="sc_type" || val=="sc_stype"){
        div1 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        sel = $("<select tabindex=\"1\" style=\"width:80px;height:30px;\" name=\"cond_"+val+"_op\"></select>");
        sel.appendTo(div1);
        if (cond_op == "eq") {
            $("<option value=\"eq\" selected = \"selected\" >等于</option>").appendTo(sel);
        } else {
            $("<option value=\"eq\">等于</option>").appendTo(sel);
        }

        if (cond_op == "not_eq") {
            $("<option value=\"not_eq\" selected = \"selected\">不等于</option>").appendTo(sel);
        } else {
            $("<option value=\"not_eq\">不等于</option>").appendTo(sel);
        }

        if (cond_op == "regex") {
            $("<option value=\"regex\" selected = \"selected\">包含</option>").appendTo(sel);
        } else {
            $("<option value=\"regex\">包含</option>").appendTo(sel);
        }
        if (cond_op == "not_regex") {
            $("<option value=\"not_regex\" selected = \"selected\">不包含</option>").appendTo(sel);
        } else {
            $("<option value=\"not_regex\">不包含</option>").appendTo(sel);
        }
        div2 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        var cond;
        if (cond_val != "") {
            cond = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\" value=\"" + cond_val + "\"/>");
        } else {
            cond = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\"/>");

        }
        cond.appendTo(div2);
        div1.insertAfter(parent_div);
        div2.insertAfter(div1);
    }else if(val=="network"){
        var wifi_check = -1;
        var g4_check = -1;
        var g3_check = -1;
        var g2_check = -1;
        if (cond_val != '') {
            net_list = cond_val.split(',');
            for (var i = 0; i < net_list.length; ++i) {
                if (net_list[i] == 0) {
                    wifi_check= 0;
                } else if (net_list[i] == 1) {
                    g4_check = 1;
                } else if (net_list[i] == 2) {
                    g3_check = 1;
                } else if (net_list[i] == 3) {
                    g2_check = 1;
                }
            }
        }
        div1= $("<div class=\"controls\" style=\"margin-left:70px;width:288px;float:left;\"></div>"); 
        if (wifi_check != -1) {
            $("<label class=\"checkbox\"  style=\"width:60px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"0\" checked/>WIFI</label>").appendTo(div1);
        } else {
            $("<label class=\"checkbox\"  style=\"width:60px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"0\" />WIFI</label>").appendTo(div1);
        }

        if (g4_check != -1) {
            $("<label class=\"checkbox\"  style=\"width:57px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"1\" checked/>4G</label>").appendTo(div1);
        } else {
            $("<label class=\"checkbox\"  style=\"width:57px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"1\"/>4G</label>").appendTo(div1);
        }

        if (g3_check != -1) {
            $("<label class=\"checkbox\"  style=\"width:65px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"2\" checked/>3G</label>").appendTo(div1);
        } else {
            $("<label class=\"checkbox\"  style=\"width:65px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"2\"/>3G</label>").appendTo(div1);
        }

        if (g2_check != -1) {
            $("<label class=\"checkbox\"  style=\"width:45px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"3\" checked/>2G</label>").appendTo(div1);
        } else {
            $("<label class=\"checkbox\"  style=\"width:45px;float:left;\"> <input type=\"checkbox\" name=\"cond_"+val+"\" value=\"3\"/>2G</label>").appendTo(div1);
        }
        div1.insertAfter(parent_div);
    }else if(val=="frm"){
        div1 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        sel = $("<select id=\"frm_select\" tabindex=\"1\" style=\"width:80px;height:30px;\" name=\"cond_"+val+"_op\" onchange=\"change_iner_outer();\"></select>");
        sel.appendTo(div1);
        if (cond_op == "eq") {
            $("<option value=\"eq\" selected = \"selected\">等于</option>").appendTo(sel);
        } else {
            $("<option value=\"eq\">等于</option>").appendTo(sel);
        }

        if (cond_op == "not_eq") {
            $("<option value=\"not_eq\" selected = \"selected\">不等于</option>").appendTo(sel);
        } else {
            $("<option value=\"not_eq\">不等于</option>").appendTo(sel);
        }

        if (cond_op == "iner") {
            $("<option value=\"iner\" selected = \"selected\">内渠</option>").appendTo(sel);
        } else {
            $("<option value=\"iner\">内渠</option>").appendTo(sel);
        }

        if (cond_op == "outer") {
            $("<option value=\"outer\" selected = \"selected\">外渠</option>").appendTo(sel);
        } else {
            $("<option value=\"outer\">外渠</option>").appendTo(sel);
        }
        div2 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");

        if (cond_val != "") {
            cond = $("<input id=\"frm_val\" type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\"  value=\"" + cond_val + "\"/>");
        } else {
            cond = $("<input id=\"frm_val\" type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\"/>");
        }
        cond.appendTo(div2);
        div1.insertAfter(parent_div);
        div2.insertAfter(div1);
    }else if(val=="province" || val=="city"){
        div1 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        sel = $("<select tabindex=\"1\" style=\"width:80px;height:30px;\" name=\"cond_"+val+"_op\"></select>");
        sel.appendTo(div1);
        if (cond_op == "eq") {
            $("<option value=\"eq\" selected = \"selected\">等于</option>").appendTo(sel);
        } else {
            $("<option value=\"eq\">等于</option>").appendTo(sel);
        }
        if (cond_op == "not_eq") {
            $("<option value=\"not_eq\" selected = \"selected\">不等于</option>").appendTo(sel);
        } else {
            $("<option value=\"not_eq\">不等于</option>").appendTo(sel);
        }

        div2 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        if (cond_val != "") {
            cond = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\" value=\"" + cond_val + "\"/>");
        } else {
            cond = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\"/>");
        }
        cond.appendTo(div2);
        div1.insertAfter(parent_div);
        div2.insertAfter(div1);
    } else if (val=="query_cls") {
        div1 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        sel = $("<select tabindex=\"1\" style=\"width:80px;height:30px;\" name=\"cond_"+val+"_op\"></select>");
        sel.appendTo(div1);
        if (cond_op == "eq") {
            $("<option value=\"regex\" selected = \"selected\">匹配</option>").appendTo(sel);
        } else {
            $("<option value=\"regex\">匹配</option>").appendTo(sel);
        }
        if (cond_op == "not_eq") {
            $("<option value=\"not_regex\" selected = \"selected\">不匹配</option>").appendTo(sel);
        } else {
            $("<option value=\"not_regex\">不匹配</option>").appendTo(sel);
        }

        div2 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        if (cond_val != "") {
            cond = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\" value=\"" + cond_val + "\"/>");
        } else {
            cond = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:270px;height:28px;padding:0px;\" placeholder=\"请输入条件值,多个条件之间用逗号分隔！\"/>");
        }
        cond.appendTo(div2);
        div1.insertAfter(parent_div);
        div2.insertAfter(div1);
    }else if(val=="bucket"){
        div1= $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>"); 
        cond_exp = $("<input type=\"text\" name=\"cond_"+val+"_op\" style=\"width:148px;height:28px;padding:0px;\" placeholder=\"   实验名\" />");
        if (cond_op != "") {
            cond_exp = $("<input type=\"text\" name=\"cond_"+val+"_op\" style=\"width:148px;height:28px;padding:0px;\" placeholder=\"   实验名\"  value=\"" + cond_op + "\"/>");
        }
        cond_exp.appendTo(div1);
        div2 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;\"></div>");
        cond_bucket = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:184px;height:28px;padding:0px;margin-left:3px;\"  placeholder=\"   桶名\"/>");
        if (cond_val != "") {
            cond_bucket = $("<input type=\"text\" name=\"cond_"+val+"\" style=\"width:184px;height:28px;padding:0px;margin-left:3px;\"  placeholder=\"   桶名\" value=\"" + cond_val + "\"/>");
        }
        cond_bucket.appendTo(div2);
        div1.insertAfter(parent_div);
        div2.insertAfter(div1);
        div3 = $("<div class=\"controls\" style=\"margin-left:3px;float:left;height:28px;width:10px;\"></div>");
        $("<label class=\"radio\"  style=\"width:10px;\">=</label>").appendTo(div3);
        div3.insertAfter(div1);
    }else if(val=="languang"){
        div1= $("<div class=\"controls\" style=\"margin-left:108px;width:250px;float:left;\"></div>"); 
        if (cond_val != "") {
            if (cond_val == "0") {
                $("<label class=\"radio\" style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"0\" checked/>触发</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"1\" />未触发</label>").appendTo(div1);
            } else {
                $("<label class=\"radio\" style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"0\" />触发</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"1\"  checked/>未触发</label>").appendTo(div1);
            }
        } else {
            $("<label class=\"radio\" style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"0\" checked/>触发</label>").appendTo(div1);
            $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"1\"/>未触发</label>").appendTo(div1);
        }
        div1.insertAfter(parent_div);
    }else if(val=="voice"){
        div1= $("<div class=\"controls\" style=\"margin-left:108px;width:250px;float:left;\"></div>"); 
        if (cond_val != "") {
            if (cond_val == "0") {
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"0\" checked/>是</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"1\" />否</label>").appendTo(div1);
            } else {
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"0\" />是</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"1\" checked/>否</label>").appendTo(div1);
            }
        } else {
            $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"0\" checked/>是</label>").appendTo(div1);
            $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"1\"/>否</label>").appendTo(div1);
        }

        div1.insertAfter(parent_div);
    }else if(val=="cid"){
        div1= $("<div class=\"controls\" style=\"margin-left:108px;width:250px;float:left;\"></div>"); 
        if (cond_val != "") {
            if (cond_val == "7") {
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"7\" checked/>简版</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"9\" />高版</label>").appendTo(div1);
            } else {
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"7\" />简版</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"9\" checked/>高版</label>").appendTo(div1);
            }
        } else {
            $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"7\" checked/>简版</label>").appendTo(div1);
            $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"9\"/>高版</label>").appendTo(div1);
        }
        div1.insertAfter(parent_div);
    }else if(val=="fr"){
        div1= $("<div class=\"controls\" style=\"margin-left:108px;width:250px;float:left;\"></div>"); 
        if (cond_val != "") {
            if (cond_val == "android") {
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"android\" checked/>android</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"ios\"  />ios</label>").appendTo(div1);
            } else {
                $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"android\" />android</label>").appendTo(div1);
                $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"ios\"  checked/>ios</label>").appendTo(div1);
            }
        } else {
            $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"android\" checked/>android</label>").appendTo(div1);
            $("<label class=\"radio\"  style=\"width:45px;\"> <input type=\"radio\" name=\"cond_"+val+"\" value=\"ios\"/>ios</label>").appendTo(div1);
        }
        div1.insertAfter(parent_div);
    }
}
function removeCondition(obj){
    $(obj).parent().parent().remove();
    exist_sel = getCondList(); 
    $("#cond_num_area").text(exist_sel.length);
    if (exist_sel.length <= 0) {
        $('#cond_num').hide();
    }
}
function switchMode(){
    if($("#query_condition_mini_area").is(":hidden")){
        $("#query_condition_mini_area").show();
        $("#cond_mode").val("0");
        $('#query_add_cond_btn').removeAttr("disabled"); 
        $("#sql_mode").show();
        $("#sql_ex_mode").hide();
        $("#cond_num").show();
        $("#query_add_cond_btn").show();
    }else{
        $("#query_condition_mini_area").hide();
        $("#sql_mode").hide();
        $("#cond_num").hide();
        $("#query_add_cond_btn").hide();
        $("#sql_ex_mode").show();
    }
    if($("#query_condition_sql_area").is(":hidden")){
        $("#query_condition_sql_area").show();
        $("#cond_mode").val("1");
        $('#query_add_cond_btn').attr('disabled',"true");
    }else{
        $("#query_condition_sql_area").hide();
    }

    exist_sel = getCondList(); 
    if (exist_sel.length <= 0) {
        $('#cond_num').hide();
    }
}
function addTask(){
//     $("#execute_task", window.parent.document).modal('show');

    $("#execute_task").modal({
        backdrop:false,
        show:true,        
    });
    $("#query_source_and_mode").empty();
    $("#query_condition_mini_area").empty();
    $("#count").val(100);
    global_pl_id = 0;
    $("#cond_num_area").text(0);
    add_data_source_and_mode(0, 0);
    $('#cond_num').hide();
}
function hideModal(){
    $('#execute_task').modal('hide');
    query_action(false);
}

function query_action(busy) {
    if (busy) {
        $("#run_busy").show()
        $('#query_form_btn').attr('disabled',"true");
    } else {
        $("#run_busy").hide()
        $('#query_form_btn').removeAttr("disabled"); 
    }
}

var clicked_query_more = false;
function query_more(pl_id) {
    clicked_query_more = true;
    var e = window.event;             
    var $contextMenu = $("#contextMenu");
    $contextMenu.css({
        display: "block",
        left: e.pageX - 160,
        top: e.pageY
    });
    $contextMenu.show();
    global_pl_id = pl_id;
}

function succ_download(pl_id){
    window.open('/query_sieving/download/' + pl_id + '/');
}

function add_condition_ex(cond_name, cond_op, cond_val){
    var tpl = $("#query_cond_tpl").clone();
    if (global_data_source == 1) {
        tpl = $("#query_baidu_tpl").clone();
    }
    tpl.attr("id","");
    exist_sel = getCondList(); 
    tpl.find("select").eq(0).val(cond_name);
    tpl.appendTo($("#query_condition_mini_area"));
    tpl.show();
    $("#cond_num_area").text(exist_sel.length+1);
    changeCondType($(tpl.find("select").eq(0)), cond_name, cond_op, cond_val);
    $('#cond_num').show();
}

function re_sieving(pl_id) {
//     $("#execute_task", window.parent.document).modal('show');

    $("#execute_task").modal({
        backdrop:false,
        show:true,        
    });
    global_pl_id = pl_id;
    $("#query_source_and_mode").empty();
    $("#query_condition_mini_area").empty();
    $("#cond_num_area").text(0);
    $('#cond_num').hide();
    $.ajax({
        type: 'post',
        url: '/query_sieving/get_sieving_info/',
        dataType: 'json',
        async: false,
        data: { 'pl_id': pl_id },
        success: function (result) {
            if (result.status == 0) {
                $("#time_field").val(result.time_range);
                $("#count").val(result.count);
                data_source = parseInt(result.data_source, 10);
                mode = parseInt(result.mode, 10);
                add_data_source_and_mode(data_source, mode);
                condition_list = result.condition.split("\001")
                if (result.cond_mode == 1) {
                    if($("#query_condition_sql_area").is(":hidden")){
                        switchMode();
                        $("#query_condition_sql_area").find("textarea").val(condition_list[0]);
                    }
                } else {
                    if($("#query_condition_mini_area").is(":hidden")){
                        switchMode();
                    }
                    cond_param_list = condition_list[1].split('\n');
                    for (var i = 0; i < cond_param_list.length; ++i) {
                        cond_params = cond_param_list[i].split('`');
                        if (cond_params[0].replace(/(^\s*)|(\s*$)/g, "").length == 0) {
                            continue;
                        }
                        add_condition_ex(cond_params[0], cond_params[1], cond_params[2]);
                    }
                }
            }
        }
    });
}

var all_uniq_table = new Array(
    "query", "搜索量", "sug搜索", "相关搜索", 
    "uv", "总点击数", "条件sc点击", "条件sc平均点击位置", 
    "sc点击", "sc平均点击位置", "自然结果点击", 
    "自然结果平均点击位置", "query分类");
var all_nature_table = new Array(
    "query", "时间", "ip", "省份", "城市", "经纬度", "网络", "输入方式", "语音", "uid", "query分类");
var baidu_uniq_table = new Array("query", "搜索量", "总点击数");
var baidu_nature_table = new Array("query", "城市", "网络", "平台", "经纬度");

function create_config_table(config, data_source, mode) {
    if (config != '') {
        var tb = document.getElementById('_table');
        var rowNum=tb.rows.length;
        for (i=0;i<rowNum;i++) {
            tb.deleteRow(i);
            rowNum=rowNum-1;
            i=i-1;
        }

        var temp = config.split('\n');
        var count = temp.length;
        if (count == 1) {
            config_right_split = temp[0].split('`')
            if (config_right_split.length <= 1) {
                showErrorMessage(temp);
                return;
            }
        }
        if (count > 10) {
            count = 10;
        }
        var row = document.createElement("tr");
        document.getElementById("_table").appendChild(row);
        if (data_source == 0 && mode != 4) {
            for (cell in all_uniq_table) {
                var key_cell = document.createElement("td");
                key_cell.innerText = all_uniq_table[cell];
                key_cell.style.fontWeight="bold";
                row.appendChild(key_cell);
            }
        } else if (data_source == 0 && mode == 4) {
            for (cell in all_nature_table) {
                var key_cell = document.createElement("td");
                key_cell.style.fontWeight="bold";
                key_cell.innerText = all_nature_table[cell];
                row.appendChild(key_cell);
            }
        }else if (data_source == 1 && mode != 4) {
            for (cell in baidu_uniq_table) {
                var key_cell = document.createElement("td");
                key_cell.innerText = baidu_uniq_table[cell];
                key_cell.style.fontWeight="bold";
                row.appendChild(key_cell);
            }
        } else if (data_source == 1 && mode == 4) {
            for (cell in baidu_nature_table) {
                var key_cell = document.createElement("td");
                key_cell.innerText = baidu_nature_table[cell];
                key_cell.style.fontWeight="bold";
                row.appendChild(key_cell);
            }
        }

        if (count > 0) {
            for (var i = 0; i < count; i++) {
                config_str = temp[i]
                config_right_split = config_str.split('`')
                var row = document.createElement("tr");
                document.getElementById("_table").appendChild(row);
                for (var field_idx = 0; field_idx < config_right_split.length; ++field_idx) {
                    var key_cell = document.createElement("td");
                    key_cell.innerText = config_right_split[field_idx];
                    row.appendChild(key_cell);
                }
            }
        }
    }
}

function preview(pl_id) {
    $.ajax({
        type: 'post',
        url: '/query_sieving/get_preview_log/',
        dataType: 'json',
        async: false,
        data: { 'pl_id': pl_id },
        success: function (result) {
            if (result.status == 0) {
                var temp = result.file_content.split('\n');
                var count = temp.length;
                if (count == 1) {
                    config_right_split = temp[0].split('`')
                    if (config_right_split.length <= 1) {
                        showErrorMessage(temp);
                        return;
                    }
                }
                $("#preview_div", window.parent.document).modal('show');
                create_config_table(result.file_content, result.data_source, result.mode);
                return;
            } else {
                showErrorMessage("请求数据失败，无法预览数据！");
            }
        }
    });

}

var clip_board;
function get_path(pl_id) {       
    $('#con', window.parent.document).html("pangu://AY501/product/data_platform/query_sieving/result_log/" + pl_id + ".src");
    $("#copyModal", window.parent.document).modal('show');
    clip_board.setText("pangu://AY501/product/data_platform/query_sieving/result_log/" + pl_id + ".src");
}

function pipeline(pl_id) {
    var url = "/query_sieving/check_pipeline/";
    $.ajax({
        type :'post',
        url : url,
        dataType : "json",
        data : {"pl_id": pl_id},
        success : function(result) {
            if(result.status){
                showErrorMessage(result.info);
                return;
            } else {
                url = "http://ark.sm.cn/pipeline/history/" + pl_id + "/";
                window.open(url);
            }
        }
    });
}

var TableAdvanced = function () {
    var initTable1 = function() {
        function fnFormatDetails ( tmp_table, nTr )
        {
            var aData = tmp_table.fnGetData( nTr );
            var sOut = '<table>';
            try{
                condtion = aData["condition"].split("\001");
                src_cond = condtion[1].split('\n')
                str = ""
                for (var i = 0; i < src_cond.length; ++i) {
                    cond_list = src_cond[i].split('`')
                    if (cond_list[0].replace(/(^\s*)|(\s*$)/g, "").length == 0) {
                        continue;
                    }
                    op = "";
                    if (cond_list[1] == "eq") {
                        op = "&nbsp;&nbsp;&nbsp;&nbsp;等于&nbsp;&nbsp;&nbsp;&nbsp;";
                    } else if (cond_list[1] == "not_eq") {
                        op = "&nbsp;&nbsp;&nbsp;&nbsp;不等于&nbsp;&nbsp;";
                    } else if (cond_list[1] == "regex") {
                        op = "&nbsp;&nbsp;&nbsp;&nbsp;匹配&nbsp;&nbsp;&nbsp;&nbsp;";
                    } else if (cond_list[1] == "not_regex") {
                        op = "&nbsp;&nbsp;&nbsp;&nbsp;不匹配&nbsp;&nbsp;";
                    }
                    val = cond_list[2];

                    if (cond_list[0] == "sc_type") {
                        str += "&nbsp;&nbsp;&nbsp;&nbsp;sc名称" + op +  val + "<br>"
                    } else if (cond_list[0] == "sc_stype") {
                        str += "sc子类型" + op +  val + "<br>"
                    } else if (cond_list[0] == "languang") {
                        if (cond_list[2] == "0") {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;蓝光&nbsp;&nbsp;&nbsp;&nbsp;触发" + "<br>"
                        } else {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;蓝光&nbsp;&nbsp;&nbsp;&nbsp;不触发" + "<br>"
                        }
                    } else if (cond_list[0] == "query_cls") {
                        str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;行业" + op +  val + "<br>"
                    } else if (cond_list[0] == "frm") {
                        if (cond_list[1] == "iner") {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;渠道&nbsp;&nbsp;&nbsp;&nbsp;内渠<br>"
                        } else if (cond_list[1] == "outer") {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;渠道&nbsp;&nbsp;&nbsp;&nbsp;外渠<br>"
                        } else {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;渠道" + op +  val + "<br>"
                        }
                    } else if (cond_list[0] == "cid") {
                        if (cond_list[2] == "7") {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;版式&nbsp;&nbsp;&nbsp;&nbsp;简版" + "<br>"
                        } else {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;版式&nbsp;&nbsp;&nbsp;&nbsp;高版" + "<br>"
                        }
                    } else if (cond_list[0] == "bucket") {
                        str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;分桶&nbsp;&nbsp;&nbsp;&nbsp;" + cond_list[1] + "=" + cond_list[2] + "<br>"
                    } else if (cond_list[0] == "province") {
                        str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;省份" + op +  val + "<br>"
                    } else if (cond_list[0] == "city") {
                        str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;城市" + op +  val + "<br>"
                    } else if (cond_list[0] == "network") {
                        tmp_str = ""
                        tmp_list = cond_list[2].split(',');
                        for (var tmp_idx = 0; tmp_idx < tmp_list.length; ++tmp_idx) {
                            if (tmp_list[tmp_idx] == "0") {
                                tmp_str += "WIFI,";
                            } else if (tmp_list[tmp_idx] == "1") {
                                tmp_str += "4G,";
                            } else if (tmp_list[tmp_idx] == "2") {
                                tmp_str += "3G,";
                            } else if (tmp_list[tmp_idx] == "3") {
                                tmp_str += "2G,";
                            }
                        }
                        str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;网络&nbsp;&nbsp;&nbsp;&nbsp;等于&nbsp;&nbsp;&nbsp;&nbsp;" + tmp_str + "<br>"
                    } else if (cond_list[0] == "fr") {
                        str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;平台&nbsp;&nbsp;&nbsp;&nbsp;等于&nbsp;&nbsp;&nbsp;&nbsp;" + cond_list[2] + "<br>"
                    } else if (cond_list[0] == "voice") {
                        if (cond_list[2] == "0") {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;语音&nbsp;&nbsp;&nbsp;&nbsp;是" + "<br>"
                        } else {
                            str += "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;语音&nbsp;&nbsp;&nbsp;&nbsp;否" + "<br>"
                        }
                    }
                }
                sOut += '<tr><td style="width:60px;">抽取条件：</td><td>'+str+'</td></tr>';
                sOut += '<tr><td style="width:60px;">&nbsp;&nbsp;sql语句：</td><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+condtion[0]+'</td></tr>';
            }catch(err){
                sOut += '<tr><td style="width:60px;">抽取条件:</td><td>'+aData["condition"]+'</td></tr>';
            } 
            sOut += '</table>';
            return sOut;
        }

        query_data_table = $('#sample_1').dataTable( {
            "serverSide": true,
            "processing": true,
            "ajax": {
                "url": "/query_sieving/list/",
                "type": "POST",
            },
            "columnDefs": [
                {
                    "targets": [0],
                    "searchable": false,
                    "bSortable": false,
                    "mData": "id",
                    "render": function(data, type, full) {
                        return '<span class="row-details row-details-close" style="width:100%"></span>';
                    }
                },
                { "data": "creator" ,"bSortable": false, "visible": true, "aTargets": [ 1 ]},
                {
                    "targets": [2],
                    "searchable": false,
                    "bSortable": false,
                    "mData": "time_range",
                    "render": function(data,type,full) {
                       return data;
                    }
                },

                { "mData": "data_source" ,"bSortable": false, "aTargets": [ 3 ]},
                { "mData": "mode" ,"bSortable": false,  "aTargets": [ 4 ]},
                {
                    "targets": [5],
                    "searchable": false,
                    "bSortable": false,
                    "mData": "condition",
                    "visible": false,
                    "render": function(data,type,full) {
                       return data;
                    }
                },

                { "mData": "count" ,"bSortable": false,  "aTargets": [6 ]},
                { "mData": "update_time" ,"bSortable": false,  "aTargets": [ 7 ]},
                {
                    "targets": [8],
                    "searchable": false,
                    "bSortable": false,
                    "mData": "status",
                    "render": function(data,type,full) {
                        if (data == 2) {
                            return '<div class="ProgressBar"> <div style="width: 100%;color:rgb(255, 255, 255);background:rgb(0, 166, 90);"><span style="font-size:5px;">100%</span><a href="javascript:void(0)" title="成功" rel="tooltip" style="text-decoration:none;"><font style="color:rgb(0, 166, 90);">---------</font></a></div> </div>';
                        } else if (data == 3) {
                            return '<div class="ProgressBar"> <div style="width: 100%;color:rgb(221, 75, 57);background:rgb(221, 75, 57);"><a href="javascript:void(0)" title="失败" rel="tooltip" style="text-decoration:none;"><font style="color:rgb(221, 75, 57);">---------</font></a></div> </div>';
                        } else if (data == 6) {
                            return '<div class="ProgressBar"> <div style="width: 100%;color:rgb(221, 75, 57);background:rgb(221, 75, 57);"><a href="javascript:void(0)" title="用户停止" rel="tooltip" style="text-decoration:none;"><font style="color:rgb(221, 75, 57);">---------</font></a></div> </div>';
                        } else if (data >= 1000) {
                            var val = parseInt((data - 1000) / 3 * 100, 10) + "%";
                            return '<div class="ProgressBar"> <div style="width: '+ val + ';color:rgb(0, 0, 0);background:rgb(243, 161, 31);"><span>' + val + '</span></div> </div>';
                        } else {
                            return "执行中...";
                        }
                    }
                },
                {
                    "targets": [9],
                    "searchable": false,
                    "bSortable": false,
                    "mData": "id",
                    "render": function(data,type,full) {
                        if (full.status == 2) {
                            return "<a type='button' href='#' title='点击下载日志' rel='tooltip' onclick=succ_download(" + full.pl_id + ");><font class='oper-Font'>下载</font></a>"+
                                "&nbsp;"+
                                '<img id="succ_more" href="#" type="button" style="width:17px;margin-top:-5px;" src="/static/images/query_more.png" onclick="query_more(' + full.pl_id + ');" />';
                        } else if (full.status == 3 ||　full.status == 6) {
                            return "<a type='button' href='#' title='点击重抽' rel='tooltip' onclick=re_sieving(" + full.pl_id + ");><font class='oper-Font'>重抽</font></a>"+
                                "&nbsp;"+
                                "<a type='button' href='#' title='后台流程' rel='tooltip' onclick=pipeline(" + full.pl_id + ");><font class='oper-Font'>后台流程</font></a>";
                        } else {
                            return "<a type='button' href='#' title='后台流程' rel='tooltip' onclick=pipeline(" + full.pl_id + ");><font class='oper-Font'>后台流程</font></a>";
                        }
                    }
                },
            ],
            // set the initial value
            "iDisplayLength": 10,
        });

        $('#sample_1').on('click', ' tbody td .row-details', function () {
            var nTr = $(this).parents('tr')[0];
            if ( query_data_table.fnIsOpen(nTr) )
            {
                $(this).addClass("row-details-close").removeClass("row-details-open");
                query_data_table.fnClose( nTr );
            }
            else
            {
                $(this).addClass("row-details-open").removeClass("row-details-close");
                query_data_table.fnOpen( nTr, fnFormatDetails(query_data_table, nTr), 'details' );
            }
        });

        setInterval(function(){
            $('#sample_1_paginate ul.pagination li').each(function(){
                if($(this).hasClass('active')){
                    activeindex2=$(this).index();

                }
                });
                    
                $('#sample_1_paginate ul.pagination li').each(function(){
                if($(this).index()==activeindex2){
                            var that=$(this);
                        $(this).trigger('click',function(){
                            that.addClass('active');
                    });

                }
            });
        }, 3600000);

    }
    return {
        init: function () {
            if (!jQuery().dataTable) {
                return;
            }
            initTable1();
        }
    };
}();

function switch_datasource(tag) {
    global_data_source = tag;
    $("#query_condition_mini_area").empty();
    $("#cond_num_area").text(0);
    $('#cond_num').hide();
}

function add_data_source_and_mode(source, mode) {
    div1= $("<div class=\"span6\" style=\"width:70%;margin-left:-13px;margin-top:-5px;\"></dev>"); 
    div2 = $("<div class=\"control-group\" style=\"margin-bottom:10px;\"></dev>"); 
    div2.appendTo(div1);
    $("<label class=\"control-label\" style=\"width:68px;margin-right:14px;\">数据源</label>").appendTo(div2);
    div3 = $("<div class=\"controls\" style=\"margin-left:0px;\">"); 
    div3.appendTo(div2);
    if (source == 0) {
        $("<label class=\"radio\" style=\"width:100px;\"> <input type=\"radio\" style=\"margin-left:8px;\" id=\"data_source0\" name=\"data_source\" value=\"0\" onclick=\"switch_datasource(0);\" checked/>&nbsp;全网日志</label>").appendTo(div3);
        $("<label class=\"radio\" style=\"width:85px;\"> <input type=\"radio\" id=\"data_source\" name=\"data_source\" value=\"1\" onclick=\"switch_datasource(1);\"/>&nbsp;狼厂日志</label>").appendTo(div3);
        switch_datasource(0);
    } else {
        $("<label class=\"radio\" style=\"width:100px;\"> <input type=\"radio\" style=\"margin-left:10px;\" id=\"data_source0\" name=\"data_source\" value=\"0\" onclick=\"switch_datasource(0);\" />全网日志</label>").appendTo(div3);
        $("<label class=\"radio\" style=\"width:85px;\"> <input type=\"radio\" id=\"data_source\" name=\"data_source\" value=\"1\" onclick=\"switch_datasource(1);\" checked/>狼厂日志</label>").appendTo(div3);
        switch_datasource(1);
    }
    div1.appendTo($("#query_source_and_mode"));

    mode_div1= $("<div class=\"span6\" style=\"width:110%;margin-left:-13px;margin-top:-5px;\"></dev>"); 
    mode_div2 = $("<div class=\"control-group\" style=\"margin-bottom:10px;\"></dev>"); 
    mode_div2.appendTo(mode_div1);
    $("<label class=\"control-label\" style=\"width:68px;margin-right:42px;\">抽取方式</label>").appendTo(mode_div2);
    mode_div3 = $("<div class=\"controls\" style=\"margin-left:0px;\">"); 
    mode_div3.appendTo(mode_div2);
    if (mode == 0) {
        $("<label class=\"radio\"  style=\"width:72px;\"> <input type=\"radio\" name=\"mode\" value=\"1\" checked/>top pv</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"2\" />top click</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"3\" />随机去重</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"mode\" value=\"4\" />随机不去重</label>").appendTo(mode_div3);
    } else if (mode == 1) {
        $("<label class=\"radio\"  style=\"width:72px;\"> <input type=\"radio\" name=\"mode\" value=\"1\" />top pv</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"2\" checked/>top click</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"3\" />随机去重</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"mode\" value=\"4\" />随机不去重</label>").appendTo(mode_div3);
    } else if (mode == 2) {
        $("<label class=\"radio\"  style=\"width:72px;\"> <input type=\"radio\" name=\"mode\" value=\"1\" />top pv</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"2\" />top click</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"3\" checked/>随机去重</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"mode\" value=\"4\" />随机不去重</label>").appendTo(mode_div3);
    } else {
        $("<label class=\"radio\"  style=\"width:72px;\"> <input type=\"radio\" name=\"mode\" value=\"1\" />top pv</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"2\" />top click</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:85px;\"> <input type=\"radio\" name=\"mode\" value=\"3\" />随机去重</label>").appendTo(mode_div3);
        $("<label class=\"radio\"  style=\"width:100px;\"> <input type=\"radio\" name=\"mode\" value=\"4\" checked/>随机不去重</label>").appendTo(mode_div3);
    }
    mode_div1.appendTo($("#query_source_and_mode"));
}

$(document).ready(function(){    
    $("#query_source_and_mode").empty();
    $("#query_condition_mini_area").empty();

    add_data_source_and_mode(0, 0);
    clip_board = new ZeroClipboard($("#copyBtn", window.parent.document));
    clip_board.on( "ready", function( readyEvent ) {
        clip_board.on( "aftercopy", function( event ) {
            new PNotify({
                title: '通知',
                text: '复制成功！',
                addclass: 'custom',
                type: 'success'
            });
        });
    });  

    var $contextMenu = $("#contextMenu");
    $contextMenu.css({
        display: "block",
        minWidth: 100
    });

    $contextMenu.on("click", "a", function (e) {
        $contextMenu.hide();
        if ('preview' == $(this).attr("op")) {
            preview(global_pl_id);
        } else if ('sieving_again' == $(this).attr("op")) {
            re_sieving(global_pl_id);
        } else if ('get_path' == $(this).attr("op")) {
            get_path(global_pl_id);
        } else if ('pipeline' == $(this).attr("op")) {
            pipeline(global_pl_id);
        }
    });
    $contextMenu.hide();

     $(document).click(function () {
        if (!clicked_query_more) {
            $contextMenu.hide();
        }
        clicked_query_more = false;
     });

    $("#query_sieving_submit").click(function(){
        addTask();
    });
    $("#query_add_cond_btn").click(function(){
        addCondition();
    });

    $("#query_form_btn").click(function(){
        document.documentElement.scrollTop = document.body.scrollTop =0;
        query_action(true);
        querySubmitAjax();
        return false;
    });
    end_date = yesterday = get_pre_date(1);
    start_date = end_date;
    last_week = get_pre_date(7);
    last_month = get_pre_month(1);
    $('#time_field').daterangepicker(
            {
                "ranges": {
                    "昨天": [
                        yesterday,
                        yesterday
                    ],
                    "近一周": [
                        last_week,
                        yesterday
                    ],
                    "近一个月": [
                        last_month,
                        yesterday
                    ],
                },
                "locale": {
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "fromLabel": "From",
                    "toLabel": "To",
                    "customRangeLabel": "自定义时间",
                    "daysOfWeek": [
                        "日", 
                        "一", 
                        "二", 
                        "三", 
                        "四", 
                        "五", 
                        "六"
                    ],
                    "monthNames": [
                        "一月",  
                        "二月",  
                        "三月",  
                        "四月",
                        "五月",
                        "六月",
                        "七月",
                        "八月",
                        "九月",
                        "十月",
                        "十一月",
                        "十二月"
                    ],
                    "firstDay": 1
                },
                opens: (App.isRTL() ? 'left' : 'right'),
                format: 'yyyy-MM-dd',
                separator: ' to ',
                startDate: yesterday,
                endDate: yesterday,
                minDate: last_month,
                maxDate: yesterday
            }
        );
    $("#time_field").val(start_date+" to "+end_date);
    $(document).mousewheel(function(event, delta) {
        mousewheelEvent(event,delta);
    });
});
function mousewheelEvent(e, delta) {
    $(".daterangepicker").eq(0).css("display","none");    
}
