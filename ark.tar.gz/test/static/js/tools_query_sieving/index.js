view_dialog_id = 'view_dialog'
query_data_table = null;

function get_busy_html(channel_id) {
    busy_obj = $('#row_detail_div').clone().prop({id:'row_detail_div_' + channel_id});
    busy_obj.show();
    return busy_obj[0];
}

$(function(){
    query_data_table = $('#query_data_list').dataTable({
        "processing": true,
        "serverSide": true,
        "bLengthChange": true,
        "ajax": {
            "url": "/query_sieving/list/",
            "type": "POST",
        },
        "oLanguage": {
            "sEmptyTable": "暂无抽取任务！",
            "oPaginate": {"sPrevious": "上一页", "sNext": "下一页"},
        },
        "columns": [
            { "data": "creator" ,"bSortable": false},
            { "data": "time_range" ,"bSortable": false},
            { "data": "data_source" ,"bSortable": false},
            { "data": "mode" ,"bSortable": false},
            { "data": "count" ,"bSortable": false},
            { "data": "update_time" ,"bSortable": false},
            { "data": "status" ,"bSortable": false },
            {
                "data": "id",
                "bSortable": false,
                "render": function(data, type, full) {
                    return "<a class='glyphicon glyphicon-eye-open' name='channel-detail-control'></a>&nbsp;&nbsp;"+
                        "<a class='glyphicon glyphicon-chevron-down' name='history-data-control'></a>";
                }
            },
        ],
    });
    $('#query_data_list tbody').on('click', '[name="channel-detail-control"]', function () {
        var tr = $(this).closest('tr');
        var row = query_data_table.row(tr);
        alert(row.data());
    });
})

