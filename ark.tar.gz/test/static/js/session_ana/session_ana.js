var session_result = false;

Array.prototype.remove = function (s) {
    for (var i = 0; i < this.length; i++) {
        if (s == this[i])
            this.splice(i, 1);
    }
}

function showMessage(type, title, msg) {
    PNotify.prototype.options.styling = "bootstrap3";
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}

function add_days(date,days){
    var nd = new Date(date);
    nd = nd.valueOf();
    nd = nd + days * 24 * 60 * 60 * 1000;
    return new Date(nd);
}

function get_days_diff(day1 ,day2){
    var days = parseInt((day1 - day2) / 86400000 );
    if (days < 0){
        days = 0 - days;
    }
    return days
}


function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0, 10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0, 10);
}

function create_li_head_first(object, date_str) {
    li = $(
            '<li class="time-label" style="margin-top:20px;margin-bottom:25px;" name="auto_li_name" data-date="'+date_str+'">'+
                '<span class="bg-light-blue " style="float:left;">事件开始'+
                     '<span style="margin-left:6px">('+date_str+')</span>'+
                '</span>'+
            '</li>'
        );
    li.insertAfter(object);
    return li;
}

function create_li_head_tail(object, date_str) {
    li = $(
            '<li class="time-label" style="margin-top:20px;margin-bottom:45px;" name="auto_li_name" data-date="'+date_str+'">'+
                '<span class="bg-light-blue " style="float:left;">事件结束</span>'+
            '</li>'
        );
    li.insertAfter(object);
    return li;
}

var action_icon_list = {
    "0": "fa",//未知
    "11": "fa fa-search bg-blue",//search
    "12": "fa fa-fw fa-hand-pointer-o bg-yellow",//click
    //"21": "fa fa-fw fa-thumbs-o-up bg-red",//头条推荐
    "21": "fa fa-fw fa-comment-o bg-red",//头条推荐
    "22": "fa fa-fw fa-arrow-down bg-orange",//ucpush
    "23": "fa fa-fw fa-book bg-lightblue",//uc浏览
    "31": "fa fa-fw fa-play bg-green",//youku播放
}

function get_word_short(word, len, fix){
    if (fix == undefined) fix = "...";
    if (word.length > len){
        word = word.substr(0, len) + fix;
    }
    return word
}

function set_select_val(selector, val){
    if (val == undefined || val == ""){
        return false
    }
    if (selector != undefined && selector != "" && $(selector).length > 0){
        var el = $(selector)
        el.val(val)
        if (el[0].tagName == "SELECT"){
            if (el.hasClass("select2")){
                el.select2()
            }
        }
    }
}


function create_li_item(object, data, date_str){
    var action_icon_class = action_icon_list[data.action_code] || ""

    var item_title = data.action_name
    var action = data.action_name

    var margin_top = '-35px;';
    if (action.replace(/(^\s*)|(\s*$)/g, "").length > 2) {
        margin_top = '-52px;';
    }

    var url = data.url
    if(url != ""){
        a_url_href = " href='"+url+"' target=\"_blank\"";
    }else{
        a_url_href = " href='javascript:void(0)'";
    }
    var color = "color:#435668";
    var keyword_short = get_word_short(data.keyword, 100, "...");
    li = $(
        '<li class="auto_li" name="auto_li_name" title="'+item_title+'" data-date="'+date_str+'" data-pid="'+data.pid+'">'+
            '<label class="li_label_time" >'+data.time+' </label>'+
            '<i class="'+action_icon_class+'" style="float:left;" ></i>' +
            '<label class="li_label_action" >'+action+'</label>'+
            '<label class="li_label_keyword" title="'+data.keyword+'">'+'<a '+a_url_href+'>'+keyword_short+'</a></label>'+
        '</li>');
    li.insertAfter(object);
    return li;
}

function before_submit(){
    $('#wait_busy_icon').show();
    $('#div_time_scroll').hide();

    $('#submit_button').attr('disabled', "true");
    $('#btn_day_before').attr('disabled', "true");

    $("li[name='auto_li_name']").remove();

    $("#summary_date").empty()
    $("#summary_product").empty()

}

function after_submit(session_result, end_date){
    $('#wait_busy_icon').hide();
    $('#submit_button').removeAttr("disabled");
    $('#btn_day_before').removeAttr("disabled");

    if(!session_result){
        showErrorMessage("没有数据!");
    }else{
        $('#div_time_scroll').show();
        var now_date_pre = new Date(Date.parse(get_pre_date(1)));
        if (end_date >= now_date_pre){
            $('#btn_day_next').attr('disabled', "true");
        }
    }
}


function get_session_list() {
    uid = $('#uid').val();
    if(uid == undefined || uid == ""){
        showErrorMessage("请输入用户标识！");
        $('#uid').focus();
        return false;
    }


    var uid_type = $("#uid_type").val();
    var data_type = $("#data_type").val();
    var date_range = $("#time_field").val().split(' to ');
    var start_date = new Date(Date.parse(date_range[0]));
    var end_date = new Date(Date.parse(date_range[1]));
    var days_diff = get_days_diff(end_date, start_date);

    var days_limit = 7
    if(days_diff > days_limit){
        showErrorMessage("Error：查询日期范围不能超过"+days_limit+"天！");
        $('#time_field').focus();
        return false;
    }

    var data_param = { "uid": uid, "uid_type": uid_type, "data_type": data_type };

    before_submit()
    do_get_session_list(data_param, start_date, end_date);

    session_result = false;
}


function build_summary_date(date_str, count){
    date_digit =  date_str.replace(/[^\d]/g, "");
    date_id = "date_" + date_digit
    var date_el = "<button class='btn btn-green summary summary_date' style='margin-right:15px;' "+
         "id='#"+date_id +"' data-date='"+date_str+"'>"+
              date_str+"(<span style='color:red;font-weight:bold;'>"+count+"</span>)"
        "</button>";
    $("#summary_date").append(date_el)
}

function build_summary_product(data_list){
    if (data_list == undefined || data_list == ""){
        return false;
    }
    for (pid in data_list){
        var count = data_list[pid]
        var el_id = "p_"+pid;
        var product_el = $("#summary_product #"+el_id);

        if (product_el.length > 0){
            count = product_el.data('count') + count;
            product_el.data('count', count);
            product_el.children('span.count').text(count);
        }else{
            var pname = $("#data_type option[value="+pid+"]").text();
            var product_html = "<button class='btn btn-green summary summary_product' style='margin-right:15px;' "+
                  "id='"+el_id+"' data-count="+count+" data-pid="+pid+" >"+
                                    pname+"(<span class='count' style='color:red;font-weight:bold;'>"+count+"</span>)"+
                             "</button>";
            $("#summary_product").append(product_html)
        }
    }
}


function do_get_session_list(data_param, start_date, end_date){
    data_param['date'] = get_date_str(end_date);
    var url = "/session_ana/list/"

    $.ajax({
        url: url,
        type: 'post',
        dataType: 'json',
        async: true,
        data: data_param,
        success: function (result) {
            var date_count = 0;
            if (result.status == 0) {
                var object = $('#timeline li:last')
                object = create_li_head_first(object, date_str);
                for (var data_idx = 0; data_idx < result.data.length; data_idx++) {
                    object = create_li_item(object, result.data[data_idx], date_str);
                }
                if (result.data.length > 0) {
                    date_count = result.data.length;
                    session_result = true;
                }
                set_select_val("#uid_type", result.uid_type_hit)
                create_li_head_tail(object, date_str);
            }
            build_summary_date(date_str, date_count)
            build_summary_product(result.data_product)

            if(end_date > start_date){
                end_date = add_days(end_date, -1);
                do_get_session_list(data_param, start_date, end_date);
            } else {
                after_submit(session_result, end_date)
                return false;
            }
        }
    });
}


function register_event(){
    $(document).mousewheel(function (event, delta) {
        $(".daterangepicker").eq(0).css("display", "none");
    });

    $("#snid_scan" ).bind( "click", function() {
        $("#div_img_snid").modal('show');
    });

    $("#submit_button" ).bind( "click", function() {
        get_session_list();
    });

    $("body").delegate("button.summary_date","click",function(){
        var date_click = $(this).data("date")
        $("#timeline li[data-date!='"+date_click+"']").hide()
        $("#timeline li[data-date='"+date_click+"']").show()
    });

    $("body").delegate("button.summary_product","click",function(){
        var click_id = $(this).data("pid")
        $("#timeline li[data-pid!='"+click_id+"']").hide()
        $("#timeline li[data-pid='"+click_id+"']").show()
        $("li.time-label").each(function(el) {
            var date_label = $(this).data("date");
            if($("li.auto_li[data-date="+date_label+"]:visible").length <= 0 ){
                $(this).hide()
            } else {
                $(this).show()
            }
        });
    });

    $("button.btn_day_scroll" ).bind( "click", function() {
        var type = $(this).data("type");
        
        var date_range = $("#time_field").val().split(' to ');
        var start_date = new Date(Date.parse(date_range[0]));
        var end_date = new Date(Date.parse(date_range[1]));

        if(type == "pre"){
            var day_before = add_days(start_date, -1);
        } else if (type == "next"){
            var now_date_pre = new Date(Date.parse(get_pre_date(1)));
            if (end_date >= now_date_pre){
                return false;
            }
            var day_before = add_days(end_date, 1);
        }

        var start_date = end_date = get_date_str(day_before);
        var last_month = get_pre_month(1);
        //initDateRange(start_date, end_date, {'min_date':get_pre_month(1), 'max_date':);
        $("#time_field").val(start_date+" to "+end_date);

        $("#submit_button" ).click()
    });

}


$(document).ready(function () {
    var end_date = get_pre_date(1);
    var start_date = last_week = get_pre_date(7);
    var last_month = get_pre_month(1);
    //initDateRange(start_date, end_date);
    initDateRange(start_date, end_date, {'min_date':last_month, 'max_date':end_date});
    $("select.select2").select2()
    register_event();
    //get_session_list();

});


