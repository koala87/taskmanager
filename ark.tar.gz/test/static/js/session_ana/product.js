var table_list = null;
var table_id = 0;

$(function () {
    init_event_create_product()
    init_table();
    $("#table_list.table-bordered").css("border", "none");
    $("#table_list").parent("div.col-sm-12").css("padding-right", "13px");
 });


function init_table()
{
    table_list = $('#table_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/shuqi_toufang/get_table_list/",
            "url": "/session_ana/product/get_product_list/",
            "type": "POST",
            "data":function(d){
                d.test = '';
            },
        },
        "pageLength":10,
        "lengthChange": false,
        "sDom": "<'row'<'col-sm-12'tr>><'row'<'col-sm-6'i><'col-sm-6'p>>",
        "language":{
            "sLengthMenu": "test-sL",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },

        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    data = full.name
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[1],
                "render":function(data,type,full){
                    data = full.code
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[2],
                "render":function(data,type,full){
                    data = full.status
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[3],
                "render":function(data,type,full){
                    data = full.desc
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    data = full.view_type
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    data = full.create_user
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[6],
                "render":function(data,type,full){
                    var ret = '<a data-id="'+full.id+'" class="op_update" >编辑</a> ' +
                              '| <a data-id="'+full.id+'" class="op_delete" >删除</a> '
                    return ret;
                },
            }
        ],
    });
}

function init_event_create_product(){
    console.log("init...")
    //show create-modal
    $("button.create" ).bind( "click", function() {
      $("#add_table_model").modal('show');
    });

    //submit-create-form
    $("#btn_do_create_product" ).bind( "click", function() {
        create_product()
    });
    
}

function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function() {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function() {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function(a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function(a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return + Globalize.parseDate(a)
                }
                return a
            },
            _format: function(a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function() {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}

function update_table_enable(table_id){
    $("#table_enable_busy_icon").show();
    $.ajax({
        url: '/interest_graphs/shuqi_toufang/get_table_enable/',
        data: { "table_id": table_id},
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            $("#table_enable_busy_icon").hide();
            if (result.status != 0) {
                showMessage("error", "获取应用开关信息", result.msg);
                return;
            }

            var table_enable = result.data.table_enable || 0;
            var table_hour = result.data.table_hour || 0;

            var html_hour = "";
            for (i = 0; i < 24; i++) {
                html_hour += "<option value='" + i + "' > " + i + " 点</option>";
            }
            $("#table_enable_hour_select").html("");
            $("#table_enable_hour_select").append(html_hour);
            $("#table_enable_hour_select").val(table_hour);

            init_select2_async();

            $("#fix_table_enable_model").modal('show');
            $('#fix_table_enable_model #btn_update_table_user_ok').attr('onclick', 'do_update_table_enable('+table_id+')');

            $("#table_enable_flag_select").bootstrapSwitch('state', table_enable, true);
            $("#table_enable_flag_select").on('switchChange.bootstrapSwitch', function(event, state) {
                if(state === true){
                    $("#div_table_enable_hour_select").show();
                } else {
                    $("#div_table_enable_hour_select").hide();
                }
            });

            if (table_enable == 0) {
                $("#div_table_enable_hour_select").hide();
            } else {
                $("#div_table_enable_hour_select").show();
            }

        }
    });

}

function do_update_table_enable(table_id) {
    $("#table_enable_busy_icon").show();
    var table_enable = $('#table_enable_flag_select').bootstrapSwitch('state') ? 1 : 0;
    // 修改应用激活开关
    $.ajax({
        url: '/interest_graphs/shuqi_toufang/update_table_enable/',
        data: { "table_id": table_id, "table_enable": table_enable, "table_hour": $("#table_enable_hour_select").val() },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            $("#table_enable_busy_icon").hide();
            if (result.status != 0) {
                showMessage("error", "修改应用开关", result.msg);
                return;
            } else {
                showMessage("success", "修改应用开关", result.msg);
            }
            table_list.ajax.reload();
            $("#fix_table_enable_model").modal('hide');
        }
    });
}


function update_table_users(table_id) {
    $('#table_managers_select').html("");
    $('#table_users_select').html("");
    var url = "/interest_graphs/shuqi_toufang/get_all_user_list/";
    $.ajax({
        type: "post",
        url: url,
        async: false,
        dataType: "json",
        success: function (result) {
            if (result.status) {
                // alert(result.msg);
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            } else {
                $.ajax({
                    url: '/interest_graphs/shuqi_toufang/get_author_list/',
                    type: 'POST',
                    data: { "table_id": table_id, "auth_tag": 1 },
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success: function (sub_result) {
                        var reportTo = "";
                        if (sub_result.status != 0) {
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                reportTo += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                            }
                        } else {
                            var arr = new Array();
                            for (var i = 0; i < sub_result.data.length; ++i) {
                                arr.push(sub_result.data[i].user_id);
                            }
                            var users = result.user_list;
                            for (var i = 0; i < users.length; i++) {
                                if (arr.indexOf(users[i].id) >= 0) {
                                    reportTo += "<option value='" + users[i].id + "' selected='true'>" +
                                    users[i].name + "</option>";
                                } else {
                                    reportTo += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }
                        }
                        $("#table_managers_select").append(reportTo);
                    }
                });
                $.ajax({
                    url: '/interest_graphs/shuqi_toufang/get_author_list/',
                    type: 'POST',
                    data: { "table_id": table_id, "auth_tag": 2 },
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success: function (sub_result) {
                        var reportTo = '';
                        if (sub_result.status != 0) {
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                reportTo += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                            }
                        } else {
                            var arr = new Array();
                            for (var i = 0; i < sub_result.data.length; ++i) {
                                arr.push(sub_result.data[i].user_id);
                            }
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                if (arr.indexOf(users[i].id) >= 0) {
                                    reportTo += "<option value='" + users[i].id + "' selected>" +
                                    users[i].name + "</option>";
                                } else {
                                    reportTo += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }
                        }
                        $("#table_users_select").append(reportTo);
                        init_select2_async();
                        $("#fix_table_users_model").modal('show');
                        $('#fix_table_users_model #btn_update_table_user_ok').attr('onclick', 'do_update_table_user('+table_id+')');
                    }
                });
            }
        }
    });
}

function do_update_table_user(table_id) {
    var auth_list = '';
    if ($("#table_managers_select").val() != null) {
        auth_list = $("#table_managers_select").val().join(',');
    }
    $.ajax({
        url: '/interest_graphs/shuqi_toufang/update_table_author/',
        type: 'POST',
        data: { "table_id": table_id, "auth_id_list": auth_list, "auth_tag": 1 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改管理员失败", result.msg);
                return;
            }
        }
    });

    var auth_list = '';
    if ($("#table_users_select").val() != null) {
        auth_list = $("#table_users_select").val().join(',');
    }

    $.ajax({
        url: '/interest_graphs/shuqi_toufang/update_table_author/',
        type: 'POST',
        data: { "table_id": table_id, "auth_id_list": auth_list, "auth_tag": 2 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改使用者失败", result.msg);
                return;
            }
            table_list.ajax.reload();
            $("#fix_table_users_model").modal('hide');
        }
    });
}


// 创建
function create_product() {
    var modal_id = "add_table_model"
    var form_data = get_form_data(modal_id+" form", "json")
    console.log("form_data..", form_data)

    var url = "/session_ana/product/create/";
    var callback = function(){table_list.ajax.reload();};

    ajax_post(url, form_data, msg_title="创建业务数据", modal_id, async_type=true, callback);

}


function get_form_data(form_selector, data_type){
    if (!form_selector || form_selector == undefined ) return;
    form_el = $("#"+form_selector);
    if (form_el.length <= 0) return;

    var data;
    if(data_type == "json"){
        data = {}
        data_list = form_el.serializeArray()
        $.each(data_list, function(i, field){
            data[field.name] = field.value;
        });

    }else {
        data = form_el.serialize()
    }
    return data

}

function ajax_post(url, data, msg_title, modal_id, async_type, callback){

    if (async_type !== true) async_type = false
    if (!msg_title) msg_title = "操作";

    $("#busy_icon").show();

    $.ajax({
        url: url,
        data: data,
        type: 'POST',
        dataType: "json",
        async: async_type,
        success: function (result) {
            $("#busy_icon").hide();
            if (result.status != 0) {
                showMessage("error", msg_title, result.msg);
                return;
            }
            table_list.ajax.reload();
            if (callback) callback()
            $("#"+modal_id).modal('hide');
        }
    });
}

function delete_table(table_id) {
    $('#delete_table_model #btn_do_delete_table_ok').attr('onclick', 'do_delete_table('+table_id+')');
    $("#delete_table_model").modal('show');
}

function do_delete_table(table_id) {
    $("#delete_table_busy_icon").show();
    // 删除应用列表
    $.ajax({
        url: '/interest_graphs/shuqi_toufang/delete_table/',
        type: 'POST',
        data: { "table_id": table_id },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            $("#delete_table_busy_icon").hide();
            if (result.status != 0) {
                showMessage("error", "删除应用失败", result.msg);
                return;
            }
            table_list.ajax.reload();
        $("#delete_table_model").modal('hide');
        }
    });
}

function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}
