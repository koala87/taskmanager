var all_group_conf = [
        {name:'分析', icon:'/static/images/index/index_icon_analysis.png', color:'#0099CC'},
        {name:'数据', icon:'/static/images/index/index_icon_data.png', color:'#00CC99'},
        {name:'开发', icon:'/static/images/index/index_icon_console.png', color:'#00CCFF'},
        {name:'标签', icon:'/static/images/index/index_icon_tag.png', color:'#FF6600'},
        {name:'其他', icon:'/static/images/index/index_icon_other.png', color:'#FF0099'},
    ];
$(function(){
    $(".homepage_setting").on('click', function(){
        if($("#id_user").val() == 'None')
        {
            window.location.href = '/login/';
            return;
        }
        $(".homepage_setting").show();
        $(this).hide();
        config_home_page();
    });
    $(document).on('click', ".item_op_remove", function(){
        var id = $(this).parent().attr('action-data');
        var url = '/common/home_link/remove/';
        var post_data = {id:id};
        var result = makeAPost(url, post_data);
        if(result.status != 0)
        {
            return ark_notify(result);
        }
        $(this).parent().parent().remove();
        var item = $(".group_content .item_container[action-data='"+id+"'] .item_op");
        item.removeClass('item_op_no');
        if(!item.hasClass('item_op_add'))
        {
            item.addClass('item_op_add');
        }
        item.html('+');
    });
    $(document).on('click', ".item_op_add", function(){
        var id = $(this).parent().attr('action-data');
        var url = '/common/home_link/add/';
        var post_data = {id:id};
        var result = makeAPost(url, post_data);
        if(result.status != 0)
        {
            return ark_notify(result);
        }
        $(".links_block_body_choosen").append('<div class="col-sm-2 group_choosen">\
                                            <div class="item_container item_editting" action-data="'+id+'">\
                                                <a href="'+$(this).parent().find('a').prop('href')+'">'+$(this).parent().find('a').html()+'</a>\
                                                <span class="item_op item_op_remove" style="display: inline;">×</a>\
                                            </div>\
                                        </div>');
        $(this).removeClass('item_op_add');
        if(!$(this).hasClass('item_op_no'))
        {
            $(this).addClass('item_op_no');
        }
        $(this).html('√');
    });
    init_choosen_list();
    init_choosen_list_all();
});
function init_choosen_list()
{
    var url = '/common/home_link/list/';
    var post_data = {};
    var args = {};
    var callback = callback_init_choosen_list;
    makeAPost(url, post_data, true, callback, args);
}
function callback_init_choosen_list(result, args)
{
    $(".links_block_body_choosen").html('');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    for(var i in result.data)
    {
        $(".links_block_body_choosen").append('<div class="col-sm-2 group_choosen">\
                                                 <div class="item_container" action-data="'+result.data[i].id+'">\
                                                     <a href="'+result.data[i].url+'">'+result.data[i].title+'</a>\
                                                     <span class="item_op item_op_remove">×</a\
                                                 </div>\
                                             </div>');
    }
}
function init_choosen_list_all()
{
    var url = '/common/home_link/list_all/';
    var post_data = {};
    var args = {};
    var callback = callback_init_choosen_list_all;
    makeAPost(url, post_data, true, callback, args);
}
function callback_init_choosen_list_all(result, args)
{
    $(".links_block_body_all").html('');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    for(var i in all_group_conf)
    {
        var group_name = all_group_conf[i].name;
        if(result.data[group_name] != undefined && result.data[group_name].length > 0)
        {
            var html = '<div class="row">\
                            <div class="col-sm-2 group_label"><img src="'+all_group_conf[i].icon+'"><span class="group_title" style="color: '+all_group_conf[i].color+';">'+group_name+'</span></div>\
                                <div class="col-sm-10 group_content">';
            for(var j in result.data[group_name])
            {
                html += '<div class="col-sm-2 group_item">\
                             <div class="item_container" action-data="'+result.data[group_name][j].id+'">\
                                 <a href="'+result.data[group_name][j].url+'">'+result.data[group_name][j].title+'</a>\
                                 <span class="item_op">+</span>\
                             </div>\
                         </div>';
            }
            html += '   </div>\
                     </div>';
            $(".links_block_body_all").append(html);
        }
    }
}
function config_home_page()
{
    var choosen_id = [];
    $(".group_choosen .item_container").each(function(){
        choosen_id.push($(this).attr('action-data'));
    });
    $(".group_content .item_container").each(function(){
        var id = $(this).attr('action-data');
        var item = $(this).find('.item_op');
        if(choosen_id.indexOf(id) < 0)
        {
            item.removeClass('item_op_no');
            if(!item.hasClass('item_op_add'))
            {
                item.addClass('item_op_add');
            }
            item.html('+');
        }
        else
        {
            item.removeClass('item_op_add');
            if(!item.hasClass('item_op_no'))
            {
                item.addClass('item_op_no');
            }
            item.html('√');
        }
    });
    $(".links_block_body a").each(function(){
        $(this).parent().addClass('item_editting');
        $(this).next().show();
    });
}
