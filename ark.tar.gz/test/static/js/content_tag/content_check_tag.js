var table_list = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var candidate_obj = null;
var click_parent_id = null;
var table_container = "#table_list";

$(function () {
    if ($('#global_parent_id').val() != undefined && $('#global_parent_id').val() != -1) {
        click_parent_id = $('#global_parent_id').val();
    }
    init_table(table_container);
    $("#table_list.table-bordered").css("border", "none");
    $("#table_list").parent("div.col-sm-12").css("padding-right", "13px");
    $('#start_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });
    $('#end_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });

    $(document).on("change", "#id_tag_filter_name", function (e) {
        click_parent_id = null;
        table_reload();
    });
    $(document).on("change", "#start_update_time", function (e) {
        click_parent_id = null;
        table_reload();
    });
    $(document).on("change", "#end_update_time", function (e) {
        click_parent_id = null;
        table_reload();
    });
    $(document).on("change", "#tag_type_select", function (e) {
        click_parent_id = null;
        table_reload();
    });
    $(document).on("change", "#check_status_select", function (e) {
        click_parent_id = null;
        table_reload();
    });


    import_dict_new_1();
    import_dict_new_2(-1);
    import_dict_new_3(-1);
    $(document).on("change", "input.ct_select_dict_list_new_1", function (e) {
        import_dict_new_2(-1);
        import_dict_new_3(-1);
        if(e.added != undefined)
        {
            import_dict_new_2(e.added.id);
        }
    });

    $(document).on("change", "input.ct_select_dict_list_new_2", function (e) {
        import_dict_new_3(-1);
        if(e.added != undefined)
        {
            import_dict_new_3(e.added.id);
        }
    });


    //全选
    $('#checkall').on('change',function(){
        if($(this).is(':checked')){
            $('.ct_allcheck').each(function(){
                $(this).prop('checked',true);
            });
        }else{
            $('.ct_allcheck').each(function(){
                $(this).prop('checked', false);
            });
        }
    });

    //审核字段全选
    $('input.check_f_all').on('change',function(){
        var checked = $(this).is(':checked');
        $('.check_f').each(function(){
            $(this).prop('checked', checked);
            // show_hide_table_column($(this).val(), checked);
        });
    });
    $('input.check_f').on('change',function(){
        var column_name = $(this).val();
        var open_flag = $(this).is(':checked');
        // console.log("column_name..", column_name, "..open_flag", open_flag);
        // show_hide_table_column(column_name, open_flag);
    });


});


function show_hide_table_column(column_name, open_flag){
    var data_src = table_list.columns().dataSrc();
    if (data_src.length > 0){
        for (var i=0; i< data_src.length; i++){
            if(data_src[i] == column_name){
                table_list.column(i).visible(open_flag);
                draw_bg_td();
            }
        }
    }
    return;
}


function draw_bg_td(){
    //$("td .bg_default").parents("td").css("background-color", "#FEF5F1");
    $("td .bg_to_check").parents("td").css("background-color", "#FEF5F1");
}


function table_reload(){
    table_list.ajax.reload();
}


function refresh_table_list() {
    var el = $('#table_list_paginate ul.pagination li.active');
    if (el.length > 0 && el.index() >= 0){
        el.trigger('click',function(){
            el.addClass('active');
        });
    }
}


function search_tag() {
    refresh_table_list();
}

function delete_tags(tag_id) {
    var tag_list = "" + tag_id;
    $.ajax({
        url: '/content_tag/tag_mgr/delete_tag/',
        type: 'POST',
        data: { "tag_id_list": tag_list },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            refresh_table_list();
        }
    });
}

function import_dict_new_1()
{
    $.ajax({
        url: '/content_tag/tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_1").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },
            });
        }
    });
}

function import_dict_new_2(first_div_id)
{
    if (first_div_id == -1) {
        $("input.ct_select_dict_list_new_2").val(null).trigger("change");
        $("input.ct_select_dict_list_new_2").select2({
            placeholder: '请先选择一级分类',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true,
            initSelection: function (element, callback) {
                var data = [{id: element.val(), text: element.val()}];
                callback({id: element.val(), text: element.val()});//这里初始化
            },

        });
        return;
    }

    $.ajax({
        url: '/content_tag/tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_2").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },

            });
        }
    });
}

function import_dict_new_3(first_div_id)
{
    if (first_div_id == -1) {
        $("input.ct_select_dict_list_new_3").val(null).trigger("change");
        $("input.ct_select_dict_list_new_3").select2({
            placeholder: '请先选择二级分类',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true,
            initSelection: function (element, callback) {
                var data = [{id: element.val(), text: element.val()}];
                callback({id: element.val(), text: element.val()});//这里初始化
            },
        });
        return;
    }

    $.ajax({
        url: '/content_tag/tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_3").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },

            });
        }
    });
}

function init_table(table_container, load_flag)
{
    this.load_flag = true;
    if (load_flag === false){
        this.load_flag = false;
    }
    this.tableContainer = table_container;
    var _this = this;
    var bg_class1 = "bg_suc";;
    var bg_class2 = "bg_wait";;
    var bg_classd = "bg_default";;
    var bg_c_to_check = "bg_to_check";;
    this.init_columns = function(){

        var columns_list = [
            {
                data: "id",
                bSortable: false,
                "render":function(data,type,full){
                    return "<input type='checkbox' class='ct_allcheck' tag_name = '" + full.name + "'tag_id='" + data + "'/>";
                },
            },
            {
                data: "name",//标签
                bSortable: false,
                "render":function(data,type,full){
                    bg = (full.check_status == 0) ? bg_c_to_check : bg_classd
                    html = "<span class='"+bg+"' title='"+data+"' >"+data+"</span>";
                    return html;
                },
            }, {
                data: "path",//分类
                bSortable: false,
                // visible: false,
                "render":function(data,type,full){
                    bg = (full.is_path_checked > 0) ? bg_class1 : bg_c_to_check
                    html = "<span class='"+bg+"' title='"+data+"' >"+full.path+"</span>";
                    return html;
                },
            }, {
                data: "tag_obj",//对象
                bSortable: false,
                // visible: false,
                "render":function(data,type,full){
                    bg = (full.is_tagobj_checked > 0) ? bg_class1 : bg_c_to_check
                    var text = "";
                    if (full.is_article == 1 && full.is_video == 1) {
                        text = "文章&视频";
                    }else if (full.is_article == 1) {
                        text = "文章";
                    }else if (full.is_video == 1) {
                       text = "视频";
                    }
                    html = "<span class='"+bg+"' title='"+text+"' >"+text+"</span>";
                    return html;
                }
            }, {
                data: "is_entity_tag",//类型
                bSortable: false,
                // visible: false,
                "render":function(data,type,full){
                    bg = (full.is_entity_checked > 0) ? bg_class1 : bg_c_to_check
                    var text = (data == 1) ? "实体" : "概念";
                    html = "<span class='"+bg+"' title='"+text+"' >"+text+"</span>";
                    return html;
                }
            },{
                data: "notice_type",//突发标签
                bSortable: false,
                "render":function(data,type,full){
                    return (data == 2) ? "是" : "否";
                }
            },{
                data: "hot_media",//媒体热度
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "hot",//query热度
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "id",//来源url
                bSortable: false,
                "render":function(data,type,full){
                    return "<a href='#' onclick='get_tag_urls(" + full.id + ");'>查看</a>";
                }
            },{
                data: "alias",//别名
                bSortable: false,
                // visible: false,
                "render":function(data,type,full){
                    if (full.is_alias_checked > 0){
                        bg = bg_class1;
                        show_text = full.passed_alias;
                    }else{
                        bg = bg_c_to_check;
                        show_text = full.alias;
                    }
                    html = "<span class='"+bg+"' title='"+show_text+"' >"+show_text+"</span>";
                    return html;
                }
            },{
                data: "relate",//关联
                bSortable: false,
                // visible: false,
                "render":function(data,type,full){
                    if (full.is_relate_checked > 0){
                        bg = bg_class1;
                        show_text = full.relate;
                    }else{
                        bg = bg_c_to_check;
                        show_text = full.candidate_relate;
                    }
                    html = "<span class='"+bg+"' title='"+show_text+"' >"+show_text+"</span>";
                    return html;
                }
            },{
                data: "update_time",//更新时间
                bSortable: false,
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                }
            },{
                data: "id",
                bSortable: false,
                "render":function(data,type,full){
                    var ret = ''
                    if (full.is_deleted) {
                        ret += '<a href="javascript:" onclick="recover_deleted_tag('+data+')">恢复</a> ';
                    } else {
                        ret += '<a href="javascript:" onclick="pass_reject_tag_check('+data+', 1)">通过</a> ';
                        ret += '| <a href="javascript:" onclick="pass_reject_tag_check('+data+', 0)">拒绝</a> ';
                        ret += '| <a href="javascript:" onclick="delete_tags('+data+')">删除</a> ';
                    }
                    return ret;
                }
            }
        ];
        var columns = [];
        var columnDefs = [];
        for (var i=0; i < columns_list.length; i++){
            columns.push({"data":columns_list[i].data, "bSortable":columns_list[i].bSortable});
            if(columns_list[i].render != undefined){
                var column_one = {"targets":i, "render":columns_list[i].render}
                if(columns_list[i].visible != undefined){
                    column_one.visible = columns_list[i].visible
                }
                columnDefs.push(column_one);
            }
        }

        return {'columns':columns, 'columnDefs':columnDefs};
    }
    this.get_data_param = function(data_param){
        data_param.tag_name_list = $("#id_tag_filter_name").val();
        data_param.start_time = $("#start_update_time").val();
        data_param.end_time = $("#end_update_time").val();
        data_param.tag_type = $("#tag_type_select").val();
        data_param.check_status = $("#check_status_select").val();
        data_param.type = 1;
        if (click_parent_id != null) {
            data_param.check_status = 2;
            data_param.second_div_id = click_parent_id;
        }

        return data_param;

    }
    this.fnDrawCallback = function(oSettings){
        draw_bg_td();
    }

    this.init = function(){
        var url = "/content_tag/tag_mgr/get_tag_list/";
        var sdom = "<'top'i>frt<'bottom'p<'#page-length-choose' l><'#bottom-info-show' i>><'clear'>";

        var data_param = _this.get_data_param;
        var fnDrawCallback = _this.fnDrawCallback;
        var columns_init = _this.init_columns();

        var columns = columns_init.columns;
        var columnDefs = columns_init.columnDefs;
        var option = {
            'load_flag' : true,
            'server_side' : true,
            'searching' : false,
            'url' : url,
            'order_column' : [ 1, 'asc' ],//设置列的默认排序方式
            'tableContainer' : table_container,
            'fnDrawCallback' : fnDrawCallback,
            'sdom' : sdom,
            'data_param' : data_param,
            'columns' : columns,
            'columnDefs' : columnDefs,
            'page_length' : 20,
            'language' : {'sInfo':"当前 _START_ to _END_ , 共 _TOTAL_ 条"},
        };

        var data_table = new DataTable(option);
        table_list = data_table.tableObj;

        return false;
    }

    if (this.load_flag !== false){
        this.init();
    }

}


function pass_reject_tag_check(tag_id, op_type) {
    tag_list = tag_id;

    var cf_checkboxlist=$('.cf:checked');
    var cf_list = "";
    cf_checkboxlist.each(function(){
        var cf_val = $(this).val()
        if (cf_val != undefined && cf_val != "all") {
            cf_list += $(this).val()+",";
        }
    });

    var data_param = { "tag_id_list":tag_list, "check_status": op_type, "check_field":cf_list};
    var url = "/content_tag/tag_check/batch_tag_check/"

    $.ajax({
        url:url,
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }else{
                showMessage("success", "标签审核", "操作成功")
                refresh_table_list();
            }
        }
    });


}

function batch_check(op_type){
    var checkboxlist=$('.ct_allcheck:checked');
    tag_list = "";
    tag_name_list = "";
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            tag_list += $(this).attr('tag_id')+",";
            tag_name_list += $(this).attr('tag_name')+",";
        }
    });
    if (tag_list == "") {
        showMessage("info", "提示", "请选择需要操作的项！");
        return false;
    }

    var cf_checkboxlist=$('.cf:checked');
    var cf_list = "";
    cf_checkboxlist.each(function(){
        var cf_val = $(this).val()
        if (cf_val != undefined && cf_val != "all") {
            cf_list += $(this).val()+",";
        }
    });

    var data_param = { "tag_id_list":tag_list, "check_status": op_type, "check_field":cf_list};
    var url = "/content_tag/tag_check/batch_tag_check/"

    $.ajax({
        url:url,
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }else{
                showMessage("success", "批量审核", "操作成功")
                refresh_table_list();
            }
        }
    });
}


function get_tag_urls(tag_id) {
    $.ajax({
        url: '/content_tag/tag_check/get_tag_urls/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }

            var tb = document.getElementById('url_view_body');
            var rowNum=tb.rows.length;
            for (i=0;i<rowNum;i++) {
                tb.deleteRow(i);
                rowNum=rowNum-1;
                i=i-1;
            }

            var row = document.createElement("tr");
            document.getElementById("url_view_body").appendChild(row);
            var key_cell = document.createElement("td");
            inner_html = "url";
            key_cell.innerHTML = inner_html;
            row.appendChild(key_cell);

            for (var i = 0; i < result.url_list.length; ++i) {
                var row = document.createElement("tr");
                document.getElementById("url_view_body").appendChild(row);
                var key_cell = document.createElement("td");
                inner_html = '<a href="' + result.url_list[i] +'" target="_blank">' + result.url_list[i]  + '</a> ';
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);
            }
            $("#url_view_model").modal('show');
        }
    });
}

function recover_deleted_tag(tag_id) {
    $.ajax({
        url: '/content_tag/tag_check/recover_deleted_tag/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            refresh_table_list();
        }
    });
}



function create_new_tag_batch() {
    $('#add_new_tag_title').html("新建标签");
    $('#new_tag_name').val('');
    $('#new_tag_check_status_id').val(0);

    $("input[id='new_tag_tag_type_article']").removeAttr("checked");
    $("input[id='new_tag_tag_type_video']").removeAttr("checked");
    $("input[id='new_tag_book_tag']").removeAttr("checked");
    $("input[id='new_tag_entity_tag']").removeAttr("checked");
    $("input[id='new_tag_tag_type_article']").prop("checked", true);
    $("input[id='new_tag_tag_type_video']").prop("checked", true);
    $("input[id='new_tag_entity_tag']").prop("checked", true);

    import_dict_new_2(-1);
    import_dict_new_3(-1);
    $("input.ct_select_dict_list_new_1").select2("data", null);
    $("input.ct_select_dict_list_new_2").select2("data", null);
    $("input.ct_select_dict_list_new_3").select2("data", null);

    $('#new_tag_guid').val("");
    $('#new_tag_alias').val("");

    $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_create_new_tag()');
    $("#add_new_tag_model").modal('show');
}

function do_create_new_tag() {
    var tag_name = $('#new_tag_name').val();
    var check_status = $('#new_tag_check_status_id').val();
    var parent_id = -1;
    var first_div = $("input.ct_select_dict_list_new_1").val();
    if (first_div != undefined && first_div.trim() != "") {
        parent_id = first_div;
    } else {
        showMessage("info", "提示", "必须选择一级分类！");
        return;
    }
    var second_div = $("input.ct_select_dict_list_new_2").val();
    if (second_div != undefined && second_div.trim() != "") {
        parent_id = second_div;
    }

    var third_div = $("input.ct_select_dict_list_new_3").val();
    if (third_div != undefined && third_div.trim() != "") {
        parent_id = third_div;
    }
    var is_article = $("input[id='new_tag_tag_type_article']").is(':checked');
    if (is_article) {
        is_article = 1;
    } else {
        is_article = 0;
    }
    var is_video = $("input[id='new_tag_tag_type_video']").is(':checked');
    if (is_video) {
        is_video = 1;
    } else {
        is_video = 0;
    }
    var is_book_tag = $("input[id='new_tag_book_tag']").is(':checked');
    if (is_book_tag) {
        is_book_tag = 1;
    } else {
        is_book_tag = 0;
    }
    var is_entity_tag = $("input[id='new_tag_entity_tag']").is(':checked');
    if (is_entity_tag) {
        is_entity_tag = 1;
    } else {
        is_entity_tag = 0;
    }
    var guid = $('#new_tag_guid').val();
    var alias = $('#new_tag_alias').val();
    $.ajax({
        url: '/content_tag/tag_mgr/create_new_tag_batch/',
        type: 'POST',
        data: { "name": tag_name, "parent_id": parent_id,
                 "check_status": check_status, "is_article": is_article,
                 "is_video": is_video, "is_book_tag": is_book_tag,
                 "is_entity_tag": is_entity_tag, "alias": alias,
                 "guid": guid},
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

