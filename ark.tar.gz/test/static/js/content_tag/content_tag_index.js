var table_list = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var add_node_str = "+添加节点";
var tree_container = "#favorite_tree";
$(function () {
    get_favorite_tree();
    init_event_drag_tree()
    $(document).on('change', ".input_favorite_search", function () {
        $(tree_container).tree("doFilter", $(".input_favorite_search").val().trim());
        $(tree_container).tree("expandAll");
    });
});

function down_load_class_tag(tag_id) {
    var params = {
        "tag_id": tag_id
    };
    var url = '/content_tag/tag_mgr/download_class_tag/?' + $.param(params);
    location.href = url;
}


function down_load_all_tags(tag_id) {
    var params = {
        "tag_id": tag_id
    };
    var url = '/content_tag/tag_mgr/download_all_tags/?' + $.param(params);
    location.href = url;
}

function drag_classtag(){
    var tree_data = $(tree_container).tree("getRoots");
    var id_parentid_list = get_id_parentid(tree_data, -1);
    parent_list_json = JSON.stringify(id_parentid_list );
    var data_param = {parent_data:parent_list_json};
    var url = "/content_tag/class_tag/drag_class_tag/";
    $.ajax({
        url: url,
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            get_favorite_tree(false);
        }
    });
}

function get_id_parentid(tree_data, parent_id){
    var data = [];
    for (var i=0; i<tree_data.length; i++){
        var id = tree_data[i].id;
        if (id == parent_id){
            continue;
        }
        data.push({"id":id, "parent_id":parent_id})
        if (tree_data[i].children != undefined && tree_data[i].children.length > 0){
            data_children = get_id_parentid(tree_data[i].children, id);
            data = $.merge(data_children, data)
        }

    }
    return data;
}

function init_event_drag_tree(){
    $(document).on("click", "#btn_drag_table", function (e) {
        var el = $(this);
        var action_type = el.data("action")
        if (action_type == "" || action_type == "1"){
            $(tree_container).tree("enableDnd")
            el.text("完成并提交")
            el.data("action", "2")

        }else{
            el.text("标签路径移动")
            el.data("action", "1")
            $(tree_container).tree("disableDnd")
            drag_classtag();
        }
    });
    $('#btn_drag_table').tooltipster({
        side: 'right',
        delay: [100, 200],
        delayTouch: [100, 200],
        trigger: 'custom',
        triggerOpen: {mouseenter: true},
        triggerClose: {mouseleave: true,scroll: true},

        functionInit: function(instance, helper){
            var content = "点击路径移动后，拖拽左侧标签树，可进行标签位置的移动。操作完成后，提交生效。";
            instance.content(content);
        },
    });
}


function get_favorite_tree(drag_able)
{
    if (drag_able == undefined || drag_able !== true){
        drag_able = false;
    }
    var url = '/content_tag/class_tag/get_tag_tree/';
    var load_flag = false;
    $(tree_container).tree({
        url: url,
        animate: true,
        lines: true,
        dnd:drag_able,
        formatter: function (node) {
            if (node.text == add_node_str) {
                return '<span style="float:left" onclick="add_new_class_tag(' + node.id + ');"><font color="blue">' + node.text + '</font></span> ';
            } else {
                return node.text + '&nbsp;&nbsp;&nbsp;&nbsp;<span class="tree-edit" title="修改标签信息" style="display:none;" id="tree_edit_' + node.id +
                '" onclick="update_class_tag(' + node.id + ');"></span> <span class="tree-add"  title="添加子节点" style="display:none;" id="tree_add_' + node.id +
                 '" onclick="add_new_class_tag(' + node.id + ');"></span> <span class="tree-delete"  title="删除" style="display:none;" id="tree_delete_' + node.id + '" onclick="delete_class_tag(' + node.id + ');"></span>';
            }
        },
        onHover: function (e, node) {
            if (node.text != add_node_str) {
                $('#tree_add_' + node.id).show();
                $('#tree_delete_' + node.id).show();
                $('#tree_edit_' + node.id).show();
            }
        },
        onHoverLeave: function (e, node) {
            if (node.text != add_node_str) {
                $('#tree_add_' + node.id).hide();
                $('#tree_delete_' + node.id).hide();
                $('#tree_edit_' + node.id).hide();
            }
        },
        onLoadSuccess: function (node, data) {
            if (load_flag){
                return false;
            }else{
                load_flag = true;
            }
            var root_node = $(tree_container).tree('getRoot');
            if (root_node != null && root_node.text != add_node_str) {
                $(tree_container).tree("select", root_node.target);
                get_class_tag_info(root_node.id);
                $('#down_load_class_tag').attr('onclick', 'down_load_class_tag(' + root_node.id + ')');
                $('#down_load_all_tags').attr('onclick', 'down_load_all_tags(' + root_node.id + ')');

            }
        },
        onClick: function (node) {
            var root_nodes = $(tree_container).tree('getRoots');
            if (node.text != add_node_str) {
                get_class_tag_info(node.id);
                $('#down_load_class_tag').attr('onclick', 'down_load_class_tag(' + node.id + ')');
                $('#down_load_all_tags').attr('onclick', 'down_load_all_tags(' + node.id + ')');
            }
        },
        onBeforeDrag:function(node){
        },
        onStartDrag:function(node){
        },
        onStopDrag:function(node){
        },
        onDragEnter:function(target, source){
        },
        onDragOver:function(target, source){
        },
        onDragLeave:function(target, source){
        },
    });
}

function get_class_tag_info(tag_id) {
    $.ajax({
        url: '/content_tag/class_tag/get_tag_info/',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $('#class_tag_name').html('<font size="5">' + result.name + '</font>');

            content_type = [];
            if (result.is_article){
                content_type.push("文章")
            }
            if (result.is_video){
                content_type.push("视频")
            }
            if (result.is_short_video){
                content_type.push("短视频")
            }
            content_type = content_type.join("&");
            if (content_type == ""){
                content_type = "未设置";
            }
            type = "类型：" + content_type;

            $('#class_tag_type').html('<font size="2">' + type + '</font>');
            if (result.is_div) {
                $('#class_tag_is_div').html('<font size="2">仅维度：是</font>');
            } else {
                $('#class_tag_is_div').html('<font size="2">仅维度：否</font>');
            }

            if (result.is_auto_add) {
                $('#class_tag_auto').html('<font size="2">添加方式：机器</font>');
            } else {
                $('#class_tag_auto').html('<font size="2">添加方式：运营</font>');
            }
            $('#class_tag_update_time').html('<font size="2">更新时间：' + result.update_time + '</font>');
            $('#class_tag_editor').html('<font size="2">操作人：' + result.owner_name + '</font>');

            $("#table_list").html('<colgroup>' +
                                   '<col width="20%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                '</colgroup>' +
                                '<thead>' +
                                    '<tr>' +
                                       '<th >名称</th>' +
                                       '<th >子节点数</th>' +
                                       '<th >标签数</th>' +
                                       '<th >待审核标签</th>' +
                                       '<th >topic标签</th>' +
                                       '<th >行业热度</th>' +
                                       '<th >文章数</th>' +
                                    '</tr>' +
                                '</thead>');

            $("#table_list").append("<tr>" +
                                       "<th id=\"table_class_tag_name\">" + result.name + "</th>" +
                                       "<th >" + result.child_num + "</th>" +
                                       "<th ><a href='/content_tag/tag_mgr/?parent_id=" + tag_id + "'>" + result.child_tag_num + "</a></th>" +
                                       "<th ><a href='/content_tag/tag_check/?parent_id=" + tag_id + "'>" + result.child_wait_check_tag_num + "</a></th>" +
                                       "<th ><a href='/content_tag/tag_check/?parent_id=" + tag_id + "'>" + result.topic_tag_num + "</a></th>" +
                                       "<th >" + result.avg_hot + "</th>" +
                                       "<th >" + result.article_num + "</th>" +
                                    "</tr>");
        }
    });
}

function update_class_tag(node_id) {
    $.ajax({
        url: '/content_tag/class_tag/get_tag_info/',
        data: { "tag_id": node_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $('#new_class_tag_name').val(result.name);
            $('#new_class_tag_title').html("修改数据");

            $("input[id='new_class_is_video']").removeAttr("checked");
            $("input[id='new_class_is_short_video']").removeAttr("checked");
            $("input[id='new_class_is_article']").removeAttr("checked");
            $("input[id='new_class_just_div']").removeAttr("checked");

            if (result.is_article) {
                $("#new_class_is_article").prop("checked", true);
            } else {
                $("#new_class_is_article").prop("checked", false);
            }

            if (result.is_video) {
                $("#new_class_is_video").prop("checked", true);
            } else {
                $("#new_class_is_video").prop("checked", false);
            }
            if (result.is_short_video) {
                $("#new_class_is_short_video").prop("checked", true);
            } else {
                $("#new_class_is_short_video").prop("checked", false);
            }

            if (result.is_div) {
                $("input[name='is_div']").prop("checked", true);
            } else {
                $("input[id='new_class_just_div']").removeAttr("checked");
            }

            $('#add_table_model #btn_do_add_class_tag_ok').attr('onclick', 'do_update_class_tag(' + node_id + ')');
            $("#add_table_model").modal('show');
        }
    });
}

function do_update_class_tag(node_id) {
    var tag_name = $('#new_class_tag_name').val();
    var tag_is_article = $("input[id='new_class_is_article']").is(':checked');
    if (tag_is_article) {
        tag_is_article = 1;
    } else {
        tag_is_article = 0
    }
    var tag_is_video = $("input[id='new_class_is_video']").is(':checked');
    if (tag_is_video) {
        tag_is_video = 1;
    } else {
        tag_is_video = 0
    }

    var tag_is_short_video = $("input[id='new_class_is_short_video']").is(':checked');
    if (tag_is_short_video) {
        tag_is_short_video = 1;
    } else {
        tag_is_short_video = 0
    }


    var tag_is_div = $("input[id='new_class_just_div']").is(':checked');
    if (tag_is_div) {
        tag_is_div = 1;
    } else {
        tag_is_div = 0
    }

    $.ajax({
        url: '/content_tag/class_tag/update_class_tag/',
        data: { "name": tag_name, "tag_id": node_id, "is_article": tag_is_article, "is_video": tag_is_video, "is_short_video": tag_is_short_video, "is_div": tag_is_div },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#add_table_model").modal('hide');

            var t = $(tree_container);
            var node = t.tree('getSelected');
            if (node.text != add_node_str) {
                t.tree('update', {
                    target: node.target,
                    text: tag_name
                });
                get_class_tag_info(node_id);
            }
        }
    });
}

function delete_class_tag(node_id) {
    $('#delete_table_model #btn_do_delete_ok').attr('onclick', 'do_delete('+node_id+')');
    $("#delete_table_model").modal('show');
}

function do_delete(node_id) {
    $.ajax({
        url: '/content_tag/class_tag/delete_class_tag/',
        data: { "tag_id": node_id },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#delete_table_model").modal('hide');

            var t = $(tree_container);
            var node = t.tree('getSelected');
            if (node.text != add_node_str) {
                t.tree('remove', node.target);
            }
            var root_node = $(tree_container).tree('getRoot');
            if (root_node != null && root_node.text != add_node_str) {
                $(tree_container).tree("select", root_node.target);
                get_class_tag_info(root_node.id);
            }
        }
    });
}

function add_new_class_tag(node_id) {
    $('#new_class_tag_name').val('');
    $("input[id='new_class_is_video']").removeAttr("checked");
    $("input[id='new_class_is_short_video']").removeAttr("checked");
    $("input[id='new_class_is_article']").removeAttr("checked");
    $("input[id='new_class_just_div']").removeAttr("checked");

    $("input[id='new_class_is_video']").prop("checked", true);
    $("input[id='new_class_is_article']").prop("checked", true);

    $('#new_class_tag_title').html("新建分类");

    $('#add_table_model #btn_do_add_class_tag_ok').attr('onclick', 'do_add_new_class_tag('+node_id+')');
    $("#add_table_model").modal('show');
}

function do_add_new_class_tag(node_id) {
    var tag_name = $('#new_class_tag_name').val();
    var tag_is_article = $("input[id='new_class_is_article']").is(':checked');
    if (tag_is_article) {
        tag_is_article = 1;
    } else {
        tag_is_article = 0;
    }

    var tag_is_video = $("input[id='new_class_is_video']").is(':checked');
    if (tag_is_video) {
        tag_is_video = 1;
    } else {
        tag_is_video = 0;
    }

    var tag_is_short_video = $("input[id='new_class_is_short_video']").is(':checked');
    if (tag_is_short_video) {
        tag_is_short_video = 1;
    } else {
        tag_is_short_video = 0
    }



    var tag_is_div = $("input[id='new_class_just_div']").is(':checked');
    if (tag_is_div) {
        tag_is_div = 1;
    } else {
        tag_is_div = 0;
    }

    $.ajax({
        url: '/content_tag/class_tag/add_new_class_tag/',
        data: { "name": tag_name, "parent_id": node_id, "is_article": tag_is_article, "is_video": tag_is_video, "is_short_video": tag_is_short_video, "is_div": tag_is_div },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#add_table_model").modal('hide');

            var t = $(tree_container);
            var node = t.tree('getSelected');
            if (node.text == add_node_str) {
                for (var i = 0; i < result.ret_list.length; ++i) {
                    t.tree('insert', {
                        before: node.target,
                        data: [{
                            id: result.ret_list[i].id,
                            text: result.ret_list[i].text,
                            state: 'open'
                        }]
                    });
                }
            } else {
                children = t.tree('getChildren', node.target);
                if (children.length > 0) {
                    for (var i = 0; i < result.ret_list.length; ++i) {
                        t.tree('insert', {
                            before: children[0].target,
                            data: [{
                                id: result.ret_list[i].id,
                                text: result.ret_list[i].text,
                                state: 'open'
                            }]
                        });
                    }
                } else {
                    for (var i = 0; i < result.ret_list.length; ++i) {
                        t.tree('append', {
                            parent: (node ? node.target : null),
                            data: [{
                                id: result.ret_list[i].id,
                                text: result.ret_list[i].text,
                                state: 'open'
                            }]
                        });
                    }
                }
            }

            t.tree('expand', node.target);
            var new_node = t.tree('find', result.ret_list[0].id);
            t.tree('select', new_node.target);
            get_class_tag_info(result.ret_list[0].id);
        }
    });
}

function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
}

