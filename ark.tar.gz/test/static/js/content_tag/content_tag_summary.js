$(function () {
    import_dict();
    get_table_data();
    $(document).on("change", "#parentid_select", function (e) {
        get_table_data();
    });

});

//初始化下拉框
function import_dict()
{
    $.ajax({
        url: '/content_tag/tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#parentid_select").select2({
                placeholder: '请选择行业分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true
            });
        }
    });
}

function get_table_data()
{
    var limit = 10;
    var parent_id = $("#parentid_select").val();
    var url = "/content_tag/summary/get_summary_info/";
    var data_param = {parent_id:parent_id};
    $.ajax({
        url: url,
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            console.log("result...", result);
            show_summary_info(result);
            show_table(result, limit);
        }
    });
}

function show_summary_info(result){
    var sum_parent = $("#parentid_select").find("option:selected").text();
    var sum_tag_num = 0;
    var sum_content_user = 0;
    if (result.status == 0){
        for (var i=0; i<result.data.count_tag.length; i++){
            sum_tag_num += result.data.count_tag[i].count;
        }
        for (var i=0; i<result.data.count_content.length; i++){
            sum_content_user += result.data.count_content[i].count;
        }

    }
    $("#sum_parent").html(sum_parent);
    $("#sum_tag_num").html(sum_tag_num);
    $("#sum_content_user").html(sum_content_user);

}

function show_table(result, limit){
    var list = ["tag", "hot", "content"];
    for (var j=0; j< list.length; j++){
        var item = list[j];
        var data_temp = result.data['count_' + item] || [];
        var html = "";
        for (var i=0; i< data_temp.length; i++){
            if (i >= limit)    break;
            var data_one = data_temp[i];
            html += "<tr>"+
                       "<td>"+(i+1)+"</td>"+
                       "<td>"+data_one['name']+"</td>"+
                       "<td>"+data_one['count']+"</td>"+
                   "</tr>";
        }
        if (data_temp.length <= 0){
            html = "<tr><td colspan=3 align='center'>没有数据</td></tr>";
        } else {
            if (item == "tag"){
                var html_url = "<tr><td colspan=3 align='right'><a href='#' onclick='javascript:void();' target='_blank' >" +
                    "&nbsp;</a></td></tr>";
            } else{
                var html_url = "<tr><td colspan=3 align='right'><a href='/content_tag/tag_mgr/' target='_blank' " +
                    " style='color:orange;float:right;margin-right:30px;'>查看更多></a></td></tr>";
            }
            $('#table_list_'+item + " tfoot").html(html_url);
        }
        $('#table_list_'+item + " tbody").html(html);
    }
}
