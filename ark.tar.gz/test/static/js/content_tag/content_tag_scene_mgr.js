
var table_list = null;
var data_table = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var candidate_obj = null;
var click_parent_id = null;
var global_check_alias = null;
var table_container = "#table_list";
var tag_name_type = 0;
var data_search_type = 0;
var data_table_trash = null;
var classtag_id_selected = -1;

var tree_container_select = "#favorite_tree_select";

$(function () {
    if ($('#global_parent_id').val() != -1) {
        click_parent_id = $('#global_parent_id').val();
    }

    init_event_document();

    //init_table(table_container);
    init_event_op();
    //$("#table_list.table-bordered").css("border", "none");
    //$("#table_list").parent("div.col-sm-12").css("padding-right", "13px");

});

function init_event_document(){
    //全选
    $('#checkall').on('change',function(){
        if($(this).is(':checked')){
            $('.ct_allcheck').each(function(){
                $(this).prop('checked',true);
            });
        }else{
            $('.ct_allcheck').each(function(){
                $(this).prop('checked', false);
            });
        }
    });

    //tooltip
    $(table_container).on('mouseenter', 'td', function(){
        init_event_op();
    });

    //导入标签
    $("#uplod_file").change(function() {
        upload_file();
    });

    $('#btn_import_file').on('click',function(){
        $("#import_tag_modal").modal("show");
    });

   $('#id_tag_filter_name').on('change',function(){
        table_reload();
    });

}


function delete_tags(node_id) {
    var checkboxlist=$('.ct_allcheck:checked');
    tag_list = "";
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            tag_list+=$(this).attr('tag_id')+",";
        }
    });

    if (tag_list == "") {
        showMessage("info", "提示", "请选择需要删除的项！");
        return;
    }
    $('#modal_del_tag #btn_do_delete_ok').attr('onclick', 'do_delete_tags('+node_id+')');
    $("#modal_del_tag").modal('show');
}

function do_delete_tags() {
    var url = "/content_tag/scene/delete_tag/";
    var data_param = { "tag_id_list": tag_list };
    var callback_func = function(result){
        if (result.status == 0){
            $("#modal_del_tag").modal('hide');
            refresh_table_list();
        }
    }
    post_ajax_data(url, data_param, {async:false, callback:callback_func, show_success:true});
}

function update_tag(tag_id) {
    $.ajax({
        url: '/content_tag/scene/get_tag_by_id/',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            var model_tag = result.data;

            $('#new_tag_name').val(model_tag.name);
            $("input.ct_select_dict_list_new_1").select2("data", null);

            $("input[id='new_tag_tag_type_article']").removeAttr("checked");
            if (model_tag.is_article) {
                $("input[id='new_tag_tag_type_article']").prop("checked", true);
            }

            $("input[id='new_tag_tag_type_video']").removeAttr("checked");
            if (model_tag.is_video) {
                $("input[id='new_tag_tag_type_video']").prop("checked", true);
            }

            $("input[name=entity_tag_type][value="+model_tag.entity_tag_type+"]").prop("checked",true);

            $('#new_tag_alias').val(model_tag.alias);
            $('#new_tag_note').val(model_tag.note);
            $('#new_tag_prokv').val(model_tag.pro_kv);

            $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_update_tag(' + tag_id + ')');
            $('#add_new_tag_title').html("修改标签");

            get_favorite_tree_select(tree_container_select, model_tag.parent_id);

            $("#add_new_tag_model").modal('show');
        }
    });

}

function do_update_tag(tag_id) {
    var tag_name = $('#new_tag_name').val();
    var is_article = $("input[id='new_tag_tag_type_article']").is(':checked');
    if (is_article) {
        is_article = 1;
    } else {
        is_article = 0;
    }
    var is_video = $("input[id='new_tag_tag_type_video']").is(':checked');
    if (is_video) {
        is_video = 1;
    } else {
        is_video = 0;
    }
    var entity_tag_type = $("input[name='entity_tag_type']:checked").val();
    var alias = $('#new_tag_alias').val();
    var pro_kv = $('#new_tag_prokv').val();
    var note = $('#new_tag_note').val();
    var data_param = {
            "tag_id": tag_id,
            "project": project,
            "name": tag_name,
            "parent_id": classtag_id_selected,
            "is_article": is_article,
            "is_video": is_video,
            "entity_tag_type": entity_tag_type,
            "alias": alias,
            "pro_kv": pro_kv,
            "note": note,
        };
    var url = "/content_tag/scene/update_tag/";
    console.log("data_param...", data_param);
    $.ajax({
        url: url,
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');
            refresh_table_list();
        }
    });

}



function manage_note(tag_id) {
    var url = "/content_tag/scene/get_tag_by_id/";
    var data_param = {"tag_id": tag_id };
    var callback_func = function(result){
        if (result.status == 0){
            $("#id_note").val(result.data.note);

            $('#update_note_model #btn_update_tag_note').attr('onclick', 'do_update_tag_note('+ tag_id + ')');
            $("#update_note_model").modal('show');
        }
    }
    post_ajax_data(url, data_param, {async:false, callback:callback_func, show_success:false});
}

function do_update_tag_note(tag_id) {
    var note = $("#id_note").val();
    var url = "/content_tag/scene/update_tag_note/";
    var data_param = {"tag_id": tag_id, "note": note};
    var callback_func = function(result){
        if (result.status == 0){
            $("#update_note_model").modal('hide');
            refresh_table_list();
        }
    }
    post_ajax_data(url, data_param, {async:false, callback:callback_func, show_success:false});
}


function refresh_table_list() {
    var el = $('#table_list_paginate ul.pagination li.active');
    if (el.length > 0 && el.index() >= 0){
        el.trigger('click',function(){
            el.addClass('active');
        });
    }
}

function create_new_tag_batch() {
    $('#add_new_tag_title').html("新建标签");
    $('#new_tag_name').val('');
    $('#new_tag_check_status_id').val(0);

    $("input[id='new_tag_tag_type_article']").removeAttr("checked");
    $("input[id='new_tag_tag_type_video']").removeAttr("checked");
    $("input[name=entity_tag_type][value=1]").prop("checked",true);

    $('#new_tag_alias').val("");
    $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_create_new_tag()');

    $("#selected_node_path").html("");
    get_favorite_tree_select(tree_container_select);
    $("#add_new_tag_model").modal('show');
}

function do_create_new_tag() {
    var tag_name = $('#new_tag_name').val();
    var is_article = $("input[id='new_tag_tag_type_article']").is(':checked');
    if (is_article) {
        is_article = 1;
    } else {
        is_article = 0;
    }
    var is_video = $("input[id='new_tag_tag_type_video']").is(':checked');
    if (is_video) {
        is_video = 1;
    } else {
        is_video = 0;
    }
    var entity_tag_type = $("input[name='entity_tag_type']:checked").val();
    var alias = $('#new_tag_alias').val();
    var pro_kv = $('#new_tag_prokv').val();
    var note = $('#new_tag_note').val();
    var data_param = {
            "project": project,
            "name": tag_name,
            "parent_id": classtag_id_selected,
            "is_article": is_article,
            "is_video": is_video,
            "entity_tag_type": entity_tag_type,
            "alias": alias,
            "pro_kv": pro_kv,
            "note": note,
        };
    var url = "/content_tag/scene/create_new_tag/";

    $.ajax({
        url: url,
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
}


/******** begin 标签操作 ********/

function search_tag() {
    data_search_type = 0;
    table_reload();
}

function search_tag_kv() {
    var tag_name_list = $("#id_tag_filter_name").val();
    if(tag_name_list == ""){
        showMessage("info", "提示", "请输入标签的属性！");
        $("#id_tag_filter_name").focus();
        return false;
    }
    tag_name_type = 2;
    table_reload();
}

function table_reload(){
    table_list.ajax.reload();
}

function init_table(table_container, load_flag)
{
    this.tableContainer = table_container;
    this.load_flag = true;
    this.url = "/content_tag/scene/get_tag_list/";

    if (load_flag === false){
        this.load_flag = false;
    }
    var _this = this;
    this.init_columns = function(){
        var columns_list = [
            {
                data: "id",
                exclude: true,
                bSortable: false,
                "render":function(data,type,full){
                    return "<input type='checkbox' class='ct_allcheck' tag_name = '" + full.name + "'tag_id='" + data + "'/>";
                },
            },
            {
                data: "id",//标签
                bSortable: true,
                visible: false,
                "render":function(data,type,full){
                    return data;
                },
            },
            {
                data: "name",//标签
                exclude: true,
                bSortable: true,
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='update_tag(" + full.id + ");'>"+data+"</a>";
                },
            }, {

                data: "path",//分类
                bSortable: false,
                "render":function(data,type,full){
                    return data;
                }

            }, {
                data: "id",//对象
                bSortable: false,
                "render":function(data,type,full){
                    if (full.is_article == 1 && full.is_video == 1) {
                        return "文章&视频";
                   }else if (full.is_article == 1) {
                        return "文章";
                   }else if (full.is_video == 1) {
                        return "视频";
                   }
                    return "";
                }
            }, {
                data: "entity_tag_type",//类型
                bSortable: false,
                "render":function(data,type,full){
                    return (data == 1) ? "实体" : "topic";
                }
            },{
                data: "pro_kv",//自定义属性
                bSortable: false,
                "render":function(data,type,full){
                    var data_short = get_word_short(data, 30, "...");
                    return "<span title='"+data+"'>"+data_short+"</span>";
                }
            },{
                data: "owner_name",//审核人
                bSortable: false,
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                }
            },{
                data: "update_time",//更新时间
                bSortable: true,
                //visible: false,
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                }
            },{
                data: "id",
                bSortable: false,
                exclude: true,
                "render":function(data,type,full){
                    var baike_url = "http://baike.baidu.com/item/" + full.name;
                    full.alias = full.alias || "";
                    var ret = '<a class="op_alias op" data-alias="' + full.alias + '" data-id="' + full.id + '">别名</a> '+
                              '| <a href="javascript:" onclick="manage_relate('+full.id +');">关联</a>'+
                              '| <a class="op_note op" data-note="'+full.note+'" data-id="' + full.id + '" >注释</a> '+
                              '| <a href="'+baike_url+'" target="_blank">百科</a> ';

                    return ret;
                }
            }
        ];
        var columnDefs = [];
        var columnExclude = [];
        for (var i=0; i < columns_list.length; i++){
            if(columns_list[i].render != undefined){
                var column_one = {"targets":i, "render":columns_list[i].render}
                if(columns_list[i].visible != undefined){
                    column_one.visible = columns_list[i].visible
                }
                columnDefs.push(column_one);
                if (columns_list[i].exclude != undefined && columns_list[i].exclude == true){
                    columnExclude.push(i);
                }
            }
        }

        return {'columns':columns_list, 'columnDefs':columnDefs, 'columnExclude':columnExclude};
    }

    this.get_data_param = function(d){
        if (d == undefined) d = {};
        d.tag_name_list = $("#id_tag_filter_name").val();
        d.project = project;
        d.parent_id = parent_id;
        d.tag_name_type = tag_name_type;
        console.log("get_data_param...", d);
        tag_name_type = 0;

        return d;
    }

    this.init = function(){
        var sdom = "<'top'i>Cfrt<'bottom'p<'#page-length-choose' l><'#bottom-info-show' i>><'clear'>";

        var data_param = _this.get_data_param;
        var columns_init = _this.init_columns();

        var columns = columns_init.columns;
        var columnDefs = columns_init.columnDefs;
        var columnExclude = columns_init.columnExclude;
        var colVis = {
            order: 'column',
            buttonText: "显示/隐藏列",
            exclude: columnExclude,//不能选择是否显示，默认显示
            restore: "重置",
            showAll: "显示全部",
        }
        var sort_index = 0;
        for (var i=0;i<columns.length;i++){
            if (columns[i].data == "update_time"){
                sort_index = i;
                break;
            }
        }
        var option = {
            'load_flag' : true,
            'server_side' : true,
            'searching' : false,
            'url' : this.url,
            'order_column' : [ sort_index, 'desc' ],//设置列的默认排序方式
            'tableContainer' : table_container,
            'sdom' : sdom,
            'colVis' : colVis,
            'data_param' : data_param,
            'columns' : columns,
            'columnDefs' : columnDefs,
            'page_length' : 20,
            'language' : {'sInfo':"当前 _START_ to _END_ , 共 _TOTAL_ 条"},
        };

        data_table = new DataTable(option);
        table_list = data_table.tableObj;

        return false;
    }

    if (this.load_flag !== false){
        this.init();
    }
}


/******** end 标签操作 ********/


/******** begin 标签路径选择 ********/

function tree_select_node_by_id(tree_container, node_id){
    $(tree_container_select).tree('doFilter', "");
    $(tree_container_select).tree('collapseAll');

    if (node_id != undefined && node_id != ""){
        var node = $(tree_container_select).tree('find', node_id);
        if (node != undefined){
            $(tree_container_select).tree('select', node.target);
            $(tree_container_select).tree("expandTo", node.target);
        }
    }

}
function tree_get_path_abs(tree_container, node_id){
    var path = "";
    if (node_id != undefined && node_id != ""){
        var node = $(tree_container_select).tree('find', node_id);
        if (node != undefined && node != null){
            path = node.text;
            var node_parent = $(tree_container_select).tree('getParent', node.target);
            if (node_parent != undefined && node_parent != null){
                path_parent = tree_get_path_abs(tree_container, node_parent.id);
                if (path_parent != ""){
                    path = path_parent + "->" + path;
                }
            }
        }
    }
    return path;
}

function get_favorite_tree_select(tree_container, node_id){
    var if_to_load = true;
    try{
        var root_node = $(tree_container_select).tree("getRoot");
        var root_children = root_node.children;
        if (root_children.length > 0){
            if_to_load = false;
        }

    }catch(err){
        if_to_load = true;
    }
    if (if_to_load == false){
        tree_select_node_by_id(tree_container, node_id);
        var select_node_text = tree_get_path_abs(tree_container, node_id);
        $("#selected_node_path").html(select_node_text);

        return false;
    }

    var url = '/content_tag/scene/get_tag_tree/?project='+project;
    $(tree_container).tree({
        url: url,
        animate: true,
        lines: true,
        dnd:false,
        loadFilter: function(data){
            var root_node = [{text:"全部", id:-1,state:"open", children:data}];
            return root_node;
        },
        formatter: function (node) {
            if (node.text == "全部"){
                var html_input = "<input type='text' class='tree_search' name='tree_input_search' placeholder='输入关键词快速查找'>";
                return node.text + html_input;
            }else{
                return node.text;
            }
        },
        onClick: function (node) {
            classtag_id_selected = node.id;
            var select_node_text = tree_get_path_abs(tree_container, node.id);
            $("#selected_node_path").html(select_node_text);
        },
        onLoadSuccess: function (node, data) {
            $(tree_container + " input[name=tree_input_search]").on('change',function(){
                $(tree_container).tree("doFilter", $(this).val().trim());
                $(tree_container).tree("expandAll");
            });
            tree_select_node_by_id(tree_container, node_id);
            var select_node_text = tree_get_path_abs(tree_container, node_id);
            $("#selected_node_path").html(select_node_text);
        },
    });
}



/******** end 标签路径选择 ********/


function show_check_alias(tag_id, passed_alias) {
    var alias_list = []
    if (passed_alias != null && passed_alias != 'null' && passed_alias != "") {
        var tmp_list = passed_alias.split('|');
        for (var i = 0; i < tmp_list.length; ++i) {
            var val_i = tmp_list[i];
            if (val_i!='' && ! in_array(val_i, alias_list)){
                alias_list.push(val_i);
            }
        }
    }

    $("input.ct_alias_select").tagsInput({
        'defaultText':'添加别名',
        'width':'400px',
    });
    $("input.ct_alias_select").importTags(alias_list.join(','));

    $('#check_alias_modal #check_alias_btn').attr('onclick', 'do_check_alias('+ tag_id + ')');
    $("#check_alias_modal").modal('show');
}

function do_check_alias(tag_id) {
    var passed_alias = $("input.ct_alias_select").val();
    var url = "/content_tag/scene/check_alias/";
    var data_param = {'tag_id':tag_id, 'passed_alias':passed_alias};

    var callback_func = function(res){
        if (res.status == 0){
            $("#check_alias_modal").modal('hide');
            refresh_table_list();
        }
    }
    post_ajax_data(url, data_param, {async:false, callback:callback_func, show_success:true});
}



function init_event_op(){
    //alias
    alias_tootip_click_func = function(el_id){
        var el = $("a.op_alias[data-id="+el_id+"]");
        if(el && el.length > 0){
            tag_id = el.data('id');
            passed_alias = el.data('alias');

            show_check_alias(tag_id, passed_alias);
        }
        return false;
    }
    $('a.op_alias:not(.tooltipstered)').tooltipster({
        side: 'left',
        delay: [100, 200],
        delayTouch: [100, 200],
        contentAsHTML:true,
        interactive:true,
        trigger: 'custom',
        triggerOpen: {mouseenter: true, click:true},
        triggerClose: {click: true,mouseleave: true,scroll: true},

        functionInit: function(instance, helper){
            var el = $(helper.origin)
            var content = el.data('alias') || "";
            var el_id = el.data('id');
            var alias_html = "暂无别名";
            if(content != ""){
                alias_html = content;
            }
            content = "<div class='tooptip_div' style='max-width:400px;min-width:200px;'>"+
                "<div>别名<span class='tooltip_update' onclick='alias_tootip_click_func("+el_id+")' style='float:right;cursor:pointer;'>编辑</span></div><hr/>"+
                "<div>"+alias_html+"</div></div>";
            instance.content(content);
        },
    });

    //注释
    note_tootip_click_func = function(el_id){
        manage_note(el_id);
        return false;
    }
    $('a.op_note:not(.tooltipstered)').tooltipster({
        side: 'left',
        delay: [100, 200],
        delayTouch: [100, 200],
        contentAsHTML:true,
        interactive:true,
        trigger: 'custom',
        triggerOpen: {mouseenter: true, click:true},
        triggerClose: {click: true,mouseleave: true,scroll: true},

        functionInit: function(instance, helper){
            var el = $(helper.origin)
            var note = el.data('note') || "";
            var el_id = el.data('id');
            var detail_html = "暂无注释";
            if(note != "") detail_html = note;

            var content = "<div class='tooptip_div' style='max-width:400px;min-width:200px;'>"+
                "<div>注释<span class='tooltip_update' onclick='note_tootip_click_func("+el_id+")' style='float:right;cursor:pointer;'>编辑</span></div><hr/>"+
                "<div>"+detail_html+"</div></div>";
            instance.content(content);
        },
    });

}


function download_tags() {
    var tag_name_list = $("#id_tag_filter_name").val();

    var params = {
           "tag_name_list": tag_name_list,
            "parent_id": parent_id,
            "project": project,
        };
    var url = '/content_tag/scene/download_tags/?'+$.param(params);
    location.href = url;
}

function do_update_candidate_relate(tag_id) {
    prev_list = $("input.ct_candidate_mul_tag_prev").val();
    relate_list = $("input.ct_candidate_mul_tag_relate").val();
    next_list = $("input.ct_candidate_mul_tag_next").val();
    $.ajax({
        url: '/content_tag/scene/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#manage_candidate_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

function candidate_tag_manage(tag_id) {
    $("input.ct_candidate_mul_tag_prev").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });
    $("input.ct_candidate_mul_tag_relate").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });
    $("input.ct_candidate_mul_tag_next").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });

    $.ajax({
        url: '/content_tag/scene/get_candidate_relate/',
        type: 'POST',
        data: { "tag_id": tag_id },
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_candidate_mul_tag_prev").attr('action-data', JSON.stringify(result.prev_ret_list));
            $("input.ct_candidate_mul_tag_relate").attr('action-data', JSON.stringify(result.relate_ret_list));
            $("input.ct_candidate_mul_tag_next").attr('action-data', JSON.stringify(result.next_ret_list));
            $("input.ct_candidate_mul_tag_prev").select2("data", result.prev_ret_list);
            $("input.ct_candidate_mul_tag_relate").select2("data", result.relate_ret_list);
            $("input.ct_candidate_mul_tag_next").select2("data", result.next_ret_list);
            candidate_obj = result.data_list;
            refresh_candidate_table();
            $('#manage_candidate_tag_model #btn_update_candidate_relate').attr('onclick', 'do_update_candidate_relate('+ tag_id + ')');
            $("#manage_candidate_tag_model").modal('show');
        }
    });
}

function refresh_candidate_table() {
    var prev_val_list = $("input.ct_candidate_mul_tag_prev").val().split(',');
    var relate_val_list = $("input.ct_candidate_mul_tag_relate").val().split(',');
    var next_val_list = $("input.ct_candidate_mul_tag_next").val().split(',');
    var table_list = "";
    var all_list = "";
    var row_num = 0;
    for (var i = 0; i < candidate_obj.length; ++i) {
        if (prev_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        if (relate_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        if (next_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        table_list += '<th style="white-space:nowrap;overflow:hidden;text-overflow: ellipsis;"><input name="candidate_tag" type="checkbox" value="' + candidate_obj[i].id +'" ><span title="' + candidate_obj[i].text + '">' + candidate_obj[i].text + '</span></th>'
        row_num += 1;
        if (row_num > 3) {
            all_list += '<tr>' + table_list + '</tr>';
            table_list = "";
            row_num = 0;
        }
    }
        if (row_num > 0) {
            all_list += '<tr>' + table_list + '</tr>';
        }

    if (all_list != "") {
        $('#candidate_tags').html(
            '<div style="margin-top:0px;float:left;"><table class="table" id="candidate_tag_table" style="table-layout: fixed;word-break:break-all;word-wrap:break-all;font-family: MicrosoftYaHei;font-size:13px;" cellspacing="0" width="100%">'+
            all_list +
            '</table></div>'
        );
    } else {
        $('#candidate_tags').html("没有候选标签！")
    }
}


function manage_relate(tag_id) {
    init_prev_relate_mul_select(tag_id);
    init_relate_mul_select(tag_id);
    init_next_relate_mul_select(tag_id);
    $.ajax({
        url: '/content_tag/scene/get_relate_list/',
        type: 'POST',
        data: { "tag_id": tag_id },
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }

            $("input.ct_mul_tag_prev").select2("data", result.prev_list);
            $("input.ct_mul_tag_relate").select2("data", result.relate_list);
            $("input.ct_mul_tag_next").select2("data", result.next_list);

            $('#update_relate_model #btn_update_tag_relate').attr('onclick', 'do_update_tag_relate('+ tag_id + ')');
            $("#update_relate_model").modal('show');
        }
    });
}

function do_update_tag_relate(tag_id) {
    prev_list = $("input.ct_mul_tag_prev").val();
    relate_list = $("input.ct_mul_tag_relate").val();
    next_list = $("input.ct_mul_tag_next").val();
    $.ajax({
        url: '/content_tag/scene/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#update_relate_model").modal('hide');
        }
    });

}

function init_prev_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_prev").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/content_tag/scene/get_tag_list_with_query/',
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });
}

function init_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_relate").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/content_tag/scene/get_tag_list_with_query/',
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function init_next_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_next").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/content_tag/scene/get_tag_list_with_query/',
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function upload_file() {
    $("#upload_busy").show();
    $("#batch_file_name").val("");
    var form_data = new FormData($("#form_upload")[0]);
    console.log("form-data...", form_data);
    $.ajax({
        url: '/content_tag/scene/handle_uploaded_file/?project='+project,
        type: 'POST',
        data: form_data,
        cache: false,
        contentType: false,
        processData: false,
        success: function (result) {
            $("#upload_busy").hide();
            if (result.status == 0) {
                $("#batch_file_name").val(result.file_name);
                var msg = "上传文件成功";
                if (result.data != undefined && result.data > 0){
                    msg += "，成功导入标签" + result.data +" 条";
                }
                showMessage("info", "信息", msg);
                refresh_table_list();
            } else {
                $("#uplod_file").val("");
                showMessage("error", "失败", result.msg);
            }
        }
    });
}
