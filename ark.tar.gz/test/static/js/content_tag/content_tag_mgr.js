
var table_list = null;
var data_table = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var candidate_obj = null;
var click_parent_id = null;
var global_check_alias = null;
var table_container = "#table_list";
var tag_name_type = 0;
var data_search_type = 0;
var data_table_trash = null;
var classtag_id_selected = null;

var classtag_id_selected_crud = null;

var tree_container_select = "#favorite_tree_select";


$(function () {
    if ($('#global_parent_id').val() != -1) {
        click_parent_id = $('#global_parent_id').val();
    }

    init_event_document();

    init_table(table_container);
    init_event_op();
    $("#table_list.table-bordered").css("border", "none");
    $("#table_list").parent("div.col-sm-12").css("padding-right", "13px");
    $('#start_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });
    $('#end_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });
    import_dict();
    import_dict2();

    $(document).on("change", "select.ct_select_dict_list", function (e) {
        var val = $(this).val();
        console.log("div1 changed...val=", val);
        import_dict2(val);
        click_parent_id = null;
        table_reload();
        return false;
    });

    $(document).on("change", "select.ct_select_dict_list2", function (e) {
        click_parent_id = null;
        table_reload();
        return true;
    });
    $(document).on("change", "#id_tag_filter_name", function (e) {
        table_reload();
    });
    $(document).on("change", "#start_update_time", function (e) {
        table_reload();
    });
    $(document).on("change", "#end_update_time", function (e) {
        table_reload();
    });

});

function init_event_document(){
    init_event_advance_filter();

    //全选
    $('#checkall').on('change',function(){
        if($(this).is(':checked')){
            $('.ct_allcheck').each(function(){
                $(this).prop('checked',true);
            });
        }else{
            $('.ct_allcheck').each(function(){
                $(this).prop('checked', false);
            });
        }
    });

    //tooltip
    $(table_container).on('mouseenter', 'td', function(){
        init_event_op();
    });

    //reset form
    $('#advance_filter_btn_reset').on('click',function(){
        $("#form_advance_filter")[0].reset();
    });

    $('#btn_search_alias').tooltipster({
        side: 'right',
        delay: [100, 200],
        delayTouch: [100, 200],
        trigger: 'custom',
        triggerOpen: {mouseenter: true},
        triggerClose: {mouseleave: true,scroll: true},

        functionInit: function(instance, helper){
            var content = "关联搜索只支持标签关联词的查询，其它查询条件不生效";
            instance.content(content);
        },
    });

    //回收站全选
    $('#checkall_trash').on('change',function(){
        if($(this).is(':checked')){
            $('.ct_allcheck_trash').each(function(){
                $(this).prop('checked',true);
            });
        }else{
            $('.ct_allcheck_trash').each(function(){
                $(this).prop('checked', false);
            });
        }
    });
    //回收站删除，还原
    $("table" ).on( "click", "a.op_delete", function() {
        var type = $(this).data('action');
        var id = $(this).data('id');
        var id_list = [id];
        trash_del_op_bat(type, id_list)
    });

    //导入标签
    $("#uplod_file").change(function() {
        //if ($("#uplod_file").val() != "") {
            upload_file();
       // }
    });

    $('#btn_import_file').on('click',function(){
        $("#import_tag_modal").modal("show");
    });


}

function do_trash_delete(type){
    var id_list = [];

    var checkboxlist = $('.ct_allcheck_trash:checked');
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            id_list.push($(this).attr('tag_id'));
        }
    });

    if (id_list.length <= 0) {
        showMessage("info", "提示", "请选择需要批量删除／还原的项！");
        return false;
    }
    trash_del_op_bat(type, id_list);
}

function trash_del_op_bat(op_type, id_list){
    var op_name = "";
    var url = "";
    if (op_type == 1){
        op_name = "删除";
        url = "/content_tag/tag_mgr/trash_del_bat/";
    } else if (op_type == 2){
        op_name = "还原";
        url = "/content_tag/tag_mgr/trash_recover_bat/";
    }else {
        return false;
    }
    if (confirm("确定要"+op_name+"吗？") == false){
        return false;
    }

    id_list = id_list.join(",")
    var data_param = {"op_type":op_type, "id_list":id_list};

    var callback_func = function(result){
        data_table_trash.ajax.reload();
    }
    post_ajax_data(url, data_param, {async:true, callback:callback_func, show_success:true});
    return false;
}

function show_trash_modal(){
    console.log("show_trash_modal...");
    $("#trash_modal").modal('show');

    if (data_table_trash == undefined || data_table_trash == ""){
        init_table_trash("#table_trash");
    } else {
        data_table_trash.ajax.reload();

    }

}


function init_table_trash(table_container, load_flag)
{
    this.tableContainer = table_container;
    this.load_flag = true;
    this.url = "/content_tag/tag_mgr/get_tag_list/";

    if (load_flag === false){
        this.load_flag = false;
    }
    var _this = this;
    this.init_columns = function(){
        var columns_list = [
            {
                data: "id",
                bSortable: false,
                "render":function(data,type,full){
                    return "<input type='checkbox' class='ct_allcheck_trash' tag_name = '" + full.name + "'tag_id='" + data + "'/>";
                },
            },
            {
                data: "id",//标签id
                bSortable: true,
                "render":function(data,type,full){
                    return data;
                },
            },
            {
                data: "name",//标签
                bSortable: true,
                "render":function(data,type,full){
                    return data;
                },
            }, {

                data: "path",//分类
                bSortable: false,
                "render":function(data,type,full){
                    return data;
                }

            }, {
                data: "id",//对象
                bSortable: false,
                "render":function(data,type,full){
                    var content_type = [];
                    if (full.is_article == 1){
                        content_type.push("文章")
                    }
                    if (full.is_video == 1){
                        content_type.push("视频")
                    }
                    if (full.is_short_video == 1){
                        content_type.push("短视频")
                    }

                    return content_type.join("&");
                }
            }, {
                data: "is_entity_tag",//类型
                bSortable: false,
                "render":function(data,type,full){
                    return (data == 1) ? "实体" : "topic";
                }
            }, {
                data: "id",
                bSortable: false,
                "render":function(data,type,full){
                    var ret = '<a class="op_delete op" data-action="1" data-id="' + full.id + '">删除</a> '+
                              '<a class="op_delete op" data-action="2" data-id="' + full.id + '">还原</a> ';
                    return ret;
                }
            }
        ];
        var columnDefs = [];
        var columnExclude = [];
        for (var i=0; i < columns_list.length; i++){
            if(columns_list[i].render != undefined){
                var column_one = {"targets":i, "render":columns_list[i].render}
                if(columns_list[i].visible != undefined){
                    column_one.visible = columns_list[i].visible
                }
                columnDefs.push(column_one);
                if (columns_list[i].exclude != undefined && columns_list[i].exclude == true){
                    columnExclude.push(i);
                }
            }
        }

        return {'columns':columns_list, 'columnDefs':columnDefs, 'columnExclude':columnExclude};
    }

    this.get_data_param = function(d){
        if (d == undefined){ d = {};}
        d.is_deleted = 1;
        d.check_status = -1;
        return d;
    }

    this.init = function(){
        var sdom = "<'row'<'col-sm-12'tr>>";

        var data_param = _this.get_data_param;
        var columns_init = _this.init_columns();

        var columns = columns_init.columns;
        var columnDefs = columns_init.columnDefs;
        var columnExclude = columns_init.columnExclude;
        var option = {
            'load_flag' : true,
            'server_side' : true,
            'searching' : false,
            'url' : this.url,
            'order_column' : [ 1, 'asc' ],//设置列的默认排序方式
            'tableContainer' : table_container,
            'sdom' : sdom,
            'data_param' : data_param,
            'columns' : columns,
            'columnDefs' : columnDefs,
            'page_length' : 1000,
            'language' : {'sInfo':"当前 _START_ to _END_ , 共 _TOTAL_ 条"},
        };

        this.data_table = new DataTable(option);
        data_table_trash = this.data_table.tableObj;
        return false;
    }

    if (this.load_flag !== false){
        this.init();
    }
}


function show_trans_tag_modal(){
    var id_list = [];
    var checkboxlist = $('.ct_allcheck:checked');
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            id_list.push($(this).attr('tag_id'));
        }
    });

    if (id_list.length <= 0) {
        showMessage("info", "提示", "请选择标签！");
        return false;
    }
    get_favorite_tree();
    $("#trans_tag_modal").modal("show");
}

function clear_tag_tree(data, filter){
    var data_list = [];
    for (var i=0; i<data.length; i++){
        var data_i = data[i];
        if (data_i.text == filter){
            continue;
        }

        if (data_i.children){
            data_i.children = clear_tag_tree(data_i.children, filter);
        }
        data_list.push(data_i);
    }

    return data_list;

}

function get_favorite_tree()
{
    var tree_container = "#trans_classtag_tree";
    var url = '/content_tag/class_tag/get_tag_tree/';
    var add_node_str = "+添加节点";
    $(tree_container).tree({
        url: url,
        animate: true,
        lines: true,
        dnd:false,
        loadFilter: function(data){
            data_list = clear_tag_tree(data, add_node_str);
            data_node = [{text:"全部", id:-1,state:"open"}];
            if (data_list.length > 0){
                data_node[0].children = data_list;
            }
            return data_node;
        },
        formatter: function (node) {
            return node.text
        },
        onClick: function (node) {
            classtag_id_selected = node.id;
            console.log("classtag_id_selected ...", classtag_id_selected );
        },
    });
}


function do_trans_tag(){
    var id_list = [];
    var checkboxlist = $('.ct_allcheck:checked');
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            id_list.push($(this).attr('tag_id'));
        }
    });

    if (id_list.length <= 0) {
        showMessage("info", "提示", "请选择标签！");
        return false;
    }
    var parent_id = classtag_id_selected;
    if (parent_id == undefined || parent_id == ""){
        showMessage("info", "提示", "请选择分类的父节点！");
        return false;
    }

    var url = "/content_tag/tag_mgr/trans_tag_to_class/";
    id_list = id_list.join(",")
    var data_param = {"parent_id":parent_id, "id_list":id_list};
    console.log("data_param...", data_param);

    post_ajax_data(url, data_param, {async:true, show_success:true});
}

//advance-filer
function init_event_advance_filter(){
    $(document).on("click", "a.advance_filter_btn", function (e) {
        $("#advance_filter_model").modal('show');
    });
    $(document).on("click", "#advance_filter_btn_submit", function (e) {
        $("#advance_filter_model").modal('hide');
        search_tag();
    });
}

function init_event_op(){
    //alias
    alias_tootip_click_func = function(el_id){
        var el = $("a.op_alias[data-id="+el_id+"]");
        if(el && el.length > 0){
            tag_id = el.data('id');
            passed_alias = el.data('passed_alias');

            show_check_alias(tag_id, passed_alias);
        }
        return false;
    }
    $('a.op_alias:not(.tooltipstered)').tooltipster({
        side: 'left',
        delay: [100, 200],
        delayTouch: [100, 200],
        contentAsHTML:true,
        interactive:true,
        trigger: 'custom',
        triggerOpen: {mouseenter: true, click:true},
        triggerClose: {click: true,mouseleave: true,scroll: true},

        functionInit: function(instance, helper){
            var el = $(helper.origin)
            var content = el.data('passed_alias') || "";
            var el_id = el.data('id');
            var alias_html = "暂无别名";
            if(content != ""){
                alias_html = content;
                /*var alias_split = content.split("|")
                alias_html = "";
                $.each(alias_split, function (i, item) {
                    alias_html += item+", ";
                });*/
            }
            content = "<div class='tooptip_div' style='max-width:400px;min-width:200px;'>"+
                "<div>别名<span class='tooltip_update' onclick='alias_tootip_click_func("+el_id+")' style='float:right;cursor:pointer;'>编辑</span></div><hr/>"+
                "<div>"+alias_html+"</div></div>";
            instance.content(content);
        },
    });

    //关联
    /*relate_tootip_click_func = function(el_id){
        manage_relate(el_id);
        return false;
    }
    $('a.op_relate:not(.tooltipstered)').tooltipster({
        side: 'left',
        delay: [100, 200],
        delayTouch: [100, 200],
        contentAsHTML:true,
        interactive:true,
        trigger: 'custom',
        triggerOpen: {mouseenter: true, click:true},
        triggerClose: {click: true,mouseleave: true,scroll: true},

        functionInit: function(instance, helper){
            var el = $(helper.origin)
            var content = el.data('relate');
            var el_id = el.data('id');
            var alias_html = "暂无别名";
            if(content != "" && content != undefined){
                var alias_split = content.split("|")
                alias_html = "";
                $.each(alias_split, function (i, item) {
                    alias_html += item+"..";
                });
            }
            content = "<div class='tooptip_div' style='max-width:300px;'>"+
                "<div>别名<span class='tooltip_update' onclick='relate_tootip_click_func("+el_id+")' style='float:right;cursor:pointer;'>编辑</span></div><hr/>"+
                "<div>"+alias_html+"</div></div>";
            instance.content(content);
        },
    });*/

    //注释
    note_tootip_click_func = function(el_id){
        manage_note(el_id);
        return false;
    }
    $('a.op_note:not(.tooltipstered)').tooltipster({
        side: 'left',
        delay: [100, 200],
        delayTouch: [100, 200],
        contentAsHTML:true,
        interactive:true,
        trigger: 'custom',
        triggerOpen: {mouseenter: true, click:true},
        triggerClose: {click: true,mouseleave: true,scroll: true},

        functionInit: function(instance, helper){
            var el = $(helper.origin)
            var note = el.data('note') || "";
            var el_id = el.data('id');
            var detail_html = "暂无注释";
            if(note != "") detail_html = note;

            var content = "<div class='tooptip_div' style='max-width:400px;min-width:200px;'>"+
                "<div>注释<span class='tooltip_update' onclick='note_tootip_click_func("+el_id+")' style='float:right;cursor:pointer;'>编辑</span></div><hr/>"+
                "<div>"+detail_html+"</div></div>";
            instance.content(content);
        },
    });

}



function search_check_unpassed(data_param_json){
    var url = "/content_tag/tag_mgr/get_tag_list/";
    var data_param = objClone(data_param_json)
    data_param.check_status = 0;//wait
    $("#id_check_status_unpass_href").remove();
    if (data_param.tag_name_list != undefined && data_param.tag_name_list.length > 0){
        $.ajax({
            url: url,
            type: 'POST',
            data: data_param,
            dataType: "json",
            async: true,
            success: function (result) {
                if (result.status == 0) {//success
                    if(result.recordsTotal > 0){
                        var url = "/content_tag/tag_check/?tag_name_list="+data_param.tag_name_list;
                        var html_c = "<a href='"+url+"' target='_blank' id='id_check_status_unpass_href' style='margin-left:10px;'>查询条件中有<span style='color:red;font-weight:bold;'>"+result.recordsTotal+"</span>个标签待审核</a>";
                        $("#id_check_status_unpass_href").remove();
                        $("#btn_submit").append(html_c);
                    }
                }
            }
        });
    }

}


function get_search_params(){
    var d = {}
    d.tag_name_list = $("#id_tag_filter_name").val();
    d.start_time = $("#start_update_time").val();
    d.end_time = $("#end_update_time").val();
    d.first_div_id = $("select.ct_select_dict_list").val();
    if (d.first_div_id == "")  d.first_div_id = -1;
    d.second_div_id = $("select.ct_select_dict_list2").val();
    if (d.second_div_id == "") d.second_div_id = -1;
    if (click_parent_id != null && click_parent_id != "" && d.first_div_id == -1 ) {
        d.second_div_id = click_parent_id;
    }
    d.tag_type = $("#tag_type_select").val();
    d.is_book_tag = $("#tag_is_book_select").val();
    d.is_entity_tag = $("#tag_is_entity_select").val();
    d.src_tag = $("#tag_src_select").val();

    d.has_alias = $("#has_alias_select").val();//有无别名
    d.has_related = $("#has_related_select").val();//有无关联标签
    d.has_path = $("#has_path_select").val();//有无分类(path)
    d.tag_char_type = $("#tag_char_type_select").val();//标签字段分类
    d.tag_produce_src = $("#tag_produce_src_select").val();//标签生成方式

    d.tag_name_type = tag_name_type;//标签查询字段：0:name, 1:alias
    return d;
}


function download_tags() {
    var params = get_search_params();
    var url = '/content_tag/tag_mgr/download_tags/?'+$.param(params);
    location.href = url;
}

function do_update_candidate_relate(tag_id) {
    prev_list = $("input.ct_candidate_mul_tag_prev").val();
    relate_list = $("input.ct_candidate_mul_tag_relate").val();
    next_list = $("input.ct_candidate_mul_tag_next").val();
    $.ajax({
        url: '/content_tag/tag_mgr/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#manage_candidate_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

function manage_note(tag_id) {
    $.ajax({
        url: '/content_tag/class_tag/get_tag_by_id/',
        type: 'POST',
        data: { "tag_id": tag_id },
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }

            $("#id_note").val(result.data.note);

            $('#update_note_model #btn_update_tag_note').attr('onclick', 'do_update_tag_note('+ tag_id + ')');
            $("#update_note_model").modal('show');
        }
    });
}

function do_update_tag_note(tag_id) {
    note = $("#id_note").val();
    $.ajax({
        url: '/content_tag/tag_mgr/update_tag_note/',
        type: 'POST',
        data: {"tag_id": tag_id, "note": note},
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#update_note_model").modal('hide');
            refresh_table_list();
        }
    });
}

function manage_relate(tag_id) {
    // init_prev_relate_mul_select(tag_id);
    // init_relate_mul_select(tag_id);
    // init_next_relate_mul_select(tag_id);

    $.ajax({
        // url: '/content_tag/class_tag/get_tag_by_id/',
        // url: '/content_tag/class_tag/get_relate_list/',
        url: '/content_tag/tag_mgr/get_candidate_relate/',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            return false;
            var id_list = [];
            var model_tag = result.data;
            if (model_tag.pre_relate){
                id_list += model_tag.pre_relate + ",";
            }
            if (model_tag.next_relate){
                id_list += model_tag.next_relate + ",";
            }
            if (model_tag.relate){
                id_list += model_tag.relate + ",";
            }
            console.log("result.data...", result);

            var relate_all = [];
            id_list = id_list.split(",");
            for (var i in id_list){
                var tag_id = id_list[i];
                if (tag_id){
                    var name = tree_get_path_abs(tree_container_select, tag_id);
                    relate_all.push({"id":tag_id, "name": name});
                }
            }
            console.log("relate_all...", relate_all);
            return false;
            $("input.ct_mul_tag_prev").select2("data", result.prev_list);

            $("input.ct_mul_tag_relate").select2("data", result.relate_list);
            $("input.ct_mul_tag_next").select2("data", result.next_list);

            $('#update_relate_model #btn_update_tag_relate').attr('onclick', 'do_update_tag_relate('+ tag_id + ')');
            $("#update_relate_model").modal('show');
        }
    });

}


function build_select_option(option_arr, value_list){
    var option_list = [];
    value_list = value_list || [];

    for (var i = 0; i < option_arr.length; i++) {
        if (value_list.indexOf(option_arr[i].id) >= 0) {
            option_list.push("<option value='" + option_arr[i].id + "' selected >" + option_arr[i].name + "</option>");
        } else {
            option_list.push("<option value='" + option_arr[i].id + "' >" + option_arr[i].name + "</option>");
        }
    }
    return option_list;
}


function do_update_tag_relate(tag_id) {
    prev_list = $("input.ct_mul_tag_prev").val();
    relate_list = $("input.ct_mul_tag_relate").val();
    next_list = $("input.ct_mul_tag_next").val();
    $.ajax({
        url: '/content_tag/tag_mgr/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#update_relate_model").modal('hide');
        }
    });

}

function init_prev_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_prev").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/content_tag/tag_mgr/get_tag_list_with_query/',
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });
}

function init_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_relate").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/content_tag/tag_mgr/get_tag_list_with_query/',
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function init_next_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_next").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/content_tag/tag_mgr/get_tag_list_with_query/',
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function upload_file() {
    $("#upload_busy").show();
    $("#batch_file_name").val("");
    var form_data = new FormData($("#form_upload")[0]);
    console.log("form-data...", form_data);
    $.ajax({
        url: '/content_tag/tag_mgr/handle_uploaded_file/',
        type: 'POST',
        data: form_data,
        cache: false,
        contentType: false,
        processData: false,
        success: function (result) {
            $("#upload_busy").hide();
            if (result.status == 0) {
                $("#batch_file_name").val(result.file_name);
                var msg = "上传文件成功";
                if (result.data != undefined && result.data > 0){
                    msg += "，成功导入标签" + result.data +" 条";
                }
                showMessage("info", "信息", msg);
                refresh_table_list();
            } else {
                $("#uplod_file").val("");
                showMessage("error", "失败", result.msg);
            }
        }
    });
}



function search_tag() {
    data_search_type = 0
    table_reload();
}

function search_tag_alias() {
    var tag_name_list = $("#id_tag_filter_name").val();
    if(tag_name_list == ""){
        showMessage("info", "提示", "请输入标签的别名！");
    	$("#id_tag_filter_name").focus();
    	return false;
    }
    data_search_type = 0
    tag_name_type = 1;
    table_reload();
}

function search_tag_relate() {
    var tag_name_list = $("#id_tag_filter_name").val();
    if(tag_name_list == ""){
    	showMessage("info", "提示", "请输入标签的别名！");
    	$("#id_tag_filter_name").focus();
    	return false;
    }

    data_search_type = 1;
    table_list.ajax.reload();
}

function table_reload(){
    table_list.ajax.reload();
    var data_param = table_list.ajax.params();
    search_check_unpassed(data_param);
}

function merge_tag() {
    var checkboxlist=$('.ct_allcheck:checked');
    $("#merge_tag_div").html("");

    var merge_num = 0;
    radio_html = ""
    checked = 'checked';
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            radio_html += '<label class="radio" style="margin-left:50px;margin-top:0px;"> <input type="radio" name="merge_tag_main_tag" value=' + $(this).attr('tag_id') + ' ' + checked + '>' + $(this).attr('tag_name') + '</label>';
            checked = "";
            merge_num += 1;
        }
    });

    if (merge_num <= 1) {
        showMessage("info", "提示", "合并标签至少需要选择两项！");
        return;
    }

    if (radio_html == "") {
        showMessage("info", "提示", "请选择需要合并的项！");
        return;
    }

    $("#merge_tag_div").html(radio_html)
    $("#merge_tag_model").modal('show');
}

function do_merge_tag() {
    var main_tag = ''
    var temp = document.getElementsByName("merge_tag_main_tag");
    for (var i = 0; i < temp.length; i++) {
        if (temp[i].checked)
            main_tag = temp[i].value;
    }

    var checkboxlist=$('.ct_allcheck:checked');
    tag_list = "";
    tag_name_list = "";
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            tag_list += $(this).attr('tag_id')+",";
            tag_name_list += $(this).attr('tag_name')+",";
        }
    });

    $.ajax({
        url: '/content_tag/tag_mgr/merge_tag/',
        type: 'POST',
        data: { "main_tag": main_tag, "tag_id_list":tag_list, "tag_name_list": tag_name_list},
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#merge_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

function delete_tags(node_id) {
    var checkboxlist=$('.ct_allcheck:checked');
    tag_list = "";
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            tag_list+=$(this).attr('tag_id')+",";
        }
    });

    if (tag_list == "") {
        showMessage("info", "提示", "请选择需要删除的项！");
        return;
    }
    $('#delete_table_model #btn_do_delete_ok').attr('onclick', 'do_delete_tags('+node_id+')');
    $("#delete_table_model").modal('show');
}

function do_delete_tags() {
    $.ajax({
        url: '/content_tag/tag_mgr/delete_tag/',
        type: 'POST',
        data: { "tag_id_list": tag_list },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#delete_table_model").modal('hide');
            refresh_table_list();
        }
    });
}

function get_tag_params_from_modal(){
    var parent_id = classtag_id_selected_crud;
    if (parent_id == undefined || parent_id == null || parent_id == "" || parent_id <= 0){
        var msg = "请选择标签路径";
        if (parent_id == -1){
            msg = "请选择标签路径，不能为\"全部\"";
        }
        return {'status' :1, 'msg':msg};
    }

    var tag_name = $('#new_tag_name').val();
    var check_status = $('#new_tag_check_status_id').val();
    var is_article = $("input[id='new_tag_tag_type_article']").is(':checked');
    if (is_article) {
        is_article = 1;
    } else {
        is_article = 0;
    }
    var is_video = $("input[id='new_tag_tag_type_video']").is(':checked');
    if (is_video) {
        is_video = 1;
    } else {
        is_video = 0;
    }
    var is_short_video = $("input[id='new_tag_tag_type_short_video']").is(':checked');
    if (is_short_video) {
        is_short_video = 1;
    } else {
        is_short_video = 0;
    }

    var is_book_tag = $("input[id='new_tag_book_tag']").is(':checked');
    if (is_book_tag) {
        is_book_tag = 1;
    } else {
        is_book_tag = 0;
    }
    var is_entity_tag = $("input[id='new_tag_entity_tag']").is(':checked');
    if (is_entity_tag) {
        is_entity_tag = 1;
    } else {
        is_entity_tag = 0;
    }
    var guid = $('#new_tag_guid').val();
    var alias = $('#new_tag_alias').val();
    data_param = {
        "name": tag_name,
        "parent_id": parent_id,
        "check_status": check_status,
        "is_article": is_article,
        "is_video": is_video,
        "is_short_video": is_short_video,
        "is_book_tag": is_book_tag,
        "is_entity_tag": is_entity_tag,
        "alias": alias,
       "guid": guid
   };

    return {'status' :0, 'data':data_param};
}

function update_tag(tag_id) {
    $.ajax({
        url: '/content_tag/tag_mgr/get_tag_info/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $('#new_tag_name').val(result.name);
            $('#new_tag_check_status_id').val(result.check_status);

            $("input[id='new_tag_tag_type_article']").removeAttr("checked");
            $("input[id='new_tag_tag_type_video']").removeAttr("checked");
            $("input[id='new_tag_tag_type_short_video']").removeAttr("checked");
            $("input[id='new_tag_book_tag']").removeAttr("checked");
            $("input[id='new_tag_entity_tag']").removeAttr("checked");

            if (result.is_article) {
                $("input[id='new_tag_tag_type_article']").prop("checked", true);
            }

            if (result.is_video) {
                $("input[id='new_tag_tag_type_video']").prop("checked", true);
            }
            if (result.is_short_video) {
                $("input[id='new_tag_tag_type_short_video']").prop("checked", true);
            }

            if (result.is_book_tag) {
                $("input[id='new_tag_book_tag']").prop("checked", true);
            }

            if (result.is_entity_tag) {
                $("input[id='new_tag_entity_tag']").prop("checked", true);
            }

            $('#new_tag_guid').val(result.guid);
            $('#new_tag_alias').val(result.passed_alias);

            classtag_id_selected_crud = result.parent_id;
            clear_tree_search(tree_container_select);
            get_favorite_tree_select(tree_container_select, result.parent_id);

            $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_update_tag(' + tag_id + ')');
            $('#add_new_tag_title').html("修改标签");
            $("#add_new_tag_model").modal('show');
        }
    });

}


function do_update_tag(tag_id) {
    var data_res = get_tag_params_from_modal();
    if (data_res['status'] != 0){
        showMessage("info", "提示", data_res['msg']);
        return false;
    }
    var data_param = data_res['data'];
    data_param['tag_id'] = tag_id;

    $.ajax({
        url: '/content_tag/tag_mgr/update_tag/',
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');
            classtag_id_selected_crud = null;

            refresh_table_list();
        }
    });
}

function refresh_table_list() {
    var el = $('#table_list_paginate ul.pagination li.active');
    if (el.length > 0 && el.index() >= 0){
        el.trigger('click',function(){
            el.addClass('active');
        });
    }
}

function create_new_tag_batch() {
    $('#add_new_tag_title').html("新建标签");
    $('#new_tag_name').val('');
    $('#new_tag_check_status_id').val(0);

    $("input[id='new_tag_tag_type_article']").removeAttr("checked");
    $("input[id='new_tag_tag_type_video']").removeAttr("checked");
    $("input[id='new_tag_book_tag']").removeAttr("checked");
    $("input[id='new_tag_entity_tag']").removeAttr("checked");
    $("input[id='new_tag_tag_type_article']").prop("checked", true);
    $("input[id='new_tag_tag_type_video']").prop("checked", true);
    $("input[id='new_tag_entity_tag']").prop("checked", true);

    $('#new_tag_guid').val("");
    $('#new_tag_alias').val("");


    get_favorite_tree_select(tree_container_select);

    $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_create_new_tag()');
    $("#add_new_tag_model").modal('show');
}

function do_create_new_tag() {
    var data_res = get_tag_params_from_modal();
    if (data_res['status'] != 0){
        showMessage("info", "提示", data_res['msg']);
        return false;
    }
    var data_param = data_res['data'];
    $.ajax({
        url: '/content_tag/tag_mgr/create_new_tag_batch/',
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

function import_dict()
{
    $.ajax({
        url: '/content_tag/tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("select.ct_select_dict_list").select2({
                placeholder: '--请选择--',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                value: "",
                allowClear:true
            });
        }
    });
}
function import_dict2(first_div_id)
{
    if(first_div_id == undefined || first_div_id == "" || first_div_id == -1){
        $("select.ct_select_dict_list2").select2({
            placeholder: '--请选择--',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true
        });
        return false;
    }
    $.ajax({
        url: '/content_tag/tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 1, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("select.ct_select_dict_list2").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true
            });
        }
    });
}


function init_table(table_container, load_flag)
{
    this.tableContainer = table_container;
    this.load_flag = true;
    this.url = "/content_tag/tag_mgr/get_tag_list/";
	this.relate_url = "/content_tag/tag_mgr/get_tag_list_with_relate/";

    if (load_flag === false){
        this.load_flag = false;
    }
    var _this = this;
    this.init_columns = function(){
        var columns_list = [
            {
                data: "id",
                exclude: true,
                bSortable: false,
                "render":function(data,type,full){
                    return "<input type='checkbox' class='ct_allcheck' tag_name = '" + full.name + "'tag_id='" + data + "'/>";
                },
            },
            {
                data: "id",//标签
                bSortable: true,
                visible: false,
                "render":function(data,type,full){
                    return data;
                },
            },
            {
                data: "name",//标签
                exclude: true,
                bSortable: true,
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='update_tag(" + full.id + ");'>"+data+"</a>";
                },
            }, {

                data: "path",//分类
                bSortable: false,
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='select_tag_with_parent_id(" + full.parent_id + ");'>"+data+"</a>";
                }

            }, {
                data: "id",//对象
                bSortable: false,
                "render":function(data,type,full){
                    var content_type = [];
                    if (full.is_article == 1){
                        content_type.push("文章")
                    }
                    if (full.is_video == 1){
                        content_type.push("视频")
                    }
                    if (full.is_short_video == 1){
                        content_type.push("短视频")
                    }

                    return content_type.join("&");
                }
            }, {
                data: "is_entity_tag",//类型
                bSortable: false,
                "render":function(data,type,full){
                    return (data == 1) ? "实体" : "topic";
                }
            },{
                data: "guid",//guid
                bSortable: false,
                visible: false,
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                }
            },{
                data: "hot_media",//媒体热度
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "hot",//query热度
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "article_num",//文章数
                bSortable: true,
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='get_tag_articles(" + full.id + ");'>"+data+"</a>";
                }
            },{
                data: "video_num",//视频数
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "video_vv_num",//视频vv
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "content_user",//内容用户
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "video_user",//视频用户
                bSortable: true,
                "render":function(data,type,full){
                    return data || 0;
                }
            },{
                data: "id",//来源
                bSortable: true,
                visible: false,
                "render":function(data,type,full){
                    var src = [];
                    if (full.is_src_youku){
                        src.push("优酷");
                    }
                    if (full.is_src_uc){
                        src.push("uc");
                    }
                    if (full.is_src_sm){
                        src.push("神马");
                    }
                    src = src.join("&");
                    return "<span title='"+src+"'>"+src+"</span>";
                }
            },{
                data: "owner_name",//审核人
                bSortable: false,
                visible: false,
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                }
            },{
                data: "update_time",//更新时间
                bSortable: true,
                visible: false,
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                }
            },{
                data: "id",
                bSortable: false,
                exclude: true,
                "render":function(data,type,full){
                    //var baike_url = "http://baike.baidu.com/item/" + full.name;
                    var baike_url = "https://www.baidu.com/s?wd=" + full.name;
                    full.alias = full.alias || "";
                    full.passed_alias = full.passed_alias || "";
                    var ret = '<a class="op_alias op" data-alias="' + full.alias + '" data-id="' + full.id + '" data-passed_alias="' + full.passed_alias + '">别名</a> '+
                              //'| <a class="op_relate op" data-id="' + full.id + '" >关联</a> '+
                              '| <a href="javascript:" onclick="manage_relate('+full.id +');">关联</a>'+
                              '| <a class="op_note op" data-note="'+full.note+'" data-id="' + full.id + '" >注释</a> '+
                              '| <a href="'+baike_url+'" target="_blank">百科</a> ';

                    return ret;
                }
            }
        ];
        var columnDefs = [];
        var columnExclude = [];
        for (var i=0; i < columns_list.length; i++){
            if(columns_list[i].render != undefined){
                var column_one = {"targets":i, "render":columns_list[i].render}
                if(columns_list[i].visible != undefined){
                    column_one.visible = columns_list[i].visible
                }
                columnDefs.push(column_one);
                if (columns_list[i].exclude != undefined && columns_list[i].exclude == true){
                	columnExclude.push(i);
                }
            }
        }

        return {'columns':columns_list, 'columnDefs':columnDefs, 'columnExclude':columnExclude};
    }

    this.get_data_param = function(d){
        if (d == undefined){
            d = {};
        }
        d.tag_name_list = $("#id_tag_filter_name").val();
        d.start_time = $("#start_update_time").val();
        d.end_time = $("#end_update_time").val();
        d.first_div_id = $("select.ct_select_dict_list").val();
        if (d.first_div_id == "")  d.first_div_id = -1;
        d.second_div_id = $("select.ct_select_dict_list2").val();
        if (d.second_div_id == "") d.second_div_id = -1;
        if (click_parent_id != null && click_parent_id != "" && d.first_div_id == -1 ) {
            d.second_div_id = click_parent_id;
        }
        d.tag_type = $("#tag_type_select").val();
        d.is_book_tag = $("#tag_is_book_select").val();
        d.is_entity_tag = $("#tag_is_entity_select").val();
        d.src_tag = $("#tag_src_select").val();

        d.has_alias = $("#has_alias_select").val();//有无别名
        d.has_related = $("#has_related_select").val();//有无关联标签
        d.has_path = $("#has_path_select").val();//有无分类(path)
        d.tag_char_type = $("#tag_char_type_select").val();//标签字段分类
        d.tag_produce_src = $("#tag_produce_src_select").val();//标签生成方式

        d.tag_name_type = tag_name_type;//标签查询字段：0:name, 1:alias
        tag_name_type = 0;

        if (table_list != undefined && table_list != "" && table_list != null){
            if (data_search_type == 1){
                table_list.ajax.url(_this.relate_url);
            }else {
                table_list.ajax.url(_this.url);
            }
        }
        //d.alias_check_status = $("#alias_check_status_select").val();
        //d.relate_check_status = $("#relate_check_status_select").val();

        return d;
    }

    this.init = function(){
        var sdom = "<'top'i>Cfrt<'bottom'p<'#page-length-choose' l><'#bottom-info-show' i>><'clear'>";

        var data_param = _this.get_data_param;
        var columns_init = _this.init_columns();

        var columns = columns_init.columns;
        var columnDefs = columns_init.columnDefs;
        var columnExclude = columns_init.columnExclude;
        var colVis = {
            order: 'column',
            buttonText: "显示/隐藏列",
            exclude: columnExclude,//不能选择是否显示，默认显示
            restore: "重置",
            showAll: "显示全部",
        }
        var sort_index = 0;
        for (var i=0;i<columns.length;i++){
            if (columns[i].data == "update_time"){
                sort_index = i;
                break;
            }
        }
        var option = {
            //'hide_columns' : [4,5,6],
            'load_flag' : true,
            'server_side' : true,
            'searching' : false,
            'url' : this.url,
            'order_column' : [ sort_index, 'desc' ],//设置列的默认排序方式
            'tableContainer' : table_container,
            'sdom' : sdom,
            'colVis' : colVis,
            'data_param' : data_param,
            'columns' : columns,
            'columnDefs' : columnDefs,
            'page_length' : 20,
            'language' : {'sInfo':"当前 _START_ to _END_ , 共 _TOTAL_ 条"},
        };

        data_table = new DataTable(option);
        table_list = data_table.tableObj;

        return false;
    }

    if (this.load_flag !== false){
        this.init();
    }
}


function show_check_alias(tag_id, passed_alias) {
    var alias_list = []
    if (passed_alias != null && passed_alias != 'null' && passed_alias != "") {
        var tmp_list = passed_alias.split('|');
        for (var i = 0; i < tmp_list.length; ++i) {
            var val_i = tmp_list[i];
            if (val_i!='' && ! in_array(val_i, alias_list)){
                alias_list.push(val_i);
            }
        }
    }

    $("input.ct_alias_select").tagsInput({
        'defaultText':'添加别名',
        'width':'400px',
    });
    $("input.ct_alias_select").importTags(alias_list.join(','));

    $('#check_alias_modal #check_alias_btn').attr('onclick', 'do_check_alias('+ tag_id + ')');
    $("#check_alias_modal").modal('show');
}


function do_check_alias(tag_id) {
    var passed_alias = $("input.ct_alias_select").val();
    var url = "/content_tag/tag_mgr/check_alias/";
    var data_param = {'tag_id':tag_id, 'passed_alias':passed_alias};

    var callback_func = function(res){
        if (res.status == 0){
            $("#check_alias_modal").modal('hide');
            refresh_table_list();
        }
    }
    post_ajax_data(url, data_param, {async:false, callback:callback_func, show_success:true});
}


function select_tag_with_parent_id(parent_id) {
    click_parent_id = parent_id;
    refresh_table_list();
}

function get_tag_articles(tag_id) {
    $.ajax({
        url: '/content_tag/tag_check/get_tag_articles/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }

            var tb = document.getElementById('article_view_body');
            var rowNum=tb.rows.length;
            for (i=0;i<rowNum;i++) {
                tb.deleteRow(i);
                rowNum=rowNum-1;
                i=i-1;
            }

            var row = document.createElement("tr");
            document.getElementById("article_view_body").appendChild(row);
            var key_cell = document.createElement("td");
            inner_html = "文章标题";
            key_cell.innerHTML = inner_html;
            row.appendChild(key_cell);

            var key_cell = document.createElement("td");
            inner_html = "文章url";
            key_cell.innerHTML = inner_html;
            row.appendChild(key_cell);

            for (var i = 0; i < result.article_list.length; ++i) {
                var row = document.createElement("tr");
                document.getElementById("article_view_body").appendChild(row);
                var key_cell = document.createElement("td");
                inner_html = result.article_list[i].title;
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);

                var key_cell = document.createElement("td");
                inner_html = '<a href="' + result.article_list[i].url +'" target="_blank">' + result.article_list[i].url  + '</a> ';
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);
            }
            $("#article_view_table").modal('show');
        }
    });
}

function turn_to_article_page(url) {
    window.location.href=url;
}

function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
}






/******** begin 标签路径选择 ********/

function tree_select_node_by_id(tree_container, node_id){
    $(tree_container).tree('doFilter', "");
    $(tree_container).tree('collapseAll');

    if (node_id != undefined && node_id != ""){
        var node = $(tree_container).tree('find', node_id);
        if (node != undefined){
            $(tree_container).tree('select', node.target);
            $(tree_container).tree("expandTo", node.target);
        }
    }

}
function tree_get_path_abs(tree_container, node_id){
    get_favorite_tree_select(tree_container);
    var path = "";
    if (node_id != undefined && node_id != ""){
        var node = $(tree_container_select).tree('find', node_id);
        if (node != undefined && node != null){
            path = node.text;
            var node_parent = $(tree_container_select).tree('getParent', node.target);
            if (node_parent != undefined && node_parent != null){
                path_parent = tree_get_path_abs(tree_container, node_parent.id);
                if (path_parent != ""){
                    path = path_parent + "->" + path;
                }
            }
        }
    }
    return path;
}

function clear_tree_search(tree_container){
    $(tree_container + " input[name=tree_input_search]").val("");
}

function get_favorite_tree_select(tree_container, node_id){
    var if_to_load = true;
    try{
        var root_node = $(tree_container_select).tree("getRoot");
        var root_children = root_node.children;
        if (root_children.length > 0){
            if_to_load = false;
        }

    }catch(err){
        if_to_load = true;
    }
    if (if_to_load == false){
        if (node_id){
            tree_select_node_by_id(tree_container, node_id);
            var select_node_text = tree_get_path_abs(tree_container, node_id);
            $("#selected_node_path").html(select_node_text);
        }
        return false;
    }

    var url = '/content_tag/class_tag/get_tag_tree/';

    var add_node_str = "+添加节点";
    $(tree_container).tree({
        url: url,
        animate: true,
        lines: true,
        dnd:false,
        loadFilter: function(data){
            data = clear_tag_tree(data, add_node_str);
            var root_node = [{text:"全部", id:-1,state:"open", children:data}];
            return root_node;
        },

        formatter: function (node) {
            if (node.text == "全部"){
                var html_input = "<input type='text' class='tree_search' name='tree_input_search' placeholder='输入关键词快速查找'>";
                return node.text + html_input;
            }else{
                return node.text;
            }
        },
        onClick: function (node) {
            classtag_id_selected_crud = node.id;
            var select_node_text = tree_get_path_abs(tree_container, node.id);
            $("#selected_node_path").html(select_node_text);
        },
        filter: function(q, node){
            if(node.text == "全部"){
                return true;
            }
            return node.text.toLowerCase().indexOf(q.toLowerCase()) >= 0;
        },
        onLoadSuccess: function (node, data) {
            $(tree_container + " input[name=tree_input_search]").on('change',function(){
                $(tree_container).tree("doFilter", $(this).val().trim());
                $(tree_container).tree("expandAll");
            });
            tree_select_node_by_id(tree_container, node_id);
            var select_node_text = tree_get_path_abs(tree_container, node_id);
            $("#selected_node_path").html(select_node_text);
        },
    });
}

/******** end 标签路径选择 ********/
