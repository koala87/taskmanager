var table_list = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var tree_container = "#favorite_tree";

var data_table = null;
var click_parent_id = null;
var table_container = "#table_list";
var parent_id = -1;
var project = "";

$(function () {
    project = get_value_from_location_by_name("project", "");
    init_table(table_container);
    get_favorite_tree();
    $(document).on('change', ".input_favorite_search", function () {
        $(tree_container).tree("doFilter", $(".input_favorite_search").val().trim());
        $(tree_container).tree("expandAll");
    });
});


/******** begin 标签分类操作 ********/
function get_favorite_tree(drag_able)
{
    if (drag_able == undefined || drag_able !== true){
        drag_able = false;
    }
    var url = '/content_tag/scene/get_tag_tree/?project='+project;
    var load_flag = false;
    $(tree_container).tree({
        url: url,
        animate: true,
        lines: true,
        dnd:drag_able,
        loadFilter: function(data){
            if (!load_flag){
                return [{text:"全部", id:-1,state:"open", children:data}];
            }
            return data;
        },
        formatter: function (node) {
            var node_text = node.text;

            //if (node.children){
                //node_text += '&nbsp;<span style=\'color:blue\'>(' + node.children.length + ')</span>';
            //}

            if (node.text == "全部"){
                return node_text + '&nbsp;&nbsp;&nbsp;&nbsp;'+
                    '<span class="tree-add"  title="添加子节点" style="display:none;" id="tree_add_' + node.id +'" onclick="add_new_class_tag(' + node.id + ');"></span>';

            }else{
                return node_text + '&nbsp;&nbsp;&nbsp;&nbsp;<span class="tree-edit" title="修改标签信息" style="display:none;" id="tree_edit_' + node.id + '"' +
                'data-text="'+node.text+'" data-id="'+node.id+'" ></span> <span class="tree-add"  title="添加子节点" style="display:none;" id="tree_add_' + node.id +
                 '" onclick="add_new_class_tag(' + node.id + ');"></span> <span class="tree-delete"  title="删除" style="display:none;" id="tree_delete_' + node.id + '" onclick="delete_class_tag(' + node.id + ');"></span>';
            }
        },
        onHover: function (e, node) {
            $('#tree_add_' + node.id).show();
            $('#tree_delete_' + node.id).show();
            $('#tree_edit_' + node.id).show();
        },
        onHoverLeave: function (e, node) {
            $('#tree_add_' + node.id).hide();
            $('#tree_delete_' + node.id).hide();
            $('#tree_edit_' + node.id).hide();
        },
        onLoadSuccess: function (node, data) {
            if (load_flag){
                return false;
            }else{
                load_flag = true;
            }
            var root_node = $(tree_container).tree('getRoot');
            if (root_node != null ) {
                $(tree_container).tree("select", root_node.target);
            }
            $("span.tree-edit").on('click', function(e){
                var node_id = $(this).data('id')
                var node_text = $(this).data('text')
                update_class_tag(node_id, node_text);
                e.stopPropagation();
            });
        },
        onClick: function (node) {
            var root_nodes = $(tree_container).tree('getRoots');
            parent_id = node.id;
            get_class_tag_info(node.id);
        },
    });
}

function get_class_tag_info() {
    table_reload();
}

function update_class_tag(node_id, node_name) {
    $('#new_class_tag_name').val(node_name);
    $('#new_class_tag_title').html("修改标签分类");

    $('#add_classtag_table_model #btn_do_add_class_tag_ok').attr('onclick', 'do_update_class_tag(' + node_id + ')');
    $("#add_classtag_table_model").modal('show');
    return false;
}

function do_update_class_tag(node_id) {
    var tag_name = $('#new_class_tag_name').val();
    $.ajax({
        url: '/content_tag/scene/update_class_tag/',
        data: {"project":project, "name": tag_name, "tag_id": node_id},
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#add_classtag_table_model").modal('hide');

            var t = $(tree_container);
            var node = t.tree('getSelected');
            t.tree('update', {
                target: node.target,
                text: tag_name
            });
        }
    });
}

function delete_class_tag(node_id) {
    $('#modal_del_classtag #btn_do_delete_ok').attr('onclick', 'do_delete_classtag('+node_id+')');
    $("#modal_del_classtag").modal('show');
}

function do_delete_classtag(node_id) {
    $.ajax({
        url: '/content_tag/scene/delete_class_tag/',
        data: { "project":project, "tag_id": node_id },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#modal_del_classtag").modal('hide');

            var t = $(tree_container);
            var node = t.tree('getSelected');
            t.tree('remove', node.target);
            var root_node = $(tree_container).tree('getRoot');
            if (root_node != null) {
                $(tree_container).tree("select", root_node.target);
            }
        }
    });
}

function add_new_class_tag(node_id) {
    $('#new_class_tag_name').val('');
    $('#new_class_tag_title').html("新建标签分类");

    $('#add_classtag_table_model #btn_do_add_class_tag_ok').attr('onclick', 'do_add_new_class_tag('+node_id+')');
    $("#add_classtag_table_model").modal('show');
}

function do_add_new_class_tag(node_id) {
    var tag_name = $('#new_class_tag_name').val();
    $.ajax({
        url: '/content_tag/scene/add_new_class_tag/',
        data: { "project":project, "name": tag_name, "parent_id": node_id},
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#add_classtag_table_model").modal('hide');

            var t = $(tree_container);
            var node = t.tree('getSelected');
            children = t.tree('getChildren', node.target);
            if (children.length > 0) {
                for (var i = 0; i < result.ret_list.length; ++i) {
                    t.tree('insert', {
                        before: children[0].target,
                        data: [{
                            id: result.ret_list[i].id,
                            text: result.ret_list[i].text,
                            state: 'open'
                        }]
                    });
                }
            } else {
                for (var i = 0; i < result.ret_list.length; ++i) {
                    t.tree('append', {
                        parent: (node ? node.target : null),
                        data: [{
                            id: result.ret_list[i].id,
                            text: result.ret_list[i].text,
                            state: 'open'
                        }]
                    });
                }
            }

            t.tree('expand', node.target);
            var new_node = t.tree('find', result.ret_list[0].id);
            t.tree('select', new_node.target);
        }
    });
}

function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
}


/******** end 标签分类操作 ********/
