var project_list = ["common", "uc", "youku", "tudou"];

$(function () {
    //update_table_users();
    get_all_users();
});

function get_all_users(){
    var url = "/interest_graphs/shuqi_toufang/get_all_user_list/";
    post_ajax_data(url, {}, {async:true, callback:get_auth_user});
}

function draw_user_list(user_list, result){
    var data = result.data;

    for (var i=0; i< project_list.length; i++){
        var project_one = project_list[i];

        //editor-html
        var project_user_list = [];
        if (data[project_one] != undefined){
            project_user_list = data[project_one].editor_list;
        }
        var editor_html = build_select_option(user_list, project_user_list).join("");
        $("#select_content_editor_"+project_one).html(editor_html);

        //check-html
        if (project_one == "common"){
            var check_list = [];
            if (data[project_one] != undefined){
                check_list = data[project_one].check_list;
            }
            var checker_html = build_select_option(user_list, check_list).join("");
            $("#select_content_checker").html(checker_html);
        }
    }

    init_select2_async();
}

function build_select_option(option_arr, value_list){
    var option_list = [];
    value_list = value_list || [];

    for (var i = 0; i < option_arr.length; i++) {
        if (value_list.indexOf(option_arr[i].id) >= 0) {
            option_list.push("<option value='" + option_arr[i].id + "' selected >" + option_arr[i].name + "</option>");
        } else {
            option_list.push("<option value='" + option_arr[i].id + "' >" + option_arr[i].name + "</option>");
        }
    }
    return option_list;
}

function get_auth_user(result){
    var user_list = result.user_list;

    $.ajax({
        url: '/content_tag/tag_perm/get_user_list/',
        type: 'POST',
        data: { },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (res) {
            draw_user_list(user_list, res);
        }
    });
}


function do_update_table_user() {
    var data_project_list = [];
    for (var i=0; i< project_list.length; i++){
        var project_one = project_list[i];

        //editor-list
        var editor_val = $("#select_content_editor_"+project_one).val();
        var editor_list = "";
        if (editor_val != undefined && editor_val != "" ) {
            editor_list = editor_val.join(",");
        }

        //check-list
        var check_list = "";
        var check_val = "";
        if (project_one == "common"){
            check_val = $("#select_content_checker").val();
        }
        if (check_val != undefined && check_val != "") {
            check_list = check_val.join(",");
        }

        data_project_list.push({
            "project":project_one,
            "editor_list":editor_list,
            "check_list":check_list
        });

    }

    data_project_list = JSON.stringify(data_project_list);
    var data_param = {"data_auth":data_project_list};

    $.ajax({
        url: '/content_tag/tag_perm/update_user_list/',
        type: 'POST',
        data: data_param,
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改权限失败", result.msg);
                return;
            }
            showMessage("info", "成功", "修改权限成功!");
        }
    });
}

function init_select2_async() {
    $(".select2-select-00").select2({
        allowClear: true
    });
}

