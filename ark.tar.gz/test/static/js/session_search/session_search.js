var host_table = null;
var query_data_table;
var global_pl_id = 0;
var global_data_source = 0;
var session_result_empty = false;
var query_str = ''
var query_day = ''
var url_str = ''
var url_target_str = ''

function showMessage(type, title, msg) {
    PNotify.prototype.options.styling = "bootstrap3";
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0, 10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0, 10);
}

function create_li_head_first(object, item_lable, count, fr, location, show_session) {
    count += 1;
    img_src = "/static/images/apple.png"
    tilte = "操作系统：其他";
    if (fr == 'android' || fr == 'ANDROID') {
        img_src = "/static/images/android.png"
        tilte = "操作系统：android";
    } else if (fr == 'ios' || fr == 'IOS' || fr == 'iphone' || fr == 'IPHONE') {
        img_src = "/static/images/apple.png"
        tilte = "操作系统：ios";
    } else {
        img_src = "/static/images/other.png"
    }

    li = $('<li class="time-label" style="margin-top:20px;margin-bottom:45px;" name="auto_li_name">' +
            '<span class="bg-light-blue " style="float:left;">Session ' + count + '</span>'+
            '<a href="javascript:void(0)" ><img src="' + img_src + '" title = "' + tilte + '" style="margin-left:20px;margin-top:-5px;float:left;" /></a>' +
            '<i class="fa fa-map-marker" style="float:left;margin-top:0px;margin-left:131px;background-color:#ecf0f5;"></i>'+
            '<label style="margin-left:53px;margin-top:4px;font-size:18px;color:rgb(153,163,190);width:200px;float:left;">' + location + '</label>'+
        '</li>');

    var data_type = $("#data_type").val();

    if (data_type == 1) {
        li = $('<li class="time-label" style="margin-top:20px;margin-bottom:45px;" name="auto_li_name">' +
            '<span class="bg-light-blue " style="float:left;">' + item_lable + '</span>' +
            '<a href="javascript:void(0)" ><img src="' + img_src + '" title = "' + tilte + '" style="margin-left:20px;margin-top:-5px;float:left;" /></a>' +
            '<i class="fa fa-map-marker" style="float:left;margin-top:0px;margin-left:131px;background-color:#ecf0f5;"></i>' +
            '<label style="margin-left:53px;margin-top:4px;font-size:18px;color:rgb(153,163,190);width:200px;float:left;">' + location + '</label>' +
        '</li>');
    }
    li.insertAfter(object);
    return li;
}

function create_li_head(object, item_lable, count, show_session) {
    count += 1;
    li = $('<li class="time-label" style="margin-top:20px;margin-bottom:45px;" name="auto_li_name">' +
        '<span class="bg-light-blue " style="border-radius:15px 15px 15px 15px;" title="' + item_lable + '" > Session ' +
        count + '</span></li>')

    var data_type = $("#data_type").val();
    if (data_type == 1) {
        li = $('<li class="time-label" style="margin-top:20px;margin-bottom:45px;" name="auto_li_name">' +
        '<span class="bg-light-blue " style="border-radius:15px 15px 15px 15px;" title="' + item_lable + '" >' +
        item_lable + '</span></li>')
    }

    li.insertAfter(object);
    return li;
}

function create_li_tail(object) {
    li = $('<li style="margin-bottom:45px;" name="auto_li_name">' +
            '<i class="fa fa-clock-o bg-gray"></i>' +
        '</li>')
    li.insertAfter(object);
    return li;
}

Array.prototype.remove = function (s) {
    for (var i = 0; i < this.length; i++) {
        if (s == this[i])
            this.splice(i, 1);
    }
}   

function Map() {
    /** 存放键的数组(遍历用到) */
    this.keys = new Array();
    /** 存放数据 */
    this.data = new Object();

    /**  
    * 放入一个键值对  
    * @param {String} key  
    * @param {Object} value  
    */
    this.put = function (key, value) {
        if (this.data[key] == null) {
            this.keys.push(key);
        }
        this.data[key] = value;
    };

    /**  
    * 获取某键对应的值  
    * @param {String} key  
    * @return {Object} value  
    */
    this.get = function (key) {
        return this.data[key];
    };

    /**  
    * 删除一个键值对  
    * @param {String} key  
    */
    this.remove = function (key) {
        this.keys.remove(key);
        this.data[key] = null;
    };

    /**  
    * 遍历Map,执行处理函数  
    *   
    * @param {Function} 回调函数 function(key,value,index){..}  
    */
    this.each = function (fn) {
        if (typeof fn != 'function') {
            return;
        }
        var len = this.keys.length;
        for (var i = 0; i < len; i++) {
            var k = this.keys[i];
            fn(k, this.data[k], i);
        }
    };

    /**  
    * 获取键值数组(类似Java的entrySet())  
    * @return 键值对象{key,value}的数组  
    */
    this.entrys = function () {
        var len = this.keys.length;
        var entrys = new Array(len);
        for (var i = 0; i < len; i++) {
            entrys[i] = {
                key: this.keys[i],
                value: this.data[i]
            };
        }
        return entrys;
    };

    /**  
    * 判断Map是否为空  
    */
    this.isEmpty = function () {
        return this.keys.length == 0;
    };

    /**  
    * 获取键值对数量  
    */
    this.size = function () {
        return this.keys.length;
    };

    /**  
    * 重写toString   
    */
    this.toString = function () {
        var s = "{";
        for (var i = 0; i < this.keys.length; i++, s += ',') {
            var k = this.keys[i];
            s += k + "=" + this.data[k];
        }
        s += "}";
        return s;
    };
}

var sc_list_arr = new Array('sc_name', 'pos', 'sc_stype', 'sc_ds', 'sc_bd', 'other');
function get_sc_row(sc_row) {
    sc_row_list = sc_row.split(",");
    var sc_map = new Map();
    for (var row_idx = 0; row_idx < sc_row_list.length; ++row_idx) {
        item_split = sc_row_list[row_idx].split(':');
        sc_map.put(item_split[0], item_split[1])
    }
    sc_name_row_str = "<tr>";
    for (var arr_idx = 0; arr_idx < sc_list_arr.length - 1; ++arr_idx) {
        val = sc_map.get(sc_list_arr[arr_idx]);

        if (!val) {
            sc_name_row_str += '<td></td>';
        } else {
            sc_name_row_str += '<td>' + val + '</td>';
            sc_map.remove(sc_list_arr[arr_idx]);
        }
    }
    other_str = sc_map.toString();
    other_str = other_str.replace(new RegExp("{", 'gm'), '');
    other_str = other_str.replace(new RegExp("}", 'gm'), '');
    sc_name_row_str += "<td>" + other_str + "</td>";
    sc_name_row_str += "</tr>";
    return sc_name_row_str;
}

function show_sc_name(sc_name) {
    if (sc_name != "") {
        sc_name_list = sc_name.split('\002');
        sc_name_row_str = '<table class="items table id="preview_table" table-bordered" style="margin-top:10px;border:1px solid rgb(219, 219, 219);table-layout:fixed;word-break:break-all; word-wrap:break-all;" cellspacing="1" cellpadding="2" border="1">'
        sc_name_row_str += '<tbody id="_table">'

        head_row = "<tr>";
        for (var arr_idx = 0; arr_idx < sc_list_arr.length; ++arr_idx) {
            if (arr_idx == 0) {
                head_row += '<td style="width:200px;"><font style="font-weight:bold;">' + sc_list_arr[arr_idx] + "</font></td>";
            } else if (arr_idx == 1) {
                head_row += '<td style="width:30px;"><font style="font-weight:bold;">' + sc_list_arr[arr_idx] + "</font></td>";
            } else {
                head_row += '<td><font style="font-weight:bold;">' + sc_list_arr[arr_idx] + "</font></td>";
            }
        }
        head_row += "</tr>";
        sc_name_row_str += head_row;

        for (var sc_name_idx = 0; sc_name_idx < sc_name_list.length; ++sc_name_idx) {
            sc_name_row_str += get_sc_row(sc_name_list[sc_name_idx]);
        }
            sc_name = sc_name.replace(new RegExp("\002", 'gm'), '<br/>');
        sc_name = sc_name.replace(new RegExp(":", 'gm'), '</font>: ');
        sc_name = sc_name.replace(new RegExp(",", 'gm'), ' ,&nbsp;<font style="font-weight:bold;">');
        sc_name = sc_name.replace(new RegExp("<br/>", 'gm'), '<br/><font style="font-weight:bold;">');
        sc_name = '<font style="font-weight:bold;">' + sc_name;
        sc_name_row_str += '</tbody>'
        sc_name_row_str += '</table>'
        $('#sc_name').html(sc_name_row_str);
        $("#preview_div", window.parent.document).modal('show');
    } 
}

function mousePosition(evt) {
    var xPos, yPos;
    evt = evt || window.event;
    if (evt.pageX) {
        xPos = evt.pageX;
        yPos = evt.pageY;
    } else {
        xPos = evt.clientX + document.body.scrollLeft - document.body.clientLeft;
        yPos = evt.clientY + document.body.scrollTop - document.body.clientTop;
    }
    return [xPos, yPos];
}

function show_query_menu(e, query, day) {
    query_str = query
    query_day = day
    var $contextMenu = $("#contextMenu");
    var $urlMenu = $("#urlMenu");
    $urlMenu.hide();
    $contextMenu.show();
    mouse_pos = mousePosition(e)
    $contextMenu.css({
        display: "block",
        left: mouse_pos[0] + 15,
        top: mouse_pos[1]
    });
}

function show_url_menu(e, url, target_url) {
    url_str = url
    url_target_str = target_url
    var $contextMenu = $("#contextMenu");
    var $urlMenu = $("#urlMenu");
    $contextMenu.hide();
    $urlMenu.show();
    mouse_pos = mousePosition(e)
    $urlMenu.css({
        display: "block",
        left: mouse_pos[0] + 15,
        top: mouse_pos[1]
    });
}

function create_li_item(object, action, query, sc_name, num, url, location, time, log_type, kt, page, pos, day) {
    icon_class = "fa fa-search bg-blue"
    item_title = "";
    if (log_type == 3) {
        icon_class = "fa fa-fw fa-hand-pointer-o bg-yellow"
        action = "";
        item_title = "点击";
    }

    if (kt == "suggest") {
        action = "下拉提示";
    } else if (kt == "history") {
        action = "搜索历史";
    } else if (kt == "next") {
        action = "翻下页";
    } else if (kt == "hot") {
        action = "热词搜索";
    } else if (kt == "multi_intention") {
        action = "多意图";
    } else if (kt == "relative_hot") {
        action = "横屏热搜";
    } else if (kt == "prev") {
        action = "翻上页";
    } else if (kt == "weather") {
        action = "天气搜索";
    } else if (kt == "submit") {
        action = "主动搜索";
    } else if (kt == "relative") {
        action = "相关搜索";
    } else if (kt == "spell") {
        action = "纠错";
    } else if (kt == "tuijian") {
        action = "推荐搜索";
    }

    if (log_type == 2) {
        item_title = "搜索";
    }

    if (log_type == 3) {
        item_title = "点击";
        action = "";
    }

    if (log_type == 4) {
        icon_class = "fa  fa-microphone bg-aqua"
        action = "";
        item_title = "语音";
    }

    margin_top = '-35px;';
    if (action.replace(/(^\s*)|(\s*$)/g, "").length > 2) {
        margin_top = '-52px;';
    }

    click_url = url;
    icon = '<i class="fa fa-link bg-white" style="margin-left:20px;float:left;margin-top:2px;"></i>';
    if (url == "") {
        click_url = "";
        icon = "";
    }

    num = page + ":" + pos;
    if (pos == -1) {
        num = page;
    }

    inner_html = "";
    if (url != "") {
        inner_html_list = url.split('?');
        inner_html = inner_html_list[0];
        for (var iner_idx = 1; iner_idx < inner_html_list.length; ++iner_idx) {
            inner_html += "\003" + inner_html_list[iner_idx];
        }
        inner_html = inner_html.replace(new RegExp("/", 'gm'), '\002');
        inner_html = inner_html.replace(new RegExp("#", 'gm'), '\004');
        inner_html = '/url_search/other_list/' + inner_html + '\001' + $("#time_field").val();
    }

    inner_html_list = query.split('?');
    change_query = inner_html_list[0];
    for (var inner_idx = 1; inner_idx < inner_html_list.length; ++inner_idx) {
        change_query += '\003' + inner_html_list[inner_idx];
    }

    color = "color:rgb(153,163,190)";
    if (action == "") {
        action = "显示";
        color = "color:rgb(236,240,245)";
    }

    if (sc_name == "[]") {
        sc_name = "";
    }
    tmp_sc_name = sc_name.replace(new RegExp("\n", 'gm'), '\002');
    li = $('<li style="margin-bottom:25px;" name="auto_li_name" title="' + item_title + '">' +
            '<label style="margin-left:-38px;margin-top:7px;font-size:10px;color:rgb(153,163,190);width:100px;float:left;">' + time + ' </label>' +
            '<i class="' + icon_class + '" style="float:left;" ></i>' +
            '<label style="margin-left:-6px;margin-top:7px;font-size:10px;' + color + ';width:100px;">' + action + '</label>' +
            '<div class="timeline-item" style="margin-left:100px;margin-top:' + margin_top + '">' +
                '<table class="items table" id="preview_table" table-bordered" style="margin-bottom:0px;border:0px solid rgb(219, 219, 219);table-layout:fixed;word-break:break-all; word-wrap:break-all;" cellspacing="1" cellpadding="1" border="0">' +
                    '<tbody id="_table" style="font-size:15px;">' +
                        '<tr>' +
                        '<td  title="' + query + '" style="width:25%;overflow:hidden;text-overflow:ellipsis;word-break:keep-all;white-space:nowrap;text-overflow:ellipsis;-o-text-overflow:ellipsis;-icab-text-overflow: ellipsis; -khtml-text-overflow: ellipsis; -moz-text-overflow: ellipsis; -webkit-text-overflow: ellipsis;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
                        '<a onmouseover="show_query_menu(event, \'' + change_query + '\',\'' + day + '\')" href="#">' + query + '</a></td>' +
                        '<td title="' + sc_name + '" style="width:30%;overflow:hidden;text-overflow:ellipsis;word-break:keep-all;white-space:nowrap;text-overflow:ellipsis;-o-text-overflow:ellipsis;-icab-text-overflow: ellipsis; -khtml-text-overflow: ellipsis; -moz-text-overflow: ellipsis; -webkit-text-overflow: ellipsis; "><a href="javascript:void(0)" style = "text-decoration:none;" onclick="show_sc_name(\'' + tmp_sc_name + '\');">' + sc_name + '</a></td>' +
                        '<td title="' + url + '" style="width:35%;overflow:hidden;text-overflow:ellipsis;word-break:keep-all;white-space:nowrap;text-overflow:ellipsis;-o-text-overflow:ellipsis;-icab-text-overflow: ellipsis; -khtml-text-overflow: ellipsis; -moz-text-overflow: ellipsis; -webkit-text-overflow: ellipsis;">' + icon + ' <a  onmouseover="show_url_menu(event, \'' + inner_html + '\',\'' + click_url + '\')" href="#">' + click_url + '</a></td>' +
                        '<td title="分页：位置" style="width:10%;"><i class="fa fa-tags bg-white" style="float:left;margin-top:2px;margin-left:30px;"></i>' + num + '</td>' +
                        '</tr>' +
                    '</tbody>' +
                '</table>' +
            '</div>' +
        '</li>');

    var data_type = $("#data_type").val();
    if (data_type == 1) {
        li = $('<li style="margin-bottom:25px;" name="auto_li_name" title="' + item_title + '">' +
            '<label style="margin-left:-38px;margin-top:7px;font-size:10px;color:rgb(153,163,190);width:100px;float:left;">' + time + ' </label>' +
            '<i class="' + icon_class + '" style="float:left;" ></i>' +
            '<label style="margin-left:-6px;margin-top:7px;font-size:10px;' + color + ';width:100px;">' + action + '</label>' +
            '<div class="timeline-item" style="margin-left:100px;margin-top:' + margin_top + '">' +
                '<table class="items table" id="preview_table" table-bordered" style="margin-bottom:0px;border:0px solid rgb(219, 219, 219);table-layout:fixed;word-break:break-all; word-wrap:break-all;" cellspacing="1" cellpadding="1" border="0">' +
                    '<tbody id="_table" style="font-size:15px;">' +
                        '<tr>' +
                        '<td title="' + url + '" style="width:100%;overflow:hidden;text-overflow:ellipsis;word-break:keep-all;white-space:nowrap;text-overflow:ellipsis;-o-text-overflow:ellipsis;-icab-text-overflow: ellipsis; -khtml-text-overflow: ellipsis; -moz-text-overflow: ellipsis; -webkit-text-overflow: ellipsis;">' + icon + ' <a style = "text-decoration:none;" href="' + inner_html + '" target="_blank">' + click_url + '</a></td>' +
                        '</tr>' +
                    '</tbody>' +
                '</table>' +
            '</div>' +
        '</li>');
    }
    li.insertAfter(object);
    return li;
}
function AddDays(date,days){
var nd = new Date(date);
   nd = nd.valueOf();
   nd = nd + days * 24 * 60 * 60 * 1000;
   return new Date(nd);
}
function get_session_list() {
    uid = $('#uid').val();
    if(uid == "") {
        showMessage("error", "错误提示", "请输入uid");
        return;
    }
    $('#wait_busy_icon').show();
    $('#submit_button').attr('disabled', "true");
    $(document).find("li[name='auto_li_name']").remove();
    clean_only = $('#ck_clean').is(":checked") ? 1 : 0;
    var data_type = $("#data_type").val();
    var date_range = $("#time_field").val().split(' to ');
    var start_date = new Date(Date.parse(date_range[0]));
    var end_date = new Date(Date.parse(date_range[1]));
    var date = start_date;
    do_get_session_list(data_type, date, end_date);
    session_result_empty = false;
}
function do_get_session_list(data_type, date, end_date){
        var year = date.getFullYear();
        var month = (date.getMonth() + 1) > 9 ? (date.getMonth() + 1) : '0'+(date.getMonth() + 1);
        var day = date.getDate() > 9 ? date.getDate() : '0'+date.getDate();
        date_str = year + "-" + month + "-" + day;
        $.ajax({
            url: '/session_search/list/',
            type: 'post',
            dataType: 'json',
            async: true,
            data: { "uid": uid, 
                    "clean_only": clean_only,
                    "date": date_str, 
                    data_type: data_type },
            success: function (result) {
                if (result.status == 0 && result.data && result.data.length > 0) {
                    if (data_type == 2)//喜唰唰
                    {
                        window.open("http://editor.zzd.shenma-dev.com/editor/reco_history/list?appToken=uc-iflow&searchType=userId&searchValue=" + result.user_id + "&accountProvider=uc&channelId=100&beginTime=&endTime=&maxCount=50");
                        return;
                    }
                    object = $('#start_li');
                    count = 0;
                    var show_session = false;
                    object = create_li_head_first(object, result.data[0][0], count, result.fr, result.location+'('+date_str+')');
                    for (var data_idx = 0; data_idx < result.data.length; data_idx++) {
                        if (count != 0) {
                            object = create_li_head(object, result.data[data_idx][0], count);
                        }
                        data_list = result.data[data_idx][1]
                        for (var i = 0; i < data_list.length; i++) {
                            object = create_li_item(object, '入口', data_list[i].query, data_list[i].sc_type, 10, data_list[i].url, data_list[i].city, data_list[i].time, parseInt(data_list[i].log_type, 10), data_list[i].kt, parseInt(data_list[i].page, 10), parseInt(data_list[i].pos, 10), date_str);
                        }
                        ++count;
                    }
                    if (count != 0) {
                        session_result_empty = true;
                    }
                    create_li_tail(object);
                }
                if(date < end_date)
                {
                    date = AddDays(date, 1);
                    do_get_session_list(data_type, date, end_date);
                }
                else
                {
                    $('#wait_busy_icon').hide();
                    $('#submit_button').removeAttr("disabled");
                    if(!session_result_empty)
                    {
                        showErrorMessage("没有数据!");
                        return;
                    }
                }
            }
        });
    }

$(document).ready(function () {
    var $contextMenu = $("#contextMenu");
    var $urlMenu = $("#urlMenu");
    
    $contextMenu.on("click", "a", function (e) {
        $contextMenu.hide();
    });

    $urlMenu.on("click", "a", function (e) {
        $urlMenu.hide();
    });
    $contextMenu.hide();
    $urlMenu.hide();
    $(document).click(function () {
        $contextMenu.hide();
        $urlMenu.hide();
    });
    $contextMenu.on("click", "a", function (e) {
        e.preventDefault();
        $contextMenu.hide();
        if ('visit_query_search' == $(this).attr("op")) {
            var url = "/query_search/other_list/" + query_str + '\001' + query_day + '/';
            window.open(url);
        }

        if ('search_result' == $(this).attr("op")) {
            var url = "http://m.sm.cn/s?q=" + query_str;
            window.open(url);
        }
    });

    $urlMenu.on("click", "a", function (e) {
        e.preventDefault();
        $urlMenu.hide();
        if ('url_search' == $(this).attr("op")) {
            window.open(url_str)
        }

        if ('url_target' == $(this).attr("op")) {
            window.open(url_target_str)
        }
    });

    now_date = get_pre_date(1);
    start_date = last_week = get_pre_date(7);
    last_month = get_pre_month(1);
    var dateTextBox = $("#time_field");
    dateTextBox.daterangepicker({
                "locale": {
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "fromLabel": "From",
                    "toLabel": "To",
                    "customRangeLabel": "自定义时间",
                    "daysOfWeek": [
                        "日", 
                        "一", 
                        "二", 
                        "三", 
                        "四", 
                        "五", 
                        "六"
                    ],
                    "monthNames": [
                        "一月",  
                        "二月",  
                        "三月",  
                        "四月",
                        "五月",
                        "六月",
                        "七月",
                        "八月",
                        "九月",
                        "十月",
                        "十一月",
                        "十二月"
                    ],
                    "firstDay": 1
                },
                opens: (App.isRTL() ? 'left' : 'right'),
                format: 'yyyy-MM-dd',
                separator: ' to ',
                startDate: last_week,
                endDate: now_date,
                minDate: last_month,
                maxDate: now_date
            });
    $("#time_field").val(last_week+" to "+now_date);
    $(document).mousewheel(function (event, delta) {
        mousewheelEvent(event, delta);
    });

    if ($('#other_query').val() != "") {
        $('#uid').val($('#other_query').val());
        $('#time_field').val($('#other_date').val());
        get_session_list();
    }
});
function mousewheelEvent(e, delta) {
    $(".daterangepicker").eq(0).css("display", "none");
}
