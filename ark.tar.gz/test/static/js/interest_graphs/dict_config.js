var local_file_name = '';
var local_file_load_interval = '';
$(function () {
    $("#file").change(function () {
        $("#a").val($("#file").val());
        if ($("#file").val() != "") {
            upload_file();
        }
    });

    tmp_dict = { "dict_id": $('#dict_id').val() };
    $.ajax({
        url: '/interest_graphs/tag/dict/get_dict_info/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            if (result.status == 0) {
                if (result.src_type == 0) {
                    init_table_fields_list('local_table_fileds_list', result, 'local_file_div');
                    create_kg_table();
                    $('#local_tab_button').trigger('click');
                } else if (result.src_type == 1) {
                    init_table_fields_list('odps_table_fileds_list', result, 'odps_table_div');
                    var table_split = result.src_path.split('/');
                    $('#odps_project').val(table_split[0]);
                    $('#odps_table').val(table_split[1]);
                    $('#odps_part').val(table_split[2]);
                    create_kg_table();
                    $('#odps_tab_button').trigger('click');
                } else if (result.src_type == 2) {
                    init_table_fields_list('kg_table_fileds_list', result, 'kg_table_div');
                    $('#kg_odps_part').val(result.src_path);
                    $('#kg_tab_button').trigger('click');
                    if (result.table_schema.length <= 0) {
                        create_kg_table();
                    }
                }
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });

    $("#kg_btn_add_filed").on('click', function () {
        $(".kg_table_fileds_list").append('<tr>' +
            '<td><input style="width:100%;" type="text" value=' + '' + '></td>' +
            '<td><input style="width:100%;" type="text" value=' + '' + '></td>' +
            '<td><input style="width:100%;" type="text" value=' + '' + '></td>' +
            '<td >' +
                '<select class="" tabindex="1" style="width:100%;table-layout: fixed;" cond_type="dropdown" id="batch_match_mode">' +
                    '<option value="int">int</option>' +
                    '<option value="double">double</option>' +
                    '<option value="varchar(128)" selected>varchar(128)</option>' +
                    '<option value="text">text</option>' +
                '</select>' +
            '</td>' +
            '<td>' +
                '<label class="radio" style="margin-left:50px;margin-top:0px;"> <input type="radio" name="kg_key_mode" value=""></label>' +
            '</td>' +
            '<td class="field_op"><i class="fa fa-fw fa-minus-circle delete_field"></i></td>' +
        '</tr>');
    });

    $(document).on("click", ".kg_table_fileds_list .delete_field", function () {
        $(this).parent().parent().remove();
    });
});


function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}

function upload_file() {
    $("#upload_busy").show();
    var form_data = new FormData($("#formid")[0]);
    $.ajax({
        url: '/interest_graphs/tag/dict/upload_local_file/',
        type: 'POST',
        data: form_data,
        cache: false,
        contentType: false,
        async: false,
        processData: false,
        success: function (result) {
            if (result.status == 0) {
                load_local_file_header(result.file_name)
            } else {
                $("#upload_busy").hide();
                $("#a").val("");
                $("#file").val("");
                showMessage("error", "失败", result.info);
            }
        }
    });
}

function create_local_file_table(headers) {
    var new_table = '<table class="table table-bordered local_table_fileds_list">'+
        '<tr>'+
            '<td style="width:30%">字段名</td>'+
            '<td style="width:30%">中文列名</td>'+
            '<td style="width:30%">数据类型</td>'+
            '<td>唯一主键</td>'+
        '</tr>'
    for (var i = 0; i < headers.length; ++i) {
        checked = ''
        if (i == 0) {
            checked = 'checked'
        }
        var tmp_row = '<tr>' +
            '<td class="field_name">' + headers[i] + '</td>' +
            '<td><input style="width:100%;" type="text" value=' + headers[i] + '></td>' +
            '<td >' +
                '<select class="" tabindex="1" style="width:100%;table-layout: fixed;" cond_type="dropdown" id="batch_match_mode">' +
                    '<option value="int">int</option>' +
                    '<option value="double">double</option>' +
                    '<option value="varchar(128)" selected>varchar(128)</option>' +
                    '<option value="text">text</option>' +
                '</select>' +
            '</td>' +
            '<td>' +
                '<label class="radio" style="margin-left:50px;margin-top:0px;"> <input type="radio" name="local_key_mode" value=' + headers[i] + ' ' + checked + '></label>' +
            '</td>' +
        '</tr>'
        new_table += tmp_row
    }
    $("#local_file_div").html(new_table)
}

function init_table_fields_list(table_name, dict_info, div_name) {
    var new_table = '<table class="table table-bordered ' + table_name + '">' +
        '<tr>' +
            '<td style="width:30%">字段名</td>' +
            '<td style="width:30%">中文列名</td>' +
            '<td style="width:30%">数据类型</td>' +
            '<td>唯一主键</td>' +
        '</tr>'

    if (dict_info.src_type == 2) {
        new_table = '<table class="table table-bordered kg_table_fileds_list">' +
        '<tr>' +
            '<td style="width:25%">图谱提取字段</td>' +
            '<td style="width:20%">字段名</td>' +
            '<td style="width:20%">中文列名</td>' +
            '<td style="width:20%">数据类型</td>' +
            '<td>唯一主键</td>' +
            '<td class="field_op"></td>' +
        '</tr>'

    }
    radio_key_mode = 'local_key_mode';
    if (dict_info.src_type == 1) {
        radio_key_mode = 'odps_key_mode';
    } else if (dict_info.src_type == 2) {
        radio_key_mode = 'kg_key_mode';
    }
    for (var i = 0; i < dict_info.table_schema.length; ++i) {
        var checked = ''
        if (dict_info.table_schema[i].col_name == dict_info.unique_cols) {
            checked = 'checked'
        }
        var int_selected = ''
        var double_selected = ''
        var varchar_selected = ''
        var text_selected = ''
        if (dict_info.table_schema[i].value_type == 'int') {
            int_selected = 'selected';
        } else if (dict_info.table_schema[i].value_type == 'double') {
            double_selected = 'selected';
        } else if (dict_info.table_schema[i].value_type == 'text') {
            text_selected = 'selected';
        } else {
            varchar_selected = 'selected';
        }

        chinese_name = dict_info.table_schema[i].chinese_name;
        if (chinese_name == '') {
            chinese_name = dict_info.table_schema[i].col_name;
        }
        var tmp_row = '<tr>' 
        if (dict_info.src_type == 2) {
            tmp_row += '<td><input style="width:100%;" type="text" value=' + dict_info.table_schema[i].kg_key + '></td>' +
                '<td><input style="width:100%;" type="text" value=' + dict_info.table_schema[i].col_name + '></td>'
        } else {
            tmp_row +=  '<td class="field_name">' + dict_info.table_schema[i].col_name + '</td>'
        }
        tmp_row +=
            '<td><input style="width:100%;" type="text" value=' + chinese_name + '></td>' +
            '<td >' +
                '<select class="" tabindex="1" style="width:100%;table-layout: fixed;" cond_type="dropdown" id="batch_match_mode">' +
                    '<option value="int"' + int_selected + '>int</option>' +
                    '<option value="double"' + double_selected + '>double</option>' +
                    '<option value="varchar(128)" ' + varchar_selected + '>varchar(128)</option>' +
                    '<option value="text"' + text_selected + '>text</option>' +
                '</select>' +
            '</td>' +
            '<td>' +
                '<label class="radio" style="margin-left:50px;margin-top:0px;"> <input type="radio" name="' + radio_key_mode + '" value=' + dict_info.table_schema[i].col_name + ' ' + checked + '></label>' +
            '</td>' +
        '</tr>'
        new_table += tmp_row
    }

    if (dict_info.src_type == 2) {
        new_table += '</table>' +
        '<input type="button" style="margin-bottom:10px;background-color: #60A4CC;border-color: #60A4CC;" value="添加字段" id="kg_btn_add_filed" class="btn btn-primary">'
    }
    $("#" + div_name).html(new_table)

    if (dict_info.src_type == 1) {
        var table_split = dict_info.src_path.split('/');
        if (table_split.length > 2 && table_split[1] != '') {
            $('#load_odps_table_div').show()
        }
    }
}

function change_color(obj) {
    return;
    for (i = 0; i < sel_s.length; i++) {
        sel_s[i].style.fontWeight = "normal";
    }
    obj.style.fontWeight = "bold";
} 

function load_local_file_header(file_name) {
    $.ajax({
        url: '/interest_graphs/tag/dict/get_data_headers/',
        type: 'POST',
        dataType: "json",
        data: { "src_name": file_name },
        async: false,
        success: function (result) {
            $("#upload_busy").hide();
            if (result.status == 0) {
                create_local_file_table(result.headers)
                local_file_name = file_name
                tmp_dict = { 'src_type': 0, 'src_path': file_name, 'dict_id': $('#dict_id').val() };
                $.ajax({
                    url: '/interest_graphs/tag/dict/update_dict/',
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    data: tmp_dict,
                    success: function (result) {
                        if (result.status == 0) {
                            $('#local_data_load_div').show()
                        } else {
                            showMessage("error", "失败", result.msg);
                        }
                    }
                });
            } else {
                $("#a").val("");
                $("#file").val("");
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function get_format_data() {
    var format = [];
    $(".local_table_fileds_list tr:gt(0)").each(function () {
        var name = $(this).find("td").eq(0).text();
        var chinese_name = $(this).find("td").eq(1).find("input").val().trim();
        var type = $(this).find("td").eq(2).find("select").val().trim();
        format.push({ 'col_name': name, 'chinese_name': chinese_name, 'value_type': type });
    });
    var uniqe_key = ''
    var temp = document.getElementsByName("local_key_mode");
    for (var i = 0; i < temp.length; i++) {
        if (temp[i].checked)
            uniqe_key = temp[i].value;
    }
    tmp_dict = { 'unique_cols': uniqe_key, 'table_schema': JSON.stringify(format), "dict_id": $('#dict_id').val() }
    return tmp_dict;
}

function update_local_data() {
    tmp_dict = get_format_data();
    $.ajax({
        url: '/interest_graphs/tag/dict/update_dict/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            if (result.status == 0) {
                showMessage("info", "信息", "更新成功！");
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function load_local_data() {
    if (local_file_name == '') {
        return;
    }
    tmp_dict = get_format_data();
    $.ajax({
        url: '/interest_graphs/tag/dict/update_dict/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
        }
    });

    tmp_dict = { "dict_id": $('#dict_id').val(), 'excel_name': local_file_name, 'src_type':0 };
    $.ajax({
        url: '/interest_graphs/tag/dict/load_data_to_mysql/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: false,
        success: function (result) {
            if (result.status == 0) {
                local_file_load_interval = setInterval("check_load_local_data_progress(0)", 1000);
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function check_load_local_data_progress(type) {
    tmp_dict = { "dict_id": $('#dict_id').val() };
    $.ajax({
        url: '/interest_graphs/tag/dict/load_and_check_data_to_mysql/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            if (result.status != 0) {
                clearInterval(local_file_load_interval)
                showMessage("error", "失败", result.msg);
            }

            if (type == 0) {
                var obj = document.getElementById('local_progress_bar');
                obj.style.width = result.progress_val;
                var obj = document.getElementById('local_progress_val');
                obj.innerHTML = result.progress_val;
                var obj = document.getElementById('local_progress_label');
                obj.innerHTML = result.progress;

            } else if (type == 1) {
                var obj = document.getElementById('odps_progress_bar');
                obj.style.width = result.progress_val;
                var obj = document.getElementById('odps_progress_val');
                obj.innerHTML = result.progress_val;
                var obj = document.getElementById('odps_progress_label');
                obj.innerHTML = result.progress;
            } else if (type == 2) {
                var obj = document.getElementById('kg_progress_bar');
                obj.style.width = result.progress_val;
                var obj = document.getElementById('kg_progress_val');
                obj.innerHTML = result.progress_val;
                var obj = document.getElementById('kg_progress_label');
                obj.innerHTML = result.progress;
            }
            
            if (result.run_status == 1) {
                return;
            }

            if (result.run_status == 2) {
                clearInterval(local_file_load_interval)
            }

            if (result.run_status == 3) {
                clearInterval(local_file_load_interval)
                showMessage("info", "失败", result.progress);
            }
        }
    });
}

function create_odps_file_table(headers) {
    var new_table = '<table class="table table-bordered odps_table_fileds_list">' +
        '<tr>' +
            '<td style="width:30%">字段名</td>' +
            '<td style="width:30%">中文列名</td>' +
            '<td style="width:30%">数据类型</td>' +
            '<td>唯一主键</td>' +
        '</tr>'
    for (var i = 0; i < headers.length; ++i) {
        checked = ''
        if (i == 0) {
            checked = 'checked'
        }
        var tmp_row = '<tr>' +
            '<td class="field_name">' + headers[i] + '</td>' +
            '<td><input style="width:100%;" type="text" value=' + headers[i] + '></td>' +
            '<td >' +
                '<select class="" tabindex="1" style="width:100%;table-layout: fixed;" cond_type="dropdown" id="odps_batch_match_mode">' +
                    '<option value="int">int</option>' +
                    '<option value="double">double</option>' +
                    '<option value="varchar(128)" selected>varchar(128)</option>' +
                    '<option value="text">text</option>' +
                '</select>' +
            '</td>' +
            '<td>' +
                '<label class="radio" style="margin-left:50px;margin-top:0px;"> <input type="radio" name="odps_key_mode" value=' + headers[i] + ' ' + checked + '></label>' +
            '</td>' +
        '</tr>'
        new_table += tmp_row
    }
    $("#odps_table_div").html(new_table)
}

function load_odps_fields() {
    $('#odps_load_schema_busy').show()
    $.ajax({
        url: '/interest_graphs/tag/dict/get_data_headers/',
        type: 'POST',
        dataType: "json",
        data: { "src_name": $("#odps_table").val(), 'odps_project': $("#odps_project").val() },
        success: function (result) {
            $("#upload_busy").hide();
            if (result.status == 0) {
                create_odps_file_table(result.header)
                file_name = $("#odps_table").val() + '/' + $("#odps_part").val()
                tmp_dict = { 'src_type': 1, 'src_path': file_name, 'dict_id': $('#dict_id').val() };
                $.ajax({
                    url: '/interest_graphs/tag/dict/update_dict/',
                    type: 'POST',
                    dataType: "json",
                    data: tmp_dict,
                    success: function (result) {
                        $('#odps_load_schema_busy').hide()
                        if (result.status == 0) {
                            $('#load_odps_table_div').show()
                        } else {
                            showMessage("error", "失败", result.msg);
                        }
                    }
                });
            } else {
                $("#a").val("");
                $("#file").val("");
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function get_odps_format_data() {
    var format = [];
    $(".odps_table_fileds_list tr:gt(0)").each(function () {
        var name = $(this).find("td").eq(0).text();
        var chinese_name = $(this).find("td").eq(1).find("input").val();
        var type = $(this).find("td").eq(2).find("select").val();
        if (name != '字段名') {
            format.push({ 'col_name': name, 'chinese_name': chinese_name, 'value_type': type });
        }
    });
    var uniqe_key = ''
    var temp = document.getElementsByName("odps_key_mode");
    for (var i = 0; i < temp.length; i++) {
        if (temp[i].checked)
            uniqe_key = temp[i].value;
    }
    tmp_dict = { 'unique_cols': uniqe_key, 'table_schema': JSON.stringify(format), "dict_id": $('#dict_id').val() }
    return tmp_dict;
}

function update_odps_data() {
    tmp_dict = get_odps_format_data();
    $.ajax({
        url: '/interest_graphs/tag/dict/update_dict/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            $('#odps_load_schema_busy').hide()
            if (result.status == 0) {
                $('#load_odps_table_div').show()
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}
function load_odps_data() {
    tmp_dict = get_odps_format_data();
    $.ajax({
        url: '/interest_graphs/tag/dict/update_dict/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            $('#odps_load_schema_busy').hide()
            if (result.status == 0) {
                $('#load_odps_table_div').show()
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });

    tmp_dict = { "dict_id": $('#dict_id').val(), 'odps_table': $("#odps_table").val(), 'src_type': 1, 'odps_project': $("#odps_project").val(), 'odps_part': $("#odps_part").val() };
    $.ajax({
        url: '/interest_graphs/tag/dict/load_data_to_mysql/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            if (result.status == 0) {
                local_file_load_interval = setInterval("check_load_local_data_progress(1)", 1000);
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function create_kg_table() {
    var new_table = '<table class="table table-bordered kg_table_fileds_list">' +
        '<tr>' +
            '<td style="width:25%">图谱提取字段</td>' +
            '<td style="width:20%">字段名</td>' +
            '<td style="width:20%">中文列名</td>' +
            '<td style="width:20%">数据类型</td>' +
            '<td>唯一主键</td>' +
            '<td class="field_op"></td>'+
        '</tr>'
    for (var i = 0; i < 1; ++i) {
        checked = 'checked'
        var tmp_row = '<tr>' +
            '<td><input style="width:100%;" type="text" value=' + '' + '></td>' +
            '<td><input style="width:100%;" type="text" value=' + '' + '></td>' +
            '<td><input style="width:100%;" type="text" value=' + '' + '></td>' +
            '<td >' +
                '<select class="" tabindex="1" style="width:100%;table-layout: fixed;" cond_type="dropdown" id="batch_match_mode">' +
                    '<option value="int">int</option>' +
                    '<option value="double">double</option>' +
                    '<option value="varchar(128)" selected>varchar(128)</option>' +
                    '<option value="text">text</option>' +
                '</select>' +
            '</td>' +
            '<td>' +
                '<label class="radio" style="margin-left:50px;margin-top:0px;"> <input type="radio" name="kg_key_mode" value="" checked></label>' +
            '</td>' +
        '</tr>'
        new_table += tmp_row
    }

    new_table += '</table>'+
    '<input type="button" style="margin-bottom:10px;background-color: #60A4CC;border-color: #60A4CC;" value="添加字段" id="kg_btn_add_filed" class="btn btn-primary">'
    $("#kg_table_div").html(new_table)
}

function get_kg_format_data() {
    var format = [];
    $(".kg_table_fileds_list tr:gt(0)").each(function () {
        var kg_key = $(this).find("td").eq(0).find("input").val().trim();
        var name = $(this).find("td").eq(1).find("input").val().trim();
        var chinese_name = $(this).find("td").eq(2).find("input").val().trim();
        var type = $(this).find("td").eq(3).find("select").val().trim();
        format.push({ 'kg_key': kg_key, 'col_name': name, 'chinese_name': chinese_name, 'value_type': type });
    });
    var uniqe_key = ''
    var temp = document.getElementsByName("kg_key_mode");
    for (var i = 0; i < temp.length; i++) {
        if (temp[i].checked) {
            uniqe_key = format[i].col_name;
            break;
        }
    }
    tmp_dict = { 'unique_cols': uniqe_key, 'table_schema': JSON.stringify(format), "dict_id": $('#dict_id').val() }
    return tmp_dict;
}

function update_kg_schema() {
    tmp_dict = get_kg_format_data();
    $.ajax({
        url: '/interest_graphs/tag/dict/update_dict/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            $('#odps_load_schema_busy').hide()
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
            } else {
                showMessage("info", "成功", "更新成功！");
            }
        }
    });
}

function load_kg_odps_data() {
    tmp_dict = get_kg_format_data();
    $.ajax({
        url: '/interest_graphs/tag/dict/update_dict/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: tmp_dict,
        success: function (result) {
            $('#odps_load_schema_busy').hide()
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
            }
        }
    });

    tmp_dict = { "dict_id": $('#dict_id').val(), 'src_type': 2, 'odps_part': $("#kg_odps_part").val() };
    $.ajax({
        url: '/interest_graphs/tag/dict/load_data_to_mysql/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        success: function (result) {
            if (result.status == 0) {
                local_file_load_interval = setInterval("check_load_local_data_progress(2)", 1000);
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });

}
