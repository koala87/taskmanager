pipeline_history_url = 'http://ark.sm.cn/pipeline/history/';
task_id = null;
scroll_step = null;
auto_incre_run_time = null;
interval_get_task_calculate_run_status = null;
calculate_task_running = false;

calculate_res_page = 0;
calculate_res_page_size = 10;

table_calculate_res = null;

dict_list_select2 = null;
interval_get_get_publish_status = null;
$(function(){
    task_id = $("#hidden_task_id").val();
    auto_seek = false;
    if(task_id)
    {
        fill_content();
    }
    init_add_source_op();
    scroll_step = $("#task_step_wizard").scrollable({
        onSeek: function(event,i){
            auto_seek = false;
            $("#title_task_step li").removeClass("active").eq(i).addClass("active");
        },
        onBeforeSeek:function(event,i){
            var ret = true;
            interval_get_task_calculate_run_status ? clearInterval(interval_get_task_calculate_run_status) : '';
            interval_get_task_calculate_run_status = null;
            auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
            auto_incre_run_time = null;
            if(i==1 && !auto_seek){
                $("#btn_save_data_conf").html('处理中...');
                $("#btn_save_data_conf").prop('disabled', true);
                var prev_index = $("#task_step_wizard").data('scrollable').getIndex();
                setTimeout(function(){
                    if(prev_index < 1)
                    {
                        ret = upsert_task();
                    }
                    $("#btn_save_data_conf").html('下一步');
                    $("#btn_save_data_conf").prop('disabled', false);
                }, 0);
            }
            else if(i==2 && !auto_seek){
                $("#btn_start_calculate").button('loading');
                setTimeout(function(){
                    ret = upsert_task();
                    $("#btn_start_calculate").button('reset');
                }, 0);
            }

            return ret;
        }
    });
    $(document).on('click', '.block_source_remove', function(){
        $(this).parents(".block_source").remove();
        sync_pk_relate();
    });
    $(document).on('click', '.attr_remove', function(){
        $(this).parents(".form-group").remove();
    });
    $(document).on('change', '#use_baike_url', function(){
        if($(this).is(':checked'))
        {
            res = false;
            $(".block_source").each(function(){
                if($(this).find('#input_kg_type').length > 0)
                {
                    $(this).find('.attr_line').each(function(){
                        if($(this).find('input:eq(0)').val().trim() == 'baike_url')
                        {
                            res = true;
                        }
                    });
                }
            });
            if(!res)
            {
                $(this).prop('checked', false);
                ark_notify({status:1, msg:'请先在知识图谱源中配置属性"baike_url"'});
                return;
            }
        }
        $("#input_baike_condition").prop('disabled', $(this).is(':checked'));
    });
    $("#output_attrs").select2();
    $(document).on('change', ".pk", function(){
        $(".pk").val($(this).val());
    });
    $('#publishModal').on('shown.bs.modal', function () {
      get_task_dict_conf();
    });
    $(document).on('change', "#publishModal .publish_type_select2", function(){
        if($(this).val() == 1)
        {
            $(this).parent().next().show();
        }
        else
        {
            $(this).parent().next().hide();
        }
    });
    $(document).on('dblclick', "#res_table_calculate tbody tr", function(){
        $("#res_table_calculate tbody tr").removeClass('selected');
        $(this).addClass('selected');
        var cols = [];
        $("#res_table_calculate thead th").each(function(){
            cols.push($(this).text());
        });
        var vals = [];
        $(this).find('td').each(function(){
            vals.push($(this).text());
        });
        var html = '';
        for(var i in cols)
        {
            html += '<tr><td>'+cols[i]+'</td><td>'+vals[i]+'</td></tr>';
        }
        $("#rowDetailModal #table_row_detail tbody").html(html);
        $("#rowDetailModal").modal('show');
    });
});
function get_task_dict_conf()
{
    var url = '/interest_graphs/tools/keywords/get_keywords_detail/';
    var post_data = {id:task_id};
    var callback = callback_get_task_dict_conf;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_task_dict_conf(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    var lines = [];
    if(result.output_schema)
    {
        lines = result.output_schema.split(',');
    }
    var lines_dict_conf = result.dict_conf ? result.dict_conf.split(',') : [];
    $("#publishModal form").empty();
    for(var i in lines)
    {
        var configed = false;
        lines[i] += ':';
        for(var j in lines_dict_conf)
        {
            if(lines_dict_conf[j].indexOf(lines[i]) > -1)
            {
                lines[i] = lines_dict_conf[j];
                configed = true;
                break;
            }
        }
        var tmp = lines[i].split(':');
        var key = tmp[0];
        var val = tmp[1];
        $("#publishModal form").append('<div class="form-group"> \
                                           <label for="dict_name_select2" class="col-sm-2 control-label">'+key+'</label> \
                                           <div class="col-sm-3"> \
                                                <select class="form-control publish_type_select2" '+(i == 0 ? 'disabled' : '')+' > \
                                                    <option value="1" '+(val ? 'selected' : '')+'>发布为词典</option> \
                                                    <option value="0" '+(!val && configed ? 'selected' : '')+'>作为属性</option> \
                                                </select> \
                                            </div> \
                                           <div class="col-sm-7" '+(!val && configed ? 'hidden' : '')+'> \
                                                <input type="text" class="form-control dict_name_select2" value="'+val+'" action-data=\''+(val ? JSON.stringify({id:val, text:val}) : '{}')+'\'> \
                                            </div> \
                                        </div>');
    }
    $("#publishModal .dict_name_select2").select2({
        placeholder: '请输入词典名称',
        allowClear: true,
        ajax: {
            url: '/interest_graphs/tag/dict/list/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                'search[value]': term,
                type:0,
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.data)
                    {
                        ret.push({id:data.data[i].name, text:data.data[i].name});
                    }
                }
                return {
                  results: ret
                };
            }
        },
        createSearchChoice:function(term, data) {
            if ($(data).filter(function() {
                return this.text.localeCompare(term)===0;
            }).length===0) {
                return {id:term, text:term};
            }
        },
        initSelection: function (element, callback) {
            var attr = JSON.parse(element.attr('action-data'));
            var data = attr;
            callback(attr);//这里初始化
        },
        language: 'ch',
    });
}
function init_add_source_op()
{
    $("#select_add_source").on('change', function(){
        var source = $(this).val();
        $(this).val("0");
        var html = '';
        if(source == 1)
        {
            if($("#input_kg_type").length > 0)
            {
                ark_notify({status:1,msg:'已存在此类型数据源'});
                return false;
            }
            html = '<div class="block_source"> \
                        <span class="block_source_title">知识图谱源</span> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><font color="red">*</font>类目</label> \
                            <div class="col-sm-2"> \
                                <input type="text" class="form-control" id="input_kg_type" placeholder="请填写类目"> \
                            </div> \
                        </div> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><font color="red">*</font>主键</label> \
                            <div class="col-sm-2"> \
                                <input type="text" class="form-control pk" id="input_kg_pk_name" placeholder="请填写主键名称"> \
                            </div> \
                            <div class="col-sm-8"> \
                                <input type="text" class="form-control" id="input_kg_pk_path" placeholder="请填写主键key"> \
                            </div> \
                        </div> \
                        <div class="form-group attr_line"> \
                            <label class="col-sm-1 control-label">属性</label> \
                            <div class="col-sm-2"> \
                                <input type="text" class="form-control" class="input_kg_attr_name" placeholder="请填写属性名"> \
                            </div> \
                            <div class="col-sm-8"> \
                                <input type="text" class="form-control" class="input_kg_attr_path" placeholder="请填写属性key"> \
                            </div> \
                            <div class="col-sm-1"> \
                                <span class="glyphicon glyphicon-remove attr_remove" aria-hidden="true"></span> \
                            </div> \
                        </div> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><span class="glyphicon glyphicon-plus btn_add_attr" onclick="add_attr(this)" aria-hidden="true"></span></label> \
                        </div> \
                        <span class="glyphicon glyphicon-remove block_source_remove" aria-hidden="true"></span> \
                    </div>';
        }
        else if(source == 2)
        {
            if($("#input_baike_condition").length > 0)
            {
                ark_notify({status:1,msg:'已存在此类型数据源'});
                return false;
            }
            html = '<div class="block_source"> \
                        <span class="block_source_title">百科源</span> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><font color="red">*</font>条件</label> \
                            <div class="col-sm-4"> \
                                <input type="text" class="form-control" id="input_baike_condition" placeholder="请填写配置条件"> \
                            </div> \
                            <div class="col-sm-4"> \
                                <label class="checkbox-inline"><input type="checkbox" id="use_baike_url" value="1">使用百科url</label> \
                            </div> \
                        </div> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><font color="red">*</font>主键</label> \
                            <div class="col-sm-2"> \
                                <input type="text" class="form-control pk" id="input_kg_baike_name" placeholder="请填写主键名称"> \
                            </div> \
                            <div class="col-sm-8"> \
                                <input type="text" class="form-control" id="input_kg_baike_path" placeholder="请填写主键key"> \
                            </div> \
                        </div> \
                        <div class="form-group attr_line"> \
                            <label class="col-sm-1 control-label">属性</label> \
                            <div class="col-sm-2"> \
                                <input type="text" class="form-control" class="input_baike_attr_name" placeholder="请填写属性名"> \
                            </div> \
                            <div class="col-sm-8"> \
                                <input type="text" class="form-control" class="input_baike_attr_path" placeholder="请填写属性key"> \
                            </div> \
                            <div class="col-sm-1"> \
                                <span class="glyphicon glyphicon-remove attr_remove" aria-hidden="true"></span> \
                            </div> \
                        </div> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><span class="glyphicon glyphicon-plus btn_add_attr" onclick="add_attr(this)" aria-hidden="true"></span></label> \
                        </div> \
                        <span class="glyphicon glyphicon-remove block_source_remove" aria-hidden="true"></span> \
                    </div>';
        }
        else if(source == 3)
        {
            if($("#input_file_path").length > 0)
            {
                ark_notify({status:1,msg:'已存在此类型数据源'});
                return false;
            }
            html = '<div class="block_source"> \
                        <span class="block_source_title">第三方文件源</span> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><font color="red">*</font>路径</label> \
                            <div class="col-sm-4"> \
                                <input type="text" class="form-control" id="input_file_path" placeholder="请填写路径,多个路径用逗号分隔"> \
                            </div> \
                        </div> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><font color="red">*</font>类型</label> \
                            <div class="col-sm-4"> \
                                <input type="text" class="form-control" id="input_file_type" placeholder="请填写类型"> \
                            </div> \
                        </div> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><font color="red">*</font>主键</label> \
                            <div class="col-sm-2"> \
                                <input type="text" class="form-control pk" id="input_kg_file_name" placeholder="请填写主键名称"> \
                            </div> \
                            <div class="col-sm-8"> \
                                <input type="text" class="form-control" id="input_kg_file_path" placeholder="请填写主键key"> \
                            </div> \
                        </div> \
                        <div class="form-group attr_line"> \
                            <label class="col-sm-1 control-label">属性</label> \
                            <div class="col-sm-2"> \
                                <input type="text" class="form-control" class="input_file_attr_name" placeholder="请填写属性名"> \
                            </div> \
                            <div class="col-sm-8"> \
                                <input type="text" class="form-control" class="input_file_attr_path" placeholder="请填写属性key"> \
                            </div> \
                            <div class="col-sm-1"> \
                                <span class="glyphicon glyphicon-remove attr_remove" aria-hidden="true"></span> \
                            </div> \
                        </div> \
                        <div class="form-group"> \
                            <label class="col-sm-1 control-label"><span class="glyphicon glyphicon-plus btn_add_attr" onclick="add_attr(this)" aria-hidden="true"></span></label> \
                        </div> \
                        <span class="glyphicon glyphicon-remove block_source_remove" aria-hidden="true"></span> \
                    </div>';
        }
        $(this).parents('.form-group').before(html);
        sync_pk_relate();
    });
}
function upsert_task()
{
    var cur_step = $("#task_step_wizard").data('scrollable').getIndex();
    var task_name = $("#input_task_name").val().trim();
    var url = (cur_step > 1 || task_id) ? '/interest_graphs/tools/keywords/update_keywords_tools/' : '/interest_graphs/tools/keywords/create_keywords_tools/';
    var post_data = {}; 
    task_id ? post_data.task_id = task_id : '';
    if(cur_step == 1)
    {
        post_data.task_name = task_name;
        var config = [];
        $(".block_source").each(function(){
            var item = {attr_list:[]};
            if($(this).find("#input_kg_type").length > 0)
            {
                item.type = 'tupu';
                item.key_type = $(this).find("#input_kg_type").val().trim();
                item.key = $(this).find("#input_kg_pk_name").val().trim();
                item.tupu_path = $(this).find("#input_kg_pk_path").val().trim();
                $(this).find('.attr_line').each(function(){
                    item.attr_list.push({name:$(this).find('input:eq(0)').val().trim(), tupu_path:$(this).find('input:eq(1)').val().trim()});
                });
            }
            else if($(this).find("#input_baike_condition").length > 0)
            {
                item.type = 'baike';
                item.filter_rule = $(this).find("#input_baike_condition").val().trim();
                item.key = $(this).find("#input_kg_baike_name").val().trim();
                item.field = $(this).find("#input_kg_baike_path").val().trim();
                item.join_tupu = $(this).find("#use_baike_url").is(':checked') ? true : false;
                $(this).find('.attr_line').each(function(){
                    item.attr_list.push({name:$(this).find('input:eq(0)').val().trim(), field:$(this).find('input:eq(1)').val().trim()});
                });
            }
            else if($(this).find("#input_file_path").length > 0)
            {
                item.type = 'local';
                item.key = $(this).find("#input_kg_file_name").val().trim();
                item.key_type = $(this).find("#input_file_type").val().trim();
                item.field = $(this).find("#input_kg_file_path").val().trim();
                item.path = $(this).find("#input_file_path").val().trim();
                $(this).find('.attr_line').each(function(){
                    item.attr_list.push({name:$(this).find('input:eq(0)').val().trim(), field:$(this).find('input:eq(1)').val().trim()});
                });
            }
            config.push(item);
        });
        post_data.config = JSON.stringify(config);
        var out_schema_arr = $("#output_attrs").val();
        if(out_schema_arr)
        {
            post_data.output_schema = out_schema_arr.join(',');
        }
    }
    else
    {
        if($("#conf_pv").is(':hidden'))
        {
            post_data.has_alias_task = 0;
        }
        else
        {
            post_data.has_alias_task = 1;
            post_data.pv = $("#conf_pv").val().trim();
        }
        post_data.compute_config = $("#calcu_params").val().trim();
    }
    result = makeAPost(url, post_data);
    if(result.status != 0)
    {
        ark_notify(result);
        $("#task_step_wizard").data('scrollable').move(-1);
        return false;
    }
    task_id ? '' : task_id = result.keywords_id;
    if(cur_step > 1)
    {
        show_calculating_info();
    }
}
function show_calculating_info()
{
    do_show_calculating_info();
    interval_get_task_calculate_run_status = setInterval(do_show_calculating_info, 30000);
}
function do_show_calculating_info()
{
    var url = '/interest_graphs/tools/keywords/get_task_run_status/';
    var post_data = {task_id:task_id};
    var args = {};
    var callback = callback_do_show_calculating_info;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_show_calculating_info(result, args)
{
    if(result.run_status == 0)//成功
    {
        calculate_task_running = false;
        $("#task_step_wizard .page:eq(2) .btn_nav").show();
        clearInterval(interval_get_task_calculate_run_status);
        auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
        var calculating_html = '<div class="run_success">\
                                   <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>\
                                   <span class="success_text">计算完成!</span>\
                               </div>\
                               <div>计算开始时间'+result.start_time+' ，耗时'+result.use_time+'秒。<a target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a></div>\
                               <div>\
                                   <p>关键词结果如下：</p>\
                               </div>';
        $('#calculating').html(calculating_html);
        get_publish_status();
        if(!interval_get_get_publish_status)
        {
            interval_get_get_publish_status = setInterval(get_publish_status, 30000);
        }
        calculate_result_preview();
 
    }
    else if(result.run_status == 1)//失败
    {
        calculate_task_running = false;
        $("#task_step_wizard .page:eq(3) .btn_nav").hide();
        clearInterval(interval_get_task_calculate_run_status);
        auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
        var calculating_html = '<div class="run_error">\
                                   <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>\
                                   <span class="error_text">哎呀，运行失败了，试试重新配置条件再重试吧</span>\
                               </div>\
                               <div>\
                                <a target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a>\
                               </div>\
                               <div class="run_error_op">\
                                   <button type="button" onclick="rerun_calculate()" class="btn btn-default" style="margin-right:20px;">重试</button>\
                                   <button type="button" onclick="go_back_caclulate()" class="btn btn-primary interest_graphs_btn_primary">返回</button>\
                               </div>';
        $('#calculating').html(calculating_html);
    }
    else//执行中
    {
        calculate_task_running = true;
        if(!auto_incre_run_time)
        {
            $("#task_step_wizard .page:eq(3) .btn_nav").hide();
            //$("#task_step_wizard .page:eq(3) .btn_nav").show();
            var collecting_html = '<span class="calculating_text">正在计算中，请耐心等待！</span>\
                                   <img alt="计算中" class="calculating_img" draggable="false" src="/static/images/interest_graphs/collecting.gif"></img>\
                                   <div>\
                                        <a target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a>\
                                   </div>\
                                   <div class="calculating_expired">\
                                       <span class="calculating_expired_tip">已运行</span>\
                                       <span class="calculating_expired_time"><font style="font-size:27px;">'+result.use_time+'</font>秒</span>\
                                   </div>';
            $('#calculating').html(collecting_html);
            auto_incre_run_time = setInterval(function(){
                $(".calculating_expired_time font").html(parseInt($(".calculating_expired_time font").html())+1);
            }, 1000);
        }
    }
}
function fill_content()
{
    var url = '/interest_graphs/tools/keywords/get_keywords_detail/';
    var post_data = {id:task_id};
    var callback = callback_do_fill_content;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_fill_content(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    $("#input_task_name").val(result.task_name);
    var config = JSON.parse(result.config);
    for(var i in config)
    {
        if(config[i].type == 'tupu')
        {
            $("#select_add_source").val('1');
            $("#select_add_source").trigger('change');
            var cur_block = $(".block_source:last");
            cur_block.find("#input_kg_type").val(config[i].key_type);
            cur_block.find("#input_kg_pk_name").val(config[i].key);
            cur_block.find("#input_kg_pk_path").val(config[i].tupu_path);
            for(var j=1; j<config[i].attr_list.length; j++)
            {
                cur_block.find(".btn_add_attr").trigger('click');
            }
            for(var j=0; j<config[i].attr_list.length; j++)
            {
                cur_block.find(".attr_line:eq("+j+") input:eq(0)").val(config[i].attr_list[j].name);
                cur_block.find(".attr_line:eq("+j+") input:eq(1)").val(config[i].attr_list[j].tupu_path);
            }
        }
        else if(config[i].type == 'baike')
        {
            $("#select_add_source").val('2');
            $("#select_add_source").trigger('change');
            var cur_block = $(".block_source:last");
            cur_block.find("#input_baike_condition").val(config[i].filter_rule);
            cur_block.find("#input_kg_baike_path").val(config[i].field);
            cur_block.find("#input_kg_baike_name").val(config[i].key);
            cur_block.find("#use_baike_url").prop('checked', config[i].join_tupu ? true : false);
            for(var j=1; j<config[i].attr_list.length; j++)
            {
                cur_block.find(".btn_add_attr").trigger('click');
            }
            for(var j=0; j<config[i].attr_list.length; j++)
            {
                cur_block.find(".attr_line:eq("+j+") input:eq(0)").val(config[i].attr_list[j].name);
                cur_block.find(".attr_line:eq("+j+") input:eq(1)").val(config[i].attr_list[j].field);
            }
        }
        else if(config[i].type == 'local')
        {
            $("#select_add_source").val('3');
            $("#select_add_source").trigger('change');
            var cur_block = $(".block_source:last");
            cur_block.find("#input_file_type").val(config[i].key_type);
            cur_block.find("#input_kg_file_name").val(config[i].key);
            cur_block.find("#input_kg_file_path").val(config[i].field);
            cur_block.find("#input_file_path").val(config[i].path);
            for(var j=1; j<config[i].attr_list.length; j++)
            {
                cur_block.find(".btn_add_attr").trigger('click');
            }
            for(var j=0; j<config[i].attr_list.length; j++)
            {
                cur_block.find(".attr_line:eq("+j+") input:eq(0)").val(config[i].attr_list[j].name);
                cur_block.find(".attr_line:eq("+j+") input:eq(1)").val(config[i].attr_list[j].field);
            }
        }
    }
    refresh_output(result.output_schema.split(','));
    $("#calcu_params").val(result.kv_config);
    if(result.has_alias_task)
    {
        $("#btn_alias_conf").trigger('click');
        $("#conf_pv").val(result.pv);
    }
    //$("#publishModal #dict_name_select2").val(result.dict_name);
    //$("#publishModal #dict_name_select2").attr('action-data', JSON.stringify({id:result.dict_name, text:result.dict_name}));
    auto_seek = true;
    if(result.run_status == 101)//未执行
    {
        $("#task_step_wizard").data('scrollable').seekTo(0);
    }
    else
    {
        $("#task_step_wizard").data('scrollable').seekTo(2);
        show_calculating_info();
    }
}
function rerun_calculate()
{
    upsert_task();
}
function go_back_caclulate()
{
    $("#task_step_wizard").data('scrollable').seekTo(1);
}
function load_more_calculate_res()
{
    calculate_res_page += 1;
    if(table_calculate_res)
    {
        table_calculate_res.ajax.reload();
    }
    else
    {
        table_calculate_res = $('#res_table_calculate').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": "/interest_graphs/tools/keywords/get_keywords_merge_result/",
                "type": "POST",
                "data":function(d){
                    d.task_id = task_id;
                    d.page = calculate_res_page;
                    d.page_size = calculate_res_page_size;
                },
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0 || json.data_list == undefined || json.data_list.length == 0)
                    {
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        json.data = json.data_list;
                        json.recordsTotal = json.all_num;
                        json.recordsFiltered = json.all_num;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "paginate":false,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
            },
            columns: calculate_params.headers,
        });
    }
}
function calculate_result_preview()
{
    var url = '/interest_graphs/tools/keywords/get_keywords_merge_result/';
    var post_data = {task_id:task_id};
    var callback = callback_calculate_result_preview;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_calculate_result_preview(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    if(result.header == undefined || result.header.length == 0)
    {
        ark_notify({status:1, msg:'暂无数据'});
        return;
    }
    table_calculate_res = null;
    calculate_params = {headers:[]};
    var html = '<div id="calculate_res_div">';
    html += '<table class="table table-hover table-bordered" id="res_table_calculate" style="table-layout: fixed;" cellspacing="0" width="100%">\
                    <thead><tr>';
    for(var i in result.header)
    {
        html += '<th>'+result.header[i]+'</th>';
        calculate_params.headers.push({data: i,bSortable: false});
    }
    html += '</tr></thead><tbody></tbody></table>';
    html += '<button type="button" onclick="load_more_calculate_res()" class="btn btn-default">换一批</button>';
    html += '</div>';
    $("#calculating").append(html);

    load_more_calculate_res();
}
function publish_to_dict()
{
    $("#publishModal").modal('show');
}
function do_publish_dict()
{
    $("#publishModal #btn_do_publish_dict").button('loading');
    var url = '/interest_graphs/tools/keywords/add_keywords_to_tag/';
    var post_data = {task_id:task_id, dict_config:''};
    var dict_config = [];
    $("#publishModal form .form-group").each(function(){
        var str = $(this).find('label').html()+':';
        if($(this).find('.publish_type_select2').val() == 1)
        {
            str += $(this).find('input.dict_name_select2').val();
        }
        dict_config.push(str);
    });
    post_data.dict_config = dict_config.join(',');
    var args = {};
    var callback = callback_do_publish_dict;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_publish_dict(result, args)
{
    $("#publishModal #btn_do_publish_dict").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#publishModal").modal('hide');
        get_publish_status();
        if(!interval_get_get_publish_status)
        {
            interval_get_get_publish_status = setInterval(get_publish_status, 30000);
        }
    }
}
function get_publish_status()
{
    var url = '/interest_graphs/tools/keywords/get_keywords_to_tag_status/';
    var post_data = {task_id:task_id};
    var args = {};
    var callback = callback_get_publish_status;
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_publish_status(result, args)
{
    if(result.status == 0)
    {
        $("#btn_publish_to_dict").nextAll().remove();
        if(result.run_status == 0)//成功
        {
            interval_get_get_publish_status ? clearInterval(interval_get_get_publish_status) : '';
            interval_get_get_publish_status = null;
            if($("#btn_cancel_publish_to_dict").length == 0)
            {
                $("#btn_publish_to_dict").before('<button type="button" id="btn_cancel_publish_to_dict" onclick="cancel_publish_to_dict()" class="btn btn-primary interest_graphs_btn_primary">取消发布</button>');
            }
            $("#btn_publish_to_dict").html('发布配置');
            $("#btn_publish_to_dict").after('<span class="glyphicon glyphicon-ok" aria-hidden="true" style="color:green;"></span><span>已发布</span>');
        }
        else if(result.run_status == 1)//失败
        {
            interval_get_get_publish_status ? clearInterval(interval_get_get_publish_status) : '';
            interval_get_get_publish_status = null;
            $("#btn_publish_to_dict").after('<span class="glyphicon glyphicon-remove" aria-hidden="true" style="color:red;"></span><span>发布失败</span>');
        }
        else if(result.run_status == 2)//执行中
        {
            $("#btn_publish_to_dict").after('<span>发布中...</span>');
        }
        else//未执行
        {
            interval_get_get_publish_status ? clearInterval(interval_get_get_publish_status) : '';
            interval_get_get_publish_status = null;
        }
    }
}
function cancel_publish_to_dict()
{
    $("#cancelPublishModal").modal('show');
}
function do_cancel_publish_dict()
{
    $("#btn_do_cancel_publish_dict").button('loading');
    var url = '/interest_graphs/tools/keywords/delete_keywords_to_tag/';
    var post_data = {task_id:task_id};
    var args = {};
    var callback = callback_do_cancel_publish_dict;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_cancel_publish_dict(result, args)
{
    ark_notify(result);
    $("#btn_do_cancel_publish_dict").button('reset');
    if(result.status == 0)
    {
        $("#cancelPublishModal").modal('hide');
        $("#btn_cancel_publish_to_dict").remove();
        $("#btn_publish_to_dict").html('发布到词典');
        $("#btn_publish_to_dict").nextAll().remove();
    }
}
function add_attr(obj)
{
    var html = '<div class="form-group attr_line"> \
                    <label class="col-sm-1 control-label">属性</label> \
                    <div class="col-sm-2"> \
                        <input type="text" class="form-control" class="input_file_attr_name" placeholder="请填写属性名"> \
                    </div> \
                    <div class="col-sm-8"> \
                        <input type="text" class="form-control" class="input_file_attr_path" placeholder="请填写属性key"> \
                    </div> \
                    <div class="col-sm-1"> \
                        <span class="glyphicon glyphicon-remove attr_remove" aria-hidden="true"></span> \
                    </div> \
                </div>';
     $(obj).parents(".form-group").before(html);
}
function alias_conf(obj)
{
    if($("#conf_pv").is(':hidden'))
    {
        $("#conf_pv").show();
        $(obj).attr('src', '/static/images/interest_graphs/open-icon.png');
    }
    else
    {
        $("#conf_pv").hide();
        $(obj).attr('src', '/static/images/interest_graphs/close-icon.png');
    }
}
function refresh_output(selected_arr)
{
    var pk = '';
    if($(".pk:eq(0)").length > 0)
    {
        pk = $(".pk:eq(0)").val().trim();
    }
    var attrs = [];
    $(".attr_line").each(function(){
        var attr = $(this).find('input:eq(0)').val().trim();
        if(attr)
        {
            attrs.push(attr);
        }
    });
    $("#output_attrs").empty();
    if(pk)
    {
        $("#output_attrs").append('<option selected value="'+pk+'">'+pk+'</option>');
    }
    for(var i in attrs)
    {
        var str = 'selected';
        if(selected_arr != undefined && selected_arr.indexOf(attrs[i]) < 0)
        {
            str = '';
        }
        $("#output_attrs").append('<option '+str+' value="'+attrs[i]+'">'+attrs[i]+'</option>');
    }
    $("#output_attrs").select2();
    if(pk)
    {
        $(".select2-container-multi .select2-choices .select2-search-choice").eq(0).css('background-color', '#ccc');
        $(".select2-container-multi .select2-choices .select2-search-choice a").eq(0).off('click');
        $(".select2-container-multi .select2-choices .select2-search-choice a").eq(0).off('dblclick');
        $(".select2-container-multi .select2-choices .select2-search-choice a").eq(0).css('background', 'url(\'/static/images/interest_graphs/pk.png\') right top no-repeat');
    }
}
function sync_pk_relate()
{
    $('.pk:eq(0)').prop('disabled', false);
    $('.pk:gt(0)').prop('disabled', true);
    $(".pk").val($(".pk:eq(0)").val());
}
