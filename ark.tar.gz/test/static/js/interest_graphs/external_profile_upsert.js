var odps_table_list = '';
var table_odps_table_schema = '';
var detail = null;
$(function(){
    if($("#external_profile_detail").val())
    {
        detail = JSON.parse($("#external_profile_detail").val())
    }
    $("#table_name").on('change', function(){
        flush_odps_table_schema();
    });
    if(detail)
    {
        $("#name").val(detail.name);
        $("#table_name").val(detail.table_name);
        $("#table_name").prop('disabled', true);
        $("#desc").val(detail.desc);
        recovery_schema();
    }
    else
    {
        init_odps_table_list();
    }
    $(document).on('change', '#table_odps_schema .checkbox_is_main', function(){
        console.log($(this).val());
        $(this).parents('tbody').find(".main_col_icon").hide();
        $(this).parents('td').find(".main_col_icon").show();
    });
});
function init_odps_table_list()
{
    odps_table_list = $("#table_name").select2({
        placeholder: '请输入odps表名称',
        multiple: false,
        ajax: {
            url: '/interest_graphs/tag/show_odps_tables/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                match_str: term,
                page: page,
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.table_list)
                    {
                        ret.push({id:data.table_list[i], text:data.table_list[i]});
                    }
                }
                return {
                  results: ret
                };
            }
        },
        language: 'ch',
    }).on('select2-open', function(e) {
        var input = $(".select2-drop.select2-display-none.select2-with-searchbox.select2-drop-active input");
        input.val($(this).val());
    });
}
function flush_odps_table_schema()
{
    if(table_odps_table_schema)
    {
        table_odps_table_schema.ajax.reload();
    }
    else
    {
        table_odps_table_schema = $('#table_odps_schema').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": "/interest_graphs/tag/show_odps_table_schema/",
                "type": "POST",
                "data":function(d){
                    d.table_name = $("#table_name").val().trim();
                },
            },
            //"pageLength":10,
            "paginate":false,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
                //"paginate":{
                //    'next':'下一页',
                //    'previous':'上一页',
                //},
            },
            "fnDrawCallback":function(){
                $("#table_odps_schema tbody tr").each(function(){
                    $(this).find('td:first').on('mouseover', function(){
                        $(this).find('.checkbox_is_main').show();
                        $(this).find('.col_table_name').css('padding-right', '100px');
                    });
                    $(this).find('td:first').on('mouseleave', function(){
                        $("#table_odps_schema tbody").find('.checkbox_is_main:visible').hide();
                        $(this).find('.col_table_name').css('padding-right', '0');
                    });
                });
                $('#table_odps_schema .checkbox_is_main [name="radio_main_col"]:eq(0)').prop('checked', true);
                $('#table_odps_schema .checkbox_is_main [name="radio_main_col"]:eq(0)').trigger('change');
            },
            columns: [
            {
                data: "field_name",
                bSortable: false
            }, {
                data: "desc",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[0],
                    "render":function(data,type,full){
                        return '<img class="main_col_icon" src="/static/images/interest_graphs/main_col_icon.png"></img><label style="display:none;" class="radio-inline checkbox_is_main"><input type="radio" name="radio_main_col" value="'+data+'">设为用户列</label>' + '<span class="col_table_name">'+data +'</span>';
                    },
                },
                {
                    "targets":[1],
                    "render":function(data,type,full){
                        return data;
                    },
                }]
        });
    }
}
function get_post_data()
{
    var ret = {};
    ret.name = $("#name").val().trim();
    ret.table_name = $("#table_name").val().trim();
    ret.desc = $("#desc").val().trim();
    ret.schema = [];
    $('#table_odps_schema tbody tr').each(function(){
        ret.schema.push({
            pk:$(this).find(".main_col_icon").is(':hidden') ? 0 : 1,
            name:$(this).find('.col_table_name').text().trim(),
            desc:$(this).find('td:eq(1)').text().trim(),
        });
    });
    ret.schema = JSON.stringify(ret.schema);

    return ret;
}
function do_add_external_profile()
{
    $("#btn_do_add_external_profile").button('loading');
    var url = '/interest_graphs/tag/external_profile_add/';
    var post_data = get_post_data();
    var callback = callback_do_add_external_profile;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_external_profile(result, args)
{
    $("#btn_do_add_external_profile").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        location.href = '/interest_graphs/tag/external_profile_index/';
    }
 
}
function do_update_external_profile()
{
    $("#btn_do_update_external_profile").button('loading');
    var url = '/interest_graphs/tag/external_profile_update/';
    var post_data = get_post_data();
    post_data.id = detail.id;
    var callback = callback_do_update_external_profile;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_update_external_profile(result, args)
{
    $("#btn_do_update_external_profile").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        location.href = '/interest_graphs/tag/external_profile_index/';
    }
}
function recovery_schema()
{
    for(var i in detail.schema)
    {
        $("#table_odps_schema tbody").append('<tr role="row" class="odd">\
                                                  <td>\
                                                    <img class="main_col_icon" '+(detail.schema[i].pk ? 'style="display:inline"' : '')+' src="/static/images/interest_graphs/main_col_icon.png">\
                                                    <label class="radio-inline checkbox_is_main">\
                                                        <input type="radio" name="radio_main_col" '+(detail.schema[i].pk ? 'checked' : '')+' value="product">设为用户列\
                                                    </label>\
                                                    <span class="col_table_name" style="padding-right: 0px;">'+detail.schema[i].name+'</span>\
                                                    </td>\
                                                    <td>'+detail.schema[i].desc+'</td></tr>');
    }
    $("#table_odps_schema tbody tr").each(function(){
        $(this).find('td:first').on('mouseover', function(){
            $(this).find('.checkbox_is_main').show();
            $(this).find('.col_table_name').css('padding-right', '100px');
        });
        $(this).find('td:first').on('mouseleave', function(){
            $("#table_odps_schema tbody").find('.checkbox_is_main:visible').hide();
            $(this).find('.col_table_name').css('padding-right', '0');
        });
    });
    $('#table_odps_schema .checkbox_is_main [name="radio_main_col"]:eq(0)').prop('checked', true);
    $('#table_odps_schema .checkbox_is_main [name="radio_main_col"]:eq(0)').trigger('change');
}
function delete_external_profile()
{
    $("#deleteDataModal").modal('show');
}
function do_delete_external_profile()
{
    $("#deleteDataModal #btn_delete_external_profile").button('loading');
    var url = '/interest_graphs/tag/external_profile_delete/';
    var post_data = {id:detail.id};
    var callback = callback_do_delete_external_profile;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_external_profile(result, args)
{
    $("#deleteDataModal #btn_delete_external_profile").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        location.href = '/interest_graphs/tag/external_profile_index/';
    }
 
}
function manual_flush_odps_table_schema()
{
    if($("#table_name").val().trim())
    {
        flush_odps_table_schema();
    }
}
