var table_dict_list = null;
var dict_id_preview = '';
$(function(){
    init_dict_group_list();
    $(document).on('click', '#left_dict_group_list .dict_group_item .group_value', function(){
        if(!$(this).parent().hasClass('active'))
        {
            $('#left_dict_group_list .dict_group_item').removeClass('active');
            $(this).parent().addClass('active');
            flush_dict_list_table();
        }
    });
    $(document).on('mouseover', '#left_dict_group_list .dict_group_item .group_value', function(){
        $(this).nextAll('.glyphicon').show();
    });
    $(document).on('mouseleave', '#left_dict_group_list .dict_group_item', function(){
        $(this).find('.glyphicon').hide();
    });
    $('body').scroll(function(){
        $("#dict_container #table_title").css('top', ($('#table_dict_list_wrapper').position().top).toString()+'px');
    });
});
function flush_dict_list_table()
{
    if(table_dict_list)
    {
        table_dict_list.ajax.reload();
    }
    else
    {
        init_table();
    }
}
function init_dict_group_list()
{
    var url = '/interest_graphs/tag/dict/dict_group_list/';
    var post_data = {};
    var callback = callback_init_dict_group_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_init_dict_group_list(result, args)
{
    if(result.status ==0)
    {
        $("#left_dict_group_list ul").empty();
        for(var i in result.data)
        {
            var html = '<li class="dict_group_item" action-data="'+result.data[i].id+'"><span class="group_value">'+result.data[i].name+'</span>';
            if(result.data[i].id)
            {
                html += '<span class="glyphicon glyphicon-remove" title="删除" onclick="delete_dict_group(this)" aria-hidden="true"></span><span class="glyphicon glyphicon-pencil" title="修改" onclick="edit_dict_group(this)" aria-hidden="true"></span></li>';
            }
            $("#left_dict_group_list ul").append(html);
        }
        $("#left_dict_group_list ul").append('<li class="add_group" onclick="add_dict_group()"><span style="text-align: center;display: inline-block;"><img src="/static/images/interest_graphs/add_group.png"></img>新建分组</span></li>');
        $("#left_dict_group_list ul li:first .group_value").trigger('click');
    }
}
function add_dict_group()
{
    $("#addDictGroupModal #input_group_name").val('');
    $("#addDictGroupModal").modal('show');
}
function do_add_dict_group()
{
    $("#addDictGroupModal #btn_do_add_dict_group_ok").button('loading');
    var url = '/interest_graphs/tag/dict/create_dict_group/';
    var post_data = {name:$("#addDictGroupModal #input_group_name").val().trim()};
    var callback = callback_create_dict_group;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_create_dict_group(result, args)
{
    $("#addDictGroupModal #btn_do_add_dict_group_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#addDictGroupModal").modal('hide');
        init_dict_group_list();
    }
}

function add_dict()
{
    $("#addDictModal #name").val('');
    $("#addDictModal [name='dict_type']").eq(0).prop('checked', true)
    var cur_dict_group = $('#left_dict_group_list .dict_group_item.active').attr('action-data');
    $("#addDictModal #input_set_group_name").val(cur_dict_group);
    $("#addDictModal #input_set_group_name").attr('action-data', JSON.stringify({id:cur_dict_group,text:cur_dict_group ? $('#left_dict_group_list .dict_group_item.active').text() : '默认分组'}));
    init_set_group_select2();
    $("#addDictModal #desc").val('');
    $("#addDictModal").modal('show');
}
function do_add_dict()
{
    $("#addDictModal #btn_do_add_dict_ok").button('loading');
    var url = '/interest_graphs/tag/dict/create/';
    var post_data = {};
    post_data['name'] = $("#addDictModal #name").val().trim();
    post_data['type'] = $("#addDictModal [name='dict_type']:checked").val();
    var group_id = $("#addDictModal #input_set_group_name").val();
    group_id != 0 ? post_data['group_id'] = group_id : '';
    post_data['desc'] = $("#addDictModal #desc").val().trim();
    var callback = callback_do_add_dict;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_dict(result, args)
{
    $("#addDictModal #btn_do_add_dict_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#addDictModal").modal('hide');
        //刷新词典列表
        //table_dict_list.ajax.reload();
        location.href = '/interest_graphs/tag/dict/detail_index/?id='+result.data;
    }
}
function init_table()
{
    table_dict_list = $('#table_dict_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": true,
        "ajax": {
            "url": "/interest_graphs/tag/dict/list/",
            "type": "POST",
            "data":function(d){
                d.group_id= $('#left_dict_group_list .dict_group_item.active').attr('action-data');
            },
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        "fnDrawCallback":function(){
            //$('.popover_entity').popover(option_popover); 
            var left_height = $("#left_dict_group_list").height()+50;
            var right_height = $("#right_dict_list").height();
            if(left_height > right_height)
            {
                $("#right_dict_list").css('min-height', left_height);
            }
            $('.popover_entity').mouseover(function(){
                //$(this).trigger('click')
                var dict_id_preview = $(this).attr('action-data');
                var dict_preview_table_id = 'popover_table_'+dict_id_preview;
                var option_popover = {
                    html:true,
//                    container: 'body',
                    placement:'right',
                    template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content" style="height:143px;"></div></div>',
                    title:'词典预览',
                    selector:'.popover_entity',
                    content:'<table style="table-layout: fixed;" class="table table-bordered" id="'+dict_preview_table_id+'"><tbody><tr><td>加载中...</td></tr></tbody></table>',
                    trigger:'click'
                };
                $(this).popover(option_popover);
                $(this).popover('show');
                //获取预览数据
                var url = '/interest_graphs/tag/dict/get_dict_preview/';
                var post_data = {id:dict_id_preview};
                var callback = callback_show_dict_id_preview;
                var args = {table_id:dict_preview_table_id};
                makeAPost(url, post_data, true, callback, args);
            });
            $('.popover_entity').parent().on('mouseleave', function(){
                $(this).find('.popover').popover('hide');
            });
        },
        columns: [
        {
            data: "name",
            bSortable: false
        }, {
            data: "type",
            bSortable: false
        }, {
            data: "size",
            bSortable: false
        }, {
            data: "owner",
            bSortable: false
        }, {
            data: "update_time",
            bSortable: false
        }, {
            data: "desc",
            bSortable: false
        }],
                
        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    return '<a action-data="'+full.id+'" href="/interest_graphs/tag/dict/detail_index/?id='+full.id+'" class="popover_entity">'+data+'</a>';
                },
            },
            {
                "targets":[1],
                "render":function(data,type,full){
                    return data == 0 ? '实体词典' : '主题词典';
                },
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    return data;
                 }
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    return data == '' ? '暂无' : ('<span title="'+data+'">'+data+'</span>');
                },
            },
            {
                "targets":[6],
                "render":function(data,type,full){
                    var ret = '<a href="/interest_graphs/tag/dict/config/?id='+full.id+'">编辑</a> | <a href="javascript:" onclick="delete_dict('+full.id+')">删除</a> | <a href="javascript:" onclick="move_dict('+full.id+', '+full.group_id+', \''+full.group_name+'\')">移动</a>';
                    return ret;
                },
            },
        ]

    });

}
function move_dict(dict_id, group_id, group_name)
{
    $("#moveDictModal #btn_do_move_dict_group_ok").attr('onclick', 'do_move_dict_group('+dict_id+')');
    $("#moveDictModal #input_move_group_name").val(group_id);
    $("#moveDictModal #input_move_group_name").attr('action-data', JSON.stringify({id:group_id,text:group_name}));
    init_move_group_select2(group_id);
    $("#moveDictModal").modal('show');
}
function do_move_dict_group(dict_id)
{
    $("#moveDictModal #btn_do_move_dict_group_ok").button('loading');
    var group_id = $("#moveDictModal #input_move_group_name").val();
    var post_data = {dict_id:dict_id}
    if(group_id)
    {
        post_data['group_id'] = group_id;
    }
    var url = '/interest_graphs/tag/dict/move_dict_group/';
    var callback = callback_move_dict_group;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_move_dict_group(result, args)
{
    $("#moveDictModal #btn_do_move_dict_group_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#moveDictModal").modal('hide');
        flush_dict_list_table();
    }
}
function delete_dict(dict_id)
{
    $('#deleteDictConfirmModal #btn_do_delete_dict_ok').attr('onclick', 'do_delete_dict('+dict_id+')');
    $("#deleteDictConfirmModal").modal('show');
}
function do_delete_dict(dict_id)
{
    $('#deleteDictConfirmModal #btn_do_delete_dict_ok').button('loading');
    var url = '/interest_graphs/tag/dict/delete_dict/';
    var post_data = {dict_id:dict_id};
    var callback = callback_do_delete_dict;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_dict(result, args)
{
    $('#deleteDictConfirmModal #btn_do_delete_dict_ok').button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteDictConfirmModal").modal('hide');
        //刷新词典列表
        table_dict_list.ajax.reload();
    }
}
function callback_show_dict_id_preview(result, args)
{
    var cols_num = 4;
    var table_id = args['table_id'];
    var html = '';
    if(result.status != 0)
    {
        html = '预览失败';
    }
    else
    {
        if(result.data.length < 1)
        {
            html = '无词典数据';
        }
        else if(result.data.length < cols_num)
        {
            html += '<tr>';
            for(var k in result.data)
            {
                html += '<td>'+result.data[k][1]+'"\</td>';
            }
            html += '</tr>';
        }
        else
        {
            for(var i=0; i<Math.ceil(result.data.length/cols_num); i++)
            {
                html += '<tr>';
                for(var j=0; j<cols_num; j++)
                {
                    html += '<td>'+(result.data[i*cols_num+j] == undefined ? '' : result.data[i*cols_num+j])+'</td>';
                }
                html += '</tr>';
            }
        }
    }
    $("#"+table_id+" tbody").html(html);
}
function init_move_group_select2(group_id)
{
    $("#moveDictModal #input_move_group_name").select2({
                placeholder: '请输入分组名称',
                ajax: {
                    url: '/interest_graphs/tag/dict/dict_group_list/', 
                    type:'POST',
                    dataType: 'json',
                    data: function (term, page) {
                      var query = {
                        'search[value]': term,
                      }
                      return query;
                    },
                    results: function (data) {
                        var ret = [];
                        if(data.status ==0)
                        {
                            for(var i in data.data)
                            {
                                ret.push({id:data.data[i].id, text:data.data[i].name});
                            }
                        }
                        return {
                          results: ret
                        };
                    }
                },
                language: 'ch',
                initSelection: function (element, callback) {
                    //var data = [{id: element.val(), text: element.val()}];
                    var attr = JSON.parse(element.attr('action-data'));
                    var data = attr;
                    //for(var i in attr)
                    //{
                    //    data.push();
                    //}
                    //callback([{id: element.val(), text: element.val()}]);//这里初始化
                    callback(attr);//这里初始化
                },
            });
}
function init_set_group_select2()
{
    $("#addDictModal #input_set_group_name").select2({
                placeholder: '请输入分组名称',
                ajax: {
                    url: '/interest_graphs/tag/dict/dict_group_list/', 
                    type:'POST',
                    dataType: 'json',
                    data: function (term, page) {
                      var query = {
                        'query': term,
                      }
                      return query;
                    },
                    results: function (data) {
                        var ret = [];
                        if(data.status ==0)
                        {
                            for(var i in data.data)
                            {
                                ret.push({id:data.data[i].id, text:data.data[i].name});
                            }
                        }
                        return {
                          results: ret
                        };
                    }
                },
                language: 'ch',
                initSelection: function (element, callback) {
                    var attr = JSON.parse(element.attr('action-data'));
                    var data = attr;
                    callback(attr);//这里初始化
                },
            });
}
function edit_dict_group(obj)
{
    var group_id = $(obj).parents(".dict_group_item").attr('action-data');
    var group_name = $(obj).parents(".dict_group_item").find('.group_value').text();
    $("#editDictGroupModal #input_edit_group_id").val(group_id);
    $("#editDictGroupModal #input_edit_group_name").val(group_name);
    $("#editDictGroupModal").modal('show');
}
function do_edit_dict_group()
{
    $("#editDictGroupModal #btn_do_edit_dict_group_ok").button('loading');
    var group_id = $("#editDictGroupModal #input_edit_group_id").val();
    var group_name = $("#editDictGroupModal #input_edit_group_name").val().trim();
    var url = '/interest_graphs/tag/dict/update_dict_group/';
    var post_data = {id:group_id, name:group_name};
    var callback = callback_update_dict_group;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_update_dict_group(result, args)
{
    $("#editDictGroupModal #btn_do_edit_dict_group_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#editDictGroupModal").modal('hide');
        init_dict_group_list();
    }
}
function delete_dict_group(obj)
{
    var group_id = $(obj).parents(".dict_group_item").attr('action-data');
    $("#deleteGroupConfirmModal #input_delete_group").val(group_id);
    $("#deleteGroupConfirmModal ").modal('show');
}
function do_delete_dict_group()
{
    $("#deleteGroupConfirmModal #btn_do_delete_dict_group_ok").button('loading');
    var group_id = $("#deleteGroupConfirmModal #input_delete_group").val();
    var url = '/interest_graphs/tag/dict/delete_dict_group/';
    var post_data = {id:group_id};
    var callback = callback_delete_dict_group;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_delete_dict_group(result, args)
{
    $("#deleteGroupConfirmModal #btn_do_delete_dict_group_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteGroupConfirmModal").modal('hide');
        init_dict_group_list();
    }
}
