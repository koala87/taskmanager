var tip = $("#tip_keyword").hide();
var tipText = "";
var over = false;
var cur_scatter_ele = null;
var scatter_parents_tag = null;
var scatter_parents_tag_user = null;
var graph_basic_index = -1;
$(document).mousemove(function(e){
    if (over){
      tip.css("left", e.clientX+20).css("top", e.clientY+20);
      tip.html(tipText);
    }
});
window.GraphPie = {
        get_data : function(callback, chart_index, ele){
            var url = "/interest_graphs/users_analysis/get_sex_attr/";
            var data = {query_id:query_id};
            var args = {index: chart_index, ele:ele}
            makeAPost(url, data, true, callback, args);
        },
        get_pie_option: function(title, sub_title, legend_data, series_data) {
            var option = {
                title: {
                    text: '性别分布',
                    x: 'left',
                    textStyle: {
                        color:'#666',
                        fontSize:18,
                        fontWeight:'bold',
                    },
                    padding:[0, 0, 0, 20],
                },
                tooltip: {
                    show : true,
                },
                toolbox: {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                legend: {
                    data:[]
                },
                backgroundColor:'white',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['tooltip']['trigger'] = 'item';
            o['tooltip']['formatter'] = '{a} <br/>{b} : {c} ({d}%)';
            o['legend'] = {data: legend_data, 
                           orient : 'horizontal', 
                           left: 'center',
                           bottom: 20,
                           top: 'bottom',
                           padding: [30, 0, 0, 0],
                          };
            if(series_data.length == 0) {
                o['series'] = [{'type':'pie'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_data: function(data, index) {
            //data = [['男', 123], ['女', 77]];
            var legend_data = [];
            var dsp_data = [];
            for(var i in data) {
                if(!data[i]['sex'])
                {
                    data[i]['sex'] = '未知';
                }
                dsp_data.push(
                    {'name': data[i]['sex'], 
                     'value': data[i]['num']});
                legend_data.push(data[i]['sex']);
            }
            var series_data = [{
                name: '类型分布',
                type: 'pie',
                center: ['50%', '50%'],
                radius: [0, '50%'],
                data: dsp_data
            }];

            var title = '';
            var sub_title = '';
            var option = GraphPie.get_pie_option(
                title, sub_title, legend_data, series_data);
            //option['legend']['x'] = 20;
            //option['legend']['y'] = 0;
           
            charts_all[index].setOption(option);
            charts_all[index].hideLoading();
        },
        callback: function(result, args) {
            if(result.status != 0) {
                ark_notify(result);
                return;
            }
            if(result.data_list.length == 0)
            {
                args.ele.parentElement.style.display = 'none';
            }
            else
            {
                args.ele.parentElement.style.display = 'block';
            }
            GraphPie.display_data(result.data_list, args.index);
        },
        refresh: function(ele) {
            ele.style.height = ele.offsetWidth+'px';
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/pie',
            ], function(ec) {
                charts_cur_index += 1;
                charts_all.push(ec.init(ele, 'macarons'));
                charts_all[charts_cur_index].showLoading({effect:'whirling'});
                GraphPie.get_data(GraphPie.callback, charts_cur_index, ele);
            });
        },
}
window.GraphBar = {
        get_data : function(callback, chart_index, bar_conf){
            var url = bar_conf.url;
            var data = {query_id:query_id};
            var args = {index: chart_index, bar_conf:bar_conf}
            makeAPost(url, data, true, callback, args);
        },
        get_bar_option: function(title, sub_title, legend_data, series_data) {
            var option = {
                color:['#33c6eb'],
                title: {
                    text: title,
                    x: 'left',
                    textStyle: {
                        color:'#666',
                        fontSize:18,
                        fontWeight:'bold',
                    },
                    padding:[0, 0, 0, 20],
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
               },
                grid: {
                    containLabel: false,
                },
                toolbox: {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                calculable : true,
                xAxis : [
                    {
                        type : 'category',
                        data : [],
                        axisTick: {
                            alignWithLabel: false,
                        }
                    }
                ],
                yAxis : [
                    {
                        type : 'value',
                        show: false,
                    }
                ],
                backgroundColor:'white',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['tooltip']['trigger'] = 'axis';
            o['xAxis'] = [{    data: legend_data, 
                              type: 'category', 
                              axisLabel: {
                                rotate:-30,
                              },
                              axisTick: {
                                  alignWithLabel: true
                              },
                              //padding: [30, 0, 0, 0],
                          }];
            if(series_data.length == 0) {
                o['series'] = [{'type':'bar'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_data: function(data, index, bar_conf) {
            //data = [['a', 123], ['b', 7], ['c', 207], ['d', 107], ['e', 37]];
            var legend_data = [];
            var dsp_data = [];
            for(var i in data) {
                dsp_data.push(data[i]['num']);
                legend_data.push(data[i][bar_conf.col_label]);
            }
            var series_data = [{
                name: bar_conf.title,
                type: 'bar',
                data: dsp_data
            }];

            var title = bar_conf.title;
            var sub_title = '';
            var option = GraphBar.get_bar_option(
                title, sub_title, legend_data, series_data);

           
            charts_all[index].setOption(option);
            charts_all[index].hideLoading();
        },
        callback: function(result, args) {
            if(result.status != 0) {
                ark_notify(result);
                return;
            }
            GraphBar.display_data(result.data_list, args.index, args.bar_conf);
        },
        refresh: function(ele, url, bar_conf) {
            ele.style.height = ele.offsetWidth+'px';
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/bar',
            ], function(ec) {
                charts_cur_index += 1;
                charts_all.push(ec.init(ele, 'macarons'));
                charts_all[charts_cur_index].showLoading({effect:'whirling'});
                GraphBar.get_data(GraphBar.callback, charts_cur_index, bar_conf);
            });
        },
}
function randomData() {
    return Math.round(Math.random()*1000);
}
window.GraphMap = {
        get_data : function(callback, chart_index){
            var url = $(".block_table_op_type.active").attr('action-data') == 1 ? "/interest_graphs/users_analysis/get_all_city_attr/" : "/interest_graphs/users_analysis/get_province_attr/";
            var data = {query_id:query_id};
            var args = {index: chart_index}
            makeAPost(url, data, true, callback, args);
        },
        get_map_option: function(title, sub_title, legend_data, series_data, max) {
            option = {
                title: {
                    text: '省市分布',
                    x: 'left',
                    textStyle: {
                        color:'#666',
                        fontSize:18,
                        fontWeight:'bold',
                    },
                    padding:[0, 0, 0, 20],
                },
                tooltip: {
                    trigger: 'item'
                },
                dataRange: {
                    min: 0,
                    max: max,
                    left: 'left',
                    type: 'continuous',
                    top: 'bottom',
                    color:['#3ec7f4','#dce6ea'], 
                    text: ['高','低'],           // 文本，默认为数值文本
                    calculable: true
                },
                toolbox:  {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                backgroundColor:'white',
                series: []
            };
            var o = $.extend(true, {}, option);
            if(series_data.length == 0) {
                o['series'] = [{'type':'map'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_data: function(data, index) {
            var legend_data = [];
            var dsp_data = [];
            for(var i in data)
            {
                dsp_data.push({name:data[i].location, value:data[i].num});
            }
            var series_data = [
            {
                name: '省市分布',
                type: 'map',
                mapType: 'china',
                roam: false,
                label: {
                    normal: {
                        show: true
                    },
                    emphasis: {
                        show: true
                    }
                },
                itemStyle:{
                    normal:{
                        //areaColor:'#cfe0e6',
                        borderColor: '#fff',
                        borderWidth: 1,
                        color: '#cfe0e6',
                    },
                    emphasis:{
                        label:{
                            show:true,
                        },
                    }
                },
                data: dsp_data
            }];

            var title = '';
            var sub_title = '';
            var max_user_num = data[0] ? data[0].num : 0;
            var option = GraphMap.get_map_option(
                title, sub_title, legend_data, series_data, max_user_num);
            if($(".block_table_op_type.active").attr('action-data') == 1)
            {
                option.series[0].markPoint = {
                    effect: {type: 'bounce'},
                    symbol:'pin',
                    itemStyle:{normal:{color:'#4cc9f3', label:{textStyle:{color:'#f37327'}, show:true}}},
                    data:dsp_data,
                };
                option.series[0].geoCoord = {};
                for(var i in data)
                {
                    option.series[0].geoCoord[data[i].location] = [data[i].longitude, data[i].latitude];
                }
            }
            charts_all[index].clear();
            charts_all[index].setOption(option);
            charts_all[index].hideLoading();
        },
        callback: function(result, args) {
            if(result.status != 0) {
                ark_notify(result);
                return;
            }
            if($(".block_table_op_type.active").attr('action-data') == 1)
            {
                result.data_list = result.data_list.slice(0, 10);
            }
            GraphMap.display_data(result.data_list, args.index);
        },
        refresh: function(ele) {
            ele.style.height = ele.offsetWidth*0.5+'px';
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/map',
            ], function(ec) {
                charts_cur_index += 1;
                charts_all.push(ec.init(ele, 'macarons'));
                charts_all[charts_cur_index].showLoading({effect:'whirling'});
                GraphMap.get_data(GraphMap.callback, charts_cur_index);
            });
        },
}
window.GraphBarAggregation = {
        get_data : function(callback, chart_index, ele_arr){
            var url = "/interest_graphs/users_analysis/get_city_attr/";
            var data = {query_id:query_id};
            var args = {index: chart_index, ele_arr:ele_arr}
            makeAPost(url, data, true, callback, args);
        },
        get_bar_option: function(title, sub_title, legend_data, series_data) {
            var option = {
                color:['#33c6eb'],
                title: {
                    text: title,
                    subtext: sub_title,
                    left:'center',
                    x:'center',
                    textStyle: {
                        color:'#666',
                        fontSize:18,
                        fontWeight:'bold',
                    },
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                grid: {
                    containLabel: false,
                    borderWidth: 0,
                },
                toolbox: {
                    show : true,
                    feature : {
                        //saveAsImage : {show: true},
                    }
                },
                xAxis : [
                    {
                        type : 'category',
                        data : [],
                        axisTick: {
                            alignWithLabel: true
                        }
                    }
                ],
                yAxis : [
                    {
                        type : 'value',
                        show: false,
                    }
                ],
                backgroundColor:'#c8d8ef',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['tooltip']['trigger'] = 'axis';
            o['tooltip']['formatter'] = '{a} <br/>{b} : {c}';
            o['xAxis'] = {    data: legend_data, 
                              type: 'category', 
                              axisLine: {
                                show:false,
                              },
                              axisTick: {
                                  show:false,
                                  alignWithLabel: true,
                                  interval:0,
                              },
                              axisLabel:{
                                  interval:0,
                                  formatter: function (val) {
                                      return val.split("").join("\n");
                                  },
                              },
                          };
            if(series_data.length == 0) {
                o['series'] = [{'type':'bar'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_data: function(data, index) {
            //data = [['北京', 123], ['上海', 7], ['广州', 207], ['深圳', 107]];
            var key_arr = [{key:'first', title:'一线城市', color:'#4253ae', background_color:'#c8d8ef'}, {key:'second', title:'二线城市', color:'#84cf68', background_color:'#e2f2d9'},  {key:'three', title:'三线城市', color:'#f3a857', background_color:'#fbebd8'},];
            for(var i in key_arr)
            {
                var legend_data = [];
                var dsp_data = [];
                for(var j in data[key_arr[i].key].list) {
                    dsp_data.push(data[key_arr[i].key].list[j].num);
                    legend_data.push(data[key_arr[i].key].list[j].location);
                }
                var series_data = [{
                    name: key_arr[i].title,
                    type: 'bar',
                    data: dsp_data,
                    //itemStyle:{
                    //    normal:{
                    //        barBorderWidth:0,
                    //        barBorderColor:'red',
                    //    },
                    //},
                }];

                var title = '';
                var sub_title = key_arr[i].title+'(共'+data[key_arr[i].key].all_num+'人 - '+data[key_arr[i].key].prop+')';
                var option = GraphBarAggregation.get_bar_option(
                    title, sub_title, legend_data, series_data);
                option.backgroundColor = key_arr[i].background_color;
                option.color = [key_arr[i].color];
           
                charts_all[index[i]].setOption(option);
                charts_all[index[i]].hideLoading();
                //if(i == 0)
                //{
                //    charts_all[index].setOption(option);
                //}
                //else
                //{
                //    charts_all[index].connect(option);
                //}
            }
        },
        callback: function(result, args) {
            if(result.status != 0) {
                ark_notify(result);
                return;
            }
            GraphBarAggregation.display_data(result.city_info, args.index, args.ele_arr);
        },
        refresh: function(ele_arr) {
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/bar',
            ], function(ec) {
                var batch_index = [];
                for(var i in ele_arr)
                {
                    ele_arr[i].style.height = ele_arr[i].offsetWidth*0.9+'px';
                    charts_cur_index += 1;
                    charts_all.push(ec.init(ele_arr[i], 'macarons'));
                    batch_index.push(charts_cur_index);
                    charts_all[charts_cur_index].showLoading({effect:'whirling'});
                }
                GraphBarAggregation.get_data(GraphBarAggregation.callback, batch_index, ele_arr);
            });
        },
}
window.GraphScatter = {
    get_data : function(callback, ele){
        $(ele).children().hide();
        $(ele).append('<p style="text-align:center;margin-top:100px;">计算中,请稍候...</p>');
        var url = "/interest_graphs/users_analysis/get_interest_attr/";
        var data = {query_id:query_id,max_width:1020,max_height:555};
        if(scatter_parents_tag)
        {
            data.div_list = scatter_parents_tag;
        }
        var args = {ele: ele};
        makeAPost(url, data, true, callback, args);
    },
    callback: function(result, args) {
        $(args.ele).children('p').remove();
        if(result.status != 0)
        {
            ark_notify(result);
            $(args.ele).children().show();
            data = [];
        }
        else if(result.data_list.length == 0)
        {
            $(args.ele).children().show();
            return;
        }
        else
        {
            data = result.data_list;
            $(args.ele).html('');
        }
        var background_colors = ['#fccdad', '#fee6d6', '#feece0', '#fff3ea','#FFFAF4', ]
        var main_width = 1020;
        var main_height = 555;
        var paper = Raphael(args.ele, main_width, main_height);
            
        for(var i in data)
        {
            var circle = paper.circle(data[i].x, data[i].y, data[i].r);
            circle.attr({
                fill: data[i].c,
                opacity: 1, 
                stroke: data[i].c, 
            });
            var circle_text = paper.text(data[i].x, data[i].y, data[i].div);
            addTip(circle.node, data[i].div+'<br/>num:'+data[i].num);
            (function(){
                var div = data[i].div;
                var ele_i = args.ele;
                circle.click(function(){
                        graph_scatter_handler(div, ele_i);
                    })
                circle_text.click(function(){
                        graph_scatter_handler(div, ele_i);
                    })
            })();
        }
        result.div_list.unshift('兴趣偏好');
        $(".scatter_favorite_body .breadcrumb").html('');
        for(var i in result.div_list)
        {   
            $(".scatter_favorite_body .breadcrumb").append('<li><a onclick="change_favorite_root(this)"><font>'+result.div_list[i]+'</font></a></li>');
        }
    },
    refresh: function(ele) {
        cur_scatter_ele = ele;
        GraphScatter.get_data(GraphScatter.callback, ele);
    },
}
function graph_scatter_handler(div, ele)
{
    scatter_parents_tag = [];
    $(".scatter_favorite_body .breadcrumb li:gt(0)").each(function(){
        scatter_parents_tag.push($(this).find('font').text());
    });
    scatter_parents_tag.push(div);
    GraphScatter.refresh(ele);
}
window.GraphTreemap = {
        get_treemap_option: function(title, sub_title, legend_data, series_data) {
            var option = {
                calculable : true,
                tooltip: {
                    show : true,
                },
                toolbox: {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                legend: {
                    data:[]
                },
                backgroundColor:'white',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['tooltip']['trigger'] = 'item';
            o['tooltip']['formatter'] = '{b} : {c}';
            if(series_data.length == 0) {
                o['series'] = [{'type':'treemap'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_data: function(data, index) {
            var data_formated = [];
            for(var i in data)
            {
                data_formated.push({name:data[i].tag, value:data[i].num});
            }
            //data = [
            //    {
            //        name: '三星',
            //        value: 6
            //    },
            //    {
            //        name: '小米',
            //        value: 4
            //    },
            //    {
            //        name: '苹果',
            //        value: 4
            //    },
            //    {
            //        name: '华为',
            //        value: 2
            //    },
            //    {
            //        name: '联想',
            //        value: 2
            //    },
            //    {
            //        name: '魅族',
            //        value: 1
            //    },
            //    {
            //        name: '中兴',
            //        value: 1
            //    }
            //];
            var legend_data = [];
            var dsp_data = [];
            var series_data = [{
                name: '',
                type: 'treemap',
                itemStyle: {
                    normal: {
                        label: {
                            show: true,
                            formatter: "{b}"
                        },
                        borderWidth: 1
                    },
                    emphasis: {
                        label: {
                            show: true
                        }
                    }
                },
                data: data_formated,
            }];

            var title = '';
            var sub_title = '';
            var option = GraphTreemap.get_treemap_option(
                title, sub_title, legend_data, series_data);
           
            charts_all[index].setOption(option);
            charts_all[index].hideLoading();
        },
        refresh: function(ele, data) {
            ele.style.height = ele.offsetWidth*0.4+'px';
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/treemap',
            ], function(ec) {
                charts_cur_index += 1;
                charts_all.push(ec.init(ele, 'macarons'));
                GraphTreemap.display_data(data, charts_cur_index);
            });
        },
}
window.GraphBarMix = {
        get_data : function(callback, chart_index){
            var url = "/interest_graphs/users_analysis/get_user_thirty_pv/";
            var data = {uid:uid};
            var args = {index: chart_index}
            makeAPost(url, data, true, callback, args);
        },
        get_mixbar_option: function(title, sub_title, x_axis, legend_data, series_data) {
            var legend_selected = {};
            for(var i in legend_data)
            {
                legend_selected[legend_data[i]] = i ==0 ? true : false;
            }
            var option = {
                tooltip: {
                    trigger: 'item',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
               },
                calcuable:true,
                legend: {
                    selected:legend_selected,
                    data:legend_data,
                },
                toolbox: {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                xAxis : [
                    {
                        type : 'category',
                        data : [],
                    }
                ],
                yAxis : [
                    {
                        type : 'value',
                        show: false,
                    }
                ],
                backgroundColor:'white',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['xAxis'] = {    data: x_axis, 
                              type: 'category', 
                              axisTick: {
                                  show:false 
                              },
                              padding: [30, 0, 0, 0],
                          };
            if(series_data.length == 0) {
                o['series'] = [{'type':'bar'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_data: function(data, index) {
            var source_map = {1:'UC', 2:'喜唰唰', 5:'神马'};
            var x_axis = [];
            var legend_data = [];
            var series_data = [];
            for(var i in data) {
                var values = [];
                if(x_axis.length < 1)
                {
                    for(var j in data[i])
                    {
                        x_axis.push(data[i][j].time);
                    }
                }
                for(var j in data[i])
                {
                    values.push(data[i][j].num);
                }
                series_data.push({
                    name:source_map[i],
                    type:'bar',
                    stack: '总量',
                    itemStyle : { normal: {label : {show: true, position: 'inside'}}},
                    data:values,
                });
                legend_data.push(source_map[i]);
            }
            //legend_data = ['周一','周二','周三','周四','周五','周六','周日'];
            //series_data = [
            //    {
            //        name:'直接访问',
            //        type:'bar',
            //        stack: '总量',
            //        itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
            //        data:[320, 302, 301, 334, 390, 330, 320]
            //    },
            //    {
            //        name:'邮件营销',
            //        type:'bar',
            //        stack: '总量',
            //        itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
            //        data:[120, 132, 101, 134, 90, 230, 210]
            //    },
            //    {
            //        name:'联盟广告',
            //        type:'bar',
            //        stack: '总量',
            //        itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
            //        data:[220, 182, 191, 234, 290, 330, 310]
            //    },
            //    {
            //        name:'视频广告',
            //        type:'bar',
            //        stack: '总量',
            //        itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
            //        data:[150, 212, 201, 154, 190, 330, 410]
            //    },
            //    {
            //        name:'搜索引擎',
            //        type:'bar',
            //        stack: '总量',
            //        itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
            //        data:[820, 832, 901, 934, 1290, 1330, 1320]
            //    }
            //];

            var title = '';
            var sub_title = '';
            var option = GraphBarMix.get_mixbar_option(
                title, sub_title, x_axis, legend_data, series_data);
            //option['legend']['x'] = 20;
            //option['legend']['y'] = 0;
           
            charts_all[index].setOption(option);
            charts_all[index].hideLoading();
        },
        callback: function(result, args) {
            if(result.status != 0) {
                ark_notify(result);
                result.data_map = {};
            }
            GraphBarMix.display_data(result.data_map, args.index);
        },
        refresh: function(ele) {
            ele.style.height = ele.offsetWidth*0.4+'px';
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/bar',
            ], function(ec) {
                charts_cur_index += 1;
                charts_all.push(ec.init(ele, 'macarons'));
                charts_all[charts_cur_index].showLoading({effect:'whirling'});
                GraphBarMix.get_data(GraphBarMix.callback, charts_cur_index);
            });
        },
}
window.GraphKeyword = {
        get_data : function(callback, ele){
            $(ele).html('<p style="text-align:center;margin-top:100px;">计算中,请稍候...</p>');
            var url = "/interest_graphs/users_analysis/get_tag_words_attr/";
            var data = {query_id:query_id};
            var args = {ele: ele}
            makeAPost(url, data, true, callback, args);
        },
        callback: function(result, args) {
            $(args.ele).html('');
            if(result.status != 0)
            {
                ark_notify(result);
                data = [];
            }
            else
            {
                data = result.data_list.slice(0, 20);
            }
            var background_colors = ['#fccdad', '#fee6d6', '#feece0', '#fff3ea','#FFFAF4', ]
            var main_width = 1020;
            var main_height = 555;
            var paper = Raphael(args.ele, main_width, main_height);
            var layer_num = 5;
            for(var i=layer_num; i>0; i--)
            {
                var ellipse = paper.ellipse(main_width/2, main_height/layer_num/2*(i-1), main_width/layer_num/2*i, main_height/layer_num/2*i);
                ellipse.attr({
                    fill: background_colors[i-1],
                    opacity: 1, 
                    stroke: "#fff", 
                    "stroke-width":2 ,
                });
            }
            paper.text(main_width/2, 20, '用户人群');
            //开始画圈
            var min_pv = Number.MAX_SAFE_INTEGER;
            var min_uv = Number.MAX_SAFE_INTEGER;
            var max_pv = 0;
            var max_uv = 0;
            for(var i in data)
            {
                data[i].pv > max_pv ? max_pv = data[i].pv : '';
                data[i].uv > max_uv ? max_uv = data[i].uv : '';
                data[i].pv < min_pv ? min_pv = data[i].pv : '';
                data[i].uv < min_uv ? min_uv = data[i].uv : '';
            }
            var min_distance = main_width/layer_num/2+40;
            var max_distance = main_height/layer_num*(layer_num-1);
            var cur_pos = [];
            for(var i in data)
            {
                var radius = 5 + 35*(data[i].pv - min_pv)/(max_pv - min_pv);
                data[i].radius = radius;
                var distance = min_distance + (max_uv - data[i].uv)*(max_distance-min_distance)/(max_uv-min_uv);
                while(1)
                {
                    var alpha = Math.PI/180*(Math.round(Math.random()*150)-75);
                    var pos = {x:main_width/2+distance*Math.sin(alpha), y:distance*Math.cos(alpha)};
                    var pos_flag = true;
                    for(var j in cur_pos)
                    {
                        if(( (pos.x-cur_pos[j].x)*(pos.x-cur_pos[j].x) + (pos.y-cur_pos[j].y)*(pos.y-cur_pos[j].y) ) < (radius+cur_pos[j].r)*(radius+cur_pos[j].r))
                        {
                            pos_flag = false;
                            break;
                        }
                    }
                    if(pos_flag)
                    {
                        cur_pos.push({x:pos.x, y:pos.y, r:radius});
                        data[i].pos = pos;
                        break;
                    }
                }
                var circle = paper.circle(data[i].pos.x, data[i].pos.y, data[i].radius);
                circle.attr({
                    fill: '#f79b64',
                    opacity: 1, 
                    stroke: "#f79b64", 
                });
                paper.text(data[i].pos.x, data[i].pos.y+data[i].radius+10, data[i].word);
                addTip(circle.node, data[i].word+'<br/>pv:'+data[i].pv+'<br/>uv:'+data[i].uv);
            }
        },
        refresh: function(ele) {
            GraphKeyword.get_data(GraphKeyword.callback, ele);
        },
}
function addTip(node, txt){
    $(node).mouseenter(function(){
       tipText = txt;
       tip.fadeIn();
       over = true;
    }).mouseleave(function(){
       tip.fadeOut(200);
       over = false;
    });
}
function eConsole(param){
    scatter_parents_tag = [];
    $(".scatter_favorite_body .breadcrumb li:gt(0)").each(function(){
        scatter_parents_tag.push($(this).find('font').text());
    });
    scatter_parents_tag.push(param.data[3]);
    GraphScatter.get_data(GraphScatter.callback, charts_cur_index);
    scatter_parents_tag = null;
    //for(var i in charts_all)
    //{
    //    if(i == charts_all.length-1)
    //    {
    //        charts_all[i].off('click');
    //    }
    //}
    //charts_all = [];
    //charts_cur_index -= 1;
    //GraphScatter.refresh(cur_scatter_ele);
}
function change_favorite_root(obj)
{
    $(obj).parent().nextAll().remove();
    scatter_parents_tag = [];
    $(".scatter_favorite_body .breadcrumb li:gt(0)").each(function(){
        scatter_parents_tag.push($(this).find('font').text());
    });
    if(scatter_parents_tag.length < 1)
    {
        scatter_parents_tag = null;
    }
    GraphScatter.get_data(GraphScatter.callback, cur_scatter_ele);
    scatter_parents_tag = null;
}
window.GraphPieStatic = {
        get_pie_option: function(title, sub_title, legend_data, series_data) {
            var option = {
                tooltip: {
                    show : true,
                },
                toolbox: {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                legend: {
                    data:[]
                },
                backgroundColor:'white',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['tooltip']['trigger'] = 'item';
            o['tooltip']['formatter'] = '{a} <br/>{b} : {c} ({d}%)';
            o['legend'] = {data: legend_data, 
                           orient : 'horizontal', 
                           left: 'center',
                           bottom: 20,
                           top: 'bottom',
                           padding: [30, 0, 0, 0],
                          };
            if(series_data.length == 0) {
                o['series'] = [{'type':'pie'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_data: function(data, index) {
            var legend_data = [];
            var dsp_data = [];
            for(var i in data) {
                dsp_data.push(
                    {'name': data[i]['tag'], 
                     'value': data[i]['num']});
                legend_data.push(data[i]['tag']);
            }
            var series_data = [{
                name: 'test',
                type: 'pie',
                center: ['50%', '50%'],
                radius: [0, '50%'],
                data: dsp_data
            }];

            var title = '';
            var sub_title = '';
            var option = GraphPieStatic.get_pie_option(
                title, sub_title, legend_data, series_data);
            charts_all[index].setOption(option);
        },
        refresh: function(ele, data) {
            ele.style.height = ele.offsetWidth*0.5+'px';
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/pie',
            ], function(ec) {
                charts_cur_index += 1;
                charts_all.push(ec.init(ele, 'macarons'));
                GraphPieStatic.display_data(data, charts_cur_index);
            });
        },
}
window.GraphScatterUser = {
    get_data : function(callback, ele){
        $(ele).children().hide();
        $(ele).append('<p style="text-align:center;margin-top:100px;">计算中,请稍候...</p>');
        var url = "/interest_graphs/users_analysis/user_interest_div_info/";
        var data = {uid:uid,max_width:800,max_height:600};
        if(scatter_parents_tag_user)
        {
            data.div_list = scatter_parents_tag_user;
        }
        var args = {ele: ele}
        makeAPost(url, data, true, callback, args);
    },
    callback: function(result, args) {
        $(args.ele).children('p').remove();
        if(result.status != 0)
        {
            ark_notify(result);
            $(args.ele).children().show();
            data = [];
        }
        else if(result.data_list.length == 0)
        {
            $(args.ele).children().show();
            return;
        }
        else
        {
            data = result.data_list;
            $(args.ele).html('');
        }
        var background_colors = ['#fccdad', '#fee6d6', '#feece0', '#fff3ea','#FFFAF4', ]
        var main_width = 800;
        var main_height = 600;
        var paper = Raphael(args.ele, main_width, main_height);
            
        for(var i in data)
        {
            var circle = paper.circle(data[i].x, data[i].y, data[i].r);
            circle.attr({
                fill: data[i].c,
                opacity: 1, 
                stroke: data[i].c, 
            });

            var weight = '强';
            if (data[i].weight == 1) {
                weight = '中';
            } else if (data[i].weight == 2) {
                weight = '弱';
            }
            var circle_text = paper.text(data[i].x, data[i].y, data[i].word + "(" + weight + ")");
            addTip(circle.node, data[i].word+'<br/>强度:'+weight);
            (function(){
                var div = data[i].word;
                var ele_i = args.ele;
                circle.click(function(){
                    graph_scatter_user_handler(div, ele_i);
                });
                circle_text.click(function(){
                    graph_scatter_user_handler(div, ele_i);
                });
             })();
        }
        result.div_list.unshift('兴趣偏好');
        $("#id_interest_container .breadcrumb").html('');
        for(var i in result.div_list)
        {
            $("#id_interest_container .breadcrumb").append('<li><a onclick="change_favorite_root_user(this)"><font>'+result.div_list[i]+'</font></a></li>');
        }          
    },
    refresh: function(ele) {
        cur_scatter_ele = ele;
        GraphScatterUser.get_data(GraphScatterUser.callback, ele);
    },
}
function graph_scatter_user_handler(div, ele)
{
    scatter_parents_tag_user = [];
    $("#id_interest_container .breadcrumb li:gt(0)").each(function(){
        scatter_parents_tag_user.push($(this).find('font').text());
    });
    scatter_parents_tag_user.push(div);
    GraphScatterUser.refresh(ele);
}
function change_favorite_root_user(obj)
{
    $(obj).parent().nextAll().remove();
    scatter_parents_tag_user = [];
    $("#id_interest_container .breadcrumb li:gt(0)").each(function(){
        scatter_parents_tag_user.push($(this).find('font').text());
    });
    if(scatter_parents_tag_user.length < 1)
    {
        scatter_parents_tag_user= null;
    }
    GraphScatterUser.get_data(GraphScatterUser.callback, cur_scatter_ele);
    scatter_parents_tag_user = null;
}
window.GraphBasic = {
        get_data : function(callback, chart_index_pie, chart_index_bar, ele_pie, ele_bar){
            var url = "/interest_graphs/users_analysis/get_default_base_info_list/";
            var data = {query_id:query_id};
            var args = {
                    chart_index_pie:chart_index_pie, 
                    chart_index_bar:chart_index_bar, 
                    ele_pie:ele_pie,
                    ele_bar: ele_bar,};
            makeAPost(url, data, true, callback, args);
        },
        get_pie_option: function(title, sub_title, legend_data, series_data) {
            var option = {
                title: {
                    text: title,
                    x: 'left',
                    textStyle: {
                        color:'#666',
                        fontSize:18,
                        fontWeight:'bold',
                    },
                    padding:[0, 0, 0, 20],
                },
                tooltip: {
                    show : true,
                },
                toolbox: {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                legend: {
                    data:[]
                },
                backgroundColor:'white',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['tooltip']['trigger'] = 'item';
            o['tooltip']['formatter'] = '{a} <br/>{b} : {c} ({d}%)';
            o['legend'] = {data: legend_data, 
                           orient : 'horizontal', 
                           left: 'center',
                           bottom: 20,
                           top: 'bottom',
                           padding: [30, 0, 0, 0],
                          };
            if(series_data.length == 0) {
                o['series'] = [{'type':'pie'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_pie_data: function(data, index) {
            var legend_data = [];
            var dsp_data = [];
            for(var i in data.data_list) {
                if(!data.data_list[i]['div'])
                {
                    data.data_list[i]['div'] = '未知';
                }
                dsp_data.push(
                    {'name': data.data_list[i]['div'], 
                     'value': data.data_list[i]['num']});
                legend_data.push(data.data_list[i]['div']);
            }
            var series_data = [{
                name: '占比分布',
                type: 'pie',
                center: ['50%', '50%'],
                radius: [0, '50%'],
                data: dsp_data
            }];

            var title = data.title_name;
            var sub_title = '';
            var option = GraphBasic.get_pie_option(
                title, sub_title, legend_data, series_data);
            //option['legend']['x'] = 20;
            //option['legend']['y'] = 0;
           
            charts_all[index].setOption(option);
            charts_all[index].hideLoading();
        },
        get_bar_option: function(title, sub_title, legend_data, series_data) {
            var option = {
                color:['#33c6eb'],
                title: {
                    text: title,
                    x: 'left',
                    textStyle: {
                        color:'#666',
                        fontSize:18,
                        fontWeight:'bold',
                    },
                    padding:[0, 0, 0, 20],
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
               },
                grid: {
                    containLabel: false,
                },
                toolbox: {
                    show : true,
                    feature : {
                        saveAsImage : {show: true},
                    }
                },
                calculable : true,
                xAxis : [
                    {
                        type : 'category',
                        data : [],
                        axisTick: {
                            alignWithLabel: false,
                        }
                    }
                ],
                yAxis : [
                    {
                        type : 'value',
                        show: false,
                    }
                ],
                backgroundColor:'white',
                series : []
            };

            var o = $.extend(true, {}, option);
            o['tooltip']['trigger'] = 'axis';
            o['xAxis'] = [{    data: legend_data, 
                              type: 'category', 
                              axisLabel: {
                                rotate:-30,
                              },
                              axisTick: {
                                  alignWithLabel: true
                              },
                              //padding: [30, 0, 0, 0],
                          }];
            if(series_data.length == 0) {
                o['series'] = [{'type':'bar'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        display_bar_data: function(data, index) {
            //data = [['a', 123], ['b', 7], ['c', 207], ['d', 107], ['e', 37]];
            var legend_data = [];
            var dsp_data = [];
            for(var i in data.data_list) {
                dsp_data.push(data.data_list[i]['num']);
                legend_data.push(data.data_list[i]['div']);
            }
            var series_data = [{
                name: data.title_name,
                type: 'bar',
                data: dsp_data
            }];

            var title = data.title_name;
            var sub_title = '';
            var option = GraphBasic.get_bar_option(
                title, sub_title, legend_data, series_data);

           
            charts_all[index].setOption(option);
            charts_all[index].hideLoading();
        },
        callback: function(result, args) {
            if(result.status != 0) {
                ark_notify(result);
                return;
            }
            if(result.data_list.length == 0)
            {
                args.ele_pie.parentElement.style.display = 'none';
                args.ele_bar.parentElement.style.display = 'none';
            }
            //else
            //{
            //    args.ele_pie.parentElement.style.display = 'inline-block';
            //    args.ele_bar.parentElement.style.display = 'inline-block';
            //}
            var pie_drawed_flag = false;
            var bar_drawed_flag = false;
            for(var i in result.data_list)
            {
                if(result.data_list[i].status == 0)
                {
                    if(result.data_list[i].show_type == 0)//占比
                    {
                        var index = 0;
                        if(pie_drawed_flag == false)
                        {
                            pie_drawed_flag = true;
                            index = args.chart_index_pie;
                        }
                        else
                        {
                            index = ++charts_cur_index;
                            var new_pie_id = 'graph_basic_'+index;
                            $(".figure_result").append('<div class="col-sm-6 col-md-6 chart_item_container">\
                                                        <div id="'+new_pie_id+'" class="chart_item">\
                                                        </div>\
                                                    </div>');
                            var ele_pie = document.getElementById(new_pie_id);
                            ele_pie.style.height = ele_pie.offsetWidth+'px';
                            require([
                                'echarts',
                                'echarts/theme/macarons',
                                'echarts/chart/pie',
                            ], function(ec) {
                                charts_all.push(ec.init(ele_pie, 'macarons'));
                                charts_all[charts_cur_index].showLoading({effect:'whirling'});
                            });
                        }
                        GraphBasic.display_pie_data(result.data_list[i], index);
                    }
                    else if(result.data_list[i].show_type == 2)//分布
                    {
                        var index = 0;
                        if(bar_drawed_flag == false)
                        {
                            bar_drawed_flag = true;
                            index = args.chart_index_bar;
                        }
                        else
                        {
                            index = ++charts_cur_index;
                            var new_bar_id = 'graph_basic_'+index;
                            $(".figure_result").append('<div class="col-sm-6 col-md-6 chart_item_container">\
                                                        <div id="'+new_bar_id+'" class="chart_item">\
                                                        </div>\
                                                    </div>');
                            var ele_bar = document.getElementById(new_bar_id);
                            ele_bar.style.height = ele_bar.offsetWidth+'px';
                            require([
                                'echarts',
                                'echarts/theme/macarons',
                                'echarts/chart/bar',
                            ], function(ec) {
                                charts_all.push(ec.init(ele_bar, 'macarons'));
                                charts_all[charts_cur_index].showLoading({effect:'whirling'});
                            });
                        }
                        GraphBasic.display_bar_data(result.data_list[i], index);
                    }
                }
            }
            if($(".figure_sidebar .figure_type.active").attr('action-data') == 0)
            {
                $(".figure_result").append('<div class="col-sm-6 col-md-6 chart_item_container ">\
                                            <div class="chart_item_add">\
                                                <img style="cursor: pointer;" src="/static/images/interest_graphs/add_basic_figure.png" onclick="add_basic_figure()"></img>\
                                            </div>\
                                        </div>');
            }
        },
        refresh: function() {
            graph_basic_index += 1;
            var pie_id = 'graph_basic_'+graph_basic_index;
            graph_basic_index += 1;
            var bar_id = 'graph_basic_'+graph_basic_index;
            $(".figure_result").append('<div class="col-sm-6 col-md-6 chart_item_container">\
                                        <div id="'+pie_id+'" class="chart_item">\
                                        </div>\
                                    </div>');
            $(".figure_result").append('<div class="col-sm-6 col-md-6 chart_item_container">\
                                        <div id="'+bar_id+'" class="chart_item">\
                                        </div>\
                                    </div>');
            var ele_pie = document.getElementById(pie_id);
            var ele_bar = document.getElementById(bar_id);
            ele_pie.style.height = ele_pie.offsetWidth+'px';
            ele_bar.style.height = ele_bar.offsetWidth+'px';
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/pie',
            ], function(ec) {
                charts_cur_index += 1;
                charts_all.push(ec.init(ele_pie, 'macarons'));
                charts_all[charts_cur_index].showLoading({effect:'whirling'});
                require([
                    'echarts',
                    'echarts/theme/macarons',
                    'echarts/chart/bar',
                ], function(ec) {
                    charts_cur_index += 1;
                    charts_all.push(ec.init(ele_bar, 'macarons'));
                    charts_all[charts_cur_index].showLoading({effect:'whirling'});
                    GraphBasic.get_data(GraphBasic.callback, charts_cur_index-1, charts_cur_index, ele_pie, ele_bar);
                });
            });
        },
}
