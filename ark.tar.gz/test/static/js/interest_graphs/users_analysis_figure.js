var charts_all = [];
var charts_cur_index = -1;
var table_prov_city_rank_list = null;
var query_id = $("#input_query_id").val();
var self_defined_charts_index = 0;
var cur_delete_dom = null;
var auto_click = false;
$(function(){
    $(window).on('resize', function(){
        for(var i in charts_all)
        {
            charts_all[i].resize();
        }
    });
    $(".figure_sidebar .figure_type").on("click", function(){
        if($(this).hasClass('active') && !auto_click)
        {
            return;
        }
        auto_click = false;
        table_prov_city_rank_list = null;
        $(".figure_sidebar .figure_type").removeClass('active');
        $(this).addClass('active');
        var side_index = $(this).attr('action-data');
        $(".figure_result").html('');
        if(side_index == 0)
        {
            GraphBasic.refresh();
        }
        else if(side_index == 1)
        {
            var map_id = 'div_map';
            $(".figure_result").append('<div class="col-md-12 block_map">\
                                            <div class="col-md-12 block_table">\
                                                <div class="block_table_op">\
                                                    <span action-data="0" class="block_table_op_type active">省份</span>\
                                                    <span action-data="1" class="block_table_op_type">城市</span>\
                                                </div>\
                                                <table class="table" id="table_prov_city_rank_list" cellspacing="0">\
                                                    <thead>\
                                                        <tr>\
                                                            <th style="width:20px"></th>\
                                                            <th style="width:100px"></th>\
                                                            <th style="width:140px"></th>\
                                                            <th style="width:145px"></th>\
                                                        </tr>\
                                                    </thead>\
                                                </table>\
                                            </div>\
                                            <div id="'+map_id+'" class="map_container">\
                                            </div>\
                                        </div>');
            var display_zone_ele = document.getElementById(map_id);
            GraphMap.refresh(display_zone_ele);
            $(".block_table_op .block_table_op_type").attr('tmp_chart_index', charts_cur_index);
            flush_table_prov_city_rank_list();
            var id_city_rank_1 = 'id_city_rank_1';
            var id_city_rank_2 = 'id_city_rank_2';
            var id_city_rank_3 = 'id_city_rank_3';
            $(".figure_result").append('<div class="city_distribute">\
                                            <div class="city_distribute_head">\
                                                分类城市分布\
                                            </div>\
                                            <div class="row city_distribute_body">\
                                                <div id="'+id_city_rank_1+'" class="col-md-4">\
                                                </div>\
                                                <div id="'+id_city_rank_2+'" class="col-md-4">\
                                                </div>\
                                                <div id="'+id_city_rank_3+'" class="col-md-4">\
                                                </div>\
                                            </div>\
                                        </div>');
            var ele_arr = [document.getElementById(id_city_rank_1), document.getElementById(id_city_rank_2), document.getElementById(id_city_rank_3)];
            GraphBarAggregation.refresh(ele_arr);
            //var display_zone_ele = document.getElementById(id_city_rank_1);
            //GraphBarAggregation.refresh(display_zone_ele);
            //var display_zone_ele = document.getElementById(id_city_rank_2);
            //GraphBarAggregation.refresh(display_zone_ele);
            //var display_zone_ele = document.getElementById(id_city_rank_3);
            //GraphBarAggregation.refresh(display_zone_ele);
        }
        else if(side_index == 2)
        {
            var scatter_favorite_id = 'scatter_favorite_id';
            $(".figure_result").append('<div class="scatter_favorite">\
                                            <div class="scatter_favorite_head">\
                                                兴趣偏好\
                                            </div>\
                                            <div class="scatter_favorite_body">\
                                                <div id="'+scatter_favorite_id+'" class="row">\
                                                </div>\
                                                <div class="">\
                                                    <ul class="breadcrumbs breadcrumb">\
                                                        <li>\
                                                            <a onclick="change_favorite_root(this)"><font>兴趣偏好</font></a>\
                                                        </li>\
                                                    </ul>\
                                                </div>\
                                            </div>\
                                        </div>');
            scatter_parents_tag = [];
            var display_zone_ele = document.getElementById(scatter_favorite_id);
            GraphScatter.refresh(display_zone_ele);
        }
        else if(side_index == 3)
        {
            var id_chart_keyword = 'id_chart_keyword';
            $(".figure_result").append('<div class="chart_keyword">\
                                            <div class="chart_keyword_head">\
                                                热门关键词<span class="glyphicon glyphicon-question-sign" aria-hidden="true" data-toggle="tooltip" data-placement="top" data-original-title="越靠近用户圈说明搜索的人越多，圈越大说明搜索的次数越多"></span>\
                                            </div>\
                                            <div class="row chart_keyword_body">\
                                                <div id="'+id_chart_keyword+'" class="row">\
                                                </div>\
                                            </div>\
                                        </div>');
            $('[data-toggle="tooltip"]').tooltip();
            var display_zone_ele = document.getElementById(id_chart_keyword);
            GraphKeyword.refresh(display_zone_ele);
        }
        else if(side_index == 4)
        {
            var url = "/interest_graphs/users_analysis/get_all_user_define_result/";
            var post_data = {query_id:query_id};
            var callback = callback_get_all_user_define_result;
            var args = {}
            makeAPost(url, post_data, true, callback, args);

        }
    });
    $(document).on('click', '.block_table_op_type', function(){
        if(!$(this).hasClass('active'))
        {
            $('.block_table_op_type').removeClass('active');
            $(this).addClass('active');
            flush_table_prov_city_rank_list();
            GraphMap.get_data(GraphMap.callback, $(this).attr('tmp_chart_index'));
        }
    });
    auto_click = true;
    $(".figure_sidebar .figure_type.active").trigger("click");
});
function flush_table_prov_city_rank_list()
{
    if(table_prov_city_rank_list)
    {
        var url = $(".block_table_op_type.active").attr('action-data') == 1 ? "/interest_graphs/users_analysis/get_all_city_attr/" : "/interest_graphs/users_analysis/get_province_attr/";
        table_prov_city_rank_list.ajax.url(url).load();
    }
    else
    {
        table_prov_city_rank_list = $('#table_prov_city_rank_list').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": "/interest_graphs/users_analysis/get_province_attr/",
                "type": "POST",
                "data":function(d){
                    d.query_id = query_id;
                },
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    //json = {status:0, data:[
                    //    {no:1, location:'上海',progress:'100', num_percent:'4103842(9.9%)'},
                    //    {no:2, location:'上海',progress:'80', num_percent:'4103842(9.9%)'},
                    //    {no:3, location:'上海',progress:'50', num_percent:'4103842(9.9%)'},
                    //    {no:4, location:'上海',progress:'50', num_percent:'4103842(9.9%)'},
                    //    {no:5, location:'上海',progress:'50', num_percent:'4103842(9.9%)'},
                    //    {no:6, location:'上海',progress:'50', num_percent:'4103842(9.9%)'},
                    //    {no:7, location:'上海',progress:'50', num_percent:'4103842(9.9%)'},
                    //    {no:8, location:'上海',progress:'50', num_percent:'4103842(9.9%)'},
                    //    {no:9, location:'上海',progress:'50', num_percent:'4103842(9.9%)'},
                    //    {no:10, location:'上海',progress:'90', num_percent:'4103842(9.9%)'},
                    //]};
                    if(json.status !=0)
                    {
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        json.data = json.data_list;
                        for(var i in json.data)
                        {
                            json.data[i].no = parseInt(i)+1;
                        }
                        json.data = json.data.slice(0, 10);
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "pageLength":10,
            "paginate":false,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
                "paginate":{
                    'next':'下一页',
                    'previous':'上一页',
                },
            },
            columns: [
            {
                data: "no",
                bSortable: false
            }, {
                data: "location",
                bSortable: false
            }, {
                data: "prop",
                bSortable: false
            }, {
                data: "num",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[2],
                    "render":function(data,type,full){
                        var prop = parseFloat(data);
                        return '<div class="progress">\
                                  <div class="progress-bar" role="progressbar" aria-valuenow="'+prop+'" aria-valuemin="0" aria-valuemax="100" style="width: '+prop+'%;">\
                                  </div>\
                                </div>';
                    },
                },
                {
                    "targets":[3],
                    "render":function(data,type,full){
                        return data+'('+full.prop+')';
                     }
                },
            ]

    });

    }
}

function add_self_defined_figure()
{
    $("#addSelfDefinedFigureModal #figure_type").val('-1');
    $("#addSelfDefinedFigureModal .figure_name").val('');
    $("#addSelfDefinedFigureModal").modal('show');
    $("#addSelfDefinedFigureModal #figure_dim").select2({
        placeholder: '请添加维度',
        multiple: false,
        ajax: {
            url: '/interest_graphs/tag/get_all_dim_tag/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                'search[value]': term,
                length:10,
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.data)
                    {
                        ret.push({id:data.data[i].path, text:data.data[i].path});
                    }
                }
                return {
                  results: ret
                };
            }
        },
        initSelection: function (element, callback) {
            //var data = JSON.parse(element.attr('action-data'));
            callback('');//这里初始化
        },
        language: 'ch',
    });
}
function do_add_self_defined_figure()
{
    $("#addSelfDefinedFigureModal #btn_add_self_defined_figure_ok").button('loading');
    var url = "/interest_graphs/users_analysis/select_user_define_analysis/";
    var post_data = {query_id:query_id};
    post_data.show_type = $("#addSelfDefinedFigureModal #figure_type").val();
    post_data.name = $("#addSelfDefinedFigureModal .figure_name").val().trim();
    var path = $("#addSelfDefinedFigureModal #figure_dim").val();
    post_data.div_list = path ? path.split('-') : [];
    var callback = callback_do_add_self_defined_figure;
    var args = {}
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_self_defined_figure(result, args)
{
    $("#addSelfDefinedFigureModal #btn_add_self_defined_figure_ok").button('reset');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    $("#addSelfDefinedFigureModal").modal('hide');
    show_defined_data(result);
    if($(".self_defined_empty").length > 0)
    {
        $(".self_defined_empty").remove();
        $(".figure_result").append('<div class="div_add_self_defined_figure">\
                                        <button type="button" class="btn btn-primary interest_graphs_btn_primary" onclick="add_self_defined_figure()">新建自定义画像</button>\
                                    </div>');
    }
}
function callback_get_all_user_define_result(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    if(result.data_list.length < 1)
    {
        $(".figure_result").append('<div class="self_defined_empty">\
                                        <div class="empty_tip">你目前尚无自定义的画像</div>\
                                        <div class="empty_op"><button type="button" class="btn btn-primary interest_graphs_btn_primary" onclick="add_self_defined_figure()">新建自定义画像</button></div>\
                                    </div>');
        return;
    }
    for(var i in result.data_list)
    {
        var data = result.data_list[i];
        show_defined_data(data);
    }
    $(".figure_result").append('<div class="div_add_self_defined_figure">\
                                    <button type="button" class="btn btn-primary interest_graphs_btn_primary" onclick="add_self_defined_figure()">新建自定义画像</button>\
                                </div>');
}
function show_defined_data(data)
{
    if(data.status != 0)
    {
        ark_notify(result);
        return;
    }
    if(data.show_type == 0)
    {
        self_defined_charts_index += 1;
        var ele_id = 'self_defined_charts_id_'+self_defined_charts_index;
        var ele_name = data.name;
        show_distribute_chart(ele_id, ele_name, data);
    }
    else if(data.show_type == 1)
    {
        show_rank_chart(data.name, data);
    }
    else if(data.show_type == 2)
    {
        self_defined_charts_index += 1;
        var ele_id = 'self_defined_charts_id_'+self_defined_charts_index;
        var ele_name = data.name;
        show_percent_chart(ele_id, ele_name, data);
    }
}
function show_rank_chart(chart_name, data)
{
    var tbody_html = '';
    for(var i in data.data_list)
    {
        tbody_html += '<tr>\
                         <td style="width:10%;">'+(parseInt(i)+1)+'</td>\
                         <td style="width:30%;">'+data.data_list[i].tag+'</td>\
                         <td style="width:40%;">\
                             <div class="progress">\
                                   <div class="progress-bar" role="progressbar" aria-valuenow="'+parseFloat(data.data_list[i].prop)+'" aria-valuemin="0" aria-valuemax="100" style="min-width:1em; width: '+parseFloat(data.data_list[i].prop)+'%;">\
                                   </div>\
                                 </div>\
                         </td>\
                         <td style="width:20%;">'+data.data_list[i].num+'('+data.data_list[i].prop+')</td>\
                      </tr>';
    }
    var onclick_str = 'delete_user_define_analysis(\''+JSON.stringify(data)+'\',this)';
    var download_onclick_str = 'download_user_define_analysis(\''+JSON.stringify(data)+'\')';
    var html = '<div class="distribute">\
                    <div class="distribute_head">'+chart_name+'\
                        <div class="dropdown">\
                          <span class="glyphicon glyphicon-wrench" aria-hidden="true" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>\
                          <ul class="dropdown-menu pull-right">\
                            <li><a onclick='+onclick_str+'>删除</a>\
                            <li><a onclick='+download_onclick_str+'>下载</a>\
                          </ul>\
                        </div>\
                    </div>\
                    <div class="row distribute_body">\
                        <table class="table table_defined_chart" cellspacing="0">\
                            <tbody>'+tbody_html+'</tbody>\
                        </table>\
                    </div>\
                </div>';
    if($(".div_add_self_defined_figure").length > 0)
    {
        $(".div_add_self_defined_figure").before(html);
    }
    else
    {
        $(".figure_result").append(html);
    }
}
function show_distribute_chart(ele_id, chart_name, data)
{
    var onclick_str = 'delete_user_define_analysis(\''+JSON.stringify(data)+'\',this)';
    var download_onclick_str = 'download_user_define_analysis(\''+JSON.stringify(data)+'\')';
    var html = '<div class="distribute">\
                    <div class="distribute_head">'+chart_name+'\
                        <div class="dropdown">\
                          <span class="glyphicon glyphicon-wrench" aria-hidden="true" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>\
                          <ul class="dropdown-menu pull-right">\
                            <li><a onclick='+onclick_str+'>删除</a>\
                            <li><a onclick='+download_onclick_str+'>下载</a>\
                          </ul>\
                        </div>\
                    </div>\
                    <div class="row distribute_body">\
                        <div id="'+ele_id+'" class="col-md-12">\
                        </div>\
                    </div>\
                </div>'
    if($(".div_add_self_defined_figure").length > 0)
    {
        $(".div_add_self_defined_figure").before(html);
    }
    else
    {
        $(".figure_result").append(html);
    }
    var display_zone_ele = document.getElementById(ele_id);
    GraphTreemap.refresh(display_zone_ele, data.data_list);
}
function show_percent_chart(ele_id, chart_name, data)
{
    var onclick_str = 'delete_user_define_analysis(\''+JSON.stringify(data)+'\',this)';
    var download_onclick_str = 'download_user_define_analysis(\''+JSON.stringify(data)+'\')';
    var html = '<div class="distribute">\
                    <div class="distribute_head">'+chart_name+'\
                        <div class="dropdown">\
                          <span class="glyphicon glyphicon-wrench" aria-hidden="true" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>\
                          <ul class="dropdown-menu pull-right">\
                            <li><a onclick='+onclick_str+'>删除</a>\
                            <li><a onclick='+download_onclick_str+'>下载</a>\
                          </ul>\
                        </div>\
                    </div>\
                    <div class="row distribute_body">\
                        <div id="'+ele_id+'" class="col-md-12">\
                        </div>\
                    </div>\
                </div>'
    if($(".div_add_self_defined_figure").length > 0)
    {
        $(".div_add_self_defined_figure").before(html);
    }
    else
    {
        $(".figure_result").append(html);
    }
    var display_zone_ele = document.getElementById(ele_id);
    GraphPieStatic.refresh(display_zone_ele, data.data_list);
}
function save_figure()
{
    $("#saveFigureModal .save_figure_name").val('');
    $("#saveFigureModal").modal('show');
}
function do_save_figure()
{
    $("#saveFigureModal #btn_save_figure_ok").button('loading');
    var url = "/interest_graphs/users_analysis/save_user_favorite/";
    var post_data = {query_id:query_id};
    post_data.name = $("#saveFigureModal .save_figure_name").val().trim();
    var callback = callback_do_save_figure;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_save_figure(result, args)
{
    $("#saveFigureModal #btn_save_figure_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#saveFigureModal").modal('hide');
    }
} 
function delete_user_define_analysis(data_str, obj)
{
    cur_delete_dom = obj;
    $("#deleteSingleDefinedModal #btn_do_delete_defined").attr('onclick', 'do_delete_user_define_analysis('+data_str+')');
    $("#deleteSingleDefinedModal").modal('show');
}
function do_delete_user_define_analysis(data)
{
    $("#deleteSingleDefinedModal #btn_do_delete_defined").button('loading');
    var url = "/interest_graphs/users_analysis/delete_user_define_analysis/";
    var post_data = {query_id:query_id, name:data.name, show_type:data.show_type, div_list:data.div_list};
    var callback = callback_do_delete_user_define_analysis;
    var args = {}
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_user_define_analysis(result, args)
{
    ark_notify(result);
    $("#deleteSingleDefinedModal #btn_do_delete_defined").button('reset');
    if(result.status == 0)
    {
        $("#deleteSingleDefinedModal").modal('hide');
        $(cur_delete_dom).parents(".distribute").remove();
        if($(".figure_result .distribute").length < 1)
        {
            $(".figure_result").html('<div class="self_defined_empty">\
                                            <div class="empty_tip">你目前尚无自定义的画像</div>\
                                            <div class="empty_op"><button type="button" class="btn btn-primary interest_graphs_btn_primary" onclick="add_self_defined_figure()">新建自定义画像</button></div>\
                                        </div>');
        }
    }
}
function download_user_define_analysis(data)
{
    data = JSON.parse(data);
    var params = {
            'query_id':query_id,
            'name':data.name,
            'show_type':data.show_type,
            'div_list':data.div_list,
        };
    var url = '/interest_graphs/users_analysis/download_user_def_analysis/?'+$.param(params);
    location.href = url;
}
function add_basic_figure()
{
    $("#addBasicFigureModal #basic_figure_type").val('0');
    $("#addBasicFigureModal #basic_figure_dim").select2();
    $("#addBasicFigureModal").modal('show');
}
function do_add_basic_figure ()
{
    $("#addBasicFigureModal #btn_add_basic_figure_ok").button('loading');
    var url = "/interest_graphs/users_analysis/get_user_base_info_with_div/";
    var post_data = {query_id:query_id};
    post_data.show_type = $("#addBasicFigureModal #basic_figure_type").val();
    post_data.base_div = $("#addBasicFigureModal #basic_figure_dim").val();
    var args = {}
    var callback = callback_do_add_basic_figure;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_basic_figure(result, args)
{
    $("#addBasicFigureModal #btn_add_basic_figure_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#addBasicFigureModal").modal('hide');
        $(".figure_sidebar .figure_type:eq(0)").trigger('click');
    }
}
