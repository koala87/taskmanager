
var table_list = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var candidate_obj = null;
var click_parent_id = null;
var global_check_alias = null;
$(function () {
    if ($('#global_parent_id').val() != -1) {
        click_parent_id = $('#global_parent_id').val();
    }
    init_table();
    $("#table_list.table-bordered").css("border", "none");
    $("#table_list").parent("div.col-sm-12").css("padding-right", "13px");
    $('#start_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });
    $('#end_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });
    import_dict();
    import_dict2(-1);

    $(document).on("change", "input.ct_select_dict_list", function (e) {
        import_dict2(-1);
        if(e.added != undefined)
        {
            import_dict2(e.added.id);
        }
        click_parent_id = null;
        table_list.ajax.reload();
    });

    $(document).on("change", "input.ct_select_dict_list2", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });
    $(document).on("change", "#id_tag_filter_name", function (e) {
        table_list.ajax.reload();
    });
    $(document).on("change", "#start_update_time", function (e) {
        table_list.ajax.reload();
    });
    $(document).on("change", "#end_update_time", function (e) {
        table_list.ajax.reload();
    });
    $(document).on("change", "#tag_type_select", function (e) {
        table_list.ajax.reload();
    });
    $(document).on("change", "#tag_is_book_select", function (e) {
        table_list.ajax.reload();
    });
    $(document).on("change", "#tag_is_entity_select", function (e) {
        table_list.ajax.reload();
    });
    $(document).on("change", "#tag_src_select", function (e) {
        table_list.ajax.reload();
    });
    $(document).on("change", "#alias_check_status_select", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });
    $(document).on("change", "#relate_check_status_select", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });

    $("#uplod_file").change(function() {
        if ($("#uplod_file").val() != "") {
            upload_file();
        }
    });

    import_dict_new_1();
    import_dict_new_2(-1);
    import_dict_new_3(-1);
    $(document).on("change", "input.ct_select_dict_list_new_1", function (e) {
        import_dict_new_2(-1);
        import_dict_new_3(-1);
        if(e.added != undefined)
        {
            import_dict_new_2(e.added.id);
        }
    });

    $(document).on("change", "input.ct_select_dict_list_new_2", function (e) {
        import_dict_new_3(-1);
        if(e.added != undefined)
        {
            import_dict_new_3(e.added.id);
        }
    });

    $(document).on("change", "input.ct_candidate_mul_tag_prev", function (e) {
        if(e.removed != undefined)
        {
            var val_list = [];
            if ($("input.ct_candidate_mul_tag_prev").attr('action-data') != undefined) {
                val_list = JSON.parse($("input.ct_candidate_mul_tag_prev").attr('action-data'));
            }

            var tmp_val_list = [];
            for (var i = 0; i < val_list.length; ++i) {
                if (val_list[i].id == e.removed.id) {
                    continue;
                }
                tmp_val_list.push(val_list[i]);
            }
            $("input.ct_candidate_mul_tag_prev").attr('action-data', JSON.stringify(tmp_val_list));
        }
        refresh_candidate_table();
    });
    $(document).on("change", "input.ct_candidate_mul_tag_relate", function (e) {
        if(e.removed != undefined)
        {
            var val_list = [];
            if ($("input.ct_candidate_mul_tag_relate").attr('action-data') != undefined) {
                val_list = JSON.parse($("input.ct_candidate_mul_tag_relate").attr('action-data'));
            }

            var tmp_val_list = [];
            for (var i = 0; i < val_list.length; ++i) {
                if (val_list[i].id == e.removed.id) {
                    continue;
                }
                tmp_val_list.push(val_list[i]);
            }
            $("input.ct_candidate_mul_tag_relate").attr('action-data', JSON.stringify(tmp_val_list));
        }

        refresh_candidate_table();
    });
    $(document).on("change", "input.ct_candidate_mul_tag_next", function (e) {
        if(e.removed != undefined)
        {
            var val_list = [];
            if ($("input.ct_candidate_mul_tag_next").attr('action-data') != undefined) {
                val_list = JSON.parse($("input.ct_candidate_mul_tag_next").attr('action-data'));
            }

            var tmp_val_list = [];
            for (var i = 0; i < val_list.length; ++i) {
                if (val_list[i].id == e.removed.id) {
                    continue;
                }
                tmp_val_list.push(val_list[i]);
            }
            $("input.ct_candidate_mul_tag_next").attr('action-data', JSON.stringify(tmp_val_list));
        }

        refresh_candidate_table();
    });

    $(document).on("change", "input.ct_passed_alias_select", function (e) {
        if(e.removed != undefined)
        {
            var val_list = [];
            if ($("input.ct_passed_alias_select").attr('action-data') != undefined) {
                val_list = JSON.parse($("input.ct_passed_alias_select").attr('action-data'));
            }

            var tmp_val_list = [];
            for (var i = 0; i < val_list.length; ++i) {
                if (val_list[i].id == e.removed.id) {
                    continue;
                }
                tmp_val_list.push(val_list[i]);
            }
            $("input.ct_passed_alias_select").attr('action-data', JSON.stringify(tmp_val_list));
        }
        refresh_alias_table();
    });

    //全选
    $('#checkall').on('change',function(){
        if($(this).is(':checked')){
            $('.ct_allcheck').each(function(){
                $(this).prop('checked',true);
            });
        }else{
            $('.ct_allcheck').each(function(){
                $(this).prop('checked', false);
            });
        }
    });

    //$.ajax({
    //    url: '/interest_graphs/content_tag/api/get_tag_with_id/',
    //    type: 'POST',
    //    data: { "id_list": "131418,131419,133222" },
    //    type: 'POST',
    //    dataType: "json",
    //    async: false,
    //    success: function (result) {
    //        if (result.status != 0) {
    //            showMessage("error", "修改管理员失败", result.msg);
    //            return;
    //        }
    //    }
    //});

});

function download_tags() {
    var tag_name_list = $("#id_tag_filter_name").val();
    var start_time = $("#start_update_time").val();
    var end_time = $("#end_update_time").val();
    var first_div_id = $("input.ct_select_dict_list").val();
    if (first_div_id == "") {
        first_div_id = -1;
    }
    var second_div_id = $("input.ct_select_dict_list2").val();
    if (second_div_id == "") {
        second_div_id = -1;
    }
    if (click_parent_id != null && click_parent_id != "" && first_div_id == -1 && second_div_id == -1) {
        second_div_id = click_parent_id;
    }
    var tag_type = $("#tag_type_select").val();
    var is_book_tag = $("#tag_is_book_select").val();
    var is_entity_tag = $("#tag_is_entity_select").val();
    var src_tag = $("#tag_src_select").val();

    var params = {
           "tag_name_list": tag_name_list, "start_time": start_time, 
            "end_time": end_time, "first_div_id": first_div_id, 
            "second_div_id": second_div_id, "tag_type": tag_type, 
            "is_book_tag": is_book_tag, "is_entity_tag": is_entity_tag, 
            "src_tag": src_tag
        };
    var url = '/interest_graphs/content_perm/download_tags/?'+$.param(params);
    location.href = url;
}

function do_update_candidate_relate(tag_id) {
    prev_list = $("input.ct_candidate_mul_tag_prev").val();
    relate_list = $("input.ct_candidate_mul_tag_relate").val();
    next_list = $("input.ct_candidate_mul_tag_next").val();
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#manage_candidate_tag_model").modal('hide');
            table_list.ajax.reload();
        }
    });
}

function candidate_tag_manage(tag_id) {
    $("input.ct_candidate_mul_tag_prev").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });
    $("input.ct_candidate_mul_tag_relate").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });
    $("input.ct_candidate_mul_tag_next").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_candidate_relate/',
        type: 'POST',
        data: { "tag_id": tag_id },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_candidate_mul_tag_prev").attr('action-data', JSON.stringify(result.prev_ret_list));
            $("input.ct_candidate_mul_tag_relate").attr('action-data', JSON.stringify(result.relate_ret_list));
            $("input.ct_candidate_mul_tag_next").attr('action-data', JSON.stringify(result.next_ret_list));
            $("input.ct_candidate_mul_tag_prev").select2("data", result.prev_ret_list);
            $("input.ct_candidate_mul_tag_relate").select2("data", result.relate_ret_list);
            $("input.ct_candidate_mul_tag_next").select2("data", result.next_ret_list);
            candidate_obj = result.data_list;
            refresh_candidate_table();
            $('#manage_candidate_tag_model #btn_update_candidate_relate').attr('onclick', 'do_update_candidate_relate('+ tag_id + ')');
            $("#manage_candidate_tag_model").modal('show');
        }
    });
}

function refresh_candidate_table() {
    var prev_val_list = $("input.ct_candidate_mul_tag_prev").val().split(',');
    var relate_val_list = $("input.ct_candidate_mul_tag_relate").val().split(',');
    var next_val_list = $("input.ct_candidate_mul_tag_next").val().split(',');
    var table_list = "";
    var all_list = "";
    var row_num = 0;
    for (var i = 0; i < candidate_obj.length; ++i) {
        if (prev_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        if (relate_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        if (next_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        table_list += '<th style="white-space:nowrap;overflow:hidden;text-overflow: ellipsis;"><input name="candidate_tag" type="checkbox" value="' + candidate_obj[i].id +'" ><span title="' + candidate_obj[i].text + '">' + candidate_obj[i].text + '</span></th>'
        row_num += 1;
        if (row_num > 3) {
            all_list += '<tr>' + table_list + '</tr>';
            table_list = "";
            row_num = 0;
        }
    }
        if (row_num > 0) {
            all_list += '<tr>' + table_list + '</tr>';
        }

    if (all_list != "") {
        $('#candidate_tags').html(
            '<div style="margin-top:0px;float:left;"><table class="table" id="candidate_tag_table" style="table-layout: fixed;word-break:break-all;word-wrap:break-all;font-family: MicrosoftYaHei;font-size:13px;" cellspacing="0" width="100%">'+
            all_list +
            '</table></div>'
        );
    } else {
        $('#candidate_tags').html("没有候选标签！")
    }
}

function choosed_as_prev() {
    var prev_val_list = [];
    if ($("input.ct_candidate_mul_tag_prev").attr('action-data') != undefined) {
        prev_val_list = JSON.parse($("input.ct_candidate_mul_tag_prev").attr('action-data'));
    }
    
    $("input:checked[name='candidate_tag']").each(function(index){
        if($(this)[0].checked){
            prev_val_list.push({id:$(this).val(), text:$(this).next('span').text()});
        }
    });
    $("input.ct_candidate_mul_tag_prev").select2("data", prev_val_list);
    $("input.ct_candidate_mul_tag_prev").attr('action-data', JSON.stringify(prev_val_list));
    refresh_candidate_table();
}

function choosed_as_relate() {
    var relate_val_list = [];
    if ($("input.ct_candidate_mul_tag_relate").attr('action-data') != undefined) {
        relate_val_list = JSON.parse($("input.ct_candidate_mul_tag_relate").attr('action-data'));
    }
    
    $("input:checked[name='candidate_tag']").each(function(index){
        if($(this)[0].checked){
            relate_val_list.push({id:$(this).val(), text:$(this).next('span').text()});
        }
    });
    $("input.ct_candidate_mul_tag_relate").select2("data", relate_val_list);
    $("input.ct_candidate_mul_tag_relate").attr('action-data', JSON.stringify(relate_val_list));
    refresh_candidate_table();
}

function choosed_as_next() {
    var next_val_list = [];
    if ($("input.ct_candidate_mul_tag_next").attr('action-data') != undefined) {
        next_val_list = JSON.parse($("input.ct_candidate_mul_tag_next").attr('action-data'));
    }
    
    $("input:checked[name='candidate_tag']").each(function(index){
        if($(this)[0].checked){
            next_val_list.push({id:$(this).val(), text:$(this).next('span').text()});
        }
    });
    $("input.ct_candidate_mul_tag_next").select2("data", next_val_list);
    $("input.ct_candidate_mul_tag_next").attr('action-data', JSON.stringify(next_val_list));
    refresh_candidate_table();
}

function manage_relate(tag_id) {
    init_prev_relate_mul_select(tag_id);
    init_relate_mul_select(tag_id);
    init_next_relate_mul_select(tag_id);
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_relate_list/',
        type: 'POST',
        data: { "tag_id": tag_id },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
                            
            $("input.ct_mul_tag_prev").select2("data", result.prev_list);  
            $("input.ct_mul_tag_relate").select2("data", result.relate_list);  
            $("input.ct_mul_tag_next").select2("data", result.next_list);  

            $('#update_relate_model #btn_update_tag_relate').attr('onclick', 'do_update_tag_relate('+ tag_id + ')');
            $("#update_relate_model").modal('show');
        }
    });
}

function do_update_tag_relate(tag_id) {
    prev_list = $("input.ct_mul_tag_prev").val();
    relate_list = $("input.ct_mul_tag_relate").val();
    next_list = $("input.ct_mul_tag_next").val();
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#update_relate_model").modal('hide');
        }
    });

}

function init_prev_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_prev").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/interest_graphs/content_tag_mgr/get_tag_list_with_query/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });
}

function init_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_relate").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/interest_graphs/content_tag_mgr/get_tag_list_with_query/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function init_next_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_next").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/interest_graphs/content_tag_mgr/get_tag_list_with_query/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function upload_file() {
    $("#upload_busy").show();
    $("#batch_file_name").val("");
    var form_data = new FormData($("#formid")[0]); 
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/handle_uploaded_file/',
        type: 'POST',  
        data: form_data,  
        cache: false,  
        contentType: false,  
        processData: false,         
        success: function (result) {
            $("#upload_busy").hide();
            if (result.status == 0) {
                $("#batch_file_name").val(result.file_name);
                showMessage("info", "信息", "上传文件成功");
                refresh_table_list();
            } else {
                $("#uplod_file").val("");
                showMessage("error", "失败", result.msg);
            }
        }
    });
}
   
function search_tag() {
    refresh_table_list();
}

function merge_tag() {
    var checkboxlist=$('.ct_allcheck:checked');
    $("#merge_tag_div").html("");
    
    var merge_num = 0;
    radio_html = ""
    checked = 'checked';
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            radio_html += '<label class="radio" style="margin-left:50px;margin-top:0px;"> <input type="radio" name="merge_tag_main_tag" value=' + $(this).attr('tag_id') + ' ' + checked + '>' + $(this).attr('tag_name') + '</label>';
            checked = "";
            merge_num += 1;
        }
    });

    if (merge_num <= 1) {
        showMessage("info", "提示", "合并标签至少需要选择两项！");
        return;
    }

    if (radio_html == "") {
        showMessage("info", "提示", "请选择需要合并的项！");
        return;
    }
            
    $("#merge_tag_div").html(radio_html)
    $("#merge_tag_model").modal('show');
}

function do_merge_tag() {
    var main_tag = ''
    var temp = document.getElementsByName("merge_tag_main_tag");
    for (var i = 0; i < temp.length; i++) {
        if (temp[i].checked)
            main_tag = temp[i].value;
    }

    var checkboxlist=$('.ct_allcheck:checked');
    tag_list = "";
    tag_name_list = "";
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            tag_list += $(this).attr('tag_id')+",";
            tag_name_list += $(this).attr('tag_name')+",";
        }
    });

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/merge_tag/',
        type: 'POST',
        data: { "main_tag": main_tag, "tag_id_list":tag_list, "tag_name_list": tag_name_list},
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#merge_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

function delete_tags(node_id) {
    var checkboxlist=$('.ct_allcheck:checked');
    tag_list = "";
    checkboxlist.each(function(){
        if ($(this).attr('tag_id') != undefined) {
            tag_list+=$(this).attr('tag_id')+",";
        }
    });

    if (tag_list == "") {
        showMessage("info", "提示", "请选择需要删除的项！");
        return;
    }
    $('#delete_table_model #btn_do_delete_ok').attr('onclick', 'do_delete_tags('+node_id+')');
    $("#delete_table_model").modal('show');
}

function do_delete_tags() {
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/delete_tag/',
        type: 'POST',
        data: { "tag_id_list": tag_list },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#delete_table_model").modal('hide');
            refresh_table_list();
        }
    });
}

function update_tag(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_tag/api/search_tag/',
        data: { "query": "NBA", "start": 0, "limit": 10 },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
        }
    });

    $.ajax({
        url: '/interest_graphs/content_tag/api/get_tag_with_id/',
        data: { "id": tag_id },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
        }
    });

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_tag_info/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $('#new_tag_name').val(result.name);
            $('#new_tag_check_status_id').val(result.check_status);
            $("input.ct_select_dict_list_new_1").select2("data", null);  
            $("input.ct_select_dict_list_new_2").select2("data", null);  
            $("input.ct_select_dict_list_new_3").select2("data", null);  
            if (result.first_div != null) {
                import_dict_new_2(result.first_div.id);
                $("input.ct_select_dict_list_new_1").select2("data", result.first_div);  
                if (result.second_div != null) {
                    $("input.ct_select_dict_list_new_2").select2("data", result.second_div);  
                    import_dict_new_3(result.second_div.id);
                    if (result.third_div != null) {
                        $("input.ct_select_dict_list_new_3").select2("data", result.third_div);  
                    }
                }
            } 

            $("input[id='new_tag_tag_type_article']").removeAttr("checked");
            $("input[id='new_tag_tag_type_video']").removeAttr("checked");
            $("input[id='new_tag_book_tag']").removeAttr("checked");
            $("input[id='new_tag_entity_tag']").removeAttr("checked");

            if (result.is_article) {
                $("input[id='new_tag_tag_type_article']").prop("checked", true);
            }

            if (result.is_video) {
                $("input[id='new_tag_tag_type_video']").prop("checked", true);
            }

            if (result.is_book_tag) {
                $("input[id='new_tag_book_tag']").prop("checked", true);
            }

            if (result.is_entity_tag) {
                $("input[id='new_tag_entity_tag']").prop("checked", true);
            }

            $('#new_tag_guid').val(result.guid);
            $('#new_tag_alias').val(result.passed_alias);
            
            $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_update_tag(' + tag_id + ')');
            $('#add_new_tag_title').html("修改标签");
            $("#add_new_tag_model").modal('show');
        }
    });

}

function do_update_tag(tag_id) {
    var tag_name = $('#new_tag_name').val();
    var check_status = $('#new_tag_check_status_id').val();
    var parent_id = -1;
    var first_div = $("input.ct_select_dict_list_new_1").val();
    if (first_div != undefined && first_div.trim() != "") {
        parent_id = first_div;
    }
    var second_div = $("input.ct_select_dict_list_new_2").val();
    if (second_div != undefined && second_div.trim() != "") {
        parent_id = second_div;
    }

    var third_div = $("input.ct_select_dict_list_new_3").val();
    if (third_div != undefined && third_div.trim() != "") {
        parent_id = third_div;
    }
    var is_article = $("input[id='new_tag_tag_type_article']").is(':checked');
    if (is_article) {
        is_article = 1;
    } else {
        is_article = 0;
    }
    var is_video = $("input[id='new_tag_tag_type_video']").is(':checked');
    if (is_video) {
        is_video = 1;
    } else {
        is_video = 0;
    }
    var is_book_tag = $("input[id='new_tag_book_tag']").is(':checked');
    if (is_book_tag) {
        is_book_tag = 1;
    } else {
        is_book_tag = 0;
    }
    var is_entity_tag = $("input[id='new_tag_entity_tag']").is(':checked');
    if (is_entity_tag) {
        is_entity_tag = 1;
    } else {
        is_entity_tag = 0;
    }
    var guid = $('#new_tag_guid').val();
    var alias = $('#new_tag_alias').val();
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/update_tag/',
        type: 'POST',
        data: { "name": tag_name, "tag_id": tag_id, "parent_id": parent_id,
                 "check_status": check_status, "is_article": is_article,
                 "is_video": is_video, "is_book_tag": is_book_tag, 
                 "is_entity_tag": is_entity_tag, "alias": alias, 
                 "guid": guid},
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');


            refresh_table_list();
        }
    });    
}

function refresh_table_list() {
    $('#table_list_paginate ul.pagination li').each(function(){
        if($(this).hasClass('active')){
            thisindex=$(this).index();
        }
    });
                        
    $('#table_list_paginate ul.pagination li').each(function(){
        if($(this).index()==thisindex){
            var that=$(this);
            $(this).trigger('click',function(){
                that.addClass('active');
            });
        }
    });
}

function create_new_tag_batch() {
    $('#add_new_tag_title').html("新建标签");
    $('#new_tag_name').val('');
    $('#new_tag_check_status_id').val(0);

    $("input[id='new_tag_tag_type_article']").removeAttr("checked");
    $("input[id='new_tag_tag_type_video']").removeAttr("checked");
    $("input[id='new_tag_book_tag']").removeAttr("checked");
    $("input[id='new_tag_entity_tag']").removeAttr("checked");
    $("input[id='new_tag_tag_type_article']").prop("checked", true);
    $("input[id='new_tag_tag_type_video']").prop("checked", true);
    $("input[id='new_tag_entity_tag']").prop("checked", true);

    import_dict_new_2(-1);
    import_dict_new_3(-1);
    $("input.ct_select_dict_list_new_1").select2("data", null);  
    $("input.ct_select_dict_list_new_2").select2("data", null);  
    $("input.ct_select_dict_list_new_3").select2("data", null);  

    $('#new_tag_guid').val("");
    $('#new_tag_alias').val("");

    $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_create_new_tag()');
    $("#add_new_tag_model").modal('show');
}

function do_create_new_tag() {
    var tag_name = $('#new_tag_name').val();
    var check_status = $('#new_tag_check_status_id').val();
    var parent_id = -1;
    var first_div = $("input.ct_select_dict_list_new_1").val();
    if (first_div != undefined && first_div.trim() != "") {
        parent_id = first_div;
    } else {
        showMessage("info", "提示", "必须选择一级分类！");
        return;
    }
    var second_div = $("input.ct_select_dict_list_new_2").val();
    if (second_div != undefined && second_div.trim() != "") {
        parent_id = second_div;
    }

    var third_div = $("input.ct_select_dict_list_new_3").val();
    if (third_div != undefined && third_div.trim() != "") {
        parent_id = third_div;
    }
    var is_article = $("input[id='new_tag_tag_type_article']").is(':checked');
    if (is_article) {
        is_article = 1;
    } else {
        is_article = 0;
    }
    var is_video = $("input[id='new_tag_tag_type_video']").is(':checked');
    if (is_video) {
        is_video = 1;
    } else {
        is_video = 0;
    }
    var is_book_tag = $("input[id='new_tag_book_tag']").is(':checked');
    if (is_book_tag) {
        is_book_tag = 1;
    } else {
        is_book_tag = 0;
    }
    var is_entity_tag = $("input[id='new_tag_entity_tag']").is(':checked');
    if (is_entity_tag) {
        is_entity_tag = 1;
    } else {
        is_entity_tag = 0;
    }
    var guid = $('#new_tag_guid').val();
    var alias = $('#new_tag_alias').val();
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/create_new_tag_batch/',
        type: 'POST',
        data: { "name": tag_name, "parent_id": parent_id,
                 "check_status": check_status, "is_article": is_article,
                 "is_video": is_video, "is_book_tag": is_book_tag, 
                 "is_entity_tag": is_entity_tag, "alias": alias, 
                 "guid": guid},
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');
            refresh_table_list();
        }
    });
}

function import_dict()
{
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true
            });
        }
    });
}
function import_dict2(first_div_id)
{
    if (first_div_id == -1) {
        $("input.ct_select_dict_list2").val(null).trigger("change");
        $("input.ct_select_dict_list2").select2({
            placeholder: '请先选择一级分类',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true
        });
        return;
    }
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 1, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list2").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true
            });
        }
    });
}

function import_dict_new_1()
{
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_1").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },
            });
        }
    });
}

function import_dict_new_2(first_div_id)
{
    if (first_div_id == -1) {
        $("input.ct_select_dict_list_new_2").val(null).trigger("change");
        $("input.ct_select_dict_list_new_2").select2({
            placeholder: '请先选择一级分类',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true,
            initSelection: function (element, callback) {
                var data = [{id: element.val(), text: element.val()}];
                callback({id: element.val(), text: element.val()});//这里初始化
            },

        });
        return;
    }

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_2").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },

            });
        }
    });
}

function import_dict_new_3(first_div_id)
{
    if (first_div_id == -1) {
        $("input.ct_select_dict_list_new_3").val(null).trigger("change");
        $("input.ct_select_dict_list_new_3").select2({
            placeholder: '请先选择二级分类',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true,
            initSelection: function (element, callback) {
                var data = [{id: element.val(), text: element.val()}];
                callback({id: element.val(), text: element.val()});//这里初始化
            },
        });
        return;
    }

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_3").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },

            });
        }
    });
}

function setDateFormatter(newformat) {
    $.datetimepicker.setDateFormatter({
        parseDate: function (date, format) {
            var d = window.moment;(date, newformat);

            return d.isValid() ? d.toDate() : false;
        },
        formatDate: function (date, format) {

            return window.moment;(date).format(newformat);
        }
    });
}

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10);
}

function init_table()
{
    table_list = $('#table_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/content_tag_mgr/get_tag_list/",
            "type": "POST",
            "data":function(d){
                d.tag_name_list = $("#id_tag_filter_name").val();
                d.start_time = $("#start_update_time").val();
                d.end_time = $("#end_update_time").val();
                d.first_div_id = $("input.ct_select_dict_list").val();
                if (d.first_div_id == "") {
                    d.first_div_id = -1;
                }
                d.second_div_id = $("input.ct_select_dict_list2").val();
                if (d.second_div_id == "") {
                    d.second_div_id = -1;
                }
                if (click_parent_id != null && click_parent_id != "" && d.first_div_id == -1 && d.second_div_id == -1) {
                    d.second_div_id = click_parent_id;
                }
                d.tag_type = $("#tag_type_select").val();
                d.is_book_tag = $("#tag_is_book_select").val();
                d.is_entity_tag = $("#tag_is_entity_select").val();
                d.src_tag = $("#tag_src_select").val();
                d.alias_check_status = $("#alias_check_status_select").val();
                d.relate_check_status = $("#relate_check_status_select").val();
            },
        },
        "pageLength":20,
        "lengthChange": false,
        "sDom": "<'row'<'col-sm-12'tr>><'row'<'col-sm-6'i><'col-sm-6'p>>",
        "language":{
            "sLengthMenu": "test-sL",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "id",
            bSortable: false
        },
        {
            data: "name",
            bSortable: false
        }, {
            data: "path",
            bSortable: false
        }, {
            data: "id",
            bSortable: false
        }, {
            data: "is_book_tag",
            bSortable: false
        }, {
            data: "is_entity_tag",
            bSortable: false
        },{
            data: "guid",
            bSortable: false
        },{
            data: "hot",
            bSortable: true
        },{
            data: "article_num",
            bSortable: true
        },{
            data: "update_time",
            bSortable: true
        },{
            data: "owner_name",
            bSortable: false
        },{
            data: "id",
            bSortable: false
        }
        ],

        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    return "<input type='checkbox' style='margin-left:10px;margin-top: 10px;' class='ct_allcheck' tag_name = '" + full.name + "'tag_id='" + data + "'/>";
                },
            },
            {
                "targets":[1],
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='update_tag(" + full.id + ");'>"+data+"</a>";
                },
            },
            {
                "targets":[2],
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='select_tag_with_parent_id(" + full.parent_id + ");'>"+data+"</a>";
                },
            },
            {
                "targets":[3],
                "render":function(data,type,full){
                    if (full.is_article == 1 && full.is_video == 1) {
                        return "文章&视频";
                    } 
                    
                    if (full.is_article == 1) {
                        return "文章";
                    } 
                    
                    if (full.is_video == 1) {
                        return "视频";
                    }
                    return "";
                 }
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    if (data == 1) {
                        return "是";
                    }
                    return "否";
                 }
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    if (data == 1) {
                        return "是";
                    }
                    return "否";
                 }
            },
            {
                "targets":[6],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[7],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[8],
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='get_tag_articles(" + full.id + ");'>"+data+"</a>";
                 }
            },
            {
                "targets":[9],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[10],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[11],
                "render":function(data,type,full){
                    var ret = '<a href="javascript:" onclick="manage_relate('+data +');">关联</a> ' +
                              '| <a href="javascript:" onclick="candidate_tag_manage('+data+')">候选</a> ' +
                              '| <a href="javascript:" onclick="check_alias('+data+ ',\'' + full.passed_alias + '\',\'' + full.alias + '\')">别名</a> ';
                    return ret;
                 }
            }
        ],
    });
}

function do_add_new_candidate_alias(tag_id) {
    var new_alias = $('#new_alias_edit').val().trim();
    if (new_alias == null || new_alias == undefined || new_alias == "") {
        return;
    }

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/update_tag_alias/',
        type: 'POST',
        data: { "tag_id": tag_id , "added_alias": new_alias },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }

            var passed_alias = [];
            if ($("input.ct_passed_alias_select").attr('action-data') != undefined) {
                passed_alias = JSON.parse($("input.ct_passed_alias_select").attr('action-data'));
            }

            var new_alias_split = new_alias.split('|');
            for (var i = 0; i < new_alias_split.length; ++i) {
                if (new_alias_split[i].trim() == '') {
                    continue;
                }
                passed_alias.push({"id": new_alias_split[i], "text": new_alias_split[i]});
            }
    
            $("input.ct_passed_alias_select").select2("data", passed_alias);
            $("input.ct_passed_alias_select").attr('action-data', JSON.stringify(passed_alias));
            refresh_alias_table();

            global_check_alias += "|" + new_alias;
            refresh_table_list();
            refresh_alias_table();
            $('#new_alias_edit').val("");
            $("#add_new_alias_model").modal('hide');
        }
    });
}

function check_alias(tag_id, passed_alias, alias) {
    var passed_alias_list = [];
    if (passed_alias != null && passed_alias != 'null' && passed_alias != "") {
        var tmp_list = passed_alias.split('|');
        for (var i = 0; i < tmp_list.length; ++i) {
            passed_alias_list.push({"id": tmp_list[i], "text": tmp_list[i]});
        }
    }
    $("input.ct_passed_alias_select").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });
    $("input.ct_passed_alias_select").attr('action-data', JSON.stringify(passed_alias_list));
    $("input.ct_passed_alias_select").select2("data", passed_alias_list);

    global_check_alias = alias;
    refresh_alias_table();
    $('#alias_manager #check_alias_btn').attr('onclick', 'do_check_alias('+ tag_id + ',\'' + alias + '\')');
    $('#btn_add_new_candidate_alias').attr('onclick', 'do_add_new_candidate_alias('+ tag_id + ')');
    $('#new_alias_edit').val("");
    $("#alias_manager").modal('show');
}

function change_candidate_to_pass() {
    var passed_alias = [];
    if ($("input.ct_passed_alias_select").attr('action-data') != undefined) {
        passed_alias = JSON.parse($("input.ct_passed_alias_select").attr('action-data'));
    }
    
    $("input:checked[name='candidate_alias']").each(function(index){
        if($(this)[0].checked){
            passed_alias.push({id:$(this).next('span').text(), text:$(this).next('span').text()});
        }
    });
    $("input.ct_passed_alias_select").select2("data", passed_alias);
    $("input.ct_passed_alias_select").attr('action-data', JSON.stringify(passed_alias));
    refresh_alias_table();
}

function refresh_alias_table() {
    var passed_alias = $("input.ct_passed_alias_select").val().split(',');
    alias = global_check_alias;
    
    var tmp_list = []
    var table_list = "";
    var all_list = "";
    var alias_list = global_check_alias.split('|');
    var row_num = 0;
    for (var i = 0; i < alias_list.length; ++i) {
        if (alias_list[i].trim() == "") {
            continue;
        }

        if (passed_alias.indexOf(''+alias_list[i]) >= 0) {
            continue;
        }

        if (tmp_list.indexOf(''+alias_list[i]) >= 0) {
            continue;
        }

        tmp_list.push(''+alias_list[i])

        table_list += '<th style="white-space:nowrap;overflow:hidden;text-overflow: ellipsis;"><input name="candidate_alias" type="checkbox" value="' + alias_list[i] +'" ><span title="' + alias_list[i]+ '">' + alias_list[i] + '</span></th>'
        row_num += 1;
        if (row_num > 3) {
            all_list += '<tr>' + table_list + '</tr>';
            table_list = "";
            row_num = 0;
        }
    }

    if (row_num > 0) {
        for (var i = row_num; i < 4; ++i) {
            table_list += '<th style="white-space:nowrap;overflow:hidden;text-overflow: ellipsis;"></th>'
        }
        all_list += '<tr>' + table_list + '</tr>';
    }

    if (all_list != "") {
        $('#candidate_alias').html(
            '<div style="margin-top:0px;float:left;"><table class="table" style="table-layout: fixed;word-break:break-all;word-wrap:break-all;font-family: MicrosoftYaHei;font-size:13px;" cellspacing="0" width="100%">'+
            all_list +
            '</table></div>'
        );
    } else {
        $('#candidate_alias').html("没有候选别名！")
    }
}

function do_check_alias(tag_id, alias) {
    var passed_alias = $("input.ct_passed_alias_select").val();
    var not_passed_alias = ""
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/check_alias/',
        type: 'POST',
        data: { "tag_id": tag_id , "passed_alias": passed_alias, "not_passed_alias": not_passed_alias},  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            refresh_table_list();
            $("#alias_manager").modal('hide');
        }
    });
}

function select_tag_with_parent_id(parent_id) {
    click_parent_id = parent_id;
    refresh_table_list();
}

function get_tag_articles(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_check_tag/get_tag_articles/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }

            var tb = document.getElementById('article_view_body');
            var rowNum=tb.rows.length;
            for (i=0;i<rowNum;i++) {
                tb.deleteRow(i);
                rowNum=rowNum-1;
                i=i-1;
            }

            var row = document.createElement("tr");
            document.getElementById("article_view_body").appendChild(row);
            var key_cell = document.createElement("td");
            inner_html = "文章标题";
            key_cell.innerHTML = inner_html;
            row.appendChild(key_cell);

            var key_cell = document.createElement("td");
            inner_html = "文章url";
            key_cell.innerHTML = inner_html;
            row.appendChild(key_cell);

            for (var i = 0; i < result.article_list.length; ++i) {
                var row = document.createElement("tr");
                document.getElementById("article_view_body").appendChild(row);
                var key_cell = document.createElement("td");
                inner_html = result.article_list[i].title;
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);

                var key_cell = document.createElement("td");
                inner_html = '<a href="' + result.article_list[i].url +'" target="_blank">' + result.article_list[i].url  + '</a> '; 
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);
            }
            $("#article_view_table").modal('show');
        }
    });
}

function turn_to_article_page(url) {
    window.location.href=url;
}

function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function() {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function() {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function(a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function(a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return + Globalize.parseDate(a)
                }
                return a
            },
            _format: function(a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function() {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}

function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}
