var table_list = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var candidate_obj = null;
var click_parent_id = null;
$(function () {
    if ($('#global_parent_id').val() != undefined && $('#global_parent_id').val() != -1) {
        click_parent_id = $('#global_parent_id').val();
    }
    init_table();
    $("#table_list.table-bordered").css("border", "none");
    $("#table_list").parent("div.col-sm-12").css("padding-right", "13px");
    $('#start_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });
    $('#end_update_time').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        todayButton:false
    });

    $(document).on("change", "#id_tag_filter_name", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });
    $(document).on("change", "#start_update_time", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });
    $(document).on("change", "#end_update_time", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });
    $(document).on("change", "#tag_type_select", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });
    $(document).on("change", "#check_status_select", function (e) {
        click_parent_id = null;
        table_list.ajax.reload();
    });


    $("#uplod_file").change(function() {
        if ($("#uplod_file").val() != "") {
            upload_file();
        }
    });

    import_dict_new_1();
    import_dict_new_2(-1);
    import_dict_new_3(-1);
    $(document).on("change", "input.ct_select_dict_list_new_1", function (e) {
        import_dict_new_2(-1);
        import_dict_new_3(-1);
        if(e.added != undefined)
        {
            import_dict_new_2(e.added.id);
        }
    });

    $(document).on("change", "input.ct_select_dict_list_new_2", function (e) {
        import_dict_new_3(-1);
        if(e.added != undefined)
        {
            import_dict_new_3(e.added.id);
        }
    });

    $(document).on("change", "input.ct_candidate_mul_tag_prev", function (e) {
        if(e.removed != undefined)
        {
            var val_list = [];
            if ($("input.ct_candidate_mul_tag_prev").attr('action-data') != undefined) {
                val_list = JSON.parse($("input.ct_candidate_mul_tag_prev").attr('action-data'));
            }

            var tmp_val_list = [];
            for (var i = 0; i < val_list.length; ++i) {
                if (val_list[i].id == e.removed.id) {
                    continue;
                }
                tmp_val_list.push(val_list[i]);
            }
            $("input.ct_candidate_mul_tag_prev").attr('action-data', JSON.stringify(tmp_val_list));
        }
        refresh_candidate_table();
    });
    $(document).on("change", "input.ct_candidate_mul_tag_relate", function (e) {
        if(e.removed != undefined)
        {
            var val_list = [];
            if ($("input.ct_candidate_mul_tag_relate").attr('action-data') != undefined) {
                val_list = JSON.parse($("input.ct_candidate_mul_tag_relate").attr('action-data'));
            }

            var tmp_val_list = [];
            for (var i = 0; i < val_list.length; ++i) {
                if (val_list[i].id == e.removed.id) {
                    continue;
                }
                tmp_val_list.push(val_list[i]);
            }
            $("input.ct_candidate_mul_tag_relate").attr('action-data', JSON.stringify(tmp_val_list));
        }

        refresh_candidate_table();
    });
    $(document).on("change", "input.ct_candidate_mul_tag_next", function (e) {
        if(e.removed != undefined)
        {
            var val_list = [];
            if ($("input.ct_candidate_mul_tag_next").attr('action-data') != undefined) {
                val_list = JSON.parse($("input.ct_candidate_mul_tag_next").attr('action-data'));
            }

            var tmp_val_list = [];
            for (var i = 0; i < val_list.length; ++i) {
                if (val_list[i].id == e.removed.id) {
                    continue;
                }
                tmp_val_list.push(val_list[i]);
            }
            $("input.ct_candidate_mul_tag_next").attr('action-data', JSON.stringify(tmp_val_list));
        }

        refresh_candidate_table();
    });


    //全选
    $('#checkall').on('change',function(){
        if($(this).is(':checked')){
            $('.ct_allcheck').each(function(){
                $(this).prop('checked',true);
            });
        }else{
            $('.ct_allcheck').each(function(){
                $(this).prop('checked', false);
            });
        }
    });
});

function refresh_table_list() {
    $('#table_list_paginate ul.pagination li').each(function(){
        if($(this).hasClass('active')){
            thisindex=$(this).index();
        }
    });
                        
    $('#table_list_paginate ul.pagination li').each(function(){
        if($(this).index()==thisindex){
            var that=$(this);
            $(this).trigger('click',function(){
                that.addClass('active');
            });
        }
    });
}

function do_update_candidate_relate(tag_id) {
    prev_list = $("input.ct_candidate_mul_tag_prev").val();
    relate_list = $("input.ct_candidate_mul_tag_relate").val();
    next_list = $("input.ct_candidate_mul_tag_next").val();
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#manage_candidate_tag_model").modal('hide');
        }
    });
}

function candidate_tag_manage(tag_id) {
    $("input.ct_candidate_mul_tag_prev").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });
    $("input.ct_candidate_mul_tag_relate").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });
    $("input.ct_candidate_mul_tag_next").select2({
        multiple: true,
        data: [],
        language: 'ch',
        allowClear:true
    });

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_candidate_relate/',
        type: 'POST',
        data: { "tag_id": tag_id },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_candidate_mul_tag_prev").attr('action-data', JSON.stringify(result.prev_ret_list));
            $("input.ct_candidate_mul_tag_relate").attr('action-data', JSON.stringify(result.relate_ret_list));
            $("input.ct_candidate_mul_tag_next").attr('action-data', JSON.stringify(result.next_ret_list));
            $("input.ct_candidate_mul_tag_prev").select2("data", result.prev_ret_list);
            $("input.ct_candidate_mul_tag_relate").select2("data", result.relate_ret_list);
            $("input.ct_candidate_mul_tag_next").select2("data", result.next_ret_list);
            candidate_obj = result.data_list;
            refresh_candidate_table();
            $('#manage_candidate_tag_model #btn_update_candidate_relate').attr('onclick', 'do_update_candidate_relate('+ tag_id + ')');
            $("#manage_candidate_tag_model").modal('show');
        }
    });
}

function refresh_candidate_table() {
    var prev_val_list = $("input.ct_candidate_mul_tag_prev").val().split(',');
    var relate_val_list = $("input.ct_candidate_mul_tag_relate").val().split(',');
    var next_val_list = $("input.ct_candidate_mul_tag_next").val().split(',');
    var table_list = "";
    var all_list = "";
    var row_num = 0;
    for (var i = 0; i < candidate_obj.length; ++i) {
        if (prev_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        if (relate_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        if (next_val_list.indexOf(''+candidate_obj[i].id) >= 0) {
            continue;
        }

        table_list += '<th style="white-space:nowrap;overflow:hidden;text-overflow: ellipsis;"><input name="candidate_tag" type="checkbox" value="' + candidate_obj[i].id +'" ><span title="' + candidate_obj[i].text + '">' + candidate_obj[i].text + '</span></th>'
        row_num += 1;
        if (row_num > 3) {
            all_list += '<tr>' + table_list + '</tr>';
            table_list = "";
            row_num = 0;
        }
    }
        if (row_num > 0) {
            all_list += '<tr>' + table_list + '</tr>';
        }

    if (all_list != "") {
        $('#candidate_tags').html(
            '<div style="margin-top:0px;float:left;"><table class="table" id="candidate_tag_table" style="table-layout: fixed;word-break:break-all;word-wrap:break-all;font-family: MicrosoftYaHei;font-size:13px;" cellspacing="0" width="100%">'+
            all_list +
            '</table></div>'
        );
    } else {
        $('#candidate_tags').html("没有候选标签！")
    }
}

function choosed_as_prev() {
    var prev_val_list = [];
    if ($("input.ct_candidate_mul_tag_prev").attr('action-data') != undefined) {
        prev_val_list = JSON.parse($("input.ct_candidate_mul_tag_prev").attr('action-data'));
    }
    
    $("input:checked[name='candidate_tag']").each(function(index){
        if($(this)[0].checked){
            prev_val_list.push({id:$(this).val(), text:$(this).next('span').text()});
        }
    });
    $("input.ct_candidate_mul_tag_prev").select2("data", prev_val_list);
    $("input.ct_candidate_mul_tag_prev").attr('action-data', JSON.stringify(prev_val_list));
    refresh_candidate_table();
}

function choosed_as_relate() {
    var relate_val_list = [];
    if ($("input.ct_candidate_mul_tag_relate").attr('action-data') != undefined) {
        relate_val_list = JSON.parse($("input.ct_candidate_mul_tag_relate").attr('action-data'));
    }
    
    $("input:checked[name='candidate_tag']").each(function(index){
        if($(this)[0].checked){
            relate_val_list.push({id:$(this).val(), text:$(this).next('span').text()});
        }
    });
    $("input.ct_candidate_mul_tag_relate").select2("data", relate_val_list);
    $("input.ct_candidate_mul_tag_relate").attr('action-data', JSON.stringify(relate_val_list));
    refresh_candidate_table();
}

function choosed_as_next() {
    var next_val_list = [];
    if ($("input.ct_candidate_mul_tag_next").attr('action-data') != undefined) {
        next_val_list = JSON.parse($("input.ct_candidate_mul_tag_next").attr('action-data'));
    }
    
    $("input:checked[name='candidate_tag']").each(function(index){
        if($(this)[0].checked){
            next_val_list.push({id:$(this).val(), text:$(this).next('span').text()});
        }
    });
    $("input.ct_candidate_mul_tag_next").select2("data", next_val_list);
    $("input.ct_candidate_mul_tag_next").attr('action-data', JSON.stringify(next_val_list));
    refresh_candidate_table();
}

function manage_relate(tag_id) {
    init_prev_relate_mul_select(tag_id);
    init_relate_mul_select(tag_id);
    init_next_relate_mul_select(tag_id);
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_relate_list/',
        type: 'POST',
        data: { "tag_id": tag_id },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
                            
            $("input.ct_mul_tag_prev").select2("data", result.prev_list);  
            $("input.ct_mul_tag_relate").select2("data", result.relate_list);  
            $("input.ct_mul_tag_next").select2("data", result.next_list);  

            $('#update_relate_model #btn_update_tag_relate').attr('onclick', 'do_update_tag_relate('+ tag_id + ')');
            $("#update_relate_model").modal('show');
        }
    });
}

function do_update_tag_relate(tag_id) {
    prev_list = $("input.ct_mul_tag_prev").val();
    relate_list = $("input.ct_mul_tag_relate").val();
    next_list = $("input.ct_mul_tag_next").val();
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/update_tag_relate/',
        type: 'POST',
        data: {"tag_id": tag_id, "prev_tag_ids": prev_list, "relate_ids": relate_list, "next_relate_ids":next_list },  
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#update_relate_model").modal('hide');
        }
    });

}

function init_prev_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_prev").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/interest_graphs/content_tag_mgr/get_tag_list_with_query/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });
}

function init_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_relate").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/interest_graphs/content_tag_mgr/get_tag_list_with_query/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function init_next_relate_mul_select(tag_id) {
    $("input.ct_mul_tag_next").select2({
        placeholder: '请选择标签',
        multiple: true,
        ajax: {
            url: '/interest_graphs/content_tag_mgr/get_tag_list_with_query/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                limit:10,
              }
              return query;
            },
            results: function (data) {
                return {
                  results: data
                };
            }
        },
        initSelection: function (element, callback) {
            if (element.attr('action-data') != undefined) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            } else {
                callback(null);//这里初始化
            }
        },
        language: 'ch',
    });

}

function upload_file() {
    $("#upload_busy").show();
    $("#batch_file_name").val("");
    var form_data = new FormData($("#formid")[0]); 
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/handle_uploaded_file/',
        type: 'POST',  
        data: form_data,  
        cache: false,  
        contentType: false,  
        processData: false,         
        success: function (result) {
            $("#upload_busy").hide();
            if (result.status == 0) {
                $("#batch_file_name").val(result.file_name);
                showMessage("info", "信息", "上传文件成功");
            } else {
                $("#uplod_file").val("");
                showMessage("error", "失败", result.info);
            }
        }
    });
}
   
function search_tag() {
    refresh_table_list();
}

function delete_tags(tag_id) {
    var tag_list = "" + tag_id;
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/delete_tag/',
        type: 'POST',
        data: { "tag_id_list": tag_list },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            refresh_table_list();
        }
    });
}

function update_tag(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_tag_info/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $('#new_tag_name').val(result.name);
            $('#new_tag_check_status_id').val(result.check_status);
            $("input.ct_select_dict_list_new_1").select2("data", null);
            $("input.ct_select_dict_list_new_2").select2("data", null);
            $("input.ct_select_dict_list_new_3").select2("data", null);
            if (result.first_div != null) {
                import_dict_new_2(result.first_div.id);
                $("input.ct_select_dict_list_new_1").select2("data", result.first_div);  
                if (result.second_div != null) {
                    $("input.ct_select_dict_list_new_2").select2("data", result.second_div);  
                    import_dict_new_3(result.second_div.id);
                    if (result.third_div != null) {
                        $("input.ct_select_dict_list_new_3").select2("data", result.third_div);  
                    }
                }
            } 

            $("input[id='new_tag_tag_type_article']").removeAttr("checked");
            $("input[id='new_tag_tag_type_video']").removeAttr("checked");
            $("input[id='new_tag_book_tag']").removeAttr("checked");
            $("input[id='new_tag_entity_tag']").removeAttr("checked");

            if (result.is_article) {
                $("input[id='new_tag_tag_type_article']").prop("checked", true);
            }

            if (result.is_video) {
                $("input[id='new_tag_tag_type_video']").prop("checked", true);
            }

            if (result.is_book_tag) {
                $("input[id='new_tag_book_tag']").prop("checked", true);
            }

            if (result.is_entity_tag) {
                $("input[id='new_tag_entity_tag']").prop("checked", true);
            }

            $('#new_tag_guid').val(result.guid);
            $('#new_tag_alias').val(result.passed_alias);
            
            $('#add_new_tag_model #btn_do_add_table_ok').attr('onclick', 'do_update_tag(' + tag_id + ')');
            $('#add_new_tag_title').html("修改标签");
            $("#add_new_tag_model").modal('show');
        }
    });

}

function do_update_tag(tag_id) {
    var tag_name = $('#new_tag_name').val();
    var check_status = $('#new_tag_check_status_id').val();
    var parent_id = -1;
    var first_div = $("input.ct_select_dict_list_new_1").val();
    if (first_div != undefined && first_div.trim() != "") {
        parent_id = first_div;
    }
    var second_div = $("input.ct_select_dict_list_new_2").val();
    if (second_div != undefined && second_div.trim() != "") {
        parent_id = second_div;
    }

    var third_div = $("input.ct_select_dict_list_new_3").val();
    if (third_div != undefined && third_div.trim() != "") {
        parent_id = third_div;
    }
    var is_article = $("input[id='new_tag_tag_type_article']").is(':checked');
    if (is_article) {
        is_article = 1;
    } else {
        is_article = 0;
    }
    var is_video = $("input[id='new_tag_tag_type_video']").is(':checked');
    if (is_video) {
        is_video = 1;
    } else {
        is_video = 0;
    }
    var is_book_tag = $("input[id='new_tag_book_tag']").is(':checked');
    if (is_book_tag) {
        is_book_tag = 1;
    } else {
        is_book_tag = 0;
    }
    var is_entity_tag = $("input[id='new_tag_entity_tag']").is(':checked');
    if (is_entity_tag) {
        is_entity_tag = 1;
    } else {
        is_entity_tag = 0;
    }
    var guid = $('#new_tag_guid').val();
    var alias = $('#new_tag_alias').val();
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/update_tag/',
        type: 'POST',
        data: { "name": tag_name, "tag_id": tag_id, "parent_id": parent_id,
                 "check_status": check_status, "is_article": is_article,
                 "is_video": is_video, "is_book_tag": is_book_tag, 
                 "is_entity_tag": is_entity_tag, "alias": alias, 
                 "guid": guid},
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("#add_new_tag_model").modal('hide');
            refresh_table_list();
        }
    });    
}

function import_dict_new_1()
{
    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_1").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },
            });
        }
    });
}

function import_dict_new_2(first_div_id)
{
    if (first_div_id == -1) {
        $("input.ct_select_dict_list_new_2").val(null).trigger("change");
        $("input.ct_select_dict_list_new_2").select2({
            placeholder: '请先选择一级分类',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true,
            initSelection: function (element, callback) {
                var data = [{id: element.val(), text: element.val()}];
                callback({id: element.val(), text: element.val()});//这里初始化
            },

        });
        return;
    }

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_2").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },

            });
        }
    });
}

function import_dict_new_3(first_div_id)
{
    if (first_div_id == -1) {
        $("input.ct_select_dict_list_new_3").val(null).trigger("change");
        $("input.ct_select_dict_list_new_3").select2({
            placeholder: '请先选择二级分类',
            multiple: false,
            data: [],
            language: 'ch',
            allowClear:true,
            initSelection: function (element, callback) {
                var data = [{id: element.val(), text: element.val()}];
                callback({id: element.val(), text: element.val()});//这里初始化
            },
        });
        return;
    }

    $.ajax({
        url: '/interest_graphs/content_tag_mgr/get_div_list/',
        type: 'POST',
        data: { "div_level": 0, "first_level_id": first_div_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            $("input.ct_select_dict_list_new_3").select2({
                placeholder: '请添加你想要分类',
                multiple: false,
                data: result.div_list,
                language: 'ch',
                allowClear:true,
                initSelection: function (element, callback) {
                    var data = [{id: element.val(), text: element.val()}];
                    callback({id: element.val(), text: element.val()});//这里初始化
                },

            });
        }
    });
}

function setDateFormatter(newformat) {
    $.datetimepicker.setDateFormatter({
        parseDate: function (date, format) {
            var d = window.moment;(date, newformat);

            return d.isValid() ? d.toDate() : false;
        },
        formatDate: function (date, format) {

            return window.moment;(date).format(newformat);
        }
    });
}

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10);
}

function init_table()
{
    table_list = $('#table_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/content_tag_mgr/get_tag_list/",
            "type": "POST",
            "data":function(d){
                d.tag_name_list = $("#id_tag_filter_name").val();
                d.start_time = $("#start_update_time").val();
                d.end_time = $("#end_update_time").val();
                d.tag_type = $("#tag_type_select").val();
                d.check_status = $("#check_status_select").val();
                if (click_parent_id != null) {
                    d.check_status = 2;
                    d.second_div_id = click_parent_id;
                }
                d.type = 1;
            },
        },
        "pageLength":20,
        "lengthChange": false,
        "sDom": "<'row'<'col-sm-12'tr>><'row'<'col-sm-6'i><'col-sm-6'p>>",
        "language":{
            "sLengthMenu": "test-sL",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "name",
            bSortable: false
        }, {
            data: "path",
            bSortable: false
        }, {
            data: "guid",
            bSortable: false
        },{
            data: "hot",
            bSortable: true
        },{
            data: "article_num",
            bSortable: false
        },{
            data: "update_time",
            bSortable: true
        },{
            data: "owner_name",
            bSortable: false
        },{
            data: "check_status",
            bSortable: false
        },{
            data: "id",
            bSortable: false
        }
        ],

        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    return "<a title='"+data+"' href='#' onclick='update_tag(" + full.id + ");'>"+data+"</a>";
                },
            },
            {
                "targets":[1],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[2],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[3],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    return "<a href='#' onclick='get_tag_urls(" + full.id + ");'>查看</a>";
                 }
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[6],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[7],
                "render":function(data,type,full){
                    if (full.is_deleted) {
                        return "<span title='已删除'>已删除</span>";
                    } else {
                        if (data == 0) {
                            return "<span title='待审核'>待审核</span>";
                        } else if (data == 1) {
                            return "<span title='审核拒绝'>审核拒绝</span>";
                        } else if (data == 3) {
                            return "<span title='审核通过'>审核通过</span>";
                        }
                    }
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[8],
                "render":function(data,type,full){
                    var ret = ''
                    /*'<a href="javascript:" onclick="manage_relate('+data +');">关联</a> ' +
                              '| <a href="javascript:" onclick="candidate_tag_manage('+data+')">候选</a> ';*/
                    if (full.is_deleted) {
                        ret += '<a href="javascript:" onclick="recover_deleted_tag('+data+')">恢复</a> ';
                    } else if (full.check_status == 0) {
                        ret += '<a href="javascript:" onclick="pass_tag_check('+data+')">通过</a> ';
                        ret += '| <a href="javascript:" onclick="reject_tag_check('+data+')">拒绝</a> ';
                        ret += '| <a href="javascript:" onclick="delete_tags('+data+')">删除</a> ';
                    } else if (full.check_status == 1) {
                        ret += '<a href="javascript:" onclick="pass_tag_check('+data+')">通过</a> ';
                        ret += '| <a href="javascript:" onclick="delete_tags('+data+')">删除</a> ';
                    } else if (full.check_status == 3) {
                        ret += '<a href="javascript:" onclick="reject_tag_check('+data+')">拒绝</a> ';
                        ret += '| <a href="javascript:" onclick="delete_tags('+data+')">删除</a> ';
                    } else {
                        ret += '<a href="javascript:" onclick="delete_tags('+data+')">删除</a> ';
                    }
                    return ret;
                 }
            }
        ],
    });
}

function get_tag_urls(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_check_tag/get_tag_urls/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }

            var tb = document.getElementById('url_view_body');
            var rowNum=tb.rows.length;
            for (i=0;i<rowNum;i++) {
                tb.deleteRow(i);
                rowNum=rowNum-1;
                i=i-1;
            }

            var row = document.createElement("tr");
            document.getElementById("url_view_body").appendChild(row);
            var key_cell = document.createElement("td");
            inner_html = "url";
            key_cell.innerHTML = inner_html;
            row.appendChild(key_cell);

            for (var i = 0; i < result.url_list.length; ++i) {
                var row = document.createElement("tr");
                document.getElementById("url_view_body").appendChild(row);
                var key_cell = document.createElement("td");
                inner_html = '<a href="' + result.url_list[i] +'" target="_blank">' + result.url_list[i]  + '</a> '; 
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);
            }
            $("#url_view_model").modal('show');
        }
    });
}

function recover_deleted_tag(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_check_tag/recover_deleted_tag/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            refresh_table_list();
        }
    });    
}

function pass_tag_check(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_check_tag/pass_tag_check/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            refresh_table_list();
        }
    });    
}

function reject_tag_check(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_check_tag/reject_tag_check/',
        type: 'POST',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            refresh_table_list();
        }
    });    
}

function update_table_users(table_id) {
    $('#table_managers_select').html("");
    $('#table_users_select').html("");
    var url = "/interest_graphs/shuqi_toufang/get_all_user_list/";
    $.ajax({
        type: "post",
        url: url,
        async: false,
        dataType: "json",
        success: function (result) {
            if (result.status) {
                // alert(result.msg);
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            } else {
                $.ajax({
                    url: '/interest_graphs/shuqi_toufang/get_author_list/',
                    type: 'POST',
                    data: { "table_id": table_id, "auth_tag": 1 },
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success: function (sub_result) {
                        var reportTo = "";
                        if (sub_result.status != 0) {
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                reportTo += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                            }
                        } else {
                            var arr = new Array();
                            for (var i = 0; i < sub_result.data.length; ++i) {
                                arr.push(sub_result.data[i].user_id);
                            }
                            var users = result.user_list;
                            for (var i = 0; i < users.length; i++) {
                                if (arr.indexOf(users[i].id) >= 0) {
                                    reportTo += "<option value='" + users[i].id + "' selected='true'>" +
                                    users[i].name + "</option>";
                                } else {
                                    reportTo += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }
                        }
                        $("#table_managers_select").append(reportTo);
                    }
                });
                $.ajax({
                    url: '/interest_graphs/shuqi_toufang/get_author_list/',
                    type: 'POST',
                    data: { "table_id": table_id, "auth_tag": 2 },
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success: function (sub_result) {
                        var reportTo = '';
                        if (sub_result.status != 0) {
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                reportTo += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                            }
                        } else {
                            var arr = new Array();
                            for (var i = 0; i < sub_result.data.length; ++i) {
                                arr.push(sub_result.data[i].user_id);
                            }
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                if (arr.indexOf(users[i].id) >= 0) {
                                    reportTo += "<option value='" + users[i].id + "' selected>" +
                                    users[i].name + "</option>";
                                } else {
                                    reportTo += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }
                        }
                        $("#table_users_select").append(reportTo);
                        init_select2_async();
                        $("#fix_table_users_model").modal('show');
                        $('#fix_table_users_model #btn_update_table_user_ok').attr('onclick', 'do_update_table_user('+table_id+')');
                    }
                });
            }
        }
    });
}

function do_update_table_user(table_id) {
    var auth_list = '';
    if ($("#table_managers_select").val() != null) {
        auth_list = $("#table_managers_select").val().join(',');
    }
    $.ajax({
        url: '/interest_graphs/shuqi_toufang/update_table_author/',
        type: 'POST',
        data: { "table_id": table_id, "auth_id_list": auth_list, "auth_tag": 1 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改管理员失败", result.msg);
                return;
            }
        }
    });

    var auth_list = '';
    if ($("#table_users_select").val() != null) {
        auth_list = $("#table_users_select").val().join(',');
    }

    $.ajax({
        url: '/interest_graphs/shuqi_toufang/update_table_author/',
        type: 'POST',
        data: { "table_id": table_id, "auth_id_list": auth_list, "auth_tag": 2 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改使用者失败", result.msg);
                return;
            }
            refresh_table_list();
            $("#fix_table_users_model").modal('hide');
        }
    });
}

function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}
