var table_search_tag_list = null;
$(function(){
    $("#main_search").on('change', function(){
        $("#search_result #search_val").html('搜索"'+$(this).val().trim()+'"');
        $("#table_search_tag_list tbody").html('');
        if(!table_search_tag_list)
        {
            $("#page-wrapper").html($("#search_result").html());
            init_table_search_tag_list();
        }
        else
        {
            table_search_tag_list.ajax.reload();
        }
    });
});
function init_table_search_tag_list()
{
    table_search_tag_list = $('#table_search_tag_list').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": '/interest_graphs/tag/list/',
                "type": "POST",
                "data": function(d){
                    d['search[value]']= $("#main_search").val().trim();
                    d.with_path = 1;
                    d.search_all= 1;
                },
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0 || json.recordsTotal == 0)
                    {
                        var uid = $("#main_search").val().trim();
                        var url = "/interest_graphs/users_analysis/get_user_base_info/";
                        var post_data = {uid:uid};
                        var result = makeAPost(url, post_data);
                        if(result.status == 0)
                        {
                            window.location.href = '/interest_graphs/users_analysis/user_index/?uid='+uid;
                        }
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "lengthChange": false,
            "language":{
                "sLengthMenu": "显示 _MENU_ 条记录",
                "sInfo": "显示第 _START_ 至 _END_ 条记录，共 _TOTAL_ 条",
                "sInfoEmpty": "显示第 0 至 0 条记录，共 0 条",
                "zeroRecords": '结果为空',
                "paginate":{
                    'next':'下一页',
                    'previous':'上一页',
                },
            },
            columns: [
            {
                data: "name",
                bSortable: false
            },{
                data: "path",
                bSortable: false
            },{
                data: "desc",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[0],
                    "render":function(data,type,full){
                        return '<a href="/interest_graphs/tag/detail/?id='+full.id+'">'+data+'</a>';
                    },
                },
            ]
        });
}
function return_prev_page()
{
    if ((navigator.userAgent.indexOf('MSIE') >= 0) && (navigator.userAgent.indexOf('Opera') < 0)){ // IE
            if(history.length > 0){
                window.history.go( -1 );
            }else{
                window.opener=null;window.close();
            }
    }
    else{ //非IE浏览器  
        if (navigator.userAgent.indexOf('Firefox') >= 0 ||
            navigator.userAgent.indexOf('Opera') >= 0 ||
            navigator.userAgent.indexOf('Safari') >= 0 ||
            navigator.userAgent.indexOf('Chrome') >= 0 ||
            navigator.userAgent.indexOf('WebKit') >= 0){

            if(window.history.length > 1){
                window.history.go( -1 );
            }else{
                window.opener=null;window.close();
            }
        }else{ //未知的浏览器  
            window.history.go( -1 );
        }
    }
}
