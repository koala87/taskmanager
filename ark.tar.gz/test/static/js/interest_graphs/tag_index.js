var page_size = 10;
var init_html_add_file_modal = '';
$(function(){
    init_statistic_info();
    init_tag_group_list();
    $(document).on('click', '#field_group_list .field_group_item .group_value', function(){
        if(!$(this).parent().hasClass('active'))
        {
            $('#field_group_list .field_group_item').removeClass('active');
            $(this).parent().addClass('active');
        }
        $('#block_left .field_item').remove();
        $("#btn_load_more").trigger('click');
    });
    $(document).on('mouseover', '#field_group_list .field_group_item .group_value', function(){
        $(this).nextAll('.glyphicon').show();
    });
    $(document).on('mouseleave', '#field_group_list .field_group_item', function(){
        $(this).find('.glyphicon').hide();
    });

    $(document).on('mouseover', '.field_item', function(){
        $(this).addClass('active');
    });
    $(document).on('mouseleave', '.field_item', function(){
        $(this).removeClass('active');
    });
});
function init_statistic_info()
{
    var url = '/interest_graphs/tag/statistic/';
    var post_data = {};
    var callback = callback_init_statistic_info;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_init_statistic_info(result, args)
{
    if(result.status == 0)
    {
        $("#block_top .block_top_field_num").html(result.data.section_num);
        $("#block_top .block_top_tag_num").html(result.data.tag_num);
        $("#block_top .block_top_user_num").html(result.data.user_num);
    }
}
function load_filed_list()
{
    $("#btn_load_more").button('loading');
    setTimeout(function(){
        $("#btn_load_more").button('reset');
        $("#btn_load_more").button('loading');
        var url = '/interest_graphs/tag/list/';
        var post_data = {length:page_size, parent_id:0};
        post_data.tag_type = $("#field_group_list ul .field_group_item.active").attr('action-data');
        var pre_update_time = $(".field_item:last").attr('action-data-updatetime');
        if(pre_update_time != undefined)
        {
            post_data['start_update_time'] = pre_update_time;
        }
        var callback = callback_load_filed_list;
        var args = {};
        makeAPost(url, post_data, true, callback, args);
    }, 1);
}
function callback_load_filed_list(result, args)
{
    if(result.status != 0)
    {
        $("#btn_load_more").button('reset');
        ark_notify(result);
        return;
    }
    for(var i in result.data)
    {
        var html = '<div class="field_item" action-data="'+result.data[i].id+'" action-data-updatetime="'+result.data[i].update_time+'">\
                        <div>\
                            <span class="field_name"><a href="/interest_graphs/tag/detail/?id='+result.data[i].id+'">'+result.data[i].name+'</a></span>\
                            <span class="field_tag_num">标签数：'+result.data[i].size+'</span>\
                            <span class="field_owner_name">创建人：'+result.data[i].owner+'</span>\
                            <span class="field_create_time">更新时间：'+result.data[i].update_time+'</span>\
                        </div>\
                        <div>\
                            <div class="field_op">\
                                <a href="/interest_graphs/tag/detail/?id='+result.data[i].id+'">查看</a>\
                                <a onclick="delete_field('+result.data[i].id+')">删除</a>\
                            </div>\
                            <div class="field_desc">描述：'+(result.data[i].desc ? result.data[i].desc : '无')+'</div>\
                        </div>\
                    </div>';
        $("#div_loadmore").before(html);
        $(".field_item:last .field_name a").mouseover(function(){
                var field_id_preview = $(this).parents(".field_item").attr('action-data');
                var field_preview_table_id = 'popover_table_'+field_id_preview;
                var option_popover = {
                    html:true,
                    placement:'right',
                    template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content" style="overflow-y: auto;height:223px;"></div></div>',
                    title:'子节点预览',
                    selector:'.field_item .field_name',
                    content:'<table class="table table-bordered" id="'+field_preview_table_id+'"><thead><th>名称</th><th>子节点数目</th><th>描述</th></thead><tbody><tr><td>加载中...</td></tr></tbody></table>',
                    trigger:'click'
                };
                $(this).popover(option_popover);
                $(this).popover('show');
                //获取预览数据
                var url = '/interest_graphs/tag/list/';
                var post_data = {parent_id:field_id_preview};
                var callback = callback_show_field_id_preview;
                var args = {field_id:field_preview_table_id};
                makeAPost(url, post_data, true, callback, args);
            });
        $(".field_item .field_name").parent().mouseleave(function(){
            $(this).find('.popover').popover('hide');
        });
    }
    if(result.data.length < page_size)
    {
        $("#btn_load_more").html('没有更多了');
    }
    else
    {
        $("#btn_load_more").button('reset');
    }
    var left_height = $("#field_group_list").height()+50;
    var right_height = $("#block_left").height();
    if(left_height > right_height)
    {
        $("#block_left").css('min-height', left_height);
    }
}
function add_field()
{
    $("#btn_add_field").button('loading');
    var url = '/interest_graphs/tag/list_profile_attr/';
    var post_data = {};
    var callback = callback_add_field;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_add_field(result, args)
{
    $("#btn_add_field").button('reset');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    //初始化
    if(init_html_add_file_modal)
    {
        $("#addFieldModal .modal-body").html(init_html_add_file_modal);
    }
    else
    {
        init_html_add_file_modal = $("#addFieldModal .modal-body").html();
    }
    for(var i in result.data)
    {
        $("#profile_attr_list").append('<label class="checkbox-inline"><input type="checkbox" name="attr_type" value="'+result.data[i].value_type+'">'+result.data[i].name+'</label>');
    }
    var cur_tag_group = $('#field_group_list .field_group_item.active').attr('action-data');
    $("#addFieldModal #input_set_group_name").val(cur_tag_group);
    $("#addFieldModal #input_set_group_name").attr('action-data', JSON.stringify({id:cur_tag_group,text:$('#field_group_list .field_group_item.active').text()}));
    init_set_group_select2();
    $("#addFieldModal").modal('show');
}
function do_add_field()
{
    $("#addFieldModal #btn_do_add_field_ok").button('loading');
    var url = '/interest_graphs/tag/create_node/';
    var post_data = get_create_field_post_data();
    var callback = callback_do_add_field;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function get_create_field_post_data()
{
    var post_data = {};
    post_data['name'] = $("#addFieldModal #name").val().trim();
    post_data['type'] = $("#addFieldModal input[name='node_type']:checked").val().trim();
    post_data['attrs'] = [];
    $("#addFieldModal input[name='attr_type']:checked").each(function(){
        post_data['attrs'].push($(this).val());
    });
    post_data['interest_time'] = $("#addFieldModal input[name='time_maintain']:checked").val().trim();
    post_data['interest_strength'] = $("#addFieldModal input[name='intensity']:checked").val().trim();
    post_data['desc'] = $("#addFieldModal #desc").val().trim();
    var group_id = $("#addFieldModal #input_set_group_name").val();
    post_data['tag_type'] = group_id;

    return post_data;
}
function callback_do_add_field(result, args)
{
    $("#addFieldModal #btn_do_add_field_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#addFieldModal").modal('hide');
        location.href = '/interest_graphs/tag/detail/?id='+result.data;
    }
}
function delete_field(id)
{
    $("#deleteFieldConfirmModal #btn_do_delete_field_ok").attr('onclick', 'do_delete_field('+id+')');
    $("#deleteFieldConfirmModal").modal('show');
}
function do_delete_field(id)
{
    $("#deleteFieldConfirmModal #btn_do_delete_field_ok").button('loading');
    var url = '/interest_graphs/tag/delete/';
    var post_data = {id:id};
    var callback = callback_do_delete_field;
    var args = {id:id};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_field(result, args)
{
    $("#deleteFieldConfirmModal #btn_do_delete_field_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteFieldConfirmModal").modal('hide');
        $(".field_item[action-data='"+args.id+"']").remove();
    }
}
function callback_show_field_id_preview(result, args)
{
    var cols_num = 4;
    var field_id = args['field_id'];
    var html = '';
    if(result.status != 0)
    {
        html = '预览失败';
    }
    else
    {
        if(result.data.length < 1)
        {
            html = '无子节点数据';
        }
        for(var i in result.data)
        {
            html += '<tr>';
            html += '<td><a href="/interest_graphs/tag/detail/?id='+result.data[i].id+'" targer="_blank">'+result.data[i].name+'</a></td>';
            html += '<td>'+result.data[i].size+'</td>';
            html += '<td>'+result.data[i].desc+'</td>';
            html += '</tr>';
        }
    }
    $("#"+field_id+" tbody").html(html);
}
function init_tag_group_list()
{
    var url = '/interest_graphs/tag/list_tag_group/';
    var post_data = {};
    var callback = callback_init_tag_group_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_init_tag_group_list(result, args)
{
    if(result.status ==0)
    {
        $("#field_group_list ul").empty();
        for(var i in result.data)
        {
            var html = '<li class="field_group_item" action-data="'+result.data[i].id+'"><span class="group_value">'+result.data[i].name+'</span>';
            if(result.data[i].type)
            {
                html += '<span class="glyphicon glyphicon-remove" title="删除" onclick="delete_field_group(this)" aria-hidden="true"></span><span class="glyphicon glyphicon-pencil" title="修改" onclick="edit_field_group(this)" aria-hidden="true"></span></li>';
            }
            $("#field_group_list ul").append(html);
        }
        $("#field_group_list ul").append('<li class="add_group" onclick="add_field_group()"><span style="text-align: center;display: inline-block;"><img src="/static/images/interest_graphs/add_group.png"></img>新建分组</span></li>');
        $("#field_group_list ul li:first .group_value").trigger('click');
    }
}
function add_field_group()
{
    $("#addTagGroupModal #input_group_name").val('');
    $("#addTagGroupModal").modal('show');
}
function do_add_field_group()
{
    var url = '/interest_graphs/tag/create_tag_group/';
    var post_data = {name:$("#addTagGroupModal #input_group_name").val().trim()};
    if(!post_data.name)
    {
        ark_notify({status:1,msg:'名称不能为空'});
        return;
    }
    $("#addTagGroupModal #btn_do_add_field_group_ok").button('loading');
    var callback = callback_create_tag_group;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_create_tag_group(result, args)
{
    $("#addTagGroupModal #btn_do_add_field_group_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#addTagGroupModal").modal('hide');
        init_tag_group_list();
    }
}
function edit_field_group(obj)
{
    var group_id = $(obj).parents(".field_group_item").attr('action-data');
    var group_name = $(obj).parents(".field_group_item").find('.group_value').text();
    $("#editTagGroupModal #input_edit_group_id").val(group_id);
    $("#editTagGroupModal #input_edit_group_name").val(group_name);
    $("#editTagGroupModal").modal('show');
}
function do_edit_field_group()
{
    $("#editTagGroupModal #btn_do_edit_field_group_ok").button('loading');
    var group_id = $("#editTagGroupModal #input_edit_group_id").val();
    var group_name = $("#editTagGroupModal #input_edit_group_name").val().trim();
    var url = '/interest_graphs/tag/update_tag_group/';
    var post_data = {id:group_id, name:group_name};
    var callback = callback_update_tag_group;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_update_tag_group(result, args)
{
    $("#editTagGroupModal #btn_do_edit_field_group_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#editTagGroupModal").modal('hide');
        init_tag_group_list();
    }
}
function delete_field_group(obj)
{
    var group_id = $(obj).parents(".field_group_item").attr('action-data');
    $("#deleteGroupConfirmModal #input_delete_group").val(group_id);
    $("#deleteGroupConfirmModal ").modal('show');
}
function do_delete_field_group()
{
    $("#deleteGroupConfirmModal #btn_do_delete_field_group_ok").button('loading');
    var group_id = $("#deleteGroupConfirmModal #input_delete_group").val();
    var url = '/interest_graphs/tag/delete_tag_group/';
    var post_data = {id:group_id};
    var callback = callback_delete_field_group;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_delete_field_group(result, args)
{
    $("#deleteGroupConfirmModal #btn_do_delete_field_group_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteGroupConfirmModal").modal('hide');
        init_tag_group_list();
    }
}
function init_set_group_select2()
{
    $("#addFieldModal #input_set_group_name").select2({
                placeholder: '请输入分组名称',
                ajax: {
                    url: '/interest_graphs/tag/list_tag_group/', 
                    type:'POST',
                    dataType: 'json',
                    data: function (term, page) {
                      var query = {
                        'query': term,
                      }
                      return query;
                    },
                    results: function (data) {
                        var ret = [];
                        if(data.status ==0)
                        {
                            for(var i in data.data)
                            {
                                ret.push({id:data.data[i].id, text:data.data[i].name});
                            }
                        }
                        return {
                          results: ret
                        };
                    }
                },
                language: 'ch',
                initSelection: function (element, callback) {
                    var attr = JSON.parse(element.attr('action-data'));
                    var data = attr;
                    callback(attr);//这里初始化
                },
            });
}
