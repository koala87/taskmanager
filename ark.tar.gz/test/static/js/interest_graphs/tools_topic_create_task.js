pipeline_history_url = 'http://ark.sm.cn/pipeline/history/';
task_id = null;
scroll_step = null;
auto_incre_run_time = null;
interval_get_task_filter_run_status = null;
interval_get_task_calculate_run_status = null;
filter_task_running = false;
calculate_task_running = false;
table_filter_res = null;
filter_res_page = 0;
filter_res_page_size = 10;
filter_params = {};

calculate_res_page = 0;
calculate_res_cls_num = 8;
calculate_res_page_size = 5;

table_calculate_res = null;

dict_list_select2 = null;
interval_get_get_publish_status = null;
$(function(){
    filter_rules = JSON.parse($("#hidden_filter_rules").val());
    task_id = $("#hidden_task_id").val();
    auto_seek = false;
    if(task_id)
    {
        fill_content();
    }
    scroll_step = $("#task_step_wizard").scrollable({
        onSeek: function(event,i){
            auto_seek = false;
            $("#title_task_step li").removeClass("active").eq(i).addClass("active");
        },
        onBeforeSeek:function(event,i){
            var ret = true;
            interval_get_task_filter_run_status ? clearInterval(interval_get_task_filter_run_status) : '';
            interval_get_task_filter_run_status = null;
            interval_get_task_calculate_run_status ? clearInterval(interval_get_task_calculate_run_status) : '';
            interval_get_task_calculate_run_status = null;
            auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
            auto_incre_run_time = null;
            if(i==1 && !auto_seek){
                $("#btn_start_filter").html('处理中...');
                $("#btn_start_filter").prop('disabled', true);
                var prev_index = $("#task_step_wizard").data('scrollable').getIndex();
                setTimeout(function(){
                    if(prev_index < 1)
                    {
                        filter_task_running = true;
                        ret = upsert_filter_task();
                    }
                    //else if(filter_task_running)
                    else
                    {
                        ret = show_collecting_info();
                    }
                    $("#btn_start_filter").html('开始筛选');
                    $("#btn_start_filter").prop('disabled', false);
                }, 0);
            }
            else if(i==3 && !auto_seek){
                $("#btn_start_calculate").button('loading');
                setTimeout(function(){
                    //if(calculate_task_running)
                    //{
                    //    ret = show_calculating_info();
                    //}
                    //else
                    //{
                    //    ret = update_compute_config();
                    //}
                    ret = update_compute_config();
                    $("#btn_start_calculate").button('reset');
                }, 0);
            }

            return ret;
        }
    });
    if(!task_id)
    {
        $("#btn_add_filter").trigger('click');
    }
    $(document).on('dblclick', "#res_table_filter tbody tr", function(){
        $("#res_table_filter tbody tr").removeClass('selected');
        $(this).addClass('selected');
        var cols = [];
        $("#res_table_filter thead th").each(function(){
            cols.push($(this).text());
        });
        var vals = [];
        $(this).find('td').each(function(){
            vals.push($(this).text());
        });
        var html = '';
        for(var i in cols)
        {
            html += '<tr><td>'+cols[i]+'</td><td>'+vals[i]+'</td></tr>';
        }
        $("#rowDetailModal #table_row_detail tbody").html(html);
        $("#rowDetailModal").modal('show');
    });
});
function upsert_filter_task()
{
    var task_name = $("#input_task_name").val().trim();
    var filter_config = [];
    $(".filter_line").each(function(){
        var filter_key = $(this).find('.select_filter_type').val();
        var filter_val = $(this).find('.input_filter_val').val().trim();
        var filter_alias = $(this).find('.select_filter_alias').val();
        filter_config.push(filter_key+'|'+filter_val+'|'+filter_alias);
    });
    var filter_config_str = '';
    if(filter_config.length > 0)
    {
        filter_config_str = filter_config.join('`');
    }
    var filter_expression_positive = $('#input_condition_exp_positive').val().trim();
    var filter_expression_negative = $('#input_condition_exp_negetive').val().trim();
    var url = task_id ? '/interest_graphs/tools/topic/update_topic_tools/' : '/interest_graphs/tools/topic/create_topic_tools/';
    var post_data = {task_name:task_name, filter_config:filter_config_str, filter_expression_positive:filter_expression_positive, filter_expression_negative:filter_expression_negative};
    task_id ? post_data.task_id = task_id : '';
    result = makeAPost(url, post_data);
    if(result.status != 0)
    {
        ark_notify(result);
        $("#task_step_wizard").data('scrollable').seekTo(0);
        return false;
    }
    task_id ? '' : task_id = result.topic_id;
    show_collecting_info();
}
function show_collecting_info()
{
    do_show_collecting_info();
    interval_get_task_filter_run_status = setInterval(do_show_collecting_info, 30000);
}
function do_show_collecting_info(url, post_data)
{
    var url = '/interest_graphs/tools/topic/get_task_run_status/';
    var post_data = {task_id:task_id, task_type:0};
    var args = {};
    var callback = callback_do_show_collecting_info;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_show_collecting_info(result, args)
{
    if(result.run_status == 0)//成功
    {
        filter_task_running = false;
        $("#task_step_wizard .page:eq(1) .btn_nav").show();
        clearInterval(interval_get_task_filter_run_status);
        auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
        var collecting_html = '<div class="run_success">\
                                   <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>\
                                   <span class="success_text">筛选完成!</span>\
                               </div>\
                               筛选开始时间'+result.start_time+' ，耗时'+result.use_time+'秒。<a target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a>\
                               <div class="run_error_op">\
                                   <button type="button" onclick="filter_result_preview(this, 0)" data-loading-text="处理中..." class="btn btn-default" style="margin-right:20px;">搜索合并筛选日志预览</button>\
                                   <button type="button" onclick="filter_result_preview(this, 1)" data-loading-text="处理中..." class="btn btn-default">smdb筛选日志预览</button>\
                               </div>';
        $('#collecting').html(collecting_html);

    }
    else if(result.run_status == 1)//失败
    {
        filter_task_running = false;
        $("#task_step_wizard .page:eq(1) .btn_nav").hide();
        clearInterval(interval_get_task_filter_run_status);
        auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
        var collecting_html = '<div class="run_error">\
                                   <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>\
                                   <span class="error_text">哎呀，运行失败了，试试重新配置条件再重试吧</span>\
                               </div>\
                               <a style="display: block;" target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a>\
                               <div class="run_error_op">\
                                   <button type="button" onclick="rerun_filter()" class="btn btn-default" style="margin-right:20px;">重试</button>\
                                   <button type="button" onclick="go_back_filter()" class="btn btn-primary interest_graphs_btn_primary">返回</button>\
                               </div>';
        $('#collecting').html(collecting_html);
    }
    else//执行中
    {
        filter_task_running = true;
        if(!auto_incre_run_time)
        {
            $("#task_step_wizard .page:eq(1) .btn_nav").hide();
            //$("#task_step_wizard .page:eq(1) .btn_nav").show();
            var collecting_html = '<span class="collecting_text">筛选正在进行中，请耐心等待！</span>\
                                   <img alt="筛选中" class="collecting_img" draggable="false" src="/static/images/interest_graphs/collecting.gif"></img>\
                                   <a style="display: block;" target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a>\
                                   <div class="collecting_expired">\
                                       <span class="collecting_expired_tip">已运行</span>\
                                       <span class="collecting_expired_time"><font style="font-size:27px;">'+result.use_time+'</font>秒</span>\
                                   </div>';
            $('#collecting').html(collecting_html);
            auto_incre_run_time = setInterval(function(){
                $(".collecting_expired_time font").html(parseInt($(".collecting_expired_time font").html())+1);
            }, 1000);
        }
    }
}
function add_filter(obj)
{
    var cur_form_group = $(obj).parents('.form-group');
    var html = '<div class="col-sm-2"> \
                    <select class="form-control select_filter_type">';
    for(var filter_name in filter_rules)
    {
        html += '<option value="'+filter_rules[filter_name]+'">'+filter_name+'</option>';
    }
    html += '       </select> \
                </div> \
                <div class="col-sm-5"> \
                    <input type="text" class="form-control input_filter_val" placeholder="填写条件，多个用逗号分隔"> \
                </div> \
                <div class="col-sm-2"> \
                    <select class="form-control select_filter_alias"> \
                        <option value="A">A</option> \
                        <option value="B">B</option> \
                        <option value="C">C</option> \
                        <option value="D">D</option> \
                        <option value="E">E</option> \
                        <option value="F">F</option> \
                        <option value="G">G</option> \
                        <option value="H">H</option> \
                        <option value="I">I</option> \
                        <option value="J">J</option> \
                        <option value="K">K</option> \
                        <option value="L">L</option> \
                        <option value="M">M</option> \
                        <option value="N">N</option> \
                        <option value="O">O</option> \
                        <option value="P">P</option> \
                        <option value="Q">Q</option> \
                        <option value="R">R</option> \
                        <option value="S">S</option> \
                        <option value="T">T</option> \
                        <option value="U">U</option> \
                        <option value="V">V</option> \
                        <option value="W">W</option> \
                        <option value="X">X</option> \
                        <option value="Y">Y</option> \
                        <option value="Z">Z</option> \
                    <select> \
                </div> \
                <div class="col-sm-1"> \
                    <span class="glyphicon glyphicon-remove remove_filter" onclick="remove_filter(this)" aria-hidden="true"></span> \
                </div>';
    if(cur_form_group.prev().find('.control-label').html() && cur_form_group.prev().children().length == 1)
    {
        cur_form_group.prev().append(html);
    }
    else
    {
        html = '<div class="form-group filter_line">\
                        <label class="col-sm-2 control-label"></label>'+html+'</div>';
        cur_form_group.before(html);
    }
}
function remove_filter(obj)
{
    var cur_form_group = $(obj).parents('.form-group');
    if(cur_form_group.find('.control-label').html())
    {
        cur_form_group.children().slice(1).remove();
    }
    else
    {
        cur_form_group.remove();
    }
}
function update_compute_config()
{
    var post_data = {};
    post_data.task_id = task_id;
    //post_data.compute_num = $("#caluc_result_num").val().trim();
    post_data.compute_config = $("#calcu_params").val().trim();
    var url = '/interest_graphs/tools/topic/update_topic_tools/';
    result = makeAPost(url, post_data);
    if(result.status != 0)
    {
        ark_notify(result);
        $("#task_step_wizard").data('scrollable').seekTo(2);
        return false;
    }
    show_calculating_info();
}
function show_calculating_info()
{
    do_show_calculating_info();
    interval_get_task_calculate_run_status = setInterval(do_show_calculating_info, 30000);
}
function do_show_calculating_info()
{
    var url = '/interest_graphs/tools/topic/get_task_run_status/';
    var post_data = {task_id:task_id, task_type:1};
    var args = {};
    var callback = callback_do_show_calculating_info;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_show_calculating_info(result, args)
{
    if(result.run_status == 0)//成功
    {
        calculate_task_running = false;
        $("#task_step_wizard .page:eq(3) .btn_nav").show();
        clearInterval(interval_get_task_calculate_run_status);
        auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
        var calculating_html = '<div class="run_success">\
                                   <span class="glyphicon glyphicon-ok-circle" aria-hidden="true"></span>\
                                   <span class="success_text">计算完成!</span>\
                               </div>\
                               <div>计算开始时间'+result.start_time+' ，耗时'+result.use_time+'秒。<a target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a></div>\
                               <div>\
                                   <p>本次共产出了 <font id="res_theme_words_num"></font> 个主题词，部分结果如下：</p>\
                                    <table class="table table-hover table-bordered" id="res_table_calculate" style="table-layout: fixed;" cellspacing="0" width="100%">\
                                    </table>\
                               </div>';
        $('#calculating').html(calculating_html);
        get_publish_status();
        if(!interval_get_get_publish_status)
        {
            interval_get_get_publish_status = setInterval(get_publish_status, 30000);
        }
        calculate_result_preview();
 
    }
    else if(result.run_status == 1)//失败
    {
        calculate_task_running = false;
        $("#task_step_wizard .page:eq(3) .btn_nav").hide();
        clearInterval(interval_get_task_calculate_run_status);
        auto_incre_run_time ? clearInterval(auto_incre_run_time) : '';
        var calculating_html = '<div class="run_error">\
                                   <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>\
                                   <span class="error_text">哎呀，运行失败了，试试重新配置条件再重试吧</span>\
                               </div>\
                               <a target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a>\
                               <div class="run_error_op">\
                                   <button type="button" onclick="rerun_calculate()" class="btn btn-default" style="margin-right:20px;">重试</button>\
                                   <button type="button" onclick="go_back_caclulate()" class="btn btn-primary interest_graphs_btn_primary">返回</button>\
                               </div>';
        $('#calculating').html(calculating_html);
    }
    else//执行中
    {
        calculate_task_running = true;
        if(!auto_incre_run_time)
        {
            $("#task_step_wizard .page:eq(3) .btn_nav").hide();
            //$("#task_step_wizard .page:eq(3) .btn_nav").show();
            var collecting_html = '<span class="calculating_text">正在计算中，请耐心等待！</span>\
                                   <img alt="计算中" class="calculating_img" draggable="false" src="/static/images/interest_graphs/collecting.gif"></img>\
                                   <a style="display: block;" target="_blank" href="'+pipeline_history_url+result.pl_id+'">查看日志</a>\
                                   <div class="calculating_expired">\
                                       <span class="calculating_expired_tip">已运行</span>\
                                       <span class="calculating_expired_time"><font style="font-size:27px;">'+result.use_time+'</font>秒</span>\
                                   </div>';
            $('#calculating').html(collecting_html);
            auto_incre_run_time = setInterval(function(){
                $(".calculating_expired_time font").html(parseInt($(".calculating_expired_time font").html())+1);
            }, 1000);
        }
    }
}
function fill_content()
{
    var url = '/interest_graphs/tools/topic/get_topic_detail/';
    var post_data = {id:task_id};
    var callback = callback_do_fill_content;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_fill_content(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    $("#input_task_name").val(result.task_name);
    $('#input_condition_exp_positive').val(result.filter_expression_positive);
    $('#input_condition_exp_negetive').val(result.filter_expression_negative);
    $("#publishModal #dict_name_select2").val(result.dict_name);
    $("#publishModal #dict_name_select2").attr('action-data', JSON.stringify({id:result.dict_name, text:result.dict_name}));
    var filter_config = result.filter_config ? result.filter_config.split('`') : [];
    for(var i in filter_config)
    {
        var line = filter_config[i].split('|');
        $("#btn_add_filter").trigger('click');
        $(".filter_line:eq("+i+") .select_filter_type").val(line[0]);
        $(".filter_line:eq("+i+") .input_filter_val").val(line[1]);
        $(".filter_line:eq("+i+") .select_filter_alias").val(line[2]);
    }
    $("#caluc_result_num").val(result.compute_num);
    $("#calcu_params").val(result.compute_config);
    auto_seek = true;
    if(result.type == 0)//筛选中
    {
        $("#task_step_wizard").data('scrollable').seekTo(1);
        show_collecting_info();
    }
    else
    {
        $("#task_step_wizard").data('scrollable').seekTo(3);
        show_calculating_info();
    }
}
function rerun_filter()
{
    upsert_filter_task();
}
function go_back_filter()
{
    $("#task_step_wizard").data('scrollable').seekTo(0);
}
function rerun_calculate()
{
    update_compute_config();
}
function go_back_caclulate()
{
    $("#task_step_wizard").data('scrollable').seekTo(2);
}
function filter_result_preview(obj, type)
{
    $(obj).button('loading');
    var url = '/interest_graphs/tools/topic/show_odps_table_datas/';
    var post_data = {task_id:task_id, type:type};
    var callback = callback_filter_result_preview;
    var args = {obj:obj};
    makeAPost(url, post_data, true, callback, args);
}
function callback_filter_result_preview(result, args)
{
    $(args.obj).button('reset');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    if(result.header == undefined || result.header.length == 0)
    {
        ark_notify({status:1, msg:'暂无数据'});
        return;
    }
    table_filter_res = null;
    filter_params = {headers:[]};
    $(args.obj).parent().find('#filter_res_div').remove();
    var html = '<div id="filter_res_div">';
    html += '<table class="table table-hover table-bordered" id="res_table_filter" style="table-layout: fixed;" cellspacing="0" width="100%">\
                    <thead><tr>';
    for(var i in result.header)
    {
        html += '<th>'+result.header[i]+'</th>';
        //filter_params.headers.push({data: result.header[i],bSortable: false});
        filter_params.headers.push({data: i,bSortable: false});
    }
    html += '</tr></thead><tbody></tbody></table>';
    html += '<button type="button" onclick="load_more_filter_res()" class="btn btn-default">换一批</button>';
    html += '</div>';
    filter_params.file_id = result.file_id;
    filter_params.result_no = result.result_no;
    $(args.obj).parent().append(html);
    load_more_filter_res();
}
function load_more_filter_res()
{
    filter_res_page += 1;
    if(table_filter_res)
    {
        table_filter_res.ajax.reload();
    }
    else
    {
        table_filter_res = $('#res_table_filter').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": "/interest_graphs/tools/topic/get_more_result/",
                "type": "POST",
                "data":function(d){
                    d.file_id = filter_params.file_id;
                    d.result_no = filter_params.result_no;
                    d.page = filter_res_page;
                    d.page_size = filter_res_page_size;
                },
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0 || json.item_list == undefined || json.item_list.length == 0)
                    {
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        json.data = json.item_list;
                        json.recordsTotal = json.all_num;
                        json.recordsFiltered = json.all_num;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "paginate":false,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
            },
            columns: filter_params.headers,
        });
    }
}
function calculate_result_preview()
{
    //var table_header_html = '<thead><tr>';
    //for(var i=0; i<calculate_res_cls_num;i++)
    //{
    //    table_header_html += '<th></th>';
    //}
    //table_header_html += '</tr></thead>';
    //$("#res_table_calculate").html(table_header_html);
    load_calculate_res_table();
}
function load_calculate_res_table()
{
    calculate_res_page += 1;
    if(table_calculate_res)
    {
        table_calculate_res.ajax.reload();
    }
    else
    {
        var table_cols = [];
        for(var i=0;i<calculate_res_cls_num;i++)
        {
            table_cols.push({data: i,bSortable: false});
        }
        table_calculate_res = $('#res_table_calculate').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": "/interest_graphs/tools/topic/get_topic_words/",
                "type": "POST",
                "data":function(d){
                    d.task_id = task_id;
                    d.num = calculate_res_cls_num*calculate_res_page_size;
                    d.page = filter_res_page;
                    d.page_size = calculate_res_page_size;
                },
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0)
                    {
                        $("#res_theme_words_num").html(0);
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        $("#res_theme_words_num").html(json.all_num);
                        json.data = [];
                        for(var i=0; i<Math.ceil(json.words_list.length/calculate_res_cls_num); i++)
                        {
                            var line = json.words_list.slice(i*calculate_res_cls_num, (i+1)*calculate_res_cls_num);
                            while(calculate_res_cls_num>line.length)
                            {
                                line.push('');
                            }
                            json.data.push(line);
                        }
                        json.recordsTotal = json.words_list.length;
                        json.recordsFiltered = json.words_list.length;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "paginate":false,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
            },
            columns: table_cols,
        });
    }

}
function publish_to_dict()
{
    $("#publishModal").modal('show');
    if(!dict_list_select2)
    {
        dict_list_select2 = $("#publishModal #dict_name_select2").select2({
            placeholder: '请输入词典名称',
            allowClear: true,
            ajax: {
                url: '/interest_graphs/tag/dict/list/', 
                type:'POST',
                dataType: 'json',
                data: function (term, page) {
                  var query = {
                    'search[value]': term,
                    type:1,
                  }
                  return query;
                },
                results: function (data) {
                    var ret = [];
                    if(data.status ==0)
                    {
                        for(var i in data.data)
                        {
                            ret.push({id:data.data[i].name, text:data.data[i].name});
                        }
                    }
                    return {
                      results: ret
                    };
                }
            },
            createSearchChoice:function(term, data) {
                if ($(data).filter(function() {
                    return this.text.localeCompare(term)===0;
                }).length===0) {
                    return {id:term, text:term};
                }
            },
            initSelection: function (element, callback) {
                var attr = JSON.parse(element.attr('action-data'));
                var data = attr;
                callback(attr);//这里初始化
            },
            language: 'ch',
        });
    }
}
function do_publish_dict()
{
    $("#publishModal #btn_do_publish_dict").button('loading');
    var url = '/interest_graphs/tools/topic/import_to_dict/';
    var post_data = {task_id:task_id, dict_name:$("#publishModal #dict_name_select2").val().trim()};
    var args = {};
    var callback = callback_do_publish_dict;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_publish_dict(result, args)
{
    $("#publishModal #btn_do_publish_dict").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#publishModal").modal('hide');
        get_publish_status();
        if(!interval_get_get_publish_status)
        {
            interval_get_get_publish_status = setInterval(get_publish_status, 30000);
        }
    }
}
function get_publish_status()
{
    var url = '/interest_graphs/tools/topic/get_add_topic_words_to_tag_task_status/';
    var post_data = {task_id:task_id};
    var args = {};
    var callback = callback_get_publish_status;
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_publish_status(result, args)
{
    if(result.status == 0)
    {
        $("#btn_publish_to_dict").nextAll().remove();
        if(result.run_status == 0)//成功
        {
            interval_get_get_publish_status ? clearInterval(interval_get_get_publish_status) : '';
            interval_get_get_publish_status = null;
            if($("#btn_cancel_publish_to_dict").length == 0)
            {
                $("#btn_publish_to_dict").before('<button type="button" id="btn_cancel_publish_to_dict" onclick="cancel_publish_to_dict()" class="btn btn-primary interest_graphs_btn_primary">取消发布</button>');
            }
            $("#btn_publish_to_dict").html('发布配置');
            $("#btn_publish_to_dict").after('<span class="glyphicon glyphicon-ok" aria-hidden="true" style="color:green;"></span><span>已发布</span>');
        }
        else if(result.run_status == 1)//失败
        {
            interval_get_get_publish_status ? clearInterval(interval_get_get_publish_status) : '';
            interval_get_get_publish_status = null;
            $("#btn_publish_to_dict").after('<span class="glyphicon glyphicon-remove" aria-hidden="true" style="color:red;"></span><span>发布失败</span>');
        }
        else if(result.run_status == 2)//执行中
        {
            $("#btn_publish_to_dict").after('<span>发布中...</span>');
        }
    }
}
function cancel_publish_to_dict()
{
    $("#cancelPublishModal").modal('show');
}
function do_cancel_publish_dict()
{
    $("#btn_do_cancel_publish_dict").button('loading');
    var url = '/interest_graphs/tools/topic/cancel_topic_words_to_tag/';
    var post_data = {task_id:task_id};
    var args = {};
    var callback = callback_do_cancel_publish_dict;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_cancel_publish_dict(result, args)
{
    ark_notify(result);
    $("#btn_do_cancel_publish_dict").button('reset');
    if(result.status == 0)
    {
        $("#cancelPublishModal").modal('hide');
        $("#btn_cancel_publish_to_dict").remove();
        $("#btn_publish_to_dict").html('发布到词典');
        $("#btn_publish_to_dict").nextAll().remove();
    }
}
