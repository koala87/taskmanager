$(function () {
    update_table_users()
});

function update_table_users() {
    $('#content_editor_select').html("");
    $('#content_checker_select').html("");
    var url = "/interest_graphs/shuqi_toufang/get_all_user_list/";
    $.ajax({
        type: "post",
        url: url,
        async: false,
        dataType: "json",
        success: function (result) {
            if (result.status) {
                // alert(result.msg);
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            } else {
                $.ajax({
                    url: '/interest_graphs/content_perm/get_user_list/',
                    type: 'POST',
                    data: { },
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success: function (sub_result) {
                        var editor_report = "";
                        var checker_report = "";
                        if (sub_result.status != 0) {
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                editor_report += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                                checker_report += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                            }
                        } else {
                            var editor_arr = new Array();
                            for (var i = 0; i < sub_result.editor_list.length; ++i) {
                                editor_arr.push(sub_result.editor_list[i]);
                            }

                            var users = result.user_list;
                            for (var i = 0; i < users.length; i++) {
                                if (editor_arr.indexOf(users[i].id) >= 0) {
                                    editor_report += "<option value='" + users[i].id + "' selected='true'>" +
                                    users[i].name + "</option>";
                                } else {
                                    editor_report += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }

                            var checker_arr = new Array();
                            for (var i = 0; i < sub_result.checker_list.length; ++i) {
                                checker_arr.push(sub_result.checker_list[i]);
                            }
                            for (var i = 0; i < users.length; i++) {
                                if (checker_arr.indexOf(users[i].id) >= 0) {
                                    checker_report += "<option value='" + users[i].id + "' selected='true'>" +
                                    users[i].name + "</option>";
                                } else {
                                    checker_report += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }
                        }
                        $("#content_editor_select").append(editor_report);
                        $("#content_checker_select").append(checker_report);
                        init_select2_async();
                    }
                });
            }
        }
    });
}

function do_update_table_user() {
    var editor_list = '';
    if ($("#content_editor_select").val() != null) {
        editor_list = $("#content_editor_select").val().join(',');
    }

    var checker_list = '';
    if ($("#content_checker_select").val() != null) {
        checker_list = $("#content_checker_select").val().join(',');
    }

    $.ajax({
        url: '/interest_graphs/content_perm/update_user_list/',
        type: 'POST',
        data: { "editor_list": editor_list, "checker_list": checker_list },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改管理员失败", result.msg);
                return;
            }
            showMessage("info", "成功", "修改管理员成功!");
        }
    });
}

function init_select2_async() {
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function () {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function () {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function (a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function (a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return +Globalize.parseDate(a)
                }
                return a
            },
            _format: function (a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function () {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}

function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}
