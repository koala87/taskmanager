var charts_all = [];
var charts_cur_index = -1;
var uid = $("#input_uid").val();
var snid = null
var table_interest_detail = null;
var intensity_map = {'0':'强','1':'中','2':'弱',}
$(function(){
    $('.VivaTimeline').vivaTimeline({
        carousel: false,
    });
    get_user_base_info();
    get_visit_list();
    var ele_chart_access = 'id_chart_access';
    var display_zone_ele = document.getElementById(ele_chart_access);
    GraphBarMix.refresh(display_zone_ele);
    $(document).on('click', '.chart_table_switch', function(){
        if(!$(this).hasClass('active'))
        {
            $('.chart_table_switch').removeClass('active');
            $(this).addClass('active');
            $(".table_view").toggle();
            $(".chart_view").toggle();
            if($(".table_view").is(':hidden'))
            {
                refresh_interest_graph();
            }
            else
            {
                flush_table_interest_detail();
            }
        }
    });
    $(document).on('click', '.interest_type_switch p', function(){
        $('.interest_type_switch p').removeClass('active');
        $(this).addClass('active');
        refresh_interest_graph();
    });
    $(".interest_type_switch p.active").trigger('click');
    $(document).on('click', '#table_interest_detail .glyphicon-plus', function(){
        $('#table_interest_detail .glyphicon-minus').removeClass('glyphicon-minus').addClass('glyphicon-plus');
        $(this).removeClass('glyphicon-plus');
        $(this).addClass('glyphicon-minus');
        $('#table_interest_detail .interest_detail_subrow').remove();
        var url = "/interest_graphs/users_analysis/get_user_all_tag/";
        var post_data = {uid:uid, first_div:$(this).attr('action-data')};
        var callback = callback_get_user_all_tag;
        var cur_row = $(this).parents('tr');
        cur_row.after('<tr class="interest_detail_subrow"><td>加载中...</td><td></td></tr>');
        var args = {cur_row:cur_row};
        makeAPost(url, post_data, true, callback, args);
    });
    $(document).on('click', '#table_interest_detail .glyphicon-minus', function(){
        $(this).addClass('glyphicon-plus');
        $(this).removeClass('glyphicon-minus');
        $('#table_interest_detail .interest_detail_subrow').remove();
    });
});
function refresh_interest_graph()
{
    var id_interest_chart = 'id_interest_chart';
    scatter_parents_tag_user = [];
    var display_zone_ele = document.getElementById(id_interest_chart);
    GraphScatterUser.refresh(display_zone_ele);
}
function get_user_base_info()
{
    var url = "/interest_graphs/users_analysis/get_user_base_info/";
    var post_data = {uid:uid};
    var callback = callback_get_user_base_info;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_user_base_info(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    snid = result.snid
    for(var i in result.info_list)
    {
        $(".block_item .user_info").append('<div class="user_info_item">\
                                                <span class="item_key">'+result.info_list[i][0]+'：</span>\
                                                <span class="item_value">'+result.info_list[i][1]+'</span>\
                                            </div>');
    }
}
function get_visit_list()
{
    var url = "/interest_graphs/users_analysis/get_visit_list/";
    var post_data = {uid:uid};
    var callback = callback_get_visit_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_visit_list(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    for(var i in result.data_list)
    {
        var cur_day = result.data_list[i].day;
        $(".block_item .VivaTimeline dl").append('<dt>'+cur_day+'</dt>');
        var cur_date_formated = cur_day.substr(0, 4)+'-'+cur_day.substr(4, 2) +'-'+cur_day.substr(6,2);
        for(var j in result.data_list[i].data_list)
        {
            var query = result.data_list[i].data_list[j].query;
            var link = '';
            if(query.indexOf('铜矿_') == 0)
            {
                link = 'http://ark.sm.cn/url_search/other_list/'+format_urlencode(query.substr(3))+cur_date_formated+' to '+cur_date_formated+'/';
            }
            else if(query.indexOf('网页搜索_') == 0)
            {
                link = 'http://ark.sm.cn/query_search/other_list/'+format_urlencode(query.substr(5))+cur_date_formated+' to '+cur_date_formated+'/';
            }
            $(".block_item .VivaTimeline dl").append('<dd class="pos-right clearfix">\
                            <div class="circ"></div>\
                            <div class="time">'+result.data_list[i].data_list[j].time.split(' ')[1]+'</div>\
                            <div class="events">\
                                <div class="events-body" title="'+query+'"><a href="'+link+'" target="_blank">'+query+'</a></div>\
                            </div>\
                        </dd>');
        }
    }
}
function flush_table_interest_detail()
{
    if(table_interest_detail)
    {
        table_interest_detail.ajax.reload();
    }
    else
    {
        table_interest_detail = $('#table_interest_detail').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": "/interest_graphs/users_analysis/user_interest_div_info/",
                "type": "POST",
                "data":function(d){
                    d.limit = 1000;
                    d.uid = uid;
                    d.type = $('.interest_type_switch p.active').attr('action-data');
                },
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0)
                    {
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        json.data = json.data_list;
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "pageLength":10,
            "paginate":false,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
                "paginate":{
                    'next':'下一页',
                    'previous':'上一页',
                },
            },
            "createdRow": function(row, data, dataIndex) {
                $(row).addClass( 'info' );
            },
            columns: [
            {
                data: "word",
                bSortable: false
            }, {
                data: "weight",
                width: "20px",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[0],
                    "render":function(data,type,full){
                        return data+'('+intensity_map[full.weight]+')';
                    },
                },
                {
                    "targets":[1],
                    "render":function(data,type,full){
                        return '<span action-data="'+full.word+'" class="glyphicon glyphicon-plus" aria-hidden="true"></span>';
                     }
                },
            ]

        });

    }
}
function callback_get_user_all_tag(result, args)
{
    if(args.cur_row.find('.glyphicon-minus').length > 0)
    {
        $('#table_interest_detail .interest_detail_subrow').remove();
        var html = '';
        if(result.status != 0)
        {
            html = '<tr class="interest_detail_subrow"><td>加载失败</td></tr>';
        }
        else
        {
            if(result.div_map.length < 1)
            {
                html = '<tr class="interest_detail_subrow"><td>暂无数据</td></tr>';
            }
            for(var i in result.div_map)
            {
                html += '<tr class="interest_detail_subrow"><td>'+i+'：';
                for(var j in result.div_map[i])
                {
                    for(var k in result.div_map[i][j])
                    {
                        html += k+'('+intensity_map[result.div_map[i][j][k]]+ ') ';
                    }
                }
                html += '</td><td></td></tr>';
            }
        }
        args.cur_row.after(html);
    }
}
function view_all_visit_history()
{
    var start_date = get_pre_date(8);
    var end_date = get_pre_date(1);
    var url_snid = format_urlencode(snid);
    if(url_snid == "") {
	url_snid = '\001';
    }
    var url = 'http://ark.sm.cn/session_search/other_list/'+url_snid+start_date+' to '+end_date+'/';
    window.open(url);
}
function format_urlencode(url)
{
    var inner_html = "";
    if (url != "") {
        inner_html_list = url.split('?');
        inner_html = inner_html_list[0];
        for (var iner_idx = 1; iner_idx < inner_html_list.length; ++iner_idx) {
            inner_html += "\003" + inner_html_list[iner_idx];
        }
        inner_html = inner_html.replace(new RegExp("/", 'gm'), '\002');
        inner_html = inner_html.replace(new RegExp("#", 'gm'), '\004');
        inner_html = inner_html + '\001';
    }
    return inner_html;
}
function get_pre_date(offset)
{
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0, 10);
}
