var table_name = null;
var table_odps_table_schema = null;
$(function(){
    init_odps_table_list();
    $("#table_name").on('change', function(){
        flush_odps_table_schema();
    });
});
function init_odps_table_list()
{
    var url = '/interest_graphs/tag/external_profile_get_all_names/';
    var post_data = {};
    var args = {};
    var callback = callback_init_odps_table_list;
    makeAPost(url, post_data, true, callback, args)
}
function callback_init_odps_table_list(result, args)
{
    if(result.status == 0)
    {
        for(var i in result.data)
        {
            $("#table_name").append('<option value="'+result.data[i].id+'">'+result.data[i].seq+': '+result.data[i].name+'</option>');
        }
        $("#table_name").select2({
        placeholder: '请输入odps表名称',
        allowClear: true,
        }).on('select2-open', function(e) {
            var input = $(".select2-drop.select2-display-none.select2-with-searchbox.select2-drop-active input");
            input.val($(this).val() ? $("#s2id_table_name .select2-chosen").text() : '');
        });
    }
}
function flush_odps_table_schema()
{
    if(table_odps_table_schema)
    {
        table_odps_table_schema.ajax.reload();
    }
    else
    {
        table_odps_table_schema = $('#table_odps_schema').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": "/interest_graphs/tag/external_profile_detail/",
                "type": "POST",
                "data":function(d){
                    d.id = $("#table_name").val().trim();
                },
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0)
                    {
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        json.data = json.data.schema;
                        json.recordsTotal = json.data.length;
                        json.recordsFiltered = json.data.length;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            //"pageLength":10,
            "paginate":false,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
                //"paginate":{
                //    'next':'下一页',
                //    'previous':'上一页',
                //},
            },
            //"fnDrawCallback":function(){
            //    $("#table_odps_schema tbody tr").each(function(){
            //        $(this).find('td:first').on('mouseover', function(){
            //            $(this).find('.checkbox_is_main').show();
            //            $(this).find('.col_table_name').css('padding-right', '100px');
            //        });
            //        $(this).find('td:first').on('mouseleave', function(){
            //            $("#table_odps_schema tbody").find('.checkbox_is_main:visible').hide();
            //            $(this).find('.col_table_name').css('padding-right', '0');
            //        });
            //    });
            //    $('#table_odps_schema .checkbox_is_main [name="radio_main_col"]:eq(0)').prop('checked', true);
            //    $('#table_odps_schema .checkbox_is_main [name="radio_main_col"]:eq(0)').trigger('change');
            //},
            columns: [
            {
                data: "name",
                bSortable: false
            }, {
                data: "desc",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[0],
                    "render":function(data,type,full){
                        return data +(full.pk ? '  <img class="main_col_icon" src="/static/images/interest_graphs/main_col_icon.png"></img>' : '');
                    },
                },
                {
                    "targets":[1],
                    "render":function(data,type,full){
                        return data;
                    },
                }]
        });
    }
}
