$(function() {
    window.UserPortrait = {
        get_sel_table: function() {
            return $("[name=sel_source_table]").val();
        },
        get_table_source: function(callback) {
            var url = "source_tables/";
            makeAPost(url, {}, true, function(result) {
                if(result.status != 0) {
                    ark_notify(result);
                }
                if(callback) {
                    callback(result);
                }
            });
        },
        query: function(table_id, uid, callback) {
            var url = "query/?uid=" + uid + "&table_id=" + table_id;

            $.ajax({
                url: url,
                type: "POST",
                async: true,
                traditional: true,
                success: function(result) {
                    if(typeof(callback) != 'undefined') {   
                        callback(result);
                    }
                },
                error: function(XMLHttpRequest, textStatus, error) {
                    result = {'status':1,'msg':'系统出错'};
                    if(typeof(callback) != 'undefined') {   
                        callback(result);
                    }
                }
            });
        }
    }

    UserPortrait.get_table_source(function(result) {
        if(result.status == 0) {
            if(result.data.length == 0) {
                ark_notify({"status": 1, "msg": "没有数据源权限"});
                return;
            }
            var ele = $("[name=sel_source_table]").first();
            ele.select2({
                placeholder: '选择数据源',
                data: result.data,
            });
            ele.val(result.data[0].id.toString()).trigger("change");
        }
    });

    $("input[name=btn_query_user_portrait]").click(function() {
        var table_id = UserPortrait.get_sel_table();
        var uid = $("input[name=input_uid]").first().val();
        if(table_id == "" || uid == "") {
            ark_notify({'status': 1, 'msg': '数据源和uid不能为空'});
            return;
        }
        
        var btn = $(this);
        btn.button('loading');
        var display_div = $("[name=display_user_portrait]");
        display_div.button("loading");
        UserPortrait.query(table_id, uid, function(result) {
            display_div.html(result);
            btn.button('reset');
        });
    });

    document.onkeydown = function(e){
        if(!e){
            e = window.event;
        }
        if((e.keyCode || e.which) == 13){
            console.log(window.location.pathname);
            if(window.location.pathname == '/interest_graphs/shuqi_toufang/user_portrait/') {
                $("input[name=btn_query_user_portrait]").trigger('click');
            }
        }
    }
});