var table_list = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
var upload_file_name = ""

$(function () {
    init_table();
    import_table_list()
    $("#table_list.table-bordered").css("border", "none");
    $("#table_list").parent("div.col-sm-12").css("padding-right", "13px");

    $(document).on("change", "input.qr_select_table_list", function (e) {
        table_list.ajax.reload();
    });

    $(document).on("change", "#id_tag_filter_name", function (e) {
        table_list.ajax.reload();
    });
});
    
function import_table_list()
{
    $.ajax({
        url: '/interest_graphs/shuqi_toufang/get_table_list/',
        type: 'POST',
        data: { "start": 0, "end": 10000 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "失败", result.msg);
                return;
            }
            var data_list = []
            for (var i = 0; i < result.data.length; ++i) {
                data_list.push({"id": result.data[i].id, "text": result.data[i].name})
            }

            $("input.qr_select_table_list").select2({
                placeholder: '选择应用',
                multiple: false,
                data: data_list,
                language: 'ch',
                allowClear:true
            });
        }
    });
}

function init_table()
{
    table_list = $('#table_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/shuqi_toufang/get_people_group_list/",
            "type": "POST",
            "data":function(d){
                if ($("input.qr_select_table_list").val() != null && $("input.qr_select_table_list").val() != undefined && $("input.qr_select_table_list").val() != "") {
                    d.table_id = $("input.qr_select_table_list").val();
                }
                d.tags = $("#id_tag_filter_name").val();
            },
        },
        "pageLength":10,
        "lengthChange": false,
        "sDom": "<'row'<'col-sm-12'tr>><'row'<'col-sm-6'i><'col-sm-6'p>>",
        "language":{
            "sLengthMenu": "test-sL",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "group_name",
            bSortable: false
        }, {
            data: "table_name",
            bSortable: false
        }, {
            data: "type",
            bSortable: false
        }, {
            data: "tag",
            bSortable: false
        }, {
            data: "owner_name",
            bSortable: false
        },{
            data: "create_time",
            bSortable: false
        },{
            data: "update_time",
            bSortable: false
        },{
            data: "people_num",
            bSortable: false
        },{
            data: "group_id",
            bSortable: false
        }
        ],

        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[1],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[2],
                "render":function(data,type,full){
                    return "<span title='动态'>动态</span>";
                 }
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                 }
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[6],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[7],
                "render":function(data,type,full){
                    return "<span title='"+data+"'>"+data+"</span>";
                },
            },
            {
                "targets":[8],
                "render":function(data,type,full){
                    sql = full.sql.replace(new RegExp("'",'gm'),"\\'");

                    var ret = '<a href="javascript:" onclick="download_people_group('+data+')">下载</a> ';
                    return ret;
                },
            }
        ],
    });
}

function download_people_group(group_id) {
    var params = { "group_id": group_id }

    var url = '/interest_graphs/shuqi_toufang/download_people_group/?'+$.param(params);
    location.href = url;
}

function go_to_toufang(group_id, sql, group_name) {
    $.extend({
        StandardPost: function (url, args) {
            var form = $("<form method='post'></form>"),
            input;
            form.attr({ "action": url });
            $.each(args, function (key, value) {
                input = $("<input type='hidden'>");
                input.attr({ "name": key });
                input.val(value);
                form.append(input);
            });
            form.submit();
        }
    });
    var type = get_query_string('type', -1);
    var cid = get_query_string('cid', -1);

    $.StandardPost('http://orion.alibaba-inc.com/launching_platform/#/profiles/detail/', { group_id: group_id, cid: cid, sql: sql, type: type, group_name: group_name });

}

function get_query_string (name, default_val) {
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r != null)
       return  unescape(r[2]);
    return default_val;
}



function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}
