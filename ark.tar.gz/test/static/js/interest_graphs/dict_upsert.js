var table_preview_dict = null;
var preview_post_data = {};
var blacklist = [];
var TYPE_MANUAL = 0;
var TYPE_FILE = 1;
var TYPE_PANGU = 2;
var TYPE_TUPU = 3;
var cur_black_list = [];
var table_file_uploaded_list = null;
var is_create = true;
var dict_id = '';
var sync_context = null;
$(function(){
    dict_id = $("#dict_id").val();
    init_table_file_uploaded_list();
    get_exists_relate_dicts_later_defined();
    $("#source_dict").on('change', function(){
        if(table_preview_dict)
        {
            table_preview_dict.destroy();
            table_preview_dict = null;
        }
        if(is_create)
        {
            $("#addFileModal input, #addFileModal #self_words").val('');
            $("#addFileModal #local_file_path_dsp").html('');
            $("#addFileModal #local_path_url").val('');
            $("#addFileModal #kg_file_path_dsp").html('');
            $("#addFileModal #kg_path_url").val('');
            cur_black_list = [];
            $("#table_dict_parsed tbody").html('')
        }
        $("#div_dict_parsed .parsed_summary").remove();//删除解析结果
        $(".dict_self_config").hide();
        if($(this).val() == TYPE_MANUAL)
        {
            $(".config_self").show();
            $(".config_file").hide();
        }
        else if($(this).val() == TYPE_TUPU)
        {
            $(".config_kg").show();
            $(".config_file").show();
        }
        else if($(this).val() == TYPE_PANGU)
        {
            $(".config_pangu").show();
            $(".config_file").show();
        }
        else if($(this).val() == TYPE_FILE)
        {
            $(".config_local").show();
            $(".config_file").show();
            $(".div_kg_sync").hide();
        }
    });
    $(document).on('change', "#local_path", function(){
        $("#local_file_path_dsp").html($(this).val().split('\\').pop());
        var callback = callback_local_file_sync;
        asyn_ajax_file_upload('local_path', callback);
        return false;
    });
    $(document).on('change', "#kg_file_path", function(){
        $("#kg_file_path_dsp").html($(this).val().split('\\').pop());
        var callback = callback_kg_file_sync;
        asyn_ajax_file_upload('kg_file_path', callback);
        return false;
    });
    $(".btn_sync").on('click', function(){
        $(this).button('loading');
        $("#btn_upsert_dict_source_ok").prop('disabled', true);
        $("#div_dict_parsed .parsed_summary").remove();
        cur_black_list = [];
        $("#table_dict_parsed tbody").html('');
        if(!table_preview_dict)
        {
            init_table_dict_preview();
        }
        else
        {
            table_preview_dict.ajax.reload();
        }
    });
    $("#source_dict").trigger('change');
    $("#addFileModal .form-horizontal").on('change', function(){
        if($("#source_dict").val() != TYPE_MANUAL)
        {
            var str = JSON.stringify(get_post_data());
            var md5_str = $.md5(str);
            if(sync_context != md5_str)
            {
                $("#btn_upsert_dict_source_ok").prop('disabled', true);
            }
            else
            {
                $("#btn_upsert_dict_source_ok").prop('disabled', false);
            }
        }
        else
        {
            $("#btn_upsert_dict_source_ok").prop('disabled', false);
        }
    });
    setInterval(function(){
        if(table_file_uploaded_list)
        {
            table_file_uploaded_list.ajax.reload();
        }
    }, 5000);
});
function add_file()
{
    recover_disabled_ele();
    is_create = true;
    $("#btn_upsert_dict_source_ok").attr('onclick', 'do_create_dict_source()');
    cur_black_list = [];
    $("#addFileModal select option:first").prop('selected', true);
    $("#source_dict").trigger('change');
    $("#addFileModal").modal('show');
}
function update_file(source_id)
{
    recover_disabled_ele();
    is_create = false;
    $("#btn_upsert_dict_source_ok").attr('onclick', 'do_update_dict_source('+source_id+')');
    var url = '/interest_graphs/tag/dict/source_detail/';
    var post_data = {id:source_id};
    result = makeAPost(url, post_data);
    if(result.status !=0)
    {
        ark_notify({status:1,msg:'读取词典来源信息失败!'});
        return;
    }
    $("#source_dict").val(result.data.source.type);
    if(result.data.source.type == TYPE_MANUAL)
    {
        var word_list = [];
        for(var i in result.data.words)
        {
            word_list.push(result.data.words[i][1]);
        }
        $("#self_words").val(word_list.join('\n'));
    }
    else 
    {
        if(result.data.source.type == TYPE_FILE)
        {
            $("#addFileModal #local_file_path_dsp").html('文件已上传');
            //$("#local_path").prop('disabled', true);
        }
        else if(result.data.source.type == TYPE_PANGU)
        {
            $("#addFileModal #pangu_path").val(result.data.source.key);
            $("#addFileModal #pangu_path").prop('disabled', true);
            $("#addFileModal .btn_sync").prop('disabled', true);
        }
        else if(result.data.source.type == TYPE_TUPU)
        {
            $("#addFileModal #kg_path").val(result.data.source.key);
            $("#addFileModal #kg_path").prop('disabled', true);
            if(result.data.whitelist.length > 0)
            {
                $("#addFileModal #kg_file_path_dsp").html('文件已上传');
            }
            $("#addFileModal #kg_filter").val(result.data.source.term_filter);
            $(".config_kg_attr").remove();
            var attr_filter = result.data.source.attr_filter ? JSON.parse(result.data.source.attr_filter) : [];
            for(var i=0; i < attr_filter.length; i++)
            {
                add_kg_attr();
            }
            for(var i in attr_filter)
            {
                $(".config_kg_attr").eq(i).find(".kg_attr_name").val(attr_filter[i].name);
                $(".config_kg_attr").eq(i).find(".kg_attr_key").val(attr_filter[i].key);
                $(".config_kg_attr").eq(i).find("[name='kg_attr_create_dict']").prop('checked', attr_filter[i].is_dict ? true : false);
            }
        }
        $("#table_dict_parsed tbody").html('')
        var html = '';
        for(var i in result.data.words)
        {
            html += '<tr><td>'+result.data.words[i][1]+'</td><td><a href="javascript:" onclick="remove_parsed_line(this, \''+result.data.words[i][1]+'\', \''+result.data.words[i][2]+'\')">删除</a></td></tr>';
        }
        $("#table_dict_parsed tbody").html(html);
        cur_black_list = [];
        for(var i in result.data.blacklist)
        {
            cur_black_list.push({name:result.data.blacklist[i][1], 'guid':result.data.blacklist[i][2]});
        }
    }
    $("#source_dict").prop('disabled', true);
    sync_context = $.md5(JSON.stringify(get_post_data()));
    $("#source_dict").trigger('change');
    $("#addFileModal").modal('show');
}
function callback_local_file_sync(result)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    $("#local_path_url").val(result.data);
    $(".btn_sync").eq(0).trigger('click');
}
function callback_kg_file_sync(result)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    $("#kg_path_url").val(result.data);
}
function init_table_dict_preview()
{
    table_preview_dict = $('#table_dict_parsed').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": '/interest_graphs/tag/dict/source_preview/',
                "type": "POST",
                "data": function(d){
                    var source_val = $("#source_dict").val();
                    d.type = source_val;
                    if(source_val == TYPE_TUPU)
                    {
                        d.key = $("#kg_path").val().trim();
                        d.term_filter = $("#kg_filter").val().trim();
                        var attr_filter_arr = [];
                        $(".config_kg_attr").each(function(){
                            attr_filter_arr.push({
                                name:$(this).find(".kg_attr_name").val().trim(),
                                key:$(this).find(".kg_attr_key").val().trim(),
                                is_dict:$(this).find("[name='kg_attr_create_dict']").is(":checked") ? 1 : 0,
                            });
                        });
                        d.attr_filter = JSON.stringify(attr_filter_arr);

                    }
                    else if(source_val == TYPE_PANGU)
                    {
                        d.key = $("#pangu_path").val().trim();
                    }
                    else if(source_val == TYPE_FILE)
                    {
                        d.cdn_url = $("#local_path_url").val().trim();
                    }
                },
                dataFilter: function(data){
                    $('.btn_sync').button('reset');
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0)
                    {
                        ark_notify(json);
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        $("#btn_upsert_dict_source_ok").prop('disabled', false);
                        sync_context = $.md5(JSON.stringify(get_post_data()));
                        $("#div_dict_parsed .parsed_summary").remove();
                        var main_col_total = 0;
                        for(var i in json.summary)
                        {
                            if(json.summary[i].name)
                            {
                                $("#div_dict_parsed").prepend('<p class="parsed_summary" style="padding-left: 20px;">新增词典: <font color="red">'+json.summary[i].name+'</font>, 共 <font color="red">'+json.summary[i].count+'</font> 个实例</p>');
                            }
                            else
                            {
                                main_col_total = json.summary[i].count;
                            }
                        }
                        var count_limit_tip = main_col_total > 100 ? ',下方预览仅显示前100个' : '';
                        $("#div_dict_parsed").prepend('<p class="parsed_summary" style="padding-left: 20px;">本次共导入 <font color="red">'+main_col_total+'</font> 个实例'+count_limit_tip+'</p>');
                    }
                    return JSON.stringify( json ); // return JSON string
                }
            },
            "lengthChange": false,
            "bPaginate": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '结果为空',
            },
            columns: [
            {
                data: "name",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[1],
                    "render":function(data,type,full){
                        return '<a href="javascript:" onclick="remove_parsed_line(this,  \''+full.name+'\', \''+(full.guid ? full.guid : '')+'\')">删除</a>';
                    },
                }
                ]
        });
}
function do_create_dict_source()
{
    $("#btn_upsert_dict_source_ok").button('loading');
    var url = '/interest_graphs/tag/dict/add_source/';
    var post_data = get_post_data();
    var callback = callback_do_upsert_dict;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function do_update_dict_source(source_id)
{
    $("#btn_upsert_dict_source_ok").button('loading');
    var url = '/interest_graphs/tag/dict/update_source/';
    var post_data = get_post_data();
    post_data['id'] = source_id;
    var callback = callback_do_upsert_dict;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_upsert_dict(result, args)
{
    $("#btn_upsert_dict_source_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#addFileModal").modal('hide');
        table_file_uploaded_list.ajax.reload();
    }
}
function get_post_data()
{
    var file_type = $("#source_dict").val();
    var post_data = {dict_id:dict_id};
    var source_detail = {type:file_type};
    if(file_type == TYPE_MANUAL)
    {
        source_detail['words'] = [];
        words = $("#self_words").val().replace(new RegExp(/ /g), '').split('\n');
        for(var i in words)
        {
            if(words[i])
            {
                source_detail['words'].push(words[i]);
            }
        }
    }
    else if(file_type == TYPE_FILE)
    {
        source_detail['key'] = $("#local_file_path_dsp").html().trim(); 
        source_detail['cdn_url'] = $("#local_path_url").val().trim(); 
        var local_black_list = [];
        for(var i in cur_black_list)
        {
            local_black_list.push(cur_black_list[i].name);
        }
        source_detail['blacklist'] = local_black_list; 
    }
    else if(file_type == TYPE_PANGU)
    {
        source_detail['key'] = $("#pangu_path").val().trim(); 
        var pangu_black_list = [];
        for(var i in cur_black_list)
        {
            pangu_black_list.push(cur_black_list[i].name);
        }
        source_detail['blacklist'] = pangu_black_list; 
    }
    else if(file_type == TYPE_TUPU)
    {
        source_detail['key'] = $("#kg_path").val().trim(); 
        source_detail['term_filter'] = $("#kg_filter").val().trim(); 
        var tupu_black_list = [];
        for(var i in cur_black_list)
        {
            tupu_black_list.push(cur_black_list[i].guid);
        }
        source_detail['blacklist'] = tupu_black_list; 
        source_detail['cdn_url'] = $("#kg_path_url").val().trim(); 
        source_detail['attr_filter'] = [];
        $(".config_kg_attr").each(function(){
            source_detail['attr_filter'].push({
                name:$(this).find(".kg_attr_name").val().trim(),
                key:$(this).find(".kg_attr_key").val().trim(),
                is_dict:$(this).find("[name='kg_attr_create_dict']").is(":checked") ? 1 : 0,
            });
        });
    }
    post_data['source_detail'] = JSON.stringify(source_detail);

    return post_data;
}
function remove_parsed_line(obj, del_item_name, del_term_guid)
{
    cur_black_list.push({name:del_item_name, guid:del_term_guid});
    $(obj).parent().parent().remove();
}
function asyn_ajax_file_upload(file_ele_id, callback)
{
    $.ajaxFileUpload(
    {
        url: '/interest_graphs/tag/dict/upload_file/',
        secureuri: false,
        
        fileElementId :file_ele_id,//file控件id
        dataType : 'json',
        async:true,
        success: function(result) {
            result_data = result;
            callback(result);
        },
        error: function(XMLHttpRequest, textStatus, error) {
            result_data = {'status':1,'msg':'系统出错'};
            callback(result);
        }

    });
}
function init_table_file_uploaded_list()
{
    table_file_uploaded_list = $('#table_file_uploaded_list').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": '/interest_graphs/tag/dict/source_list/',
                "type": "POST",
                "data": function(d){
                    d.dict_id = dict_id;
                },
                dataFilter: function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0)
                    {
                        ark_notify(json);
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    return JSON.stringify( json ); // return JSON string
                }
            },
            "lengthChange": false,
            "bPaginate": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '结果为空',
            },
            columns: [
            {
                data: "type",
                bSortable: false
            },{
                data: "key",
                bSortable: false
            },{
                data: "size",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[0],
                    "render":function(data,type,full){
                        var source_type = data == TYPE_FILE ? '本地上传' : (data == TYPE_PANGU ? '飞天路径' : (data == TYPE_TUPU ? '知识图谱' : '单点新建'));
                        return source_type;
                    },
                },
                {
                    "targets":[1],
                    "render":function(data,type,full){
                        return data;
                    },
                },
                {
                    "targets":[3],
                    "render":function(data,type,full){
                        if(full.progress == undefined || full.progress == 100)
                        {
                            return '<a href="javascript:" onclick="update_file('+full.id+')">修改</a> | <a href="javascript:" onclick="delete_file_source('+full.id+')">删除</a>';
                        }
                        else
                        {
                            return '<div class="progress" style="border: 1px solid #ccc;">\
                                        <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="min-width: 2em;\
                                            width:'+full.progress+'%;">\
                                            '+full.progress+'%\
                                        </div>\
                                    </div>';
                        }
                        //if(full.type == TYPE_MANUAL)
                        //{
                        //    return '<a href="javascript:" onclick="update_file('+full.id+')">筛选</a> | <a href="javascript:" onclick="delete_file_source('+full.id+')">删除</a>';
                        //}
                        //else
                        //{
                        //    return '<a style="color:#ccc;cursor:text;">筛选</a> | <a href="javascript:" onclick="delete_file_source('+full.id+')">删除</a>';
                        //}
                    },
                }
                ]
        });
}
function delete_file_source(source_id)
{
    $("#deleteFileSourceCOnfirmModal #btn_delete_file_source_ok").attr('onclick', 'do_delete_file_source('+source_id+')');
    $("#deleteFileSourceCOnfirmModal").modal('show');
}
function do_delete_file_source(source_id)
{
    $("#btn_delete_file_source_ok").button('loading');
    var url = '/interest_graphs/tag/dict/delete_source/';
    var post_data = {id:source_id};
    var callback = callback_do_delete_file_source;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_file_source(result, args)
{
    $("#btn_delete_file_source_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteFileSourceCOnfirmModal").modal('hide');
        table_file_uploaded_list.ajax.reload();
    }
 
}
function show_black_list()
{
    var html = cur_black_list.length > 0 ? '' : '黑名单为空';
    for(var i in cur_black_list)
    {
        html += '<tr><td>'+cur_black_list[i].name+'</td><td><a href="javascript:" onclick="recover_black_list(this, \''+cur_black_list[i].name+'\', \''+cur_black_list[i].guid+'\')">恢复</a></td></tr>';
    }
    $("#blackListModal table tbody").html(html);
    $("#blackListModal").modal('show');
}
function recover_black_list(obj, name, guid)
{
    for(i in cur_black_list)
    {
        if(cur_black_list[i].name == name && cur_black_list[i].guid == guid)
        {
            cur_black_list.splice(i, 1);
            $(obj).parent().parent().remove();
            $("#table_dict_parsed tbody").append('<tr><td>'+name+'</td><td><a href="javascript:" onclick="remove_parsed_line(this,  \''+name+'\', \''+guid+'\')">删除</a></td>');
            return;
        }
    }
}
function recover_disabled_ele()
{
    $("#local_path").prop('disabled', false);
    $("#addFileModal #pangu_path").prop('disabled', false);
    $("#addFileModal #kg_path").prop('disabled', false);
    $("#source_dict").prop('disabled', false);
    $("#addFileModal .btn_sync").prop('disabled', false);
}
function remove_kg_attr(obj)
{
    $(obj).parents(".config_kg_attr").remove();
    $("#addFileModal .form-horizontal").trigger('change');
}
function add_kg_attr()
{
    var html = '<div class="form-group dict_self_config config_kg config_kg_attr">\
                  <label class="col-sm-2 control-label"></label>\
                  <div class="col-sm-2">\
                    <input type="text" class="form-control kg_attr_name" placeholder="属性名称">\
                  </div>\
                  <div class="col-sm-4">\
                    <input type="text" class="form-control kg_attr_key" placeholder="图谱path">\
                  </div>\
                  <div class="col-sm-2">\
                      <label class="checkbox-inline">\
                        <input type="checkbox" name="kg_attr_create_dict">建立词典\
                      </label>\
                  </div>\
                  <div class="col-sm-1" style="padding-left: 0;">\
                    <span class="glyphicon glyphicon-remove" style="margin-top: 9px;color:red;" title="删除" onclick="remove_kg_attr(this)" aria-hidden="true"></span>\
                  </div>\
              </div>';
    $("#form-group-preview").before(html);
    $("#addFileModal .form-horizontal").trigger('change');
}
function update_relate_dicts()
{
    var cur_dicts_id = [];
    var cur_dicts_data = [];
    $(".relate_dicts_later_defined").each(function(){
        cur_dicts_id.push($(this).attr('action-data'));
        cur_dicts_data.push({id:$(this).attr('action-data'), text:$(this).text().trim()});
    });
    $("#editRelateDictModal #dicts_relate").val(cur_dicts_id.length > 0 ? cur_dicts_id.join(',') : '');
    $("#editRelateDictModal #dicts_relate").attr('action-data', JSON.stringify(cur_dicts_data));
    $("#editRelateDictModal #dicts_relate").select2({
        placeholder: '请输入词典名称',
        multiple: true,
        ajax: {
            url: '/interest_graphs/tag/dict/get_relate_dicts_later_defined/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                'query': term,
                dict_id: dict_id,
                length: 10,
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.data)
                    {
                        ret.push({id:data.data[i].id, text:data.data[i].name});
                    }
                }
                return {
                  results: ret
                };
            }
        },
        initSelection: function (element, callback) {
            var attr = JSON.parse(element.attr('action-data'));
            var data = attr;
            callback(attr);//这里初始化
        },
        language: 'ch',
    });
    $("#editRelateDictModal").modal('show');
}
function get_exists_relate_dicts_later_defined()
{
    var url = '/interest_graphs/tag/dict/get_exists_relate_dicts_later_defined/';
    var post_data = {};
    post_data['id'] = dict_id;
    var callback = callback_get_exists_relate_dicts_later_defined;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_exists_relate_dicts_later_defined(result, args)
{
    $("#list_exist_relate_dict_later_defined").empty();
    if(result.status == 0)
    {
        for(var i in result.data)
        {
            $("#list_exist_relate_dict_later_defined").append('<a action-data="'+result.data[i].id+'" href="/interest_graphs/tag/dict/detail_index/?id='+result.data[i].id+'" class="relate_dicts_later_defined">'+result.data[i].name+'</a>');
        }
        if(result.data.length < 1)
        {
            $("#list_exist_relate_dict_later_defined").html('<span style="margin-top: 7px;display: inline-block;">暂无</span>');
        }
    }
    else
    {
        ark_notify({status:1,msg:'获取词典映射失败'});
    }
}
function do_update_relate_dicts()
{
    $("#btn_do_update_relate_dicts_ok").button('loading');
    var url = '/interest_graphs/tag/dict/update_relate_dicts_later_defined/';
    var post_data = {};
    post_data['cur_id'] = dict_id;
    post_data['dict_ids'] = $("#dicts_relate").val().trim() ? $("#dicts_relate").val().trim().split(',') : [];
    var callback = callback_do_update_relate_dicts;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_update_relate_dicts(result, args)
{
    $("#btn_do_update_relate_dicts_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#editRelateDictModal").modal('hide');
        get_exists_relate_dicts_later_defined();
    }
}
