var table_mapping_list = null;
$(function(){
    get_external_profile_list();
    $("#block_type .external_type").on('click', function(){
        if(!$(this).hasClass('active'))
        {
            $(".external_type").removeClass('active');
            $(this).addClass('active');
            $('.tag_data_list').toggle();
            $('.mapping_block').toggle();
            if(!table_mapping_list)
            {
                init_table_mapping_list();
                init_search_condition_tag();
                init_search_condition_owner();
                init_search_condition_data_name();
            }
        }
    });
    $(document).on('change', "#mapping_obj_select2, #mapping_data_name_select2, #mapping_owner_select2", function(){
        table_mapping_list.ajax.reload();
    });
    if($("#tab_id").val() != 0)
    {
        $("#block_type .external_type:eq(1)").trigger('click');
    }
});
function add_tag_data()
{
    window.location.href = '/interest_graphs/tag/external_profile_add/';
}
function get_external_profile_list()
{
    var url = '/interest_graphs/tag/external_profile_list/';
    var post_data = {};
    var callback = callback_get_external_profile_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_external_profile_list(result, args)
{
    $(".tag_data_list").html('');
    if(result.status == 0)
    {
        for(var i in result.data)
        {
            $(".tag_data_list").append('<div class="tag_block tag_item">\
                                            <div class="tag_detail">\
                                                <span><a href="/interest_graphs/tag/external_profile_update/?id='+result.data[i].id+'">'+result.data[i].name+'</a></span>\
                                                <span>'+result.data[i].table_name+'</span>\
                                                <span>用户数:'+result.data[i].total_record+'</span>\
                                                <span>更新时间:'+result.data[i].last_modify_time+'</span>\
                                            </div>\
                                            <div class="tag_detail_op">\
                                                <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>\
                                                <a href="/interest_graphs/tag/external_profile_update/?id='+result.data[i].id+'">查看</a>\
                                            </div>\
                                        </div>');
        }
    }
    $(".tag_data_list").append('<div class="tag_item new_tag" onclick="add_tag_data()">\
                                    <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>\
                                </div>');
 
}
function init_table_mapping_list()
{
    table_mapping_list = $('#table_mapping_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/tag/external_mapping_list/",
            "type": "POST",
            "data":function(d){
                if($("#mapping_obj_select2").val())
                {
                    d.tag_id = $("#mapping_obj_select2").val();
                }
                if($("#mapping_data_name_select2").val())
                {
                    d.table_name = $("#mapping_data_name_select2").val();
                }
                if($("#mapping_owner_select2").val())
                {
                    d.owner_id = $("#mapping_owner_select2").val();
                }
            },
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "no",
            bSortable: false
        }, {
            data: "path",
            bSortable: false
        }, {
            data: "relate_profiles",
            bSortable: false
        }, {
            data: "owner",
            bSortable: false
        }, {
            data: "update_time",
            bSortable: false
        }, {
            data: "id",
            bSortable: false
        }],
                
        "columnDefs": [
            {
                "targets":[1],
                "render":function(data,type,full){
                    var name_arr = [];
                    for(var i in data)
                    {
                        name_arr.push(data[i].name)
                    }
                    return name_arr.join('-');
                },
            },
            {
                "targets":[2],
                "render":function(data,type,full){
                    var name_arr = [];
                    var map = data ? data.split(',') : [];
                    for(var i in map)
                    {
                        if(map[i])
                        {
                            name_arr.push(map[i].split('=')[0])
                        }
                    }
                    return '<span title="'+data+'">'+name_arr.join(', ')+'</span>';
                },
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    var ret = '<a href="/interest_graphs/tag/external_mapping_update/?id='+data+'">查看</a> | <a href="javascript:" onclick="delete_mapping('+data+')">删除</a>';
                    return ret;
                },
            },
        ]

    });
}
function delete_mapping(id)
{
    $("#deleteMappingModal #btn_delete_mapping").attr('onclick', 'do_delete_mapping('+id+')');
    $("#deleteMappingModal").modal('show');
}
function do_delete_mapping(id)
{
    $("#deleteMappingModal #btn_delete_mapping").button('loading');
    var url = '/interest_graphs/tag/external_mapping_delete/';
    var post_data = {'id':id};
    var callback = callback_do_delete_mapping;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_mapping(result, args)
{
    $("#deleteMappingModal #btn_delete_mapping").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteMappingModal").modal('hide');
        table_mapping_list.ajax.reload();
    }
}
function init_search_condition_tag()
{
    var url = '/interest_graphs/tag/external_mapping_tag_list/';
    var post_data = {};
    var args = {};
    var callback = callback_init_search_condition_tag;
    makeAPost(url, post_data, true, callback, args)
}
function callback_init_search_condition_tag(result, args)
{
    if(result.status == 0)
    {
        for(var i in result.data)
        {
            $("#mapping_obj_select2").append('<option value="'+result.data[i].id+'">'+result.data[i].path+'</option>');
        }
        $("#mapping_obj_select2").select2({
            placeholder: '请输入映射对象名称',
            allowClear: true,
        });
    }
}
function init_search_condition_data_name()
{
    var url = '/interest_graphs/tag/external_profile_get_all_names/'
    var post_data = {};
    var args = {};
    var callback = callback_init_search_condition_data_name;
    makeAPost(url, post_data, true, callback, args)
}
function callback_init_search_condition_data_name(result, args)
{
    if(result.status == 0)
    {
        for(var i in result.data)
        {
            $("#mapping_data_name_select2").append('<option value="'+result.data[i].table_name+'">'+result.data[i].name+'</option>');
        }
        $("#mapping_data_name_select2").select2({
            placeholder: '请输入源数据名称',
            allowClear: true,
        });
    }
}
function init_search_condition_owner()
{
    var url = '/interest_graphs/tag/external_mapping_owners/';
    var post_data = {};
    var args = {};
    var callback = callback_init_search_condition_owner;
    makeAPost(url, post_data, true, callback, args)
}
function callback_init_search_condition_owner(result, args)
{
    if(result.status == 0)
    {
        for(var i in result.data)
        {
            $("#mapping_owner_select2").append('<option value="'+result.data[i].id+'">'+result.data[i].name+'</option>');
        }
        $("#mapping_owner_select2").select2({
            placeholder: '请输入创建者名称',
            allowClear: true,
        });
    }
}
