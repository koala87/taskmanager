var manual_tag_id = 0;
var div_and_no = -1;
var add_div_and = false;
var table_tags_for_search = null;
var intensity_map = [{val:'-1', text:'强度不限'}, {val:'0', text:'强度高'}, {val:'1', text:'强度中'}, {val:'2', text:'强度低'}];
var query_id = $("#input_query_id").val();
var query = $("#input_query").val();
var table_user_list = null;
var table_search_history = null;
var table_favorite_list = null;
$(function(){
    get_select_figure_data();
    $(document).on('click', '.div_or', function(e){
        e.preventDefault();
        e.stopPropagation();
        div_and_no = $('.form_search .condition .div_and').index($(this).parent());
        add_div_and = false;
        show_search_block($(this).attr('action-data-tag-id'));
    });
    $(document).on('click', '.form_search .condition', function(){
        div_and_no = $(this).find('.div_and').length;
        add_div_and = true;
        show_search_block('');
    });
    $(document).on('click', ".div_tag_list .breadcrumb a", function(){
        $(this).parent().nextAll().remove();
        $(".input_tag_search").val('');
        refresh_table_tags_for_search();
    });
    $(document).on('click', ".tag_choosed_item_remove", function(){
        var tag_id = $(this).parent().attr('action-data-tag-id');
        $(this).parent().remove();
        $(".form_search .condition .div_and").eq(div_and_no).find(".div_or[action-data-tag-id='"+tag_id+"']").remove();
        $("#table_tags_for_search td a[action-data='"+tag_id+"']").parent().find('input').prop('checked', false);
        $("#table_tags_for_search td a[action-data='"+tag_id+"']").parent().find('.select_tag_intensity').slideToggle();
        if(tag_id < 0)
        {
            $(".div_manual_add .input_name_manual_add").val();
            $(".div_manual_add .select_name_manual_add option:eq(0)").prop('selected', true);
            $(".div_manual_add .btn_add_manual_tag").attr('onclick', 'add_manual_tag()');
        }
    });
    $(document).on('change', "#table_tags_for_search td label input", function(){
        $(this).parents('td').find('select').slideToggle();
        var tag_id = $(this).parents('td').find('a').attr('action-data');
        var tag_name = $(this).parents('td').find('a').text();
        var path = [];
        $(".div_tag_list .breadcrumb li:not(:first-child)").each(function(){
            path.push($(this).find('a').text());
        });
        var weight = $(this).parents('td').find('select').val();
        if($(this).is(":checked"))
        {
            $(".tag_choosed").append('<span class="tag_choosed_item" action-data-tag-id="'+tag_id+'" action-data-weight="'+weight+'">'+tag_name+'<span class="tag_choosed_item_remove">×</span></span>');
            if(add_div_and)
            {
                $('.form_search .condition').append('<div class="div_and">\
                        <div action-data-tag-id="'+tag_id+'" action-data-tag-path=\''+JSON.stringify(path)+'\' action-data-weight="'+weight+'" class="div_or">\
                            <span class="tag_name">'+tag_name+'</span>\
                            <span class="tag_intensity">('+get_intensity_name_by_val(weight)+')</span>\
                        </div>\
                   </div>');
                add_div_and = false;
            }
            else
            {
                $('.form_search .condition .div_and').eq(div_and_no).append('<div action-data-tag-id="'+tag_id+'" action-data-tag-path=\''+JSON.stringify(path)+'\' action-data-weight="'+weight+'" class="div_or">\
                       <span class="tag_name">'+tag_name+'</span>\
                       <span class="tag_intensity">('+get_intensity_name_by_val(weight)+')</span>\
                   </div>');
            }
        }
        else
        {
            $(".form_search .condition .div_and").eq(div_and_no).find(".div_or[action-data-tag-id='"+tag_id+"']").remove();
            $(".tag_choosed_item[action-data-tag-id='"+tag_id+"']").remove();
        }
    });
    $(document).on('change', "#table_tags_for_search td .select_tag_intensity", function(){
        var tag_id = $(this).parents('td').find('a').attr('action-data');
        $(".tag_choosed .tag_choosed_item[action-data-tag-id="+tag_id+"]").attr('action-data-weight', $(this).val());
        $('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').find('.tag_intensity').html('('+get_intensity_name_by_val($(this).val())+')');
        $('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').attr('action-data-weight', $(this).val());
    });
    $(document).on('keyup', ".input_tag_search", function(){
        refresh_table_tags_for_search();
    });
    if(query)
    {
        refill_condition(query, query_id);
    }
    else
    {
        query = [];
    }
    if(query_id)
    {
        $(".query_op .btn_view_graphs").attr('href', '/interest_graphs/users_analysis/figure/?query_id='+query_id);
        $(".query_op").hide();
        var condition = [];
        query = [];
        $(".form_search .condition .div_and").each(function(){
            if($(this).children().length > 0)
            {
                var or_list = [];
                var query_or = [];
                $(this).find('.div_or').each(function(){
                    or_list.push($(this).find(".tag_name").text() + $(this).find(".tag_intensity").text());
                    query_or.push({
                        parent_list:JSON.parse($(this).attr('action-data-tag-path')),
                        tag_word: $(this).find(".tag_name").text(),
                        tag_id: $(this).attr('action-data-tag-id'),
                        weight:$(this).attr('action-data-weight'),
                        is_div:false,
                    });
                });
                condition.push(or_list.join(','));
                query.push({or_list:query_or});
            }
        });
        $(".query_user_list_head .query_condition").html('条件：'+condition.join('+'));
        if($(".query_user_list").is(':hidden'))
        {
            $(".query_user_list").slideToggle();
        }
        flush_table_user_list();
    }
});
function get_intensity_name_by_val(val)
{
    ret = '';
    for(var i in intensity_map)
    {
        if(intensity_map[i].val == val)
        {
            ret = intensity_map[i].text;
            break;
        }
    }
    return ret;
}
function show_search_block(tag_id)
{
    //$(".form_search .condition .div_and").each(function(){
    //    if($(this).children().length < 1)
    //    {
    //        $(this).remove();
    //    }
    //});
    if($(".div_tag_list").is(":hidden"))
    {
        $(".div_tag_list").slideToggle();
    }
    var path = [];
    if(tag_id == undefined || !tag_id || tag_id < 0)
    {
        path = [{id:"", name:'首页'}];
        if(tag_id < 0)
        {
            var full_path = JSON.parse($('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').attr('action-data-full-path'));
            path = path.concat(full_path);
        }
    }
    else
    {
        var url = '/interest_graphs/tag/detail/';
        var post_data = {'id':tag_id};
        var result = makeAPost(url, post_data);
        if(result.status == 0)
        {
            path = result.data.path;
        }
        else
        {
            path = [{id:"", name:'首页'}];
        }
    }
    $(".div_tag_list .breadcrumb").html('');
    for(var i in path)
    {
        $(".div_tag_list .breadcrumb").append('<li><a action-data="'+path[i].id+'"><font>'+path[i].name+'</font></a></li>');
    }
    if(tag_id == undefined || !tag_id || tag_id > 0)
    {
        refresh_table_tags_for_search();
    }
    else
    {
        $("#table_tags_for_search_wrapper").hide();
        $(".div_manual_add").show();
        $(".div_manual_add .btn_add_manual_tag").attr('onclick', 'update_manual_tag('+tag_id+')');
        var tag_name = $('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').find('.tag_name').text();
        $(".div_manual_add .input_name_manual_add").val(tag_name);
        var weight = $('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').attr('action-data-weight');
        $(".div_manual_add .select_name_manual_add").val(weight);
        var old_tag_list = [];
        if(!add_div_and)
        {
            $('.form_search .condition .div_and').eq(div_and_no).find('.div_or').each(function(){
                old_tag_list.push({id:$(this).attr('action-data-tag-id'), weight:$(this).attr('action-data-weight'), name:$(this).find('.tag_name').text().trim()});
            });
        }
        $(".tag_choosed .tag_choosed_item").remove();
        for(var i in old_tag_list)
        {
            $(".tag_choosed").append('<span class="tag_choosed_item" action-data-tag-id="'+old_tag_list[i].id+'" action-data-weight="'+old_tag_list[i].weight+'">'+old_tag_list[i].name+'<span class="tag_choosed_item_remove">×</span></span>');
        }
    }
}
function refresh_table_tags_for_search()
{
    if(table_tags_for_search)
    {
        table_tags_for_search.ajax.reload();
        return;
    }
    var cols_num = 7;
    table_tags_for_search = $('#table_tags_for_search').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/tag/list/",
            "type": "POST",
            "data":function(d){
                var pid = $(".div_tag_list .breadcrumb a:last").attr('action-data');
                if(pid)
                {
                    d.parent_id = pid;
                }
                d['search[value]'] = $(".input_tag_search").val().trim();
            }, 
            "dataFilter": function(data){
                var json = jQuery.parseJSON( data );
                if(json.status !=0)
                {
                    ark_notify(json);
                    json.recordsTotal = 0;
                    json.recordsFiltered = 0;
                    json.data = [];
                    total_words_num = 0;
                }
                else
                {
                    total_words_num = json.recordsTotal;
                    var cols_name = [];
                    var formated_data = [];
                    for(var i=0;i<Math.ceil(json.data.length/cols_num);i++)
                    {
                        var line = {}
                        for(var j=1;j<=cols_num;j++)
                        {
                            line['col_'+j] = json.data[i*cols_num+j-1] == undefined ? {name:'',id:''} : json.data[i*cols_num+j-1];
                        }
                        formated_data.push(line);
                    }
                    json.data = formated_data;
                }
                if(json.recordsTotal == 0)
                {
                    $("#table_tags_for_search_wrapper").hide();
                    $(".div_manual_add .btn_add_manual_tag").attr('onclick', 'add_manual_tag()');
                    $(".div_manual_add").show();
                    $(".div_manual_add .input_name_manual_add").val($(".input_tag_search").val());
                    $(".div_manual_add .select_name_manual_add option:eq(0)").prop('selected', true);
                    $(".div_manual_add .btn_add_manual_tag").attr('onclick', 'add_manual_tag()');
                }
                else
                {
                    $("#table_tags_for_search_wrapper").show();
                    $(".div_manual_add").hide();
                }
                return JSON.stringify( json ); // return JSON string
            },
        },
        "pageLength":28,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "col_1",
            bSortable: false
        }, {
            data: "col_2",
            bSortable: false
        }, {
            data: "col_3",
            bSortable: false
        }, {
            data: "col_4",
            bSortable: false
        }, {
            data: "col_5",
            bSortable: false
        }, {
            data: "col_6",
            bSortable: false
        }, {
            data: "col_7",
            bSortable: false
        }],
        "columnDefs": [
            {
                "targets":[0, 1, 2, 3, 4, 5, 6],
                "render":function(data,type,full){
                    var old_tag_list = [];
                    if(!add_div_and)
                    {
                        $('.form_search .condition .div_and').eq(div_and_no).find('.div_or').each(function(){
                            old_tag_list.push({id:$(this).attr('action-data-tag-id'), weight:$(this).attr('action-data-weight'), name:$(this).find('.tag_name').text().trim()});
                        });
                    }
                    $(".tag_choosed .tag_choosed_item").remove();
                    for(var i in old_tag_list)
                    {
                        $(".tag_choosed").append('<span class="tag_choosed_item" action-data-tag-id="'+old_tag_list[i].id+'" action-data-weight="'+old_tag_list[i].weight+'">'+old_tag_list[i].name+'<span class="tag_choosed_item_remove">×</span></span>');
                    }
                    var ret = '';
                    if(data.id)
                    {
                        var checked = '';
                        var weight = -1;
                        for(var i in old_tag_list)
                        {
                            if(old_tag_list[i].id == data.id)
                            {
                                checked = 'checked';
                                weight = old_tag_list[i].weight;
                            }
                        }
                        //var text = data.id ? '<a action-data="'+data.id+'" '+(data.size > 0 ? 'onclick="show_subnode_list('+data.id+', \''+data.name+'\')"' : 'style="color:#333;"') + '>'+data.name+'</a>': '';
                        var text = data.id ? '<a action-data="'+data.id+'" onclick="show_subnode_list('+data.id+', \''+data.name+'\')"' + '>'+data.name+'</a>': '';
                        var select = '<select '+(checked ? '' : 'style="display:none;"')+' class="form-control select_tag_intensity">';
                        for(var i in intensity_map)
                        {
                            select += '<option value="'+intensity_map[i].val+'" '+(intensity_map[i].val == weight ? "selected" : "")+'>'+intensity_map[i].text+'</option>';
                        }
                        select += '</select>';
                        ret = select + '<label><input type="checkbox" '+checked+'></label>'+text;
                    }
                    return ret;
                },
            }
        ],
    });
}
function show_subnode_list(tag_id, tag_name)
{
    $(".input_tag_search").val('');
    $(".div_tag_list .breadcrumb").append('<li><a action-data="'+tag_id+'"><font>'+tag_name+'</font></a></li>');
    refresh_table_tags_for_search();
}
function close_tag_list()
{
    $(".div_tag_list").slideToggle();
}
function query_user_list()
{
    query_id = 0;
    $(".div_tag_list").hide();
    $(".query_op").hide();
    var condition = [];
    query = [];
    $(".form_search .condition .div_and").each(function(){
        if($(this).children().length > 0)
        {
            var or_list = [];
            var query_or = [];
            $(this).find('.div_or').each(function(){
                or_list.push($(this).find(".tag_name").text() + $(this).find(".tag_intensity").text());
                query_or.push({
                    parent_list:JSON.parse($(this).attr('action-data-tag-path')),
                    tag_word: $(this).find(".tag_name").text(),
                    tag_id: $(this).attr('action-data-tag-id'),
                    weight:$(this).attr('action-data-weight'),
                    is_div:false,
                    full_path:$(this).attr('action-data-full-path') == undefined ? [] : $(this).attr('action-data-full-path'),
                });
            });
            condition.push(or_list.join(','));
            query.push({or_list:query_or});
        }
    });
    $(".query_user_list_head .query_condition").html('条件：'+condition.join('+'));
    if($(".query_user_list").is(':hidden'))
    {
        $(".query_user_list").slideToggle();
    }
    flush_table_user_list();
}
function flush_table_user_list()
{
    if(table_user_list)
    {
        table_user_list.ajax.reload();
    }
    else
    {
        table_user_list = $('#table_user_list').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": '/interest_graphs/users_analysis/select_users_with_query/',
                "type": "POST",
                "data":function(d){
                    $("#btn_query_user_list").button('loading');
                    if(query_id)
                    {
                        d.query_id = query_id;
                    }
                    else
                    {
                        d.query = JSON.stringify(query);
                        d.type = $(".form_search .search_period").val();
                    }

                },
                "dataFilter": function(data){
                    $("#btn_query_user_list").button('reset');
                    var json = jQuery.parseJSON( data );
                    if(json.status != 0)
                    {
                        $(".query_op").hide();
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        $(".query_op").show();
                        $(".query_op .btn_view_graphs").show();
                        $(".query_op .user_num").text(json.users_all);
                        if(json.all_num == 0)
                        {
                            $(".query_op .btn_view_graphs").hide();
                        }
                        if(!query_id)
                        {
                            query_id = json.query_id;
                            $(".query_op").show();
                            $(".query_op .btn_view_graphs").attr('href', '/interest_graphs/users_analysis/figure/?query_id='+query_id);
                        }
                        json.data = json.data_list;
                        //json.recordsTotal = 0;
                        //json.recordsFiltered = 0;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "pageLength":10,
            "paginate":true,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
                "paginate":{
                    'next':'下一页',
                    'previous':'上一页',
                },
            },
            columns: [
            {
                data: "uid",
                bSortable: false
            }, {
                data: "snid",
                bSortable: false
            }, {
                data: "pv",
                bSortable: false
            }, {
                data: "last_visit_time",
                bSortable: false
            }, {
                data: "city",
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[0],
                    "render":function(data,type,full){
                        return '<a href="/interest_graphs/users_analysis/user_index/?uid='+data+'" target="_blank">'+data+'</a>'
                    },
                },
                {
                    "targets":[4],
                    "render":function(data,type,full){
                        return data ? data : '--';
                    },
                },
                {
                    "targets":[5],
                    "render":function(data,type,full){
                        return '<a href="/interest_graphs/users_analysis/user_index/?uid='+full.uid+'" target="_blank">查看</a>'
                     }
                },
            ]

    });

    }
}
function add_manual_tag()
{
    manual_tag_id -= 1;
    var tag_name = $(".div_manual_add .input_name_manual_add").val().trim();
    if(!tag_name)
    {
        ark_notify({status:1, msg:'标签名称不能为空'});
        return;
    }
    var weight = $(".div_manual_add .select_name_manual_add").val();
    var path = [];
    var full_path = [];
    $(".div_tag_list .breadcrumb li:not(:first-child)").each(function(){
        path.push($(this).find('a').text());
        full_path.push({id:$(this).find('a').attr('action-data'), name:$(this).find('a').text()});
    });
    $(".tag_choosed").append('<span class="tag_choosed_item" action-data-tag-id="'+manual_tag_id+'" action-data-weight="'+weight+'">'+tag_name+'<span class="tag_choosed_item_remove">×</span></span>');
    if(add_div_and)
    {
        $('.form_search .condition').append('<div class="div_and">\
                <div action-data-tag-id="'+manual_tag_id+'" action-data-tag-path=\''+JSON.stringify(path)+'\' action-data-full-path=\''+JSON.stringify(full_path)+'\' action-data-weight="'+weight+'" class="div_or">\
                    <span class="tag_name">'+tag_name+'</span>\
                    <span class="tag_intensity">('+get_intensity_name_by_val(weight)+')</span>\
                </div>\
           </div>');
        add_div_and = false;
    }
    else
    {
        $('.form_search .condition .div_and').eq(div_and_no).append('<div action-data-tag-id="'+manual_tag_id+'" action-data-tag-path=\''+JSON.stringify(path)+'\' action-data-full-path=\''+JSON.stringify(full_path)+'\' action-data-weight="'+weight+'" class="div_or">\
               <span class="tag_name">'+tag_name+'</span>\
               <span class="tag_intensity">('+get_intensity_name_by_val(weight)+')</span>\
           </div>');
    }
    $(".div_manual_add .input_name_manual_add").val('');
    $(".div_manual_add .select_name_manual_add option:eq(0)").prop('selected', true);
}
function update_manual_tag(tag_id)
{
    var tag_name = $(".div_manual_add .input_name_manual_add").val().trim();
    if(!tag_name)
    {
        ark_notify({status:1, msg:'标签名称不能为空'});
        return;
    }
    var weight = $(".div_manual_add .select_name_manual_add").val();
    $(".tag_choosed .tag_choosed_item[action-data-tag-id="+tag_id+"]").attr('action-data-weight', weight);
    $(".tag_choosed .tag_choosed_item[action-data-tag-id="+tag_id+"]").html(tag_name+'<span class="tag_choosed_item_remove">×</span>');
    $('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').find('.tag_name').html(tag_name);
    $('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').find('.tag_intensity').html('('+get_intensity_name_by_val(weight)+')');
    $('.form_search .condition .div_and').eq(div_and_no).find('.div_or[action-data-tag-id="'+tag_id+'"]').attr('action-data-weight', weight);

    $(".div_manual_add .btn_add_manual_tag").attr('onclick', 'add_manual_tag()');
    $(".div_manual_add .input_name_manual_add").val('');
    $(".div_manual_add .select_name_manual_add option:eq(0)").prop('selected', true);
}
function show_search_history()
{
    $("#searchHistoryModal").modal('show');
    refresh_search_history_table();
}
function refresh_search_history_table()
{
    if(table_search_history)
    {
        table_search_history.ajax.reload();
        return;
    }
    var cols_num = 7;
    table_search_history = $('#table_search_history').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/users_analysis/get_history_list/",
            "type": "POST",
            "dataFilter": function(data){
                var json = jQuery.parseJSON( data );
                json.recordsTotal = 0;
                json.recordsFiltered = 0;
                if(json.status !=0)
                {
                    ark_notify(json);
                    json.data = [];
                }
                else
                {
                    json.data = json.data_list;
                }
                return JSON.stringify( json ); // return JSON string
            },
        },
        "pageLength":10,
        "lengthChange": false,
        "paginate":false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "query",
            bSortable: false
        }, {
            data: "query_id",
            bSortable: false
        }],
        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    data = JSON.parse(data);
                    var and_arr = [];
                    for(var i in data)
                    {
                        var or_arr = [];
                        for(var j in data[i].or_list)
                        {
                            or_arr.push(data[i].or_list[j].tag_word+'('+get_intensity_name_by_val(data[i].or_list[j].weight)+')')
                        }
                        and_arr.push(or_arr.join(","));
                    }
                    return and_arr.join("+");
                },
            },
            {
                "targets":[1],
                "render":function(data,type,full){
                    var onclick_refill = 'refill_condition(\''+full.query+'\',\''+full.query_id+'\')';
                    var onclick_requery = 'requery_condition(\''+full.query+'\',\''+full.query_id+'\')';
                    return "<a onclick="+onclick_refill+">条件回填</a> | <a onclick="+onclick_requery+">再次查询</a>";
                },
            },
        ],
    });
}
function flush_table_favorite_list()
{
    if(table_favorite_list)
    {
        table_favorite_list.ajax.reload();
    }
    else
    {
        table_favorite_list = $('#table_favorite_list').DataTable({
            "bDestroy":true,
            "processing": true,
            "serverSide": true,
            "searching": false,
            "ajax": {
                "url": '/interest_graphs/users_analysis/get_user_favorite_list/',
                "type": "POST",
                "dataFilter": function(data){
                    var json = jQuery.parseJSON( data );
                    if(json.status !=0)
                    {
                        json.recordsTotal = 0;
                        json.recordsFiltered = 0;
                        json.data = [];
                    }
                    else
                    {
                        json.data = json.data_list;
                        //json.recordsTotal = 0;
                        //json.recordsFiltered = 0;
                    }
                    return JSON.stringify( json ); // return JSON string
                },
            },
            "pageLength":10,
            "paginate":true,
            "lengthChange": false,
            "language":{
                "sLengthMenu": "",
                "sInfo": "",
                "sInfoEmpty": "",
                "zeroRecords": '暂无结果',
                "paginate":{
                    'next':'下一页',
                    'previous':'上一页',
                },
            },
            columns: [
            {
                data: "no",
                width:'10px',
                bSortable: false
            }, {
                data: "name",
                bSortable: false
            }, {
                data: "create_time",
                width:'120px',
                bSortable: false
            }, {
                data: "query_id",
                width:'190px',
                bSortable: false
            }],
                    
            "columnDefs": [
                {
                    "targets":[3],
                    "render":function(data,type,full){
                        var onclick_refill = 'refill_condition(\''+full.query+'\',\''+full.query_id+'\')';
                        var onclick_requery = 'requery_condition(\''+full.query+'\',\''+full.query_id+'\')';
                        return '<a href="/interest_graphs/users_analysis/figure/?query_id='+data+'">查看</a> | <a onclick='+onclick_refill+'>条件回填</a> | <a onclick='+onclick_requery+'>再次查询</a> | <a onclick="delete_favorite(\''+full.id+'\')">删除</a>';
                    },
                },
            ]

    });

    }
}
function show_favorite()
{
    $("#favoriteListModal").modal('show');
    flush_table_favorite_list();
}
function requery_condition(condition, query_id)
{
    refill_condition(condition, query_id);
    query_user_list();
}
function refill_condition(condition, query_id)
{
    var type = query_id.substr(-1);
    $(".form_search .search_period").val(type);
    condition = JSON.parse(condition);
    $(".form_search .condition .div_and").remove();
    var html = '';
    for(var i in condition)
    {
        html += '<div class="div_and">';
        var or_list = condition[i].or_list;
        //for(var k in or_list)
        //{
        //    full_path.push({id:or_list[k].tag_id, name:or_list[k].tag_word});
        //}
        for(var j in or_list)
        {
            var full_path = or_list[j].full_path;
            html += '<div action-data-tag-id="'+or_list[j].tag_id+'" action-data-tag-path=\''+JSON.stringify(or_list[j].parent_list)+'\' action-data-full-path=\''+full_path+'\' action-data-weight="'+or_list[j].weight+'" class="div_or">\
                        <span class="tag_name">'+or_list[j].tag_word+'</span>\
                        <span class="tag_intensity">('+get_intensity_name_by_val(or_list[j].weight)+')</span>\
                     </div>';
        }
        html += '</div>';
    }
    $(".form_search .condition").append(html);
    $(".modal").modal('hide');
}
function hide_modal(modal_id)
{
    $(modal_id).modal('hide');
}
function delete_favorite(id)
{
    $("#deleteFavoriteModal #btn_do_delete_favorite").attr('onclick', 'do_delete_favorite(\''+id+'\')');
    $("#deleteFavoriteModal").modal({
         show:true,
         backdrop:'static'
       });
}
function do_delete_favorite(id)
{
    $("#deleteFavoriteModal #btn_do_delete_favorite").button('loading');
    var url = "/interest_graphs/users_analysis/delete_favorite/";
    var post_data = {id:id};
    var callback = callback_do_delete_favorite;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_favorite(result, args)
{
    ark_notify(result);
    $("#deleteFavoriteModal #btn_do_delete_favorite").button('reset');
    if(result.status == 0)
    {
        $("#deleteFavoriteModal").modal('hide');
        flush_table_favorite_list();
    }
}
function get_select_figure_data()
{
    var url = "/interest_graphs/users_analysis/get_choice_pic_list/";
    var post_data = {};
    var callback = callback_get_select_figure_data;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_select_figure_data(result, args)
{
    if(result.status == 0)
    {
        for(var i=0; i< result.data_list.length; i+=3)
        {
            $(".select_figure .carousel-indicators").append('<li data-target="#carousel-example-generic" data-slide-to="'+(i/3)+'" '+( i == 0 ? 'class="active"' : '') +'></li>');
            var imgs_html = '<a href="'+result.data_list[i].url+'"><div class="img_item_block"><div class="img_item_title">'+result.data_list[i].title+'</div><img src="'+result.data_list[i].pic+'"></img><div class="img_item_desc">'+result.data_list[i].desc+'</div></div></a>';
            imgs_html += (i+1) < result.data_list.length ? '<a href="'+result.data_list[i+1].url+'"><div class="img_item_block"><div class="img_item_title">'+result.data_list[i+1].title+'</div><img src="'+result.data_list[i+1].pic+'"></img><div class="img_item_desc">'+result.data_list[i+1].desc+'</div></div></a>' : '';
            imgs_html += (i+2) < result.data_list.length ? '<a href="'+result.data_list[i+2].url+'"><div class="img_item_block"><div class="img_item_title">'+result.data_list[i+2].title+'</div><img src="'+result.data_list[i+2].pic+'"></img><div class="img_item_desc">'+result.data_list[i+2].desc+'</div></div></a>' : '';
            $(".select_figure .carousel-inner").append('<div class="item'+( i == 0 ? ' active' : '') +'">'+imgs_html+'</div>');
        }
    }
}
