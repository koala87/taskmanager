var table_list = null;
var dict_id_preview = '';
var table_id = 0;
var field_id = 0;
$(function () {
    get_favorite_tree();
    $(document).on('change', ".input_favorite_search", function () {
        $('#favorite_tree').tree("doFilter", $(".input_favorite_search").val().trim());
        $('#favorite_tree').tree("expandAll");
    });
});

function down_load_class_tag(tag_id) {
    var params = {
        "tag_id": tag_id
    };
    var url = '/interest_graphs/content_tag_mgr/download_class_tag/?' + $.param(params);
    location.href = url;
}


function down_load_all_tags(tag_id) {
    var params = {
        "tag_id": tag_id
    };
    var url = '/interest_graphs/content_tag_mgr/download_all_tags/?' + $.param(params);
    location.href = url;
}

function get_favorite_tree()
{
    var url = '/interest_graphs/content_tag/get_tag_tree/';
    $('#favorite_tree').tree({
        url: url,
        animate: true,
        lines: true,
        formatter: function (node) {
            if (node.text == '+添加节点') {
                return '<span style="float:left" onclick="add_new_class_tag(' + node.id + ');"><font color="blue">' + node.text + '</font></span> ';
            } else {
                return node.text + '&nbsp;&nbsp;&nbsp;&nbsp;<span class="tree-edit" title="修改标签信息" style="display:none;" id="tree_edit_' + node.id +
                '" onclick="update_class_tag(' + node.id + ');"></span> <span class="tree-add"  title="添加子节点" style="display:none;" id="tree_add_' + node.id +
                 '" onclick="add_new_class_tag(' + node.id + ');"></span> <span class="tree-delete"  title="删除" style="display:none;" id="tree_delete_' + node.id + '" onclick="delete_class_tag(' + node.id + ');"></span>';
            }
        },
        onHover: function (e, node) {
            if (node.text != '+添加节点') {
                $('#tree_add_' + node.id).show();
                $('#tree_delete_' + node.id).show();
                $('#tree_edit_' + node.id).show();
            }
        },
        onHoverLeave: function (e, node) {
            if (node.text != '+添加节点') {
                $('#tree_add_' + node.id).hide();
                $('#tree_delete_' + node.id).hide();
                $('#tree_edit_' + node.id).hide();
            }
        },
        onLoadSuccess: function (node, data) {
            var root_node = $('#favorite_tree').tree('getRoot');
            if (root_node != null && root_node.text != "+添加节点") {
                $('#favorite_tree').tree("select", root_node.target);
                get_class_tag_info(root_node.id);
                $('#down_load_class_tag').attr('onclick', 'down_load_class_tag(' + root_node.id + ')');
                $('#down_load_all_tags').attr('onclick', 'down_load_all_tags(' + root_node.id + ')');

            }
        },
        onClick: function (node) {
            var root_nodes = $('#favorite_tree').tree('getRoots');
            if (node.text != '+添加节点') {
                get_class_tag_info(node.id);
                $('#down_load_class_tag').attr('onclick', 'down_load_class_tag(' + node.id + ')');
                $('#down_load_all_tags').attr('onclick', 'down_load_all_tags(' + node.id + ')');
            }
        }
    });
}

function get_class_tag_info(tag_id) {
    $.ajax({
        url: '/interest_graphs/content_tag/get_tag_info/',
        data: { "tag_id": tag_id },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $('#class_tag_name').html('<font size="5">' + result.name + '</font>');
            type = "类型："
            if (result.is_article) {
                type += "文章"
                if (result.is_video) {
                    type += "&视频"
                }
            } else {
                if (result.is_video) {
                    type += "视频"
                } else {
                    type += "未设置"
                }
            }

            $('#class_tag_type').html('<font size="2">' + type + '</font>');
            if (result.is_div) {
                $('#class_tag_is_div').html('<font size="2">仅维度：是</font>');
            } else {
                $('#class_tag_is_div').html('<font size="2">仅维度：否</font>');
            }

            if (result.is_auto_add) {
                $('#class_tag_auto').html('<font size="2">添加方式：机器</font>');
            } else {
                $('#class_tag_auto').html('<font size="2">添加方式：运营</font>');
            }
            $('#class_tag_update_time').html('<font size="2">更新时间：' + result.update_time + '</font>');
            $('#class_tag_editor').html('<font size="2">操作人：' + result.owner_name + '</font>');

            $("#table_list").html('<colgroup>' +
                                   '<col width="20%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                   '<col width="17%">' +
                                '</colgroup>' +
                                '<thead>' +
                                    '<tr>' +
                                       '<th >名称</th>' +
                                       '<th >子节点数</th>' +
                                       '<th >标签数</th>' +
                                       '<th >待审核标签</th>' +
                                       '<th >订阅标签</th>' +
                                       '<th >行业热度</th>' +
                                       '<th >文章数</th>' +
                                    '</tr>' +
                                '</thead>');

            $("#table_list").append("<tr>" +
                                       "<th id=\"table_class_tag_name\">" + result.name + "</th>" +
                                       "<th >" + result.child_num + "</th>" +
                                       "<th ><a href='/interest_graphs/content_tag_mgr/?parent_id=" + tag_id + "'>" + result.child_tag_num + "</a></th>" +
                                       "<th ><a href='/interest_graphs/content_check_tag/?parent_id=" + tag_id + "'>" + result.child_wait_check_tag_num + "</a></th>" +
                                       "<th ><a href='/interest_graphs/content_check_tag/?parent_id=" + tag_id + "'>" + result.topic_tag_num + "</a></th>" +
                                       "<th >" + result.avg_hot + "</th>" +
                                       "<th >" + result.article_num + "</th>" +
                                    "</tr>");
        }
    });
}

function update_class_tag(node_id) {
    $.ajax({
        url: '/interest_graphs/content_tag/get_tag_info/',
        data: { "tag_id": node_id },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $('#new_class_tag_name').val(result.name);
            $('#new_class_tag_title').html("修改数据");
            
            $("input[id='new_class_is_video']").removeAttr("checked");
            $("input[id='new_class_is_article']").removeAttr("checked");
            $("input[id='new_class_just_div']").removeAttr("checked");
            if (result.is_article) {
                $("input[name='article']").prop("checked", true);
            } else {
                $("input[id='new_class_is_video']").removeAttr("checked");
            }

            if (result.is_video) {
                $("input[name='vedio']").prop("checked", true);
            } else {
                $("input[id='new_class_is_article']").removeAttr("checked");
            }

            if (result.is_div) {
                $("input[name='is_div']").prop("checked", true);
            } else {
                $("input[id='new_class_just_div']").removeAttr("checked");
            }

            $('#add_table_model #btn_do_add_class_tag_ok').attr('onclick', 'do_update_class_tag(' + node_id + ')');
            $("#add_table_model").modal('show');
        }
    });    
}

function do_update_class_tag(node_id) {
    var tag_name = $('#new_class_tag_name').val();
    var tag_is_article = $("input[id='new_class_is_article']").is(':checked');
    if (tag_is_article) {
        tag_is_article = 1;
    } else {
        tag_is_article = 0
    }
    var tag_is_vedio = $("input[id='new_class_is_video']").is(':checked');
    if (tag_is_vedio) {
        tag_is_vedio = 1;
    } else {
        tag_is_vedio = 0
    }

    var tag_is_div = $("input[id='new_class_just_div']").is(':checked');
    if (tag_is_div) {
        tag_is_div = 1;
    } else {
        tag_is_div = 0
    }

    $.ajax({
        url: '/interest_graphs/content_tag/update_class_tag/',
        data: { "name": tag_name, "tag_id": node_id, "is_article": tag_is_article, "is_vedio": tag_is_vedio, "is_div": tag_is_div },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#add_table_model").modal('hide');

            var t = $('#favorite_tree');
            var node = t.tree('getSelected');
            if (node.text != '+添加节点') {
                t.tree('update', {
                    target: node.target,
                    text: tag_name
                });
                get_class_tag_info(node_id);
            }
        }
    });
}

function delete_class_tag(node_id) {
    $('#delete_table_model #btn_do_delete_ok').attr('onclick', 'do_delete('+node_id+')');
    $("#delete_table_model").modal('show');
}

function do_delete(node_id) {
    $.ajax({
        url: '/interest_graphs/content_tag/delete_class_tag/',
        data: { "tag_id": node_id },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#delete_table_model").modal('hide');

            var t = $('#favorite_tree');
            var node = t.tree('getSelected');
            if (node.text != '+添加节点') {
                t.tree('remove', node.target);
            }
            var root_node = $('#favorite_tree').tree('getRoot');
            if (root_node != null && root_node.text != "+添加节点") {
                $('#favorite_tree').tree("select", root_node.target);
                get_class_tag_info(root_node.id);
            }
        }
    });
}

function add_new_class_tag(node_id) {
    $('#new_class_tag_name').val('');
    $("input[id='new_class_is_video']").removeAttr("checked");
    $("input[id='new_class_is_article']").removeAttr("checked");
    $("input[id='new_class_just_div']").removeAttr("checked");
    $("input[id='new_class_is_video']").prop("checked", true);
    $("input[id='new_class_is_article']").prop("checked", true);

    $('#new_class_tag_title').html("新建分类");

    $('#add_table_model #btn_do_add_class_tag_ok').attr('onclick', 'do_add_new_class_tag('+node_id+')');
    $("#add_table_model").modal('show');
}

function do_add_new_class_tag(node_id) {
    var tag_name = $('#new_class_tag_name').val();
    var tag_is_article = $("input[id='new_class_is_article']").is(':checked');
    if (tag_is_article) {
        tag_is_article = 1;
    } else {
        tag_is_article = 0;
    }

    var tag_is_vedio = $("input[id='new_class_is_video']").is(':checked');
    if (tag_is_vedio) {
        tag_is_vedio = 1;
    } else {
        tag_is_vedio = 0;
    }

    var tag_is_div = $("input[id='new_class_just_div']").is(':checked');
    if (tag_is_div) {
        tag_is_div = 1;
    } else {
        tag_is_div = 0;
    }

    $.ajax({
        url: '/interest_graphs/content_tag/add_new_class_tag/',
        data: { "name": tag_name, "parent_id": node_id, "is_article": tag_is_article, "is_vedio": tag_is_vedio, "is_div": tag_is_div },
        type: 'POST',
        dataType: "json",
        async: true,
        success: function (result) {
            if (result.status != 0) {
                showErrorMessage(result.msg)
                return;
            }
            $("#add_table_model").modal('hide');

            var t = $('#favorite_tree');
            var node = t.tree('getSelected');
            if (node.text == '+添加节点') {
                for (var i = 0; i < result.ret_list.length; ++i) {
                    t.tree('insert', {
                        before: node.target,
                        data: [{
                            id: result.ret_list[i].id,
                            text: result.ret_list[i].text,
                            state: 'open'
                        }]
                    });
                }
            } else {
                children = t.tree('getChildren', node.target);
                if (children.length > 0) {
                    for (var i = 0; i < result.ret_list.length; ++i) {
                        t.tree('insert', {
                            before: children[0].target,
                            data: [{
                                id: result.ret_list[i].id,
                                text: result.ret_list[i].text,
                                state: 'open'
                            }]
                        });
                    }
                } else {
                    for (var i = 0; i < result.ret_list.length; ++i) {
                        t.tree('append', {
                            parent: (node ? node.target : null),
                            data: [{
                                id: result.ret_list[i].id,
                                text: result.ret_list[i].text,
                                state: 'open'
                            }]
                        });
                    }
                }
            }

            t.tree('expand', node.target);
            var new_node = t.tree('find', result.ret_list[0].id);
            t.tree('select', new_node.target);
            get_class_tag_info(result.ret_list[0].id);
        }
    });
}

function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function() {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function() {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function(a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function(a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return + Globalize.parseDate(a)
                }
                return a
            },
            _format: function(a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function() {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}

function update_table_users(table_id) {
    $('#table_managers_select').html("");
    $('#table_users_select').html("");
    var url = "/interest_graphs/shuqi_toufang/get_all_user_list/";
    $.ajax({
        type: "post",
        url: url,
        async: false,
        dataType: "json",
        success: function (result) {
            if (result.status) {
                // alert(result.msg);
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            } else {
                $.ajax({
                    url: '/interest_graphs/shuqi_toufang/get_author_list/',
                    type: 'POST',
                    data: { "table_id": table_id, "auth_tag": 1 },
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success: function (sub_result) {
                        var reportTo = "";
                        if (sub_result.status != 0) {
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                reportTo += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                            }
                        } else {
                            var arr = new Array();
                            for (var i = 0; i < sub_result.data.length; ++i) {
                                arr.push(sub_result.data[i].user_id);
                            }
                            var users = result.user_list;
                            for (var i = 0; i < users.length; i++) {
                                if (arr.indexOf(users[i].id) >= 0) {
                                    reportTo += "<option value='" + users[i].id + "' selected='true'>" +
                                    users[i].name + "</option>";
                                } else {
                                    reportTo += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }
                        }
                        $("#table_managers_select").append(reportTo);
                    }
                });
                $.ajax({
                    url: '/interest_graphs/shuqi_toufang/get_author_list/',
                    type: 'POST',
                    data: { "table_id": table_id, "auth_tag": 2 },
                    type: 'POST',
                    dataType: "json",
                    async: false,
                    success: function (sub_result) {
                        var reportTo = '';
                        if (sub_result.status != 0) {
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                reportTo += "<option value='" + users[i].id + "' >" +
                                users[i].name + "</option>";
                            }
                        } else {
                            var arr = new Array();
                            for (var i = 0; i < sub_result.data.length; ++i) {
                                arr.push(sub_result.data[i].user_id);
                            }
                            var users = result.user_list;
                            for (i = 0; i < users.length; i++) {
                                if (arr.indexOf(users[i].id) >= 0) {
                                    reportTo += "<option value='" + users[i].id + "' selected>" +
                                    users[i].name + "</option>";
                                } else {
                                    reportTo += "<option value='" + users[i].id + "' >" +
                                    users[i].name + "</option>";
                                }
                            }
                        }
                        $("#table_users_select").append(reportTo);
                        init_select2_async();
                        $("#fix_table_users_model").modal('show');
                        $('#fix_table_users_model #btn_update_table_user_ok').attr('onclick', 'do_update_table_user('+table_id+')');
                    }
                });
            }
        }
    });
}

function do_update_table_user(table_id) {
    var auth_list = '';
    if ($("#table_managers_select").val() != null) {
        auth_list = $("#table_managers_select").val().join(',');
    }
    $.ajax({
        url: '/interest_graphs/shuqi_toufang/update_table_author/',
        type: 'POST',
        data: { "table_id": table_id, "auth_id_list": auth_list, "auth_tag": 1 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改管理员失败", result.msg);
                return;
            }
        }
    });

    var auth_list = '';
    if ($("#table_users_select").val() != null) {
        auth_list = $("#table_users_select").val().join(',');
    }

    $.ajax({
        url: '/interest_graphs/shuqi_toufang/update_table_author/',
        type: 'POST',
        data: { "table_id": table_id, "auth_id_list": auth_list, "auth_tag": 2 },
        type: 'POST',
        dataType: "json",
        async: false,
        success: function (result) {
            if (result.status != 0) {
                showMessage("error", "修改使用者失败", result.msg);
                return;
            }
            table_list.ajax.reload();
            $("#fix_table_users_model").modal('hide');
        }
    });
}

function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}
