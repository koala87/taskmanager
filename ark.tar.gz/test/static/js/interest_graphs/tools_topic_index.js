table_task_list = null;
$(function(){
    init_table_task_list();
});
function init_table_task_list()
{
    table_task_list = $('#table_task_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/interest_graphs/tools/topic/list/",
            "type": "POST",
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "no",
            bSortable: false
        }, {
            data: "task_name",
            bSortable: false
        }, {
            data: "owner",
            bSortable: false
        }, {
            data: "create_time",
            bSortable: false
        }, {
            data: "run_status",
            bSortable: false
        }, {
            data: "is_auto_schedule",
            bSortable: false
        }, {
            data: "",
            bSortable: false
        }],
                
        "columnDefs": [
            {
                "targets":[4],
                "render":function(data,type,full){
                    var ret = '';
                    if(data == 101)
                    {
                        ret = '未执行';
                    }
                    else if(data == 0)
                    {
                        ret = '<font color="#0099FF">筛选中</font>';
                    }
                    else if(data == 50)
                    {
                        ret = '<font color="#0099FF">筛选完成</font>';
                    }
                    else if(data == 51)
                    {
                        ret = '<font color="#0099FF">计算中</font>';
                    }
                    else if(data == 100)
                    {
                        ret = '<font color="#009900">已完成</font>';
                    }
                    else if(data < 0)
                    {
                        ret = '<font color="red">失败</font>';
                    }
                    return ret;
                },
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    var ret = '';
                    if(data == 0)
                    {
                        ret = '<img style="cursor:pointer;" src="/static/images/interest_graphs/close-icon.png" title="点击开启自动调度" onclick="create_auto_schedule('+full.id+')"></img>';
                    }
                    else
                    {
                        ret = '<img style="cursor:pointer;" src="/static/images/interest_graphs/open-icon.png" title="点击关闭自动调度" onclick="stop_auto_schedule('+full.id+')"></img>';
                    }
                    return ret;
                },
            },
            {
                "targets":[6],
                "render":function(data,type,full){
                    var ret = '<a href="/interest_graphs/tools/topic/create_task/?id='+full.id+'">查看</a> | ';
                    if(full.run_status == 0 || full.run_status == 51)
                    {
                        ret += '<a href="javascript:" onclick="stop_task('+full.id+')">停止</a>';
                    }
                    else
                    {
                        ret += '<a href="javascript:" onclick="delete_task('+full.id+')">删除</a>';
                    }
                    return ret;
                },
            },
        ]

    });

}
function delete_task(task_id)
{
    $("#deleteTaskConfirmModal #btn_do_delete_task_ok").attr('onclick', 'do_delete_task('+task_id+')');
    $("#deleteTaskConfirmModal").modal('show');
}
function do_delete_task(task_id)
{
    $("#deleteTaskConfirmModal #btn_do_delete_task_ok").button('loading');
    var url = '/interest_graphs/tools/topic/delete_task/';
    var post_data = {'task_id':task_id};
    var callback = callback_do_delete_task;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_task(result, args)
{
    $("#deleteTaskConfirmModal #btn_do_delete_task_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteTaskConfirmModal").modal('hide');
        table_task_list.ajax.reload();
    }
}
function stop_task(task_id)
{
    $("#stopTaskConfirmModal #btn_do_stop_task_ok").attr('onclick', 'do_stop_task('+task_id+')');
    $("#stopTaskConfirmModal").modal('show');
}
function do_stop_task(task_id)
{
    $("#stopTaskConfirmModal #btn_do_stop_task_ok").button('loading');
    var url = '/interest_graphs/tools/topic/stop_task/';
    var post_data = {'task_id':task_id};
    var callback = callback_do_stop_task;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_stop_task(result, args)
{
    $("#stopTaskConfirmModal #btn_do_stop_task_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#stopTaskConfirmModal").modal('hide');
        table_task_list.ajax.reload();
    }
}
function create_auto_schedule(task_id)
{
    $("#createAutoScheduleConfirmModal #btn_do_create_auto_schedule_ok").attr('onclick', 'do_create_auto_schedule('+task_id+')');
    $("#createAutoScheduleConfirmModal").modal('show');
}
function do_create_auto_schedule(task_id)
{
    $("#createAutoScheduleConfirmModal #btn_do_create_auto_schedule_ok").button('loading');
    var url = '/interest_graphs/tools/topic/create_auto_schedule/';
    var post_data = {'task_id':task_id, ct_time:$("#run_time").val().trim()};
    var callback = callback_do_create_auto_schedule;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_create_auto_schedule(result, args)
{
    $("#createAutoScheduleConfirmModal #btn_do_create_auto_schedule_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#createAutoScheduleConfirmModal").modal('hide');
        table_task_list.ajax.reload();
    }
}
function stop_auto_schedule(task_id)
{
    $("#stopAutoScheduleConfirmModal #btn_do_stop_auto_schedule_ok").attr('onclick', 'do_stop_auto_schedule('+task_id+')');
    $("#stopAutoScheduleConfirmModal").modal('show');
}
function do_stop_auto_schedule(task_id)
{
    $("#stopAutoScheduleConfirmModal #btn_do_stop_auto_schedule_ok").button('loading');
    var url = '/interest_graphs/tools/topic/stop_auto_schedule/';
    var post_data = {'task_id':task_id};
    var callback = callback_do_stop_auto_schedule;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_stop_auto_schedule(result, args)
{
    $("#stopAutoScheduleConfirmModal #btn_do_stop_auto_schedule_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#stopAutoScheduleConfirmModal").modal('hide');
        table_task_list.ajax.reload();
    }
}
