var dict_id = $("#dict_id").val();
var table_dict_detail_list = null;
var cols_num = 1;
var total_words_num = 0;
var html_term_detail_init = '';
var html_term_detail_view = '';

var dict_detail_result = ''
var dict_detail_word_id = ''

$(function(){
    $('body').bind('scroll', function(e){
        $("#dict_words_op").css('top', (210 -188 +$("#dict_detail_container").position().top).toString()+'px');
    });

    tmp_dict = { "dict_id": $('#dict_id').val() };
    $.ajax({
        url: '/interest_graphs/tag/dict/get_dict_schema/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: false,
        success: function (result) {
            if (result.status == 0) {
                init_table(result.header_list);
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });

    $("#file_type").on('change', function(){
        table_dict_detail_list.ajax.reload();
    });
//    $(document).on('dblclick', ".word_item", function(e){
//        if($(this).find('input').length > 0)
//        {
//            return;
//        }
//        $(this).html('<input type="text" value="'+$(this).html()+'">');
//        $(this).find('input').eq(0).select();
//    });
    $(document).on('hover', ".word_item", function(){
        $(this).next().show();
    });
    $(document).on('blur', ".word_item input", function(){
        var url = '/interest_graphs/tag/dict/update_term/';
        var post_data = {id:$(this).parent().attr('action-data'), term_detail:$(this).val().trim()};
        var callback = callback_update_term;
        var args = {obj:this};
        makeAPost(url, post_data, true, callback, args);
    });
    $(document).on('keydown', ".word_item input", function(e){
        var e=e||window.event;
        var code = e.keyCode|| e.which;
        if(code == 13){
            $(this).trigger('blur');
        }
    });
});

function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}

function callback_term_detail(result, args)
{
    if(result.status != 0)
    {
        ark_notify({status:1,msg:'查看详情失败'});
        return;
    }
    if(html_term_detail_init)
    {
        $("#editTermModal").html(html_term_detail_init);
    }
    else
    {
        html_term_detail_init = $("#editTermModal").html();
    }
    $("#editTermModal .modal-body").attr('action-data', args.term_id);
    $("#editTermModal #span_term_name").html(result.data.word);
    var attrs = result.data.attrs ? JSON.parse(result.data.attrs) : {};
    for(var item in attrs)
    {
        $("#editTermModal #term_detail_basic").append('<div class="form-group">\
                                                            <label class="col-sm-3 control-label">'+item+'</label>\
                                                            <div class="col-sm-8">\
                                                                <span class="span_term_detail_value">'+attrs[item]+'</span>\
                                                            </div>\
                                                        </div>');
    }
    var relate_terms = result.data.relate_terms;
    if(!$.isEmptyObject(relate_terms))
    {
        for(var item in relate_terms)
        {
            var display_term = relate_terms[item].term_name;
            if(relate_terms[item].term_num > 1)
            {
                display_term = '关联'+relate_terms[item].term_num+'个词,暂不支持单个修改';
            }
            $("#editTermModal #term_detail_attr").append('<div class="form-group">\
                                                                <label class="col-sm-3 control-label">'+relate_terms[item].dict_name+'</label>\
                                                                <div class="col-sm-8">\
                                                                    <span class="span_term_detail_value">'+display_term+'</span>\
                                                                </div>\
                                                            </div>');
        }
        $("#editTermModal #term_detail_attr").show();
    }
    $("#editTermModal").modal('show');
}
function hide_edit_term_modal()
{
    $("#editTermModal").modal('hide');
}
function back_view_term_detail()
{
    $(".btn_edit_term_toggle").toggle();
    $("#editTermModal form").html(html_term_detail_view);
    $("#editTermModal #btn_do_edit_term_ok").attr('onclick', 'hide_edit_term_modal()');
    $("#editTermModal #btn_do_edit_term_cancel").attr('onclick', 'hide_edit_term_modal()');
}
function edit_term()
{
    html_term_detail_view = $("#editTermModal form").html();
    var term_id = $("#editTermModal .modal-body").attr('action-data');
    var url = '/interest_graphs/tag/dict/term_detail/';
    var post_data = {id:term_id};
    var callback = callback_edit_term;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_edit_term(result, args)
{
    if(result.status != 0)
    {
        ark_notify({status:1,msg:'获取term详情失败'});
        return;
    }
    var term_id = $("#editTermModal .modal-body").attr('action-data');
    $("#editTermModal #btn_do_edit_term_ok").attr('onclick', 'do_edit_term('+term_id+')');
    $("#editTermModal #btn_do_edit_term_cancel").attr('onclick', 'back_view_term_detail()');
    $(".btn_edit_term_toggle").toggle();
    $("#editTermModal form .form-group").remove();
    $("#editTermModal #term_detail_basic").append('<div class="form-group">\
                                                        <label class="col-sm-3 control-label">名称</label>\
                                                        <div class="col-sm-8">\
                                                            <input class="form-control" id="input_term_name" value="'+result.data.word+'">\
                                                        </div>\
                                                    </div>');
    var attrs = result.data.attrs ? JSON.parse(result.data.attrs) : {};
    for(var item in attrs)
    {
        $("#editTermModal #term_detail_basic").append('<div class="form-group form_group_term_attr">\
                                                            <label class="col-sm-3 control-label">'+item+'</label>\
                                                            <div class="col-sm-8">\
                                                                <input class="form-control" value="'+attrs[item]+'">\
                                                            </div>\
                                                        </div>');
    }
    var relate_terms = result.data.relate_terms;
//    relate_terms['81'] = {term_num:10,dict_name:'test'};
    if(!$.isEmptyObject(relate_terms))
    {
        for(var item in relate_terms)
        {
            var display_term = relate_terms[item].term_name;
            if(relate_terms[item].term_num > 1)
            {
                display_term = '关联'+relate_terms[item].term_num+'个词,暂不支持单个修改';
                var action_data = {};
                action_data['dict_id'] = item;
                action_data['value'] = relate_terms[item];
                $("#editTermModal #term_detail_attr").append('<div class="form-group" action-data=\''+JSON.stringify(action_data)+'\'>\
                                                                    <label class="col-sm-3 control-label">'+relate_terms[item].dict_name+'</label>\
                                                                    <div class="col-sm-8">\
                                                                        <span class="span_term_detail_value">'+display_term+'</span>\
                                                                    </div>\
                                                                </div>');
            }
            else
            {
                $("#editTermModal #term_detail_attr").append('<div class="form-group" style="padding:0 50px 0 10px;">\
                                                                    <div class="col-sm-6">\
                                                                        <input class="form-control select_dict_attr" value="'+item+'">\
                                                                    </div>\
                                                                    <div class="col-sm-6">\
                                                                        <input class="form-control select_term_attr" value="'+relate_terms[item].term_id+'">\
                                                                    </div>\
                                                                    <a onclick="delete_term_detail_attr(this)" style="position: absolute;right: 40px;margin-top: 12px;">删除</a>\
                                                                </div>');
                $("#editTermModal #term_detail_attr .form-group:last .select_dict_attr").attr('action-data', JSON.stringify({id:item,text:relate_terms[item].dict_name}));
                $("#editTermModal #term_detail_attr .form-group:last .select_dict_attr").select2({
                    placeholder: '请输入词典名称',
                    ajax: {
                        url: '/interest_graphs/tag/dict/list/', 
                        type:'POST',
                        dataType: 'json',
                        data: function (term, page) {
                          var query = {
                            'search[value]': term,
                            type: 0,//实体词典
                            length: 10,
                          }
                          return query;
                        },
                        results: function (data) {
                            var ret = [];
                            if(data.status ==0)
                            {
                                for(var i in data.data)
                                {
                                    ret.push({id:data.data[i].id, text:data.data[i].name});
                                }
                            }
                            return {
                              results: ret
                            };
                        }
                    },
                    initSelection: function (element, callback) {
                        var data = JSON.parse(element.attr('action-data'));
                        callback(data);
                    },
                    language: 'ch',
                });
                $("#editTermModal #term_detail_attr .form-group:last .select_term_attr").attr('action-data', JSON.stringify({id:relate_terms[item].term_id,text:relate_terms[item].term_name}));
                $("#editTermModal #term_detail_attr .form-group:last .select_term_attr").select2({
                    placeholder: '请输入单词名称',
                    ajax: {
                        url: '/interest_graphs/tag/dict/term_list/', 
                        type:'POST',
                        dataType: 'json',
                        data: function (term, page) {
                          var query = {
                            'search[value]': term,
                            //dict_id: item,
                            dict_id: $(this).parents('.form-group').find("input.select_dict_attr").val(),
                            cols_num: 1,
                            length: 10,
                          }
                          return query;
                        },
                        results: function (data) {
                            var ret = [];
                            if(data.status ==0)
                            {
                                for(var i in data.data)
                                {
                                    ret.push({id:data.data[i].id, text:data.data[i].word});
                                }
                            }
                            return {
                              results: ret
                            };
                        }
                    },
                    initSelection: function (element, callback) {
                        var data = JSON.parse(element.attr('action-data'));
                        callback(data);
                    },
                    language: 'ch',
                });
                $("#editTermModal #term_detail_attr .form-group:last input.select_dict_attr").on('change', function(){
                    //$("#editTermModal #term_detail_attr .form-group:first div.select_term_attr").select2('data', null);
                    $(this).parents(".form-group").find("div.select_term_attr").select2('data', null);
                });
            }
        }
    }
    $("#editTermModal #term_detail_attr").append('<p id="btn_add_term_detail_attr" style="text-align:right;padding-right: 15px;"><a onclick="add_term_detail_attr()">添加</a></p>');
    $("#editTermModal #term_detail_attr").show();

    
}
function callback_update_term(result, args)
{
    var node = $(args['obj']);
    if(result.status == 0)
    {
        node.parent().attr('title', node.val().trim());
        node.parent().html(node.val().trim());
    }
    else
    {
        ark_notify(result);
        node.focus();
    }
}
function init_table(table_schema)
{
    table_dict_detail_list = $('#table_dict_detail_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": true,
        "ajax": {
            "url": "/interest_graphs/tag/dict/get_dict_data_list/",
            "type": "POST",
            "data":function(d){
                d.dict_id = dict_id;
                d.cols_num = cols_num;
            }, 
            "dataFilter": function(data){
                var json = jQuery.parseJSON( data );
                if(json.status !=0)
                {
                    ark_notify(json);
                    json.recordsTotal = 0;
                    json.recordsFiltered = 0;
                    json.data = [];
                    total_words_num = 0;
                }
                return JSON.stringify( json ); // return JSON string
            },
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: table_schema,
        "columnDefs": [
            {
                "targets":[table_schema.length - 1],
                "render":function(data,type,full){
                    return '<a onclick="view_term_detail('+full.id+')">修改</a> | <a title="删除" onclick="delete_word('+full.id+')">删除</a>';
                },
            },
        ],
    });

}
function edit_word(obj)
{
    var node = $(obj).prev().prev();
    if(node.find('input').length > 0)
    {
        return;
    }
    node.html('<input type="text" value="'+node.html()+'">');
    node.find('input').eq(0).select();
}
function delete_word(word_id)
{
    $("#btn_do_delete_word_ok").attr('onclick', 'do_delete_word('+word_id+')');
    $("#deleteConfirmModal").modal('show');
}
function do_delete_word(word_id)
{
    tmp_dict = { "dict_id": $('#dict_id').val(), 'word_id': word_id };
    $.ajax({
        url: '/interest_graphs/tag/dict/delete_dict_word/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: false,
        success: function (result) {
            $("#deleteConfirmModal").modal('hide');
            if (result.status == 0) {
                table_dict_detail_list.ajax.reload();
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}
function callback_do_delete_word(result, args)
{
    $("#btn_do_delete_word_ok").button('loading');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteConfirmModal").modal('hide');
        $("#btn_do_delete_word_ok").button('reset');
        table_dict_detail_list.ajax.reload();
    }
}
function edit_dict()
{
    $("#updateDictModal #name").val($("#dict_detail_name").html());
    $("#updateDictModal #desc").val($("#dict_detail_desc").html());
    $("#updateDictModal #desc").val($("#dict_detail_desc").html());
    init_set_group_select2();
    $("#updateDictModal").modal('show');
}
function do_edit_dict(dict_id)
{
    $("#btn_do_edit_dict_ok").button('loading');
    var url = '/interest_graphs/tag/dict/update/';
    var name = $("#updateDictModal #name").val().trim();
    var desc = $("#updateDictModal #desc").val().trim();
    var post_data = {id:dict_id,name:name,desc:desc};
    var group_id = $("#updateDictModal #input_group").val();
    group_id == 0 ? '' : post_data['group_id'] = group_id;
    var callback = callback_do_edit_dict;
    var args = {dict_id:dict_id, name:name, desc:desc};
    var group_name = $("#updateDictModal #s2id_input_group .select2-chosen").text();
    args['group_name'] = group_name;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_edit_dict(result, args) 
{
    $("#btn_do_edit_dict_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#updateDictModal").modal('hide');
        $("#dict_detail_name").html(args.name);
        $("#dict_detail_desc").html(args.desc);
        $("#input_group").attr('action-data', JSON.stringify({id:args.dict_id,text:args.group_name}));
    }
}
function delete_term_detail_attr(obj)
{
    $(obj).parents('.form-group').remove();
}
function add_term_detail_attr()
{
    $("#editTermModal #term_detail_attr #btn_add_term_detail_attr").before('<div class="form-group" style="padding:0 50px 0 10px;">\
                                                        <div class="col-sm-6">\
                                                            <input class="form-control select_dict_attr">\
                                                        </div>\
                                                        <div class="col-sm-6">\
                                                            <input class="form-control select_term_attr">\
                                                        </div>\
                                                        <a onclick="delete_term_detail_attr(this)" style="position: absolute;right: 40px;margin-top: 12px;">删除</a>\
                                                    </div>');
    $("#editTermModal #term_detail_attr .form-group:last .select_dict_attr").select2({
        placeholder: '请输入词典名称',
        ajax: {
            url: '/interest_graphs/tag/dict/list/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                'search[value]': term,
                type: 0,//实体词典
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.data)
                    {
                        ret.push({id:data.data[i].id, text:data.data[i].name});
                    }
                }
                return {
                  results: ret
                };
            }
        },
        language: 'ch',
    });
    $("#editTermModal #term_detail_attr .form-group:last .select_term_attr").select2({
        placeholder: '请输入单词名称',
        ajax: {
            url: '/interest_graphs/tag/dict/term_list/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                'search[value]': term,
                //dict_id: item,
                dict_id: $(this).parents('.form-group').find("input.select_dict_attr").val(),
                cols_num: 1,
                length: 10,
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.data)
                    {
                        ret.push({id:data.data[i].id, text:data.data[i].word});
                    }
                }
                return {
                  results: ret
                };
            }
        },
//        initSelection: function (element, callback) {
//            var data = JSON.parse(element.attr('action-data'));
//            callback(data);
//        },
        language: 'ch',
    });
    $("#editTermModal #term_detail_attr .form-group:last input.select_dict_attr").on('change', function(){
        //$("#editTermModal #term_detail_attr .form-group:first div.select_term_attr").select2('data', null);
        $(this).parents(".form-group").find("div.select_term_attr").select2('data', null);
    });
}
function do_edit_term(term_id)
{
    var url = '/interest_graphs/tag/dict/update_term/';
    var post_data = {id:term_id};
    post_data['term_detail'] = JSON.stringify(get_term_detail_conf());
    var callback = callback_do_edit_term;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_edit_term(result, args)
{
    if(result.status != 0)
    {
        ark_notify({status:1,msg:'修改term失败'});
        return;
    }
    $("#editTermModal").modal('hide');
    table_dict_detail_list.ajax.reload(null, false);
}
function get_term_detail_conf()
{
    var ret = {};
    ret['word'] = $("#term_detail_basic #input_term_name").val().trim();
    ret['attrs'] = {};
    $("#term_detail_basic .form_group_term_attr").each(function(){
        ret['attrs'][$(this).find('label').text().trim()] = $(this).find("input").val().trim();
    });
    ret['relate_terms'] = {};
    $("#term_detail_attr .form-group").each(function(){
        if($(this).find('input').length < 1)
        {
            var old_data = JSON.parse($(this).attr('action-data'));
            ret['relate_terms'][old_data.dict_id] = old_data.value;
        }
        else
        {
            var dict_id = $(this).find('input.select_dict_attr').val().trim();
            var term_id = $(this).find('input.select_term_attr').val().trim();
            if(dict_id && term_id)
            {
                ret['relate_terms'][dict_id] = {term_id:term_id};
            }
        }
    });
    return ret;
}
function view_term_detail(word_id)
{
    tmp_dict = { "dict_id": $('#dict_id').val(), 'word_id': word_id };
    $.ajax({
        url: '/interest_graphs/tag/dict/get_dict_word_info/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: false,
        success: function (result) {
            if (result.status == 0) {
                dict_detail_word_id = word_id
                create_dict_detail_table(result)
                $("#editTermModal").modal('show');
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
};
function init_set_group_select2()
{
    $("#updateDictModal #input_group").select2({
                placeholder: '请输入分组名称',
                ajax: {
                    url: '/interest_graphs/tag/dict/dict_group_list/', 
                    type:'POST',
                    dataType: 'json',
                    data: function (term, page) {
                      var query = {
                        'search[value]': term,
                      }
                      return query;
                    },
                    results: function (data) {
                        var ret = [];
                        if(data.status ==0)
                        {
                            for(var i in data.data)
                            {
                                ret.push({id:data.data[i].id, text:data.data[i].name});
                            }
                        }
                        return {
                          results: ret
                        };
                    }
                },
                language: 'ch',
                initSelection: function (element, callback) {
                    var attr = JSON.parse(element.attr('action-data'));
                    var data = attr;
                    callback(attr);//这里初始化
                },
            });
}

function create_dict_detail_table(result) {
    dict_detail_result = result;
    var new_table = '<table class="table table-bordered dict_detail_fields_list">'+
        '<tr>'+
            '<td style="width:30%"><strong>字段名</strong></td>'+
            '<td style="width:70%"><strong>值</strong></td>'+
        '</tr>'
    for (var i = 0; i < result.json_ret.length; ++i) {
        if (result.json_ret[i].chinese_name == '是否删除') {
            continue;
        }
        var tmp_row = '<tr>' +
            '<td class="field_name">' + result.json_ret[i].chinese_name + '</td>' +
            '<td><input style="width:100%;" type="text" value="' + result.json_ret[i].value + '"></td>' +
            '</td>' +
        '</tr>'
        new_table += tmp_row
    }
    $("#dict_word_detail").html(new_table)
}

function get_odps_format_data() {
    var format = [];
    $(".dict_detail_fields_list tr:gt(0)").each(function () {
        var name = $(this).find("td").eq(0).text();
        var chinese_name = $(this).find("td").eq(1).find("input").val().trim();
        var type = $(this).find("td").eq(2).find("select").val().trim();
        format.push({ 'col_name': name, 'chinese_name': chinese_name, 'value_type': type });
    });
    var uniqe_key = ''
    var temp = document.getElementsByName("local_key_mode");
    for (var i = 0; i < temp.length; i++) {
        if (temp[i].checked)
            uniqe_key = temp[i].value;
    }
    tmp_dict = { 'unique_cols': uniqe_key, 'table_schema': JSON.stringify(format), "dict_id": $('#dict_id').val() }
    return tmp_dict;
}

function update_dict_detail() {
    var idx = 0;
    var update_succ = true;
    $(".dict_detail_fields_list tr:gt(0)").each(function () {
        var new_value = $(this).find("td").eq(1).find("input").val().trim();
        if (new_value != dict_detail_result.json_ret[idx].value) {
            tmp_dict = { 
                "dict_id": $('#dict_id').val(), 
                "word_id": dict_detail_word_id, 
                "field_name": dict_detail_result.json_ret[idx].col_name,
                "new_value": new_value};
            $.ajax({
                url: '/interest_graphs/tag/dict/update_dict_word/',
                type: 'POST',
                dataType: "json",
                data: tmp_dict,
                async: false,
                success: function (result) {
                    if (result.status != 0) {
                        showMessage("error", "失败", result.msg);
                        update_succ = false;
                        return;
                    }
                }
            });
        }
        idx++;
    });

    if (update_succ) {
        $("#editTermModal").modal('hide');
        table_dict_detail_list.ajax.reload(null, false);
    }
}