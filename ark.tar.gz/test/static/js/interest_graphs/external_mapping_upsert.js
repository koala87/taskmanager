var table_tags_for_mapping = null;
var cols_num = 5;
var detail = null;
$(function(){
    if($("#external_mapping_detail").val())
    {
        detail = JSON.parse($("#external_mapping_detail").val())
        $("#mapping_tag").attr('action-data', detail.tag_id);
        $("#mapping_tag").html(detail.tag_name);
        for(var i in detail.rules.simple)
        {
            $("#btn_add_rule").trigger('click');
            $('.mapping_rule_line:last .input_rule_key').val(detail.rules.simple[i].key);
            $('.mapping_rule_line:last .select_filter_type').val(detail.rules.simple[i].op);
            $('.mapping_rule_line:last .input_rule_val').val(detail.rules.simple[i].val);
        }
        $("#mapping_rule_complex").val(detail.rules.complex);
    }
    if(!detail)
    {
        $("#btn_add_rule").trigger('click');
    }
    $(document).on('click', "#selectTagModal .breadcrumb a", function(){
        $(this).parent().nextAll().remove();
        table_tags_for_mapping.ajax.reload();
    });
    $(document).on('dblclick', "#table_tags_for_mapping tbody td", function(){
        if($(this).html())
        {
            var tag_id = $(this).find('a').attr('action-data');
            if(tag_id != undefined && tag_id)
            {
                var path = [];
                $("#selectTagModal .breadcrumb li:gt(0)").each(function(){
                    path.push($(this).find('a>font').text());
                });
                path.push($(this).find('a').text());
                $("#mapping_tag").html(path.join(' - '));
                $("#mapping_tag").attr('action-data', tag_id);
                $("#selectTagModal").modal('hide');
            }
        }
    });
});
function add_rule(obj)
{
    var cur_form_group = $(obj).parents('.form-group');
    var html = '<div class="col-sm-4"> \
                    <input type="text" class="form-control input_rule_key" placeholder="填写字段名，如a.b"> \
                </div> \
                <div class="col-sm-2"> \
                    <select class="form-control select_filter_type">\
                        <option value="=">等于</option> \
                        <option value=">">大于</option> \
                        <option value="<">小于</option> \
                        <option value="!=">不等于</option> \
                        <option value="like">包含</option> \
                    </select> \
                </div> \
                <div class="col-sm-3"> \
                    <input type="text" class="form-control input_rule_val" placeholder="填写具体取值"> \
                </div> \
                <div class="col-sm-1"> \
                    <span class="glyphicon glyphicon-remove remove_rule" onclick="remove_rule(this)" aria-hidden="true"></span> \
                </div>';
    if(cur_form_group.prev().find('.control-label').html() && cur_form_group.prev().children().length == 1)
    {
        cur_form_group.prev().append(html);
    }
    else
    {
        html = '<div class="form-group mapping_rule_line">\
                        <label class="col-sm-2 control-label"></label>'+html+'</div>';
        cur_form_group.before(html);
    }
}
function remove_rule(obj)
{
    var cur_form_group = $(obj).parents('.form-group');
    if(cur_form_group.find('.control-label').html())
    {
        cur_form_group.children().slice(1).remove();
    }
    else
    {
        cur_form_group.remove();
    }
}
function select_mapping_tag()
{
    $("#selectTagModal").modal('show');
    if(!table_tags_for_mapping)
    {
        init_table_tags_for_mapping();
    }
}
function init_table_tags_for_mapping()
{
    table_tags_for_mapping = $('#table_tags_for_mapping').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": true,
        "ajax": {
            "url": "/interest_graphs/tag/list/",
            "type": "POST",
            "data":function(d){
                d.parent_id = $("#selectTagModal .breadcrumb a:last").attr('action-data');
            }, 
            "dataFilter": function(data){
                var json = jQuery.parseJSON( data );
                if(json.status !=0)
                {
                    ark_notify(json);
                    json.recordsTotal = 0;
                    json.recordsFiltered = 0;
                    json.data = [];
                    total_words_num = 0;
                }
                else
                {
                    total_words_num = json.recordsTotal;
                    //json.recordsTotal = Math.ceil(json.recordsTotal/cols_num);
                    //json.recordsFiltered = Math.ceil(json.recordsFiltered/cols_num);
                    var cols_name = [];
                    var formated_data = [];
                    for(var i=0;i<Math.ceil(json.data.length/cols_num);i++)
                    {
                        var line = {}
                        for(var j=1;j<=cols_num;j++)
                        {
                            line['col_'+j] = json.data[i*cols_num+j-1] == undefined ? {name:'',id:''} : json.data[i*cols_num+j-1];
                        }
                        formated_data.push(line);
                    }
                    json.data = formated_data;
                }
                return JSON.stringify( json ); // return JSON string
            },
        },
        "pageLength":50,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "col_1",
            bSortable: false
        }, {
            data: "col_2",
            bSortable: false
        }, {
            data: "col_3",
            bSortable: false
        }, {
            data: "col_4",
            bSortable: false
        }, {
            data: "col_5",
            bSortable: false
        }],
        "columnDefs": [
            {
                "targets":[0, 1, 2, 3, 4],
                "render":function(data,type,full){
                    return data.id ? '<a action-data="'+data.id+'" '+(data.size > 0 ? 'onclick="show_subnode_list('+data.id+', \''+data.name+'\')"' : 'style="color:#333;"') + '>'+data.name+'</a>': '';
                },
            }
        ],
    });
}
function show_subnode_list(tag_id, tag_name)
{
    $("#selectTagModal .breadcrumb").append('<li><a action-data="'+tag_id+'"><font>'+tag_name+'</font></a></li>');
    table_tags_for_mapping.ajax.reload();
}
function get_post_data()
{
    var ret = {};
    ret.tag_id = $("#mapping_tag").attr('action-data').trim();
    ret.rule_detail = {'simple':[], 'complex':''};
    $(".mapping_rule_line").each(function(){
        if($(this).find('.input_rule_key').length > 0)
        {
            var key = $(this).find('.input_rule_key').val().trim();
            var op = $(this).find('.select_filter_type').val().trim();
            var val = $(this).find('.input_rule_val').val().trim();
            ret.rule_detail.simple.push({key:key, op:op, val:val});
        }
    });
    ret.rule_detail.complex = $("#mapping_rule_complex").val().trim();
    ret.rule_detail = JSON.stringify(ret.rule_detail);

    return ret;
}
function do_add_external_mapping()
{
    $("#btn_do_add_external_mapping").button('loading');
    var url = '/interest_graphs/tag/external_mapping_add/';
    var post_data = get_post_data();
    var callback = callback_do_add_external_mapping;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_external_mapping(result, args)
{
    $("#btn_do_add_external_mapping").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        location.href = '/interest_graphs/tag/external_profile_index/?tab=1';
    }
}
function do_update_external_mapping()
{
    $("#btn_do_update_external_mapping").button('loading');
    var url = '/interest_graphs/tag/external_mapping_update/';
    var post_data = get_post_data();
    post_data.id = detail.id;
    var callback = callback_do_update_external_mapping;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_update_external_mapping(result, args)
{
    $("#btn_do_update_external_mapping").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        location.href = '/interest_graphs/tag/external_profile_index/?tab=1';
    }
}
