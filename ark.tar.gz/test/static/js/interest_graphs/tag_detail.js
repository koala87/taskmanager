var type_values_seperator = '\n';
var alias_seperator = '\n';
var theme_words_seperator = '\n';
var pattern_seperator = '\n';
var other_seperator = '\n';
var tag_id = null;
var tag_type = null;
var tag_detail = {};
var init_html_edit_node_modal = '';//编辑节点
var init_html_edit_attr_modal = '';//编辑属性
var cur_dict_all_list = {};
var table_subnode_list = null;
var tag_selected_attrs = [];
var selected_dict_ids = [];//当前tag已导入的词典ids
var ATTR_TYPE_ALIAS = 1;
var ATTR_TYPE_THEME = 2;
var ATTR_TYPE_RELY = 3;
var ATTR_TYPE_CONSTRAIN = 4;
var ATTR_TYPE_PATTERN = 5;
var ATTR_TYPE_DETAIL = 6;

var week_rely_on_dict = null;

$(function(){
    tag_detail = JSON.parse($("#tag_detail").val());
    tag_id = $("#tag_id").val().trim();
    tag_type = $("#tag_type").val().trim();
    show_attrs();
    init_table_subnode_list();
    $(document).on("change", "input.select_dict_list", function (e) {
        if(e.removed != undefined)
        {
            var id = e.removed.id;
            $("#table_dict_imported_show tbody tr[action-data='"+id+"']").remove();
            if ($("#table_dict_imported_show tr").length <= 0) {
                $('#tag_rely_dict_div').hide();
            } else {
                show_dict_info_rely($("#table_dict_imported_show tr").eq(0).attr('action-data'), $("#table_dict_imported_show tr").eq(0));
            }
        }
        else if(e.added != undefined)
        {
            var id = e.added.id;
            for (var i = 0; i < $("#table_dict_imported_show tr").length; ++i) {
                if ($("#table_dict_imported_show tr").eq(i).attr('action-data') == id) {
                    return;
                }
            }
            var text = e.added.text;
            var size = cur_dict_all_list[id].size;
            var owner = cur_dict_all_list[id].owner;
            var time = cur_dict_all_list[id].update_time;
            $('#tag_rely_dict_div').show();
            obj = '<tr onclick="show_dict_info_rely(' + id + ', this)" action-data="'+id+'"><td>'+text+'</td></tr>'
            $("#table_dict_imported_show tbody").append(obj);
            show_dict_info_rely(id, $("#table_dict_imported_show tr").get($("#table_dict_imported_show tr").length - 1));
        }
    });
    get_relate_dicts();
    get_inherited_info();
    get_be_inherited_info();
    get_be_relied();
    $(document).on('change', ".item_create_subnode [name='create_subnode_type']", function(){
        $("#editNodeModal .form-group:gt(0)").slideToggle();
    });
    $(document).on('change', "#editNodeModal #is_dim", function(){
        $("#editNodeModal #is_single_div").slideToggle();
    });
    $(document).on('change', ".attr_constrain_line .attr_constrain_type", function(){
        var action_data = $(this).parents(".attr_constrain_line").attr("action-data");
        var line = (action_data == undefined || action_data == '') ? [] : JSON.parse(action_data);
        $(this).next().html('');
        var html = '';
        if($(this).val() == 0)
        {
            var min = line.type != undefined ? line.value.min : "";
            var max = line.type != undefined ? line.value.max : "";
            html = '<input type="number" style="width:48%" value="'+min+'" placeholder="最小值"><span style="width:4%;display: inline-block;text-align: center;" >-</span><input type="number" style="width:48%" value="'+max+'" placeholder="最大值">';
        }
        else if($(this).val() == 1)
        {
            var value = line.type != undefined ? line.value.join(',') : "";
            html = '<input type="text" style="width:100%" class="attr_constrain_type_dict" value="'+value+'">';
        }
        else if($(this).val() == 2)
        {
            var text = line.type != undefined ? line.value : "";
            html = '<input type="text" style="width:100%" value="'+text+'" placeholder="请输入条件表达式">';
        }
        $(this).next().html(html);
        if($(this).val() == 1)
        {
            html = '<input type="text" class="attr_constrain_type_dict" placeholder="请输入条件表达式">';
            var url = '/interest_graphs/tag/dict/list/';
            var attr_val = [];
            var attr_data = [];
            $(this).parent().parent().parent().find(".attr_value_item").each(function(){
                attr_data.push({id:$(this).attr('action-data'), text:$(this).text()});
                attr_val.push($(this).attr('action-data'));
            });
            $(this).parent().find(".attr_constrain_type_dict").attr('data', JSON.stringify(attr_data));
            //$(this).parent().find(".attr_constrain_type_dict").val(attr_val.join(','));

            $(this).parent().find(".attr_constrain_type_dict").select2({
                placeholder: '请输入词典名称',
                multiple: true,
                ajax: {
                    url: url, 
                    type:'POST',
                    dataType: 'json',
                    data: function (term, page) {
                      var query = {
                        'search[value]': term,
                        page: page,
                        search_all:1,
                      }
                      return query;
                    },
                    results: function (data) {
                        var ret = [];
                        if(data.status ==0)
                        {
                            for(var i in data.data)
                            {
                                ret.push({id:data.data[i].id, text:data.data[i].name});
                            }
                        }
                        return {
                          results: ret
                        };
                    }
                },
                initSelection: function (element, callback) {
                    //var data = [{id: element.val(), text: element.val()}];
                    var attr = JSON.parse(element.attr('data'));
                    var data = attr;
                    //for(var i in attr)
                    //{
                    //    data.push();
                    //}
                    //callback([{id: element.val(), text: element.val()}]);//这里初始化
                    callback(attr);//这里初始化
                },
                language: 'ch',
            });
        }
    });
    $(document).on('click', ".attr_item_block .attr_item_block_name", function(){
        if($(this).hasClass('active'))
        {
            $(this).removeClass('active');
        }
        else
        {
            $(this).addClass('active');
        }
    });
    /*
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        if($(e.target).attr('href') == '#block_subnode')
        {
            $(".tab_btn").show();
        }
        else
        {
            $(".tab_btn").hide();
        }
    });
    */
});

function Map(){
this.container = new Object();
}


Map.prototype.put = function(key, value){
this.container[key] = value;
}


Map.prototype.get = function(key){
return this.container[key];
}


Map.prototype.keySet = function() {
var keyset = new Array();
var count = 0;
for (var key in this.container) {
// 跳过object的extend函数
if (key == 'extend') {
continue;
}
keyset[count] = key;
count++;
}
return keyset;
}


Map.prototype.size = function() {
var count = 0;
for (var key in this.container) {
// 跳过object的extend函数
if (key == 'extend'){
continue;
}
count++;
}
return count;
}


Map.prototype.remove = function(key) {
delete this.container[key];
}


Map.prototype.toString = function(){
var str = "";
for (var i = 0, keys = this.keySet(), len = keys.length; i < len; i++) {
str = str + keys[i] + "=" + this.container[keys[i]] + ";\n";
}
return str;
}

function tag_week_rely_on_dict(col_name, dict_id, old_tag_id, select_obj) {
    if (week_rely_on_dict == null) {
        week_rely_on_dict = new Map();
    }
    other_tag = $(select_obj).val();
    key = col_name + ":" + dict_id
    new_val = old_tag_id + ":" + other_tag
    val = week_rely_on_dict.get(key)
    if (!val) {
        week_rely_on_dict.put(key, new_val);
    } else {
        if (other_tag == old_tag_id) {
            week_rely_on_dict.remove(key);
            return;
        }
        week_rely_on_dict.put(key, new_val);
    }
}
function create_dict_rely_table(result) {
    var div_list = '';
    $.ajax({
        url: '/interest_graphs/tag/dict/get_div_list/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: {},
        success: function (div_result) {
            if (div_result.status == 0) {
                var new_table = '<table class="table table-bordered dict_rely_table_fileds_list">' +
                    '<tr>' +
                        '<td style="width:40%">中文名</td>' +
                        '<td >关联标签</td>' +
                    '</tr>'
                for (var i = 0; i < result.table_schema.length; ++i) {
                    var tmp_row = '<tr>' +
                        '<td >' + result.table_schema[i].chinese_name + '</td>' +
                        '<td >' +
                            '<select onchange="tag_week_rely_on_dict(\'' + result.table_schema[i].col_name + '\',' + result.id + ',' + result.table_schema[i].week_rely_id + ', this)" style="width:100%" id="div_select' + i + '">' +
                            '</select>' +
                        '</td>' +
                    '</tr>'
                    new_table += tmp_row
                }
                $('#tag_rely_on_dict_table').html(new_table);      
                for (var i = 0; i < result.table_schema.length; ++i) {
                    $('#div_select' + i).append('<option value="-1">不关联</option>');     
                    for(var j=0;j<div_result.data_list.length;j++){     
                        if (result.table_schema[i].week_rely_id != -1 && result.table_schema[i].week_rely_id == div_result.data_list[j].id) {
                            $('#div_select' + i).append('<option value="' + div_result.data_list[j].id + '" selected>'+div_result.data_list[j].name+'</option>');     
                        } else {
                            $('#div_select' + i).append('<option value="' + div_result.data_list[j].id + '">'+div_result.data_list[j].name+'</option>');     
                        }
                    } 
                }          
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function showMessage(type, title, msg) {
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg) {
    showMessage("error", "错误提示", msg);
}

function init_tag_rely_on_dicts() {
    $.ajax({
        url: '/interest_graphs/tag/dict/get_rely_on_dict_list/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: {"tag_id": tag_id},
        success: function (result) {
            if (result.status == 0) {
                if (result.dict_list.length > 0) {
                    $('#tag_rely_dict_div').show();
                }

                for (var i = 0; i < result.dict_list.length; i++) {
                    var id = result.dict_list[i].dict_id;
                    var text = result.dict_list[i].dict_name;
                    obj = '<tr onclick="show_dict_info_rely(' + id + ', this)" action-data="'+id+'"><td>'+text+'</td></tr>';
                    $("#table_dict_imported_show tbody").append(obj);
                    show_dict_info_rely(id, $("#table_dict_imported_show tr").get($("#table_dict_imported_show tr").length - 1));
                }
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function delete_rely_dict(dict_id) {
    $.ajax({
        url: '/interest_graphs/tag/dict/tag_unrely_on_dict/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: {"tag_id": tag_id, "dict_id": dict_id},
        success: function (result) {
            $('#odps_load_schema_busy').hide()
            if (result.status == 0) {
                var id = dict_id;
                $("#table_dict_imported_show tbody tr[action-data='"+id+"']").remove();
                if ($("#table_dict_imported_show tr").length <= 0) {
                    $('#tag_rely_dict_div').hide();
                } else {
                    show_dict_info_rely($("#table_dict_imported_show tr").eq(0).attr('action-data'), $("#table_dict_imported_show tr").eq(0));
                }
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });

}
function show_dict_info_rely(dict_id, obj) {   
    $.ajax({
        url: '/interest_graphs/tag/dict/get_dict_info_with_tag/',
        type: 'POST',
        dataType: "json",
        async: false,
        data: {"dict_id": dict_id, "tag_id": tag_id},
        success: function (result) {
            $('#odps_load_schema_busy').hide()
            if (result.status == 0) {
                $('#tag_word_count').html('词数：' + result.word_num + '<input type="button" value = "删除" onclick="delete_rely_dict(' + dict_id + ')" '+ 
                            'class="btn btn-primary pipe_btn" style="margin-left:165px;margin-top:5px;"/>')
                $('#dict_owner').html("创建者：" + result.owner)
                $('#dict_update_time').html("更新时间：" + result.data_end_update_time)

                create_dict_rely_table(result);
                $("#table_dict_imported_show tr").each(function () {
                    this.style.backgroundColor ="rgb(255,255,255)";
                });
                obj.style.backgroundColor ="rgb(0,153,204)";
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}
function delete_seleced_dict(obj)
{
    var cur_selected_ids = [];
    var cur_selected_data = [];
    $(obj).parent().parent().remove();
    $("#table_dict_imported_show tbody tr").each(function(){
        cur_selected_ids.push($(this).attr('action-data'));
        cur_selected_data.push({id:$(this).attr('action-data'), text:$(this).find('td:first').text()});
    });
    $("input.select_dict_list").val(cur_selected_ids.join(','));
    $("input.select_dict_list").attr('action-data', JSON.stringify(cur_selected_data));
    $("input.select_dict_list").trigger('change');
}
function toggle_edit_type_values()
{
    $('#type_edit_values').on('show.bs.collapse', function () {
        var cur_words = [];
        $("#block_type_value .type_value_dsp .type_value_item").each(function(){
            cur_words.push($(this).html().trim());
        });
        $(this).find("#textarea_type_values").val(cur_words.join(type_values_seperator));
    })
    $("#block_type_value .type_value_dsp .type_value_item").slideToggle();
    $('#type_edit_values').collapse('toggle');
}
function edit_type_values(tag_id)
{
    $("#block_type_value #btn_do_edit_type_values_ok").button('loading');
    var content = $("#block_type_value #textarea_type_values").val().trim();
    var words = content.split(type_values_seperator);
    var post_content = [];
    for(var i in words)
    {
        words[i].trim() == '' ? '' : (post_content.push(words[i].trim()));
    }
    var post_data = {tag_id:tag_id, words:JSON.stringify(post_content)};
    var url = '/interest_graphs/tag/update_type_values/';
    var callback = callback_edit_type_values;
    var args = {words:post_content};
    makeAPost(url, post_data, true, callback, args);
}
function callback_edit_type_values(result, args)
{
    $("#block_type_value #btn_do_edit_type_values_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#block_type_value .type_value_dsp .type_value_item").remove();
        for(var i in args.words)
        {
            var html = '<span class="type_value_item">'+args.words[i]+'</span>';
            $("#block_type_value .type_value_dsp #type_edit_values").before(html);
        }
        $('#type_edit_values').collapse('toggle');
    }
}
function toggle_edit_alias()
{
    $('#attr_edit_alias').on('show.bs.collapse', function () {
        var cur_words = [];
        $("#block_attr_item_alias .attr_value_item").each(function(){
            cur_words.push($(this).html().trim());
        });
        $(this).find("#textarea_alias").val(cur_words.join(alias_seperator));
    })
    $("#block_attr_item_alias .attr_value_item").slideToggle();
    $('#attr_edit_alias').collapse('toggle');
}
function edit_attr_alias(attr_id)
{
    var content = $("#attr_edit_alias #textarea_alias").val().trim();
    var words = $("#attr_edit_alias #textarea_alias").val().trim().split(alias_seperator);
    var post_content = [];
    for(var i in words)
    {
        words[i].trim() == '' ? '' : (post_content.push(words[i].trim()));
    }
    var post_data = {attr_id:attr_id, content:JSON.stringify(post_content)};
    var url = '/interest_graphs/tag/update_attr/';
    var callback = callback_edit_attr;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function toggle_edit_other(obj)
{
    $(obj).parents(".block_attr_item_other").find('.attr_edit_other').on('show.bs.collapse', function () {
        var cur_words = [];
        $(obj).parents(".block_attr_item_other").find(".attr_value_item").each(function(){
            cur_words.push($(this).html().trim());
        });
        $(this).find(".textarea_other").val(cur_words.join(other_seperator));
    })
    $(obj).parents(".block_attr_item_other").find(".attr_value_item").slideToggle();
    $(obj).parents(".block_attr_item_other").find('.attr_edit_other').collapse('toggle');
}
function edit_attr_other(obj, attr_id)
{
    var content = $(obj).parents(".block_attr_item_other").find(".attr_edit_other .textarea_other").val().trim();
    var words = $(obj).parents(".block_attr_item_other").find(".attr_edit_other .textarea_other").val().trim().split(other_seperator);
    var post_content = [];
    for(var i in words)
    {
        words[i].trim() == '' ? '' : (post_content.push(words[i].trim()));
    }
    var post_data = {attr_id:attr_id, content:JSON.stringify(post_content)};
    var url = '/interest_graphs/tag/update_attr/';
    var callback = callback_edit_attr;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function edit_attr_pattern(attr_id)
{
    var content = $("#attr_edit_pattern #textarea_pattern").val().trim();
    var words = $("#attr_edit_pattern #textarea_pattern").val().trim().split(pattern_seperator);
    var post_content = [];
    for(var i in words)
    {
        words[i].trim() == '' ? '' : (post_content.push(words[i].trim()));
    }
    var post_data = {attr_id:attr_id, content:JSON.stringify(post_content)};
    var url = '/interest_graphs/tag/update_attr/';
    var callback = callback_edit_attr;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function edit_attr_constrain(obj)
{
    $(obj).parents(".attr_constrain_line").addClass("cur_upload");
    var attr_id = $("#block_attr_item_constrain").attr('action-data');
    var content = [];
    var editing_type = $(obj).parent().prev().find(".attr_constrain_type").val();
    var editing_value = {type:parseInt(editing_type), value:''};
    if(editing_type == 0)
    {
        var min = $(obj).parent().prev().find(".attr_constrain_value input:eq(0)").val().trim();
        var max = $(obj).parent().prev().find(".attr_constrain_value input:eq(1)").val().trim();
        if(min || max)
        {
            editing_value['value'] = {min:min, max:max};
        }
    }
    else if(editing_type == 1)
    {
        var editing_ids = $(obj).parent().prev().find(".attr_constrain_value input.attr_constrain_type_dict").val().trim().split(',');
        var cur_line = [];
        for(var i in editing_ids)
        {
            if(editing_ids[i].trim() != '')
            {
                cur_line.push(parseInt(editing_ids[i].trim()));
            }
        }
        if(cur_line.length > 0)
        {
            editing_value['value'] = cur_line;
        }
    }
    else if(editing_type == 2)
    {
        var condition = $(obj).parent().prev().find(".attr_constrain_value input").val().trim();
        if(condition)
        {
            editing_value['value'] = condition;
        }
    }
    if(editing_value.value)
    {
        content.push(editing_value);
    }
    $(".attr_constrain_line").each(function(){
        if(!$(this).hasClass("cur_upload"))
        {
            var line = $(this).attr('action-data');
            if(line != undefined && line.length > 0)
            {
                content.push(JSON.parse(line));
            }
        }
    });
    var post_data = {attr_id:attr_id, content:JSON.stringify(content)};
    var url = '/interest_graphs/tag/update_attr/';
    var callback = callback_edit_attr;
    var args = {obj: obj};
    makeAPost(url, post_data, true, callback, args);
}
function edit_attr_rely(obj)
{
    $(obj).parents(".attr_rely_line").addClass("cur_upload");
    var attr_id = $("#block_attr_item_rely").attr('action-data');
    var content = [];
    var editing_ids = $(obj).parent().prev().val().split(',');
    var cur_line = [];
    for(var i in editing_ids)
    {
        if(editing_ids[i].trim() != '')
        {
            cur_line.push(parseInt(editing_ids[i].trim()));
        }
    }
    if(cur_line.length > 0)
    {
        content.push(cur_line);
    }
    $(".attr_rely_line").each(function(){
        if(!$(this).hasClass("cur_upload"))
        {
            var line = [];
            $(this).find(".attr_value_item").each(function(){
                line.push(parseInt($(this).attr('action-data')));
            });
            if(line.length >0)
            {
                content.push(line);
            }
        }
    });
    var post_data = {attr_id:attr_id, content:JSON.stringify(content)};
    var url = '/interest_graphs/tag/update_attr/';
    var callback = callback_edit_attr;
    var args = {obj:obj};
    makeAPost(url, post_data, true, callback, args);
}
function callback_edit_attr(result, args)
{
    ark_notify(result);
    if(result.status == 0)
    {
        show_attrs();
    }
    else
    {
        $(args.obj).parents(".attr_rely_line").removeClass("cur_upload");
    }
}
function toggle_edit_theme()
{
    var url = '/interest_graphs/tag/dict/list/';
    $('#attr_edit_theme').on('show.bs.collapse', function () {
        var cur_dict_ids = [];
        var cur_dict_data = [];
        $("#block_attr_item_theme .attr_value_item").each(function(){
            cur_dict_ids.push($(this).attr('action-data'));
            cur_dict_data.push({id:$(this).attr('action-data'), text:$(this).text().trim()});
        });
        $("#select2_theme").val(cur_dict_ids.join(','));
        $("#select2_theme").attr('action-data', JSON.stringify(cur_dict_data));
        $("#select2_theme").select2({
            placeholder: '请添加要导入的主题词典',
            multiple: true,
            ajax: {
                url: url, 
                type:'POST',
                dataType: 'json',
                data: function (term, page) {
                  var query = {
                    'search[value]': term,
                    type:1,
                  }
                  return query;
                },
                results: function (data) {
                    var ret = [];
                    if(data.status ==0)
                    {
                        for(var i in data.data)
                        {
                            ret.push({id:data.data[i].id, text:data.data[i].name});
                        }
                    }
                    return {
                      results: ret
                    };
                }
            },
            initSelection: function (element, callback) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            },
            language: 'ch',
        });
    })
    $("#block_attr_item_theme .attr_value_item").slideToggle();
    $('#attr_edit_theme').collapse('toggle');
}
function edit_attr_theme(attr_id)
{
    var content = $("#select2_theme").val().trim();
    content = content ? content.split(',') : [];
    var post_data = {attr_id:attr_id, content:JSON.stringify(content)};
    var url = '/interest_graphs/tag/update_attr/';
    var callback = callback_edit_attr;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function toggle_edit_pattern()
{
    $('#attr_edit_pattern').on('show.bs.collapse', function () {
        var cur_words = [];
        $("#block_attr_item_pattern .attr_value_item").each(function(){
            cur_words.push($(this).html().trim());
        });
        $(this).find("#textarea_pattern").val(cur_words.join(pattern_seperator));
    })
    $("#block_attr_item_pattern .attr_value_item").slideToggle();
    $('#attr_edit_pattern').collapse('toggle');
}
function toggle_edit_constrain(obj)
{
    var action_data = $(obj).parent().attr("action-data");
    if(action_data != undefined && action_data != '')
    {
        var line = JSON.parse(action_data);
        $(obj).parent().find(".attr_constrain_type").val(line.type);
    }
    $(obj).parent().find(".attr_constrain_type").trigger('change');
    $(obj).next().find(".attr_value_item").slideToggle();
    $(obj).next().find(".attr_edit_constrain").collapse('toggle');
    $(obj).slideToggle();
}
function toggle_edit_rely(obj)
{
    $(obj).parents(".attr_rely_line").removeClass("cur_upload");
    var url = '/interest_graphs/tag/list_for_rely/';
    $(obj).next().find('.attr_edit_rely').on('show.bs.collapse', function () {
        var attr_val = [];
        var attr_data = [];
        $(obj).next().find(".attr_value_item").each(function(){
            attr_data.push({id:$(this).attr('action-data'), text:$(this).text()});
            attr_val.push($(this).attr('action-data'));
        });
        $(this).find(".select2_rely").attr('data', JSON.stringify(attr_data));
        $(this).find(".select2_rely").val(attr_val.join(','));

        //$(this).find(".select2_rely").attr('data', JSON.stringify([{id:139,text:'aaa'},{id:141,text:'bbb'}]));
        //$(this).find(".select2_rely").val(139,141);
        $(this).find(".select2_rely").select2({
            placeholder: '请输入标签名称',
            multiple: true,
            ajax: {
                url: url, 
                type:'POST',
                dataType: 'json',
                data: function (term, page) {
                  var query = {
                    'query': term,
                    page: page,
                    search_all:1,
                    node_id:tag_id,
                  }
                  return query;
                },
                results: function (data) {
                    var ret = [];
                    if(data.status ==0)
                    {
                        for(var i in data.data)
                        {
                            ret.push({id:data.data[i].id, text:data.data[i].name});
                        }
                    }
                    return {
                      results: ret
                    };
                }
            },
            initSelection: function (element, callback) {
                //var data = [{id: element.val(), text: element.val()}];
                var attr = JSON.parse(element.attr('data'));
                var data = attr;
                //for(var i in attr)
                //{
                //    data.push();
                //}
                //callback([{id: element.val(), text: element.val()}]);//这里初始化
                callback(attr);//这里初始化
            },
            language: 'ch',
        });
    })
    $(obj).next().find(".attr_value_item").slideToggle();
    $(obj).next().find(".attr_edit_rely").collapse('toggle');
        $(obj).slideToggle();
}
function edit_node()
{
    $("#btn_edit_node").button('loading');
    var url = '/interest_graphs/tag/detail/';
    var post_data = {'id':tag_id};
    var callback = callback_edit_node;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_edit_node(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        $("#btn_edit_node").button('reset');
        return;
    }
    var post_data = {};
    var url = '/interest_graphs/tag/list_profile_attr/';
    var result_attr = makeAPost(url, post_data);
    $("#btn_edit_node").button('reset');
    if(result_attr.status != 0)
    {
        ark_notify(result_attr);
        return;
    }
    //初始化
    $("#editNodeModal #btn_do_edit_node_ok").attr("onclick", 'do_edit_node('+tag_id+')');
    if(init_html_edit_node_modal)
    {
        $("#editNodeModal .modal-body").html(init_html_edit_node_modal);
    }
    else
    {
        init_html_edit_node_modal = $("#editNodeModal .modal-body").html();
    }
    for(var i in result_attr.data)
    {
        $("#profile_attr_list").append('<label class="checkbox-inline"><input type="checkbox" name="attr_type" value="'+result_attr.data[i].id+'">'+result_attr.data[i].name+'</label>');
    }
    //填值
    $("#editNodeModal #name").val(result.data.info.name);
    $("#editNodeModal input[name='node_type'][value='"+result.data.info.type+"']").prop('checked', true);
    var old_attrs = result.data.attrs;
    $("#editNodeModal input[name='attr_type']").each(function(){
        for(var i in old_attrs)
        {
            if($(this).val() == old_attrs[i].value_id)
            {
                $(this).prop('checked', true);
            }
        }
    });
    $("#editNodeModal input[name='time_maintain'][value='"+result.data.info.interest_time+"']").prop('checked', true);
    $("#editNodeModal input[name='intensity'][value='"+result.data.info.interest_strength+"']").prop('checked', true);
    $("#editNodeModal #desc").val(result.data.info.desc);
    $("#editNodeModal .modal-title").html('编辑节点');
    if(result.data.info.is_dim)
    {
        $("#editNodeModal #is_dim").prop('checked', true);
        $("#editNodeModal #is_dim").trigger('change');
        if(result.data.info.is_single)
        {
            $("#editNodeModal #is_single").prop('checked', true);
        }
    }
    $("#editNodeModal").modal('show');
}
function import_dict()
{
    week_rely_on_dict == null;
    $("#btn_import_dict").button('loading');
    var url = '/interest_graphs/tag/to_import_dict/';
    var post_data = {tag_id:tag_id};
    var callback = callback_import_dict;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_import_dict(result, args)
{
    $("#btn_import_dict").button('reset');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    selected_dict_ids = result.data.dict_ids;
    cur_dict_all_list = {};
    var old_dict_ids = [];
    var old_dict_data = [];
    for(var dict_id in result.data.dict_ids)
    {
        old_dict_ids.push(dict_id);
        old_dict_data.push({id:dict_id, text:result.data.dict_ids[dict_id].info.name});
    }
    $("input.select_dict_list").val(old_dict_ids.join(','));
    $("input.select_dict_list").attr('action-data', JSON.stringify(old_dict_data));
    $("input.select_dict_list").select2({
        placeholder: '请添加你想要导入的词典',
        multiple: true,
        ajax: {
            url: '/interest_graphs/tag/get_all_import_dict/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                query: term,
                length:10,
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.data)
                    {
                        ret.push({id:data.data[i].id, text:data.data[i].name});
                        cur_dict_all_list[data.data[i].id] = data.data[i];
                    }
                }
                return {
                  results: ret
                };
            }
        },
        initSelection: function (element, callback) {
            var data = JSON.parse(element.attr('action-data'));
            callback(data);//这里初始化
        },
        language: 'ch',
    });
    $("#table_dict_imported_show tbody").html('');
    for(var j in result.data.dict_ids)
    {
        var id = j;
        var text = result.data.dict_ids[j].info.name;
        var size = result.data.dict_ids[j].info.size;
        var owner = result.data.dict_ids[j].info.owner;
        var time = result.data.dict_ids[j].info.time;
        $("#table_dict_imported_show tbody").append('<tr action-data="'+id+'" action-data-attr-conf=\''+JSON.stringify(result.data.dict_ids[j].config)+'\'><td>'+text+'</td><td>'+size+'</td><td>'+owner+'</td><td>'+time+'</td><td><a onclick="select_attr_from_import(this)">属性</a> | <a onclick="delete_seleced_dict(this)">删除</a></td></tr>');
    }
    $("#importDictModal").modal('show');
    init_tag_rely_on_dicts();
}
function do_import_dict()
{
    $("#btn_import_dict_ok").button('loading');
    var url = '/interest_graphs/tag/dict/tag_rely_on_dict/';
    var dicts = [];
    $("#table_dict_imported_show tbody tr").each(function(){
        if($(this).attr('action-data-attr-conf'))
        {
            dicts.push(JSON.parse($(this).attr('action-data-attr-conf')));
        }
        else
        {
            dicts.push({id:$(this).attr('action-data')});
        }
    });

    var week_dicts = []
    if (week_rely_on_dict != null) {
        var array = week_rely_on_dict.keySet();
        for(var i in array) {
            key_split = array[i].split(':')
            col_name = key_split[0]
            dict_id = key_split[1]
            val = week_rely_on_dict.get(array[i])
            val_split = val.split(':');
            old_tag_id = val_split[0]
            new_tag_id = val_split[1]
            if (old_tag_id == -1) {
                if (new_tag_id != -1) {
                    week_dicts.push({'tag_id':tag_id, 'dict_id':dict_id, 'field_name':col_name, 'other_tag':new_tag_id, 'rely_on': true})
                }
            } else {
                week_dicts.push({'tag_id':tag_id, 'dict_id':dict_id, 'field_name':col_name, 'other_tag':old_tag_id, 'rely_on': false})
                if (new_tag_id != -1) {
                    week_dicts.push({'tag_id':tag_id, 'dict_id':dict_id, 'field_name':col_name, 'other_tag':new_tag_id, 'rely_on': true})
                }
            }
        }
    }

    if (dicts.length <= 0 && week_dicts.lengh <= 0) {
        $("#importDictModal").modal('hide');
        return;
    }

    var post_data = {tag_id:tag_id, dicts:JSON.stringify(dicts), week_dicts:JSON.stringify(week_dicts)};
    console.log(post_data);
    var callback = callback_do_import_dict;
    var args = {};
    makeAPost(url, post_data, true, callback, args);

}
function callback_do_import_dict(result, args)
{
    $("#btn_import_dict_ok").button('reset');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }

    $("#importDictModal").modal('hide');
    location.reload();
}
function do_edit_node()
{
    $("#editNodeModal #btn_do_edit_node_ok").button('loading');
    var url = '/interest_graphs/tag/update_node/';
    var post_data = get_edit_node_post_data();
    var callback = callback_do_edit_node;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_edit_node(result, args)
{
    $("#editNodeModal #btn_do_edit_node_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#editNodeModal").modal('hide');
        location.reload();
//        location.href = '/interest_graphs/tag/detail/?id='+result.data;
    }
}
function get_edit_node_post_data()
{
    var post_data = {};
    post_data['id'] = tag_id;
    post_data['name'] = $("#editNodeModal #name").val().trim();
    post_data['type'] = $("#editNodeModal input[name='node_type']:checked").val().trim();
    post_data['attrs'] = [];
    $("#editNodeModal input[name='attr_type']:checked").each(function(){
        post_data['attrs'].push($(this).val());
    });
    post_data['interest_time'] = $("#editNodeModal input[name='time_maintain']:checked").val().trim();
    post_data['interest_strength'] = $("#editNodeModal input[name='intensity']:checked").val().trim();
    post_data['desc'] = $("#editNodeModal #desc").val().trim();
    post_data['is_dim'] = $("#editNodeModal #is_dim").is(":checked") ? 1 : 0;
    if(post_data['is_dim'])
    {
        post_data['is_single'] = $("#editNodeModal #is_single").is(":checked") ? 1 : 0;
    }

    return post_data;
}
function show_attrs()
{
    var url = '/interest_graphs/tag/attrs/';
    var post_data = get_edit_node_post_data();
    var callback = callback_show_attrs;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_attrs(result, args)
{
    if(result.status != 0)
    {
        $("#block_attr .block_header").after("<span class='block_attr_item'>加载属性失败</span>");
    }
    tag_selected_attrs = result.data;
    $("#block_attr .block_attr_item").remove();
    for(var i in result.data)
    {
        if(result.data[i].value_id == ATTR_TYPE_ALIAS)
        {
            show_attr_alias(result.data[i]);
        }
        else if(result.data[i].value_id == ATTR_TYPE_THEME)
        {
            show_attr_theme(result.data[i]);
        }
        else if(result.data[i].value_id == ATTR_TYPE_PATTERN)
        {
            show_attr_pattern(result.data[i]);
        }
        else if(result.data[i].value_id == ATTR_TYPE_RELY)
        {
            show_attr_rely(result.data[i]);
        }
        else if(result.data[i].value_id == ATTR_TYPE_CONSTRAIN)
        {
            show_attr_constrain(result.data[i]);
        }
        else if(result.data[i].value_id == ATTR_TYPE_DETAIL)
        {
            show_attr_detail(result.data[i]);
        }
        else
        {
            show_attr_other(result.data[i]);
        }
    }
    $("#block_attr").append('<div class="block_attr_footer block_attr_item">\
                                 <a class="btn btn-primary interest_graphs_btn_primary" data-loading-text="处理中..."  id="btn_edit_attr" onclick="edit_attr()">编辑属性</a>\
                             </div>');
}
function show_attr_alias(data)
{
    var html = '<div class="block_attr_item" id="block_attr_item_alias">\
                    <div class="attr_name">\
                        <span>'+data.name+'</span>\
                        <a class="btn btn-primary interest_graphs_btn_primary" data-toggle="collapse" onclick="toggle_edit_alias()">编辑</a>\
                    </div>\
                    <div class="attr_values">';
    var words = data.content ? JSON.parse(data.content) : [];
    for(var i in words)
    {
        if(words[i] != '')
        {
            html += '<span class="attr_value_item">'+words[i]+'</span>';
        }
    }
    html += '               <div id="attr_edit_alias" class="collapse">\
                            <textarea rows="5" id="textarea_alias"></textarea>\
                            <div class="op">\
                                <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_alias_ok" onclick="edit_attr_alias('+data.id+')">确定</a>\
                                <a class="btn btn-default" onclick="toggle_edit_alias()">取消</a>\
                            </div>\
                        </div>\
                    </div>\
                </div>';
    $("#block_attr").append(html);
}
function show_attr_theme(data)
{
    var html = '<div class="block_attr_item" id="block_attr_item_theme">\
                    <div class="attr_name">\
                        <span>'+data.name+'</span>\
                        <a class="btn btn-primary interest_graphs_btn_primary" data-toggle="collapse" onclick="toggle_edit_theme()">编辑</a>\
                    </div>\
                    <div class="attr_values">';
    for(var i in data.content)
    {
        html += '<span class="attr_value_item" action-data="'+data.content[i].id+'">'+data.content[i].name+'</span>';
    }
    html += '           <div id="attr_edit_theme" class="collapse">\
                            <input id="select2_theme" type="text" style="width:100%;">\
                            <div class="op">\
                                <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_theme_ok" onclick="edit_attr_theme('+data.id+')">确定</a>\
                                <a class="btn btn-default" onclick="toggle_edit_theme()">取消</a>\
                            </div>\
                        </div>\
                    </div>\
                </div>'
    $("#block_attr").append(html);
}
function show_attr_pattern(data)
{
    var html = '<div class="block_attr_item" id="block_attr_item_pattern">\
                    <div class="attr_name">\
                        <span>'+data.name+'</span>\
                        <a class="btn btn-primary interest_graphs_btn_primary" data-toggle="collapse" onclick="toggle_edit_pattern()">编辑</a>\
                    </div>\
                    <div class="attr_values">';
    var words = data.content ? JSON.parse(data.content) : [];
    for(var i in words)
    {
        if(words[i] != '')
        {
            html += '<span class="attr_value_item">'+words[i]+'</span>';
        }
    }
    html += '               <div id="attr_edit_pattern" class="collapse">\
                            <textarea rows="5" id="textarea_pattern"></textarea>\
                            <div class="op">\
                                <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_pattern_ok" onclick="edit_attr_pattern('+data.id+')">确定</a>\
                                <a class="btn btn-default" onclick="toggle_edit_pattern()">取消</a>\
                            </div>\
                        </div>\
                    </div>\
                </div>';
    $("#block_attr").append(html);
}
function show_attr_rely(data)
{
    var html = '<div class="block_attr_item" action-data="'+data.id+'" id="block_attr_item_rely">\
                    <div class="attr_name">\
                            <span>依赖</span>\
                            <a class="btn btn-primary interest_graphs_btn_primary" data-toggle="collapse" onclick="add_rely_line()">添加</a>\
                    </div>\
                    <div class="attr_values">';
    var lines = (data.content.length > 0) ? data.content : [];
    for(var i in lines)
    {
        html += '<div class="attr_rely_line">\
                     <a class="btn btn-primary interest_graphs_btn_primary attr_rely_line_op" data-toggle="collapse" onclick="toggle_edit_rely(this)">编辑</a>\
                        <div class="attr_rely_line_value_show">';
        for(var j in lines[i])
        {
            html += '<span class="attr_value_item" action-data="'+lines[i][j].id+'">'+lines[i][j].name+'</span>';
        }
        html += '<div class="attr_edit_rely collapse">\
                             <input class="select2_rely" style="width:50%;">\
                             <div class="op">\
                                 <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_rely_ok" onclick="edit_attr_rely(this)">确定</a>\
                                 <a class="btn btn-default" onclick="cancel_edit_rely(this)">取消</a>\
                             </div>\
                         </div>\
                     </div>\
                 </div>';
    }
    html += '   </div>\
             </div>';
    $("#block_attr").append(html);
}
function show_attr_constrain(data)
{
    var html = '<div class="block_attr_item" action-data="'+data.id+'" id="block_attr_item_constrain">\
                    <div class="attr_name">\
                            <span>约束</span>\
                            <a class="btn btn-primary interest_graphs_btn_primary" data-toggle="collapse" onclick="add_constrain_line()">添加</a>\
                    </div>\
                    <div class="attr_values">';
    var lines = (data.content.length > 0) ? data.content : [];
    for(var i in lines)
    {
        var action_data = lines[i];
        if(lines[i].type == 1)
        {
            action_data = {type:lines[i].type,value:[]}
            for(var k in lines[i].value)
            {
                action_data.value.push(lines[i].value[k].id);
            }
        }
        html += '<div class="attr_constrain_line" action-data=\''+JSON.stringify(action_data)+'\'>\
                     <a class="btn btn-primary interest_graphs_btn_primary attr_constrain_line_op" data-toggle="collapse" onclick="toggle_edit_constrain(this)">编辑</a>\
                      <div class="attr_constrain_line_value_show">';
        if(lines[i].type == 0)
        {
            html += '<span>取值范围: </span>';
            html += '<span class="attr_value_item">最小值'+(lines[i].value.min == undefined ? '无' : lines[i].value.min)+'</span>';
            html += '<span class="attr_value_item">最大值'+(lines[i].value.max == undefined ? '无' : lines[i].value.max)+'</span>';
        }
        else if(lines[i].type == 1)
        {
            html += '<span>标签集合: </span>';
            for(var j in lines[i].value)
            {
                html += '<span class="attr_value_item" action-data="'+lines[i].value[j].id+'">'+lines[i].value[j].name+'</span>';
            }
        }
        else if(lines[i].type == 2)
        {
            html += '<span>条件: </span>';
            html += '<span class="attr_value_item">'+lines[i].value+'</span>';
        }
        html += '<div class="attr_edit_constrain collapse">\
                          <div style="width:50%;">\
                            <select class="attr_constrain_type" style="padding: 2px 0;float:left;margin-right:10px;">\
                                <option value="0">取值范围</option>\
                                <option value="1">标签集合</option>\
                                <option value="2">条件</option>\
                            </select>\
                            <div class="attr_constrain_value">\
                            </div>\
                          </div>\
                          <div class="op">\
                              <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_constrain_ok" onclick="edit_attr_constrain(this)">确定</a>\
                              <a class="btn btn-default" onclick="cancel_edit_constrain(this)">取消</a>\
                          </div>\
                      </div>\
                 </div>\
             </div>';
    }
    html += '   </div>\
             </div>';
    $("#block_attr").append(html);
}
function show_attr_detail(data)
{
    var content = JSON.parse(data.content);
    for(var i in content)
    {
        var html = '';
        if(content[i].tags != undefined)
        {
            html = '<div class="block_attr_item block_attr_item_detail" action-data="'+content[i].parent_id+'">\
                        <div class="attr_name">\
                            <span><a target="_blank" href="/interest_graphs/tag/detail/?id='+content[i].parent_id+'">'+content[i].parent_name+'</a></span>';
            html += '   <a class="btn btn-primary interest_graphs_btn_primary attr_detail_op" action-data=\''+JSON.stringify(content[i].tags)+'\' onclick="toggle_edit_detail_tag(this)">编辑</a>';
            html += '   </div>\
                        <div class="attr_values" action-data=\''+JSON.stringify(content[i].tags)+'\'>';
            var show_items_num_max = 5;
            for(var j=0; j<Math.min(content[i].tags.length, show_items_num_max); j++)
            {
                html += '   <a class="item_tag_mapping" target="_blank" href="/interest_graphs/tag/detail/?id='+content[i].tags[j].tag_id+'">'+content[i].tags[j].tag_name+'</a>';
            }
            if(content[i].tags.length > show_items_num_max)
            {
                html += '   <a class="btn btn-primary interest_graphs_btn_primary" action-data=\''+JSON.stringify(content[i].tags)+'\' onclick="show_all_detail_attrs(this)">查看全部</a>';
            }
            html += '<div class="attr_edit_detail_tag collapse">\
                                 <input class="select2_detail_tag" style="width:50%;">\
                                 <div class="op" style="margin-top:10px;">\
                                     <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_detail_tag_ok" onclick="edit_attr_detail_tag(this)">确定</a>\
                                     <a class="btn btn-default" onclick="cancel_edit_detail(this)">取消</a>\
                                 </div>\
                             </div>\
                         </div>\
                     </div>'

            html += '    </div>\
                     </div>';
        }
        else if(content[i].tag_id != undefined && content[i].tag_id !== '')
        {
            html = '<div class="block_attr_item block_attr_item_detail" action-data="'+content[i].parent_id+'">\
                        <div class="attr_name">\
                            <span><a target="_blank" href="/interest_graphs/tag/detail/?id='+content[i].parent_id+'">'+content[i].parent_name+'</a></span>\
                            <a class="btn btn-primary interest_graphs_btn_primary attr_detail_op" action-data=\''+JSON.stringify(content[i].tags)+'\' onclick="toggle_edit_detail_tag(this)">编辑</a>\
                        </div>\
                        <div class="attr_values" action-data=\''+JSON.stringify([{tag_id:content[i].tag_id, tag_name:content[i].tag_name}])+'\'>\
                        <a class="item_tag_mapping" target="_blank" href="/interest_graphs/tag/detail/?id='+content[i].tag_id+'">'+content[i].tag_name+'</a>';
            html += '   <div class="attr_edit_detail_tag collapse">\
                             <input class="select2_detail_tag" style="width:50%;">\
                             <div class="op" style="margin-top:10px;">\
                                <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_detail_tag_ok" onclick="edit_attr_detail_tag(this)">确定</a>\
                                <a class="btn btn-default" onclick="cancel_edit_detail(this)">取消</a>\
                             </div>\
                         </div>\
                      </div>';
        }
        else
        {
            html = '<div class="block_attr_item block_attr_item_detail block_attr_item_detail_plain">\
                        <div class="attr_name">\
                            <span class="plain_attr_name">'+content[i].name+'</span>\
                            <a class="btn btn-primary interest_graphs_btn_primary" data-toggle="collapse" onclick="toggle_edit_plain_attr(this)">编辑</a>\
                        </div>\
                        <div class="attr_values">\
                        <span class="attr_value_item">'+content[i].value+'</span>';
            html += '<div class="attr_edit_detail_plain collapse">\
                          <textarea rows="5" class="textarea_plain"></textarea>\
                          <div class="op">\
                              <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_plain_ok" onclick="edit_attr_detail_plain(this)">确定</a>\
                              <a class="btn btn-default" onclick="cancel_edit_detail_plain(this)">取消</a>\
                          </div>\
                     </div>';

            html += '</div></div>';
        }
        $("#block_attr").append(html);
    }
}
function show_attr_other(data)
{
    var html = '<div class="block_attr_item block_attr_item_other">\
                    <div class="attr_name">\
                        <span>'+data.name+'</span>\
                        <a class="btn btn-primary interest_graphs_btn_primary" data-toggle="collapse" onclick="toggle_edit_other(this)">编辑</a>\
                    </div>\
                    <div class="attr_values">';
    var words = data.content ? JSON.parse(data.content) : [];
    for(var i in words)
    {
        if(words[i] != '')
        {
            html += '<span class="attr_value_item">'+words[i]+'</span>';
        }
    }
    html += '               <div class="attr_edit_other collapse">\
                            <textarea rows="5" class="textarea_other"></textarea>\
                            <div class="op">\
                                <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_other_ok" onclick="edit_attr_other(this, '+data.id+')">确定</a>\
                                <a class="btn btn-default" onclick="toggle_edit_other(this)">取消</a>\
                            </div>\
                        </div>\
                    </div>\
                </div>';
    $("#block_attr").append(html);
}


function create_dict_detail_table(result) {
    dict_detail_result = result;
    var new_table = '<table class="table table-bordered dict_detail_fields_list">'+
        '<tr>'+
            '<td style="width:30%"><strong>属性</strong></td>'+
            '<td style="width:70%"><strong>值</strong></td>'+
        '</tr>'
    for (var i = 0; i < result.json_ret.length; ++i) {
        if (result.json_ret[i].chinese_name == '是否删除') {
            continue;
        }
        var tmp_row = '<tr>' +
            '<td class="field_name">' + result.json_ret[i].chinese_name + '</td>' +
            '<td class="field_name">' + result.json_ret[i].value + '</td>' +
            '</td>' +
        '</tr>'
        new_table += tmp_row
    }
    $("#modle_attr").html(new_table)
}

function get_more_week_rely_data(field_name, dict_id, strong_tag_id, word_name) {
    start_idx = $(".dict_detail_fields_list_" + strong_tag_id + " tr:gt(0)").length * 2
    tmp_dict = { "dict_id": dict_id, 'field_name': field_name, 'word_name': word_name, 'strong_tag_id': strong_tag_id, 'tag_id': tag_id , 'start_idx': start_idx, 'end_idx': start_idx + 10};
    $.ajax({
        url: '/interest_graphs/tag/dict/get_rely_week_word_list/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: true,
        success: function (result) {
            if (result.status == 0) {
                for (var i = 0; i < result.data_list.length; i+= 2) {
                    var second_td = '';
                    if (i + 1 < result.data_list.length) {
                        second_td = result.data_list[i + 1];
                    }
                    var tmp_row = '<tr>' +
                        '<td style="font-size:5px;width:50%;">' + result.data_list[i] + '</td>' +
                        '</td>' +
                        '<td style="font-size:5px;width:50%;">' + second_td + '</td>' +
                        '</td>' +
                    '</tr>'
                    $(".dict_detail_fields_list_" + strong_tag_id).append(tmp_row)
                }
            } else {
                $("#modle_attr").html("没有属性值！")
            }
        }
    });
}

function create_dicts_rely_tag_table(result, word_name) {
    var new_table = '';
    for (var table_idx = 0; table_idx < result.data_list.length; ++table_idx) {
        new_table += '<table class="table table-bordered dict_detail_fields_list_' + result.data_list[table_idx].strong_tag_id + '">'+
            '<tr>'+
                '<td style="width:50%;margin-bottom:10px;background-color: #60A4CC;border-color: #60A4CC;"><strong>' + result.data_list[table_idx].tag_name + '</strong></td>'+
                '<td style="width:50%;margin-bottom:10px;background-color: #60A4CC;border-color: #60A4CC;"><strong></strong></td>'+
            '</tr>'
        for (var i = 0; i < result.data_list[table_idx].word_list.length; i += 2) {
            var second_td = ''
            if (i + 1 < result.data_list[table_idx].word_list.length) {
                second_td = result.data_list[table_idx].word_list[i + 1];
            }
            var tmp_row = '<tr>' +
                '<td style="font-size:5px;width:50%;">' + result.data_list[table_idx].word_list[i] + '</td>' +
                '</td>' +
                '<td style="font-size:5px;width:50%;">' + second_td + '</td>' +
                '</td>' +
            '</tr>'
            new_table += tmp_row
        }
        new_table += '</table><input type="button" style="margin-bottom:10px;margin-left:499px;background-color: #60A4CC;border-color: #60A4CC;" '+
                    'value="更多" onclick="get_more_week_rely_data(\'' + result.data_list[table_idx].field_name + '\',' + 
                    result.data_list[table_idx].dict_id  + ',' + result.data_list[table_idx].strong_tag_id +  
                    ',\'' + word_name + '\'' +
                    ')" class="btn btn-primary">'
    }

    if (result.data_list.length <= 0) {
        new_table = '没有关联关系！';
    }
    $("#modle_rely").html(new_table)
}

function show_tag_words_info(dict_id, word_id, word_name) {
    $('#show_tag_word_name').html(word_name);
    $("#show_tag_word_model").modal('show');    

    tmp_dict = { "dict_id": dict_id, 'word_id': word_id };
    $.ajax({
        url: '/interest_graphs/tag/dict/get_dict_word_info/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: true,
        success: function (result) {
            if (result.status == 0) {
                dict_detail_word_id = word_id
                create_dict_detail_table(result)
            } else {
                $("#modle_attr").html("没有属性值！")
            }
        }
    });

    tmp_dict = { "tag_id": tag_id, "word_name": word_name };
    $.ajax({
        url: '/interest_graphs/tag/dict/get_all_week_rely_dict_words/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: true,
        success: function (result) {
            if (result.status == 0) {
                create_dicts_rely_tag_table(result, word_name)
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });

}

function delete_word(dict_id, word_id, word)
{
    $("#btn_do_delete_word_ok").attr('onclick', 'delete_tag_words('+dict_id+',' + word_id + ',\'' + word + '\')');
    $("#deleteConfirmModal").modal('show');
}

function delete_tag_words(dict_id, word_id, word) {    
    tmp_dict = { "tag_id": tag_id, "dict_id": dict_id, 'word_id': word_id, 'word': word };
    $.ajax({
        url: '/interest_graphs/tag/dict/delete_tag_words/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: false,
        success: function (result) {
            $("#deleteConfirmModal").modal('hide');
            if (result.status == 0) {
                location.reload();
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function init_table_subnode_list()
{
    url = "/interest_graphs/tag/list/"
    if (tag_type == 1) {
        url = '/interest_graphs/tag/dict/get_tag_word_list/';
    }

    table_subnode_list = $("#table_subnode_list").DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": url,
            "type": "POST",
            "data":function(d){
                d.parent_id = tag_id;
            },
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "name",
            bSortable: false
        }, {
            data: "term_id",
            bSortable: false
        }, {
            data: "size",
            bSortable: false
        }, {
            data: "desc",
            bSortable: false
        }],
                
        "columnDefs": [
            {
                "targets":[0],
                "render":function(data,type,full){
                    var inherite_flag = '';
                    if(full.inherit_id)
                    {
                        inherite_flag = '<sup><span style="color: #ef7f3d;margin-left: 5px;" class="glyphicon glyphicon-camera" aria-hidden="true"></span></sup>';
                    }

                    if (tag_type == 1) {
                        return '<a href="#" onclick="show_tag_words_info(' + full.dict_id + ',' + full.term_id + ',\'' + full.name + '\');">'+data+'</a>';
                    }
                    return '<a href="/interest_graphs/tag/detail/?flag=1&id='+full.id+'">'+data+'</a>'+inherite_flag;
                },
            },
            {
                "targets":[1],
                "render":function(data,type,full){
                    if (full.dict_id != -1) {
                        return '实体词典';
                    } 
                    return '手动创建';
                },
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    if (tag_type == 1) {
                        return '<a onclick="show_tag_words_info(' + full.dict_id + ',' + full.term_id + ',\'' + full.name + '\');" href="#">查看</a> | <a href="javascript:" onclick="delete_word(' + full.dict_id + ',' + full.term_id+ ',\'' + full.name +'\')">删除</a>';
                    }

                    var ret = '<a href="/interest_graphs/tag/detail/?id='+full.id+'">查看</a> | <a href="javascript:" onclick="delete_subnode('+full.id+')">删除</a>';
                    return ret;
                },
            },
        ]

    });
}

function add_tag_words() {
    tmp_dict = { "tag_id": tag_id };
    $.ajax({
        url: '/interest_graphs/tag/dict/get_all_user_create_tag_words/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: true,
        success: function (result) {
            if (result.status == 0) {
                $("#new_tag_words").val(result.words_str)
                $("#batch_create_tag_words_model").modal("show");
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function create_batch_tag_words() {
    $("#add_tag_words_busy").show()
    tmp_dict = { "tag_id": tag_id, "words": $("#new_tag_words").val() };
    $.ajax({
        url: '/interest_graphs/tag/dict/insert_tag_words_by_user/',
        type: 'POST',
        dataType: "json",
        data: tmp_dict,
        async: true,
        success: function (result) {
            if (result.status == 0) {
                $("#add_tag_words_busy").hide()
                $("#batch_create_tag_words_model").modal("hide");
                location.reload();
            } else {
                showMessage("error", "失败", result.msg);
            }
        }
    });
}

function add_subnode()
{
    $("#btn_add_subnode").button('loading');
    var url = '/interest_graphs/tag/list_profile_attr/';
    var post_data = {'id':tag_id};
    var callback = callback_add_subnode;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_add_subnode(result_attr, args)
{
    $("#btn_add_subnode").button('reset');
    if(result_attr.status != 0)
    {
        ark_notify(result_attr);
        return;
    }
    //初始化
    $("#editNodeModal #btn_do_edit_node_ok").attr("onclick", 'do_add_subnode()');
    if(init_html_edit_node_modal)
    {
        $("#editNodeModal .modal-body").html(init_html_edit_node_modal);
    }
    else
    {
        init_html_edit_node_modal = $("#editNodeModal .modal-body").html();
    }
    $("#editNodeModal #inherite_node").select2({
        placeholder: '请输入标签名称',
        ajax: {
            url: '/interest_graphs/tag/list_for_inherit/', 
            type:'POST',
            dataType: 'json',
            data: function (term, page) {
              var query = {
                node_id: tag_id,
                query: term,
                page: page,
                search_all:1,
              }
              return query;
            },
            results: function (data) {
                var ret = [];
                if(data.status ==0)
                {
                    for(var i in data.data)
                    {
                        ret.push({id:data.data[i].id, text:data.data[i].name});
                    }
                }
                return {
                  results: ret
                };
            }
        },
        language: 'ch',
    });
    $("#editNodeModal .item_create_subnode").show();
    for(var i in result_attr.data)
    {
        $("#profile_attr_list").append('<label class="checkbox-inline"><input type="checkbox" name="attr_type" value="'+result_attr.data[i].id+'">'+result_attr.data[i].name+'</label>');
    }
    if(tag_detail.info.is_dim)
    {
        $("#editNodeModal [name='node_type'][value='"+tag_detail.info.type+"']").prop('checked', true);
        $("#editNodeModal [name='node_type']").prop('disabled', true);
        //在维度节点下新建节点时，属性应默认勾选上维度节点已有的属性类型
        for(var i in tag_selected_attrs)
        {
            $("#profile_attr_list [name='attr_type'][value='"+tag_selected_attrs[i].value_id+"']").prop('checked', true);
        }
    }
    $("#editNodeModal .modal-title").html('单点新建');
    $("#editNodeModal").modal('show');
}
function do_add_subnode()
{
    $("#editNodeModal #btn_do_edit_node_ok").button('loading');
    var url = '/interest_graphs/tag/create_node/';
    var post_data = {};
    if($(".item_create_subnode [name='create_subnode_type']:checked").val() == 0)
    {
        post_data = get_edit_node_post_data();
    }
    else
    {
        post_data['inherit_id'] = $("input#inherite_node").val();
        url = '/interest_graphs/tag/create_with_inherit/';
    }
    post_data['parent_id'] = tag_id;
    var callback = callback_do_add_subnode;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_subnode(result, args)
{
    $("#editNodeModal #btn_do_edit_node_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#editNodeModal").modal('hide');
        table_subnode_list.ajax.reload();
    }
}
function delete_subnode(tag_id)
{
    $("#deleteSubNodeConfirmModal #btn_do_delete_subnode_ok").attr('onclick', 'do_delete_subnode('+tag_id+')');
    $("#deleteSubNodeConfirmModal").modal('show');
}
function do_delete_subnode(id)
{
    $("#deleteSubNodeConfirmModal #btn_do_delete_subnode_ok").button('loading');
    var url = '/interest_graphs/tag/delete/';
    var post_data = {id:id};
    var callback = callback_do_delete_subnode;
    var args = {id:id};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_subnode(result, args)
{
    $("#deleteSubNodeConfirmModal #btn_do_delete_subnode_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteSubNodeConfirmModal").modal('hide');
        table_subnode_list.ajax.reload();
    }
}
function hide_upsert_attr_modal()
{
    $("#editNodeAttrModal").modal('hide');
}
function edit_attr()
{
    $("#btn_edit_attr").button('loading');
    $("#editNodeAttrModal #btn_do_upsert_attr_ok").attr('onclick', 'do_edit_attr()');
    $("#editNodeAttrModal #btn_do_upsert_attr_cancel").attr('onclick', 'hide_upsert_attr_modal()');
    var url = '/interest_graphs/tag/detail/';
    var post_data = {'id':tag_id};
    var callback = callback_edit_attr_modal;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_edit_attr_modal(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        $("#btn_edit_attr").button('reset');
        return;
    }

    var url = '/interest_graphs/tag/list_profile_attr/';
    var post_data = {};
    var result_attr = makeAPost(url, post_data);
    $("#btn_edit_attr").button('reset');
    if(result_attr.status != 0)
    {
        ark_notify(result_attr);
        return;
    }
    //初始化
    $("#editNodeModal #btn_do_edit_node_ok").attr("onclick", 'do_add_subnode()');
    if(init_html_edit_attr_modal)
    {
        $("#editNodeAttrModal .modal-content").html(init_html_edit_attr_modal);
    }
    else
    {
        init_html_edit_attr_modal = $("#editNodeAttrModal .modal-content").html();
    }
    for(var i in result_attr.data)
    {
//        $("#single_edit_profile_attr_list").append('<label class="checkbox-inline"><input type="checkbox" name="attr_type" value="'+result_attr.data[i].id+'">'+result_attr.data[i].name+'</label>');
        var delete_html = result_attr.data[i].id > 6 ? '<sup><span class="glyphicon glyphicon-remove" aria-hidden="true" title="删除" onclick="delete_attr(this)"></span></sup>' : '';
        $("#single_edit_profile_attr_list").append('<div class="attr_item_block"><span class="attr_item_block_name" action-data="'+result_attr.data[i].id+'">'+result_attr.data[i].name+'</span>'+delete_html+'</div>');
    }
    var old_attrs = result.data.attrs;
    $("#editNodeAttrModal .attr_item_block_name").each(function(){
        for(var i in old_attrs)
        {
            if($(this).attr('action-data') == old_attrs[i].value_id)
            {
                $(this).addClass('active');
            }
        }
    });
    $("#editNodeAttrModal").modal('show');
}
function do_edit_attr()
{
    $("#btn_do_upsert_attr_ok").button('loading');
    var url = '/interest_graphs/tag/select_attr/';
    var post_data = {'id':tag_id};
    post_data['attr_ids'] = [];
    $("#editNodeAttrModal .attr_item_block_name.active").each(function(){
        post_data['attr_ids'].push($(this).attr('action-data'));
    });
    var callback = callback_select_attr;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_select_attr(result, args)
{
    ark_notify(result);
    if(result.status != 0)
    {
        $("#btn_do_upsert_attr_ok").button('reset');
        return;
    }
    $("#editNodeAttrModal").modal('hide');
    show_attrs();
}
function add_attr()
{
    $("#editNodeAttrModal #btn_do_upsert_attr_cancel").attr('onclick', 'cancel_add_attr()');
    $("#editNodeAttrModal #btn_do_upsert_attr_ok").attr('onclick', 'do_add_attr()');
    $("#a_add_new_attr").slideToggle();
    $("#editNodeAttrModal #form_edit_attr").slideToggle();
    $('#editNodeAttrModal #form_add_attr').collapse('toggle');
}
function cancel_add_attr()
{
    $("#editNodeAttrModal #btn_do_upsert_attr_ok").attr('onclick', 'do_edit_attr()');
    $("#editNodeAttrModal #btn_do_upsert_attr_cancel").attr('onclick', 'hide_upsert_attr_modal()');
    $("#a_add_new_attr").slideToggle();
    $("#editNodeAttrModal #form_edit_attr").slideToggle();
    $('#editNodeAttrModal #form_add_attr').collapse('toggle');
}
function do_add_attr()
{
    $("#btn_do_upsert_attr_ok").button('loading');
    var url = '/interest_graphs/tag/create_profile_attr/';
    var post_data = {};
    var new_attr_name = $('#form_add_attr #attr_name').val().trim();
    post_data['name'] = new_attr_name;
    post_data['value_type'] = $('#form_add_attr #attr_type').val();
    if(new_attr_name == '')
    {
        ark_notify({status:1,msg:'属性名称不能为空'});
        $("#btn_do_upsert_attr_ok").button('reset');
        return;
    }
    var callback = callback_do_add_attr;
    var args = {new_attr_name:new_attr_name};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_attr(result, args)
{
    $("#btn_do_upsert_attr_ok").button('reset');
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    $("#single_edit_profile_attr_list").append('<div class="attr_item_block"><span class="attr_item_block_name" action-data="'+result.data+'">'+args.new_attr_name+'</span><sup><span class="glyphicon glyphicon-remove" aria-hidden="true" title="删除" onclick="delete_attr(this)"></span></sup></div>');
    cancel_add_attr();
}
function get_relate_dicts()
{
    var url = '/interest_graphs/tag/relate_dicts/';
    var post_data = {id:tag_id};
    var callback = callback_relate_dicts;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_relate_dicts(result, args)
{
    if(result.status == 0)
    {
        for(i in result.data)
        {
            $(".dict_block .related_block_body").append('<p class="sider_block_item"><a href="/interest_graphs/tag/dict/detail_index/?id='+result.data[i].id+'">'+result.data[i].name+'</a></p>');
        }
        if(result.data.length < 1)
        {
            $(".dict_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无词典信息</p>');
        }
    }
    else
    {
        $(".dict_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无词典信息</p>');
    }
}
function get_be_inherited_info()
{
    var url = '/interest_graphs/tag/be_inherited_info/';
    var post_data = {id:tag_id};
    var callback = callback_be_inherited_info;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_be_inherited_info(result, args)
{
    if(result.status == 0)
    {
        for(i in result.data)
        {
            $(".be_inherited_block .related_block_body").append('<p class="sider_block_item"><a href="/interest_graphs/tag/detail/?id='+result.data[i][0]+'">'+result.data[i][1]+'</a></p>');
        }
        if(result.data.length < 1)
        {
            $(".be_inherited_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无被继承信息</p>');
        }
    }
    else
    {
        $(".be_inherited_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无被继承信息</p>');
    }
}
function get_inherited_info()
{
    var url = '/interest_graphs/tag/inherit_info/';
    var post_data = {id:tag_id};
    var callback = callback_inherit_info;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_inherit_info(result, args)
{
    if(result.status == 0)
    {
        for(i in result.data)
        {
            $(".inherit_block .related_block_body").append('<p class="sider_block_item"><a href="/interest_graphs/tag/dict/detail_index/?id='+result.data[i][0]+'">'+result.data[i][1]+'</a></p>');
        }
        if(result.data.length < 1)
        {
            $(".inherit_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无继承信息</p>');
        }
    }
    else
    {
        $(".be_inherited_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无继承信息</p>');
    }
}
function get_be_relied()
{
    var url = '/interest_graphs/tag/be_relied/';
    var post_data = {id:tag_id};
    var callback = callback_be_relied;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_be_relied(result, args)
{
    if(result.status == 0)
    {
        for(i in result.data)
        {
            $(".be_relied_block .related_block_body").append('<p class="sider_block_item"><a href="/interest_graphs/tag/detail/?id='+result.data[i][0]+'">'+result.data[i][1]+'</a></p>');
        }
        if(result.data.length < 1)
        {
            $(".be_relied_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无依赖信息</p>');
        }
    }
    else
    {
        $(".be_relied_block .related_block_body").append('<p class="sider_block_item relate_empty">暂无依赖信息</p>');
    }
}
function add_constrain_line()
{
    var html = '';
    html += '<div class="attr_constrain_line">\
                 <a class="btn btn-primary interest_graphs_btn_primary attr_constrain_line_op" style="display:none" data-toggle="collapse" onclick="toggle_edit_constrain(this)">编辑</a>\
                  <div class="attr_constrain_line_value_show">\
                      <div class="attr_edit_constrain collapse">\
                          <div style="width:50%;">\
                            <select class="attr_constrain_type" style="padding: 2px 0;float:left;margin-right:10px;">\
                                <option value="0">取值范围</option>\
                                <option value="1">标签集合</option>\
                                <option value="2">条件</option>\
                            </select>\
                            <div class="attr_constrain_value">\
                            </div>\
                          </div>\
                          <div class="op">\
                              <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_constrain_ok" onclick="edit_attr_constrain(this)">确定</a>\
                              <a class="btn btn-default" onclick="cancel_edit_constrain(this)">取消</a>\
                          </div>\
                      </div>\
                 </div>\
             </div>';
    $("#block_attr_item_constrain .attr_values").append(html);
    $("#block_attr_item_constrain .attr_constrain_line .attr_constrain_line_op:last").trigger('click');
    $("#block_attr_item_constrain .attr_constrain_line:last .attr_constrain_type").trigger('change');
}
function add_rely_line()
{
    var html = '';
    html += '<div class="attr_rely_line">\
                 <a class="btn btn-primary interest_graphs_btn_primary attr_rely_line_op" style="display:none" data-toggle="collapse" onclick="toggle_edit_rely(this)">编辑</a>\
                  <div class="attr_rely_line_value_show">\
                      <div class="attr_edit_rely collapse">\
                          <input class="select2_rely" style="width:50%;">\
                          <div class="op">\
                              <a class="btn btn-default" data-loading-text="处理中..."  id="btn_do_edit_attr_rely_ok" onclick="edit_attr_rely(this)">确定</a>\
                              <a class="btn btn-default" onclick="cancel_edit_rely(this)">取消</a>\
                          </div>\
                      </div>\
                 </div>\
             </div>'
    $("#block_attr_item_rely .attr_values").append(html);
    $("#block_attr_item_rely .attr_rely_line .attr_rely_line_op:last").trigger('click');
}
function cancel_edit_rely(obj)
{
    $(obj).parents(".attr_rely_line").find(".attr_rely_line_op").trigger('click');
}
function cancel_edit_detail(obj)
{
    $(obj).parents(".block_attr_item_detail").find(".attr_detail_op").trigger('click');
}
function cancel_edit_constrain(obj)
{
    $(obj).parents(".attr_constrain_line").find(".attr_constrain_line_op").trigger('click');
}
function select_attr_from_import(obj)
{
    var dict_id = $(obj).parents("tr").attr("action-data");
    $("#importDictAttrModal .modal-body").html("加载中...");
    $("#importDictAttrModal #btn_save_dict_attr_conf").attr("onclick", "save_dict_attr_conf("+dict_id+")");
    var url = '/interest_graphs/tag/dict/dict_tags_attrs/';
    var post_data = {id:dict_id};
    var callback = callback_select_attr_from_import;
    var args = {obj:obj};
    makeAPost(url, post_data, true, callback, args);
}
function callback_select_attr_from_import(result, args)
{
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    if(result.tags.length < 1 && result.attrs.length < 1)
    {
        //$("#importDictAttrModal .modal-body").html("无可配置的属性");
        ark_notify({status:1,msg:'暂无可配置的属性'});
        return;
    }
    var action_data_config_str = $(args.obj).parents('tr').attr('action-data-attr-conf');
    if(action_data_config_str != undefined)
    {
        action_data_config_json = JSON.parse(action_data_config_str);
    }
    else
    {
        action_data_config_json = {};
    }
    if(action_data_config_json.attr_filter_reg == undefined)
    {
        action_data_config_json.attr_filter_reg = '';
    }
    if(action_data_config_json.attrs == undefined)
    {
        action_data_config_json.attrs = [];
    }
    if(action_data_config_json.tag_id == undefined || action_data_config_json.tag_id == '')
    {
        action_data_config_json.tag_id = [];
    }
    else
    {
        action_data_config_json.tag_id = action_data_config_json.tag_id.split(',');
    }
    $("#importDictAttrModal").modal("show");
    var html = '<form class="form-horizontal" id="form_attr_filter_reg">\
                    <div class="form-group">\
                        <label class="col-sm-2 control-label">筛选条件</label>\
                        <div class="col-sm-8">\
                            <input type="text" class="form-control" id="attr_filter_reg" value=\''+action_data_config_json.attr_filter_reg+'\' placeholder="请输入属性过滤">\
                        </div>\
                    </div>\
                </form>';
    if(result.tags.length > 0)
    {
        html += '<form class="form-horizontal" id="form_attr_relation">';
        html += '<span id="form_title_attr_relation">节点关系</span>';
        for(var j in result.tags)
        {
            html += '<div class="form-group">\
                         <label class="col-sm-3 control-label">'+result.tags[j].name+'</label>\
                         <div class="col-sm-8">\
                            <select class="form-control attr_tag_mapping">\
                                <option></option>';
            for(var i in result.tags[j].tags)
            {
                var selected_str = (action_data_config_json.tag_id.indexOf(String(result.tags[j].tags[i].id)) > -1) ? 'selected' : '';
                html += '<option value="'+result.tags[j].tags[i].id+'" '+selected_str+'>'+result.tags[j].tags[i].name+'</option>';
            }
            html += '       </select>\
                         </div>\
                     </div>';
        }
        html += '</form>';
    }
    if(result.attrs.length > 0)
    {
        html += '<form class="form-horizontal" id="form_attr_detail" style="margin-top: 30px;">';
        html += '<span id="form_title_attr_detail">普通属性</span>';
        html += '<div class="form-group">\
                     <div class="col-sm-10">';
        for(var i in result.attrs)
        {
            var checked_str = (action_data_config_json.attrs.indexOf(result.attrs[i]) > -1) ? 'checked' : '';
            html += '<label class="checkbox-inline"><input type="checkbox" name="checkbox_attr_name" '+checked_str+' value="'+result.attrs[i]+'">'+result.attrs[i]+'</label>';
        }
        html += '    </div>\
                 </div>';
        html += '</form>'; }
    $("#importDictAttrModal .modal-body").html(html);
    $(".attr_tag_mapping").select2({allowClear:true});
}
function save_dict_attr_conf(dict_id)
{
    var conf = {id:dict_id};
    var attr_filter_reg = $("#importDictAttrModal #attr_filter_reg").val().trim();
    conf.attr_filter_reg = attr_filter_reg;
    var tag_ids = [];
    $("#importDictAttrModal select.attr_tag_mapping").each(function(){
        var tag_id = $(this).val().trim();
        if(tag_id)
        {
            tag_ids.push(tag_id);
        }
    });
    if(tag_ids.length > 0)
    {
        conf.tag_id = tag_ids.join(',');
    }
    var attrs = [];
    $("#importDictAttrModal [name='checkbox_attr_name']:checked").each(function(){
        attrs.push($(this).val());
    });
    if(attrs.length > 0)
    {
        conf.attrs = attrs;
    }
    $("#table_dict_imported_show tr[action-data='"+dict_id+"']").attr('action-data-attr-conf', JSON.stringify(conf));
    $("#importDictAttrModal").modal("hide");
}
function delete_attr(obj)
{
    var item = $(obj).parents('.attr_item_block').find('.attr_item_block_name');
    var attr_id = item.attr('action-data');
    $("#deleteProfileAttrModal #btn_delete_attr").attr('onclick', 'do_delete_attr('+attr_id+')');
    $("#deleteProfileAttrModal").modal('show');
}
function do_delete_attr(attr_id)
{
    $("#deleteProfileAttrModal #btn_delete_attr").button('loading');
    var url = '/interest_graphs/tag/delete_profile_attr/';
    var post_data = {id:attr_id};
    var callback = callback_do_delete_attr;
    var args = {id:attr_id};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_delete_attr(result, args)
{
    $("#deleteProfileAttrModal #btn_delete_attr").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#single_edit_profile_attr_list .attr_item_block_name[action-data='"+args.id+"']").parent().remove();
        $("#deleteProfileAttrModal").modal('hide');
    }
}
function show_all_detail_attrs(obj)
{
    $("#detailAttrShowAllModal .modal-body").empty();
    var tags = JSON.parse($(obj).attr('action-data'));
    for(var i in tags)
    {
        $("#detailAttrShowAllModal .modal-body").append('<p><a target="_blank" href="/interest_graphs/tag/detail/?id='+tags[i].tag_id+'">'+tags[i].tag_name+'</a></p>');
    }
    $("#detailAttrShowAllModal").modal('show');
}
function toggle_edit_detail_tag(obj)
{
    var url = '/interest_graphs/tag/list/';
    var parent_tag_id = $(obj).parents('.block_attr_item_detail').attr('action-data');
    $(obj).parents(".block_attr_item_detail").find('.attr_edit_detail_tag').on('show.bs.collapse', function () {
        var cur_tag_ids = [];
        var cur_tag_data = [];
        var tags = JSON.parse($(this).parent().attr('action-data'));
        for(var i in tags)
        {
            cur_tag_ids.push(tags[i].tag_id);
            cur_tag_data.push({id:tags[i].tag_id, text:tags[i].tag_name});
        };
        $(this).find(".select2_detail_tag").val(cur_tag_ids.join(','));
        $(this).find(".select2_detail_tag").attr('action-data', JSON.stringify(cur_tag_data));
        $(this).find(".select2_detail_tag").select2({
            placeholder: '请输入标签名称',
            multiple: true,
            ajax: {
                url: url, 
                type:'POST',
                dataType: 'json',
                data: function (term, page) {
                  var query = {
                    'search[value]': term,
                    parent_id:parent_tag_id,
                    length:10,
                  }
                  return query;
                },
                results: function (data) {
                    var ret = [];
                    if(data.status ==0)
                    {
                        for(var i in data.data)
                        {
                            ret.push({id:data.data[i].id, text:data.data[i].name});
                        }
                    }
                    return {
                      results: ret
                    };
                }
            },
            initSelection: function (element, callback) {
                var data = JSON.parse(element.attr('action-data'));
                callback(data);//这里初始化
            },
            language: 'ch',
        });
    })
    $(obj).parents('.block_attr_item_detail').find(".attr_values>a").slideToggle();
    $(obj).parents('.block_attr_item_detail').find('.attr_edit_detail_tag').collapse('toggle');
}
function edit_attr_detail_tag(obj)
{
    var tag_ids = $(obj).parents('.attr_edit_detail_tag').find("input.select2_detail_tag").val().trim();
    tag_ids = tag_ids ? tag_ids.split(',') : [];
    var term_id = tag_detail.info.term_id;
    var parent_tag_id = $(obj).parents('.block_attr_item_detail').attr("action-data");
    var post_data = {term_id:term_id, tag_ids:tag_ids, parent_tag_id:parent_tag_id};
    var url = '/interest_graphs/tag/update_mapping_attr/';
    var callback = callback_edit_attr;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function cancel_edit_detail_plain(obj)
{
    $(obj).parents('.block_attr_item_detail').find('[data-toggle="collapse"]').trigger('click');
}
function toggle_edit_plain_attr(obj)
{
    $(".block_attr_item_detail_plain").removeClass("cur_upload");
    $(obj).parents('.block_attr_item_detail').find('.attr_edit_detail_plain').on('show.bs.collapse', function () {
        var cur_word = $(this).parents('.block_attr_item_detail').find('.attr_value_item').text();
        $(this).parents('.block_attr_item_detail').find(".textarea_plain").val(cur_word);
    })
    $(obj).parents('.block_attr_item_detail').find(".attr_value_item").slideToggle();
    $(obj).parents('.block_attr_item_detail').find('.attr_edit_detail_plain').collapse('toggle');
}
function edit_attr_detail_plain(obj)
{
    $(obj).parents(".block_attr_item_detail_plain").addClass("cur_upload");
    var new_attrs = {};
    var cur_key = $(obj).parents('.block_attr_item_detail').find('.plain_attr_name').text();
    var cur_val = $(obj).parents('.block_attr_item_detail').find(".textarea_plain").val().trim();
    new_attrs[cur_key] = cur_val;
    $(".block_attr_item_detail_plain").each(function(){
        if(!$(this).hasClass('cur_upload'))
        {
            var item_key = $(this).find('.plain_attr_name').text();
            var item_val = $(this).find('.attr_value_item').text();
            new_attrs[item_key] = item_val;
        }
    });
    var post_data = {term_id:tag_detail.info.term_id, attrs:JSON.stringify(new_attrs)};
    var url = '/interest_graphs/tag/dict/update_term_attrs/';
    var callback = callback_edit_attr;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
