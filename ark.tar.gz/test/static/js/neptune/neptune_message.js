function goview(that){
    var that=$(that);
    var str;
    if(index==0){
        str="全部消息";
    }else if(index==1){
        str="权限消息";
    }else{
        str="上线消息";
    }
    var content=that.attr('content');
     $('#content').append('<div class="modal"><div class="togglemodal" style="width:620px;height:285px;margin-left:-310px"><span class="cr-mess" style="margin-bottom:10px;float:left;margin-left:269px">'+str+'</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:575px;margin-top:15px;clear:both"></span><p class="cr-p" style="text-align:left;margin-top:10px">'+content+'</p></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);


}
function addMessage(data){
    if(data.status==0){
        
    }else{

    }
}
function deleteMessage(that){
    var that=$(that);
    mess_id_del_single = that.attr('mess_id');
    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">操作确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定要删除该消息吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="do_deleteMessage()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
}
function do_deleteMessage()
{
    getAjaxData('post','/neptune/delete_message/',messageM,{'id[]':[mess_id_del_single]});    
}
function messageM(data){
    deletemodal();
    if(data.status==0){
        if(index==0){
            $('.nav-li:eq(0)').trigger('click');
        }else if(index==1){
            $('.nav-li:eq(1)').trigger('click');
        }else{
            $('.nav-li:eq(2)').trigger('click');
        }
    }else{
         $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    }

}
function callfn(data){
     if(data.status=0){
        window.location.reload();
    }else if(data.status=0){
         $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    }
}
function deletemodal(){
    $('#content .modal').remove();
}

function getOb(type,page){
    return {
      //  is_owner:is_owner,
      //  owner_name:$('#user_name').val(),
        type:type,
        page:page,
        page_size:10
    }

}
function getNum(data){
    $('.nav-li').eq(0).find('.nav-num').text(data.data.total);
     $('.nav-li').eq(1).find('.nav-num').text(data.data.perm);
     $('.nav-li').eq(2).find('.nav-num').text(data.data.online);

    

}

var page=1;
var index;
status_type = '';
$(function(){
    //批量删除
        $('#selectall').on('change',function(){
            $('.f-check:gt(0)').each(function(){
               $(this).prop('checked',!$(this).prop('checked')); 
            });
        });
        $('#chooseDelete').on('click',function(){
           var arr=[];
             $('.f-check:gt(0):checked').each(function(){
                arr.push($(this).attr('mess_id'));
            });
             getAjaxData('post','/neptune/delete_message/',messageM,{'id[]':arr}); 
        });
    //批量标记为已读
        $('#haveRead').on('click',function(){
             var arr=[];
             $('.f-check:gt(0):checked').each(function(){
                arr.push($(this).attr('mess_id'));
            });
             getAjaxData('post','/neptune/read_message/',messageM,{'id[]':arr});
        });
    //
    index=0;
    //切换菜单
    getAjaxData('post','/neptune/list_message/',getData,{page:page,page_size:10});
    getAjaxData('post','/neptune/each_type_message_num/',getNum);
    $('.nav-li').on('click',function(){
        page = 1;
        $(this).siblings().find('.ft').css('color', '#868686');
        $(this).find('.ft').css('color', '#0099FF');
        $(this).siblings().find('.nav-icon').remove();
        $(this).prepend('<span class="nav-icon"></span>');
        index=$(this).index();
        if(index==0){
            status_type = '';
            $('.content-nav').find('li:eq(3)').remove();
             var tli=$('.content-nav').find('li:eq(2)');
            tli.find('a').addClass('h_text').removeClass('li_hover');
            tli.unbind('click');
            getAjaxData('post','/neptune/list_message/',getData,{page:page,page_size:10}); 
        }else if(index==1){
            status_type = 6;
            var text=$(this).find('.ft').text();
            $('.content-nav').find('li:eq(3)').remove();
            var tli=$('.content-nav').find('li:eq(2)');
            tli.find('a').addClass('li_hover').removeClass('h_text');
            tli.unbind('click');
            tli.on('click',function(){
                  $('.nav-li:eq(0)').trigger('click');
             });
            $('.content-nav').append('<li><a href="javascript:void(0)" class="h_text">&nbsp;&nbsp;&gt;&nbsp;&nbsp;'+text+'</a></li>');
             getAjaxData('post','/neptune/list_message/',getData,getOb(6,1)); 
         
    
        }else if(index==2){
              status_type = 7;
              var text=$(this).find('.ft').text();
              $('.content-nav').find('li:eq(3)').remove();
                var tli= $('.content-nav').find('li:eq(2)');
              tli.find('a').removeClass('h_text').addClass('li_hover');
              tli.unbind('click');
              tli.on('click',function(){
                 $('.nav-li:eq(0)').trigger('click');
              });

            $('.content-nav').append('<li><a href="javascript:void(0)" class="h_text">&nbsp;&nbsp;&gt;&nbsp;&nbsp;'+text+'</a></li>');
             getAjaxData('post','/neptune/list_message/',getData,getOb(7,1)); 

           
        }   
    }); 
});
function getData(data){
    $('#bar').remove();
    if(index==0){
         $('#div0 tbody tr').remove();
         $('#div0 .m-title').text('全部消息');
         $('#div0 p:eq(1)').remove();
         if(data.status==0){
             $('.navbar li:eq(0)').find('.nav-num').text(data.count);
             var data_list=data.data;
             if(data_list.length!=0){
                for(var i=0;i<data_list.length;i++){
                var type = data_list[i].type == 6 ? '权限消息' : (data_list[i].type == 7 ? "上线消息" : "未知类型");
                var str;
                if(data_list[i].read==false){
                    str="未读";
                }else{
                    str="已读";
                }
                var appendHtml='<tr style="height:50px;"><td style="width:5%;border:1px solid #e4e4e4"><input type="checkbox" class="f-check" mess_id="'+data_list[i].id+'"></td><td style="width:41%;border:1px solid #e4e4e4" class="m-hov">'+data_list[i].content+'</td><td style="width:12%;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:35px" class="">'+str+'</span></td><td style="width:12%;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:21px" class="">'+type+'</span></td><td style="width:19%;border:1px solid #e4e4e4">'+data_list[i].create_time+'</td><td style="width:28%;border:1px solid #e4e4e4"><a href="javascript:void(0)" class="back" style="color:#0099FF;margin-right:25px" onclick="goview(this)" content="'+data_list[i].content+'">查看</a><a href="javascript:void(0)" style="color:#0099FF" class="outline" onclick="deleteMessage(this)" mess_id="'+data_list[i].id+'">删除</a></td></tr>';
                $('#div0 tbody').append(appendHtml);
            }
                var pag=pagination(page,10,data.count,data.pagination.index_min,data.pagination.index_max);
                $('.bar-nav li').unbind('click');
                $('#div0').append(pag);
                $('.bar-nav li').on('click',function(){
                $(this).addClass('bg-li');
                $(this).siblings().removeClass('bg-li');
                page=$(this).attr('action-data');
                getAjaxData('post','/neptune/list_message/',getData,{page:page,page_size:10});
               }); 
            }else{
                  $('#div0 table').after('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">全部消息为空</p>');
            }
         }else{
             $('.navbar li:eq(0)').find('.nav-num').text(0);
             $('#div0 table').after('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');            
            }

    }else if(index==1){
         $('#div0 tbody tr').remove();
         $('#div0 .m-title').text('权限消息');
         $('#div0 p:eq(1)').remove();
         if(data.status==0){
             $('.navbar li:eq(1)').find('.nav-num').text(data.count);
             var data_list=data.data;
             if(data_list.length!=0){
                for(var i=0;i<data_list.length;i++){
                 var str;
                if(data_list[i].read==false){
                    str="未读";
                }else{
                    str="已读";
                }
                 var appendHtml='<tr style="height:50px;"><td style="width:5%;border:1px solid #e4e4e4"><input type="checkbox" class="f-check" mess_id="'+data_list[i].id+'"></td><td style="width:41%;border:1px solid #e4e4e4" class="m-hov">'+data_list[i].content+'</td><td style="width:12%;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:35px" class="">'+str+'</span></td><td style="width:12%;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:21px" class="">权限消息</span></td><td style="width:19%;border:1px solid #e4e4e4">'+data_list[i].create_time+'</td><td style="width:28%;border:1px solid #e4e4e4"><a href="javascript:void(0)" class="back" style="color:#0099FF;margin-right:25px" onclick="goview(this)" content="'+data_list[i].content+'">查看</a><a href="javascript:void(0)" style="color:#0099FF" class="outline" onclick="deleteMessage(this)" mess_id="'+data_list[i].id+'">删除</a></td></tr>';
                $('#div0 tbody').append(appendHtml);
                }
                var pag=pagination(page,10,data.count,data.pagination.index_min,data.pagination.index_max);
                $('.bar-nav li').unbind('click');
                $('#div0').append(pag);
                $('.bar-nav li').on('click',function(){
                $(this).addClass('bg-li');
                $(this).siblings().removeClass('bg-li');
                page=$(this).attr('action-data');
                getAjaxData('post','/neptune/list_message/',getData,getOb(6,page));
               });
          }else{
                  $('#div0 table').after('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">权限消息为空</p>');
            }
         }else{
             $('.navbar li:eq(1)').find('.nav-num').text(0);
             $('#div0 table').after('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');
            }         

    }else if(index==2){
             $('#div0 tbody tr').remove();
         $('#div0 .m-title').text('上线消息');
         $('#div0 p:eq(1)').remove();
         if(data.status==0){
             $('.navbar li:eq(2)').find('.nav-num').text(data.count);
             var data_list=data.data;  
                console.log(data_list.length);
             if(data_list.length!=0){
                 for(var i=0;i<data_list.length;i++){
                 var str;
                if(data_list[i].read==false){
                    str="未读";
                }else{
                    str="已读";
                }
                 var appendHtml='<tr style="height:50px;"><td style="width:5%;border:1px solid #e4e4e4"><input type="checkbox" class="f-check" mess_id="'+data_list[i].id+'"></td><td style="width:41%;border:1px solid #e4e4e4" class="m-hov">'+data_list[i].content+'</td><td style="width:12%;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:35px" class="">'+str+'</span></td><td style="width:12%;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:21px" class="">上线消息</span></td><td style="width:19%;border:1px solid #e4e4e4">'+data_list[i].create_time+'</td><td style="width:28%;border:1px solid #e4e4e4"><a href="javascript:void(0)" class="back" style="color:#0099FF;margin-right:25px" onclick="goview(this)" content="'+data_list[i].content+'">查看</a><a href="javascript:void(0)" style="color:#0099FF" class="outline" onclick="deleteMessage(this)" mess_id="'+data_list[i].id+'">删除</a></td></tr>';
                $('#div0 tbody').append(appendHtml);
                }
                var pag=pagination(page,10,data.count,data.pagination.index_min,data.pagination.index_max);
                $('.bar-nav li').unbind('click');
                $('#div0').append(pag);
                $('.bar-nav li').on('click',function(){
                $(this).addClass('bg-li');
                $(this).siblings().removeClass('bg-li');
                page=$(this).attr('action-data');
                getAjaxData('post','/neptune/list_message/',getData,getOb(7,page));
               });
          }else{
                  $('#div0 table').after('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">上线消息为空</p>');
            }
         }else{
             $('.navbar li:eq(2)').find('.nav-num').text(0);
             $('#div0 table').after('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');
            }        

    }
        $('#bar').css({
            'margin-top':'35px'
        });
        $('#bar .bar-nav').css({
            'margin-left': '14px'
        });
}
function removemodal(){

    $('#content .modal').remove();
}
function deletemodal(){
    $('#content .modal').remove();
}
function gopage(){
    var page=parseInt($('.searchpage').val());
    if(isNaN(page))
    {
        alert('请输入页号后点击翻页');
        return;
    }
    getAjaxData('post','/neptune/list_message/',getData,getOb(status_type,page));
}
