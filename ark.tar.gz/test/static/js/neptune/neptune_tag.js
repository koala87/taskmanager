var search_key = '';
function getAjaxData(ajaxgp,url,fn,obj){
        if(ajaxgp=="get"){
            if(typeof obj!="undefined"){
            var str="";
            for(var p in obj){
                str=str+p+"="+obj[p]+"&";
            }
            str=str.substr(0,str.length-1);
            url=url+"?"+str;
            }
            $.get(url,function(data){
                fn(data,1);
                
            },'json');
        }else if(ajaxgp=="post"){
                if(typeof obj=="undefined"){
                    $.post(url,function(data){
                        fn(data,1);
                    },'json');

                }else{
                $.post(url,obj,function(data){
                   
                    fn(data,obj.page);
                },'json');
               }

        }
    }

var index="";
$(function(){
/*   $('#navright li').on('click',function(){
      var toggleSelect=$('#toggle-select');
       if(toggleSelect.is(':visible')) {
           toggleSelect.fadeOut();
       }else{
           toggleSelect.show();
       }
   });*/

    //点击标签页
    $('#right-content').delegate('.tag_content','click',function(e){
        var e=e||window.event;
        var app_name=$(this).attr('app_name');
        var owner_name = $(this).find("span").eq(1).text();
        window.open("/neptune/tag_person/?tag_name="+app_name+"&owner_name="+owner_name);
    });
    //切换种类
    $('.nav-choose li').on('click',function(){
        index=$(this).attr('cid');
        search_key = '';
         $(".message").html('');
        $('.tag_content').remove();
        $('#bar').remove();
        $(this).siblings().find('span').remove();
        $(this).css({
            'color':'#0099FF'
        }).siblings().css({
            'color':'#666666'
        })
        if($(this).index()==0){
            $('<span class="nav-choose-bg"></span>').prependTo($(this));
        }else{
            $('<span class="nav-choose-other"></span>').prependTo($(this));
        }

        if($(this).text()!="全部分类"){
            $('.content-nav li:eq(3)').remove();
           $('.content-nav').append('<li>&nbsp;&nbsp;<a href="javascript:void(0)">>&nbsp;&nbsp;<span class="h_text">'+$(this).text()+'</span></a></li>');
              $('.content-nav li:eq(2)').find('a').find('span').addClass('li_hover').removeClass('h_text');
             $('.content-nav li:eq(2)').unbind('click');
              $('.content-nav li:eq(2)').on('click',function(){
                index=0;
                getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));

            });
        }else if($(this).text()=="全部分类"){
            $('.content-nav li:eq(3)').remove();
            $('.content-nav li:eq(2)').find('a').find('span').removeClass('li_hover').addClass('h_text');
            $('.content-nav li:eq(2)').unbind('click');
        }
      
        console.log($('#inputcid').val());
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
         $('.search-input').val('');
        $('#inputcid').val('4');
        $('.chooseul li').each(function(){
              $(this).css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
        });
            if($(this).index()==0){
            $(this).find('span:eq(0)').text('最早发布').css('color','#666666');
            }else if($(this).index()==1){
            $(this).find('span:eq(0)').text('最近更新').css('color','#666666');
            }else if($(this).index()==2){
            $(this).find('span:eq(0)').text('最多使用').css('color','#666666');
            }
        });
    });
    //排序js
    $('.chooseul li').on('click',function(){
        $(this).siblings().css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
       }).find('span:eq(0)').css('color','#666666');
        
        $(this).css({
            "background":'url("../../static/images/neptune/u314_selected.png") no-repeat'
        });
        if($(this).index()==0){
        $(this).find('.spanleft').css({
            'color':'#0099FF'
        });
        $('#inputcid').val('1');

       
        //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //
        $(this).find('span').eq(0).unbind('click');
        $(this).find('span').eq(1).unbind('click');
        $(this).find('span').eq(0).on('click',function(e){
            e.stopPropagation();
            
             $(this).parent().siblings().css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
       }).find('span:eq(0)').css('color','#666666');

        $(this).parent().css({
            "background":'url("../../static/images/neptune/u314_selected.png") no-repeat'
        });

            if($(this).text()=="最早发布"){
                $(this).text('最新发布');
                $('#inputcid').val('2');
                $(this).css('color','#0099FF');
            }else if($(this).text()=='最新发布'){
                $(this).text('最早发布');
                  $('#inputcid').val('1');
                $(this).css('color','#0099FF');
            }
            //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        });
        
         $(this).find('span').eq(1).on('click',function(e){
            e.stopPropagation();
               $(this).parent().siblings().css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
       }).find('span:eq(0)').css('color','#666666');

        $(this).parent().css({
            "background":'url("../../static/images/neptune/u314_selected.png") no-repeat'
        });
    
            if($(this).prev().text()=="最早发布"){
                $(this).prev().text('最新发布');
                  $('#inputcid').val('2');
                $(this).prev().css('color','#0099FF');

            }else if($(this).prev().text()=='最新发布'){
                $(this).prev().text('最早发布');
                  $('#inputcid').val('1');
                $(this).prev().css('color','#0099FF');

            }
            //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        });



        }else if($(this).index()==1){
        $(this).find('.spanleft').css({
            'color':'#0099FF'
        });
        $('#inputcid').val('3');
        //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        $(this).find('span').eq(0).unbind('click');
        $(this).find('span').eq(1).unbind('click');
        $(this).find('span').eq(0).on('click',function(e){
            e.stopPropagation();

               $(this).parent().siblings().css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
       }).find('span:eq(0)').css('color','#666666');

        $(this).parent().css({
            "background":'url("../../static/images/neptune/u314_selected.png") no-repeat'
        });

            if($(this).text()=="最近更新"){
                $(this).text('最早更新');
                  $('#inputcid').val('4');
                   $(this).css('color','#0099FF');
            }else if($(this).text()=='最早更新'){
                $(this).text('最近更新');
                  $('#inputcid').val('3');
                     $(this).css('color','#0099FF');
            }

            //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        });

         $(this).find('span').eq(1).on('click',function(e){
             e.stopPropagation();

               $(this).parent().siblings().css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
       }).find('span:eq(0)').css('color','#666666');

        $(this).parent().css({
            "background":'url("../../static/images/neptune/u314_selected.png") no-repeat'
        });


            if($(this).prev().text()=="最近更新"){
                $(this).prev().text('最早更新');
                 $('#inputcid').val('4');
                $(this).prev().css('color','#0099FF');
            }else if($(this).prev().text()=='最早更新'){
                $(this).prev().text('最近更新');
                 $('#inputcid').val('3');
                       $(this).prev().css('color','#0099FF');
            }
            //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        });


        }else if($(this).index()==2){
              $(this).find('.spanleft').css({
            'color':'#0099FF'
        });
        $('#inputcid').val('5');

        //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        $(this).find('span').eq(0).unbind('click');
        $(this).find('span').eq(1).unbind('click');
        $(this).find('span').eq(0).on('click',function(e){
            e.stopPropagation();
               $(this).parent().siblings().css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
       }).find('span:eq(0)').css('color','#666666');

        $(this).parent().css({
            "background":'url("../../static/images/neptune/u314_selected.png") no-repeat'
        });


            if($(this).text()=="最多使用"){
                $(this).text('最少使用');
                $(this).css('color','#0099FF');
                 $('#inputcid').val('6');

            }else if($(this).text()=='最少使用'){
                $(this).text('最多使用');
                    $(this).css('color','#0099FF');
                   $('#inputcid').val('5');
            }

            //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        });

         $(this).find('span').eq(1).on('click',function(e){
            e.stopPropagation();
               $(this).parent().siblings().css({
            "background":'url("../../static/images/neptune/u314.png") no-repeat'
       }).find('span:eq(0)').css('color','#666666');

        $(this).parent().css({
            "background":'url("../../static/images/neptune/u314_selected.png") no-repeat'
        });


            if($(this).prev().text()=="最多使用"){
                $(this).prev().text('最少使用');
                  $(this).prev().css('color','#0099FF');
                 $('#inputcid').val('6');

            }else if($(this).prev().text()=='最少使用'){
                $(this).prev().text('最多使用');
                  $(this).css('color','#0099FF');
                 $('#inputcid').val('5');
            }
            //search
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        //

        });
        }
    });


    //搜索
    $('.search-input').on('focus',function(){
       $(this).css({
          "border":"0px !important"
       });
    }).on('keydown',function(e){
        var e=e||window.event;
        var enter= e.keyCode|| e.which;
        if(enter==13){
              search_key = $(".search-input").val();
              getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
        }
    });
    $('.search-btn').on('click',function(){
        search_key = $(".search-input").val();
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
    });
    
   // getAjaxData('get','/neptune/tag_list/',getTagListpage(1),getTagList);
    getAjaxData('get','/neptune/tag_rank_num/',getTagUse);
    getAjaxData('get','/neptune/tag_rank_pub/',getTagNew);
    $('#inputcid').val('4');
    getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(1));
    function getTagUse(tag_use){
    if(tag_use.status==0){
        if(tag_use.rank_list.length==0){
            $('#tag-use tbody').append('<tr><th class="padsmall" style="width:50%">标签数目为空</th><th class="pad" style="width:20%"></th></tr>');
        }else{
            for(var i=0;i<tag_use.rank_list.length;i++){
                $('#tag-use tbody').append('<tr><th class="padsmall" style="width:53%"><a href="/neptune/tag_person/?owner_name='+tag_use.rank_list[i].user_name+'&tag_name='+tag_use.rank_list[i].app_name+'" style="color:#0099FF">'+tag_use.rank_list[i].app_name+'</a></th><th class="pad" style="width:32%;padding-left:5px">'+tag_use.rank_list[i].count+'</th></tr>');
            }
        }
    }else{
         $('#tag-use tbody').append('<tr><th class="padsmall" style="width:50%">'+tag_use.info+'</th><th class="pad" style="width:20%"></th></tr>');
    }
   }
    
    function getTagNew(tag_new){
    if(tag_new.status==0){
          if(tag_new.rank_list.length==0){
              $('#tag-new tbody').append('<tr><th class="padsmall" style="width:46%">标签数目为空</th><th class="pad" style="width:37%"></th></tr>');
          }else{
              for(var i=0;i<tag_new.rank_list.length;i++){
                  $('#tag-new tbody').append('<tr><th class="padsmall" style="width:39%"><a href="/neptune/tag_person/?owner_name='+tag_new.rank_list[i].user_name+'&tag_name='+tag_new.rank_list[i].app_name+'" style="color:#0099FF">'+tag_new.rank_list[i].app_name+'</a></th><th class="pad" style="width:37%;display:inline-block;text-align:center">'+tag_new.rank_list[i].user_name+'</th></tr>');
              }
          }   
      }else{  
           $('#tag-new tbody').append('<tr><th class="padsmall" style="width:46%">'+tag_new.info+'</th><th class="pad" style="width:37%"></th></tr>');
      }
}

   
});

/*function pagination(cur_page, page_size, record_total,index_min,index_max)
{
    var show_page_num = 5;
    var page_total = Math.ceil(record_total/page_size);
    if(cur_page < 1 || cur_page > page_total){return '';}
    var html = '<div id="bar">';
    html = html + '<span class="pagenum">共'+record_total+'条记录，正在浏览'+index_min+'-'+index_max+'条</span>';
    html = html + '<ul class="bar-nav">';
    if(cur_page>1)
    {
        html = html + '<li style="width:20px;cursor:pointer" class="firstpage pagenition_li" action-data="1"><<</li>';
        html = html + '<li style="width:40px;cursor:pointer" class="firstpage pagenition_li" action-data="'+(cur_page-1).toString()+'">上一页</li>';
    }
    if(cur_page>Math.ceil(show_page_num/2))
    {
        html = html + '<li>...</li>';
    } 
    var page_show_list = [];
    for(var i=-Math.floor(show_page_num/2); i<=Math.floor(show_page_num/2);i++)
    {
        page_show_list.push(cur_page+i);
    }
    for(var i=0,j=0; i<Math.floor(page_show_list.length/2);i++,j++)
    {
        if(page_show_list[i]<1){
            page_show_list.splice(0, 1);
            page_show_list.push(cur_page+Math.ceil(show_page_num/2)+j);
            i--;
        }
    }
    for(var i=0; i<page_show_list.length; i++)
    {
        if(page_show_list[i]>page_total){
            page_show_list.splice(i, 1);
            i--;
        }
    }
    while(page_show_list.length < show_page_num)
    {
        if((page_show_list[0]-1)>1)
        {
            page_show_list.unshift(page_show_list[0]-1);
        }
        else
        {
            break;
        }
    }
    for(var i=0; i<page_show_list.length; i++)
    {
        if(page_show_list[i] == cur_page)
        {
            html = html + '<li class="pagenition_li bg-li" action-data="'+page_show_list[i]+'">'+page_show_list[i]+'</li>';
        }
        else
        {
            html = html + '<li style="cursor:pointer;" action-data="'+page_show_list[i]+'">'+page_show_list[i]+'</li>';
        }
    }
    if(page_show_list[page_show_list.length-1] < page_total)
    {
        html = html + '<li>...</li>';
    }
    if(cur_page < page_total)
    {
        html = html + '<li style="width:40px; cursor:pointer;" class="pagenition_li" action-data="'+(cur_page+1).toString()+'">下一页</li>';
        html = html + '<li style="width:20px; cursor:pointer;" class="lastpage pagenition_li" action-data="'+page_total+'">>></li>';
    }
    html = html + '</ul>';
    html = html + '<p style="margin-top:20px;margin-left:15px" class="pull-left bar-p">共 '+page_total+' 页， 到第<input type="text" class="searchpage"/>页</p>';
    html = html + '<span style="display: inline-block;width: 53px;height: 30px;border-radius: 5px;color: black;line-height: 30px;border: 1px solid lightgray;;margin-top:19px;cursor:pointer" class="pull-left btnpage" onclick="gopage()">确定</span>';
    html = html + '</div>';
    return html;
}*/


function getTagListPage(page){
       
        var sort_type=parseInt($('#inputcid').val());
        
        var tag_name=$('.search-input').val();
        var category_type=index;
       /* $('.nav-choose li').each(function(){
            var jSpan=$(this).find('span');
            console.log(jSpan.attr('class'));
            if(jSpan){
                console.log($(this).attr('cid'));
                category_type=$(this).attr('cid');
            }

        });*/
        return {
             category_type: category_type,
             sort_type:sort_type,
             tag_name:tag_name,
             page:page,
             page_size:10
        }
    }



 function getTagList(tag_list,page){
        $('.tag_content').remove();
        $('#bar').remove();
        var data_list=tag_list.data_list;
       for(var i=0;i<data_list.length;i++){
            var str=data_list[i].update_cycle;
            var datetime=data_list[i].update_time;
            datetime = new Date(Date.parse(datetime.replace(/-/g, "/"))); 
            var date1=new Date();
            var distance=date1.getTime()-datetime.getTime();
            console.log(data_list[i].update_time);
            console.log(distance);
            var time;
            if((distance/1000)>=1&&(distance/1000)<60){
                time=Math.round((distance/1000))+"秒前";
            }else if(distance/(1000*60)>=1&&distance/(1000*60)<60){
                time=Math.round((distance/(1000*60)))+"分前";
            }else if(distance/(1000*60*60)>=1&&distance/(1000*60*60)<24){
                 time=Math.round((distance/(1000*60*60)))+"小时前";
            }else if(distance/(1000*60*60*24)>=1&&distance/(1000*60*60*24)<30){

                 time=Math.round(distance/(1000*60*60*24))+"天前";
            }else if(distance/(1000*60*60*24*30)>=1&&distance/(1000*60*60*24*30)<12){
                  time=Math.round((distance/(1000*60*60*24*30)))+"个月前";
            }else if(distance/(1000*60*60*24*30*12)>=1){
                time=Math.round((distance/(1000*60*60*24*30*12)))+"年前";
            }
            console.log(time);
            if(str===0){
                str="天级";
            }else{
                str="小时级";
            }
         $('#right-content').append('<div class="tag_content" app_name="'+data_list[i].app_name+'" cid="'+i+'"><p class="tag_title"><span>'+data_list[i].app_name+'</span></p><span class="common" style="position: absolute; left: 306px;top: 20px;">'+data_list[i].user_name+'</span><span class="common" style="position: absolute; left: 440px;top: 20px;">使用次数:'+data_list[i].use_count+'次</span><p class="commonp" style="position: absolute; left: 611px;top: 25px;"><span style="margin-left: -5px;">'+str+'</span></p><span class="common" style="margin-left:48px;float:right;display:inline-block;margin-top:19px">'+time+'</span></br></br><p class="desp">描述:'+data_list[i].description+'</p></div>');
        data_list[i].index=i;
         
         if($('.desp:last').width()>$('.tag_content:last').width()*0.92){
            console.log($('.desp:last').width());
            $('.desp:last').css({
                  'width':'89%', 
                  'overflow':'hidden',
                   'white-space':'nowrap',
                    'text-overflow':'ellipsis',
                    'display':'block'
            });
           $('.tag_content:last').append('<p class="toggle" style="cursor:pointer;position:absolute;bottom:8px;right:10px;width: 8%;font-weight: 400;font-style: normal;  font-size: 14px;color: #0099FF;text-align: right;line-height: 30px;" onclick="toggle(this)">查看更多</p>');
          /*  $('.toggle').on('click',function(){
                var cid=parseInt($(this).parent().attr('cid'));
                $(this).remove();
                $('.desp').css({
                  'width':'96%', 
                  'overflow':'hidden',
                   'word-wrap':'break-word',
                    'word-break':'normal'
                });*/
              /*  $('.tag_content:last').append('<p class="toggleup" style="position:absolute;bottom:1px;right:7px;width:8%;font-weight:400;font-style:normal;font-size: 14px;color: #0099FF;text-align: right;line-height: 30px;" onclick="toggleUp()">收起</p>');*/
           
        }

        $(".message").html('');
        if(search_key != '')
        {
            $(".message").html('根据关键词"'+search_key+'"共有'+data_list.length+'个搜索结果，根据最多使用人数进行排序');
        }
 }
   /* $('#right-content').append('<div id="bar"><span class="pagenum">共1000条记录，正在浏览1-6条</span><ul class="bar-nav"><li class="firstpage" cid="0"><img src="/static/images/neptune/u198.png" alt=""><a href="">上一页</a></li><li class="bg-li" cid="1"><a href="">1</a></li><li cid="2"><a href="">2</a></li><li cid="3"><a href="">3</a></li><li cid="4"><a href="">4</a></li><li cid="5"><a href="">5</a></li><li cid="6"><a href="">...</a></li><li cid="7" class="lastpage"><a href="">下一页</a><img src="/static/images/neptune/u200.png" alt=""></li></ul><p class="pull-left bar-p">共 100 页， 到第<input type="text" class="searchpage">页</p><span class="pull-left btnpage">确定</span></div>');
*/
    var pag=pagination(parseInt(page),10,tag_list.count,tag_list.index_min,tag_list.index_max);
    $('.bar-nav li').unbind('click');    
    $('#right-content').append(pag);
    $('.bar-nav li').on('click',function(){
        $(this).addClass('bg-li');
        $(this).siblings().removeClass('bg-li');
        var page=$(this).attr('action-data');
         getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(page));
    });
    }

function gopage(){
    var page=parseInt($('.searchpage').val());
    getAjaxData('post','/neptune/tag_list/',getTagList,getTagListPage(page));
}
function toggle(that){
              
               $(that).parent().find('.desp').css({
                  'width':'96%', 
                 /* 'overflow':'hidden',*/
                   'word-wrap':'break-word',
                    'word-break':'normal',
                    'white-space':''
                });
          /*  $(that).parent().append('<p class="toggleup" style="cursor:pointer;width:8%;font-weight:400;font-style:normal;font-size: 14px;color: #0099FF;text-align: right;line-height: 30px;" onclick="toggleUp(this)">收起</p>');*/
            $(that).parent().find('.desp').append('<span class="toggleup" style="cursor:pointer;width:8%;font-weight:400;font-style:normal;font-size: 14px;color: #0099FF;text-align: right;line-height: 30px;padding-left:31px" onclick="toggleUp(this)">收起</span>');
            $(that).remove();

}
function toggleUp(that){
    
                
               $(that).parent().parent().find('.desp').css({
                     'width':'89%',
                  'overflow':'hidden',
                   'white-space':'nowrap',
                    'text-overflow':'ellipsis',
                    'word-wrap':'',
                    'word-break':''
                });
                 $(that).parent().parent().append('<p class="toggle" style="cursor:pointer;position:absolute;right:10px;bottom:8px;width: 8%;font-weight: 400;font-style: normal;  font-size: 14px;color: #0099FF;text-align: right;line-height: 30px;" onclick="toggle(this)">查看更多</p>');

                $(that).remove();

     
}

