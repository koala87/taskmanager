var indexObject;
$(function(){
    $('.f-left input').on('focus',function(){
        $(this).css({
            'border':'2px solid #1bbc9c'
        });
    }).on('blur',function(){

        $(this).css({
            'border':'1px solid #BDC3C7'
        });
    });
    $('#basic_message').on('click',function(){
        indexObject=$(this);
        var ob={
            user_name:$('#user_name').val(),
            email:$('#email').val(),
            password:$('#password').val()
        }
        getAjaxData('post','',getData,ob);
    });
    $('#changePassword').on('click',function(){
         indexObject=$(this);
        var ob={
        oldpassword:$('#oldpassword').val(),
        newpassword:$('#newpassword').val(),
        againpassword:$('#againpassword').val()
        }
        getAjaxData('post','',getData,ob);

    });
    $('#acount_message').on('click',function(){
          indexObject=$(this);
        var ob={
        odps_dxp:$('#odps_dxp').val(),
        odps_id:$('#odps_id').val(),
        odps_key:$('#odps_key').val(),
        odps_biz_id:$('#odps_biz_id').val(),
        job_user:$('#job_user').val(),
        ali_group:$('#ali_group').val()
        }
        getAjaxData('post','',getData,ob);
    });    


});
function getData(data){
    if(data.status==0){
        indexObject.parent().append('<span class="f-icon"></span><span class="f-span" style="color:#0099FF;float:left;margin-left:15px;margin-top:30px;">修改成功</span>');
    }else{
        indexObject.parent().append('<span class="f-icon-w"></span><span class="f-span" style="color:#E94D3C;float:left;margin-left:15px;margin-top:30px;">错误</span>');
    }
}
