function removeRad(that){
    var htm=$(that).parent().attr('htm').toString();
    var $parent=$(that).parent();
    $(that).parent().find('span').remove();
    $(that).parent().find('input').remove();
    $(that).parent().find('button').remove();
    $parent.find('select').remove();
    console.log(htm);
    $parent.append(htm);   

}
function init_user_list()
{
    $('select.combobox').combobox();
    var suggest_input = $(".combobox-container input[type=text]");
    suggest_input.attr('placeholder',"输入标签关键字进行搜索");
    suggest_input.css('padding-left', '8px');
    suggest_input.css('width', '179px');
    suggest_input.css('height', '40px');
    suggest_input.css('border', '1px solid #0099FF');
    $(".dropdown-menu").css('position','absolute');
    $(".dropdown-menu").css('z-index','10000');
    $(".dropdown-menu").css('background-color','lightblue');
$('.select2-container .select2-choice').css('height', '146px'); 

}
function add_user_select_list(data)
{
    for(var i=0; i<data.data.length;i++)
    {
        $("#apply_group").append("<option>"+data.data[i]+"</option>");
    }
    init_user_list();
}
$(function(){
    getAjaxData('post', '/neptune/tag_get_except_users/', add_user_select_list);
    var tag_id=parseInt($('#tag_type').val());
    console.log(tag_id);
    if(tag_id==0){
        $('#type').append('<div class="person_tag"><button class="apply_btn">权限申请</button></div><span class="fontic">申请权限后才能查看和使用</span>');
     //  $('#data_tag').remove();
      //  $('#server').remove();
       // $('#app_req').remove();
       // $('.cr-w').remove();
    }else if(tag_id==1){
        $('#type').append('<div class="person_tag" style="background:url(\'../../static/images/neptune/search-input-auto_u33.png\') no-repeat"><span style="padding-left:16px;color:#a1a1a1">权限申请中</span></div><span class="fontic">权限申请中，请等待发布方审核权限</span>');
         $('#data_tag').remove();
        $('#server').remove();
        $('#app_req').remove();
        $('.cr-w').remove();
    }else if(tag_id==2){
        $('#type').append('<div class="person_tag"><span style="padding-left:29px">已订阅</span></div><span class="fontic" style="color:#0099FF;cursor:pointer" id="deleteView">取消订阅</span><span class="fontic">已订阅的信息可查看数据配置详情</span>');
          $('#server').remove();
        $('#app_req').remove();

    }else if(tag_id==3){
        $('#type').append('<div class="person_tag"><span style="padding-left:22px">个人数据</span></div><span class="fontic">这是自己已经发布的标签数据，可以查看详情并进行修改</span>');
        $('#app_pro').remove();
    }
    
    

});
var glob;

var writeObject;

var cindex;
$(function(){
    //
        $('.apply_btn').on('click',function(){
             var ob={
        tag_name:$('#tag_app').val(),
        owner_name:$('#tag_user').val(),
        user_name:$('#header .sr-user').text(),
        op:3
        }
        getAjaxData('post','/neptune/tag_auth/',ApplyResult,ob);
        });

    //

    
    //展开收起块
    var divHeight;
    $('.toggled').attr('toggle','0');
    $('.toggled').on('click',function(){
        
        if(parseInt($(this).attr('toggle'))==0){
        $(this).attr('toggle','1');
        divHeight=$(this).parent().height();

        $(this).attr('getheight',$(this).parent().height());
        $(this).parent().css({
            'height':'70px',
            'overflow':'hidden'
        });
        
        $(this).next().remove(); 
        $(this).html('展开<img src="../../static/images/neptune/toggle_u74.png" width="22" height="22" style="position:absolute;top:20px;transform:rotate(180deg)">');
     }else if(parseInt($(this).attr('toggle'))==1){
         $(this).attr('toggle','0');
        $(this).parent().css({
            'height':$(this).attr('getheight')+'px',
            'overflow':''
        });
        $(this).html('收起<img src="../../static/images/neptune/toggle_u74.png" width="22" height="22" style="position:absolute;top:20px;">');
         $('<span class="line" style="width:1133px;margin-top:15px"></span>').insertAfter($(this));
     }
    });
    //取消订阅
    $('#deleteView').on('click',function(){
        $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">取消订阅确认</span><span class="deletemodal" style="float:right"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定要取消该订阅内容？</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="removeContent()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
    });

    //更改基本信息
        $('.cr-left').delegate('.cr-w','click',function(){
            var index=parseInt($(this).attr('index'));
            var $parent=$(this).parent();
            glob=$parent;
            if(index==0){
                $parent.attr('htm',$parent.html());
                 $(this).parent().find('img').remove();
                 $parent.find('span:eq(1)').remove();
               /* $parent.append('<div style="width:18px;height:18px;border-radius:50%;margin-left:20px;display:inline-block;float:left;margin-top:4px"><input class="bg-rad" type="radio" style="" name="time" checked></div><span class="ra-span" style="float:left">天级</span><div style="width:18px;height:18px;border-radius:50%;margin-left:10px;display:inline-block;float:left;margin-top:4px"><input class="bg-rad" type="radio" name="time"></div><span class="ra-span" style="float:left">小时级</span><button class="save_btn">保存</button><button class="remove_btn">取消</button>');
            */
                $parent.append('<input class="bg-rad" type="radio" value="0" style="float:left" name="time" checked=""><span class="ra-span" style="float:left">天级</span><input class="bg-rad" type="radio" value="1" name="time" style="float:left"><span class="ra-span" style="float:left">小时级</span><button class="save_btn" index="0">保存</button><button class="remove_btn" onclick="removeRad(this)">取消</button>');      
            }else if(index==1){
                 $parent.attr('htm',$parent.html());
                 $(this).parent().find('img').remove();
             $parent.append('<select class="ra-basic"><option value="1">人群自然属性</option><option value="2">搜索兴趣偏好</option><option value="3">购物人群偏好</option><option value="4">阅读兴趣偏好</option><option value="5">LBS兴趣偏好</option><option value="7">视频兴趣偏好</option></select><button class="save_btn" style="margin-top:-5px" index="1">保存</button><button class="remove_btn" style="margin-top:-5px" onclick="removeRad(this)">取消</button>');
            }else if(index==2){
                  $parent.attr('htm',$parent.html());

                       $(this).parent().find('img').remove();
                var update_cycle = $("#id_span_update_cycle").text().trim();
                var append_html = "";
                var crontab_conf = $("#id_span_crontab_conf").prev().attr('action-data');
                var hour_val = crontab_conf.split(" ")[1];
                var minute_val = crontab_conf.split(" ")[0];
                if(update_cycle == "小时级")
                {
                    append_html = '<input type="text" class="ra-basic" value="'+minute_val+'" id="id_minute_conf" style="width:50px;"/><span style="float:left;margin-left:5px;">分</span>';
                }
                else
                {
                    append_html = '<input type="text" class="ra-basic" value="'+hour_val+'" id="id_hour_conf" style="width:50px;"/><span style="float:left;margin-left:5px;">时</span><input type="text" class="ra-basic" value="'+minute_val+'" id="id_minute_conf" style="width:50px;"/><span style="float:left;margin-left:5px;">分</span>';
                }
               append_html += '<button class="save_btn" style="margin-top:-5px" index="2">保存</button><button class="remove_btn" style="margin-top:-5px" onclick="removeRad(this)">取消</button>';
               $parent.find('span:gt(0)').remove();
               $parent.append(append_html);


           }else if(index==3){
                 $parent.attr('htm',$parent.html());
                 $(this).parent().find('img').remove();
                 $parent.find('span:gt(0)').remove();          
               $parent.append('<select class="ra-basic" style="width:120px"><option value="300">5分钟</option><option value="600">10分钟</option><option value="1800">30分钟</option><option value="3600">1小时</option><option value="10800">3小时</option></select><button class="save_btn" style="margin-top:-5px" index="3">保存</button><button class="remove_btn" style="margin-top:-5px" onclick="removeRad(this)">取消</button>');
            }
               $('.save_btn').on('click',function(){
                                   
                  writeObject=this;//ajax successful after 
     $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">修改确认</span><span class="deletemodal" style="float:right" onclick="removemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定对修改内容进行保存吗？</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="deleteView('+index+')">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
        });
               $('.remove_btn').on('click',function(){

                $('#content .modal').remove();
            });
        
        });
    //解除用户权限显示
       $('.list-app').delegate('.block','mouseenter',function(){
                
            
                if(!$(this).parent().find('.callmodal').is(':visible')){
                     $(this).parent().append('<div class="tip"><p>解除用户权限</p><span class="icon_tip"></span></div>');
                }
            });
        $('.list-app').delegate('.block','mouseleave',function(){
            $(this).parent().find('.tip').remove();
            
        });
       
        

         $('.list-app').delegate('.block','click',function(){
            if($(this).parent().find('.callmodal').is(':visible')){
                  $(this).parent().find('.tip').remove();
                   $(this).parent().find('.callmodal').remove();
            }else{
            $(this).parent().find('.tip').remove();
            $(this).parent().siblings().find('.callmodal').remove();
            var $par=$(this).parent();
            $(this).parent().append('<div class="callmodal"><p>确认解除用户权限？</p><button class="call_btn re_bg" style="margin-left:34px" onclick="delete_call(this)" key="0">确认解除</button><button onclick="delete_call(this)" key="1" class="call_btn bl_bg" style="margin-left:33px">取消</button><span class="iconspan"><span></span></span</div>');
                 $('#server').on('click',function(e){
                        if(e.target.id=="server"){
                            
                            $par.find('.callmodal').remove();
                        }
                    }); 
            }
        });


        //权限请求管理
          $('.cr-req').delegate('.cr-req-block','click',function(){
                 if($(this).parent().find('.callmodal').is(':visible')){
                    $(this).parent().find('.callmodal').remove();
                }else{
                $par=$(this).parent();
                $(this).parent().siblings().find('.callmodal').remove();
                $(this).parent().append('<div class="callmodal"><p>确认通过用户权限申请？</p><button class="call_btn bl_bg" style="margin-left:34px" onclick="applycall(this)" key="0">确认通过</button><button class="call_btn re_bg" style="margin-left:33px" onclick="applycall(this)" key="1">拒绝申请</button><span class="iconspan"><span></span></span></div>');
                    $('#app_req').on('click',function(e){
                        if(e.target.id=="app_req"){
                      
                            $par.find('.callmodal').remove();     
                        }
                    });
                }
            });
          //添加
            $('.addblock').on('click',function(){
                var input_value=$(".combobox-container input[type=text]").val();
               
                if(input_value!=""){
                      var ob={
                    tag_name:$('#tag_app').val(),
                    owner_name:$('#tag_user').val(),
                     user_name:input_value,
                       op:0
                 }
                  getAjaxData('post','/neptune/tag_auth/',getFlash,ob);
                }
            });
        //折线图
        getAjaxData('post','/neptune/tag_statistic/',getDataLine,{time_distance:'1',tag_name:$('#tag_app').val()});
       $('.line_span').on('click',function(){
            $(this).addClass('line_b').removeClass('line_g').siblings().addClass('line_g').removeClass('line_b');
            var day=$(this).attr('day');
            getAjaxData('post','/neptune/tag_statistic/',getDataLine,{time_distance:day,tag_name:$('#tag_app').val()});
        }); 


});
function delete_call(that){
    var key=parseInt($(that).attr('key'));
    if(key==0){
        var ob={
        tag_name:$('#tag_app').val(),
        owner_name:$('#tag_user').val(),
        user_name:$(that).parent().parent().find('.cr-bor').find('span').text(),
        op:4
        }
        console.log(ob);
         $(that).parent().remove();
        getAjaxData('post','/neptune/tag_auth/',getFlash,ob);
          
    }else if(key==1){
        $(that).parent().remove();
    }

}
function applycall(that){
     var key=parseInt($(that).attr('key'));
    if(key==0){
        var ob={
        tag_name:$('#tag_app').val(),
        owner_name:$('#tag_user').val(),
        user_name:$(that).parent().parent().find('.cr-req-bor').find('span').text(),
        op:1
        }
         $(that).parent().remove();
        getAjaxData('post','/neptune/tag_auth/',getFlash,ob);

    }else if(key==1){
         var ob={
        tag_name:$('#tag_app').val(),
        owner_name:$('#tag_user').val(),
        user_name:$(that).parent().parent().find('.cr-req-bor').find('span').text(),
        op:2
        }
         $(that).parent().remove();
        getAjaxData('post','/neptune/tag_auth/',getFlash,ob);

    }

}
function getFlash(data){
    $('.nonep').remove();
   if(data.status==0){
       getAjaxData('post','/neptune/tag_get_authorited_users/',AgainOwner,{ tag_name:$('#tag_app').val(),
    owner_name:$('#tag_user').val(),
}); 
       getAjaxData('post','/neptune/tag_get_all_applied_users/',AgainApply,{
         tag_name:$('#tag_app').val(),
        owner_name:$('#tag_user').val(),
    });
    }else{
          $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="removemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal .correct').css('top', '60%');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    } 
}
function ApplyResult(data){
    console.log(data.status);
    if(data.status==0){
       window.location.reload();
    }else{
         $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="removemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    }
}
function AgainOwner(data){
    $('#server .list-app').remove();
    //reflash应用方管理  
    if(data.status==0){
        
        var owner_list=data.data;
        if(owner_list.length!=0){
        for(var i=0;i<owner_list.length;i++){
            var appendHtml='<div class="list-app"><div class="cr-bor"><span>'+owner_list[i]+'</span></div><span class="block"></span></div>';
        $('#id_seperator').before(appendHtml);
        }  
        $('.list-app').delegate('.block','click',function(){
            if($(this).parent().find('.callmodal').is(':visible')){
                  $(this).parent().find('.tip').remove();
                   $(this).parent().find('.callmodal').remove();
            }else{
            $(this).parent().find('.tip').remove();
            $(this).parent().siblings().find('.callmodal').remove();
            var $par=$(this).parent();
            $(this).parent().append('<div class="callmodal"><p>确认解除用户权限？</p><button class="call_btn re_bg" style="margin-left:34px" onclick="delete_call(this)" key="0">确认解除</button><button onclick="delete_call(this)" key="1" class="call_btn bl_bg" style="margin-left:33px">取消</button><span class="iconspan"><span></span></span</div>');
                 $('#server').on('click',function(e){
                        if(e.target.id=="server"){
                            
                            $par.find('.callmodal').remove();
                        }
                    }); 
            }
        });
        }else{
            $('#id_seperator').before('<p class="nonep"style="margin-top: 10px;margin-left: 23px;font-size: 15px;color: #999999;clear:both;">已经取得这个数据标签的应用方个数为0</p>');
        }  
    }else{
          $('#id_seperator').before('<p class="nonep"style="margin-top: 10px;margin-left: 23px;font-size: 15px;color: #999999;clear:both;">'+data.info+'</p>');

    }
    
}
function AgainApply(data){
    $('#app_req .cr-req').remove();
    //reflash权限请求管理
      if(data.status==0){

        var apply_list=data.data;
        if(apply_list.length!=0){
        for(var i=0;i<apply_list.length;i++){
            var appendHtml='<div class="cr-req"><div class="cr-req-bor"><span>'+apply_list[i]+'</span></div><span class="cr-req-block"><span>处理</span></span></div>';
        $('#app_req').append(appendHtml);
        }
        }else{          
          $('#app_req').append('<p class="nonep"style="margin-top: 10px;margin-left: 23px;font-size: 15px;color: #999999;clear:both;">申请这个数据标签的应用方个数为0</p>');
        }
    }else{         
     $('#app_req').append('<p class="nonep"style="margin-top: 10px;margin-left: 23px;font-size: 15px;color: #999999;clear:both;">'+data.info+'</p>');

    }

    
}
//折线图回调
function getDataLine(data){
    $('#container').empty();
    var xA=[];
    var yA=[];
    var statistic=data.statistic_list;
    for(var i=0;i<statistic.length;i++){
        xA.push(statistic[i].date_time);
        yA.push(statistic[i].uv);
    }
    $('#container').highcharts({
        chart: {
            zoomType: 'xy'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
        xAxis: [{
            categories: xA
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value}',
                style: {
                    color: '#BDC3C7'
                }
            },
            title: {
                text: 'uv',
                style: {
                    color: '#BDC3C7'
                }
            }
        }, /*{ // Secondary yAxis
            title: {
                text: 'Rainfall',
                style: {
                    color: '#BDC3C7'
                }
            },
            labels: {
                format: '{value} mm',
                style: {
                    color: '#BDC3C7'
                }
            },*/
         
        ],
        tooltip: {
            shared: true
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            x: 120,
            verticalAlign: 'top',
            y: 100,
            floating: true,
            backgroundColor: '#FFFFFF'
        },
        series: [/*{
            name: 'Rainfall',
            color: '#0099FF',
            type: 'column',
            yAxis: 1,
            data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4],
            tooltip: {
                valueSuffix: ' mm'
            }

        },*/ {
            name: 'uv',
            color: '#0099FF',
            type: 'line',
            data:yA, 
            marker: {
                lineWidth: 2,
                lineColor: "#0099FF",
                fillColor: 'white'
            },
            tooltip: {
                valueSuffix: ''
            }
        }]
    });

}
    


function deleteView(index){//modal 确定
    if(index==0){
        var time=parseInt($('.bg-rad:checked').val());
        var ob={
        tag_id:$('#tag_id').val(),
        update_key:'update_cycle',
        update_val:time
        }
    getAjaxData('post','/neptune/tag_update/',getDeleteViewMessage,ob);
    }else if(index==1){//后台字段不清楚
        var value=glob.find('.ra-basic').find('option:selected').val();
         var ob={
        tag_id:$('#tag_id').val(),
        update_key:'category_type',
        update_val:value 
        }
    getAjaxData('post','/neptune/tag_update/',getDeleteViewMessage,ob);
    }else if(index==2){
        var value="";
        var value_display="";
        var val_hour = $("#id_hour_conf").val();
        if(val_hour == undefined)
        {
            value = $("#id_minute_conf").val()+" * * * *";
            value_display = "每小时"+$("#id_minute_conf").val()+"分";
        }
        else
        {
            value = $("#id_minute_conf").val()+" "+val_hour+" * * *";
            value_display = "每天"+val_hour+"时"+$("#id_minute_conf").val()+"分";
        }
        crontab_conf_global = value;
        crontab_conf_global_display  = value_display;
         var ob={
        tag_id:$('#tag_id').val(),
        update_key:'crontab_conf',
        update_val:value
        }
    getAjaxData('post','/neptune/tag_update/',getDeleteViewMessage,ob);
    }else if(index==3){
         var value=glob.find('.ra-basic').find('option:selected').val();
         var ob={
        tag_id:$('#tag_id').val(),
        update_key:'overtime',
        update_val:value
        }
        getAjaxData('post','/neptune/tag_update/',getDeleteViewMessage,ob);
    }
}
function getDeleteViewMessage(data){
    $('#content .modal').remove();
    if(data.status==0){
        var keyindex=$(writeObject).attr('index');
        var keyvalue; 
        if(keyindex==0){
            keyvalue=$('.bg-rad:checked').next().text();
        }else if(keyindex==1){
            keyvalue=$(writeObject).parent().find('.ra-basic option:selected').text();
        }else if(keyindex==2){
            keyvalue=crontab_conf_global_display;
        }else if(keyindex==3){
            keyvalue=$(writeObject).parent().find('.ra-basic option:selected').text();
        }
        var $parentObject=$(writeObject).parent();
        removeRad(writeObject);
        if(keyindex==2){
            $("#id_span_crontab_conf").prev().attr('action-data', crontab_conf_global);
        }
        console.log(keyvalue);
           $parentObject.find('span').eq(1).text(keyvalue);

           
    }else if(data.status==1){
           $('#content .modal').remove();
          $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="removemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);

    }
}
function removemodal(){//modal取消
    $('#content .modal').remove();
}
function removeContent(){
        var ob={
         tag_name:$('#tag_app').val(),
        owner_name:$('#tag_user').val(),
        user_name:$('#header .sr-user').text(),
        op:4
        }
        getAjaxData('post','/neptune/tag_auth/',ApplyResult,ob); 
}

function viewSchema(url)
{
//        $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">schema文件查看</span><span class="deletemodal" style="float:right"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><iframe frameborder="0" scrolling="yes" width="100%" height="527px" src='+url+'></iframe></div></div>');
          $('#content').append('<div class="modal"><div class="correct" style="width:680px;height:500px;margin-left:-305px;"><span class="cr-mess" style="margin-bottom:10px;float:left">schema文件查看</span><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="removemodal()"></span><span class="line" style="width:616px;margin-top:15px;clear:both"></span><iframe frameborder="0" scrolling="yes" width="100%" height="420px" src='+url+'></iframe></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
}
