var index;
var page=1;
var historypage=1;
function getOb(status,page){
    return {
        status:status,
        page:page,
        page_size:10
    }

}
function gethistory(page){
    return {
        page:page,
        page_size:10,
        owner_name:$('.sr-user').text()
    }
}
status_type = 4; //4 全部 2 处理中 1 发布失败 0 未发布
$(function(){
        
        //
      index=0;
        //
      $('.tag_s').on('click',function(){
        window.location.href="/neptune/tag_senddata/";
      });
      getAjaxData('post','/neptune/list_center/',getData,getOb(4,1));
      $('.nav-li').on('click',function(){
        page = 1;
        $(this).siblings().find('.ft').css('color', '#868686');
        $(this).find('.ft').css('color', '#0099FF');
        $(this).siblings().find('.nav-icon').remove();
        $(this).prepend('<span class="nav-icon"></span>');
        index=$(this).index();
        if(index==0){
            status_type = 4;
            getAjaxData('post','/neptune/list_center/',getData,getOb(4,1));
              $('.content-nav').find('li:eq(3)').remove();
             var tli=$('.content-nav').find('li:eq(2)');
            tli.find('a').addClass('h_text').removeClass('li_hover');
            tli.unbind('click');

        }else if(index==1){
            status_type = 2;
            getAjaxData('post','/neptune/list_center/',getData,getOb(2,1));
            $('.content-nav').find('li:eq(3)').remove();
            var tli=$('.content-nav').find('li:eq(2)');
            tli.find('a').addClass('li_hover').removeClass('h_text');
            tli.unbind('click');
            tli.on('click',function(){
                 $('.navbar li:eq(0)').trigger('click');
             });
            $('.content-nav').append('<li><a href="javascript:void(0)" class="h_text">&nbsp;&nbsp;&gt;&nbsp;&nbsp;处理中</a></li>');


        }else if(index==2){
            status_type = 1;
            getAjaxData('post','/neptune/list_center/',getData,getOb(1,1));

            $('.content-nav').find('li:eq(3)').remove();
            var tli=$('.content-nav').find('li:eq(2)');
            tli.find('a').addClass('li_hover').removeClass('h_text');
            tli.unbind('click');
            tli.on('click',function(){
                $('.navbar li:eq(0)').trigger('click');
             });
            $('.content-nav').append('<li><a href="javascript:void(0)" class="h_text">&nbsp;&nbsp;&gt;&nbsp;&nbsp;发布失败</a></li>');

        }else if(index==3){
            status_type = 0;
            getAjaxData('post','/neptune/list_center/',getData,getOb(0,1));
            
              var text=$(this).find('.ft').text();
            $('.content-nav').find('li:eq(3)').remove();
            var tli=$('.content-nav').find('li:eq(2)');
            tli.find('a').addClass('li_hover').removeClass('h_text');
            tli.unbind('click');
            tli.on('click',function(){
                  $('.navbar li:eq(0)').trigger('click');
             });
            $('.content-nav').append('<li><a href="javascript:void(0)" class="h_text">&nbsp;&nbsp;&gt;&nbsp;&nbsp;未发布</a></li>');
        }
    });
    //发布历史
    $('#sendhistory').on('click',function(){
       $('#content').append('<div class="modal"><div class="togglemodal" style="border-radius:4px;width:740px;height:775px;margin-left:-370px;top:100px"><span class="cr-mess" style="margin-bottom:10px;float:left">发布历史</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:697px;margin-top:15px;clear:both"></span><p class="m-title">发布历史列表</p><table class="m-tab" border="0" cellspacing="0" cellpadding="0" style="margin-left:26px"><thead><tr style="height:50px;background:#f3f6f9"><th style="width:50px">No.</th><th style="width:320px">数据名</th><th style="width:135px">版本</th><th style="width:175px">发布时间</th></tr></thead><tbody></tbody></table></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
     getAjaxData('post','/neptune/list_pub_history/',getHistoryPub,gethistory(1));

   /* $('#content .togglemodal').append('<div id="bar" style="width:100%"><span class="pagenum" style="margin-left:0px">共1000条记录，正在浏览1-6条</span><ul class="bar-nav" style="margin-left:60px"><li class="firstpage" cid="0"><img src="/static/images/neptune/u198.png" alt=""><a href="">上一页</a></li><li class="bg-li" cid="1"><a href="">1</a></li><li cid="2"><a href="">2</a></li><li cid="3"><a href="">3</a></li><li cid="4"><a href="">4</a></li><li cid="5"><a href="">5</a></li><li cid="6"><a href="">...</a></li> <li cid="7" class="lastpage"><a href="">下一页</a><img src="/static/images/neptune/u200.png" alt=""></li></ul><p class="pull-left bar-p">共 100 页， 到第<input type="text" class="searchpage">页</p><span class="pull-left btnpage">确定</span></div>');
*/
    });
});
function getHistoryPub(data){
    $('.togglemodal tbody tr').remove();
    $('.togglemodal p:eq(1)').remove();
    if(data.status==0){
        var history_list=data.history_list;
        if(history_list.length!=0){
            for(var i=0;i<history_list.length;i++){
            var appendHtml='<tr style="height:50px;"><td style="width:50px;border:1px solid #e4e4e4">'+history_list[i].no+'</td><td style="width:320px;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:16px" class="m-hov">'+history_list[i].app_name+'</span></td><td style="width:135px;border:1px solid #e4e4e4">'+history_list[i].version+'</td><td style="width:175px;border:1px solid #e4e4e4;">'+history_list[i].create_time+'</td></tr>';
            $('.togglemodal tbody').append(appendHtml);
            }
           var pag=pagination(page,10,data.count,data.index_min,data.index_max,"go_history_page");
            $('.bar-nav li').unbind('click');
         $('#div0').append(pag);
          $('.bar-nav li').on('click',function(){
          $(this).addClass('bg-li');
         $(this).siblings().removeClass('bg-li');
        historypage=$(this).attr('action-data');
         getAjaxData('post','/neptune/list_pub_history/',getHistoryPub,gethistory(historypage));
        }); 
       }else{
           $('.togglemodal').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">发布历史为空</p>');
        }
    }else{
          $('.togglemodal').append('<p style="padding-left:13px;font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');
    }
}
function getData(data){//回掉函数append
        $('#div0 tbody tr').remove();
        $('#div0 p:eq(1)').remove();
        $("#bar").remove();
        if(data.status==0){
        $('.navbar li').eq(index).find('.nav-num').text(data.count);
        var data_list=data.data_list;
        if(data_list.length!=0){
        for(var i=0;i<data_list.length;i++){
            var appendHtml='<tr style="height:50px;"><td style="width:71px;border:1px solid #e4e4e4">'+data_list[i].no+'</td><td style="width:448px;text-align:left;border:1px solid #e4e4e4"><span style="margin-left:16px" class="m-hov">'+data_list[i].app_name+'</span></td>';
            if(data_list[i].status==0){
                appendHtml+='<td style="width:200px;border:1px solid #e4e4e4">未发布</td> <td style="width:249px;border:1px solid #e4e4e4;"><a href="javascript:void(0)" class="back" style="color:#0099FF;" onclick="publicate(this)">发布</a><a href="/neptune/tag_senddata_update/?tag_name='+data_list[i].app_name+'" style="color:#0099FF;margin:0 20px" class="outline" onclick="outline(this)">编辑</a><a style="color:#0099FF" href="javascript:void(0)" onclick="del_center(this)">删除</a></td></tr>';
            }else if(data_list[i].status==1){
                appendHtml+='<td style="width:200px;border:1px solid #e4e4e4">发布失败</td> <td style="width:249px;border:1px solid #e4e4e4;"><a href="javascript:void(0)" class="back" style="color:#0099FF;" onclick="publicate(this)">发布</a><a href="/neptune/tag_senddata_update/?tag_name='+data_list[i].app_name+'" style="color:#0099FF;margin:0 20px" class="outline" onclick="outline(this)">编辑</a><a style="color:#0099FF" href="javascript:void(0)" onclick="del_center(this)">删除</a></td></tr>';
                 //appendHtml+='<td style="width:200px;border:1px solid #e4e4e4">发布失败</td> <td style="width:249px;border:1px solid #e4e4e4;"><a href="javascript:void(0)" class="back" style="color:#0099FF;" onclick="publicate(this)">发布</a><a href="javascript:void(0)" style="color:#0099FF;margin:0 20px" class="outline" onclick="outline(this)">编辑</a><a style="color:#0099FF" href="javascript:void(0)">删除</a></td></tr>';
            }else if(data_list[i].status==2){
                 appendHtml+='<td style="width:200px;border:1px solid #e4e4e4">处理中</td> <td style="width:249px;border:1px solid #e4e4e4;"><a href="javascript:void(0)" class="back" style="color:#868686;cursor:text;">发布</a><a href="javascript:void(0)" style="color:#868686;margin:0 20px; cursor:text;" class="outline">编辑</a><a style="color:#868686;cursor:text;" href="javascript:void(0)">删除</a></td></tr>';
            }else if(data_list[i].status==3){
                appendHtml+='<td style="width:200px;border:1px solid #e4e4e4">发布成功</td> <td style="width:249px;border:1px solid #e4e4e4;"><a href="javascript:void(0)" class="back" style="color:#868686;cursor:text;">发布</a><a href="javascript:void(0)" style="color:#868686;margin:0 20px; cursor:text;" class="outline">编辑</a><a style="color:#868686;cursor:text;" href="javascript:void(0)">删除</a></td></tr>';
                 //appendHtml+='<td style="width:200px;border:1px solid #e4e4e4">发布成功</td> <td style="width:249px;border:1px solid #e4e4e4;"><a href="javascript:void(0)" class="back" style="color:#868686;cursor:text">发布</a><a href="javascript:void(0)" style="color:#0099FF;margin:0 20px" class="outline" onclick="outline(this)">编辑</a><a style="color:#0099FF" href="javascript:void(0)">删除</a></td></tr>';
            }

            $('#div0 tbody').append(appendHtml);
          }
       var pag=pagination(page,10,data.count,data.index_min,data.index_max);
        $('.bar-nav li').unbind('click');
    $('#div0').append(pag);
    $(".bar-nav li[style*='cursor:pointer;']").on('click',function(){
        $(this).addClass('bg-li');
        $(this).siblings().removeClass('bg-li');
        page=$(this).attr('action-data');
        getAjaxData('post','/neptune/list_center/',getData,getOb(status_type,page));
    });
    }else{
        
        $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">我的发布列表为空</p>');
    }
    }else{
          $('.navbar li').eq(index).find('.nav-num').text(0);
        $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');
    }
    
}
function gopage(){
    var page=parseInt($('.searchpage').val());
    if(isNaN(page))
    {
        alert('请输入页号后点击翻页');
        return;
    }
    getAjaxData('post','/neptune/list_center/',getData,getOb(status_type,page));
}
function go_history_page(){
    var page=parseInt($('.searchpage').val());
    getAjaxData('post','/neptune/list_pub_history/',getHistoryPub,gethistory(historypage));
}
function publicate(that){
    var that=$(that);
    tag_name = that.parent().prev().prev().text();

    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">操作确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定要执行发布吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="do_publicate()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
}

function do_publicate()
{
    getAjaxData('post','/neptune/tag_publicate_apply/',callfn,{tag_name:tag_name});    
}
function del_center(that){
    var that=$(that);
    tag_name = that.parent().prev().prev().text();

    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">操作确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定要删除此条记录吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="do_del_center()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
}

function do_del_center()
{
    getAjaxData('post','/neptune/delete_user_tag/',callfn,{tag_name:tag_name});    
}
function callfn(data){
    deletemodal();
    if(data.status==0){
        window.location.reload();
    }else{
         $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="removemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    }
}
function removemodal(){

    $('#content .modal').remove();
}
function deletemodal(){
    $('#content .modal').remove();
}
