var index=0;
var page=1;

var boutline=0;
var app_name;
status_type = 2;
function getOb(page,is_owner){

    return {
        is_owner:is_owner,
        owner_name:$('#user_name').val(),
        page:page,
        page_size:10
    }

}
$(function(){
    index=0;
    //切换菜单
    getAjaxData('post','/neptune/list_mydata/',getData,getOb(1,3));
    $('.nav-li').on('click',function(){
        page = 1;
        $(this).siblings().find('.ft').css('color', '#868686');
        $(this).find('.ft').css('color', '#0099FF');
        $(this).siblings().find('.nav-icon').remove();
        $(this).prepend('<span class="nav-icon"></span>');
        index=$(this).index();
        if(index==0){
            status_type = 3;
             $('.content-nav').find('li:eq(2)').remove();
             
            $('.content-nav').append('<li><a href="javascript:void(0)" class="h_text">我发布的</a></li>');
            getAjaxData('post','/neptune/list_mydata/',getData,getOb(1,3));
            
        }else if(index==1){
            status_type = 2;
             $('.content-nav').find('li:eq(2)').remove();
             $('.content-nav').append('<li><a href="javascript:void(0)" class="h_text">我订阅的</a></li>');
               getAjaxData('post','/neptune/list_mydata/',getData,getOb(1,2));
            
        }
    });
});
function getData(data){
    if(index==0){
        $('#div0 tbody tr').remove();
         $('#div0 .m-title').text('我的发布列表');
        $('#div0 p:eq(1)').remove();
            $('#div0 thead th:eq(2)').text('更新时间');
          $('#div0 thead th:eq(3)').text('操作');
        $('#bar').remove();
        if(data.status==0){
        $('.navbar li:eq(0)').find('.nav-num').text(data.count);
        var data_list=data.data_list;
        if(data_list.length!=0){
        for(var i=0;i<data_list.length;i++){
             $('#div0 tbody').append('<tr style="height:50px;"><td style="width:71px;border:1px solid #e4e4e4">'+data_list[i].no+'</td><td style="width:448px;text-align:left;border:1px solid #e4e4e4"><a href="/neptune/tag_person/?owner_name='+data_list[i].owner_name+'&tag_name='+data_list[i].app_name+'" style="color:#868686;margin-left:16px" class="m-hov">'+data_list[i].app_name+'</a></td><td style="width:274px;border:1px solid #e4e4e4">'+data_list[i].update_time+'</td><td style="width:177px;border:1px solid #e4e4e4"><a href="javascript:void(0)" class="back" style="color:#0099FF;margin-right:41px" app_name="'+data_list[i].app_name+'" onclick="back(this)" key="0">回滚</a><a href="javascript:void(0)" style="color:#0099FF" class="outline" onclick="outline(this)" key="1" app_name="'+data_list[i].app_name+'">下线</a></td>');
          }
       var pag=pagination(page,10,data.count,data.index_min,data.index_max);
        $('.bar-nav li').unbind('click');
    $('#div0').append(pag);
    $('.bar-nav li').on('click',function(){
        $(this).addClass('bg-li');
        $(this).siblings().removeClass('bg-li');
        page=$(this).attr('action-data');
        getAjaxData('post','/neptune/list_mydata/',getData,getOb(page,3));
    });
    }else{
        $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">我发布的数据内容为空</p>');
    }
    }else{
          $('.navbar li:eq(0)').find('.nav-num').text(0);
        $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');
    }
    }else if(index==1){
            $('#div0 .m-title').text('我的订阅列表');
          $('#div0 tbody tr').remove();
            $('#div0 p:eq(1)').remove();
            $('#div0 thead th:eq(2)').text('产出方');
            $('#div0 thead th:eq(3)').text('状态');
            $('#bar').remove();
        if(data.status==0){
         console.log(data.status);
          $('.navbar li:eq(1)').find('.nav-num').text(data.count);
        var data_list=data.data_list;
        if(data_list.length!=0){
        for(var i=0;i<data_list.length;i++){
             var appendHtml;
             if(data_list[i].status==2){
                appendHtml='<div class="person_tag" style=" position: absolute;left: 21px;top: -20px;"><span style="padding-left: 5px;">已订阅</span></div>';
             }else{
                appendHtml='<div class="person_tag" style="background:url(\'../../static/images/neptune/search-input-auto_u33.png\') no-repeat;position: absolute;left: 18px;top: -20px;"><span style="padding-left: 4px;color:#a1a1a1">权限申请中</span></div>';
             }
             $('#div0 tbody').append('<tr style="height:50px;"><td style="width:71px;border:1px solid #e4e4e4">'+data_list[i].id+'</td><td style="width:448px;text-align:left;border:1px solid #e4e4e4"><a href="/neptune/tag_person/?owner_name='+data_list[i].owner_name+'&tag_name='+data_list[i].app_name+'" style="color:#868686;margin-left:16px" class="m-hov">'+data_list[i].app_name+'</a></td><td style="width:274px;border:1px solid #e4e4e4">'+data_list[i].owner_name+'</td><td style="width:177px;border:1px solid #e4e4e4;position:relative">'+appendHtml+'</td>');
          }
       var pag=pagination(page,10,data.count,data.index_min,data.index_max);
        $('.bar-nav li').unbind('click');
    $('#div0').append(pag);
    $('.bar-nav li').on('click',function(){
        $(this).addClass('bg-li');
        $(this).siblings().removeClass('bg-li');
        page=$(this).attr('action-data');
        getAjaxData('post','/neptune/list_mydata/',getData,getOb(page,3));

    });
    }
    else{
          $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">我订阅的数据内容为空</p>');
    }
    }else{
          $('.navbar li:eq(1)').find('.nav-num').text(0);
        $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');
    }
    }
}
function outline(that){
    //下线
    var that=$(that);
     app_name=that.attr('app_name');
    boutline=1;
    /*    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">下线确认</span><span class="deletemodal" style="float:right"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定要取消该订阅内容？</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="deleteView()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    });*/
         $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">下线确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">现在有n个应用方正在使用您的应用,确定下线吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="btnajax()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
    
}
function back(that){
    var that=$(that);
    app_name=that.attr('app_name');
    boutline=0;
    $('#content').append('<div class="modal"><div class="togglemodal" style="width:480px;height:587px;"><span class="cr-mess" style="margin-bottom:10px;float:left">回滚时间选择</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p" style="margin-top:28px">选择要回滚的时间点</p><div style="margin-left:20px;margin-top:20px"><span class="date_bg"><span class="date_icon"></span></span><input type="text" class="date_choose"/></div><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:120px" onclick="btnajax()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
     $('.modal').height($('body').height());
     $('.modal').width($(window).width());
     $('.modal').css('margin-left', -($(window).width()-1210)/2);
     $('.date_choose').datetimepicker({
            lang:'ch',
            format:'Y-m-d H:i',
            formatTime:'H:i',
            formatDate:"Y-m-d",
            step:1,
        });

}
function btnajax(){
   if(boutline==0){  
     var date_time=$('.date_choose').val().replace('-','').replace('-','').replace(' ','').replace(':',''); 
    var ob={
        tag_name:app_name,
        owner_name:$('#user_name').val(),
        action:0,
        back_time:date_time
    }
      getAjaxData('post','/neptune/data_operate/',backmessage,ob); 
    }else{
      var ob={
        tag_name:app_name,
        owner_name:$('#user_name').val(),
        action:1
    }
      getAjaxData('post','/neptune/data_operate/',backmessage,ob);
    }
}
function backmessage(data){
      $('#content .modal').remove();
   if(data.status==0){
        var str;
        if(boutline==0){
            str="回滚成功";
    }else{
            str="下线成功";
        }
       /* $('#content').append('<div class="modal"><div class="correct"><span class="correct_back"></span><p class="correct_p">'+str+'</p></div></div>');
         $('.modal').height($('body').height());
        setTimeout(function(){
            $('#content .modal').remove();
        },3000);*/
        if(boutline==0){
            $('.navbar li:eq(0)').trigger('click');
        }else{
             $('.navbar li:eq(1)').trigger('click');
        }
    }else if(data.status!=0){
        var str;
        if(boutline==0){
            str="回滚失败";
        }else{
            str="下线失败";
        }
        $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+str+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    }
}
//重新加载页面
function windowreload(){
    $('#content .modal').remove();
    window.location.reload();
}
function deletemodal(){
    $('#content .modal').remove();
}
function removemodal(){
    $('#content .modal').remove();
}
function gopage(){
    var page=parseInt($('.searchpage').val());
    if(isNaN(page))
    {
        alert('请输入页号后点击翻页');
        return;
    }
    getAjaxData('post','/neptune/list_mydata/',getData,getOb(page, status_type));
}
