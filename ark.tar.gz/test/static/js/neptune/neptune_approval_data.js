$(function(){
    $("#id_approval_proc_no").on('click', function(){
        back(this);
    });
    $("#id_approval_proc_ok").on('click', function(){
        outline(this);
    });
    //展开收起块
    var divHeight;
    $('.toggled').attr('toggle','0');
    $('.toggled').on('click',function(){
        
        if(parseInt($(this).attr('toggle'))==0){
        $(this).attr('toggle','1');
        divHeight=$(this).parent().height();

        $(this).attr('getheight',$(this).parent().height());
        $(this).parent().css({
            'height':'70px',
            'overflow':'hidden'
        });
        
        $(this).next().remove(); 
        $(this).html('展开<img src="../../static/images/neptune/toggle_u74.png" width="22" height="22" style="position:absolute;top:20px;transform:rotate(180deg)">');
     }else if(parseInt($(this).attr('toggle'))==1){
         $(this).attr('toggle','0');
        $(this).parent().css({
            'height':$(this).attr('getheight')+'px',
            'overflow':''
        });
        $(this).html('收起<img src="../../static/images/neptune/toggle_u74.png" width="22" height="22" style="position:absolute;top:20px;">');
         $('<span class="line" style="width:1133px;margin-top:15px"></span>').insertAfter($(this));
     }
    });
});
function back(that){
    var that=$(that);
    tag_name = that.attr('action-data');

    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">审批确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定拒绝此发布请求吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="do_back()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
}

function do_back()
{
    getAjaxData('post','/neptune/tag_reject_approval_apply/',callfn,{tag_name:tag_name});    
}
function outline(that){
    var that=$(that);
    tag_name = that.attr('action-data');

    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">审批确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定同意此发布请求吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="do_outline()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
}
function do_outline()
{
    getAjaxData('post','/neptune/tag_confirm_approval_apply/',callfn,{tag_name:tag_name});
}


function callfn(data){
    deletemodal();
    if(data.status==0){
        window.location.href = "/neptune/tag_approval/";
    }else{
         $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="removemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    }
}
function removemodal(){

    $('#content .modal').remove();
}
function deletemodal(){
    $('#content .modal').remove();
}
