function deleteDataRow(that){
    var that=$(that);
    that.parent().remove();
    $('#data_tag').height($('#data_tag').height()-56);
}
cron_hour_html = '';
$(function(){
        $('.update_cycle').on('change', function(){
            var cur_val = $('.update_cycle:checked').val();
            if(cur_val == "0")
            {
                $("#id_span_crontab").remove();
                $("#id_div_crontab").prepend(cron_hour_html);
            }
            else
            {
                var dom_hour_conf = $("#crontab_conf_hour");
                cron_hour_html = '<span style="padding-left:117px" id="id_span_crontab"><span style="color:red">*</span>定时</span>' + ($('<div></div>').append(dom_hour_conf.clone()).append(dom_hour_conf.next().clone())).html()
                dom_hour_conf.next().remove();
                dom_hour_conf.remove();
            }
        });
        $('#test_time').datetimepicker({
            lang:'ch',
            format:'Y-m-d H:i',
            formatTime:'H:i',
            formatDate:"Y-m-d",
            step:1,
        });
        var pangu='<div id="pangu"><div class="data_left"><span style="padding-left:120px;float:left;margin-top:5px"><span style="color:red">*</span>文件数</span><input type="text" placeholder="请输入文件数量" class="send_input" style="width:580px" id="pangu_file_num"></div><div class="data_left"><span style="padding-left:106px;float:left;margin-top:5px"><span style="color:red">*</span>数据路径</span><input type="text" placeholder="输入数据路径" class="send_input" style="width:580px" id="pangu_path"/></div><div class="data_left"><span style="padding-left:93px;float:left;margin-top:5px"><span style="color:red">*</span>字段分隔符</span><input type="text" placeholder="输入字段分隔符" class="send_input" style="width:580px" id="grep"></div><div>';
        var odps='<div id="odps"><div class="data_left"><span style="padding-left:115px;float:left;margin-top:5px"><span style="color:red">*</span>project</span><input id="odps_project" type="text" placeholder="输入odps project" class="send_input" style="width:580px"></div><div class="data_left"><span style="padding-left:129px;float:left;margin-top:5px"><span style="color:red">*</span>table</span><input id="odps_table" type="text" placeholder="输入odps table" class="send_input" style="width:580px"></div><div class="data_left"><span style="padding-left:112px;float:left;margin-top:5px">partition</span><input id="odps_partition" type="text" placeholder="输入数据路径" class="send_input" style="width:580px"></div></div>';
        //odps pangu切换
        $('.data_type').on('change',function(){
            if($(this).val()=="0"){
                console.log(0);
                if($('#data_tag').find('#pangu').length==0){
                    $('#odps').remove();
                    $('#tag_source').after($(pangu));
                }
            }else{
                console.log(1);
                
                 if($('#data_tag').find('#odps').length==0){
                    $('#pangu').remove();
                    $('#tag_source').after($(odps));
                }
            }
        });

          //审批数据同意或拒绝发布
             var divHeight;
    $('.toggled').attr('toggle','0');
    $('.toggled').on('click',function(){

        if(parseInt($(this).attr('toggle'))==0){
        $(this).attr('toggle','1');
        divHeight=$(this).parent().height();

        $(this).attr('getheight',$(this).parent().height());
        $(this).parent().css({
            'height':'70px',
            'overflow':'hidden'
        });

        $(this).next().remove();
        $(this).html('展开<img src="../../static/images/neptune/toggle_u74.png" width="22" height="22" style="position:absolute;top:20px;transform:rotate(180deg)">');
     }else if(parseInt($(this).attr('toggle'))==1){
         $(this).attr('toggle','0');
        $(this).parent().css({
            'height':$(this).attr('getheight')+'px',
            'overflow':''
        });
      $(this).html('收起<img src="../../static/images/neptune/toggle_u74.png" width="22" height="22" style="position:absolute;top:20px;">');
         $('<span class="line" style="width:1133px;margin-top:15px"></span>').insertAfter($(this));
     }
    });
    

         //发布数据数据配置数据列添加
        $('.data_add_icon').on('click',function(){
            $(this).parent().parent().append('<div style="clear:both" class="data_col"><span style="padding-left:122px;float:left;margin-top:5px"><span style="color:red"></span></span><select class="send_input" style="width:215px;margin-left:69px;margin-top:16px;float:left"><option>base_column</option><option>mul-val-column</option><option>mul_kv_column</option><option>mul_kv_xp_column</option></select><input type="text" placeholder="输入列名" class="send_input" style="float:left;width:355px;margin-left:10px;margin-top:16px"><span class="data_remove_icon" style="margin-left:5px;margin-top:26px;float:left" onclick="deleteDataRow(this)"></span></div>');
        $('#data_tag').height($('#data_tag').height()+56);
        });
       $('#uploadfile').on('change',function(){
            console.log($(this).val());
            $('#schema_file').val($(this).val());
        });
        $('#pub_save_btn').on('click',function(){
            var data_config;
            if($('#data_tag').find('#odps').length==0){
                    var column_sm=$('#column_sm option:selected').val();
                    var column_col=$('#column_col').val();
                    var arr=[['0',column_sm,column_col]];
                    for(var i=0;i<$('.data_col').length;i++){
                        var data_sel=$('.data_col select')[i].value;
                        var data_inp=$('.data_col input')[i].value;
                        arr.push(['1',data_sel,data_inp]);  
                    } 
                    data_config={
                        data_source:"pangu",//也可以为"odps" 如果对应为pangu则只有"pu_path"，"sep"，"columns"三项，如果对应为odps则只有："project"，"table"，"columns"，"partition"
                        pu_path:$('#pangu_path').val(),
                        pu_file_num:$('#pangu_file_num').val(),
                        sep:$('#grep').val(), //分隔符
                        columns:arr
                    };
                    console.log(data_config);
            }else{
                    var column_sm=$('#column_sm option:selected').val();
                    var column_col=$('#column_col').val();
                    var arr=[['0',column_sm,column_col]];
                    for(var i=0;i<$('.data_col').length;i++){
                        var data_sel=$('.data_col select')[i].value;
                        var data_inp=$('.data_col input')[i].value;
                        arr.push(['1',data_sel,data_inp]);
                    }
                    data_config={
                        data_source:"odps",//也可以为"odps" 如果对应为pangu则只有"pu_path"，"sep"，"columns"三项，如果对应为odps则只有："project"，"table"，"columns"，"partition"
                        project:$('#odps_project').val(),
                        table:$('#odps_table').val(),
                        partition:$('#odps_partition').val(),
                        columns:arr
                    };
 

            }
             var user_name=$('.sr-user').text();
             var app_name=$('#app_name').val();
            var category_type=$('#category_type option:selected').val();
            var update_cycle=$('.update_cycle:checked').val();
            var crontab_conf=get_crontab_conf_val();
            var overtime=$('#overtime option:selected').val();
            var test_time=$('#test_time').val().replace(/:/g,'').replace(/-/g,'').replace(/ /g,'')
            var protect_level=$('.protect_level:checked').val();
            var version=$('#version').val();
            var schema_file=$('#schema_file').val();
            var old_scheme_file_url=$('#old_scheme_file_url').val();
            var description=$('#description').val();
            $.ajaxFileUpload(
            {
            url: '/neptune/publish_tagconf_data/',
            secureuri: false,
            
            fileElementId :'uploadfile',//file控件id
            dataType : 'json',
            data: {            
            data_type:$('.data_type:checked').val(),        
            action:2,
             user_name:user_name,
             app_name:app_name, 
            category_type:category_type,
            update_cycle:update_cycle,
            crontab_conf:crontab_conf,
            overtime:overtime,
            test_time:test_time,
            protect_level:protect_level,
            version:version,
            old_scheme_file_url:old_scheme_file_url,
            description:description,
            data_config:JSON.stringify(data_config)
             },
            success:function(data){
                if(data.status == 0)
                {
                   window.location.href = '/neptune/tag_center/';        
                }
                else
                {
                    $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">操作失败</p></div></div>');
                    $('.modal .correct').css('top', '56%');
                    $('.modal').height($('body').height());
                    $('.modal').width($(window).width());
                    $('.modal').css('margin-left', -($(window).width()-1210)/2);
                }
            }
            });   

        })
        $('#send_btn').on('click',function(){
            var data_config;
            if($('#data_tag').find('#odps').length==0){
                    var column_sm=$('#column_sm option:selected').val();
                    var column_col=$('#column_col').val();
                    var arr=[['0',column_sm,column_col]];
                    for(var i=0;i<$('.data_col').length;i++){
                        var data_sel=$('.data_col select')[i].value;
                        var data_inp=$('.data_col input')[i].value;
                        arr.push(['1',data_sel,data_inp]);  
                    } 
                    data_config={
                        data_source:"pangu",//也可以为"odps" 如果对应为pangu则只有"pu_path"，"sep"，"columns"三项，如果对应为odps则只有："project"，"table"，"columns"，"partition"
                        pu_path:$('#pangu_path').val(),
                        pu_file_num:$('#pangu_file_num').val(),
                        sep:$('#grep').val(), //分隔符
                        columns:arr
                    };
                    console.log(data_config);
            }else{
                    var column_sm=$('#column_sm option:selected').val();
                    var column_col=$('#column_col').val();
                    var arr=[['0',column_sm,column_col]];
                    for(var i=0;i<$('.data_col').length;i++){
                        var data_sel=$('.data_col select')[i].value;
                        var data_inp=$('.data_col input')[i].value;
                        arr.push(['1',data_sel,data_inp]);
                    }
                    data_config={
                        data_source:"odps",//也可以为"odps" 如果对应为pangu则只有"pu_path"，"sep"，"columns"三项，如果对应为odps则只有："project"，"table"，"columns"，"partition"
                        project:$('#odps_project').val(),
                        table:$('#odps_table').val(),
                        partition:$('#odps_partition').val(),
                        columns:arr
                    };
 

            }
             var user_name=$('.sr-user').text();
             var app_name=$('#app_name').val();
            var category_type=$('#category_type option:selected').val();
            var update_cycle=$('.update_cycle:checked').val();
            var crontab_conf=get_crontab_conf_val();
            var overtime=$('#overtime option:selected').val();
            var test_time=$('#test_time').val().replace(/:/g,'').replace(/-/g,'').replace(/ /g,'')
            var protect_level=$('.protect_level:checked').val();
            var version=$('#version').val();
            var schema_file=$('#schema_file').val();
            var description=$('#description').val();
            var old_scheme_file_url=$('#old_scheme_file_url').val();
            var action = update_flag ? 3 : 1;
            $.ajaxFileUpload(
            {
            url: '/neptune/publish_tagconf_data/',
            secureuri: false,
            
            fileElementId :'uploadfile',//file控件id
            dataType : 'json',
            data: {            
            data_type:$('.data_type:checked').val(),        
            action:action,
             user_name:user_name,
             app_name:app_name, 
            category_type:category_type,
            update_cycle:update_cycle,
            crontab_conf:crontab_conf,
            overtime:overtime,
            test_time:test_time,
            protect_level:protect_level,
            version:version,
            old_scheme_file_url:old_scheme_file_url,
            description:description,
            data_config:JSON.stringify(data_config)
             },
            success:function(data){
                if(data.status == 0)
                {
                   window.location.href = '/neptune/tag_center/';        
                }
                else
                {
                    $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">操作失败</p></div></div>');
                    $('.modal .correct').css('top', '56%');
                    $('.modal').height($('body').height());
                    $('.modal').width($(window).width());
                    $('.modal').css('margin-left', -($(window).width()-1210)/2);
                }
            }
            });   

        });

});
function deletemodal(){
    $('#content .modal').remove();
}
function removemodal(){
    $('#content .modal').remove();
}
function get_crontab_conf_val()
{
    var type = $('.update_cycle:checked').val();
    var ret = '';
    if(type == '0')
    {
        ret = $("#crontab_conf_minute").val() + " " + $("#crontab_conf_hour").val() + " * * *";
    }
    else
    {
        ret = $("#crontab_conf_minute").val() + " * * * *";
    }
    return ret;
}
