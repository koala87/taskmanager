$(function(){
      $('#navright li:gt(0)').on('click',function(){
      var toggleSelect=$('#toggle-select');
       if(toggleSelect.is(':visible')) {
           toggleSelect.fadeOut();
       }else{
           toggleSelect.show();
       }
       });
        $('.iconli').on('click',function(){
            window.location.href="/neptune/tag_message/";
        });
        getAjaxData('post','/neptune/unread_message_num/',getUnReadNum);
        setInterval(function(){ 
        getAjaxData('post','/neptune/unread_message_num/',getUnReadNum);
        },60000);


});
function getUnReadNum(data){
   $('.iconfont').text(data.count); 
}
function getAjaxData(ajaxgp,url,fn,obj){
        if(ajaxgp=="get"){
            if(typeof obj!="undefined"){
            var str="";
            for(var p in obj){
                str=str+p+"="+obj[p]+"&";
            }
            str=str.substr(0,str.length-1);
            url=url+"?"+str;
            }
            $.get(url,function(data){
                fn(data);

            },'json');
        }else if(ajaxgp=="post"){
                if(typeof obj=="undefined"){
                    $.post(url,function(data){
                        fn(data);
                    },'json');

                }else{
                $.post(url,obj,function(data){

                    fn(data);
                },'json');
    }
    }
}

function pagination(cur_page, page_size, record_total,index_min,index_max,fn_gopage)
{
    if(fn_gopage == undefined)
    {
        fn_gopage = 'gopage';
    }
    cur_page = parseInt(cur_page);
    page_size = parseInt(page_size);
    record_total = parseInt(record_total);
    index_min = parseInt(index_min);
    index_max = parseInt(index_max);
    var show_page_num = 5;
    var page_total = Math.ceil(record_total/page_size);
    if(cur_page < 1 || cur_page > page_total){return '';}
    var html = '<div id="bar">';
    html = html + '<span class="pagenum">共'+record_total+'条记录，正在浏览'+index_min+'-'+index_max+'条</span>';
    html = html + '<ul class="bar-nav">';
    if(cur_page>1)
    {
        html = html + '<li style="width:20px;cursor:pointer" class="firstpage pagenition_li" action-data="1"><<</li>';
        html = html + '<li style="width:40px;cursor:pointer" class="firstpage pagenition_li" action-data="'+(cur_page-1).toString()+'">上一页</li>';
    }
    if(cur_page>Math.ceil(show_page_num/2))
    {
        html = html + '<li>...</li>';
    }
    var page_show_list = [];
    for(var i=-Math.floor(show_page_num/2); i<=Math.floor(show_page_num/2);i++)
    {
        page_show_list.push(cur_page+i);
    }
    for(var i=0,j=0; i<Math.floor(page_show_list.length/2);i++,j++)
    {
        if(page_show_list[i]<1){
            page_show_list.splice(0, 1);
            page_show_list.push(cur_page+Math.ceil(show_page_num/2)+j);
            i--;
        }
    }
    for(var i=0; i<page_show_list.length; i++)
    {
        if(page_show_list[i]>page_total){
            page_show_list.splice(i, 1);
            i--;
        }
    }
     while(page_show_list.length < show_page_num)
    {     
        if((page_show_list[0]-1)>1)
        {
            page_show_list.unshift(page_show_list[0]-1);
        }    
        else
        {
            break;
        }
    }
    for(var i=0; i<page_show_list.length; i++)
    {
        if(page_show_list[i] == cur_page)
        {
            html = html + '<li class="pagenition_li bg-li" action-data="'+page_show_list[i]+'">'+page_show_list[i]+'</li>';
        }
        else 
        {
            html = html + '<li style="cursor:pointer;" action-data="'+page_show_list[i]+'">'+page_show_list[i]+'</li>';
        }
    }
    if(page_show_list[page_show_list.length-1] < page_total)
    {
        html = html + '<li>...</li>';
    }
    if(cur_page < page_total)
    {
        html = html + '<li style="width:40px; cursor:pointer;" class="pagenition_li" action-data="'+(cur_page+1).toString()+'">下一页</li>';
        html = html + '<li style="width:20px; cursor:pointer;" class="lastpage pagenition_li" action-data="'+page_total+'">>></li>';
    }
    html = html + '</ul>';
    html = html + '<p style="margin-top:20px;margin-left:15px" class="pull-left bar-p">共 '+page_total+' 页， 到第<input type="text" class="searchpage"/>页</p>';
    html = html + '<span style="display: inline-block;width: 53px;height: 30px;border-radius: 5px;color: black;line-height: 30px;border: 1px solid lightgray;;margin-top:19px;cursor:pointer" class="pull-left btnpage" onclick="'+fn_gopage+'()">确定</span>';
    html = html + '</div>';
    return html;
}

