var page=1;
var index;
function getOb(page){   
        
    return {
        owner_name:$('#user_name').val(),
        page:page,
        page_size:10
    }
} 
$(function(){
    getAjaxData('post','/neptune/tag_list_approval/',getData,getOb(1));
});
function getData(data){
      $('#div0 tbody tr').remove();
      $('#div0 p:eq(1)').remove();
      if(data.status==0){
        var data_list=data.online_list;
        if(data_list.length!=0){
            for(var i=0;i<data_list.length;i++){
            var index = i+1;
            var appendHtml='<tr style="height:50px;"><td style="width:66px;border:1px solid #e4e4e4">'+index+'</td><td style="width:145px;text-align:center;border:1px solid #e4e4e4">'+data_list[i].user_name+'</td><td style="width:503px;border:1px solid #e4e4e4"><a target="_blank" href="/neptune/tag_approval_data?tag_name='+data_list[i].app_name+'&owner_name='+data_list[i].user_name+'" style="color:#868686" class="data_hov">'+data_list[i].app_name+'</a></td><td style="width:220px;border:1px solid #e4e4e4">'+data_list[i].time+'</td><td style="width:196px;border:1px solid #e4e4e4"><a href="javascript:void(0)" class="back" style="color:#0099FF;margin-right:41px" action-data="'+data_list[i].app_name+'" onclick="back(this)">同意</a><a href="javascript:void(0)" style="color:#0099FF" action-data="'+data_list[i].app_name+'" class="outline" onclick="outline(this)">拒绝</a></td></tr>';
            $('#div0 tbody').append(appendHtml);
            }
//             var pag=pagination(page,10,data.count,data.index_min,data.index_max);
//             $('.bar-nav li').unbind('click');
//            $('#div0').append(pag);
//             $('.bar-nav li').on('click',function(){
//             $(this).addClass('bg-li');
//              $(this).siblings().removeClass('bg-li');
//             page=$(this).attr('action-data');
//             getAjaxData('post','/neptune/list_mydata/',getData,getOb(page,2));
//          });

        }else{
             $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">发布审批列表为空</p>');
        }
      }else{
        $('#div0').append('<p style="font-size: 14px;margin-left: 17px;margin-top: 10px;">'+data.info+'</p>');

      }
}
function back(that){
    var that=$(that);
    tag_name = that.attr('action-data');
    owner_name = that.parent().parent().children().eq(1).text();

    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">审批确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定同意此发布请求吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="do_outline()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
}

function do_back()
{
    getAjaxData('post','/neptune/tag_reject_approval_apply/',callfn,{owner_name:owner_name, tag_name:tag_name});    
}
function outline(that){
    var that=$(that);
    tag_name = that.attr('action-data');
    owner_name = that.parent().parent().children().eq(1).text();

    $('#content').append('<div class="modal"><div class="togglemodal"><span class="cr-mess" style="margin-bottom:10px;float:left">审批确认</span><span class="deletemodal" style="float:right;cursor:pointer" onclick="deletemodal()"></span><span class="line" style="width:394px;margin-top:15px;clear:both"></span><p class="cr-p">您确定拒绝此发布请求吗?</p><button class="btn" style="background:aliceblue;margin-top:33px;margin-left:95px" onclick="do_back()">确定</button><button class="btn" style="margin-left:43px;background:#0099FF;color:white" onclick="removemodal()">取消</button></div></div>');
    $('.modal').height($('body').height());
    $('.modal').width($(window).width());
    $('.modal').css('margin-left', -($(window).width()-1210)/2);
}
function do_outline()
{
    getAjaxData('post','/neptune/tag_confirm_approval_apply/',callfn,{owner_name:owner_name, tag_name:tag_name});
}


function callfn(data){
    deletemodal();
    if(data.status==0){
        window.location.reload();
    }else{
         $('#content').append('<div class="modal"><div class="correct"><span class="deletemodal" style="margin-top:14px;float:right;cursor:pointer" onclick="removemodal()"></span><span class="line" style="width:302px;margin-top:15px;clear:both"></span><span class="wrong_back"></span><p class="correct_p">'+data.info+'</p></div></div>');
         $('.modal').height($('body').height());
         $('.modal').width($(window).width());
         $('.modal').css('margin-left', -($(window).width()-1210)/2);
    }
}
function removemodal(){

    $('#content .modal').remove();
}
function deletemodal(){
    $('#content .modal').remove();
}
