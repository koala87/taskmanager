$(function(){
    $('#l-bg').height($(window).height());
    last_username = getCookie("last_username");
    $("#username").val(last_username);
    if(last_username)
    {
        $("#is_remember").prop("checked", "checked");
    }
    $('.sub_btn').on('click', function(){
        var username = $("#username").val();
        var password = $("#password").val();
        var is_remember = $("#is_remember").is(":checked") ? 1 : 0;
        var is_auto_login = $("#is_auto_login").is(":checked") ? 1 : 0;
        $.post('/do_login/', {username:username,password:password,is_remember:is_remember,is_auto_login:is_auto_login},function(data){
            if(data.status==0)
                window.location.href="/neptune/tag_introduction/";
            else
                alert(data.info);
        }, 'json');
    });
    $(".l-center").on('keydown', function(e){
        if(e.which == 13)
        {
            $('.sub_btn').click();
            return false;
        }
    });


});
function getCookie(name)
{
    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
    if(arr=document.cookie.match(reg))
        return unescape(arr[2]);
    else
        return null;
}
