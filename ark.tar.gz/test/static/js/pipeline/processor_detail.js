//操作状态
function status_convert(status){
    status_str = '';
    if(status == 0){
        status_str = '未使用';
    }
    else if(status == 1){
        status_str = '<font color="red">使用中</font>';
    }
    return status_str;
}

//历史表格
function hist_table(list){
    var content = "";
    for(var i=0;i<list.length;i++){
        content += "<tr><td>" + (i+1) + "</td><td>" + 
            list[i].upload_user_name;
        content += "</td><td>" + list[i].upload_time;
        content += "</td><td>" + list[i].description;
        content += "</td><td>" + status_convert(list[i].status);
        if(list[i].status == 1){
            content += "</td><td><font color='red'>已上线</font></td></tr>"
        }
        else{
            content += "</td><td><a id='refresh_"+i+
                "' href='javascript:void(0)'"+
                " onclick='reback("+list[i].id+")'>上线</a>"+
                "<img id='busy_"+i+"' src='/static/images/busy.gif' "+
                " style='display:none'></td></tr>";
        }
    }
    return content;
}

var choose_value = 0;
function ok_value(){
    choose_value = 1;
}

//回滚
function reback(id){
    var url = "/processor/reback/"+id+"/";
    $('#quit_ok_modal').unbind('hide.bs.modal');
    $("#modal_content").html('确定要上线这个版本吗?');
    $("#quit_ok_modal").modal('show');
    //添加modal事件
    $("#quit_ok_modal").on('hide.bs.modal',function(e){
        if(choose_value == 1){
            $.ajax({
                type:'post',
                url:url,
                success:function(result){
                    if(result.status){
                        $('#messageModal .modal-body p').text(result.msg);
                        $('#messageModal').modal('show');
                    }
                    else{
                        alert("上线成功！");
                        location.reload();
                    }
                }
            });
        }
    });
}


//查询操作历史
function showProcHist(){
    var id = $("#proc_id").val();
    $("#view_hist_list").empty();
    var url = "/processor/viewHistory/" + id + "/";
    $.ajax({
        type :'post',
        url : url,
        success : function(result){
            if(result.status){
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            }else{
                //展示历史表格
                content = hist_table(result.history_list);
                $("#view_hist_list").html(content);
            }
        }
    });
}



//引用表格
function quote_list_table(list){
    var content = "";
    for(var i=0;i<list.length;i++){
        content += "<tr><td>" + (i+1) + "</td><td>" + 
            "<a href='/pipeline/task/"+list[i].pipeline_id+"/'>"+
            list[i].pipeline_name+"</a>";
        content += "</td><td>" + list[i].task_name;
        content += "</td><td>" + list[i].last_run_time;
        content += "</td><td>" + list[i].owner_name;
    }
    return content;
}


//引用信息
function showQuote(){
    var id = $("#proc_id").val();
    $("#quote_list").empty();
    var url = "/processor/viewQuote/" + id + "/";
    $.ajax({
        type :'post',
        url : url,
        success : function(result){
            if(result.status){
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');

            }else{
                //展示引用信息
                content = quote_list_table(result.quote_list);
                $("#quote_list").html(content);
            }
        }
    });
}

function change_color(obj){ 
    for(i=0;i<sel_s.length;i++){ 
        sel_s[i].style.fontWeight="normal"; 
    } 
    obj.style.fontWeight="bold"; 
} 

//开放插件
function publishNode(id, info) {
    choose_value = 0;
    var url = '/processor/public_processor/';
    $('#quit_ok_modal').unbind('hide.bs.modal');
    $("#modal_content").html(info);
    $("#quit_ok_modal").modal('show');
    //添加modal事件
    $("#quit_ok_modal").on('hide.bs.modal',function(e){
        if(choose_value == 1){
            $.ajax({
                type:'post',
                url:url,
                data:{"id":id},
                success:function(result){
                    if(result.status){
                        $('#messageModal .modal-body p').text(result.msg);
                        $('#messageModal').modal('show');
                    }
                    else{
                        location.reload();
                    }
                }
            });
        }
    });
}

function showCopyModal(){
   $('#copyModal').modal('show');
}


function pn_notice(pl_id) {                
    window.open('/pipeline/task/'+pl_id+'/');
    location.href = '/pipeline/task/'+pl_id+'/';
}

//申请ajax
function apply_new_pipeline() {
    var proc_id = $("#proc_id").val();
    var pl_id = $("#pipe_id").val();
    var pl_name = $("#new_pl_name").val()

    var project_id = $('#new_pl_select option:selected').val();
    var url = "/pipeline/new_pipeline_by_proc/";
    text = '创建流程成功！';
    $.ajax({
        type:'post',
        url:url,
        data:{'proc_id':proc_id,'pl_name':pl_name, 'project_id': project_id},
        success:function(result){
            if(result.status){
                alert("创建流程失败！原因:" + result.msg);
            } else {
                new PNotify({
                    title: '通知消息',
                    text: '创建成功，即将为你跳转到新流程......',
                    addclass: 'custom',
                    type: 'success'
                });
                setTimeout("pn_notice(" + result.pl_id + ")", 1500);
            }
        }
    });
}

function create_new_pipeline() {
    var id = $("#proc_id").val();
    $("#new_pipeline_div").modal({
        backdrop:false,
        show:true,        
    });

}

function  create_new_task() {
    $.ajax({
        type : "post",
        url  : '/pipeline/getPipelines/',
        async: false,
        dataType:"json",
        data:{"task_id":1},
        success : function(result) {
            if(result.status){
                console.log(result.msg);
            }else{
                data_list = result.pipeline_list;
                var data_str = '';
                for(i = 0;i<data_list.length;i++){
                    data_str += "<option value='"+data_list[i].id+"' >"+
                    data_list[i].name+"</option>";
                }
                //select2初始化选第一个
                //$(".select2-chosen").html(data_list[0].name);
                $("#s2id_pipeline_select span.select2-chosen").html(data_list[0].name);
                $("#pipeline_select").append(data_str);
            }
        }
    });

    var id = $("#proc_id").val();

    $("#new_task_hid").show();
    $("#new_task_sure").show();
    $("#new_task_hint").hide();
    $("#button_to_other").hide();
    $("#new_task_div").hide();

    $("#new_task_div").show();
    //获取应用列表
    $("#new_task_div").modal({
        backdrop:false,
        show:true,        
    });
}

function skip_new_pipeline() {    
    var pl_id = $("#pipeline_select").val();
    location.href = '/pipeline/task/'+pl_id+'/';
}

//申请ajax
function apply_new_task() {
    $("#new_busy_icon").show()
    $("#new_task_hid").hide()
    $("#new_task_sure").hide()
    
    var pl_id = $("#pipeline_select").val();
    var proc_id = $("#proc_id").val();
    var url = "/pipeline/new_task_by_proc/";
    $.ajax({
        type:'post',
        url:url,
        data:{'proc_id':proc_id, 'dest_pl_id': pl_id},
        success:function(result){
            $("#new_busy_icon").hide()
            if(result.status){
                alert("创建任务失败！" + result.msg);
                $("#new_task_hid").show();
                $("#new_task_sure").show();
                $("#new_task_hint").hide();
                $("#button_to_other").hide();
                $("#new_task_div").hide();
            } else{
                $("#new_task_hint").show();
                $('#new_task_hint').text('创建任务成功！');

                $("#button_to_other").show();
                $("#delete-task").hide();
            }
        }
    });
}

function create_config_table() {
    var config = $("#config_str").val();
    if (config != '') {
        var temp = config.split('\n');
        var count = temp.length;
        if (count > 0) {
            for (var i = 0; i < count; i++) {
                config_str = temp[i]
                config_str_ = config_str.split('=');
                config_str_left = config_str_[0];
                config_str_right = temp[i].substring(config_str_left.length + 1);

                config_right_split = config_str_right.split('\1100')
                var config_state = ""
                if (config_right_split.length >= 2) {
                    config_state = config_right_split[1];
                    config_str_right = config_right_split[0];
                }

                var row = document.createElement("tr");
                document.getElementById("_table").appendChild(row);
                var key_cell = document.createElement("td");
                key_cell.innerText = config_str_left;
                row.appendChild(key_cell);
                var value_cell = document.createElement("td");
                value_cell.innerText = config_str_right;
                row.appendChild(value_cell);
                var state_cell = document.createElement("td");
                state_cell.innerText = config_state;
                row.appendChild(state_cell);
            }
        }
    }
}

$(function () {

    //tab show事件
    $('a[class="history_tab"]').on('shown.bs.tab', function (e) {
        showProcHist();
    })

    $('a[class="relate_tab"]').on('shown.bs.tab', function (e) {
        showQuote();
        //alert('hello');
    })


    prc_type = $("#proc_type").val();
    if (prc_type == 3) {
        var sql = $("#proc_sql").val();
        sql = sql.replace(new RegExp("\n","gm"), '<br/>');
        sql = sql.replace(new RegExp(" ","gm"), '&nbsp;');
        document.getElementById('proc_template').innerHTML = sql;
    }
    var desc = $("#proc_description").val();
    desc = desc.replace(new RegExp(" ","gm"), '&nbsp;');
    desc = desc.replace(new RegExp("\n","gm"), '<br/>');

    document.getElementById('proc_desc').innerHTML = desc;

    var user_list = $("#user_name_list").val();
    user_list = user_list.replace(new RegExp(",","gm"), ',&nbsp;');
    document.getElementById('user_list').innerHTML = user_list;
    create_config_table();

    $(document).scroll(function(){
        $("#btn_op_list a:lt(5)").each(function(){
            $(this).css('margin-top', (-$(document).scrollTop()).toString()+'px');
        });
        $('#type_name').css('margin-top', (-$(document).scrollTop()).toString()+'px');
        $("#tip").hide();
    });

    //若为odps_sql，需请求包上传命令
    var proc_type = $("#proc_type").val();
    var proc_name = $("#proc_name").val();
    if (proc_type != 3) {
        $.ajax({
            type: 'post',
            url: '/api/pipeline/getUploadCmd/',
            dataType: 'json',
            async: false,
            data: { 'proc_name': proc_name },
            success: function (result) {
                var cmd = result.cmd;
                $("#upload_cmd").html(cmd);
                $('#con').html($('#upload_cmd').html());
            }
        });
    }

    //复制剪切板
    var cli = new ZeroClipboard(document.getElementById("copyBtn"));
    cli.setText($('#upload_cmd').text());
    cli.on("ready", function (readyEvent) {
        cli.on("aftercopy", function (event) {
            new PNotify({
                title: '通知',
                text: '复制成功！',
                addclass: 'custom',
                type: 'success'
            });
        });
    });

    var url = "/pipeline/get_project/";
    $.ajax({
        type:'post' ,
        url:url,
        dataType:'json',
        data:{"tag":0},
        success:function(result){
            project_list = result.project_list;
            var obj = document.getElementById('new_pl_select');
            for(var i=obj.options.length-1;i>=0;i--) {
                obj.options.remove(i);
            }
            var select_option = document.createElement("OPTION");
            obj.options.add(select_option);
            select_option.innerText = '我的默认项目';
            select_option.value = 0;

            for(var i = 0; i < project_list.length; i++) {
                if (project_list[i].is_default == 1) {
                    continue;
                }
                name = project_list[i].name;
                id = project_list[i].id;
                var select_option = document.createElement("OPTION");
                obj.options.add(select_option);
                select_option.innerText = name;
                select_option.value = id;
            }
        }
    });

    var options = "";
    $("#pipeline_select").empty();

	guiders.createGuider({
	attachTo: "#id_create_new_task",
		buttons: [{name: "知道了",onclick:guiders.hideAll}],
		description: "点击我，自动创建依赖这个插件的任务.",
		id: "tip",
		overlay: false,
		position:6,
		autoFocus:false,
        width: 200,
		title: "快速使用"
	}).show();

    $("#id_create_new_task").click(function(){
        $("#tip").hide();
    });

});




