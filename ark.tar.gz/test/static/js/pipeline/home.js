$(function(){
    adjust_align();
});
$(window).on('resize',function(){
    adjust_align();
});
function adjust_align()
{
    $("#div_back_01").height($(document).width()/1920*617);
 //   $("#div_back_02").height($(document).width()/1920*687);
 //   $("#div_back_02 div").each(function(){$(this).css('margin-top', 428*$(document).width()/1920+'px');})
 //   $("#div_back_03").height($(document).width()/1920*605);
}
