var task_list;

//删除连接标记tag
var detach_tag = 0;

//获取该流程的所有任务
function get_tasks(){
    var pipe_id = $("#pipe_id").val();
    $.ajax({
        type:'post',
        url:'/pipeline/getTasks/',
        async: false,
        dataType:"json",
        data:{'pipeline_id':pipe_id},
        success:function(result){
            if(result.status){
                //alert(result.msg);
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            }else{
                task_list = result.task_list;
            }
        }
    });
}

;(function() {
    get_tasks();
    console.log(task_list);
    var pipe_id = $("#pipe_id").val();

    var DIV_ID_CONTAINER = 'pipeline-tasks';
    var TAG_PREFIX = 'w';
    var LAYOUT_ENGINE = 'dot';
    var LAYOUT_ENGINE_SRC = LAYOUT_ENGINE + '-src';
    var formType = 'add';

    //构建task图
    window.AutoLayout = {
        init : function() {
            var tasks = task_list;
            var layoutString = "digraph chargraph {node[shape=box, margin=0, width=2, height=1];";
            for(var i = 0; i < tasks.length; i++) {
                var next_tags = tasks[i].next_task_ids;
                if(null != next_tags && undefined != typeof(next_tags)) {
                    var tag_from = TAG_PREFIX + tasks[i].id;
                    next_tags = next_tags.split(',');
                    for(var j = 0; j < next_tags.length; j++) {
                        if(next_tags[j]) {
                            var tag_to = TAG_PREFIX + next_tags[j];
                            layoutString += " " + tag_from + " -> " + tag_to;
                        }
                    }
                }
            }
            layoutString += "}";
            console.log(layoutString);
            $("#" + LAYOUT_ENGINE_SRC).html(layoutString);
        },
        run : function() {
            w_launch();
        }
    };



    //task 增删改查
    window.PipelineTask = {
        init : function() {
            PipelineTask.initModal();
            PipelineTask.initWindow();
            PipelineTask.initOp();
        },
        initWindow: function() {
            if(0 == $("#user_permission_tag").val()){
                $(".window").on('click', function(e) {
//                    $(this).popover({'title':'任务描述','content':$(this).attr('action-data'),'container':'body'});
                    $("#task_desc_show_modal #task_desc").text($(this).attr('action-data'));
                    $("#task_desc_show_modal").modal('show');
                })
            };
            //双击修改task
            $(".window").on('dblclick', function(e) {
                if(0 == $("#user_permission_tag").val())
                {
                    return;
                }
                //formType = 'update';    
                var url = "/pipeline/updateTask/"+ $(e.target).attr('taskId')+"/";
                $("#modal_iframe iframe").attr('src',url);
                $(".modal_iframe h4").html("修改任务");
                $("#modal_iframe").show();
                $("#modal_iframe").modal('show');

                /*
                $.post("/pipeline/updateTask/"+ $(e.target).attr('taskId')+"/", function(result){
                    console.log(result);
                },"json");*/

                /*
                $.ajaxSetup({async : false}); 
                $("#modal-task-form").modal({
                    remote : "/pipeline/updateTask/" + $(e.target).attr('taskId'),
                    keyboard: false,
                    backdrop: 'static'
                });*/
            });
        },
        initOp: function() {
            //add task
            $('#add-task').on('click', function(e){
                formType = 'create';
                $.ajaxSetup({async : false});  
                $("#modal-task-form").modal({
                    remote : "/pipeline/createTask/" +pipe_id+"/",
                    keyboard: false,
                    backdrop: 'static'
                });
                Task.autoFillTpl("modal-task-form");
            });
            $('#auto-layout').on('click', function(e){
                e.preventDefault();
                w_launch();
            });
        },
        initModal: function() {
            $('body').on('hidden', '.modal', function () {
                $(this).removeData('modal');
            });
            $("#task-form-submit").on('click', function(e){
                e.preventDefault();
                if(!$('#Task_name').val()) {
                    //alert('名称不能为空');
                    $('#messageModal .modal-body p').text('名称不能为空');
                    $('#messageModal').modal('show');

                }else {
                    combineParams();
                    $('#task-form').ajaxSubmit({
                        dataType:'json',
                        type:'POST',
                        beforeSend:function(){
                            if(($("[name='Processor[type]']:checked").val()==2) && !$("[name='Processor[config]']").val()) {
                                alert("sql语句不能为空");
                                return false;
                            }else {
                                return true;
                            }
                        },
                        success:function(result){
                            if(result.status != 0)
                                alert(result.msg);
                            else {
                                var task = result.data;
                                if('create' == formType)
                                    PipelineTasks.addTask(task);
                                else if('update' == formType)
                                    PipelineTasks.updateTask(task);
                                $("#modal-task-form").modal('hide');
                            }
                        },
                        error:function(){alert('请求异常')}
                    });

                }
            });
        },
    };

    //操作，删除、连接、断连接
    window.PipelineTasks = {
        makeWindows : function() {

            var windows = jsPlumb.getSelector(".window");
            jsPlumb.makeSource(windows, {
                filter:".ep",               // only supported by jquery
                anchor:"Continuous",
                connector:[ "StateMachine", { curviness:20 } ],
                connectorStyle:{ strokeStyle:"#5c96bc", lineWidth:2, outlineColor:"transparent", outlineWidth:4 },
            });                     

            // initialise all '.window' elements as connection targets.
            jsPlumb.makeTarget(windows, {
                dropOptions:{ hoverClass:"dragHover", },
                beforeDrop:function(params) { 
                    var conn1 = jsPlumb.select({source:params.sourceId, target:params.targetId});
                    var conn2 = jsPlumb.select({source:params.targetId, target:params.sourceId});
                    return 0 == (conn1.length + conn2.length);
                },
                anchor:"Continuous"             
            });
            
            jsPlumb.draggable(windows);
        },

        init : function() { 
            
            var tasks = task_list;
            jsPlumb.importDefaults({
                Endpoint : ["Dot", {radius:2}],
                HoverPaintStyle : {strokeStyle:"#216477", lineWidth:4,outlineWidth:2,outlineColor:"white",font:"bold 50px Arial" },
                ConnectionOverlays:[
                    [ "Arrow", { 
                        location:1
                    } ],
                    ["Label", {
                        label: (0 == $("#user_permission_tag").val()) ? "" : "X",
                        location: 0.5
                    }]
                ],
                DragOptions : { cursor: "pointer", zIndex:2000, containment:"#pipeline-tasks" }
            });

            var ep_html = (0 == $("#user_permission_tag").val()) ? '' :'<div class="ep"></div>';
            for(var i = 0; i < tasks.length; i++) {
                var tag = TAG_PREFIX + tasks[i].id;
                var pos = 100 * i;
                var desc = tasks[i].description ? tasks[i].description : 'owner没有添加描述！';
                $("#" + DIV_ID_CONTAINER).append("<div id='" + tag + "' taskId=" + tasks[i].id + " class='window' action-data='"+desc+"'>" + tasks[i].name+ ep_html+"</div>");
                var elm = document.getElementById(tag);
                elm.style.left = pos + "px";
            }

            //点击连线，删除连接
            jsPlumb.bind("click", function(c) { 
                if(0 == $("#user_permission_tag").val())
                {
                    return;
                }
                jsPlumb.detach(c,{
                        fireEvent:true,
                        forceDetach: false
                    }); 
            });

            //连接前询问
            jsPlumb.bind("beforeDetach", function(conn) {
                return confirm("删除连接？");
            });

            //连接task
            jsPlumb.doWhileSuspended(function() {
                PipelineTasks.makeWindows();
                for(var i = 0; i < tasks.length; i++) {
                    tag = TAG_PREFIX + tasks[i].id;
                    next_tags = tasks[i].next_task_ids.split(',');
                    for(var j = 0; j < next_tags.length; j++)
                        if(next_tags[j]) {
                            next_tag = TAG_PREFIX + next_tags[j];
                            if($("#" + next_tag).length > 0)
                                jsPlumb.connect({
                                    source:tag,
                                    target:next_tag
                                });
                            else
                                console.log('task不存在 from=' + tasks[i].id + ' to=' + next_tags[j]);
                        }
                } 

                //添加连接
                if(1 == $("#user_permission_tag").val())
                {
                jsPlumb.bind("connection", function(info, originalEvent) {
                    var fromId = info.source.attr('taskId');
                    var toId = info.target.attr('taskId');
                    $.post("/pipeline/linkTask/", { Link: {from: fromId, to: toId} }, function(result){
                        if(result.status){
                            detach_tag = 1;
                            alert('连接失败！');
                            jsPlumb.detach(info,{
                                    fireEvent:false,
                                    forceDetach: true
                                }); 

                            //jsPlumb.detach(info,{fireEvent:false,forceDetach: false});
                        }
                        else{
                            console.log(result);
                        }
                    },"json");
                });
                }

                //删除连接
                jsPlumb.bind("connectionDetached", function(info, originalEvent) {
                    var fromId = info.source.attr('taskId');
                    var toId = info.target.attr('taskId');
                    if(detach_tag == 0){
                        $.post("/pipeline/unlinkTask/", { Link: {from: fromId, to: toId} }, function(result){
                            if(result.status){
                                //alert('删除连接失败！');
                                $('#messageModal .modal-body p').text('删除连接失败');
                                $('#messageModal').modal('show');
                            }
                            else{
                                console.log(result);
                            }
                        },"json");
                    }
                });
            });
        },

        //删除任务
        deleteTask : function(taskId) {
            $.post("/pipeline/deleteTask/"+pipe_id+"/", { Task: {id: taskId} }, function(result){
                if(0 == result.status) {
                    var $window = $("#" + TAG_PREFIX + taskId);
                    jsPlumb.detachAllConnections($window,{fireEvent:false});
                    $window.remove();
                } else {
                    //alert(result.msg);
                    if (result.status == 2) {
                        msg = result.msg.replace(new RegExp("\n",'gm'), '<p></p>');
                        msg = msg.replace(new RegExp("\t",'gm'), '&nbsp;&nbsp;');
                        $('#messageModal .modal-body p').html(msg);
                        $('#messageModal').modal('show');
                    } else {
                        $('#messageModal .modal-body p').text(result.msg);
                        $('#messageModal').modal('show');
                    }
                }
            },"json");
        },

        //添加任务
        addTask : function(task) {
            console.log('addTask');
            $("#" + DIV_ID_CONTAINER).append("<div id='" + TAG_PREFIX + task.id + "' taskId=" + task.id + " class='window' action-data='"+task.description+"'>" + task.name + "<div class='ep'></div></div>");
            var elem = document.getElementById(TAG_PREFIX + task.id);
            PipelineTasks.makeWindows();
            //处理上游
            tag = TAG_PREFIX + task.id;
            prev_tags = task.prev_task_ids.split(',');
            for(var j = 0; j < prev_tags.length; j++)
                if(prev_tags[j]) {
                    prev_tag = TAG_PREFIX + prev_tags[j];
                    if($("#" + prev_tag).length > 0)
                        jsPlumb.connect({
                            source:prev_tag,
                            target:tag
                        });
                    else
                        console.log('task不存在 from=' + prev_tags[j] + ' to=' + task.id);
                }
            PipelineTask.initWindow();
        },

        //修改任务
        updateTask : function(task) {
            console.log('updateTask');
            var $window = $("#" + TAG_PREFIX + task.id);

            //链接处理开始------先删除所有此节点链接，然后依次添加上下游链接
            jsPlumb.detachAllConnections($window,{fireEvent:false});
            tag = TAG_PREFIX + task.id;
            //处理下游
            next_tags = task.next_task_ids.split(',');
            for(var j = 0; j < next_tags.length; j++)
                if(next_tags[j]) {
                    next_tag = TAG_PREFIX + next_tags[j];
                    if($("#" + next_tag).length > 0)
                        jsPlumb.connect({
                            source:tag,
                            target:next_tag
                        });
                    else
                        console.log('task不存在 from=' + task.id + ' to=' + next_tags[j]);
                }
            //处理上游
            prev_tags = task.prev_task_ids.split(',');
            for(var j = 0; j < prev_tags.length; j++)
                if(prev_tags[j]) {
                    prev_tag = TAG_PREFIX + prev_tags[j];
                    if($("#" + prev_tag).length > 0)
                        jsPlumb.connect({
                            source:prev_tag,
                            target:tag
                        });
                    else
                        console.log('task不存在 from=' + prev_tags[j] + ' to=' + task.id);
                }
            //链接处理结束
            $("#" + DIV_ID_CONTAINER + " #" + TAG_PREFIX + task.id).html(task.name + "<div class='ep'></div>");
        }
    };  
})();


//jsPlumb初始化
jsPlumb.bind("ready", function() {
    document.onselectstart = function () { return false; };
    PipelineTasks.init();
    AutoLayout.init();
    AutoLayout.run();
    PipelineTask.init();
});

function skip_copy_pipeline() {    
    var pl_id = $("#pipeline_select").val();
    location.href = '/pipeline/task/'+pl_id+'/';
}

//申请ajax
function apply_copy_task() {
    $("#copy_busy_icon").show()
    $("#copy_task_hid").hide()
    $("#copy_task_sure").hide()
    
    var task_id = $("#task_id").val();
    var pl_id = $("#pipeline_select").val();
    var src_pl_id = $("#pipe_id").val();
    var url = "/pipeline/copy_task/";
    $.ajax({
        type:'post',
        url:url,
        data:{'task_id':task_id, 'dest_pl_id': pl_id},
        success:function(result){
            $("#copy_busy_icon").hide()
            if(result.status){
                alert("复制任务失败！" + result.msg);
                $("#copy_task_hid").show();
                $("#copy_task_sure").show();
                $("#copy_task_hint").hide();
                $("#button_to_other").hide();
                $("#copy_task_div").hide();
            }
            else{
                if (src_pl_id == pl_id) {
                    task = result.data;
                    PipelineTasks.addTask(task);
                    $("#copy_task_hid").show();
                    $("#copy_task_sure").show();
                    $("#copy_task_hint").hide();
                    $("#button_to_other").hide();
                    $("#copy_task_div").hide();
                } else {
                    $("#copy_task_hint").show();
                    $('#copy_task_hint').text('拷贝任务成功！');

                    $("#button_to_other").show();
                    $("#delete-task").hide();
                }
            }
        }
    });
}

$(function(){
    var $contextMenu = $("#contextMenu");
    var $taskSelected;

    $("body").on("contextmenu", ".window", function (e) {
        $taskSelected = $(this);
        $contextMenu.css({
            display: "block",
            left: e.pageX,
            top: e.pageY
        });
        return false;
    });
    $contextMenu.on("click", "a", function (e) {
        e.preventDefault();
        $contextMenu.hide();
        if('delete-task' == $(this).attr("op") && confirm("删除该task?")) {
            var taskId = $taskSelected.attr('taskId');
            PipelineTasks.deleteTask(taskId);
        }

        if('copy-task' == $(this).attr("op")) {
            var taskId = $taskSelected.attr('taskId');
                
            var pl_id = $("#pipe_id").val();
            var url = "/pipeline/copy_task/";
            $.ajax({
                type:'post',
                url:url,
                data:{'task_id':taskId, 'dest_pl_id': pl_id},
                success:function(result){
                    if(result.status){
                        alert("复制流程失败！原因:" + result.msg);
                    }
                    else{
                        task = result.data;
                        PipelineTasks.addTask(task);
                    }
                }
            });
        }

        if('copy-task-other' == $(this).attr("op")) {
            $("#copy_task_hid").show();
            $("#copy_task_sure").show();
            $("#copy_task_hint").hide();
            $("#button_to_other").hide();
            $("#copy_task_div").hide();

            $("#copy_task_div").show();
            var taskId = $taskSelected.attr('taskId');
            //获取应用列表
            $("#task_id").val(taskId);
            $("#copy_task_div").modal({
                backdrop:false,
                show:true,        
            });
    
        }

        if('show-next-tasks' == $(this).attr("op")) {
            var taskId = $taskSelected.attr('taskId');
            //获取应用列表
            $.ajax({
                type : "post",
                url  : '/pipeline/get_task_next_tasks/',
                async: false,
                dataType:"json",
                data:{"task_id":taskId},
                success : function(result) {
                    if(result.status){
                        console.log(result.msg);
                    }else{
                        sc_name_row_str = '<table class="items table id="preview_table" table-bordered" style="margin-top:10px;border:1px solid rgb(219, 219, 219);table-layout:fixed;word-break:break-all; word-wrap:break-all;" cellspacing="1" cellpadding="2" border="1">'
                        sc_name_row_str += '<tbody id="_table">'

                        head_row = "<tr>";
                        head_row += '<td style="width:200px;"><font style="font-weight:bold;">流程名</font></td>';
                        head_row += '<td style="width:200px;"><font style="font-weight:bold;">任务名</font></td>';
                        head_row += '<td style="width:200px;"><font style="font-weight:bold;">用户名</font></td>';
                        head_row += "</tr>";
                        sc_name_row_str += head_row;
                        for (var sc_name_idx = 0; sc_name_idx < result.tasks.length; ++sc_name_idx) {
                            item_str = "<tr>";
                            item_str += '<td style="width:200px;">' + result.tasks[sc_name_idx].pl_name + '</td>';
                            item_str += '<td style="width:200px;">' + result.tasks[sc_name_idx].task_name + '</td>';
                            item_str += '<td style="width:200px;">' + result.tasks[sc_name_idx].owner_name + '</td>';
                            item_str += "</tr>";
                            sc_name_row_str += item_str;
                        }
                        sc_name_row_str += '</tbody>'
                        sc_name_row_str += '</table>'
                        $('#messageModal .modal-body p').html(sc_name_row_str);
                        $('#messageModal').modal('show');
                    }
                }
            });    
        }

    });

    $(document).click(function () {
        $contextMenu.hide();
    });

    var options = "";
    $("#pipeline_select").empty();

    $.ajax({
        type : "post",
        url  : '/pipeline/getPipelines/',
        async: false,
        dataType:"json",
        data:{"task_id":1},
        success : function(result) {
            if(result.status){
                console.log(result.msg);
            }else{
                data_list = result.pipeline_list;
                var data_str = '';
                for(i = 0;i<data_list.length;i++){
                    data_str += "<option value='"+data_list[i].id+"' >"+
                    data_list[i].name+"</option>";
                }
                //select2初始化选第一个
                //$(".select2-chosen").html(data_list[0].name);
                $("#s2id_pipeline_select span.select2-chosen").html(data_list[0].name);
                $("#pipeline_select").append(data_str);
            }
        }
    });

});
