function createProcessor(){
    var url = "/processor/create/";
    window.location.href = url;
}

var choose_value = 0;
function ok_value(){
    choose_value = 1;
}

//删除数据
function deleteProc(id) {
    choose_value = 0;
    var url = "/processor/delete/" + id + "/";
    $('#quit_ok_modal').unbind('hide.bs.modal');
    $("#modal_content").html('确定要删除这条数据吗?');
    $("#quit_ok_modal").modal('show');
    //添加modal事件
    $("#quit_ok_modal").on('hide.bs.modal',function(e){
        if(choose_value == 1){
            $.ajax({
                type:'post',
                url : url,
                success : function(result) {
                    if(result.status){
                        $('#messageModal .modal-body p').text(result.msg);
                        $('#messageModal').modal('show');
                    }else{
                        location.reload();
                    }
                }
            });
        }
    });
}


//生成dataTable
$(function(){
    $(document).scroll(function(){
        if($(document).scrollTop() > 100)
        {
            $("#nav-left-sidebar").css('top', '63px');
        }
        else
        {
            $("#nav-left-sidebar").css('top', '123px');
        }
    });

    $('#example thead th').each( function (i) {
        //alert($(this).attr('id'));
        if($(this).attr("id") == "type"){
            $(this).html('<select class="form-control" style="width:100%">'+
                '<option value="">全部</option><option value="1">'+
                'script</option><option value="2">job</option>'+
                '<option value="3">odps_sql</option>'+
                '<option value="4">odps_mr</option>'+
                '<option value="5">odps_xlib</option>'+
                '<option value="6">odps_spark</option>'+
                '<select>');
        }
        if($(this).attr("id") == "name"){
            $(this).html( '<input class="form-control" style="width:100%"'+
                ' type="text" placeholder="Search 插件名称" />' );
        }
        if($(this).attr("id") == "perm"){
            $(this).html('<select class="form-control" style="width:100%">'+
                '<option value="0" selected>全部</option>'+
                '<option value="1">私有</option>'+
                '<option value="2">开放</option>'+
                '<option value="3">公共</option><select>');
        }
        if($(this).attr("id") == "tag"){
            $(this).html( '<input class="form-control" style="width:100%"'+
                ' type="text" placeholder="Search 标签" />' );
        }
        if($(this).attr("id") == "desc"){
            $(this).html( '<input class="form-control" style="width:100%"'+
                ' type="text" placeholder="Search 描述" />' );
        }
    });
    
    var table = $('#example').DataTable({
        "lengthChange": false,
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "/processor/list/",
            "type": "POST",
        },
        "language":{
            "sLengthMenu": "显示 _MENU_ 条记录",
            "sInfo": "显示第 _START_ 至 _END_ 条记录，共 _TOTAL_ 条",
            "sInfoEmpty": "显示第 0 至 0 条记录，共 0 条",
        },
        "columns": [
            {},
            { "data": "type" ,"bSortable": false},
            { "data": "name" ,"bSortable": false},
            { "data": "description" ,"bSortable": false },
            { "data": "tag" ,"bSortable": false },
            { "data": "quote_num" ,"bSortable": false },
            { "data": "update_time","searchable":false,"bSortable": false }
        ],
        "columnDefs": [
            {
                "targets":[0],
                 "searchable": false,
                "bSortable": false,
                "render":function(data,type,full){
                    return full.no;
                }
                
            },
            //自定义操作列
            {
                "targets": [7],
                "searchable": false,
                "bSortable": false,
                "data": "id",
                "render": function(data,type,full) {
                    if(full.private == '公共'){   //公共
                        return "<a title='查看' rel='tooltip' href='/processor/" +
                            data+"/'><font class='oper-Font'>查看</font></a>";
                    }
                    else{
                        return "<a class='eyeColor' title='数据更新'"+
                                " rel='tooltip' href='/processor/update/" + data +
                                "/'><font class='oper-Font'>修改</font>"+
                                "</a>&nbsp;&nbsp;<a class='delete' title='删除'"+
                                " rel='tooltip' href='javascript:void(0)'"+
                                " onclick='deleteProc(" +data+ 
                                ")' data-original-title='删除'>"+
                                "<font class='oper-Font'>删除</font></a>";
                    }
                }
            },
        ],
    });

    var index_of_type = 1;
    var index_of_name = 2;
    //var index_of_private = 4;
    var index_of_tag = 4;
    var index_of_desc = 3;
   
    function search_event(colIdx){
        return function(){
            table
                .column( colIdx )
                .search( this.value )
                .draw();
            this.index=$(this).val();
        }
    }

    $("#perm").on( 'change', search_event(5));

    table.columns().eq( 0 ).each( function ( colIdx ) {
        if(colIdx ==1){
            $( 'select', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
        }
        if(colIdx == 2||colIdx==3||colIdx==4){
            $( 'input', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
             $( 'input', table.column( colIdx ).header()).on('keydown',function(event){
                var event=event||window.event;
                if(event.keyCode==13||event.which==13){
                    if($(this).val()==this.index){
                            $( 'input', table.column( colIdx ).header()).trigger('change');
                    }
                }
            });
        }
      /*  if(colIdx == index_of_private){
            $( 'select', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
            //加载完后自动change
            //$( 'select', table.column( colIdx ).header() ).change();
        }
        if(colIdx == index_of_tag){
            $( 'input', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
        }
        if(colIdx == index_of_desc){
            $( 'input', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
        }*/
    });

    $("#example_filter").hide();
//    $("perm").on( 'change', search_event(9));
})



function status_change(obj, status_id)
{
    $(obj).removeClass();
    $(obj).addClass("private-choosed");
    $(obj).siblings().removeClass();
    $(obj).siblings().addClass("private-unchoosed");
    $("#perm").val(status_id);
    $("#perm").trigger("change");    
}
