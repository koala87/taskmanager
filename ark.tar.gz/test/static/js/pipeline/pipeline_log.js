var pathtotal = "";

function readLog(filename,istail) {
    if(istail == 0){
        var url = '/pipeline/getlogContent/';
    }
    else{
        var url = '/pipeline/gettail/';
    }

    $.ajax({
        url: url,
        type: 'post',
        data: { 'schedule_id': $('#schedule_p').val(), 'file_name': pathtotal + filename },
        success: function (result) {
            if (istail == 0) {
                $("#tail_btn").empty();
                if (result.status) {
                    $('.filecontent').text("获取失败");
                }
                else {
                    if (result.file_content) {
                        $("#tail_btn").html('<button class="btn" aria-hidden="true" onclick=readLog("' + filename + '",1)>tail</button>');
                        $('.filecontent').text(result.file_content);
                    }
                    else {
                        $('.filecontent').text("该文件为空");
                    }
                }
            }
            else {
                if (result.res) {
                    $('.filecontent').text(result.res);
                }
                else {
                    $('.filecontent').text('该文件为空');
                }
            }
        }
    });
}

function downloadFile(url) {
    try {
        var elemIF = document.createElement("iframe");
        elemIF.src = url;
        elemIF.style.display = "none";
        document.body.appendChild(elemIF);
    } catch (e) {

    }
}

function downloadLog(filename){
    window.open('/pipeline/download/' + $('#schedule_p').val() + '&' + pathtotal + filename + '/');
}



  function getlogcontent(schedule_id,subpath,that){ 
    pathtotal=subpath;
    $('#nulldocument').css({
       'display':'none'
    });
    $('.nulldocument').remove(); 
     $(that).nextAll().remove();
      $('#navultrance a').remove();
           $('#navulstdout a').remove();
             $('#navulconf a').remove();
         $('#navulpy a').remove();
          $('#navulother a').remove();
           $('#navuldir a').remove();
        
    
    $('.filecontent').text(''); 
    var boolv="";
    var filecontent;
    var contentdown;
    var path=subpath;
    path=path.substr(0,path.length-1);
    console.log(path);
   // var schedule_id=parseInt($('#schedule_p').val());
         $.post('/pipeline/gettasklog/',{
        schedule_id:schedule_id,
        subpath:path
         },function(data){
        if(data.status!=0){
            $('#messageview .modal-body h5').text(data.info);
           $('#messageview').modal('show');
            $('#spanmessage').html('加载失败!');
             $('#navultrance li').remove();
           $('#navulstdout li').remove();
             $('#navulconf li').remove();
         $('#navulpy li').remove();
          $('#navulother li').remove();
           $('#navuldir li').remove();
        }else if(data.status==0){
            //$('<li>'+$('#pl_name').val()+'</li>').insertAfter($('.breadcrumb li:eq(0)'));
            //清空
            $('#navultrance').empty();
            $('#navulstdout').empty();
            $('#navulconf').empty();
            $('#navulpy').empty();
            $('#navulother').empty();
            $('#navuldir').empty();

            $('#spanmessage').remove();
            var logarr=data.list;
          /*  for(var i=0;i<list.length;i++){
              $('#navul').append('<li class="hoverli" role="presentation"><button style="background-color:#01579b"  type="button" class="log_button btn-block btn  dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">'+list[i]+'<span class="caret"></span></button><ul class="dropdown-menu"><li class="frontlast"><a href="#">从前往后看</a></li><li class="lastfront"><a href="#">从后往前看</a></li><li class="downlog"><a href="#">下载文件</a></li></ul></li>');
            
            }*/
            var tranceArr=[];
            var stdoutArr=[];
            var confArr=[];
            var pyArr=[];
            var other=[];
            var dirArr=[];
            for(var i=0;i<logarr.length;i++){
                if(logarr[i]=="trace.log"){
                   tranceArr.push(logarr[i]);        
                 }
                else if(logarr[i].indexOf('.log')>=0){
                    stdoutArr.push(logarr[i]);
                }
                else if(logarr[i].indexOf('.conf')>=0||logarr[i].indexOf('.tpl')>=0){
                    confArr.push(logarr[i]);
                 }
                else if(logarr[i].indexOf('.py')>=0||logarr[i].indexOf('.tar.gz')>=0){
                    pyArr.push(logarr[i]);
                }else if(logarr[i].charAt(logarr[i].length-1)=="/"){
                    dirArr.push(logarr[i]);
               }else if(logarr[i]!=""){
                    other.push(logarr[i]);
               }
            }
            console.log(other.length); 
            if(tranceArr.length==0){
                $('#navultrance li').remove();
                $('#navultrance').css('margin-right','0px');
            }else{
                $('#navultrance').css('margin-right','40px');
                $('#navultrance').append('<li class="firstli">平台日志:</li>');   
              }
             if(stdoutArr.length==0){
                $('#navulstdout li').remove();
                $('#navulstdout').css('margin-right','0px');
            }else{
                $('#navulstdout').css('margin-right','40px');
                 $('#navulstdout').append('<li class="firstli">任务日志:</li>');

            }
             if(confArr.length==0){
               $('#navulconf li').remove();
                $('#navulconf').css('margin-right','0px');
            }else{
                $('#navulconf').css('margin-right','40px');
                   $('#navulconf').append('<li class="firstli">配置文件:</li>');
            }
             if(pyArr.length==0){
                $('#navulpy li').remove();
                $('#navulpy').css('margin-right','0px');
            }else{
                $('#navulpy').css('margin-right','40px');
             $('#navulpy').append('<li class="firstli">执行文件:</li>');

            }
             if(other.length==0){
                $('#navulother li').remove();
                $('#navulother').css('margin-right','0px');
            }else{
                $('#navulother').css('margin-right','40px');
                 $('#navulother').append('<li class="firstli">其他文件:</li>');

            }
            if(dirArr.length==0){
                $('#navuldir li').remove();
                $('#navuldir').css('margin-right','0px');
            }else{
                $('#navuldir').css('margin-right','40px');
                 $('#navuldir').append('<li class="firstli">子目录:</li>');
            }
            if(tranceArr.length==0&&stdoutArr.length==0&&confArr.length==0&&pyArr.length==0&&other.length==0&&dirArr.length==0){
                $('#nulldocument').css({
                    'display':'block'
                });
            }
            for(var i=0;i<tranceArr.length;i++){
                 //$('#navultrance').append('<li class="hoverli" role="presentation"><button style="overflow:hidden;background-color:#f0fff0;color:black;width:100px;height:40px"  type="button" class="log_button btn-block btn  dropdown-toggle" data-toggle="dropdown" title="'+tranceArr[i]+'" aria-haspopup="true" aria-expanded="false">'+tranceArr[i]+'<span class="caret"></span></button><ul class="dropdown-menu"><li class="frontlast"><a href="#">从前往后看</a></li><li class="lastfront"><a href="#">从后往前看</a></li><li class="downlog"><a href="#">下载文件</a></li></ul></li>');
                 $("#navultrance").append("&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void(0)' onclick=readLog('" + tranceArr[i] + "',0)>" + tranceArr[i] + "</a>");
                 $("#navultrance").append("&nbsp;<a href='javascript:void(0)' title='下载' class='icon-download' onclick=downloadLog('" + tranceArr[i] + "')/>");
            }
            for(var i=0;i<stdoutArr.length;i++){
                //$('#navulstdout').append('<li class="hoverli" role="presentation"><button style="overflow:hidden;background-color:#f0fff0;color:black;width:100px;height:40px"  type="button" class="log_button btn-block btn  dropdown-toggle" data-toggle="dropdown" title="'+stdoutArr[i]+'" aria-haspopup="true" aria-expanded="false">'+stdoutArr[i]+'<span class="caret"></span></button><ul class="dropdown-menu"><li class="frontlast"><a href="#">从前往后看</a></li><li class="lastfront"><a href="#">从后往前看</a></li><li class="downlog"><a href="#">下载文件</a></li></ul></li>');
                 $("#navulstdout").append("&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void(0)' onclick=readLog('" + stdoutArr[i] + "',0)>" + stdoutArr[i] + "</a>");
                 $("#navulstdout").append("&nbsp;<a href='javascript:void(0)' title='下载' class='icon-download' onclick=downloadLog('" + stdoutArr[i] + "')/>");
            }
            for(var i=0;i<confArr.length;i++){
                 // $('#navulconf').append('<li class="hoverli" role="presentation"><button style="overflow:hidden;background-color:#f0fff0;color:black;width:100px;height:40px" type="button" class="log_button btn-block btn  dropdown-toggle" data-toggle="dropdown" title="'+confArr[i]+'" aria-haspopup="true" aria-expanded="false">'+confArr[i]+'<span class="caret"></span></button><ul class="dropdown-menu"><li class="frontlast"><a href="#">从前往后看</a></li><li class="lastfront"><a href="#">从后往前看</a></li><li class="downlog"><a href="#">下载文件</a></li></ul></li>');
                 $("#navulconf").append("&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void(0)' onclick=readLog('" + confArr[i] + "',0)>" + confArr[i] + "</a>");
                 $("#navulconf").append("&nbsp;<a href='javascript:void(0)' title='下载' class='icon-download' onclick=downloadLog('" + confArr[i] + "')/>");
            }
            for(var i=0;i<pyArr.length;i++){
                //$('#navulpy').append('<li class="hoverli" role="presentation"><button style="overflow:hidden;background-color:#f0fff0;color:black;width:100px;height:40px"  type="button" class="log_button btn-block btn  dropdown-toggle" data-toggle="dropdown" title="'+pyArr[i]+'" aria-haspopup="true" aria-expanded="false">'+pyArr[i]+'<span class="caret"></span></button><ul class="dropdown-menu"><li class="frontlast"><a href="#">从前往后看</a></li><li class="lastfront"><a href="#">从后往前看</a></li><li class="downlog"><a href="#">下载文件</a></li></ul></li>');
                 $("#navulpy").append("&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void(0)' onclick=readLog('" + pyArr[i] + "',0)>" + pyArr[i] + "</a>");
                 $("#navulpy").append("&nbsp;<a href='javascript:void(0)' title='下载' class='icon-download' onclick=downloadLog('" + pyArr[i] + "')/>");
            }
            for(var i=0;i<other.length;i++){
                  //$('#navulother').append('<li class="hoverli" role="presentation"><button style="overflow:hidden;background-color:#f0fff0;color:black;width:100px;height:40px"  type="button" class="log_button btn-block btn  dropdown-toggle" data-toggle="dropdown" title="'+other[i]+'" aria-haspopup="true" aria-expanded="false">'+other[i]+'<span class="caret"></span></button><ul class="dropdown-menu"><li class="frontlast"><a href="#">从前往后看</a></li><li class="lastfront"><a href="#">从后往前看</a></li><li class="downlog"><a href="#">下载文件</a></li></ul></li>');
                 $("#navulother").append("&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void(0)' onclick=readLog('" + other[i] + "',0)>" + other[i] + "</a>");
                 $("#navulother").append("&nbsp;<a href='javascript:void(0)' title='下载' class='icon-download' onclick=downloadLog('" + other[i] + "')/>");
            }
            for(var i=0;i<dirArr.length;i++){
                  var dir="'"+dirArr[i]+"'";
                    console.log(dir);
                 //$('#navuldir').append('<li class="hoverli" onclick="addhref('+dir+','+schedule_id+')" role="presentation" dir="'+dirArr[i]+'" ><button style="background-color:#f0fff0;color:black;width:100px;height:40px;overflow:hidden"  type="button" class="log_button btn-block btn  dropdown-toggle" data-toggle="dropdown" title="'+dirArr[i]+'" aria-haspopup="true" aria-expanded="false">'+dirArr[i]+'</button>');
		          $("#navuldir").append("&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:void(0)' onclick=addhref("+dir+","+schedule_id+")>" + dirArr[i] + "</a>");
            }
                  $('.frontlast').each(function(){
                     $(this).click(function(){
                         $('.filecontent').text("");
                   var file_name=$(this).parent().parent().find('button').text();
                    console.log(subpath);
                   $.post('/pipeline/getlogContent/',{
                       schedule_id:schedule_id,
                      file_name:subpath+file_name
                     },function(data){
                       if(data.status==0){
                            if(data.file_content){
                                $('.filecontent').text(data.file_content);
                            }else{
                                 $('.filecontent').text("该文件为空");
                            }
                            filecontent=data.file_content;
                        }else if(data.status==1){
                         $('.filecontent').text(data.info);
                        }
                },'json');
                });
                }); 
                  $('.lastfront').each(function(){
                        $(this).click(function(){
                        $('filecontent').text("");
             
                      var tailfile=$(this).parent().parent().find('button').text();
                         $.post('/pipeline/gettail/',{
                      schedule_id:schedule_id,
                      file_name:subpath+tailfile
                     },function(data){
                        if(data.res){
                              $('.filecontent').text(data.res);
                        }
                    },'json');
                    });
                    });
                  $('.downlog').each(function(){
                   $(this).click(function(){
                    var file_name=$(this).parent().parent().find('button').text();
                   $.post('/pipeline/getlogContent/',{
                       schedule_id:schedule_id,
                      file_name:subpath+file_name
                     },function(data){
                       if(data.status==0){
                            if(data.file_content){
                                contentdown=data.file_content;             
                            }else{
                                contentdown="文件为空";
                            }
                             var content=contentdown;
                             var aLink = document.createElement('a');
                             var blob = new Blob([content]);
                             var evt = document.createEvent("HTMLEvents");
                             evt.initEvent("click", false, false);
                             aLink.download = file_name;
                             aLink.href = URL.createObjectURL(blob);
                             aLink.dispatchEvent(evt);
                        }else{
                         //       alert('二进制文件不能下载');
                                      $('#messageview .modal-body h5').text('二进制文件不能下载');
                                      $('#messageview').modal('show');

                            }                  
                },'json');
        });
        });
    }
    },'json');
}
function addhref(hrefdir,schedule_id){
    var href=hrefdir;
    var href="'"+href+"'";
    var total="";
    $('.breadcrumb li:gt(2)').each(function(){
        total+=$(this).find('a').text()+'/';
    });
    total=total+hrefdir;
    var treeview=total;
    total="'"+total+"'";

    var deleteg=hrefdir;
    deleteg=deleteg.substr(0,deleteg.length-1);
    $('.breadcrumb').append('<li onclick="getlogcontent('+schedule_id+','+total+',this)"><a style="cursor:pointer">'+deleteg+'</a></li>');
    
    $("#navultrance").empty();
    $("#navulstdout").empty();
    $("#navulconf").empty();
    $("#navulpy").empty();
    $("#navulother").empty();
    $("#navuldir").empty();

    getlogcontent(schedule_id,treeview);
}

$(function () {
//     var status = "执行成功";
//     var status_val = $('#status').val();
//     if (status_val == 0) {
//         status = "等待中";
//     } else if (status_val == 1) {
//         status = "正在执行";
//     } else if (status_val == 2) {
//         status = "执行成功";
//     } else if (status_val == 3) {
//         status = "执行失败";
//     } else if (status_val == 5) {
//         status = "等待调度";
//     } else if (status_val == 6) {
//         status = "用户停止";
//     }   
//     $("<li>" + $('#run_time').val() + '</li>').insertBefore($('.breadcrumb li:eq(1)'));
//     $("<li>" + status + '</li>').insertBefore($('.breadcrumb li:eq(1)'));
    $("<li><a href='/pipeline/task/" + $('#pl_id').val() + "/'>" + $('#task_name').val() + '</li>').insertBefore($('.breadcrumb li:eq(0)'));
    $("<li><a href='/pipeline/task/" + $('#pl_id').val() + "/'>" + $('#pl_name').val() + '</li>').insertBefore($('.breadcrumb li:eq(0)'));
    var schedule_id = parseInt($('#schedule_p').val());
    getlogcontent(schedule_id, '', document.getElementById('readdocument'));

    $('#readdocument').on('click', function () {
        getlogcontent(schedule_id, '', document.getElementById('readdocument'));
    });
});

