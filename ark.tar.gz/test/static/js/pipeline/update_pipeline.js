var choosevalue=0;
function hrefindex(){
    choosevalue=1;
}

//修改数据Ajax
function updatePipeAjax(id){
    $("#update_busy_icon").show();
    $("#update_pipeline_btn").attr('disabled',"true");
    var url = "/pipeline/update/" + id + "/";
    var param = $("#update_pipeline_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : param,
        success : function(result) {
            if(result.status){
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            }else{
                choosevalue=0;
                $('#copyModal').unbind('hide.bs.modal');
                $('#copyModal .modal-body p').text('修改成功');
                $('#copyModal').modal('show');
                $('#copyModal').on('hide.bs.modal',function(){
                    if(choosevalue==1){
                        location.href = "/pipeline/task/"+id+"/";
                    }
                });
            }
            $("#update_busy_icon").hide();
            $("#update_pipeline_btn").removeAttr('disabled');
        }
    });
}

//修改数据
function updatePipe(id) {
   var project_group = ''
    $("#project_id").find("input[type='text']").each(function(j){
        if(j == 0){
            if($(this).val() != ''){
                project_group = $("#select_project_list").val();
            }
        }    
    })
    $("#id_project_id").val(project_group);

    updatePipeAjax(id); 
}

function get_project_list(){
    var options = "";
    $.ajax({
            type : "post",
            url  : '/pipeline/getProjectList/',
            async: false,
            dataType:"json",
            success : function(result) {
                var default_project_id_flag = 0;
                if(result.status){
                    console.log(result.msg);
                }else{
                    project_list = result.project_list;
                    options = '<option value="0">我的默认项目</option>';
                    if(project_list != ''){
                        for(i = 0;i<project_list.length;i++){
                            if(project_list[i]['id'] == $("#project_id_hidden_manual").val())
                            {
                                default_project_id_flag = 1;
                            }
                            options += "<option value='"+project_list[i]['id']+"' >"+
                            project_list[i]['name']+"</option>";
                        }
                    }
                    $("#select_project_list").append(options);
                }
                default_project_id_flag ? '' : ($("#project_id_hidden_manual").val(0));
            }
        });
}


$(function(){
    //获取应用分组
    get_project_list()
    var project_group = $("#project_id_hidden_manual") .val();
//    $("#id_project_id").val(project_group);
    $("#select_project_list").val(project_group);

    //可输入selector
  //  $('.combobox').combobox();
      //by xiaolin
    $('select.combobox').combobox();
    var text=$('input.combobox').val();
    $('input.combobox').on('blur',function(){
        if($(this).val()==""){
        $('input.combobox').val(text);
        }
    });

    $("#id_principal").val($("#principal").val());

    $("#principal").change(function(){
        $("#id_principal").val($("#principal").val());
    });
    
    $("#id_send_sms").change(function(){
        if($(this).is(':checked')){
            var url = '/pipeline/check_sms_phone/';
            $.ajax({
                type:"post",
                url:url,
                success:function(result){
                    if(result.status){
                        alert("未配置手机号！");
                        $("#id_send_sms").prop("checked",false);
                    }
                    else{
                    }
                }
            });
        }
    });

    var dateTextBox = $("#id_life_cycle");
    dateTextBox.datetimepicker({
        format:'Ymd',
        timepicker:false,
        onShow:function( ct ){
            this.setOptions({
                //maxDate:'+1970/01/31'
                minDate:'0'
            })
        },
    });

});





