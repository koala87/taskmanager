//添加任务
function addTask(pipe_id){
    var url = "/pipeline/createTask/"+pipe_id+"/";
    $("#modal_iframe iframe").attr('src',url);
    $(".modal_iframe h4").html("添加任务");
    $("#modal_iframe").show();
    $("#modal_iframe").modal('show');
    //window.location.href = url;
}



//组成任务checkbox区
function create_task_check(task_list){
    var tasks = '';
    var i = 0;
    var count = 2;

    for(i = 1;i<=task_list.length;){
        /*
        tasks += '<label>';
        tasks += '<input type="checkbox" value="'+id+'" name="task_check"/>' +
            name+'</label>';
        i++;
        */
        name = task_list[i-1].name;
        id = task_list[i-1].id;

        if(i % count == 1){
            tasks += '<tr>';
        }

        tasks += '<td title="'+name+'"><input type="checkbox" value="'+id
            +'" name="task_check"/>'+name
            +'&nbsp;&nbsp;&nbsp;&nbsp;</td>'
        if(i % count == 0){
            tasks += '</td></tr>';
        }
        else{
            tasks += '</td>';
        }
        i++;

    }
    return tasks;
}

//执行任务
function execTask(pipe_id){
    $("#execute_task").modal({
        backdrop:false,
        show:true,        
    });
    var url = "/pipeline/getTasks/";
    $.ajax({
        type:'post' ,
        url:url,
        dataType:'json',
        data:{"pipeline_id":pipe_id},
        success:function(result){
            task_list = result.task_list;
            console.log(task_list);
            tasks = create_task_check(task_list);
            $("#tasks_checkbox").html(tasks);
            $("#check_all_task").attr("checked",false);
        }
    });
}

function run_all_task(run_time) {
    $("#run_task_busy").show()
    var task_id_list = '';
    $("input[name='task_check']:checked").each(function(){
        task_id_list += $(this).val() + ',';
    });

    //一个都不选就是选全部
    if(task_id_list == ''){
        $("input[name='task_check']").each(function(){
            task_id_list += $(this).val() + ',';
        });
    }

    ordered_num = $('#ordered_num').val();
    if (ordered_num > 10) {
        $('#messageModal .modal-body p').text('串行并发数不能超过10!');
        $('#messageModal').modal('show');
        $("#run_task_busy").hide()
        return ;
    }
    task_id_list = task_id_list.substr(0,task_id_list.length-1);
    var url = "/pipeline/runTasks/";
    $.ajax({
        type:'post',
        url:url,
        dataType:'json',
        data:{"task_id_list":task_id_list,"run_time":run_time, "ordered_num": ordered_num},
        success:function(result){
            $("#run_task_busy").hide()
            if(result.status){
                $('#messageModal .modal-body p').html(result.msg);
                $('#messageModal').modal('show');
            }
            else{
                $('#run_task_model .modal-body p').text('执行成功');
                $('#run_task_model').modal('show');
                $("#execute_task").modal("hide");
                choose_runhis_value = 0
                $('#run_task_model').on('hide.bs.modal',function(){
                    if (choose_runhis_value==1) {
                        var pl_id = $("#pipe_id").val();
                        window.location.href = "/pipeline/history/" + pl_id + "/";
                    }
                });
            }
        }
    });
}

function str_to_date(str) {
    var year = str.substring(0, 4);
    var month = str.substring(4, 6);
    var day = str.substring(6, 8);
    var hour = 0;
    var minute = 0;
    var second = 0;
    var date = new Date(year, month, day, hour, minute, second);
    return date;
}

//run任务
function runTask(){
    var run_time = $("#run_time").val();
    if(!run_time){
        $('#messageModal .modal-body p').text('请填写执行时间!');
        $('#messageModal').modal('show');
        return;
    }

    if (run_time.indexOf("-") < 0) {
        run_all_task(run_time);
        return ;
    }

    var array = run_time.split("-");
    var begin_len = array[0].length;
    var end_len = array[1].length;
    if (begin_len != end_len) {
        $('#messageModal .modal-body p').text('执行时间填写错误，开始时间长度不等于结束时间长度!');
        $('#messageModal').modal('show');
        return;
    }

    if (begin_len != 8 && begin_len != 10 && begin_len != 12) {
        $('#messageModal .modal-body p').text('执行时间填写错误，时间长度必须是8，10，12!');
        $('#messageModal').modal('show');
        return;
    }
    var begin_time = array[0].substring(0, 9);
    var begin_date = str_to_date(begin_time).getTime();
    var end_time = array[1].substring(0, 9);
    var end_date = str_to_date(end_time).getTime();
    var days = parseInt(Math.abs(end_date - begin_date ) / 1000 / 60 / 60 /24)
    if (days >= 3) {
        choosevalue=0;
        $('#modalcheck').unbind('hide.bs.modal');
        $('#modalcheck .modal-body h5').text('执行时间跨度超过了 ' + days + ' 天，确定执行这么多任务吗?');
        $('.changevalue').text('确定');
        $('#modalcheck').modal('show');
        $('#modalcheck').on('hide.bs.modal',function(){
            if (choosevalue==1) {
                run_all_task(run_time);
            }
        });
    } else {
        run_all_task(run_time);
    }
}

function pn_notice(pl_id) {                
    window.open('/pipeline/task/'+pl_id+'/');
    location.href = '/pipeline/task/'+pl_id+'/';
}

//申请ajax
function apply_copy_pipeline() {
    var pl_id = $("#pipe_id").val();
    var pl_name = $("#copy_pl_name").val()

    var project_id = $('#copy_pl_select option:selected').val();
    var url = "/pipeline/copy_pipeline/";
    text = '复制流程成功！';
    $.ajax({
        type:'post',
        url:url,
        data:{'pl_id':pl_id,'pl_name':pl_name, 'project_id': project_id},
        success:function(result){
            if(result.status){
                alert("复制流程失败！原因:" + result.msg);
            }
            else{
                new PNotify({
                    title: '通知消息',
                    text: '创建成功，即将为你跳转到新流程......',
                    addclass: 'custom',
                    type: 'success'
                });
                setTimeout("pn_notice(" + result.pl_id + ")", 1500);
            }
        }
    });
}

function copy_pipeline(pipe_id, pipe_name) {
    $("#copy_pipeline_div").modal({
        backdrop:false,
        show:true,        
    });
}

$(function(){
    $(document).scroll(function(){
        $("#btn_op_list a:lt(5)").each(function(){
            $(this).css('margin-top', (-$(document).scrollTop()).toString()+'px');
        });
    });
    $('.changevalue').on('click',function(){
        choosevalue=1;
        $('#modalcheck').modal('hide');
    });

    $('.changevalue_runhis').on('click',function(){
        choose_runhis_value=1;
        $('#run_task_model').modal('hide');
    });

    $("#check_all_task").click(function() {
        $("input[name='task_check']").prop("checked",this.checked);
    });

    //复制剪切板
    //var cli = new ZeroClipboard(parent.document.getElementById("copyBtn"));
    var cli = new ZeroClipboard($("#copyBtn", window.parent.document));
    cli.setText($('#upload_cmd', window.frames[0].document).text());
    cli.on( "ready", function( readyEvent ) {
        cli.on( "aftercopy", function( event ) {
            new PNotify({
                title: '通知',
                text: '复制成功！',
                addclass: 'custom',
                type: 'success'
            });
        });
    });
        
    var url = "/pipeline/get_project/";
    $.ajax({
        type:'post' ,
        url:url,
        dataType:'json',
        data:{"tag":0},
        success:function(result){
            project_list = result.project_list;
            var obj = document.getElementById('copy_pl_select');
            for(var i=obj.options.length-1;i>=0;i--) {
                obj.options.remove(i);
            }
            var select_option = document.createElement("OPTION");
            obj.options.add(select_option);
            select_option.innerText = '我的默认项目';
            select_option.value = 0;

            for(var i = 0; i < project_list.length; i++) {
                if (project_list[i].is_default == 1) {
                    continue;
                }
                name = project_list[i].name;
                id = project_list[i].id;
                var select_option = document.createElement("OPTION");
                obj.options.add(select_option);
                select_option.innerText = name;
                select_option.value = id;
            }
        }
    });
    /*
    var url = "/pipeline/getPipelines/";
    $.ajax({
        type:'post' ,
        url:url,
        dataType:'json',
        data:{"task_id":1},
        success:function(result){
            pipeline_list = result.pipeline_list;
            var obj = document.getElementById('id_app_group');
            for(var i=obj.options.length-1;i>=0;i--) {
                obj.options.remove(i);
            }

            for(var i = 0; i < pipeline_list.length; i++) {
                name = project_list[i].name;
                id = project_list[i].id;
                var select_option = document.createElement("OPTION");
                obj.options.add(select_option);
                select_option.innerText = name;
                select_option.value = id;
            }
        }
    });
    */
});
var choose_value = 0;
var choose_runhis_value = 0;
function ok_value(){
    choose_value = 1;
}
function changeStatus(pipe_id,on_line,is_super){
    choosevalue = 0;
    var url = "/pipeline/on_line/";
    if(on_line){
        confirm_str = "确定要上线该流程吗?";
        if(is_super == 1){
            text = '上线成功！';
        }
        else{
            text = '申请上线成功！';
        }
    }
    else{
        confirm_str = "确定要下线该流程吗?";
        text = '下线成功！';
        if (is_super == 1) {
            reject_pipe_online(pipe_id);
            return;
        }
    }


    $('#online_modal').unbind('hide.bs.modal');
    $("#modal_content").html(confirm_str);
    $("#online_modal").modal('show');
    //添加modal事件
    $("#online_modal").on('hide.bs.modal',function(e){
        if(choose_value == 1){
            $.ajax({
                type:'post',
                url:url,
                data:{'pipe_id':pipe_id,'on_line':on_line},
                success:function(result){
                    if(result.status){
                        alert(result.msg);
                    }
                    else{
                        alert(text);
                        location.reload();
                    }
                }
            });
        }
    })
}
function reject_pipe_online(id){
    desc = '<div style="width:430px;">&nbsp;<font color="red">*</font>'+
            '拒绝上线原因:</div><br/>' + 
            '<div style="width:430px;"><textarea rows="4"'+
            ' cols="65" id="propose_reason"' +
            'style="width:400px;" placeholder="'+
            '请说明拒绝上线的原因，如调度时间错误等信息将会邮件给用户！">'+
            '</textarea></div>';

    var d = dialog({
        title : '申请权限拒绝上线',
        content : desc,
        okValue: '确定',
        ok: function () {
            var reason = $("#propose_reason").val();
            if(reason==''){
                alert('请输入拒绝流程上线原因!'); 
                return false;
            }
            apply_reject_pipe_online(id, reason);
        },
        cancelValue: '取消',
        cancel: true
    });
    d.showModal();
}

//申请ajax
function apply_reject_pipe_online(id, reason) {
    var url = "/pipeline/on_line/";
    text = '下线成功！';
    $.ajax({
        type:'post',
        url:url,
        data:{'pipe_id':id,'on_line':0,'reason':reason},
        success:function(result){
            if(result.status){
                alert(result.msg);
            }
            else{
                new PNotify({
                    title: '拒绝流程上线通知！',
                    text: text,
                    addclass: 'custom',
                    type: 'success'
                });
                //change_status_str(id, 0, 1);
                location.reload();
            }
        }
    });
}
function switch_show_pipeline_detail(obj)
{
    $(obj).removeClass();
    if($(".table_pipeline_detail").css('display') == 'none')
    {
        $(".table_pipeline_detail").show();
        $(obj).addClass("glyphicon glyphicon-menu-up");
    }
    else
    {
        $(".table_pipeline_detail").hide();
        $(obj).addClass("glyphicon glyphicon-menu-down");
    }
}
