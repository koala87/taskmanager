function create_project()
{
    var post_data = {'project_name':$("#createProjectModal #inputProjectName").val().trim(),'description':$("#createProjectModal #inputProjectDesc").val().trim()};
    $.post('/console/add_new_project/', post_data, function(result){
        if(result.status == 0)
        {
            $("#createProjectModal").hide();
            new PNotify({
               title: '通知',
               text: '新建项目成功',
               type: 'success',
               hide: true,
               closer: true,
               addclass: 'custom'
            });
            setTimeout(function(){location.reload()}, 2000);
        }
        else
        {
            new PNotify({
               title: '通知',
               text: result.msg,
               type: 'error',
               hide: false,
               closer: true,
               addclass: 'custom'
            });;
        }
    },'json');
}

function edit_project(project_id, project_name, project_desc)
{
    $("#editProjectModal #inputProjectName").val(project_name);
    $("#editProjectModal #inputProjectDesc").val(project_desc);
    $("#editProjectModal #btn_save_project").unbind('click');
    $("#editProjectModal #btn_save_project").on('click',function(){do_edit_project(project_id);});
    $("#editProjectModal").modal('show');
}
function do_edit_project(project_id)
{
    var post_data = {'project_id':project_id, 'project_name':$("#editProjectModal #inputProjectName").val().trim(),'description':$("#editProjectModal #inputProjectDesc").val().trim()};
    $.post('/console/update_project/', post_data, function(result){
        if(result.status == 0)
        {
            $("#editProjectModal").hide();
            new PNotify({
               title: '通知',
               text: '修改项目成功',
               type: 'success',
               hide: true,
               closer: true,
               addclass: 'custom'
            });
            setTimeout(function(){location.reload()}, 2000);
        }
        else
        {
            new PNotify({
               title: '通知',
               text: result.msg,
               type: 'error',
               hide: false,
               closer: true,
               addclass: 'custom'
            });;
        }
    },'json');
}
function delete_project(project_id)
{
    $("#deleteProjectModal #btn_delete_project").unbind('click');
    $("#deleteProjectModal #btn_delete_project").on('click', function(){do_delete_project(project_id)});
    $("#deleteProjectModal").modal('show');
}
function do_delete_project(project_id)
{
    var post_data = {'project_id':project_id};
    $.post('/console/delete_project/', post_data, function(result){
        if(result.status == 0)
        {
            $("#deleteProjectModal").hide();
            new PNotify({
               title: '通知',
               text: '删除项目成功',
               type: 'success',
               hide: true,
               closer: true,
               addclass: 'custom'
            });
            setTimeout(function(){location.reload()}, 2000);
        }
        else
        {
            new PNotify({
               title: '通知',
               text: result.msg,
               type: 'error',
               hide: false,
               closer: true,
               addclass: 'custom'
            });;
        }
    },'json');
}
function editProjectMember(project_id, writer_list)
{
    $("#editMemberProjectModal #btn_edit_menber_project").unbind('click');
    $("#editMemberProjectModal #btn_edit_menber_project").on('click', function(){do_edit_menber_project(project_id)});
    var authed_user_arr = writer_list.split(',');
    $("#memberList").text('');
    var reportTo = "";
    var url = "/pipeline/getUserList/";
    $.ajax({
        type : "post",
        url  : url,
        async: false,
        dataType:"json",
        success : function(result) {
            if(result.status){
                return false;
            }else{
                users = result.user_list;
                for(i = 0;i<users.length;i++){
                    var selected_str = (authed_user_arr.indexOf(users[i].id.toString()) >= 0) ? ' selected ' : '';
                    reportTo += "<option value='"+users[i].id+"' "+selected_str+">"+
                    users[i].name+"</option>";
                }
            }
            $("#memberList").append(reportTo);
        }
    });
    initSelect2();
//    $("#memberList").val([8]);
    $("#editMemberProjectModal").modal('show');
}
function do_edit_menber_project(project_id)
{
    var post_data = {'project_id':project_id, 'writer_list':$('#memberList').val().join()};
    $.post('/console/update_project/', post_data, function(result){
        if(result.status == 0)
        {
            $("#addMemberProjectModal").hide();
            new PNotify({
               title: '通知',
               text: '修改成员成功',
               type: 'success',
               hide: true,
               closer: true,
               addclass: 'custom'
            });
            setTimeout(function(){location.reload()}, 2000);
        }
        else
        {
            new PNotify({
               title: '通知',
               text: result.msg,
               type: 'error',
               hide: false,
               closer: true,
               addclass: 'custom'
            });;
        }
    },'json');
}
function initSelect2()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function() {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function() {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function(a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function(a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return + Globalize.parseDate(a)
                }
                return a
            },
            _format: function(a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function() {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}
function show_member_list(member_list_str, project_name)
{
    if(member_list_str == '')
    {
        member_list_arr = [];
    }
    else
    {
        member_list_arr = member_list_str.split(',');
    }
    var url = "/pipeline/getUserList/";
    $.ajax({
        type : "post",
        url  : url,
        async: false,
        dataType:"json",
        success : function(result) {
            var member_name_arr = [];
            if(result.status){
               new PNotify({
                  title: '通知',
                  text: "获取项目成员信息失败",
                  type: 'error',
                  hide: false,
                  closer: true,
                  addclass: 'custom'
              });
              return false;
            }else{
                users = result.user_list;
                for(i = 0;i<users.length;i++){
                    if(member_list_arr.indexOf(users[i].id.toString()) >= 0)
                    {
                        member_name_arr.push(users[i].name);
                    }
                }
                $("#member_name_list .modal-body").text('');
                for( var j=0;j<member_name_arr.length;j++){
                    $("#member_name_list .modal-body").append('<span class="span_member_name">'+member_name_arr[j]+'</span>');
                }
                if(member_name_arr.length < 1)
                {
                    $("#member_name_list .modal-body").append('<p>暂无成员</p>');
                }
                $("#member_name_list .modal-title").text(project_name+"成员");
                $("#member_name_list").modal('show');
            }
        }
    });
}
