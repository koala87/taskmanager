//创建数据Ajax
var choosevalue=0;
var max_date='';
function hrefindex(){
    choosevalue=1;
}
function createPipeAjax(){
    $("#create_busy_icon").show();
    $("#create_pipeline_btn").attr('disabled',"true");
    var url = "/pipeline/create/";
    var param = $("#create_pipeline_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : param,
        success : function(result) {
            if(result.status){
                $('#messageModal .modal-body p').text(result.msg);
                $('#messageModal').modal('show');
            }else{
                choosevalue=0;
                $('#copyModal').unbind('hide.bs.modal');
                $('#copyModal .modal-body p').text('创建成功!');
                $('#copyModal').modal('show');
                $('#copyModal').on('hide.bs.modal',function(){
                    if(choosevalue == 1){
                        window.open('/pipeline/task/'+result.pipeline_id+'/');
                        location.href = "/pipeline/index/";
                    }
                });
                
            }
            $("#create_busy_icon").hide();
            $("#create_pipeline_btn").removeAttr('disabled');
        }
    });
}

function get_project_list(){
    var options = "";
    $.ajax({
            type : "post",
            url  : '/pipeline/getProjectList/',
            async: false,
            dataType:"json",
            success : function(result) {
                if(result.status){
                    console.log(result.msg);
                }else{
                    project_list = result.project_list;
                    options = '<option value="0">我的默认项目</option>';
                    if(project_list != ''){
                        for(i = 0;i<project_list.length;i++){
                            options += "<option value='"+project_list[i]['id']+"' >"+
                            project_list[i]['name']+"</option>";
                        }
                    }
                    $("#select_project_list").append(options);
                }
            }
        });
}


$(function(){
    //by xiaolin
     var curDate = new Date(); 
     var d = new Date(curDate.getTime() + 24*7*60*60*1000); 
  //  var d=new Date();
    var year=d.getFullYear();
    var month=d.getMonth()+1;
    var year_max =curDate.getFullYear;
    var month_max =curDate.getMonth()+1+6;
    if(month_max>12)
    {
        year_max = year + 1;
        month_max = month_max%12;
        if(month_max<10){month_max = "0"+month_max;}
    }
    max_date = year_max.toString()+ month_max.toString() +curDate.getDate();
    if(month<10){
     month="0"+month;   
    }else{
    month=month.toString();
    }
    var day=d.getDate();
    if(day<10){
        day="0"+day;
    }
    var fullDate=year.toString()+month+day.toString();

    //
    $('#id_life_cycle').val(fullDate);
    //获取应用分组
    get_project_list()
    //可输入selector
    //by xiaolin
    $('select.combobox').combobox();
    $('input.combobox').val('');
    var text=$('select.combobox option:selected').text();
    $('input.combobox').on('blur',function(){
        if($(this).val()==""){
        $('input.combobox').val(text);
        }
    });
    //
    $("#create_pipeline_btn").click(function(){
        //by xiaolin
      /* 
         var d=new Date();
         var year=parseInt(d.getFullYear());
         var month=parseInt(d.getMonth()+1);
         if(month<10){
             month=parseInt("0"+month);
         }else{
             month=parseInt(month.toString());
        }
        var day=parseInt(d.getDate());
        
        var maxdate=$('#id_life_cycle').val();
        var maxyear=parseInt(maxdate[0]+maxdate[1]+maxdate[2]+maxdate[3]);
        var maxmonth=parseInt(maxdate[4]+maxdate[5]);
        var maxday=parseInt(maxdate[6]+maxdate[7]);
        if(maxyear==year){
            if(maxmonth-month==6&&maxday>day){
                //modal
            }else if(maxmonth-month>6){
                //modal
            }else{
                add_group();
            }
        }else if(maxyear>year){
           maxmonth=maxmonth+12
           if(maxmonth-month==6&&maxday>day){
                //modal
           }else if(maxmonth-month>6){
                //modal
            }else{
               add_group();
            }
        }
        */
        //
        
        //所属项目
        
        var project_group = ''
        $("#project_id").find("input[type='text']").each(function(j){
            if(j == 0){
                if($(this).val() != ''){
                    project_group = $("#select_project_list").val();
                }
            }    
        })
        $("#id_project_id").val(project_group);
//        $("#id_project_group").val($("#select_project_list").val());
        createPipeAjax(); 
    });

    $("#principal").change(function(){
        $("#id_principal").val($("#principal").val());
    });
    
    
    $("#id_send_sms").change(function(){
        if($(this).is(':checked')){
            var url = '/pipeline/check_sms_phone/';
            $.ajax({
                type:"post",
                url:url,
                success:function(result){
                    if(result.status){
                        alert("未配置手机号！");
                        $("#id_send_sms").prop("checked",false);
                    }
                }
            });
        }
    });

    var dateTextBox = $("#id_life_cycle");
    dateTextBox.datetimepicker({
        format:'Ymd',
        timepicker:false,
        onShow:function( ct ){
            this.setOptions({
                //maxDate:'+1970/01/31'
                minDate:'0'
            })
        },
    });
    
    $('#id_life_cycle').change(function(){
        if($('#id_life_cycle').val() > max_date)
        {
            $('.xdsoft_datetimepicker').hide();
            $('#id_life_cycle').val(max_date);
            $('#messageModal .modal-body p').text("有效期最多至六个月");
            $('#messageModal').modal('show');
        }
    });
});













