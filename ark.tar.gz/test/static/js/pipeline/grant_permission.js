//获取用户列表_new
function getGrantUserList()
{
    var reportTo = "";
    var url = "/pipeline/getUserList/";
    if(permission_count == 1){
        $.ajax({
            type : "post",
            url  : url,
            async: false,
            dataType:"json",
            data : {'dataId' : $("#dataId").val()},
            success : function(result) {
                if(result.status){
                    alert(result.msg);
                    location.reload();
                }else{
                    users = result.user_list;
                    for(i = 0;i<users.length;i++){
                        reportTo += "<option value='"+users[i].id+"' >"+
                        users[i].name+"</option>";
                    }
                }
            }
        });
        $("#user_select").append(reportTo);
    }
    permission_count++;
}

//获取用户列表
function showGrantForm()
{
    $("#permission_form").modal("show");
    var reportTo = "";
    var url = "/pipeline/getUserList/";
    if(permission_count == 1){
        $.ajax({
            type : "post",
            url  : url,
            async: false,
            dataType:"json",
            data : {'dataId' : $("#dataId").val()},
            success : function(result) {
                if(result.status){
                    alert(result.msg);
                    location.reload();
                }else{
                    users = result.user_list;
                    for(i = 0;i<users.length;i++){
                        reportTo += "<option value='"+users[i].id+"' >"+
                        users[i].name+"</option>";
                    }
                }
            }
        });
        $("#user_select").append(reportTo);
    }
    permission_count++;
}

//授予权限
function grantPermission() {
    var grantTo = $("#user_select").val();
    var dataId = $("#dataId").val();
    if(grantTo == null) {
        alert("请选择要授予权限的用户！");
    }else {
        $("#grant_ok").attr('disabled',"true");
        $("#grant_cancel").attr('disabled',"true");
        $("#grant_busy").show();
        var grantTo = grantTo + ",";
        $.ajax({
            url : "/pipeline/grantPermission/",
            type : 'post',
            data : {'userIds' : grantTo, 'dataId' : dataId},
            success : function(result) {
                if(result.status){
                    new PNotify({
                        title: '授予权限通知',
                        text: result.msg,
                        addclass: 'custom',
                        type: 'error'
                    });
                }else{
                    //location.reload();
                    location.href = "/pipeline/permission/"+dataId+"/";
                }
                $("#grant_busy").hide();
                $("#grant_ok").removeAttr('disabled');
                $("#grant_cancel").removeAttr('disabled');
            }
        });
    }
}

//收回权限
function revokePerm(dataId,userId){
    $("#revoke_"+userId).removeAttr("onclick");
    $("#revoke_busy_"+userId).show();

    $.ajax({
        type : 'post',
        url : "/pipeline/revokePermission/",
        data : {'dataId' : dataId,'userId' : userId},
        dataType : 'json',
        success : function(result) {
            if(result.status){
                new PNotify({
                    title: '收回权限通知',
                    text: result.msg,
                    addclass: 'custom',
                    type: 'error'
                });
            }else{
                //location.reload();
                location.href = "/pipeline/permission/"+dataId+"/";
            }
            $("#revoke_busy_"+userId).hide();
            $("#revoke_"+userId).attr("onclick","cancelPermissionConfirm("+
                dataId+","+userId+");");
        }
    });
}


function generalConfirm(dataId,userId, title, contents, funcObj)
{
    $("#myGeneralTitle").html(title);
    $("#myGeneralBody").html(contents);
    $("#idGeneralConfirm").on('click', function(){funcObj(dataId,userId, title, contents)});
    $("#permissionGeneralModal").modal("show");
}

//允许权限
function acceptResource(hist_id,pipe_id, title, contents, funcObj) {
        $("#accept_"+hist_id).removeAttr("onclick");
        $("#deny_"+hist_id).removeAttr("onclick");
        $("#accept_busy_"+hist_id).show();
        var applicant_id = $("#applicant_id").val();

        $.ajax({
            type : 'post',
            url : '/pipeline/acceptResource/',
            data : {'id' : pipe_id,'applicant_id':applicant_id},
            dataType : 'json',
            success : function(result) {
                if(result.status){
                    new PNotify({
                        title: '通过权限通知',
                        text: result.msg,
                        addclass: 'custom',
                        type: 'error'
                    });
                }else{
                    location.href = "/pipeline/permission/"+pipe_id+"/";
                }
                $("#accept_busy_"+hist_id).hide();
                $("#accept_"+hist_id).on('click', function(){generalConfirm(dataId,userId, title, contents, funcObj)});
                $("#deny_"+hist_id).on('click', function(){generalConfirm(dataId,userId, title, contents, 'denyPerm')});
            }
        });
}


function denyResource(pipe_id,reason) {
    var url = '/pipeline/denyResource/';
    var applicant_id = $("#applicant_id").val();
    $.ajax({
        type : 'post',
        url : url,
        data : { 'id' : pipe_id,'reason':reason,'applicant_id':applicant_id },
        dataType : 'json',
        success : function(result) {
            if(result.status){
                new PNotify({
                    title: '拒绝权限通知',
                    text: result.msg,
                    addclass: 'custom',
                    type: 'error'
                });
            }else{
                location.href = "/pipeline/permission/"+pipe_id+"/";
                //location.reload();
            }
        }
    });
}

//拒绝申请
function denyPerm(pipe_id) {
    desc = '<div style="width:430px;">&nbsp;&nbsp;'+
            '拒绝权限申请，请填写以下信息：</div>'+
            '<div style="width:430px;">&nbsp;'+
            '<font color="red">*</font>拒绝原因:</div><br/>' + 
            '<div style="width:430px;"><textarea rows="4"'+
            ' cols="65" id="deny_reason" style="width:400px;"'+
            ' placeholder="请说明拒绝此申请的原因！">'+
            '</textarea></div>';
    var d = dialog({
        title : '拒绝权限申请',
        content : desc,
        okValue: '确定',
        ok: function () {
            var reason = $("#deny_reason").val();
            if(reason==''){
                alert('请输入拒绝申请原因!'); 
                return false;
            }
            denyResource(pipe_id,reason);
        },
        cancelValue: '取消',
        cancel: true
    });
    d.showModal();

}

//申请ajax
function applyResource(id,reason) {
    var url = "/pipeline/applyPerm/" + id + "/";
    $.ajax({
        type :'post',
        url : url,
        data: { 'reason': reason },
        success : function(result) {
            if(result.status){
                alert(result.msg);
                //location.href = "/update/";
            }else{
                new PNotify({
                    title: '申请权限通知',
                    text: result.msg,
                    addclass: 'custom',
                    type: 'success'
                });
                //location.reload();
            }
        }
    })
}


//申请权限
function applyPerm(id){
    desc = '<div style="width:430px;">&nbsp;&nbsp;'+
            '申请数据的使用权限，请填写以下信息：</div>'+
            '<div style="width:430px;">&nbsp;<font color="red">*</font>'+
            '申请原因:</div><br/>' + 
            '<div style="width:430px;"><textarea rows="4"'+
            ' cols="65" id="propose_reason"' +
            'style="width:400px;" placeholder="'+
            '请说明申请此数据的原因，如用途等信息！">'+
            '</textarea></div>';

    var d = dialog({
        title : '申请权限',
        content : desc,
        okValue: '确定',
        ok: function () {
            var reason = $("#propose_reason").val();
            if(reason==''){
                alert('请输入申请数据原因!'); 
                return false;
            }
            applyResource(id,reason);
        },
        cancelValue: '取消',
        cancel: true
    });
    d.showModal();
}


function cancelPermissionConfirm(dataId,userId)
{
    $("#idCancelPermConfirm").on('click', function(){revokePerm(dataId,userId)});
    $("#permissionGrantCancelModal").modal("show");
}

$(function() {
    permission_count = 1;
    
    $(".apply_reason").each(function(){
        reason = $(this).text();
        if(reason.length>15){
            reason = reason.substr(0,15)+"...";
        }
        $(this).html(reason);
    });
    getGrantUserList();

});
