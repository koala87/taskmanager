function createPipe(){
    var url = "/pipeline/create/";
    window.location.href = url;
}


var choose_value = 0;
function ok_value(){
    choose_value = 1;
}

//删除数据
function deletePipe(id) {
    choose_value = 0;
    var url = "/pipeline/delete/" + id + "/";
    $('#online_modal').unbind('hide.bs.modal');
    $("#modal_content").html('确定要删除这条数据吗?');
    $("#online_modal").modal('show');
    //添加modal事件
    $("#online_modal").on('hide.bs.modal',function(e){
        if(choose_value == 1){
            $.ajax({
                type:'post',
                url : url,
                success : function(result) {
                    if(result.status != 0){
                        if (result.status == 2) {
                            msg = result.msg.replace(new RegExp("\n",'gm'), '<p></p>');
                            msg = msg.replace(new RegExp("\t",'gm'), '&nbsp;&nbsp;');
                            $('#messageModal .modal-body p').html(msg);
                            $('#messageModal').modal('show');
                        } else {
                            $('#messageModal .modal-body p').html(result.msg);
                            $('#messageModal').modal('show');
                        }
                    }else{
                        //alert("删除成功！");
                        location.reload();
                    }
                }
            })
        }
    })
}

//获取已选择的权限
function getPermName(){
    var str = $("input[name='perm_name']");
    perm_num = str.length;
    var perm_arr=[];
    for(var i = 0;i<perm_num;i++){
        if(str[i].checked == true){
            perm_arr.push(str[i].value);
        }
    }
    return perm_arr;
}


//申请ajax
function applyResource(id,reason,obj) {
    var url = "/pipeline/applyPerm/" + id + "/";
    $.ajax({
        type :'post',
        url : url,
        data: { 'reason': reason },
        success : function(result) {
            if(result.status){
                alert(result.msg);
                //location.href = "/update/";
            }else{
                new PNotify({
                    title: '申请权限通知',
                    text: result.msg,
                    addclass: 'custom',
                    type: 'success'
                });
                //$(obj).children(".oper-Font").text('申请中');
                $(obj).parent().html("申请中");
                //alert($(obj).html());
                //location.reload();
            }
        }
    });
}


//申请权限
function applyPerm(id,obj){
    desc = '<div style="width:430px;">&nbsp;&nbsp;'+
            '申请流程的权限，请填写以下信息：</div>'+
            '<div style="width:430px;">&nbsp;<font color="red">*</font>'+
            '申请原因:</div><br/>' + 
            '<div style="width:430px;"><textarea rows="4"'+
            ' cols="65" id="propose_reason"' +
            'style="width:400px;" placeholder="'+
            '请说明申请此流程的原因，如用途等信息！">'+
            '</textarea></div>';
    var d = dialog({
        title : '申请权限',
        content : desc,
        okValue: '确定',
        ok: function () {
            var reason = $("#propose_reason").val();
            if(reason==''){
                alert('请输入申请数据原因!'); 
                return false;
            }
            applyResource(id,reason,obj);
        },
        cancelValue: '取消',
        cancel: true
    });
    d.showModal();
}



//局部改变流程状态
function change_status_str(pipe_id,on_line,is_super){
    var dom = $("#status_"+pipe_id);
    if(on_line == 1){
        if(is_super == 1){
            html_text = "<a title='点击下线' style='margin-left:14px'"+
                " onclick='changeStatus("+pipe_id+",0,1)'"+
                " href='javascript:void(0)' id='status_"+pipe_id+"'>"+
                "<img style='width: 60px; height: 26px;' src=\"/static/images/online_2.png\"></img></a>";
        }
        else{
            html_text = '申请中';
        }
    }
    else{
        html_text = "<a title='点击上线' style='margin-left:14px'"+
            " onclick='changeStatus("+pipe_id+",1,"+is_super+")'"+
            " href='javascript:void(0)' id='status_"+pipe_id+"'>"+
            "<img style='width: 60px; height: 26px;' src=\"/static/images/offline_2.png\"></img></a>";
    } 
    dom.parent().html(html_text);
}

//流程上下线
function changeStatus(pipe_id,on_line,is_super){
    choose_value = 0;
    var url = "/pipeline/on_line/";
    if(on_line){
        confirm_str = "确定要上线该流程吗?";
        if(is_super == 1){
            text = '上线成功！';
        }
        else{
            text = '申请上线成功！';
        }
    }
    else{
        confirm_str = "确定要下线该流程吗?";
        text = '下线成功！';
        if (is_super == 1) {
            reject_pipe_online(pipe_id);
            return;
        }
    }

    $('#online_modal').unbind('hide.bs.modal');
    $("#modal_content").html(confirm_str);
    $("#online_modal").modal('show');
    //添加modal事件
    $("#online_modal").on('hide.bs.modal',function(e){
        if(choose_value == 1){
            $.ajax({
                type:'post',
                url:url,
                data:{'pipe_id':pipe_id,'on_line':on_line},
                success:function(result){
                    if(result.status){
                        alert(result.msg);
                    }
                    else{
                        new PNotify({
                            title: '流程上下线通知',
                            text: text,
                            addclass: 'custom',
                            type: 'success'
                        });
                        change_status_str(pipe_id,on_line,is_super);
                    }
                }
            });
        }
    })
}

//申请ajax
function apply_reject_pipe_online(id, reason) {
    var url = "/pipeline/on_line/";
    text = '下线成功！';
    $.ajax({
        type:'post',
        url:url,
        data:{'pipe_id':id,'on_line':0,'reason':reason},
        success:function(result){
            if(result.status){
                alert(result.msg);
            }
            else{
                new PNotify({
                    title: '拒绝流程上线通知！',
                    text: text,
                    addclass: 'custom',
                    type: 'success'
                });
                change_status_str(id, 0, 1);
            }
        }
    });
}

//申请权限
function reject_pipe_online(id){
    desc = '<div style="width:430px;">&nbsp;<font color="red">*</font>'+
            '拒绝上线原因:</div><br/>' + 
            '<div style="width:430px;"><textarea rows="4"'+
            ' cols="65" id="propose_reason"' +
            'style="width:400px;" placeholder="'+
            '请说明拒绝上线的原因，如调度时间错误等信息将会邮件给用户！">'+
            '</textarea></div>';

    var d = dialog({
        title : '申请权限拒绝上线',
        content : desc,
        okValue: '确定',
        ok: function () {
            var reason = $("#propose_reason").val();
            if(reason==''){
                alert('请输入拒绝流程上线原因!'); 
                return false;
            }
            apply_reject_pipe_online(id, reason);
        },
        cancelValue: '取消',
        cancel: true
    });
    d.showModal();
}


//生成dataTable
$(function(){
    $(document).scroll(function(){
        $("#create_pipe_btn").parent().css('margin-top', (10-$(document).scrollTop()).toString()+'px');
        if($(document).scrollTop() > 100)
        {
            $("#nav-left-sidebar").css('top', '63px');
        }
        else
        {
            $("#nav-left-sidebar").css('top', '122px');
        }
    });
    //是否为管理员
    var is_super = $("#is_super").val();

    $('#example thead th').each( function (i) {
        //alert($(this).attr('id'));
        if($(this).attr("id") == "name"){
            $(this).html( '<input class="form-control" style="width:100%"'+
                ' type="text" placeholder="Search 流程名称" />' );
        }
        if($(this).attr("id") == "tag"){
        //获取应用列表
        var options = "";
        $(this).html( '<select id="id_app_group" class="form-control combobox" style="width:34px"></select>' );
        $.ajax({
            type : "post",
            url  : '/pipeline/getProjectList/?auth=2',
            async: false,
            dataType:"json",
            success : function(result) {
                if(result.status){
                    console.log(result.msg);
                }else{
                    project_list = result.project_list;
                    options = '';
                    options += '<option value="-3">全部流程</option>';
                    options += '<option value="-2">我的流程</option>';
                    options += '<option value="-1">默认分组</option>';
                    if(project_list != ''){
                        for(i = 0;i<project_list.length;i++){
                            if (project_list[i]['is_default'] == 1) {
                                continue;
                            }

                            options += "<option value='"+project_list[i]['id']+"' >"+
                            project_list[i]['name']+"</option>";
                        }
                    }
                    $("#id_app_group").append(options);
                }
            }
        });
//            $(this).html( '<input class="form-control" style="width:100%"'+
//                ' type="text" placeholder="Search 应用分组" />' );
//            $(this).html( '<select class="form-control combobox" style="width:34px" placeholder="Search 应用分组" ><option>应用分组</option></select>' );
            $('.combobox').combobox();
            $('.panel .combobox-container .input-group input[type=text]').css('width', '114px');
            $('.panel .combobox-container .input-group input[type=text]').css('margin-top', '0px');
            $('.panel .combobox-container .input-group input[type=text]').css('height', '30px');

            //下拉框样式
         //   $('.panel .dropdown-menu').css('cssText', 'left:2px!important');
         //   $('.panel .dropdown-menu').css('min-width', '131px');
        }
        if($(this).attr("id") == "perm"){
            if(is_super == 1){
                $(this).html('<select class="form-control" style="width:100%">'+
                    '<option value="0">全部</option>'+
                    '<option value="1">自己</option>'+
                    '<option value="2">有权限</option>'+
                    '<option value="3">无权限</option><select>');
            }
            else{
                $(this).html('<select class="form-control" style="width:100%">'+
                    '<option value="0" selected>全部</option>'+
                    '<option value="1">自己</option>'+
                    '<option value="2">有权限</option>'+
                    '<option value="3">无权限</option><select>');
            }
        }
        if($(this).attr("id") == "status"){
            $(this).html('<select class="form-control" style="width:100%">'+
                '<option value="">全部</option><option value="1">'+
                '已上线</option><option value="0">未上线</option>'+
                '<option value="2">申请中</option><select>');
        }
    });
    
    var table = $('#example').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "/pipeline/list/",
            "type": "POST",
        },
        "columns": [
            { "data": "no" ,"bSortable": false},
            { "data": "name" ,"bSortable": false},
            { "data": "project_name" ,"bSortable": false},
            { "data": "username" ,"bSortable": false },
            { "data": "enable" ,"bSortable": false ,'style':'text-align: center'},
            { "data": "ct_time" ,"bSortable": false}
        ],
        "columnDefs": [
            //自定义操作列
            {
                "targets": [6],
                "searchable": false,
                "bSortable": false,
                "data": "id",
                "render": function(data,type,full) {
                    if(full.permission == 2){   //读写权限
                        return "<a class='eyeColor' title='查询执行历史'"+
                                " rel='tooltip' href='/pipeline/history/" + data +
                                "/'><font class='oper-Font'>执行历史</font>"+
                                "</a>&nbsp;&nbsp;&nbsp;&nbsp;<a class='add'"+
                                " title='查看任务' rel='tooltip'"+
                                " href='/pipeline/task/" +data+ 
                                "/'><font class='oper-Font'>"+
                                "查看任务</font></a>&nbsp;&nbsp;&nbsp;&nbsp;"+
                                "<a class='delete' title='删除'"+
                                " rel='tooltip' href='javascript:void(0)'"+
                                " onclick='deletePipe(" +data+ 
                                ")' data-original-title='删除'>"+
                                "<font class='oper-Font'>删除</font></a>";
                    }
                    else if(full.permission == 1){   //只读
                        return "<a title='查看任务' rel='tooltip' href='/pipeline/task/" +
                            data+"/'><font class='oper-Font'>查看任务</font></a>";
                    }
                    else if(full.permission == 3){   //申请中
                        return "<font class='apply_font'>权限申请中</font>";
                    }
                    else{   //无权限
                        return "<a class='add' title='查看任务' rel='tooltip'"+
                                " href='/pipeline/task/" +data+"/'><font class='oper-Font'>查看任务</font></a>";
                    }
                }
            },
        ],
    });

    var index_of_name =1 ;
    var index_of_tag = 2;
    var index_of_perm = 3;
    var index_of_status =4;
   
    function search_event(colIdx){
        if($('ul.dropdown-menu').eq(1).css('display') != 'none')
        {
            return;
        }
        return function(){
            if (this.value == '[All]')
            {
                return;
                //this.value='';
            }

            table
                .column( colIdx )
                .search( this.value )
                .draw();
                this.index=$(this).val();
        }
    }

    table.columns().eq( 0 ).each( function ( colIdx ) {
        if(colIdx == index_of_name){
            $( 'input', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
            $('input',table.column(colIdx).header()).on('keydown',function(event){
                var event=event||window.event;
                if(event.keyCode==13||event.which==13){
                    if($(this).val()==this.index){
                            $( 'input', table.column( colIdx ).header()).trigger('change');
                    }
                }
            });
        }
        if(colIdx == index_of_tag){
            //$( '.combobox-container input[type=hidden]',table.column(colIdx).header()).on( 'change', search_event(colIdx));
            $(document).on( 'change', '.combobox-container input[type=hidden]', search_event(colIdx));
//            $( '.combobox-container input:eq(1)', table.column( colIdx ).header() ).
//                on( 'change', search_event(colIdx));
            //$('.combobox-container input:eq(1)',table.column(colIdx).header()).on('keydown',function(event){
            //    var event=event||window.event;
            //    if(event.keyCode==13||event.which==13){
            //        if($(this).val()==this.index){
            //                $( 'input', table.column( colIdx ).header()).trigger('change');
            //        }
            //    }
            //});

        }
        if(colIdx == index_of_perm){
            $( 'select', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
            //加载完后自动change
            //$( 'select', table.column( colIdx ).header() ).change();
        }
        if(colIdx == index_of_status){
            $( 'select', table.column( colIdx ).header() ).
                on( 'change', search_event(colIdx));
        }
    });

    $("#example_filter").hide();
})


function switch_project(obj, project_id, project_name)
{
    $(obj).parent().parent().find("a").removeClass("active");
    $(obj).addClass("active");
    switch_combobox_project_list(project_id, project_name);
    $( '.combobox-container input[type=hidden]').val(project_id);
    $( '.combobox-container .combobox').eq(0).val(project_name);
    $( '.combobox-container input[type=hidden]').trigger("change");
}

function switch_combobox_project_list(project_id, project_name)
{
    $("#tag").html('');
//    $("#name").append("<th id='tag' style='width:160px'><th>");
    $("#tag").append('<select id="id_app_group" class="form-control combobox" style="width:34px"></select>');
//    $("#id_app_group").html("");
//    $("#id_app_group").css("display",'inline');
//    $("#id_app_group").prev().remove();
    if(project_id == -3)//全部流程
    {
        $.ajax({
                type : "post",
                url  : '/pipeline/getProjectList/?auth=2',
                async: false,
                dataType:"json",
                success : function(result) {
                    if(result.status){
                        console.log(result.msg);
                    }else{
                        project_list = result.project_list;
                        options = '';
                        options += '<option value="-3">全部流程</option>';
                        options += '<option value="-2">我的流程</option>';
                        options += '<option value="-1">默认分组</option>';
                        if(project_list != ''){
                            for(i = 0;i<project_list.length;i++){
                                if (project_list[i]['is_default'] == 1) {
                                    continue;
                                }
                                options += "<option value='"+project_list[i]['id']+"' >"+
                                project_list[i]['name']+"</option>";
                            }
                        }
                        $("#id_app_group").append(options);
                    }
                }
        });
    }
    else if(project_id == -2)//我的流程
    {
        $.ajax({
                type : "post",
                url  : '/pipeline/getProjectList/?auth=2',
                async: false,
                dataType:"json",
                success : function(result) {
                    if(result.status){
                        console.log(result.msg);
                    }else{
                        project_list = result.project_list;
                        options = '';
                        options += '<option value="-2">我的流程</option>';
                        options += '<option value="-1">默认分组</option>';
                        if(project_list != ''){
                            for(i = 0;i<project_list.length;i++){
                                options += "<option value='"+project_list[i]['id']+"' >"+
                                project_list[i]['name']+"</option>";
                            }
                        }
                        $("#id_app_group").append(options);
                    }
                }
        });
    }
    else
    {
        options = '<option value="'+project_id+'">'+project_name+'</option>';
        $("#id_app_group").append(options);
    }
    $('.combobox').combobox();
    $('.panel .combobox-container .input-group input[type=text]').css('width', '114px');
    $('.panel .combobox-container .input-group input[type=text]').css('margin-top', '0px');
    $('.panel .combobox-container .input-group input[type=text]').css('height', '30px');
}
