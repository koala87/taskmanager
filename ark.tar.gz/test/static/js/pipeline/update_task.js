$(function(){
    //by xiaolin
        $('#seachprocess').on('click',function(){
            var url=$(this).attr('url');
            window.open(url);
        });
   //
    var type = $("#type").val();
    var quote_num = $("#quote_num").val();
    $("#id_type").val(type);
    $("#id_type").attr("disabled", true);
    $("#odps_sql_tag").show();
    $("#more_task").show();
    $("#more_task_btn").show();
    $("#more_task_span").show();
    if (type == 3) {
        $("#odps_sql").show();
        if (quote_num > 1) {
                $("#click_modify").show();
        }
    }
    //重置参数列表
    if(type != 1){
        $("[name='type']").change();
    }

    var template = $("#template").val();
    $("#id_template").val(template);
    if (quote_num > 1) {
        $("#id_template").attr("disabled", true);
    }

    //清掉整个Div
    $("#paramDiv").empty();

    $('#paramDiv').html("<label style='margin-right: 3px;'>" +
                "<font color='red'>*</font>" +
                "任务参数:</label><dev>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;" +
                "<i title='添加' style='color:green;cursor:pointer' class='fa fa-plus-square' onclick='addTemplate()' href='javascript:void(0)'>" +
                "</i></dev>");
    
    //参数配置展示
    var config = $("#config").val();
    console.log(config);
    if(config != ''){
        var temp = config.split('\n');
        var count = temp.length;
        if(count > 0){
            for(var i = 0;i<=(count-1);i++){
                addTemplate();
            }
        }
        for(var j=0;j<count;j++){
            config_str = temp[j]
            config_str_ = config_str.split('=');
            config_str_left = config_str_[0];
            //key-value,value里面有=的情况
            config_str_right = temp[j].substring(config_str_left.length+1);
            config_right_split = config_str_right.split('\1100')
            var config_state = ""
            if (config_right_split.length >= 2) {
                config_state = config_right_split[1];
                config_str_right = config_right_split[0];
            }
            $("#paramDiv div.param_div:eq(" + j + ")").find("input[type='text']").each(function (m) {
                if(m == 0){
                    $(this).val(config_str_left);
                }
                if(m == 1){
                    $(this).val(config_str_right);
                }   
            });
        }
        var arr=[];
         $('#paramDiv input.combobox').each(function(index){
            var text=$(this).val();
            
            arr.push(text);
            this.index=index;
            $(this).unbind('change');
            $(this).unbind('blur');
            $(this).on('blur',function(){
                var index=this.index;
                console.log(index);
                if($(this).val()==""){
                    $(this).val(arr[index]);
                    console.log(arr[index]);
                }
            }).on('change',function(){
                arr[this.index]=$(this).val();
            });
        });

    }

    //失败重复次数
    var retry_num = $("#retry_count").val();
    switch(retry_num){
        case '0':
            $("#id_retry_count").val(1);
            break;
        case '1':
            $("#id_retry_count").val(2);
            break;
        case '5':
            $("#id_retry_count").val(3);
            break;
        case '-1':
            $("#id_retry_count").val(4);
            break;
        default:
            $("#id_retry_count").val(1);
    }


    //清掉整个Div
    var div_str = "<label style='margin-right: 3px;'>" +
        "<font color='red'>*</font>" +
        "依赖任务:</label><dev>" +
        "&nbsp;&nbsp;&nbsp;&nbsp;" +
        "<i class='fa fa-plus-square' style='color:green;cursor:pointer' title='添加' onclick='addPipeTask()' href='javascript:void(0)'></i></div>";
    $('#plDiv').html(div_str);

    var prev_task_ids = $("#prev_task_ids").val();
    //去除两端的逗号，写正则表达式替换
    prev_task_ids = prev_task_ids.replace(/(^,)|(,$)/g,'')
    prev_task_ids = $.trim(prev_task_ids);

    if(prev_task_ids != ''){
        var temp = prev_task_ids.split(',');
        var count = temp.length;
        if(count>0){
            for(var i = 0;i<=(count-1);i++){
                addPipeTask();
            }
        }
    }
    
    var rely_tasks = $.parseJSON($("#rely_tasks").val());
    console.log(rely_tasks);

    var index = 0;
    for(key in rely_tasks){
        $("#rely_pipeline"+index).val(rely_tasks[key]);
        console.log(rely_tasks[key]);
        var rely_text= $('#rely_pipeline'+index+' option:selected').text();
        $('#rely_pipeline'+index).prev().find('.select2-chosen').text(rely_text);
        $("#rely_pipeline"+index).change();
        $("#rely_task"+index).val(key);
         var rely_task_text= $('#rely_task'+index+' option:selected').text();
        $('#rely_task'+index).prev().find('.select2-chosen').text(rely_task_text);

        index++;
    }

    //更新时服务标签
    var server_tag = $("#server_tag").val();
   // $("#server_tag_select").val(server_tag);

    //by xiaolin 
    $('#server_tag_select').prev().find('input').eq(1).val(server_tag);
    $('#server_tag_select').prev().find('input').eq(1).unbind('blur');
     $('#server_tag_select').prev().find('input').eq(1).unbind('change');
    var servertext= $('#server_tag_select').prev().find('input').eq(1).val();
     $('#server_tag_select').prev().find('input').eq(1).on('blur',function(){
            if($(this).val()==""){
                $(this).val(servertext);
            }
    }).on('change',function(){
            servertext=$(this).val();
    });

    var cmd = $('#copy_cmd').attr('title');
    $("#upload_cmd").html(cmd);
    //上传包命令
    $("#copy_cmd").click(function(){
        $('#con', window.parent.document).html($('#upload_cmd').html());
        $("#copyModal", window.parent.document).modal('show');
    });

    

});
















