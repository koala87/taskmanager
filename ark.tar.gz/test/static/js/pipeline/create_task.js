//创建数据Ajax
function createTaskAjax(){
    $("#create_busy_icon").show();
    $("#create_task_btn").attr('disabled',"true");
    var pipe_id = $("#pipe_id").val();
    var url = "/pipeline/createTask/"+pipe_id+"/";

    //by xiaolin
        $("#id_server_tag").val($('#server_tag_select').prev().find('input').eq(1).val());
    //
    var param = $("#create_task_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : param,
        success : function(result) {
            if(result.status){
                $('#messageModal_iframe .modal-body p', window.parent.document).text(result.msg);
                $('#messageModal_iframe', window.parent.document).modal('show');
            }else{
                $('#ok_div .modal-body p', window.parent.document).text('创建成功!');
                var task = result.task;
                parent.PipelineTasks.addTask(task);
                $("#ok_div .pipe_btn", window.parent.document).on('click', function(task){
                        $('.modal_iframe', window.parent.document).hide();
                });
                $('#ok_div', window.parent.document).modal('show');
            }
            $("#create_busy_icon").hide();
            $("#create_task_btn").removeAttr('disabled');
        }
    });
}
function hrefindex(pipe_id){
    top.location.href = "/pipeline/task/"+pipe_id+"/";
}

//修改数据Ajax
function updateTaskAjax(id){
    $("#update_busy_icon").show();
    $("#update_task_btn").attr('disabled',"true");
    $("#id_template").removeAttr('disabled');

    var pipe_id = $("#pipe_id").val();
    var url = "/pipeline/updateTask/" + id + "/";

   
    var param = $("#create_task_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : param,
        success : function(result) {
            if(result.status){
                $('#messageModal_iframe .modal-body p', window.parent.document).text(result.msg);
                $('#messageModal_iframe', window.parent.document).modal('show');
            }else{
                $('#ok_div .modal-body p', window.parent.document).text('修改成功!');
                if(0>window.parent.location.href.indexOf("history"))
                {
                    var task = result.task;
                    parent.PipelineTasks.updateTask(task);
                }
                $("#ok_div .pipe_btn", window.parent.document).on('click', function(task){
                        $('.modal_iframe', window.parent.document).hide();
                        $('.modal-open', window.parent.document).css('overflow', 'auto');
                });
                $('#ok_div', window.parent.document).modal('show');
            }
            $("#update_busy_icon").hide();
            $("#update_task_btn").removeAttr('disabled');
            $("#id_template").attr("disabled", true)
        }
    });
}


//修改数据
function updateTask(id) {
    //保存前准备
    var config_str = combineParams("paramDiv");
    $("#id_config").val(config_str);

    //若id_over_time == '' 默认值0
    if($("#id_over_time").val() == ''){
        $("#id_over_time").val(0);
    }
    //依赖任务
    task_list = combineTasks();
    $("#id_prev_task_ids").val(task_list);
    //服务标签
    if($("#server_tag_select").val() != ''){
        $("#id_server_tag").val($('#server_tag_select').prev().find('input').eq(1).val());
    }

    // odps_sql语句修改，直接在任务处修改
    updateTaskAjax(id); 
}


var scriptParam = '';

var jobParam = '<option value="_user_key">_user_key</option><option value="_tpl">_tpl</option>';

var odpssqlParam = '<option value="_odps_project">_odps_project</option>'+
                    '<option value="_odps_endpoint">_odps_endpoint</option>'+
                    '<option value="_odps_access_id">_odps_access_id</option>'+
                    '<option value="_odps_access_key">_odps_access_key</option>';

var odpsmrParam = '<option value="_odps_project">_odps_project</option>'+
                    '<option value="_odps_endpoint">_odps_endpoint</option>'+
                    '<option value="_odps_access_id">_odps_access_id</option>'+
                    '<option value="_odps_access_key">_odps_access_key</option>'+
                    '<option value="_odps_mr_conf">_odps_mr_conf</option>'+
                    '<option value="_odps_mr_resources">_odps_mr_resources</option>'+
                    '<option value="_odps_mr_classpath">_odps_mr_classpath</option>'+
                    '<option value="_odps_mr_args">_odps_mr_args</option>'+
                    '<option value="_odps_mr_mainclass">_odps_mr_mainclass</option>'+
                    '<option value="_odps_libjars">_odps_libjars</option>';

var odpsxlibParam = '<option value="_odps_project">_odps_project</option>'+
                    '<option value="_odps_endpoint">_odps_endpoint</option>'+
                    '<option value="_odps_access_id">_odps_access_id</option>'+
                    '<option value="_odps_access_key">_odps_access_key</option>';

var odpssparkParam='<option value="_odps_project">_odps_project</option>'+
                    '<option value="_odps_endpoint">_odps_endpoint</option>'+
                    '<option value="_odps_access_id">_odps_access_id</option>'+
                    '<option value="_odps_access_key">_odps_access_key</option>'+
                    '<option value="_odps_spark_jar">_odps_spark_jar</option>'+
                    '<option value="_odps_spark_mainclass">_odps_spark_mainclass</option>'+
                    '<option value="_odps_spark_args_1">_odps_spark_args_1</option>'+
                    '<option value="_odps_spark_args_2">_odps_spark_args_2</option>';

//参数默认值数组
var param_arr = [scriptParam,jobParam,odpssqlParam,odpsmrParam,odpsxlibParam,odpssparkParam];

//点击添加任务参数
function addTemplate(){
    var type = $("#id_type").val();
    var param_input_val = '';
    if(type == 1){
        param_input_val = '';
    }

    param_div = "<div class='form-group param_div'"+
            " style='margin-left: 104px;margin-top: 0px;margin-bottom: 0px;'>"+
            "<select style='width:180px'"+
            " class='combobox form-control'>"+param_arr[type-1]+"</select>&nbsp;"+
            "= <input type='text' value='"+param_input_val+"'"+
            " placeholder='填写参数的值' class='form-control'"+
            " style='width:474px;'/><a id='"+paramIndex+"' onclick='showDataForm("+paramIndex+")'"+
            " href='javascript:void(0)'><img src='../../../static/images/ring_2.png'"+
            " style='margin-top:-3px;' /></a>";
    param_div+="&nbsp;<i class='fa fa-plus-square' style='cursor:pointer;color:green' title='添加' onclick='addTemplate()' href='javascript:void(0)'></i>"+
               "&nbsp;<i class='fa fa-minus-square' style='cursor:pointer;color:red' title='删除' onclick='deleteParam(this, " + paramIndex + ")' href='javascript:void(0)'></i></dev>";

    $('#paramDiv').append(param_div);

    //$('.combobox').combobox();
    $("#paramDiv .combobox:last").combobox();
    paramIndex++;

    //by xiaolin
    if(type==1){
     $('#paramDiv .add-on').unbind('click');
    }else{
          var arr=[];
         $('#paramDiv input.combobox').each(function(index){
            var text=$(this).val();
            console.log(text);
            arr.push(text);
            this.index=index;
            console.log(arr);
            $(this).unbind('blur');
            $(this).unbind('blur');
            $(this).on('blur',function(){
                var index=this.index;
                console.log(index);
                if($(this).val()==""){
                    $(this).val(arr[index]);
                    console.log(arr[index]);
                }
            }).on('change',function(){
                arr[this.index]=$(this).val();
            });
        });
    }
}
var taskvalue;
var pangu,pangulength,text1,text2,minh,day,hour;
var changeindex=0;
//点击图标弹出数据引用框
function showDataForm(id){
    //by xiaolin
    changeindex=0;
    //  
   $("#choose_data_modal").modal({
        backdrop:false,
        show:true,        
    });
    $("#indexNumber").val(id);

    var text=$('#'+id).prev().val();
    taskvalue=text;
    if(text==""){
        taskvalue="";
        pangu="";
        pangulength="";
        text1="";
        text2="";
        minh="";
        day="";
        hour="";

        $('#data_offset').val('');
        $('#timeType option:eq(0)').prop('selected','selected');
        $('.pangu').trigger('click');
    }

    if(text!=""){
        text=text.split('@-');
        if(text[1]){
            minh=text[1];
            day=minh.match(/[0-9]+/g);
            hour=minh.match(/\D+$/g);
            day=day[0];
            hour=hour[0];
        }else{
            minh='';
        }
        pangu=text[0].replace('%','');
        pangu=pangu.replace('%','');
        pangulength=pangu.split(':');
        text1=pangulength[0];
        text2=pangulength[1];
    }
    changeDataType(taskvalue,text1,text2,minh,day,hour);
}


//改变数据的类型（弹框里）
function changeDataType(taskvalue,text1,text2,minh,day,hour){
    var data_type = $("[name='data_type']:checked").val();
    if(data_type == 1){
        $("#dataPath").html('<label class="radio-inline" style="margin-top:-2px;margin-left:-10px;">'+
                '<input type="radio" class="pangudir" name="data_mode" value="0" checked>目录</label>'+
                '<label class="radio-inline" style="margin-top:-2px;margin-left:-10px;">'+
                '<input type="radio" class="pangufile" name="data_mode" value="1">文件</label>');
    }
    else{
        $("#dataPath").html('<label class="radio-inline" style="margin-top:-2px;">'+
                '<input type="radio" class="odpsproject" name="data_mode" value="2" checked>项目名</label>'+
                '<label class="radio-inline" style="margin-top:-2px;margin-left:-10px;">'+
                '<input type="radio" class="odpstable" name="data_mode" value="3">表名</label>'+
                '<label class="radio-inline" style="margin-top:-2px;margin-left:-10px;">'+
                '<input type="radio" class="odpspart" name="data_mode" value="4">分区</label>');
    }

    //先清空select内容
    $("#data_select").empty();
    var data_str = '';
    var url = "/pipeline/getDatas/";
    $.ajax({
        type:'post' ,
        url:url,
        dataType:'json',
        data:{"data_type":data_type},
        success:function(result){
            data_list = result.data_list;
            
            for(i = 0;i<data_list.length;i++){
                data_str += "<option value='"+data_list[i].id+"' >"+
                data_list[i].name+"</option>";
            }
            //select2初始化选第一个
            //$(".select2-chosen").html(data_list[0].name);
            $("#s2id_data_select span.select2-chosen").html(data_list[0].name);
            $("#data_select").append(data_str);
            //by xiaolin
            
             if(taskvalue!=""&&taskvalue!=undefined){
                console.log(taskvalue);   
            if(text2=="dir"||text2=="file"){
           
            $('.pangu').trigger('click');
            $('#data_select option').each(function(){
               
                if($(this).text()==text1){
                    $(this).prop('selected','selected');
                    console.log('pangu');
                    console.log($('#data_select option:selected').text());
                    $('#dataDiv .select2-chosen').text($('#data_select option:selected').text());
                    console.log(minh);
                    console.log(day);
                    if(minh!=""&&typeof minh!=undefined){
                        $('#data_offset').val(day);
                        if(hour=="hour"){
                            $('#timeType option:eq(0)').prop('selected','selected');
                        }else{
                            $('#timeType option:eq(1)').prop('selected','selected');
                        }
                    }else{
                        $('#data_offset').val('');
                        $('#timeType option:eq(0)').prop('selected','selected');
                    }
                }
            });
             changeindex=1;     
            
             $('.pangu'+text2).trigger('click');

        }else if(text2=="project"||text2=="table"||text2=="part"){
            
            $('.odps').trigger('click');
              $('#data_select option').each(function(){
                
                if($(this).text()==text1){
                    $(this).prop('selected','selected');
                    console.log($('#data_select option:selected').text());
                    $('#dataDiv .select2-chosen').text($('#data_select option:selected').text());
                     if(minh){
                        $('#data_offset').val(day);
                        if(hour=="hour"){
                            $('#timeType option:eq(0)').prop('selected','selected');
                        }else{
                            $('#timeType option:eq(1)').prop('selected','selected');
                        }
                    }else{
                          $('#data_offset').val('');
                           $('#timeType option:eq(0)').prop('selected','selected');

                    }

                }
            });
            changeindex=1;
             $('.odps'+text2).trigger('click');
        }
    }
        }
    });
}

function deleteParam(obj, index) {
    $(obj).parent().remove();
}

function addPipeTask(){
    var select_str = "";
    var task_id = $('#task_id').val();
    $.ajax({
        type : 'post',
        async: false,
        url  : '/pipeline/getPipelines/',
        data : {'plIndex' : pIndex, 'task_id': task_id},
        success : function(result) {
            if(result.status == 0){
                pipelines = result.pipeline_list;
                if(pipelines.length > 0){
                    select_str += "<div class='form-group'"+
                        " style='margin-left: 104px;'><select id='rely_pipeline"+pIndex+
                        "' onchange='getTasks("+pIndex+")' style='width:350px'"+
                        " class='combobox select2-select-00 full-width-fix select2-offscreen'>"+
                        "<option value=''>--请选择流程--</option>";

                    for(i = 0;i<pipelines.length;i++){
                        select_str += "<option value='"+pipelines[i].id+"' >"+
                        pipelines[i].name+"</option>";
                    }
                   
                    select_str += "</select>&nbsp<select id='rely_task"+pIndex+
                   "' style='width:350px' class='combobox select2-select-00 full-width-fix select2-offscreen'>"+
                   "<option value=''>--请选择任务--</option></select>&nbsp;"+
                   "<i class='fa fa-plus-square' style='cursor:pointer;color:green;' title='添加' onclick='addPipeTask()' href='javascript:void(0)'></i>&nbsp;"+
                    "<i title='删除' class='fa fa-minus-square' style='cursor:pointer;color:red' onclick='deletePlDiv(this)'"+
                    " href='javascript:void(0)'></i></div>";

                    console.log(select_str);
                    $("#plDiv").append(select_str);

                    $('#rely_pipeline'+pIndex).select2();
                    $('#s2id_rely_pipeline'+pIndex).css({
                          'width':'346px',
                          'margin-left':'10px'
                    }); 
                     $('#rely_pipeline'+pIndex).prev().find('.select2-chosen').text('--请选择流程--'); 
                   // $('#rely_task'+pIndex).combobox();
                    //by xiaolin
                   var addinput= $('#rely_pipeline'+pIndex).prev().find('input').eq(1);
                    var text=addinput.val();
                    addinput.on('blur',function(){
                        if($(this).val()==""){
                        $(this).val(text);
                        }
                    });
                    $('#rely_task'+pIndex).select2();
                    $('#rely_task'+pIndex).prev().find('.select2-chosen').text('--请选择任务--');
                    $('#s2id_rely_task'+pIndex).css({
                        
                        'width':'364px',
                        'margin-left':'9px'
                    });
                }
                else {
                    alert("你没有拥有权限的流程，不能添加依赖！");
                }
            }
        }
    }); 
    pIndex++;
}

function deletePlDiv(obj) {
    $(obj).parent().remove();
}

function getTasks(index){
    var id = $("#rely_pipeline"+index).val();
    //by xiaolin
    $('#rely_task'+index).prev().find('.select2-chosen').text('--请选择任务--');

    var url = "/pipeline/getTasks/";
    var task_select = '';
    if(id != ''&&id!=null){
        $.ajax({
            type:'post',
            url:url,
            async: false,
            dataType:'json',
            data:{'pipeline_id':id},
            success:function(result){
                $("#rely_task"+index).empty();
                var task_list = result.task_list;
                if(task_list.length>0){
                    for(var i=0;i<task_list.length;i++){
                        task_select += "<option value='"+task_list[i].id+"'>"+
                        task_list[i].name+"</option>";
                    }
                }
                else{
                    task_select = "<option value=''>无</option>";
                }
                 
                $("#rely_task"+index).append(task_select);
            }
        });
    }
    else{
        //流程为空
        $("#rely_task"+index).empty();
    }
}


//if type =3 展示odps_sql
function odps_sql_show(template){
   if($("[name='type']").val() == 3){
       $("#id_template").val(template);
       $("#id_template").attr("disabled",true);
   }
}

function get_processor_ajax(){
    var processor_select = '';
    $("#processor_select").empty();
    
    $.ajax({
        type : "post",
        url  : '/pipeline/getProcessors/',
        dataType:"json",
        data:{"type":$("#id_type").val()},
        success : function(result) {
            if(result.status){
                $('#messageModal_iframe .modal-body p').text('result.msg');
                $('#messageModal_iframe').modal('show');
            }else{
                processors = result.processor_list;
                if(processors.length>0){
                    for(i = 0;i<processors.length;i++){
                        processor_select += "<option value='"+processors[i].id+"'>"+
                        processors[i].name+"</option>";
                    }
                    //参数填充
                    config = result.config;
                    console.log(config);
                    add_config_list(config);
                    
                    odps_sql_show(result.template);

                    //默认选择第一个插件
                    $("#s2id_processor_select span.select2-chosen").html(processors[0].name);
                }
                else{
                    new PNotify({
                        title: '通知',
                        text: '无可用插件',
                        addclass: 'custom',
                        type: 'error'
                    });
                }
            }
            $("#processor_select").append(processor_select);
        }
    });
}

//选择已有插件，获取参数
function getParams(){
    var param = '';
    var id = $("#processor_select").val();
    var url = "/pipeline/getParams/";    
    $.ajax({
        type:'post',
        url:url,
        data:{"processor_id":id},
        success:function(result){
            config = result.config;
            console.log(config);
            add_config_list(config);
            odps_sql_show(result.template);
        }        
    });
}

//去除字符串中间空格
function trim(str){
    return str.replace(/[ ]/g,""); //去除字符串中的空格
}

//选择已有插件，构造参数列表
function add_config_list(config){    
    var div_str = "<label style='margin-right: 3px;'>"+
                "<font color='red'>*</font>"+
                "任务参数:</label><dev>"+
                "&nbsp;&nbsp;&nbsp;&nbsp;"+
                "<i title='添加' style='color:green;cursor:pointer' class='fa fa-plus-square' onclick='addTemplate()' href='javascript:void(0)'>"+
                "</i></dev>"  
    $('#paramDiv').html(div_str);  
    if(config != ''){
        var temp = config.split('\n');
        var count = temp.length;
        if(count >= 1){
            for(var i = 0;i<=(count - 1);i++){
                addTemplate();
            }
        }

        for(var j=0;j<count;j++){
            config_str = temp[j]
            config_str_ = config_str.split('=');
            config_str_left = config_str_[0];
            //key-value,value里面有=的情况
            config_str_right = temp[j].substring(config_str_left.length+1);
            config_right_split = config_str_right.split('\1100')
            var config_state = ""
            if (config_right_split.length >= 2) {
                config_state = config_right_split[1];
                config_str_right = config_right_split[0];
            }

            //config_str_right = config_str_[1];
            $("#paramDiv div.param_div:eq("+j+")").find("input[type='text']").each(function(m){
                if(m == 0){
                    $(this).val(config_str_left);
                }
                if(m == 1){
                    $(this).val(config_str_right);
                }
            });
        }
        var arr=[];
         $('#paramDiv input.combobox').each(function(index){
            var text=$(this).val();
            
            arr.push(text);
            this.index=index;
            $(this).unbind('change');
            $(this).unbind('blur');
            $(this).on('blur',function(){
                var index=this.index;
                console.log(index);
                if($(this).val()==""){
                    $(this).val(arr[index]);
                    console.log(arr[index]);
                }
            }).on('change',function(){
                arr[this.index]=$(this).val();
            });
        });

    }
}

//组装参数配置**
function combineParams(id) {
    var config = "";
    var template = "";
    if(id=='processor_param'){
        $("#"+id+" div").each(function(){
            $(this).find("input[type='text']").each(function(j){
                if(j == 0 && $(this).val()) {
                    config += $(this).val() + '=';
                }
                if(j == 1){
                    config += $(this).val()  + "\n";
                }
            });
        });
    }
    else{
        $("#"+id+" div.param_div").each(function(i){
            $(this).find("input[type='text']").each(function(j){
                if(j == 0) {
                    if($(this).val() == ''){
                        //alert('请选择参数！');
                        return;
                    }
                    else{
                        config += $(this).val() + '=';
                    }
                }
                else{
                    if($(this).val() == ''){
                        config += '\n';
                    }
                    else{
                        config += $(this).val()  + "\n";
                    }
                }
            })
                
        });
    }
    //alert(config);
    return config;
}

//组装依赖任务list
function combineTasks(){
    var task_list = '';
    $("#plDiv div").each(function(){
        $(this).find("select").each(function(i){
            if(i == 1 && $(this).val() != ''){
                task_list += $(this).val() + ',';
            }
        });
    })
    if(task_list.length > 1){
        task_list = task_list.substr(0,task_list.length-1);
    }
    return task_list;
}

//保存前设置form参数
function task_attribute(){
    //使用已有插件
    var use_processor = $("#id_use_processor").is(':checked');
    if(use_processor){
        $("#id_processor_id").val($("#processor_select").val());
        $("#id_config").val(combineParams("processor_param"));
    }
    else{
        $("#id_processor_id").val(0);
        $("#id_config").val(combineParams("paramDiv"));
    }
    $("#id_config").val(combineParams("paramDiv"));
    //若id_over_time == '' 默认值0
    if($("#id_over_time").val() == ''){
        $("#id_over_time").val(0);
    }
    
    //服务标签
    if($("#server_tag_select").val() != ''){
        $("#id_server_tag").val($("#server_tag_select").val());
    }

    //依赖任务
    task_list = combineTasks();
    $("#id_prev_task_ids").val(task_list);
}

//获取服务器标签
function get_server_tags(task_type){
    var options = "";
    $.ajax({
        type : "post",
        url  : '/pipeline/getServerTags/',
        async: false,
        dataType:"json",
        data:{'task_type':task_type},
        success : function(result) {
            if(result.status){
                //alert(result.msg);
                $("#server_tag_div").hide();
                $("#server_tag_select").empty();

            }else{
                $("#server_tag_div").show();
                server_tags = result.server_tags;
                if(server_tags != ''){
                    server_tags_arr = server_tags.split(',');
                    for(i = 0;i<server_tags_arr.length;i++){
                        options += "<option value='"+server_tags_arr[i]+"' >"+
                        server_tags_arr[i]+"</option>";
                    }
                    $('#server_tag_select option').remove();
                    $("#server_tag_select").append(options);
                }
            }
        }
    });
}

function cancel_add_task() {
    choosevalue=0;
    $('#modalcheck_iframe', window.parent.document).unbind('hide.bs.modal');
    $('#modalcheck_iframe .modal-body h5', window.parent.document).text('确定要放弃创建task吗?');
    $('.changevalue', window.parent.document).text('确定');
    $('#modalcheck_iframe', window.parent.document).modal('show');
    $('#modalcheck_iframe', window.parent.document).on('hide.bs.modal',function(){
        if (choosevalue==1) {
            //history.go(-1);
            $('.modal_iframe', window.parent.document).hide();
        }
    });
}

//添加任务的index
var pIndex = 0;

//添加参数的index
var paramIndex = 0;

$(function(){
    $('.changevalue', window.parent.document).on('click',function(){
        choosevalue=1;
        $('#modalcheck_iframe', window.parent.document).modal('hide');
    });

    //清掉整个Div
    var div_str = "<label style='margin-right: 3px;'>" +
        "<font color='red'>*</font>" +
        "依赖任务:</label><dev>" +
        "&nbsp;&nbsp;&nbsp;&nbsp;" +
        "<i class='fa fa-plus-square' style='color:green;cursor:pointer' title='添加' onclick='addPipeTask()' href='javascript:void(0)'></i></div>";
    $('#plDiv').html(div_str);

    var div_str = "<label style='margin-right: 3px;'>"+
                "<font color='red'>*</font>"+
                "任务参数:</label><dev>"+
                "&nbsp;&nbsp;&nbsp;&nbsp;"+
                "<i title='添加' style='color:green;cursor:pointer' class='fa fa-plus-square' onclick='addTemplate()' href='javascript:void(0)'>"+
                "</i></dev>"  
    $('#paramDiv').html(div_str);  


    //使用插件开关
    $("[name='use_processor']").bootstrapSwitch();
    $('input[name="use_processor"]').on('switchChange.bootstrapSwitch',
        function(event, state) {
            if(state){
                $("#paramDiv").show();
                $("#processor_choose").css('display','inline');
                //$("#processor_choose").show();
                $("#processor_param").hide();
                get_processor_ajax();
            }
            else{
                $("#paramDiv").show();
                $("#processor_choose").hide();
                $("#processor_param").hide();

                $("#id_template").val('');
                $("#id_template").attr("disabled",false);
                var div_str = "<label style='margin-right: 3px;'>"+
                            "<font color='red'>*</font>"+
                            "任务参数:</label><dev>"+
                            "&nbsp;&nbsp;&nbsp;&nbsp;"+
                            "<i title='添加' style='color:green;cursor:pointer' class='fa fa-plus-square' onclick='addTemplate()' href='javascript:void(0)'>"+
                            "</i></dev>"  
                $('#paramDiv').html(div_str);  
            }
        });

    $("#create_task_btn").click(function(){
        //填充所需字段,create前准备
        task_attribute(); 
        createTaskAjax();
    });

    $("[name='type']").change(function() {
        var type = $(this).val();
        get_server_tags(type);

        if($("#id_use_processor").is(':checked')){
            get_processor_ajax();
        }
        else{
            $("#id_template").val('');
            $("#odps_sql").hide();
        }

        var param_defaul_val = '';
        //清掉整个Div
        $("#paramDiv").empty();

        if(type == 1){
            param_defaul_val = '';
        }

        $('#paramDiv').append("<label style='margin-right: 3px;'>"+
                "<font color='red'>*</font>"+
                "任务参数:</label><dev>"+
                "&nbsp;&nbsp;&nbsp;&nbsp;"+
                "<i title='添加' style='color:green;cursor:pointer' class='fa fa-plus-square' onclick='addTemplate()' href='javascript:void(0)'>"+
                "</i></dev>");
        $(".combobox:last").combobox();
        //by xiaolin
        var selecttext=$('#paramDiv select.combobox').prev().find('input').eq(1).val();
        
        $('#paramDiv input.combobox:eq(0)').on('blur',function(){
           if($(this).val()==""){
              $('#paramDiv input.combobox:eq(0)').val(selecttext);
            }
        }).on('change',function(){
            selecttext=$(this).val();
        });
        //
        if($(this).val() == 3){
            $("#odps_sql").show();
        }
        else{
            $("#odps_sql").hide();
        }
        //by xiaolin
       $('#server_tag_select').combobox('refresh');
       $('#server_tag_select').parent().css({
        'margin-left':'4px',
        'margin-top':'-5px'
        });

        var tag=$('#server_tag_select').parent().find('input').eq(1).val();
        $('#server_tag_select').parent().find('input').eq(1).unbind('blur');
        $('#server_tag_select').parent().find('input').eq(1).unbind('change');
        $('#server_tag_select').parent().find('input').eq(1).on('blur',function(){
            console.log(tagtext);
            if($(this).val()==""){
                $(this).val(tag);
            }
        }).on('change',function(){
                console.log(tagtext);
                tag=$(this).val();
        });
    });

    $('select.combobox').combobox();
    $('input.combobox').each(function(){
        $(this).val($(this).val());
    });
    $('#paramDiv .add-on').unbind('click');

    var reportTo = "";
    $.ajax({
        type : "post",
        url  : '/pipeline/getPipelines/',
        async: false,
        dataType:"json",
        success : function(result) {
            if(result.status){
            }else{
                pipelines = result.pipeline_list;
                for(i = 0;i<pipelines.length;i++){
                    reportTo += "<option value='"+pipelines[i].id+"' >"+
                    pipelines[i].name+"</option>";
                }
            }
            $("#rely_pipeline1").append(reportTo);
            $('#rely_pipeline1').select2();
            $('#s2id_rely_pipeline1').find('.select2-chosen').text($('#rely_pipeline1 option:selected').text());
            $('#s2id_rely_pipeline1').css({
                    'width':'346px',
                    'margin-left':'10px'
            }); 
            
            $('#rely_task1').select2();   
            $('#s2id_rely_task1').find('.select2-chosen').text('--请选择任务--'); 
            $('#s2id_rely_task1').css({
                'margin-left':'6px', 
                'width':'364px'
            }); 
        }
    });

    //获取服务标签
    get_server_tags($('#id_type').val());
    $('#server_tag_select').combobox();
    $('#server_tag_select').parent().css({
        'margin-left':'4px',
        'margin-top':'-5px'
    }); 
    var tagtext=$('#server_tag_select').parent().find('input').eq(1).val();
    $('#server_tag_select').parent().find('input').eq(1).on('blur',function(){
        console.log(tagtext);
        if($(this).val()==""){
            $(this).val(tagtext);
        }

    }).on('change',function(){
            console.log(tagtext);
            tagtext=$(this).val();
    });

    $("[name='data_type']").change(function(){
        if(changeindex==0){
             changeDataType(taskvalue,text1,text2,minh,day,hour);
        }else if(changeindex==1){
             taskvalue='';
             text1='';
             text2='';
             minh='';
             day='';
             hour='';
             changeDataType(taskvalue,text1,text2,minh,day,hour);
        }
    });

    $("#data-choose-button").click(function(){
        var dataId = $("#data_select").val();
        if(dataId == 'choose'){
            $('#messageModal_iframe .modal p').text('请选择数据');
            $('#messageModal_iframe ').modal('show');
            return;
        }
        var dataOffset = "";
        if(!isNaN(Number($("#data_offset").val())) && $("#data_offset").val() != "") {
            dataOffset = $("#data_offset").val()+$("#timeType").val();
        }
        var dataMode = $("[name='data_mode']:checked").val();
        $.ajax({
            type:'post',
            url:'/pipeline/getDataExpress/',
            data:{'data_id':dataId,'data_mode':dataMode,'data_offset':dataOffset},
            dataType:'json',
            success:function(result){
                $("#"+$("#indexNumber").val()).prev().val(result.data_express);
                $("#choose_data_modal").modal("hide");
            }
        });
    });
});
