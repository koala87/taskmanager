//创建数据Ajax
function createProcAjax(){
    $("#create_busy_icon").show();
    $("#create_processor_btn").attr('disabled',"true");
    var url = "/processor/create/";
    var param = $("#create_processor_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : param,
        success : function(result) {
            if(result.status){
               // alert(result.msg);
               $('#messageModal .modal-body p').text(result.msg);
               $('#messageModal').modal('show');
            }else{
             //   alert("创建成功！");
              //  location.href = "/processor/index/";
                $('#copyModal .modal-body p').text('创建成功');
                $('#copyModal').modal('show');
            }
            $("#create_busy_icon").hide();
            $("#create_processor_btn").removeAttr('disabled');
        }
    });
}

function href_index(){
    // window.location.href="/processor/index/";
}

//修改数据Ajax
function updateProcAjax(id){
    $("#update_busy_icon").show();
    $("#update_processor_btn").attr('disabled',"true");
    var url = "/processor/update/" + id + "/";
    var param = $("#create_processor_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : param,
        success : function(result) {
            if(result.status){
               // alert(result.msg);
                  $('#messageModal .modal-body p').text(result.msg);
               $('#messageModal').modal('show');

            }else{
             //   alert("修改成功！");
              //  location.href = "/processor/index/";
                  $('#copyModal .modal-body p').text('修改成功');
                $('#copyModal').modal('show');
            }
            $("#update_busy_icon").hide();
            $("#update_processor_btn").removeAttr('disabled');
        }
    });
}


//修改数据
function updateProc(id) {
    var $tag = $("#tag").siblings(".tagsinput").find(".tag span"); 
    var tags = []; 
    for (var i = $tag.length; i--;){ 
        tags.push($($tag[i]).text().trim()); 
    }

    tags.join(",");
    $("#id_tag").val(tags);
    $("#id_config").val(combineParams());

    updateProcAjax(id); 
}


function addTemplate(){
    $('#paramDiv').append("<div class='form-group'"+
            " style='margin-left: 84px;'><input type='text' "+
            "placeholder='填写参数的key' class='form-control'"+
            " style='width:235px;'/>&nbsp;:" +
            " <input type='text' placeholder='填写默认参数' class='form-control' style='width:237px;'/>&nbsp;//"+
            " <input type='text' placeholder='填写参数的说明' class='form-control' style='width:237px;'/>"+
            " &nbsp<i style='cursor:pointer;color:red' class='fa fa-minus-square' title='删除'"+
            " onclick='deleteParam(this)' href='javascript:void(0)'>"+
            "</i></div>");
}

function deleteParam(obj) {
    $(obj).parent().remove();
}

//组装参数配置
function combineParams() {
    var config = "";
    $("#paramDiv div").each(function(i){
        $(this).find("input[type='text']").each(function(j){
            if(j == 0 && $(this).val()) {
                config += $(this).val();
            }
            if(j == 1){
                config += "=" + $(this).val();
            }
            if (j == 2) {
                config += "\1100" + $(this).val() + "\n";
            }
        });
    });
    //$("#id_template").val(template);
    return config;
}


$(function(){
    $("#principal").change(function () {
        $("#id_principal").val($("#principal").val());
    });
      
    //
    $("#tag").tagsInput({
        'height':'auto',
        'width':'500px'
    });

    $("#create_processor_btn").click(function(){
        var $tag = $("#tag").siblings(".tagsinput").find(".tag span"); 
        var tags = []; 
        for (var i = $tag.length; i--;){ 
            tags.push($($tag[i]).text().trim()); 
        }

        tags.join(",");
        $("#id_tag").val(tags);
        $("#id_config").val(combineParams());

        createProcAjax(); 
    });

    $("[name='type']").change(function() {
        if($(this).val() == 3){
            $("#odps_sql").show();
        }
        else{
            $("#id_template").val('');
            $("#odps_sql").hide();
        }
    });

});
