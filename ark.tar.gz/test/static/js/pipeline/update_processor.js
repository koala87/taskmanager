﻿
function href_index_update() {
    window.location.href = "/processor/" + $('#proc_id').val() + "/";
}

$(function () {
    $("#id_principal").val($("#principal").val());

    var type = $("#type").val();
    if (type == 3) {
        $("#odps_sql").show();
    }

    var config = $("#config_str").val();
    if (config != '') {
        var temp = config.split('\n');
        var count = temp.length;
        if (count > 1) {
            for (var i = 0; i <= (count - 2); i++) {
                addTemplate();
            }
        }

        for (var j = 0; j < count; j++) {
            config_str = temp[j]
            config_str_ = config_str.split('=');
            config_str_left = config_str_[0];
            config_str_right = temp[j].substring(config_str_left.length + 1);

            config_right_split = config_str_right.split('\1100')
            var config_state = ""
            if (config_right_split.length >= 2) {
                config_state = config_right_split[1];
                config_str_right = config_right_split[0];
            }

            $("#paramDiv div:eq(" + j + ")").find("input[type='text']").each(function (m) {
                if (m == 0) {
                    $(this).val(config_str_left);
                }
                if (m == 1) {
                    $(this).val(config_str_right);
                }
                if (m == 2) {
                    $(this).val(config_state);
                }
            });
        }
    }
});
