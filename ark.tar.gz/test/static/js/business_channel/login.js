register_modal_id = "register_modal";
reset_password_modal_id = "reset_password_modal";
login_modal_id = "login_modal";

$(function() {
    $("img.captcha").each(
        function() {
            $(this).click(function() {
                refreshCaptcha($(this));
            });
        }
    );
    document.onkeydown = function(e){
        if(!e){
            e = window.event;
        }
        if((e.keyCode || e.which) == 13){
            login();
        }
    }
});

function beginRegister() {
    $("#" + register_modal_id).modal().show();
}
function register() {
    var items = ["email", "username", "password"];
    var data = {};
    for(var i = 0; i < items.length; i++) {
        var key = items[i];
        data[key] = $("#" + register_modal_id + " #" + key).val();
    }

    captcha = getCaptcha(register_modal_id);
    for(key in captcha) {
        data[key] = captcha[key];
    }

    var url = "/business_channel/register/";
    var ok = false;
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        dataType: "json",
        traditional: true,
        data: data,
        success: function(result) {
            ark_notify(result);
            if(result.status != 0) {
                updateCaptcha($("#" + register_modal_id + " img.captcha"), result.captcha);
            }
            ok = result.status == 0;
        },
        error: function(result) {
            result['msg'] = '服务出错';
            ark_notify(result);
        }
    });
    if(ok) {
        window.location = "/business_channel/index/";
    }
    return ok;
}

function login() {
    var items = ["username", "password"];
    var data = {};
    for(var i = 0; i < items.length; i++) {
        var key = items[i];
        data[key] = $("#" + login_modal_id + " #" + key).val();
    }

    captcha = getCaptcha(login_modal_id);
    for(key in captcha) {
        data[key] = captcha[key];
    }

    var url = "/business_channel/login/";
    var ok = false;
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        dataType: "json",
        traditional: true,
        data: data,
        success: function(result) {
            ark_notify(result);
            if(result.status != 0) {
                updateCaptcha($("#" + login_modal_id + " img.captcha"), result.captcha);
            }
            ok = result.status == 0;
        },
        error: function(result) {
            result['msg'] = '服务出错';
            ark_notify(result);
        }
    });
    if(ok) {
        window.location = "/business_channel/index/";
    }
    return ok;
}

function beginResetPassword() {
    $("#" + reset_password_modal_id).modal().show();
}
function resetPassword() {
    var items = ["email", "username"];
    var data = {};
    for(var i = 0; i < items.length; i++) {
        var key = items[i];
        data[key] = $("#" + reset_password_modal_id + " #" + key).val();
    }

    captcha = getCaptcha(reset_password_modal_id);
    for(key in captcha) {
        data[key] = captcha[key];
    }

    var url = "/business_channel/reset_password/";
    var ok = false;
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        dataType: "json",
        traditional: true,
        data: data,
        success: function(result) {
            ark_notify(result);
            ok = result.status == 0;
            if(!ok) {
                updateCaptcha($("#" + reset_password_modal_id + " img.captcha"), result.captcha);
            } else {
                $("#" + reset_password_modal_id).hide();
            }
        },
        error: function(result) {
            result['msg'] = '服务出错';
            ark_notify(result);
        }
    });
    return ok;
}

$(function() {
    $("#register_modal #email").change(function(){
        var arr = new Array();
        var email = $("#register_modal #email").val();
        if(email != '' ) {
            var filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            valid_result = filter.test(email)
            if (valid_result){
                arr = email.split("@");
                $("#register_modal #username").val(arr[0]);
            }
        }
    });
})