// 点击添加域名
function addUrl(url, idx){
    var type = $("#id_type").val();

    var param_input_val = '';
    if(url != undefined) {
        param_input_val = url;
    }

    url_div = "<div class='form-group param_div' style='margin-left: 80px;margin-top: 0px;margin-bottom: 0px;'><span><input type='text' name='channel_url' value='" + param_input_val + "'"+
        " placeholder='域名如 m.baidu.com' class='form-control'"+
        " style='width:300px;margin-left:5px;'/></span>";


    if(idx == 1) {
        url_div += "&nbsp;<i class='fa fa-plus-square' style='cursor:pointer;color:green' title='添加' onclick='addUrl()'href='javascript:void(0)'></i>";
    } else {
        url_div+="&nbsp;<i class='fa fa-minus-square' style='cursor:pointer;color:red' title='删除' onclick='$(this).parent().remove()' href='javascript:void(0)'></i>";
    }

    $('#channel_url_input').append(url_div);
}

// 默认create
function createOrUpdate(data, channel_id) {

    console.log(data);
    
    url = '';
    if(channel_id != undefined) {
        url = "/business_channel/update/" + channel_id;
    } else {
        url = "/business_channel/create/";
    }

    ok = true;
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        dataType: "json",
        traditional: true,
        data: data,
        success: function(result) {
            ark_notify(result);
            ok = result.status == 0;
        }
    });
    return ok;
}

function collectData() {
    data = {}
    data['name'] = $("#channel_name").val();
    data['owner_name'] = $("#channel_owner_name").val();
    data['description'] = $("#channel_description").val();
    data['user_ids'] = collectAccess();
    data['urls'] = collectUrl();
    data['types'] = collectType();
    return data
}

function collectUrl() {
    urls = []
    $("input[name=channel_url]").each(function() {
        if($(this).val()) {
            urls.push($(this).val());
        }
    });
    return urls;
}

function collectAccess() {
    user_ids = $('#access_user_select').val();
    return user_ids;
}

type_hot='热词';
type_search='搜索框';

function collectType() {
    var type = [];
    if ($('#channel_type_hot').prop('checked'))
        type.push(type_hot);
    if ($('#channel_type_search').prop('checked'))
        type.push(type_search);
    if ($('#channel_type_other').val())
        type.push($('#channel_type_other').val());
    return type;
}

function initType() {
    var channel_type = $("#channel_type").val();
    channel_type = JSON.parse(channel_type);
    for(var i = 0; i < channel_type.length; i++) {
        var type = channel_type[i];

        if(type == type_hot) {
            $("#channel_type_hot").attr("checked", true);
        } else if(type == type_search) {
            $("#channel_type_search").attr("checked", true);
        } else {
            $("#channel_type_other").val(type);
        }
    }
}

function initUrl() {
    var channel_url = $("#channel_url").val();
    channel_url = JSON.parse(channel_url);
    if(channel_url.length == 0)
        addUrl('', 1);
    for(var i = 0; i < channel_url.length; i++) {
        addUrl(channel_url[i], i + 1);
    }
}

function initUser() {
    var user_list = $("#user_list").val();

    var options = "";
    users = JSON.parse(user_list);
    for(var i = 0;i<users.length;i++){
        options += "<option value='" + users[i].id + "'";
        options += ">" + users[i].name + "</option>";
    }

    $('#access_user_select').append(options);

    var channel_access = $("#channel_access").val();
    access_users = JSON.parse(channel_access);
    access_user_ids = []
    for(var id in access_users) {
        access_user_ids.push(id);
    }
    $('#access_user_select').select2("val", access_user_ids);
}

