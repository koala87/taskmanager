start_date = '';
end_date = '';
date_format = 'YYYYMMDD'

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10).replace(/-/g,"");
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10).replace(/-/g,"");
}

function init_feat_date_range(obj, channel_id) {

    end_date = yesterday = get_pre_date(1);
    start_date = last_week = get_pre_date(7);
    last_month = get_pre_month(1);
    obj.daterangepicker({
        "ranges": {
            "昨天": [
                yesterday,
                yesterday
            ],
            "近一周": [
                last_week,
                yesterday
            ],
            "近一个月": [
                last_month,
                yesterday
            ],
        },
        "locale": {
            "format": date_format,
            "separator": " 到 ",
            "applyLabel": "确定",
            "cancelLabel": "取消",
            "fromLabel": "From",
            "toLabel": "To",
            "customRangeLabel": "自定义时间",
            "daysOfWeek": [
                "日", 
                "一", 
                "二", 
                "三", 
                "四", 
                "五", 
                "六"
            ],
            "monthNames": [
                "一月",  
                "二月",  
                "三月",  
                "四月",
                "五月",
                "六月",
                "七月",
                "八月",
                "九月",
                "十月",
                "十一月",
                "十二月"
            ],
            "firstDay": 1
        },
        "startDate": last_week,
        "endDate": yesterday,
        "opens": "right"
    }, function(start, end, label) {
        start = start.format(date_format);
        end = end.format(date_format);
        start_date = start;
        end_date = end;
        refresh_range_feat(channel_id);
    });
}
