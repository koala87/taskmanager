view_dialog_id = 'view_dialog'

channel_table = null;

function query_channel_feat ( id, fn ) {
    var url = "/business_channel/query_feat/" + id + "/";
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : {'start_time':start_date, 'end_time':end_date},
        success : function(result) {
            fn(result);
        }
    });
}

function get_busy_html(channel_id) {
    busy_obj = $('#row_detail_div').clone().prop({id:'row_detail_div_' + channel_id});
    busy_obj.show();
    return busy_obj[0];
}

$(function(){
    
    channel_table = $('#channel_list').DataTable({
        "processing": true,
        "serverSide": true,
        "bLengthChange": false,
        "ajax": {
            "url": "/business_channel/list/",
            "type": "POST",
        },
        "oLanguage": {
            "sEmptyTable": "暂无可见渠道",
            "oPaginate": {"sPrevious": "上一页", "sNext": "下一页"},
        },
        "columns": [
            { "data": "tag" ,"bSortable": false, "sClass":"highlight"},
            { "data": "name" ,"bSortable": false},
            { "data": "type" ,"bSortable": false},
            { "data": "sm_pv" ,"bSortable": false},
            { "data": "sm_uv" ,"bSortable": false},
            { "data": "channel_pv" ,"bSortable": false },
            { "data": "channel_uv","searchable":false,"bSortable": false},
            {
                "data": "id",
                "bSortable": false,
                "render": function(data, type, full) {
                    return "<a class='glyphicon glyphicon-eye-open' name='channel-detail-control'></a>&nbsp;&nbsp;"+
                        "<a class='glyphicon glyphicon-chevron-down' name='history-data-control'></a>";
                }
            },
        ],
    });

    $('#channel_list tbody').on('click', '[name="channel-detail-control"]', function () {
        var tr = $(this).closest('tr');
        var row = channel_table.row( tr );
        viewChannel(row.data());
    });
    $('#channel_list tbody').on('click', 'td:nth-child(1)', function () {
        var tr = $(this).closest('tr');
        var row = channel_table.row( tr );
        viewChannel(row.data());
    });
    $('#row_detail_div #feat_date_range').daterangepicker();

    // Add event listener for opening and closing details
    $('#channel_list tbody').on('click', '[name="history-data-control"]', function () {
        var tr = $(this).closest('tr');
        var row = channel_table.row( tr );
        
        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            $(this).attr("class", "glyphicon glyphicon-chevron-down");
        }
        else {
            $(this).attr("class", "glyphicon glyphicon-chevron-up");
            // Open this row
            busy_html = get_busy_html(row.data().id);
            row.child(busy_html).show();
            row.child().addClass('no-hover')

            channel_id = row.data().id
            init_feat_date_range(
                $('#row_detail_div_' + channel_id + ' #feat_date_range'), 
                channel_id);
            refresh_range_feat(row.data().id);
            $('#row_detail_div_' + channel_id + ' #export_feature').click(
                function() {
                    $('#row_detail_div_' + channel_id + ' #table').table2excel(
                        {filename:row.data().tag}
                    );
                });
        }
    } );

    $("#channel_list_filter").hide();
    $("#channel_search").keyup(function() {
        channel_table.search($(this).val()).draw();
    });
})

function refresh_range_feat(channel_id) {
    result = query_channel_feat(
        channel_id, 
        function(result){
            if(result.status == 0) {
                dsp_data = make_dsp_data(result.data);
                table_html = make_dsp_html(
                    dsp_data.table_header,
                    dsp_data.table_lines,
                    dsp_data.times,
                    dsp_data.series);

                $('#row_detail_div_' + channel_id + ' #line_plot').show();
                $('#row_detail_div_' + channel_id + ' #line_plot').highcharts({
                    title: {text:'指标趋势'},
                    legend: {
                        layout: 'vertical',
                        align: 'right',
                        verticalAlign: 'middle',
                        borderWidth: 0
                    },
                    xAxis: {
                        categories: dsp_data.times,
                    },
                    series: dsp_data.series});
                $('#row_detail_div_' + channel_id + ' #table').html(table_html);
            } else {
                $('#row_detail_div_' + channel_id + ' #line_plot').hide();
                $('#row_detail_div_' + channel_id + ' #table')
                    .html("<div align='middle'><font color='red'>" + result.msg + "</font></div>");
            }
            $('#row_detail_div_' + channel_id + ' #busy_icon').hide();
        });
}

function make_dsp_html(
    table_header, table_lines, times, series) {
    table_html = '<table class="table table-bordered table-condensed" style="margin-bottom:8px"><thead>'
    for(var i = 0; i < table_header.length; i++) {
        table_html += '<th>' + table_header[i] + '</th>';
    }
    table_html += '</thead>';
    for(var i = 0; i < table_lines.length; i++) {
        table_html += '<tr>';
        for(var j = 0; j < table_lines[i].length; j++) {
            table_html += '<td>' + table_lines[i][j] + '</td>';
        }
        table_html += '</tr>';
    }
    table_html += '</table>'
    return table_html
}


dsp_tag_time = '时间'
dsp_tag_sm_pv = '神马输出流量'
dsp_tag_sm_uv = '神马输出用户'
dsp_tag_channel_pv = '站点导入流量'
dsp_tag_channel_uv = '站点导入用户'
function make_dsp_data(feats) {
    table_header = [dsp_tag_time, dsp_tag_sm_pv, dsp_tag_sm_uv, 
                    dsp_tag_channel_pv, dsp_tag_channel_uv]
    table_lines = []
    times = []
    line_spot_data = {}
    series = []
    for(var i = 0; i < feats.length; i++) {
        time = feats[i][1];
        sm_pv = feats[i][3];
        sm_uv = feats[i][4];
        channel_pv = feats[i][5];
        channel_uv = feats[i][6];

        table_lines.push([time, sm_pv, sm_uv, channel_pv, channel_uv])
        times.push(time)

        data = {}
        data[dsp_tag_sm_pv] = sm_pv;
        data[dsp_tag_sm_uv] = sm_uv;
        data[dsp_tag_channel_pv] = channel_pv;
        data[dsp_tag_channel_uv] = channel_uv;
        for(var key in data) {
            value = data[key];
            if(line_spot_data.hasOwnProperty(key)) {
                line_spot_data[key].push(value);
            } else {
                line_spot_data[key] = [value];
            }
        }
    }

    for(var key in line_spot_data) {
        series.push({'name': key,
                     'data': line_spot_data[key]})
    }

    return {table_header: table_header,
            table_lines: table_lines,
            times: times,
            series: series};
}

function viewChannel(row_data) {
    var res = false;
    var id = row_data.id;
    $.ajax({
        url: "/business_channel/get_info/" + id,
        async: false,
        success: function(result){
            if(result instanceof Object) {
                ark_notify(result);
                res = result.status == 0;
            } else {

                button = []
                if(row_data.has_delete_perm) {
                    button.push(                        {
                        value: "删除",
                        callback: function () {
                            return deleteChannel(id, view_dialog_id)
                        },
                    });
                }

                if(row_data.has_delete_perm) {
                    button.push(                        {
                        value: '编辑',
                        callback: function () {
                            return updateChannel(id, view_dialog_id)
                        },
                    });
                }


                var d = dialog({
                    title : '渠道详情',
                    id: view_dialog_id,
                    content : result,
                    width : 400,
                    fixed : true,
                    cancel: false,
                    okValue: '确定',
                    ok : true,
                    button: button,
                });
                d.showModal();
            }
        }   
    });
    return res;
}

function deleteChannel(id, view_dialog) {

    res = false;
    dialog({
        content: '确定删除渠道？',
        cancel: function() {},
        ok: function () {    
            $.ajax({
                url: "/business_channel/delete/" + id,
                success: function(result){
                    ark_notify(result);
                    res = result.status == 0;
                    if(res) {
                        dialog.get(view_dialog).remove();
                        channel_table.draw();
                    }        
                } 
            });
        },
        okValue: '确定',
        cancelValue: '取消',
        autofocus: false
    }).show();
    return res;
}


function updateChannel(id, view_dialog) {

    res = false;
    $.ajax({
        url: "/business_channel/update/" + id,
        type: "POST",
        async: false,
        success: function(result){
            if(result instanceof Object) {
                ark_notify(result);
                res = result.status == 0;
            } else {
                var d = dialog({
                    title : '渠道更新',
                    content : result,
                    width : 500,
                    height : 400,
                    fixed : true,
                    cancelValue: '取消',
                    cancel: true,
                    okValue: '更新',
                    ok : function() {
                        data = collectData();
                        res = createOrUpdate(data, id);
                        if(res) {
                            dialog.get(view_dialog).remove();
                            channel_table.draw();
                        }
                        return res;
                    },
                });
                d.showModal();
                initType();
                initUser();
                initUrl();
            }
        }   
    });
    return res;
}

function createChannel() {

    $.ajax({
        url: "/business_channel/create/",
        type: "POST",
        success: function(result){
            if(result instanceof Object) {
                ark_notify(result);
            } else {
                var d = dialog({
                    title : '渠道申请',
                    content : result,
                    width : 500,
                    height : 400,
                    fixed : true,
                    cancelValue: '取消',
                    cancel: true,
                    okValue: '应用',
                    ok : function() {
                        data = collectData();
                        res = createOrUpdate(data);
                        if(res) {
                            channel_table.draw();
                        }
                        return res;
                    },
                });
                d.showModal();
                initUrl();
                initUser();
            }
        }   
    });
}