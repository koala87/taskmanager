update_user_modal_id = "update_user_modal";

function beginUpdateUser() {
    $("#" + update_user_modal_id).modal().show();
}
function updateUser() {
    var items = ["email", "password"];
    var data = {};
    for(var i = 0; i < items.length; i++) {
        var key = items[i];
        data[key] = $("#" + update_user_modal_id + " #" + key).val();
    }

    var url = "/business_channel/update_user/";
    var ok = false;
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        dataType: "json",
        traditional: true,
        data: data,
        success: function(result) {
            ark_notify(result);
            ok = result.status == 0;
            if(ok) {
                $("#" + update_user_modal_id).hide();
            }
        },
        error: function(result) {
            result['msg'] = '服务出错';
            ark_notify(result);
        }
    });
    return ok;
}
