var host_table = null;
var url_data_table;
var global_pl_id = 0;
var global_data_source = 0;

function showMessage(type,title,msg){
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg){
    showMessage("error","错误提示",msg);
}

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10);
}

function query_co_submit() {
    var tb = document.getElementById('co_presence');
    var rowNum = tb.rows.length;
    for (i = 0; i < rowNum; i++) {
        tb.deleteRow(i);
        rowNum = rowNum - 1;
        i = i - 1;
    }
    var tb = document.getElementById('co_relative');
    var rowNum = tb.rows.length;
    for (i = 0; i < rowNum; i++) {
        tb.deleteRow(i);
        rowNum = rowNum - 1;
        i = i - 1;
    }

    $('#wait_busy_icon').show();
    $('#submit_button').attr('disabled', "true");
    url = "/co_presence/list/"
    $.ajax({
        url: '/co_presence/list/',
        type: 'post',
        dataType: 'json',
        async: true,
        data: { "query": $('#query').val() },
        success: function (result) {
            $('#wait_busy_icon').hide();
            $('#submit_button').removeAttr("disabled");
            if (result.status == 0) {
                if (result.co_presence <= 0 && result.relative <= 0) {
                    showErrorMessage("没有数据!");
                    return;
                }
                show_re_query(result.relative);
                show_co_query(result.co_presence);
            } else {
                showErrorMessage("没有数据!");
            }
        }
    });
}


function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0, 10);
}

function show_co_query(co_presence_list) {
    var row = document.createElement("tr");
    document.getElementById("co_presence").appendChild(row);
    table = ["共现query", "score"];
    for (cell in table) {
        var key_cell = document.createElement("td");
        key_cell.innerText = table[cell];
        key_cell.style.fontWeight = "bold";
        row.appendChild(key_cell);
    }

    date = get_pre_date(1);
    for (var i = 0; i < co_presence_list.length; i++) {
        var row = document.createElement("tr");
        document.getElementById("co_presence").appendChild(row);
        var key_cell = document.createElement("td");
        inner_html = co_presence_list[i].query;
        src_html = inner_html
        inner_html = inner_html.replace(new RegExp("\002", 'gm'), "#");
        inner_html = inner_html.replace(new RegExp("\005", 'gm'), "'");
        inner_html_list = inner_html.split('?');
        inner_html = inner_html_list[0];
        for (var inner_idx = 1; inner_idx < inner_html_list.length; ++inner_idx) {
            inner_html += '\003' + inner_html_list[inner_idx];
        }

        inner_html = '<a style = "text-decoration:none;" href="/query_search/other_list/' + inner_html + '\001' + date + '/" target="_blank">&nbsp;&nbsp;' + src_html + '</a>';
        key_cell.innerHTML = inner_html;
        row.appendChild(key_cell);

        var key_cell = document.createElement("td");
        inner_html = co_presence_list[i].score;
        key_cell.innerHTML = inner_html;
        row.appendChild(key_cell);

    }
}

function show_re_query(relative_list) {
    var row = document.createElement("tr");
    document.getElementById("co_relative").appendChild(row);
    table = ["相似query", 'left_click', 'right_click'];
    for (cell in table) {
        var key_cell = document.createElement("td");
        key_cell.innerText = table[cell];
        key_cell.style.fontWeight = "bold";
        row.appendChild(key_cell);
    }

    date = get_pre_date(1);
    for (var i = 0; i < relative_list.length; i++) {
        var row = document.createElement("tr");
        document.getElementById("co_relative").appendChild(row);
        var key_cell = document.createElement("td");
        inner_html = relative_list[i].query;
        src_html = inner_html
        inner_html = inner_html.replace(new RegExp("\002", 'gm'), "#");
        inner_html = inner_html.replace(new RegExp("\005", 'gm'), "'");
        inner_html_list = inner_html.split('?');
        inner_html = inner_html_list[0];
        for (var inner_idx = 1; inner_idx < inner_html_list.length; ++inner_idx) {
            inner_html += '\003' + inner_html_list[inner_idx];
        }

        inner_html = '<a style = "text-decoration:none;" href="/query_search/other_list/' + inner_html + '\001' + date + '/" target="_blank">&nbsp;&nbsp;' + src_html + '</a>';
        key_cell.innerHTML = inner_html;
        row.appendChild(key_cell);

        var key_cell = document.createElement("td");
        inner_html = relative_list[i].left_click;
        key_cell.innerHTML = inner_html;
        row.appendChild(key_cell);

        var key_cell = document.createElement("td");
        inner_html = relative_list[i].right_click;
        key_cell.innerHTML = inner_html;
        row.appendChild(key_cell);
    }
}

$(function () {
    if ($('#other_query').val() != "") {
        $('#query').val($('#other_query').val());
        query_co_submit();
    }

});
function mousewheelEvent(e, delta) {
    $(".daterangepicker").eq(0).css("display","none");    
}
