var host_table = null;
var query_data_table;
var global_pl_id = 0;
var global_data_source = 0;

function showMessage(type,title,msg){
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg){
    showMessage("error","错误提示",msg);
}

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10);
}

function query_sieving_submit(mode) {
    // mode = 0 单条query查询
    // mode = 1 多条query查询
    // mode = 2 文件查询
    $('#wait_busy_icon').show();
    $('#submit_button').attr('disabled', "true");
    $('#query_mode').val(mode);
    if (mode == 0) {
        $("#file").val("");
    } else if (mode == 1) {
        $("#time_field").val($('#batch_time').val());
        $("#query_match_mode").val($('#batch_match_mode').val());
    }

    if ($("#file").val() != "") {
        mode = 2;
        $('#query_mode').val(2);
    } else {
        $("#batch_file_name").val("");
    }

    if (mode == 1) {
        query = $('#querys').val();
        query_split = query.split('\n');
        if (query_split.length > 100) {
            showErrorMessage("输入框批量查询条数不能超过100！");
            return;
        }
    }
    var sbtitle=document.getElementById('batch_query_dialog');
    sbtitle.style.display='none';

    url = "/query_search/list/"
    query_data_table.ajax.url(url).load();
}

function batch_query() {    
    var sbtitle=document.getElementById('batch_query_dialog');
    sbtitle.style.display='block';

    $("#batch_query_dialog").modal({
        backdrop:false,
        show:true,        
    });
    $("#a").val("");
    $("#batch_time").val($('#time_field').val());
    $("#batch_match_mode").val($('#query_match_mode').val());
    $("#file").val('');
}

function download_data() {
    if ($('#query').val() == "" && $("#file").val() == "" && $('#querys').val() == "") {
        return;
    }
    query_mode = $('#query_mode').val()
    query = "";
    if (query_mode == 0) {
        query = $('#query').val();
    } else if (query_mode == 1) {
        query = $('#querys').val();
        query = query.replace(new RegExp("\r",'gm'),'');
        query = query.replace(new RegExp("\n",'gm'),'`');
    }
    date_period = $('#time_field').val();
    match_mode = $('#query_match_mode').val();
    file_name = $("#batch_file_name").val();
    window.open('/query_search/download/' + match_mode + '&' + date_period +  '&' + query + '&' + file_name + '/');
}

function upload_file() {
    $("#upload_busy").show();
    $("#batch_file_name").val("");
    var form_data = new FormData($("#formid")[0]); 
    $.ajax({
        url: '/query_search/handle_uploaded_file/',
        type: 'POST',  
        data: form_data,  
        cache: false,  
        contentType: false,  
        processData: false,         
        success: function (result) {
            $("#upload_busy").hide();
            if (result.status == 0) {
                $("#batch_file_name").val(result.file_name);
                showMessage("info", "信息", "上传文件成功");
            } else {
                $("#a").val("");
                $("#file").val("");
                showMessage("error", "失败", result.info);
            }
        }
    });
}

function click_show_query(query) {
    $("#preview_div", window.parent.document).modal("hide");
    $('#query').val(query);
    query_sieving_submit(0);
}

var show_pv_table = new Array("时间", "PV");
var show_click_table = new Array("url或sc", "点击数", "ctr");
var avg_pos_click_table = new Array("pos", "点击数", "ctr");
var uid_table = new Array("uid", "访问次数", "城市", "系统");
var query_table = new Array("共现query", "共现pv");

function create_config_table(data_list, mode) {
    if (data_list.length > 0) {
        var row = document.createElement("tr");
        document.getElementById("_table").appendChild(row);
        table = null;
        if (mode == "show_pv") {
            table = show_pv_table;
        } else if (mode == "show_click") {
            table = show_click_table;
        } else if (mode == "show_avg_pos_click") {
            table = avg_pos_click_table;
        } else if (mode == "show_uid") {
            table = uid_table;
        } else if (mode == "show_query") {
            table = query_table;
        } else {
            return;
        }

        for (cell in table) {
            var key_cell = document.createElement("td");
            key_cell.innerText = table[cell];
            key_cell.style.fontWeight="bold";
            row.appendChild(key_cell);
        }

        for (var i = 0; i < data_list.length; i++) {
            var row = document.createElement("tr");
            document.getElementById("_table").appendChild(row);
            for (var field_idx = 0; field_idx < data_list[i].length; ++field_idx) {
                var key_cell = document.createElement("td");
                inner_html = data_list[i][field_idx];
                if (field_idx == 0 && mode == "show_click") {
                    if (inner_html.indexOf("http://") == 0) {
                        src_url = inner_html;
                        inner_html_list = inner_html.split('?');
                        inner_html = inner_html_list[0];
                        for (var iner_idx = 1; iner_idx < inner_html_list.length; ++iner_idx) {
                            inner_html += "\003" + inner_html_list[iner_idx];
                        }
                        inner_html = inner_html.replace(new RegExp("/",'gm'),'\002');
                        inner_html = inner_html.replace(new RegExp("#",'gm'),'\004');
                        inner_html = '<a style="text-decoration:none;" href="/url_search/other_list/' + inner_html + '\001' + $("#time_field").val() + '/" target="_blank">' + src_url + '</a>';
                    }
                }

                if (field_idx == 0 && mode == "show_uid") {
                    inner_html = '<a style="text-decoration:none;" href="/session_search/other_list/' + inner_html + '\001' + $("#time_field").val() + '/" target="_blank">' + inner_html + '</a>';
                }

                if (field_idx == 0 && mode == "show_query") {
                    inner_html = '<a style="text-decoration:none;" href="javascript:void(0);" onclick="click_show_query(\'' + inner_html + '\');">'  + inner_html + '</a>';
                }
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);
            }
        }
    } else {
            var row = document.createElement("tr");
            document.getElementById("_table").appendChild(row);
            var key_cell = document.createElement("td");
            key_cell.innerHTML = "没有数据......";
            row.appendChild(key_cell);
    }
}

function reset_table(mode) {    
    table = null;
    if (mode == "show_pv") {
        tilte_name = "分天PV";
        table = show_pv_table;
    } else if (mode == "show_click") {
        table = show_click_table;
        tilte_name = "点击分布（最近一天）";
    } else if (mode == "show_avg_pos_click") {
        table = avg_pos_click_table;
        tilte_name = "点击位置分布（最近一天）";
    } else if (mode == "show_uid") {
        table = uid_table;
        tilte_name = "uid分布";
    } else if (mode == "show_query") {
        table = query_table;
        tilte_name = "共现query分布";
    } else {
        return;
    }


    $('#title_name').html(tilte_name + '&nbsp;<img id="show_data_busy" src="/static/images/busy.gif" style="margin-top:0px; display: none;" />');
    var tb = document.getElementById('_table');
    var rowNum=tb.rows.length;
    for (i=0;i<rowNum;i++) {
        tb.deleteRow(i);
        rowNum=rowNum-1;
        i=i-1;
    }

    var row = document.createElement("tr");
    document.getElementById("_table").appendChild(row);
    for (cell in table) {
        var key_cell = document.createElement("td");
        key_cell.innerText = table[cell];
        key_cell.style.fontWeight="bold";
        if (mode == "show_click" && table[cell] == "url或sc") {
            key_cell.width = 350;
        }

        if (mode == "show_uid" && table[cell] == "uid") {
            key_cell.width = 300;
        }
        row.appendChild(key_cell);
    }
}

function show_pv(data_str) {
    reset_table("show_pv");
    $("#preview_div", window.parent.document).modal('show');
    data_list = data_str.split(",");
    for (var i = 0; i < data_list.length; i++) {
        var row = document.createElement("tr");
        document.getElementById("_table").appendChild(row);
        split_pv = data_list[i].split("\t");

        var key_cell_0 = document.createElement("td");
        inner_html = split_pv[0];
        key_cell_0.innerHTML = inner_html;
        row.appendChild(key_cell_0);

        var key_cell_1 = document.createElement("td");
        inner_html = split_pv[1];
        key_cell_1.innerHTML = inner_html;
        row.appendChild(key_cell_1);
    }
}

function show_click(query) {  
    reset_table("show_click");
    $("#preview_div", window.parent.document).modal('show');
    $('#show_data_busy').show();
    $.ajax({
        url: '/query_search/show_click/',
        type: 'post',
        dataType: 'json',
        async: true,
        data: { "query": query, "date_period": $('#time_field').val() },
        success: function (result) {
            $('#show_data_busy').hide();
            if (result.status == 0) {
                if (result.data.length <= 0) {
                    showErrorMessage("没有数据!");
                    return;
                }
                data_list = result.data.split("^");
                for (var i = 0; i < data_list.length; i++) {
                    var row = document.createElement("tr");
                    document.getElementById("_table").appendChild(row);
                    split_url = data_list[i].split(":");

                    var key_cell_0 = document.createElement("td");
                    inner_html = split_url[1];
                    for (var url_idx = 2; url_idx < split_url.length; ++url_idx) {
                        inner_html += ":" + split_url[url_idx];
                    }

                    if (inner_html.indexOf("http://") >= 0 || inner_html.indexOf("https://") >= 0 ) {
                        src_url = inner_html;
                        inner_html_list = inner_html.split('?');
                        inner_html = inner_html_list[0];
                        for (var iner_idx = 1; iner_idx < inner_html_list.length; ++iner_idx) {
                            inner_html += "\003" + inner_html_list[iner_idx];
                        }
                        inner_html = inner_html.replace(new RegExp("/",'gm'),'\002');
                        inner_html = inner_html.replace(new RegExp("#",'gm'),'\004');
                        inner_html = '<a style="text-decoration:none;" href="/url_search/other_list/' + inner_html + '\001' + $("#time_field").val() + '/" target="_blank">' + src_url + '</a>';
                    }

                    key_cell_0.innerHTML = inner_html;
                    row.appendChild(key_cell_0);
                    var key_cell_1 = document.createElement("td");
                    inner_html = split_url[0];

                    key_cell_1.innerHTML = inner_html;
                    row.appendChild(key_cell_1);

                    var key_cell_2 = document.createElement("td");
                    tmp_val = split_url[0] / result.pv * 100;
                    tmp_val = tmp_val.toFixed(3) + '%';
                    key_cell_2.innerHTML = tmp_val;
                    row.appendChild(key_cell_2);
                }
            } else {
                showErrorMessage("没有数据!");
            }
        }
    });
}

function show_averge_click_pos(pos_str) {
    reset_table("show_avg_pos_click");
    $("#preview_div", window.parent.document).modal('show');

    tmp_split = pos_str.split("\t");
    pv = parseInt(tmp_split[1])
    data_list = tmp_split[0].split("^");
    for (var i = 0; i < data_list.length; i++) {
        var row = document.createElement("tr");
        document.getElementById("_table").appendChild(row);
        split_pos = data_list[i].split(":");

        var key_cell_0 = document.createElement("td");
        inner_html = split_pos[0];
        key_cell_0.innerHTML = inner_html;
        row.appendChild(key_cell_0);

        var key_cell_1 = document.createElement("td");
        inner_html = split_pos[1];
        key_cell_1.innerHTML = inner_html;
        row.appendChild(key_cell_1);

        var key_cell_2 = document.createElement("td");
        tmp_val = split_pos[1] / pv * 100;
        tmp_val = tmp_val.toFixed(3) + '%';
        key_cell_2.innerHTML = tmp_val;
        row.appendChild(key_cell_2);
    }
}

function show_uid(query) {    
    reset_table("show_uid");
    $("#preview_div", window.parent.document).modal('show');
    $('#show_data_busy').show();

    $.ajax({
        url: '/query_search/show_uid/',
        type: 'post',
        dataType: 'json',
        async: true,
        data: { "query": query, "date_period": $('#time_field').val() },
        success: function (result) {
            $('#show_data_busy').hide();
            if (result.status == 0) {
                if (result.data.length <= 0) {
                    showErrorMessage("没有数据!");
                    return;
                }
                for (var i = 0; i < result.data.length; i++) {
                    var row = document.createElement("tr");
                    document.getElementById("_table").appendChild(row);

                    var key_cell_0 = document.createElement("td");
                    inner_html = result.data[i].uid;
                    inner_html = '<a style="text-decoration:none;" href="/session_search/other_list/' + inner_html + '\001' + $("#time_field").val() + '/" target="_blank">' + inner_html + '</a>';
                    key_cell_0.innerHTML = inner_html;
                    row.appendChild(key_cell_0);

                    var key_cell_1 = document.createElement("td");
                    key_cell_1.innerHTML = result.data[i].session_count;
                    row.appendChild(key_cell_1);

                    var key_cell_2 = document.createElement("td");
                    key_cell_2.innerHTML = result.data[i].city;
                    row.appendChild(key_cell_2);

                    var key_cell_3 = document.createElement("td");
                    key_cell_3.innerHTML = result.data[i].os;
                    row.appendChild(key_cell_3);
                }
            } else {
                showErrorMessage("没有数据!");
            }
        }
    });
}

function show_line_query(query) {
    show_data(query, "/query_search/show_query/", "show_query");
}

function search_query(query) {
    $('#query').val(query);
    query_sieving_submit(0);
}

$(function(){
    resetLeftMenuStyle();
    $("#file").change(function() {
        $("#a").val($("#file").val());
        if ($("#file").val() != "") {
            upload_file();
        }
    });

    query_data_table = $('#query_search_table').DataTable({
        "processing": true,
        "serverSide": true,
        "paging": false,
        "searching": false,
        "ajax": {
            "url": "/query_search/list/",
            "type": "POST",
            "data": function ( d ) {
                query_mode = $('#query_mode').val()
                if (query_mode == 0) {
                    d.query = $('#query').val();
                } else if (query_mode == 1) {
                    d.query = $('#querys').val();
                } else {
                    d.query = "";
                }
                d.date_period = $('#time_field').val();
                d.match_mode = $('#query_match_mode').val();
                d.file_name = $("#batch_file_name").val();
            }
        },
        "columnDefs": [
            {
                "targets": [0],
                "searchable": false,
                "bSortable": false,
                "data": "query",
                "render": function(data, type, full) {
                    return '<a  href="javascript:void(0)" onclick="search_query(\'' + full.query + '\');" style="text-decoration:none;">' + full.query + '</a>';
                }
            },
            {
                "targets": [1],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return '<a  href="javascript:void(0)" onclick="show_pv(\'' + full.pv_list + '\');" style="text-decoration:none;">' + full.pv + '</a>';
                }
            },
            {
                "targets": [2],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return '<a href="javascript:void(0)" onclick="show_click(\'' + full.query + '\');" style="text-decoration:none;">' + full.clk + '</a>';
                }
            },
            {
                "targets": [3],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return '<a href="javascript:void(0)" onclick="show_averge_click_pos(\'' + full.clk_pos + '\');" style="text-decoration:none;">' + full.sum_clk_pos + '</a>';
                }
            },
            {
                "targets": [4],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    var f = parseFloat(full.clk / full.pv);
                    return f.toFixed(4);
                }
            },
            {
                "targets": [5],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return full.sc_clk;
                }
            },
            {
                "targets": [6],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return full.voice_pv;
                }
            },
            {
                "targets": [7],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return full.android_pv;
                }
            },
            {
                "targets": [8],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return full.android_clk;
                }
            },
            {
                "targets": [9],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return full.feed_click;
                }
            },
            {
                "targets": [10],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return full.feed_avg;
                }
            },
            {
                "targets": [11],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return '<a href="javascript:void(0)" onclick="show_uid(\'' + full.query + '\');" style="text-decoration:none;">[ 查看 ]</a>';
                }
            },
            {
                "targets": [12],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    query = full.query.replace(new RegExp("#",'gm'),'\001');
                    return '<a href="/co_presence/other_list/' + query + '/" style="text-decoration:none;" target="_blank">[ 查看 ]</a>';
                }
            },
            {
                "targets": [13],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    return '<a href="http://qp_92.proxy.taobao.org/api/query_classify?q=' + full.query + '" style="text-decoration:none;" target="_blank">[ 查看 ]</a>';
                }
            },
        ],
        "iDisplayLength": 100,
    });

    query_data_table.on( 'draw.dt', function () {
        $('#wait_busy_icon').hide();
        $('#submit_button').removeAttr("disabled");
    } );


    end_date = yesterday = get_pre_date(1);
    start_date = end_date;
    last_week = get_pre_date(7);
    last_month = get_pre_month(1);
    $('#time_field').daterangepicker(
            {
                "ranges": {
                    "昨天": [
                        yesterday,
                        yesterday
                    ],
                    "近一周": [
                        last_week,
                        yesterday
                    ],
                    "近一个月": [
                        last_month,
                        yesterday
                    ],
                },
                "locale": {
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "fromLabel": "From",
                    "toLabel": "To",
                    "customRangeLabel": "自定义时间",
                    "daysOfWeek": [
                        "日", 
                        "一", 
                        "二", 
                        "三", 
                        "四", 
                        "五", 
                        "六"
                    ],
                    "monthNames": [
                        "一月",  
                        "二月",  
                        "三月",  
                        "四月",
                        "五月",
                        "六月",
                        "七月",
                        "八月",
                        "九月",
                        "十月",
                        "十一月",
                        "十二月"
                    ],
                    "firstDay": 1
                },
                opens: (App.isRTL() ? 'left' : 'right'),
                format: 'yyyy-MM-dd',
                separator: ' to ',
                startDate: yesterday,
                endDate: yesterday,
                minDate: last_month,
                maxDate: yesterday
            }
        );
    $('#batch_time').daterangepicker(
            {
                "ranges": {
                    "昨天": [
                        yesterday,
                        yesterday
                    ],
                    "近一周": [
                        last_week,
                        yesterday
                    ],
                    "近一个月": [
                        last_month,
                        yesterday
                    ],
                },
                "locale": {
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "fromLabel": "From",
                    "toLabel": "To",
                    "customRangeLabel": "自定义时间",
                    "daysOfWeek": [
                        "日", 
                        "一", 
                        "二", 
                        "三", 
                        "四", 
                        "五", 
                        "六"
                    ],
                    "monthNames": [
                        "一月",  
                        "二月",  
                        "三月",  
                        "四月",
                        "五月",
                        "六月",
                        "七月",
                        "八月",
                        "九月",
                        "十月",
                        "十一月",
                        "十二月"
                    ],
                    "firstDay": 1
                },
                opens: (App.isRTL() ? 'left' : 'right'),
                format: 'yyyy-MM-dd',
                separator: ' to ',
                startDate: yesterday,
                endDate: yesterday,
                minDate: last_month,
                maxDate: yesterday
            }
        );
    $("#time_field").val(start_date+" to "+end_date);
    $(document).mousewheel(function(event, delta) {
        mousewheelEvent(event,delta);
    });

    if($('#other_query').val() != ""){
        $('#query').val($('#other_query').val());
        $('#query_mode').val(0);
        $('#time_field').val($('#other_date_period').val());
        $('#query_match_mode').val(0);
        $("#batch_file_name").val("");
        url = "/query_search/list/"
        query_data_table.ajax.url(url).load();
    }
});
function mousewheelEvent(e, delta) {
    $(".daterangepicker").eq(0).css("display","none");    
}
