$(function() {
    window.PanguFile = {
        is_dir: function(str) {
            return str.substr(-1) === '/';
        },
        mk_item_display: function(str) {
            var is_dir = PanguFile.is_dir(str) ? 1 : 0;
            return '<tr><td><a name="pangu_file_item" is_dir="' + is_dir + '">' + str + '</a><td></tr>';
        },
        ls: function(dir, callback) {
            var url = '/common/pangu/ls/';
            makeAPost(url, {'dir': dir}, true, function(result) {
                callback(result);
            });
        },
        mk_display_str: function(items) {
            var str = '<table>';
            for(var i in items) {
                str += PanguFile.mk_item_display(items[i]);
            }
            str += '</table>';
            return str;
        },
        display: function(result) {
            if(result.status != 0) {
                ark_notify(result);
                $("[name=file_list]").html('<font color="red">' + result.msg + '</font>');
            } else {
                var str = PanguFile.mk_display_str(result.data);
                $("[name=file_list]").html(str);
            }
        },
        load: function() {
            var dir = $("[name=file_list]").attr('dir');
            result = PanguFile.ls(dir, PanguFile.display);
        }
    }
    PanguFile.load();
    $(document).on('click', "[name=pangu_file_item]", function(){
        var dir = $("[name=file_list]").attr('dir');
        var item = $(this).html();
        window.location.href = '/common/pangu/download_file/?file_path=' + dir + item;
    });
});

