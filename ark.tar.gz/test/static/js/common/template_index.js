function contact_us(){
    var wangwang_url_start = "http://amos.alicdn.com/msg.aw?v=2&uid=";
    var wangwang_url_end = "&site=cntaobao&s=11&charset=UTF-8";
    desc = '<div style="width:430px;">&nbsp;刘建锋 旺旺：<a href="'+wangwang_url_start+'ciwind'+wangwang_url_end+'" target="_blank" title="旺旺联系">ciwind</a></div>' + 
            '<div style="width:430px;">&nbsp;郭威 旺旺：<a href="'+wangwang_url_start+'冻结年代'+wangwang_url_end+'" target="_blank" title="旺旺联系" >冻结年代</a></div>' +
            '<div style="width:430px;">&nbsp;荣航 旺旺：<a href="'+wangwang_url_start+'思舞飞扬1218'+wangwang_url_end+'" target="_blank" title="旺旺联系" >思舞飞扬1218</a></div>' +
            '<div style="margin-top:20px"><a href="javascript:void(0)"'+
            ' onclick="send_mail()"><i class="fa fa-envelope fa-fw"></i>'+
            '&nbsp;联系我们</a></div>';

    var d = dialog({
        title : '联系方式',
        content : desc,
        okValue: '确定',
        ok: true,
    });
    d.showModal();
}

function send_mail(obj){
    var email = $(obj).html();
    var emails = "jianfeng.liu@shenma-inc.com;wei.guo@shenma-inc.com;hang.rong@shenma-inc.com";
    var link = "mailto:jianfeng.liu@shenma-inc.com" 
        + "?cc=wei.guo@shenma-inc.com;hang.rong@shenma-inc.com;"
        + "&subject=用户反馈"
        +"&body=我要反馈的内容如下:";
    location.href = link;
}

function contact_wangwang(obj){
    var my_wangwang = $(obj).html();
    var wangwang_url = "http://amos.alicdn.com/getcid.aw?v=3&site=cntaobao&groupid=0&uid="+my_wangwang;
    location.href = wangwang_url;
}

$(function(){
    
    $('#dropdown-menu-pipeline').on('mouseover', function(){
        $('#dropdown-menu-ul-list').show();
    });
    $('#dropdown-menu-pipeline').on('mouseout', function(){
        $('#dropdown-menu-ul-list').hide();
    });

});
