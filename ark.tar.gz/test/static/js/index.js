$(function () {
    window.CircularNav = {
        init: function(radius) {
            if(radius == undefined) {
                radius = 70;
            }
            var items = document.querySelectorAll('.circleNavi .sys-nav');
            for(var i = 0, l = items.length; i < l; i++) {
                items[i].style.left = (radius - 14 - radius*Math.cos(-0.5 * Math.PI - 2*(1/l)*i*Math.PI)).toFixed(4) + "%";
                
                items[i].style.top = (radius - 161 + radius*Math.sin(-0.5 * Math.PI - 2*(1/l)*i*Math.PI)).toFixed(4) + "%";
            }
        },
        chose: function(radius) {

        }
    }
    CircularNav.init();
    document.querySelector('.circleNavi').classList.toggle('open');

    $("div.sys-nav").click(function() {
        $("div.sys-nav").removeClass("nav-active");
        $(this).addClass("nav-active");
    });
    $(".navbtn").click(function() {
        $("div.sys-nav").removeClass("nav-active");
    });
});

