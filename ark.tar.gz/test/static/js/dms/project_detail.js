var modal_processing_flag = false;
var data_num_deleted = 0;
var data_num_added = 0;
var data_old_list = [];

var member_num_deleted = 0;
var member_num_added = 0;
var member_old_list = [];
$(function(){
    get_full_data_list();
    flush_member_list();
    $(document).on("change", ".project_data_list_select2", function (e) { 
        if(e.removed != undefined)
        {
            if(data_old_list.indexOf(e.removed.id) >= 0) 
            {
                data_num_deleted += 1;
            }
            else
            {
                data_num_added -= 1;
            }
        }
        else if(e.added != undefined)
        {
            if(data_old_list.indexOf(e.added.id) >= 0) 
            {
                data_num_deleted -= 1;
            }
            else
            {
                data_num_added += 1;
                $(".project_data_list_select2 .select2-choices .select2-search-choice:last").css('background-color', '#D9F5FF');
            }
        }
        $("#dataManageModal .modal-body #change_record").remove();
        $("#dataManageModal .modal-body").append('<p id="change_record">你本次移除了 <font color="red">'+data_num_deleted+'</font> 个共享数据，新添加了 <font color="red">'+data_num_added+'</font> 个共享数据</p>');
    });

    $(document).on("change", ".project_member_list_select2", function (e) { 
        if(e.removed != undefined)
        {
            if(member_old_list.indexOf(e.removed.id) >= 0) 
            {
                member_num_deleted += 1;
            }
            else
            {
                member_num_added -= 1;
            }
        }
        else if(e.added != undefined)
        {
            if(member_old_list.indexOf(e.added.id) >= 0) 
            {
                member_num_deleted -= 1;
            }
            else
            {
                member_num_added += 1;
                $(".project_member_list_select2 .select2-choices .select2-search-choice:last").css('background-color', '#D9F5FF');
            }
        }
        $("#memberManageModal .modal-body #change_record").remove();
        $("#memberManageModal .modal-body p").before('<p id="change_record">你本次移除了 <font color="red">'+member_num_deleted+'</font> 个成员，新添加了 <font color="red">'+member_num_added+'</font> 个成员</p>');
    });
    $('#dataManageModal, #memberManageModal, #dismissProjectConfirmModal').on('hide.bs.modal', function (e) {
        if(modal_processing_flag)
        {
            e.preventDefault();
            return false;
        }
    });
});
function manage_data()
{
    $("#data_manager").button('loading');
    var url = '/dms/get_project_all_datas/';
    var post_data = {id:project_id};
    var callback = callback_get_project_all_data_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_project_all_data_list(result, args)
{
    //初始化修改记录
    data_num_deleted = 0;
    data_num_added = 0;
    data_old_list = [];

    $("#data_manager").button('reset');
    var html = '<select class="form-control project_data_list_select2" multiple="multiple">';
    for(var i in result.data_list)
    {
        var selected_str = '';
        if(result.data_list[i]['selected'])
        {
            data_old_list.push(result.data_list[i]['id'].toString());
            selected_str = 'selected'
        }
        html += '<option '+selected_str+' value="'+result.data_list[i]['id']+'">'+result.data_list[i]['name']+'</option>';
    }
    html += '</select>';
    $("#dataManageModal .modal-body").html(html);
    $(".project_data_list_select2").select2({
        placeholder: '请添加你想要共享的数据..',
        language: 'ch',
    });
    $("#dataManageModal").modal('show');
}
function do_data_manage_data()
{
    $("#btn_manage_data_ok").button('loading');
    modal_processing_flag = true;
    var url = '/dms/project_update_data/';
    var post_data = {id:project_id, 'ids':$("select.project_data_list_select2").val()};
    var callback = callback_do_data_manage_data;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_data_manage_data(result, args)
{
    $("#btn_manage_data_ok").button('reset');
    modal_processing_flag = false;
    ark_notify(result);
    if(result.status == 0)
    {
        get_full_data_list();
        $("#dataManageModal").modal('hide');
    }
}
function get_full_data_list()
{
    show_div_loading($("#shared_data_list_table tbody"));
    var url = '/dms/get_project_datas/';
    var post_data = {id:project_id};
    var callback = callback_get_full_data_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_full_data_list(result, args)
{
    var html = '';
    if(result.status ==0)
    {
        for(var i in result.data_list)
        {
            html += '<tr>';
            html += '<td>'+(parseInt(i)+1).toString()+'</td>';
            html += '<td><a title="点击查看详情" href="/dms/manager_data_detail/?data_id='+result.data_list[i]['id']+'&cid=1" target="_blank">'+result.data_list[i]['name']+'</a></td>';
            html += '<td>'+result.data_list[i]['description']+'</td>';
            html += '<td>'+result.data_list[i]['owner_dsp']+'</td>';
            html += '</tr>';
        }
    }
    html == '' ? html = '<p style="width: 100px;">暂无数据</p>' : '';
    $("#shared_data_list_table tbody").html(html);
}
function dismiss_project()
{
    $("#dismissProjectConfirmModal #btn_dismiss_project_ok").button('loading');
    modal_processing_flag = true;
    var url = '/dms/project_delete/';
    var post_data = {'id':project_id};
    var callback = callback_dismiss_project;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_dismiss_project(result, args)
{
    $("#dismissProjectConfirmModal #btn_dismiss_project_ok").button('reset');
    modal_processing_flag = false;
    ark_notify(result);
    if(result.status == 0)
    {
        $("#dismissProjectConfirmModal").modal('hide');
        window.location = '/dms/project_index/';
    }
}
function show_member_modal()
{
    $("#menbers_manager").button('loading');
    var url = '/dms/get_project_all_users/';
    var post_data = {id:project_id};
    var callback = callback_show_member_modal;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_member_modal(result, args)
{
    //初始化修改记录
    member_num_deleted = 0;
    member_num_added = 0;
    member_old_list = [];
    $("#menbers_manager").button('reset');
    var html = '<select class="form-control project_member_list_select2" multiple="multiple">';
    for(var i in result.user_list)
    {
        var selected_str = '';
        if(result.user_list[i]['selected'])
        {
            member_old_list.push(result.user_list[i]['id'].toString());
            selected_str = 'selected'
        }
        html += '<option '+selected_str+' value="'+result.user_list[i]['id']+'">'+result.user_list[i]['username_dsp']+'</option>';
    }
    html += '</select><p>注意：项目成员必须在个人信息处完善odps相关信息</p>';
    $("#memberManageModal .modal-body").html(html);
    $(".project_member_list_select2").select2({
        placeholder: '请添加成员..',
        language: 'ch',
    });
    $("#memberManageModal").modal('show');
}
function do_manage_member()
{
    $("#btn_manage_menber_ok").button('loading');
    modal_processing_flag = true;
    var url = '/dms/project_update_user/';
    var post_data = {id:project_id, 'ids':$("select.project_member_list_select2").val()};
    var callback = callback_do_member_manage_data;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_member_manage_data(result, args)
{
    $("#btn_manage_menber_ok").button('reset');
    modal_processing_flag = false;
    ark_notify(result);
    if(result.status == 0)
    {
        flush_member_list();
        $("#memberManageModal").modal('hide');
    }
}
function flush_member_list()
{
    show_div_loading($("#member_list"));
    var url = '/dms/get_project_users/';
    var post_data = {id:project_id};
    var callback = callback_flush_member_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_flush_member_list(result, args)
{
    var html = '';
    if(result.status == 0)
    {
        html += '<div class="row">\
                     <span class="member_name">'+result.user_list[0].username_dsp+'</span>\
                     <span class="member_type"><img src="/static/images/dms/project_icon_admin.png"></img>管理员</span>\
                 </div>';
        for(var i in result.user_list[1])
        {
            html += '<div class="row">\
                         <span class="member_name">'+result.user_list[1][i].username_dsp+'</span>\
                         <span class="member_type"><img src="/static/images/dms/project_icon_member.png"></img>成员</span>\
                     </div>';
        }
    }
    $("#member_list").html(html);
    hide_div_loading($("#member_list"));
}
function update_project()
{
    $("#btn_update_project").button('loading');
    var url = '/dms/get_project_info/';
    var post_data = {id:project_id};
    var callback = callback_update_project;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_update_project(result, args)
{
    $("#btn_update_project").button('reset');
    if(result.status ==0)
    {
        $("#updateProjectModal #project_name").val(result.info.name);
        $("#updateProjectModal #project_desc").val(result.info.description);
    }
    $("#updateProjectModal").modal('show');
}
function do_update_project()
{
    $("#btn_update_project_ok").button('loading');
    var url = '/dms/update_project/';
    var post_data = {id:project_id, name:$("#updateProjectModal #project_name").val().trim(), desc:$("#updateProjectModal #project_desc").val().trim()};
    var callback = callback_do_update_project;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_update_project(result, args)
{
    $("#btn_update_project_ok").button('reset');
    ark_notify(result);
    if(result.status ==0)
    {
        $("#updateProjectModal").modal('hide');
    }
}
