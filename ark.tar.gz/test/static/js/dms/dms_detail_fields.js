$(function(){
    $("#btn_partition_query").on('click', function(){
        $("#btn_partition_query").button('loading');
        var url = '/dms/manager_get_odps_partitions/';
        var num = 100;
        var post_data = {'data_id':data_id, 'num':num};
        $.ajax({
            url: url,
            type: "POST",
            async: true,
            dataType: "json",
            traditional: true,
            data: post_data,
            success: function(result) {
                $("#btn_partition_query").button('reset');
                if(result.status == 0)
                {
                    $("#partitionModal .modal-title").html("分区信息(最近<font color='red'>"+num+"</font>个分区)");
                    $("#partitionModal table tbody").html("");
                    for(var i in result.partition_list)
                    {
                        $("#partitionModal table tbody").append("<tr><td>"+result.partition_list[i]+"</td></tr>");
                    }
                    $("#partitionModal").modal("show");
                }
                else
                {
                    ark_notify(result);
                }
            },
            error: function(XMLHttpRequest, textStatus, error) {
                $("#btn_partition_query").button('reset');
                ark_notify({'status': 1, 'msg': '系统错误'});
            }
        });
    });
    $("#btn_meta_query").on('click', function(){
        $("#btn_meta_query").button('loading');
        var url = '/dms/manager_get_odps_meta/';
        var post_data = {'data_id':data_id};
        $.ajax({
            url: url,
            type: "POST",
            async: true,
            dataType: "json",
            traditional: true,
            data: post_data,
            success: function(result) {
                $("#btn_meta_query").button('reset');
                if(result.status == 0)
                {
                    $("#metaModal .modal-title").html("meta信息");
                    $("#metaModal #meta_partition_num").html(result.meta.partCount);
                    $("#metaModal #meta_desc").html(result.meta.comment ? result.meta.comment : '无');
                    $("#metaModal #meta_ddlModifyTime").html(result.meta.ddlModifyTime);
                    $("#metaModal #meta_dataModifyTime").html(result.meta.dataModifyTime);
                    $("#metaModal #meta_lifecycle").html(result.meta.lifecycle);
                    $("#metaModal #meta_size").html(result.meta.size);
                    $("#metaModal").modal("show");
                }
                else
                {
                    ark_notify(result);
                }
            },
            error: function(XMLHttpRequest, textStatus, error) {
                $("#btn_meta_query").button('reset');
                ark_notify({'status': 1, 'msg': '系统错误'});
            }
        });
    });
    if(data_detail.relation == 0 || data_detail.relation ==1 || data_detail.relation == 2)
    {
        //字段
        if(data_detail.type != 0) {
            $(document).on("click", ".table_fileds_list .field_name", function(){
                if(($(this).children().length == 0) && ($(".field_name .name_update_input").length < 1))
                {
                    $(this).html('<input style="width:100%;" class="name_update_input" type="text" value="'+$(this).html()+'">');
                    $(this).find("input").focus().select();
                }
            });
        }
        $(document).on("keydown", ".name_update_input", function(e){
            var e=e||window.event;
            var enter= e.keyCode|| e.which;
            if(enter==13){
                $(this).trigger("blur");
            }
        })
        $(document).off("blur", ".name_update_input");
        $(document).on("blur", ".name_update_input", function(e){
            if($(this).val() == '')
            {
                ark_notify({'status':1, 'msg':'字段名不能为空'});
                //                $(this).focus().select();
                return false;
            }
            update_fields(this);
        });
        //类型
        $(document).on("change", ".table_fileds_list .field_type", function(e){
            update_fields(this);
        });
        //描述
        $(document).on("click", ".table_fileds_list .desc", function(){
            if(($(this).children().length == 0) && ($(".desc .desc_update_input").length < 1))
            {
                $(this).html('<input style="width:100%;" class="desc_update_input" type="text" value="'+$(this).html()+'">');
                $(this).find("input").focus().select();
            }
        });
        $(document).on("keydown", ".desc_update_input", function(e){
            var e=e||window.event;
            var enter= e.keyCode|| e.which;
            if(enter==13){
                $(this).trigger("blur");
            }
        })
        $(document).off("blur", ".desc_update_input");
        $(document).on("blur", ".desc_update_input", function(e){
            update_fields(this);
        });
        $(document).on("click", ".table_fileds_list .delete_field", function(){
            $(this).parent().parent().remove();
            update_fields();
        });
        $(".field_uid").on("click", function() {
            previous = this.value;
            console.log(previous);
        }).change(function() {
            var uid_column = $(this).parent().parent().find('.field_name').attr('value');
            var uid_type = $(this).val();
            result = update_column_uid(uid_column, uid_type);
            if(result.status != 0) {
                this.value = previous;
            }
        });;
    }
    function update_fields(obj)
    {
        var url = '/dms/manager_update_format_desc/?data_id='+data_id;
        var post_data = {};
        var format_data = get_format_data();
        for(var i in format_data)
        {
            console.log(i);
            if(format_data[i].name == '')
            {
                ark_notify({'status':1, 'msg':'字段名不能为空'});
                return false;
            }
        }
        post_data['format'] = JSON.stringify(format_data);
        var result = makeAPost(url, post_data);
        if(result.status == 0)
        {
            if(typeof(obj) != 'undefined')
            {
                $(obj).parent().html($(obj).val().trim());
            }
        }
        else
        {
            ark_notify(result);
        }
    }

    function update_column_uid(uid_column, uid_type) {
        var url = '/dms/update_column_uid/?data_id='+data_id;
        var post_data = {
            'uid_column': uid_column,
            'uid_type': uid_type,
        };
        var result = makeAPost(url, post_data);
        ark_notify(result);
        return result;
    }
    function init_column_uid() {
        if(column_uid != undefined) {
            for(var uid_column in column_uid) {
                var uid_type = column_uid[uid_column];
                $(".table_fileds_list [value=" + uid_column + "]").parent().find("select[class=field_uid]").val(uid_type);
            }
        }
        var url = '/dms/update_column_uid/?data_id='+data_id;
        var post_data = {
            'uid_column': uid_column,
            'uid_type': uid_type,
        };
        var result = makeAPost(url, post_data);
    }
    function get_format_data()
    {
        var format = [];
        $(".table_fileds_list tr:gt(0)").each(function(){
            var name = $(this).find("td").eq(0).find("input").length > 0 ? $(this).find("td").eq(0).find("input").val().trim() : $(this).find("td").eq(0).text();
            var type = $(this).find("td").eq(1).find("select").length > 0 ? $(this).find("td").eq(1).find("input").val().trim() : $(this).find("td").eq(1).text();
            var desc = $(this).find("td").eq(2).find("input").length > 0 ? $(this).find("td").eq(2).find("input").val().trim() : $(this).find("td").eq(2).text();
            format.push({'name':name, 'type':type, 'desc':desc});
            //            if(name)
            //            {
            //                format.push({'name':name, 'type':type, 'desc':desc});
            //            }
        });
        return format;
    }
    $("#btn_add_filed").on('click', function(){
        $(".table_fileds_list").append('<tr>\
<td class="field_name"><input style="width:100%;" class="name_update_input" type="text" placeholder="输入字段名"></td>\
<td class="field_type">string</td>\
<td class="desc"></td>\
<td class="field_op"><i class="fa fa-fw fa-minus-circle delete_field"></i></td>\
</tr>');
    });

    init_column_uid();
});
function update_format()
{
    $("#btn_update_format").button('loading');
    var url = '/dms/manager_update_format/';
    var post_data = {'data_id':data_id};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_update_format").button('reset');
            if(result.status == 0)
            {
                $("#updateFieldsModal").modal('hide');
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_fields']").trigger('click');
            }
            else
            {
                ark_notify(result);
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_format").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
