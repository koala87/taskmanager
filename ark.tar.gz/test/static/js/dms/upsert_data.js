old_life_cycle = 0;
$(function(){
    $('input[type="radio"][name="data_type"]').on('change', function(){
        if($(this).val() == 0)
        {
            $(".pangu_form_group").hide();
            $(".odps_form_group").show();
        }
        else
        {
            $(".odps_form_group").hide();
            $(".pangu_form_group").show();
        }
    });
    $('#privacy_status').on('change', function(){
        if($(this).val() == 2)
        {
            $(".privacy_market").show();
            $(".privacy_inner").hide();
        }
        else
        {
            $(".privacy_market").hide();
            $(".privacy_inner").show();
        }
    });
    $('input[type="radio"][name="monitor_conf_flag"]').on('change', function(){
        if($(this).val() == 0)
        {
            $(".monitor_conf_item").hide();
        }
        else
        {
            $(".monitor_conf_item").show();
        }
    });
    $('#gen_time').on('change', function(){
        var html = '';
        if($(this).val() == 'hour')
        {
            html = '<span>每小时 </span><input id="monitor_minute" type="number" min="0" max="59" class="form-control" style="display: inline;width:64px"><span> 分执行</span>\
                    <span>- </span><input id="delay" min="0" type="number" class="form-control" style="display: inline;width:64px" value="1"><span> 小时</span>';
        }
        else if($(this).val() == 'week')
        {
            html = '<span>每周 </span>\
                    <select class="form-control" id="monitor_day" style="width:64px;display:inline-block;">\
                      <option value="1">一</option>\
                      <option value="2">二</option>\
                      <option value="3">三</option>\
                      <option value="4">四</option>\
                      <option value="5">五</option>\
                      <option value="6">六</option>\
                      <option value="7">日</option>\
                    </select>\
                    <span> 当日 </span>\
                    <input id="monitor_hour" type="number" min="0" max="23" class="form-control" style="display: inline;width:64px"><span> 时执行</span>\
                    <span>- </span><input id="delay" min="0" type="number" class="form-control" style="display: inline;width:64px" value="1"><span> 天</span>';
        }
        else if($(this).val() == 'month')
        {
            html = '<span>每月 </span><input id="monitor_day" type="number" min="1" max="31" class="form-control" style="display: inline;width:64px"><span> 号当日 </span><input id="monitor_hour" type="number" min="0" max="23" class="form-control" style="display: inline;width:64px"><span> 时执行</span>\
                    <span>- </span><input id="delay" min="0" type="number" class="form-control" style="display: inline;width:64px" value="1"><span> 天</span>';
        }
        else//'day' or others
        {
            html = '<span>每天 </span><input id="monitor_hour" type="number" min="0" max="23" class="form-control" style="display: inline;width:64px"><span> 时执行</span>\
                    <span>- </span><input id="delay" min="0" type="number" class="form-control" style="display: inline;width:64px" value="1"><span> 天</span>';
        }
        $("#div_cron").html(html);
    });
    $("#btn_create_data").on("click", function(){
        $("#btn_create_data").button('loading');
        var url = '/dms/manager_create_data/';
        var post_data = get_post_data();
        if(post_data['uid_column'] && !post_data['uid_type'])
        {
            $("#btn_create_data").button('reset');
            return ark_notify({status:1,msg:'请选择标识类型'});
        }
        $.ajax({
            url: url,
            type: "POST",
            async: true,
            dataType: "json",
            traditional: true,
            data: post_data,
            success: function(result) {
                $("#btn_create_data").button('reset');
                ark_notify(result);
                if(result.status == 0)
                {
                    location.href = '/dms/manager/?cid=2';
                }
            }
        });
    });
    $("#btn_update_data").on("click", function(){
        $("#btn_update_data").button('loading');
        var url = '/dms/manager_update_data/';
        var post_data = get_post_data();
        if(post_data['uid_column'] && !post_data['uid_type'])
        {
            $("#btn_update_data").button('reset');
            return ark_notify({status:1,msg:'请选择标识类型'});
        }
        post_data['data_id'] = data_id;
        $.ajax({
            url: url,
            type: "POST",
            async: true,
            dataType: "json",
            traditional: true,
            data: post_data,
            success: function(result) {
                $("#btn_update_data").button('reset');
                ark_notify(result);
                if(result.status == 0)
                {
                    location.href = '/dms/manager_data_detail/?data_id='+data_id;
                }
            }
        });
    });
    $("#table").on('change', function(){
        update_partition($(this).val());
    });
    init_owner_list();
    init_tag_list();
    init_team_list();
    var empty_value = "___empty___";
    var empty_value_text = "--选择或输入--";
    if(typeof(data_id) != 'undefined')//编辑状态
    {
        fill_content();
        var tmp = data_detail.path.split('.');
        var table = tmp[1] == undefined ? '' : tmp[1].split(':')[0];
        empty_value = table;
        empty_value_text = table;
    }
    else
    {
        $("#project").on('change', function(){
            update_table_select_list($(this).val());
        });
    }

    var project_list = get_project_list();
    $("#project").select2({
        data: project_list,
        createSearchChoice:function(term, data) {
            if ($(data).filter(function() {
                return this.text.localeCompare(term)===0;
            }).length===0) {
                return {id:term, text:term};
            }
        }
    });
    $("#project").select2("val", empty_value);

    var data = [{id: empty_value, text: empty_value_text}];
    $("#table").select2({data: data,
                         createSearchChoice:function(term, data) {
                             if ($(data).filter(function() {
                                 return this.text.localeCompare(term)===0;
                             }).length===0) {
                                 return {id:term, text:term};
                             }
                         }});
    $("#table").select2("val", empty_value);
    init_select2_async();
    //初始化数定位默认选项
    var ps = getQueryString('ps')
    var privacy_status_arr = [0, 1, 2];
    if(privacy_status_arr.indexOf(parseInt(ps)) > -1)
    {
        $("#privacy_status").val(ps);
        $("#privacy_status").trigger('change');
    }
});
function get_post_data()
{
    var post_data = {};
    if($("#privacy_status").val() <2)
    {
        post_data['type'] = $('input[type="radio"][name="data_type"]:checked').val();
    }
    else
    {
        post_data['type'] = 0;
    }
    post_data['alias'] = $('#alias').val().trim();
    post_data['privacy_status'] = ($("#privacy_status").val() == 2 && $("#apply_type").val() == 1) ? '3' : $("#privacy_status").val();
    if(post_data['type'] == 0) {
        var name = '';
        if(document.getElementById('name')) {
            name = $('#name').html().trim();
        } else {
            var project = $('#project').val().trim();
            var table = $('#table').val().trim();
            name = project + '.' + table;
            post_data['project'] = project;
            post_data['table'] = table;
        }
        post_data['name'] = name;
        post_data['path'] = 'odps://'+name+':'+$("#partition").val().trim();
    }
    else
    {
        post_data['path'] = $('#pangu_path').val().trim();
        post_data['name'] = $('#alias').val().trim();
    }
    if($('#charger').val())
    {
        post_data['grantor_list'] = $('#charger').val();
    }
    post_data['generation'] = $('#gen_time').val();
    post_data['delay'] = $('#delay').val();
    if($('#gen_time').val() == 'hour')
    {
        post_data['minute'] = $('#monitor_minute').val();
    }
    else if($('#gen_time').val() == 'day')
    {
        post_data['hour'] = $('#monitor_hour').val();
    }
    else if($('#gen_time').val() == 'week')
    {
        post_data['hour'] = $('#monitor_hour').val();
        post_data['day'] = $('#monitor_day').val();
    }
    else if($('#gen_time').val() == 'month')
    {
        post_data['hour'] = $('#monitor_hour').val();
        post_data['day'] = $('#monitor_day').val();
    }
    post_data['life_cycle'] = $('#life_cycle').val();
    post_data['old_life_cycle'] = old_life_cycle;
    post_data['monitor_strategy'] = [];
    if($('input[type="radio"][name="monitor_conf_flag"]:checked').val() == 1)
    {
        $(".monitor_strategy:checked").each(function(){
            if($(this).val()<4)
            {
                post_data['monitor_strategy'].push({'type':$(this).val(), 'percent':$(this).parent().parent().next().find("input").val().trim()});
            }
            else
            {
                post_data['monitor_strategy'].push({'type':$(this).val(), 'low_threshold':$('#low_threshold_value').val().trim()+$('#low_threshold_unit').val(), 'high_threshold':$('#high_threshold_value').val().trim()+$('#high_threshold_unit').val()});
            }
        });
    }
    post_data['monitor_strategy'] = JSON.stringify(post_data['monitor_strategy']);
    if($('#tag').val())
    {
        post_data['tag_list'] = $('#tag').val();
    }
    post_data['description'] = $('#desc').val().trim();
    post_data['team_id'] = $('#team_list').val();
    post_data['send_mail'] = $("input[type='checkbox'][name='alert_type_email']").prop("checked") ? 1 : 0;
    post_data['send_sms'] = $("input[type='checkbox'][name='alert_type_sms']").prop("checked") ? 1 : 0;
    post_data['wiki'] = $('#wiki').val().trim();
    return post_data;
}
function init_owner_list()
{
    var url = '/dms/manager_get_add_duty_list/';
    var post_data = {};
    var result = makeAPost(url, post_data);
    if(result.status == 0)
    {
        for(var i in result.user_list)
        {
            $('#charger').append('<option value="'+result.user_list[i].user_id+'">'+result.user_list[i].user_name+'</option>');
        }
    }
}
function init_tag_list()
{
    var url = '/dms/manager_get_all_tags/';
    var post_data = {};
    var result = makeAPost(url, post_data);
    if(result.status == 0)
    {
        for(var i in result.tag_list)
        {
            $('#tag').append('<option value="'+result.tag_list[i].id+'">'+result.tag_list[i].name+'</option>');
        }
    }
}
function init_team_list()
{
    var url = '/dms/manager_get_team_list/';
    var post_data = {};
    var result = makeAPost(url, post_data);
    if(result.status == 0)
    {
        for(var i in result.team_list)
        {
            $('#team_list').append('<option value="'+result.team_list[i].team_id+'">'+result.team_list[i].team_name+'</option>');
        }
    }
}
function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function() {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function() {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function(a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function(a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return + Globalize.parseDate(a)
                }
                return a
            },
            _format: function(a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function() {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}
function get_project_list()
{
    var url = '/dms/manager_get_project_list/';
    var post_data = {};
    var result = makeAPost(url, post_data);

    var empty_value = "___empty___";
    var empty_value_text = "--选择或输入--";
    var project_list = [{id: empty_value, text: empty_value_text}];
    if(result.status == 0)
    {
        for(var i in result.project_list)
        {
            project_list.push({id: result.project_list[i], text: result.project_list[i]});
        }
    }
    return project_list;
}
function update_table_select_list(project_name)
{
    var empty_value = "___empty___";
    var empty_value_text = "--选择或输入--";
    var data = [{id: empty_value, text: empty_value_text}];
    if(project_name)
    {
        var url = '/dms/manager_get_project_odps_tables/';
        var post_data = {'project_name':project_name};
        var result = makeAPost(url, post_data);
        if(result.status == 0)
        {
            for(var i in result.table_list)
            {
                data.push({'id':result.table_list[i], 'text':result.table_list[i]});
            }
        }
    }
    $("#table").select2({data: data,
                         createSearchChoice:function(term, data) {
                             if ($(data).filter(function() {
                                 return this.text.localeCompare(term)===0;
                             }).length===0) {
                                 return {id:term, text:term};
                             }
                         }});
    $("#table").select2("val", empty_value);
    update_partition(false);
}
function update_partition(table_name)
{
    $('#partition').val('');
    if(table_name)
    {
        var url = '/dms/manager_get_odps_table_info/';
        var post_data = {'project_name':$("#project").val().trim(), 'table_name':table_name};
        var result = makeAPost(url, post_data);
        if(result.status == 0)
        {
            $('#partition').val(result.part_desc);
            if(result.generation_cycle != undefined)
            {
                $('#gen_time').val(result.generation_cycle);
                $('#gen_time').trigger('change');
            }
            if(result.life_cycle != undefined)
            {
                old_life_cycle = result.life_cycle == 'get table life_cycle fail' ? 0 : result.life_cycle;
                $('#life_cycle').val(result.life_cycle);
            }
            else
            {
                old_life_cycle = 0;
            }
        }
    }

}
function fill_content()
{
    $('input[type="radio"][name="data_type"][value="'+data_detail.type+'"]').prop('checked', true);
    $('input[type="radio"][name="data_type"][value="'+data_detail.type+'"]').trigger('change');
    $("input[name='data_type'").prop('disabled', true);
    if(data_detail.privacy_status == 2 || data_detail.privacy_status == 3)
    {
        if(data_detail.privacy_status == 3)
        {
            $("#apply_type").val(1);
        }
        $("#privacy_status").val(2);
    }
    else
    {
        $("#privacy_status").val(data_detail.privacy_status);
    }
    $("#privacy_status").trigger('change');
    if(data_detail.type == 0)//odps
    {
        var tmp = data_detail.path.split('.');
        var project = tmp[0].split('/')[2];
        var table = tmp[1] == undefined ? '' : tmp[1].split(':')[0];
        var partition = tmp[1] == undefined ? '' : tmp[1].split(':')[1];
        $("#name").html(project + '.' + table);
        $("#partition").val(partition);
    }
    else//pangu
    {
        $("#pangu_data_name").val(data_detail.name);
        $("#pangu_path").val(data_detail.path);
        $("#privacy_status option[value=2]").remove();
    }
    for(var i in data_detail.grantor_list)
    {
        $("#charger option[value='"+data_detail.grantor_list[i].user_id+"']").prop('selected', true);
    }
    $('#gen_time').val(data_detail.generation);
    $('#gen_time').trigger('change');
    if(data_detail.generation == 'hour')
    {
        $("#monitor_minute").val(data_detail.minute);
    }
    else if(data_detail.generation == 'day')
    {
        $("#monitor_hour").val(data_detail.hour);
    }
    else
    {
        $("#monitor_day").val(data_detail.day);
        $("#monitor_hour").val(data_detail.hour);
    }
    $('#life_cycle').val(data_detail.life_cycle);
    if(data_detail.monitor_strategy.length > 0)
    {
        $('input[type="radio"][name="monitor_conf_flag"][value="1"]').prop('checked', true);
        $('input[type="radio"][name="monitor_conf_flag"]').trigger('change');
    }
    for(var i in data_detail.monitor_strategy)
    {
        $(".monitor_strategy[value='"+data_detail.monitor_strategy[i].type+"']").prop('checked', true);
        if(data_detail.monitor_strategy[i].type < 4)
        {
            $(".monitor_strategy[value='"+data_detail.monitor_strategy[i].type+"']").parent().parent().next().find("input").val(data_detail.monitor_strategy[i].percent);
        }
        else
        {
            var low_str = data_detail.monitor_strategy[i].low_threshold;
            if(low_str != undefined)
            {
                var low_val = low_str.substr(0, low_str.length-2);
                var low_unit = low_str.substr(low_str.length-2, low_str.length);
                $("#low_threshold_value").val(low_val);
                $("#low_threshold_unit").val(low_unit);
            }
            var high_str = data_detail.monitor_strategy[i].high_threshold;
            if(high_str != undefined)
            {
                var high_val = high_str.substr(0, high_str.length-2);
                var high_unit = high_str.substr(high_str.length-2, high_str.length);
                $("#high_threshold_value").val(high_val);
                $("#high_threshold_unit").val(high_unit);
            }
        }
    }
    for(var i in data_detail.tag_list)
    {
        $("#tag option[value='"+data_detail.tag_list[i].tag_id+"']").prop('selected', true);
    }
    $("#alias").val(data_detail.alias);
    $("#desc").val(data_detail.description);
    $('#team_list').val(data_detail.team_id);
    $('#delay').val(data_detail.delay);
    $('#monitor_time').val(data_detail.monitor_time);
    $("input[type='checkbox'][name='alert_type_email']").prop('checked', data_detail.send_mail ? true : false);
    $("input[type='checkbox'][name='alert_type_sms']").prop('checked', data_detail.send_sms? true : false);
    $('#wiki').val(data_detail.wiki);
}
function getQueryString(name) { 
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
    var r = window.location.search.substr(1).match(reg); 
    if (r != null)
    {
        return unescape(r[2]);
    }
    return null; 
} 
