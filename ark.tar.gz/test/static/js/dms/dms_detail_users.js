
function accept_permission(obj)
{
    var hist_id = $(obj).parent().attr('action-data-hist-id')
    $("#acceptPermissionModal #btn_accept_permission").attr('onclick', 'do_accept_permission('+hist_id+')');
    $("#acceptPermissionModal").modal('show');
}
function do_accept_permission(hist_id)
{
    $("#btn_accept_permission").button('loading');
    var url = '/dms/manager_accept_permission/';
    var post_data = {'hist_id':hist_id};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_accept_permission").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#acceptPermissionModal").modal("hide");
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_users']").trigger('click');
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_accept_permission").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
function deny_permission(obj)
{
    var hist_id = $(obj).parent().attr('action-data-hist-id')
    $("#denyPermissionModal #btn_deny_permission").attr('onclick', 'do_deny_permission('+hist_id+')');
    $("#denyPermissionModal").modal('show');
}
function do_deny_permission(hist_id)
{
    $("#btn_deny_permission").button('loading');
    var url = '/dms/manager_deny_permission/';
    var post_data = {'hist_id':hist_id,'reason':$("#deny_permission_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_deny_permission").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#denyPermissionModal").modal("hide");
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_users']").trigger('click');
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_deny_permission").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
function revoke_permission(obj)
{
    var hist_id = $(obj).parent().attr('action-data-hist-id')
    $("#revokePermissionModal #btn_revoke_permission").attr('onclick', 'do_revoke_permission('+hist_id+')');
    $("#revokePermissionModal").modal('show');
}
function do_revoke_permission(hist_id)
{
    $("#btn_revoke_permission").button('loading');
    var url = '/dms/manager_revoke_permission/';
    var post_data = {'hist_id':hist_id, 'reason':$("#revoke_permission_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_revoke_permission").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#revokePermissionModal").modal("hide");
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_users']").trigger('click');
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_revoke_permission").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
function grant_permission()
{
    if($("#users_to_grant option").length<2)
    {
        var url = '/dms/manager_get_unperm_list/';
        var post_data = {}; 
        post_data['data_id'] = data_id;
        $.ajax({
            url: url,
            type: "POST",
            async: false,
            dataType: "json",
            traditional: true,
            data: post_data,
            success: function(result) {
                if(result.status == 0)
                {
                    for(var id in result.user_list)
                    {
                        $("#users_to_grant").append('<option value="'+id+'">'+result.user_list[id]+'</option>');
                    }
                }
            }
        });
    }
    else
    {
        $("#users_to_grant").val([]);
    }
    init_select2_async();
    $("#grantPermissionModal").modal("show");
}
function do_grant_permission()
{
    $("#btn_grant_permission").button('loading');
    var url = '/dms/manager_grant_permission/';
    var post_data = {}; 
    post_data['to_user_ids'] = $("#users_to_grant").val();
    post_data['data_id'] = data_id;
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_grant_permission").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#grantPermissionModal").modal("hide");
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_users']").trigger('click');
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_grant_permission").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function() {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function() {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function(a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function(a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return + Globalize.parseDate(a)
                }
                return a
            },
            _format: function(a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function() {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}
