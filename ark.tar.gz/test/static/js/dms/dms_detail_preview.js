$(function(){
    $("#query_time").daterangepicker({
        "timePicker": true,
        "timePicker24Hour": true,
        "timePickerIncrement": 60,
        "singleDatePicker": true,
        "locale": {
            "applyLabel": "确定",
            "cancelLabel": "取消",
            "firstDay": 1,
            "format":"YYYY-MM-DD HH:mm:ss",
        },
        "opens": "right"
    });
    $("#query_time").val("");
    do_preview(true);
});
function do_preview(init_flag)
{
    $("#btn_preview").button('loading');
    var url = '/dms/manager_data_detail_preview/';
    var time = $("#query_time").val().trim();
    var line = $("#lines_num").val();
    var post_data = {'data_id':data_id,'time':time.replace(new RegExp(/-/g), '').replace(new RegExp(/ /g), '').split(":")[0],'line':line};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_preview").button('reset');
            if(result.status == 0)
            {
                $("#data_preview_area").val(result.data_info.join("\n"));
                if(result.date)
                {
                    $("#query_time").val(result.date.substr(0,4)+'-'+result.date.substr(4,2)+'-'+result.date.substr(6,2)+' '+result.date.substr(8,2)+':00:00');
                }
//                var line_str = '';
//                for(var i in result.data_info)
//                {
//                    if(i == 0)
//                    {
//                        line_str += '<thead>';
//                    }
//                    line_str += '<tr>';
//                    var line = result.data_info[i].split(',');
//                    for(var j in line)
//                    {
//                        line_str += '<td>'+line[j]+'</td>';
//                    }
//                    line_str += '</tr>'
//                    if(i == 0)
//                    {
//                        line_str += '</thead><tbody>';
//                    }
//                }
//                line_str += '</tbody>';
//                $("#data_preview_table_hide").html(line_str);
            }
            else
            {
                ark_notify(result);
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_preview").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });

}
function export_preview()
{
    $("#btn_export").button('loading');
    var url = '/dms/manager_data_detail_preview/';
    var time = $("#query_time").val().trim();
    var line = $("#lines_num").val();
    var post_data = {'data_id':data_id,'time':time.replace(new RegExp(/-/g), '').replace(new RegExp(/ /g), '').split(":")[0],'line':line};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_export").button('reset');
            if(result.status == 0)
            {
                var line_str = '';
                for(var i in result.data_info)
                {
                    if(i == 0)
                    {
                        line_str += '<thead>';
                    }
                    line_str += '<tr>';
                    var line = result.data_info[i].split(',');
                    for(var j in line)
                    {
                        var content = line[j].replace(new RegExp(/(^")|("$)/g), '');
                        line_str += i == 0 ? ('<th>'+content+'</th>') : ('<td>'+content+'</td>');
                    }
                    line_str += '</tr>'
                    if(i == 0)
                    {
                        line_str += '</thead><tbody>';
                    }
                }
                line_str += '</tbody>';
                $("#data_preview_table_hide").html(line_str);
                $("#data_preview_table_hide").table2excel(
                    {filename: data_detail.name+"_"+$("#query_time").val().trim().replace(new RegExp(/-/g), '').replace(new RegExp(/ /g), '').split(":")[0]}
                );
            }
            else
            {
                ark_notify(result);
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_export").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });

}
