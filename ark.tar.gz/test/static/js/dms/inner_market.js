var page = 1;
var page_size = 10;
var search_val = '';
var flag_load_more = false;
function get_post_data()
{
    var post_data = {};
    post_data['key_word'] = search_val;
    post_data['page'] = page;
    return post_data;
}
function get_more()
{
    page += 1;
    flag_load_more = true;
    get_market_data_list();
}
function get_market_data_list()
{
    show_div_loading($(".div_left"));
    var url = '/dms/inner_manager_get_data_list/';
    var post_data = get_post_data();
    var callback = callback_get_market_data_list;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_market_data_list(result, args)
{
    hide_div_loading($(".div_left"));
    if(result.status == 0)
    {
        if(result.config_list.length < result.length)
        {
            $(".div_left #load_more_p").html("没有更多了");
        }
        else
        {
            $(".div_left #load_more_p").html('<a href="javascript:" onclick="get_more()">加载更多<i class="fa fa-fw fa-sort-down"></i></a>');
        }
        data = format_data_block(result.config_list);
        if(flag_load_more)
        {
            $(".div_left #load_more_p").before(data);
        }
        else
        {
            $(".div_left section.list").remove();
            $(".div_left #load_more_p").before(data);
        }
    }
}
function format_data_block(config_list)
{
    var ret = '';
    for(var i in config_list)
    {
        var html = '<section class="list"><span class="hot_degree">热度&nbsp;';
        for(var j=1; j<6;j++)
        {
            if(j<= config_list[i].data_cited)
            {
                html += '<i class="fa fa-fw hot_star fa-star"></i>';
            }
            else
            {
                html += '<i class="fa fa-fw hot_star fa-star-o"></i>';
            }
        }
        html += '</span>';
        html += '<div>\
                <h4 class="data_title">\
                    <a href="/dms/manager_data_detail/?data_id='+config_list[i].data_id+'">'+config_list[i].data_alias+'</a>\
                </h4>\
                <div class="data_item">\
                    <div class="data_info">\
                        <span class="type_label">类型</span>\
                        <span class="type_value">'+data_type_map[config_list[i].data_type]+'</span>\
                        <span class="owner_label">发布者</span>\
                        <span class="owner_value">'+config_list[i].data_owner+'</span>\
                        <span class="mtime_label">更新时间</span>\
                        <span class="mtime_value">'+config_list[i].update_time+'</span>\
                        <span class="table_label">表名</span>\
                        <span class="table_value">'+config_list[i].data_name+'</span>\
                    </div>\
                    <div class="tag_info">\
                        <span class="tag_label">标签</span>\
                        <div class="tag_value_list">';
        for(var k in config_list[i].tag_list)
        {
            html += '<span class="tag_value">'+config_list[i].tag_list[k].tag_name+'</span>';
        }
        html +=    '</div>\
                    </div>\
                    <div class="desc_info">\
                        <span class="desc_label">描述</span>\
                        <span class="desc_value">'+(config_list[i].data_desc ? config_list[i].data_desc : "无") +'</span>\
                    </div>\
                </div>\
            </div>\
            <div class="clear"></div></section>';
        ret += html;
    }
    return ret;
}
$(function(){
    $(window).scroll(function(){  
        if ($(window).scrollTop()>100){  
            $("#btn_back_to_top").fadeIn(1500);  
        }  
        else  
        {  
            $("#btn_back_to_top").fadeOut(1500);  
        }  
    });  

    //当点击跳转链接后，回到页面顶部位置  

    $("#btn_back_to_top").click(function(){  
        $('body,html').animate({scrollTop:0},1000);  
        return false;  
    });
    $("#btn_search").on('click', function(){
        page = 1;
        flag_load_more = false;
        search_val = $("#input_search").val().trim();
        if(search_val == '')
        {
            $(".div_left").hide();
            $(".right_sider").hide();
            $("#sitebar_1").show();
            $("#sitebar_2").show();
        }
        else
        {
            $(".div_left").show();
            $(".right_sider").show();
            $("#sitebar_1").hide();
            $("#sitebar_2").hide();
            get_market_data_list();
        }
    });
    $("#input_search").on("keydown", function(e){
        var e=e||window.event;
        var enter= e.keyCode|| e.which;
        if(enter==13){
            $("#btn_search").trigger('click');
        }
    });
    $("#btn_search").trigger('click');//初始化
});
function show_div_loading(obj, msg)
{
   if (msg == undefined) {  
       msg = "正在加载数据，请稍候...";  
   }  
   $("<div class=\"back_cover\"></div>").append($("<i class=\"fa fa-refresh fa-spin\"></i>").css({top:obj.height()/2})).css({ display: "block", top:obj.position().top, width: obj.width(), height: obj.height() }).appendTo(obj);  
}
function hide_div_loading(obj)
{
    obj.find("div.back_cover").remove();  
}
