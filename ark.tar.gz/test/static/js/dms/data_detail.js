$(function(){
    $(".data_detail_siderbar a").on('click', function(){
        $(".data_detail_siderbar li").removeClass('active');
        $(this).parent().addClass('active');
        var load_url = '/dms/' + $(this).attr('action-data')+'/?data_id='+data_id;
        window.history.pushState("", "", "/dms/manager_data_detail/?data_id="+data_id+"&cid="+$(this).attr('page-index'));
        displayLoading($("#data_detail"));
        $("#data_detail").load(load_url);
    });
    $(".data_detail_siderbar li.active a").trigger("click");
});
function publish_data(data_id)
{
    $("#btn_data_publish").button('loading');
    var url = '/dms/manager_apply_release/';
    var post_data = {'data_id':data_id, 'reason':$("#publishModal #apply_release_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_data_publish").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#publishModal").modal("hide");
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_basic']").trigger('click');
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_data_publish").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
function delete_data(data_id)
{
    $("#btn_data_delete").button('loading');
    var url = '/dms/manager_delete_data/';
    var post_data = {'data_id':data_id};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_data_delete").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#deleteDataModal").modal("hide");
                location.href = '/dms/manager/?cid=2';
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_data_publish").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
function apply_permission()
{
    $("#applyPermissionModal #apply_permission_reason").val('');
    $("#applyPermissionModal").modal('show');
}
function do_apply_permission(user_id)
{
    $("#btn_apply_permission").button('loading');
    var url = '/dms/manager_apply_permission/';
    var post_data = {'data_id':data_id, 'user_id':user_id,'reason':$("#apply_permission_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#btn_apply_permission").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#applyPermissionModal").modal("hide");
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_basic']").trigger('click');
            }
        },
        error: function(XMLHttpRequest, textStatus, error) {
            $("#btn_apply_permission").button('reset');
            ark_notify({'status': 1, 'msg': '系统错误'});
        }
    });
}
function revoke_release(hist_id)
{
    $("#revokePublishModal #btn_data_publish_revoke").attr('onclick', 'do_revoke_release("'+hist_id+'")');
    $("#revokePublishModal").modal('show');
}
function do_revoke_release(hist_id)
{
    $("#revokePublishModal #btn_data_publish_revoke").button('loading');
    $("#revokePublishModal").modal('show');
    var url = '/dms/manager_revoke_release/';
    var post_data = {'hist_id':hist_id, 'reason':$("#revokePublishModal #revoke_release_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#revokePublishModal #btn_data_publish_revoke").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#revokePublishModal").modal("hide");
                $(".modal-backdrop").remove();
                $(".data_detail_siderbar a[action-data='manager_data_detail_basic']").trigger('click');
            }
        }
    });
}
function displayLoading(zone) {
    zone.html($("[name=div_loading]").html());
}
function update_life_cycle()
{
    $("#updateLifecycleModal").modal('show');
    $("#updateLifecycleModal #life_cycle").val(data_detail.life_cycle);
}
function do_update_life_cycle(data_id)
{
    $("#updateLifecycleModal #btn_update_life_cycle_ok").button('loading');
    var url = '/dms/manager_change_life_cycle/';
    var post_data = {data_id:data_id, life_cycle:$("#updateLifecycleModal #life_cycle").val().trim()};
    var callback = callback_do_update_life_cycle;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_update_life_cycle(result, args)
{
    $("#updateLifecycleModal #btn_update_life_cycle_ok").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#updateLifecycleModal").modal('hide');
      //  $(".data_detail_siderbar a[action-data='manager_data_detail_basic']").trigger('click');
        location.reload();
    }
}

users_to_grant_inited = false;
function change_owner() {
    if(!users_to_grant_inited) {
        var url = '/ark_user/get_all_users_select/';
        var post_data = {}; 
        result = makeAPost(url, post_data);
        if(result.status != 0) {
            ark_notify(result);
        } else {
            MultiUserSelector.init($("#users_to_change"), result.data, [])
            $("#users_to_change").parent().find("[class='select2-container form-control']").attr("style", "border:none");
            users_to_grant_inited = true;
        }
    }
    $("#changeOwnerModal").modal("show");
}
function do_change_owner()
{
    var select_owner = $("#users_to_change").select2('data');
    var to_owner_id = select_owner.id;
    var to_owner_text = select_owner.text;
    var url = '/dms/change_owner/';
    var post_data = {'data_id': data_id, 'to_owner_id': to_owner_id}; 
    result = makeAPost(url, post_data);
    ark_notify(result);
    if(result.status == 0) {
        $("#changeOwnerModal").modal("hide");
        $("[name=owner_dsp_name]").text(to_owner_text);
    }
}

