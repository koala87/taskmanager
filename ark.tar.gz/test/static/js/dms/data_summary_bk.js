$(function() {
    var graph_name = '线状图';
    var display_zone_id = 'report_home_graph_line';
    var display_zone = $("#" + display_zone_id);
    var display_zone_ele = document.getElementById(display_zone_id);
    var bu_tag_list_ele = document.getElementById('bu_tag_list');
    var chart = null;
    var graph_type = 'line';

    window.HomeGraphLine = {
        get_data : function(){
            var url = "/dms/summary/";
            data = {};
            result = makeAPost(url, data);
            return result;
        },
        make_option: function(data) {
            if(!data) {
                data = {};
            }
            var legend_data = ['', '已上线报表数','总报表数'];
            var series_data = [{
                                   "name": '已上线报表数',
                                   "type": graph_type,
                                   "data": data.data.online_nums
                               },
                               {
                                   "name": '总报表数',
                                   "type": graph_type,
                                   "data": data.data.total_nums
                               }];
            var title_text = '报表总数量增长趋势';
            option = StatEcharts.get_line_option(
                title_text, data.time_list, legend_data, series_data)
            return option;
        },
        display_data: function(data) {
            var option = HomeGraphLine.make_option(data);
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/line',
                'echarts/chart/bar',
            ], function(ec) {
                chart = ec.init(display_zone_ele, 'macarons');
                chart.setOption(option);
            });

        },
        refresh: function() {
            if(chart) {
                chart.showLoading();
            }
            result = _report_trend;
            HomeGraphLine.display_data(result);

            result = HomeGraphLine.get_data();
            if(result.status == 0) {
                HomeGraphLine.display_bu_tag_list(result.data);
            }

        },
        display_bu_tag_list: function(data) {
            var bu_tag_list = data['bu_tag_list'];
            var legend_data = [];
            
            var series_data = [];
            var format_graph_data = bu_tag_list['format_graph_data'];
            for(var i in format_graph_data) {
                var tag = format_graph_data[i][0];
                var data = format_graph_data[i][1];
                series_data.push(
                    {'name': tag, 
                     'type': 'bar',
                     itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
                     'data': data});
                legend_data.push(tag);
            }

            var title = 'a';
            option = StatEcharts.get_line_option(
                title, bu_tag_list.all_teams, 
                legend_data, series_data);

            var ele = document.getElementById('bu_tag_list');
            console.log(ele);
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/line',
                'echarts/chart/bar',
            ], function(ec) {
                chart = ec.init(bu_tag_list_ele, 'macarons');
                chart.setOption(option);
                chart.hideLoading();            
                console.log(chart);
            });

            if(chart) {
                chart.showLoading();
            }
        },

    }

    HomeGraphLine.refresh();
});
