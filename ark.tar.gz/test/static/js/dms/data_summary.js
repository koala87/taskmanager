$(function() {
    var option = {
        title: {
            text: 'title',
            x: 'center',
        },
        tooltip: {
            show : true,
            trigger: 'axis',
            axisPointer: {
                type: 'shadow',
            }
        },
        legend: {
            data:[],
        },
        series : []
    };

    var bu_tag_list_chart = null;
    var tag_list_chart = null;
    var tag_list_ele = document.getElementById('tag_list');
    var bu_tag_list_ele = document.getElementById('bu_tag_list');
    var bu_list_ele = document.getElementById('bu_list');

    window.SummaryGraphs = {
        get_bu_tag_option: function(
            title, bu_list, legend_data, series_data) {
            var o = $.extend(true, {}, option);
            o['title']['text'] = title;
            o['legend']['data'] = legend_data;
            if(series_data.length == 0) {
                o['series'] = [{'type':'bar'}];
            } else {
                o['series'] = series_data;
            }
            o['xAxis'] = [
                {
                    type : 'value',
                }
            ];
            o['yAxis'] = [
                {
                    type : 'category',
                    data: bu_list,
                },
            ];
            return o;
        },
        get_bu_option: function(
            title, bu_list, legend_data, series_data) {
            var o = $.extend(true, {}, option);
            o['title']['text'] = title;
            o['legend']['data'] = legend_data;
            o['series'] = series_data;
            o['xAxis'] = [
                {
                    type : 'category',
                    data: bu_list,
                    axisLabel: {interval :0, rotate: 25}
                }
            ];
            o['yAxis'] = [
                {
                    type : 'value',
                },
            ];
            o['grid'] = {y: 10};
            return o;
        },
        get_data : function(){
            var url = "/dms/summary/";
            data = {};
            result = makeAPost(url, data);
            return result;
        },
        make_bar_html: function(value, max, bg_color, with_value) {
            if(max == undefined) {
                max = 100;
            }
            if(bg_color == undefined) {
                bg_color = '#00c0ef';
            }
            if(with_value == undefined) {
                with_value = false;
            }
            var perc = value * 100.0 / max;
            var str = '<div class="progress" title="' + value + '">';
            if(with_value) {
                str += value;
            }
            str += '<div class="progress-bar progress-bar-aqua" ' +
                'style="background-color:' + bg_color + 
                ';width:' + perc + '%"></div></div>';
            return str;
        },
        display_basic_info: function(data) {
            var num = data['num'];
            var size = data['size'];
            var user_num = data['user_num'];
            $("#basic_info_num").html(num);
            $("#basic_info_size").html(size);
            $("#basic_info_user_num").html(user_num);
        },
        display_use_list: function(data) {
            var use_list = data['use_list'];
            var html_str = '<table class="table table-condensed"><tbody>';
            var max_cited = use_list[0]['cited'];
            for(var i = 0; i < use_list.length; i++) {
                html_str += '<tr>';
                var color = i == 0 ? '#FF0000' : i == 1 ? '#FF6600' : i == 2 ? '#BCBCBC' : '';
                var bar_html = SummaryGraphs.make_bar_html(use_list[i]['cited'], max_cited)
                html_str += '<td style="color:' + color + '"><span>' + (i + 1) + '</span><a title="' + use_list[i]['alias'] + '" href="/dms/manager_data_detail/?data_id=' + use_list[i]['id'] + '" style="color:#666"> ' + use_list[i]['alias'] + '</a></td><td>' + bar_html + '</td>';
                html_str += '</tr>';
            }
            html_str += '</tbody></table>';
            $("#use_list").html(html_str);
        },
        display_tag_list: function(data) {
            var tag_list = data['tag_list'];
            var legend_data = [];
            var dsp_data = [];
            for(var i in tag_list) {
                dsp_data.push(
                    {'name': tag_list[i][0], 
                     'value': tag_list[i][1]});
                legend_data.push(tag_list[i][0]);
            }
            var series_data = [{
                name: '类型分布',
                type: 'pie',
                center: ['50%', '60%'],
                radius: '55%',
                data: dsp_data
            }];

            var title = '';
            var sub_title = '';
            var option = StatEcharts.get_pie_option(
                title, sub_title, legend_data, series_data);
            option['title'] = {}
            option['toolbox'] = {}
            option['legend']['x'] = 0;
            option['legend']['y'] = -50;
            option['legend']['orient'] = 'horizontal';
            option['legend']['padding'] = [0, -400];

            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/pie',
            ], function(ec) {
                tag_list_chart = ec.init(tag_list_ele, 'macarons');
                tag_list_chart.setOption(option);
                tag_list_chart.hideLoading();            
            });
        },
        display_bu_tag_list: function(data) {
            var bu_tag_list = data['bu_tag_list'];
            var legend_data = [];
            
            var series_data = [];
            var format_graph_data = bu_tag_list['format_graph_data'];
            for(var i in format_graph_data) {
                var tag = format_graph_data[i][0];
                var data = format_graph_data[i][1];
                series_data.push(
                    {'name': tag, 
                     'type': 'bar',
                     stack: '总量',
                     // itemStyle : { normal: {label : {show: true, position: 'insideRight'}}},
                     'data': data});
                legend_data.push(tag);
            }


            var title = '';
            var option = SummaryGraphs.get_bu_tag_option(
                title, bu_tag_list['all_teams'], 
                legend_data, series_data);

            console.log(option);
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/line',
                'echarts/chart/bar',
            ], function(ec) {
                bu_tag_list_chart = ec.init(bu_tag_list_ele, 'macarons');
                bu_tag_list_chart.setOption(option);
                bu_tag_list_chart.hideLoading();            
            });
        },
        display_bu_list_bk: function(data) {
            var bu_list = data['bu_list'];
            var max_num = bu_list['max_num'];
            var format_graph_data = bu_list['format_graph_data'];
            var html_str = '<table class="table table-condensed"><tbody>';
            for(var i = 0; i < format_graph_data.length; i++) {
                html_str += '<tr>';
                var bu = format_graph_data[i]['bu'];
                var num = format_graph_data[i]['num'];
                var bar_html = SummaryGraphs.make_bar_html(num, max_num)
                html_str += '<td>' + bu + '</a></td><td>' + bar_html + '</td>';
                html_str += '</tr>';
            }
            html_str += '</tbody></table>';
            $("#bu_list").html(html_str);
        },
        display_bu_list: function(data) {
            var bu_list = data['bu_list'];
            var legend_data = [];
            
            var series_data = [];
            var all_teams = bu_list['all_teams'];
            var graph_data = bu_list['graph_data'];
            var series_data = [
                {'name': '', 'type': 'bar', 'data': graph_data}]

            var title = '';
            var option = SummaryGraphs.get_bu_option(
                title, all_teams, [], series_data);

            console.log(option);
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/line',
                'echarts/chart/bar',
            ], function(ec) {
                bu_list_chart = ec.init(bu_list_ele, 'macarons');
                bu_list_chart.setOption(option);
                bu_list_chart.hideLoading();            
            });
        },
        display_red_black_list: function(data) {
            var red_black_list = data['red_black_list'];
            var table_str = '<table class="table table-condensed"><tbody>';
            var table_header = '<tr><th style="width:20%">部门</th><th style="width:15%">接入量</th><th style="width:15%">友好性</th><th style="width:15%">共享度</th><th>综合分</th></tr>';
            table_str += table_header;
            var team_num = red_black_list.length;
            var red_end_idx = -1;
            var black_start_idx = team_num;
            for(var i = 0; i < team_num - 1 && i < 2; i++) {
                if(red_black_list[i].overall != red_black_list[i+1].overall) {
                    red_end_idx = i;
                }
            }
            for(var i = team_num - 1; i > 0 && i >= team_num - 2; i--) {
                if(red_black_list[i].overall != red_black_list[i-1].overall) {
                    black_start_idx = i;
                }
            }
            for(var i in red_black_list) {
                var line = red_black_list[i];
                var overall_bg_color = i <= red_end_idx 
                    ? 'red' : i < black_start_idx 
                    ? '#00c0ef' : 'black';
                overall_str = SummaryGraphs.make_bar_html(line.overall, 100, overall_bg_color, true);
                row_str = '<tr><td>' + line.team_name + 
                    '</td><td>' + SummaryGraphs.make_bar_html(line.access) + 
                    '</td><td>' + SummaryGraphs.make_bar_html(line.friendliness) + 
                    '</td><td>' + SummaryGraphs.make_bar_html(line.share) + 
                    '</td><td>' + overall_str + 
                    '</td></tr>';
                table_str += row_str;
            }
            table_str += '</tbody></table>';

            $("#red_black_list").html(table_str);
        },
        display_data: function(data) {
            SummaryGraphs.display_bu_list(data);
            SummaryGraphs.display_red_black_list(data);
            SummaryGraphs.display_use_list(data);
            SummaryGraphs.display_tag_list(data);
            SummaryGraphs.display_basic_info(data);
            // SummaryGraphs.display_bu_tag_list(data);
        },
        refresh: function() {
            result = SummaryGraphs.get_data();
            if(result.status == 0) {
                SummaryGraphs.display_data(result.data);
            }
        },
    }

    SummaryGraphs.refresh();
});
