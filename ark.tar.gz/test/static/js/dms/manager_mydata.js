table = '';
$(function(){
    reflesh_table();
    $(".type_header span").on('click', function(){
        $(".type_header span").removeClass('active');
        $(this).addClass('active');
        reflesh_table();
    });
});
function reflesh_table()
{
    if(table) {
        table.destroy();
    }
    table = $('#mydata_table').DataTable({
        "processing": true,
        "serverSide": true,
        "bInfo": false,
        "bFilter": false,
        "bAutoWidth": false,
        "language": {
            "zeroRecords": "暂无数据",
            "processing": "载入中",//处理页面数据的时候的显示
            "paginate": {//分页的样式文本内容。
                "previous": "上一页",
                "next": "下一页",
                "first": "第一页",
                "last": "尾页"
            },
            "lengthMenu": ""
        },
        "ajax": {
            "url": "/dms/manager_mydata_list/",
            "type": "POST",
            "data":{ "type":  $(".type_header .active").attr('action-data-type')}
        },
        "searching":true,
        "columns": [
            { "data": "no" ,"bSortable": false},
            { "data": "data_type" ,"bSortable": false},
            { "data": "data_name" ,"bSortable": false},
            { "data": "owner_name" ,"bSortable": false },
            { "data": "update_time" ,"bSortable": false ,'style':'text-align: center'}
        ],
        "columnDefs": [
            //自定义操作列
            {
                "targets": [1],
                "render": function(data,type,full) {
                        return data==0 ? 'odps' : 'pangu';
                }
            },
            {
                "targets": [2],
                "render": function(data,type,full) {
                        var suffix_str = '';
                        if(full.relation == 3)
                        {
                            suffix_str = '<sup class="data_sup_rss">订阅</sup>';
                        }
                        else if(full.release_status == 2)
                        {
                            suffix_str = '<sup class="data_sup_market">精</sup>';
                        }
                        return suffix_str+"<a title='"+data+"' href='/dms/manager_data_detail/?data_id=" + full.data_id + "'>"+data+"</a>";
                }
            },
            {
                "targets": [3],
                "render": function(data,type,full) {
                        return "<a title='"+data+"' href='javascript:' style='color: #656565;cursor: default;'>"+data+"</a>";
                }
            },
            {
                "targets": [5],
                "render": function(data,type,full) {
                        return "<a title='查看数据' href='/dms/manager_data_detail/?data_id=" + full.data_id+"'>查看</a>";
                }
            },
        ],
    });

}
