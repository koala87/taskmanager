table = '';
$(function(){
    reflesh_table();
});
function reflesh_table()
{
    if(table) {
        table.destroy();
    }
    table = $('#audit_table').DataTable({
        "processing": true,
        "serverSide": true,
        "bInfo": false,
        "bFilter": false,
        "bAutoWidth": false,
        "language": {
            "zeroRecords": "暂无数据",
            "processing": "载入中",//处理页面数据的时候的显示
            "paginate": {//分页的样式文本内容。
                "previous": "上一页",
                "next": "下一页",
                "first": "第一页",
                "last": "尾页"
            },
            "lengthMenu": ""
        },
        "ajax": {
            "url": "/dms/manager_get_all_release/",
            "type": "POST"
        },
        "columns": [
            { "data": "data_name" ,"bSortable": false},
            { "data": "user_name" ,"bSortable": false },
            { "data": "reason" ,"bSortable": false},
            { "data": "time" ,"bSortable": false ,'style':'text-align: center'}
        ],
        "columnDefs": [
            //自定义操作列
            {
                "targets": [0],
                "render": function(data,type,full) {
                        return '<a target="_blank" href="/dms/manager_data_detail/?data_id='+full.data_id+'">'+data+'</a>';
                }
            },
            {
                "targets": [1],
                "render": function(data,type,full) {
                        return "<a title='"+data+"' href='javascript:' style='color: #656565;cursor: default;'>"+data+"</a>";
                }
            },
            {
                "targets": [2],
                "render": function(data,type,full) {
                        return '<a href="javascript:void(0)" style="color: #656565;" title="查看全部理由" onclick="show_all_desc(this)">'+data+'</a>';
                }
            },
            {
                "targets": [4],
                "render": function(data,type,full) {
                        var ret = '';
                        if(full.status == 'pending')
                        {
                            ret = "<a href='javascript:' style='margin-right:10px;' onclick='accept_release("+full.hist_id+")'>同意</a><a href='javascript:' onclick='deny_release("+full.hist_id+")'>拒绝</a>";
                        }
                        else if(full.status == 'accepted')
                        {
                            ret = "已同意<a href='javascript:' style='margin-left:10px;' onclick='revoke_release("+full.hist_id+")'>撤销发布</a>";
                        }
                        else if(full.status == 'denied')
                        {
                            ret = "已拒绝";
                        }
                        else if(full.status == 'revoked')
                        {
                            ret = "已撤销";
                        }
                        return ret;
                }
            },
        ],
    });

}
function show_all_desc(obj)
{
    $("#desc_full_modal .modal-body p").html($(obj).text().replace(new RegExp(/\n/), '</br>'));
    $("#desc_full_modal").modal('show');
}
function accept_release(hist_id)
{
    $("#acceptPublishModal #btn_data_publish_accept").attr('onclick', 'do_accept_release("'+hist_id+'")');
    $("#acceptPublishModal").modal('show');
}
function do_accept_release(hist_id)
{
    $("#acceptPublishModal #btn_data_publish_accept").button('loading');
    $("#acceptPublishModal").modal('show');
    var url = '/dms/manager_accept_release/';
    var post_data = {'hist_id':hist_id};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#acceptPublishModal #btn_data_publish_accept").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#acceptPublishModal").modal("hide");
                $(".modal-backdrop").remove();
                location.href = '/dms/manager/?cid=4';
            }
        }
    });
}
function deny_release(hist_id)
{
    $("#denyPublishModal #btn_data_publish_deny").attr('onclick', 'do_deny_release("'+hist_id+'")');
    $("#denyPublishModal").modal('show');
}
function do_deny_release(hist_id)
{
    $("#denyPublishModal #btn_data_publish_deny").button('loading');
    $("#denyPublishModal").modal('show');
    var url = '/dms/manager_deny_release/';
    var post_data = {'hist_id':hist_id};
    var post_data = {'hist_id':hist_id, 'reason':$("#denyPublishModal #deny_release_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#denyPublishModal #btn_data_publish_deny").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#denyPublishModal").modal("hide");
                $(".modal-backdrop").remove();
                location.href = '/dms/manager/?cid=4';
            }
        }
    });
}
function revoke_release(hist_id)
{
    $("#revokePublishModal #btn_data_publish_revoke").attr('onclick', 'do_revoke_release("'+hist_id+'")');
    $("#revokePublishModal").modal('show');
}
function do_revoke_release(hist_id)
{
    $("#revokePublishModal #btn_data_publish_revoke").button('loading');
    $("#revokePublishModal").modal('show');
    var url = '/dms/manager_revoke_release/';
    var post_data = {'hist_id':hist_id, 'reason':$("#revokePublishModal #revoke_release_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        dataType: "json",
        traditional: true,
        data: post_data,
        success: function(result) {
            $("#revokePublishModal #btn_data_publish_revoke").button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                $("#revokePublishModal").modal("hide");
                $(".modal-backdrop").remove();
                location.href = '/dms/manager/?cid=4';
            }
        }
    });
}
