$(function(){
    $(".sidebar-menu a").on('click', function(){
        $(".sidebar-menu li").removeClass('active');
        $(this).parent().addClass('active');
        var load_url = '/dms/' + $(this).attr('action-data')+'/';
        window.history.pushState("", "", "/dms/manager/?cid="+$(this).attr('page-index'));
        displayLoading($("#manager_data"));
        $("#manager_data").load(load_url);
    });
    $(".sidebar-menu li.active a").trigger("click");
});
function displayLoading(zone) {
    zone.html($("[name=div_loading]").html());
}
