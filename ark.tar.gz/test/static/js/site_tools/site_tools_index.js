var echarts;
var myChart;
var curTheme;
var domMain = document.getElementById('chart_domain');
var host_table = null;
var options;

function showMessage(type,title,msg){
        new PNotify({
            title: title,
            text: msg,
            addclass: 'custom',
            type: type
        });
}
function showErrorMessage(msg){
    showMessage("error","错误提示",msg);
}

function checkParam(){
    try{
        var time = $("#host_form_time").val();
        var host = $("#host_form_host_name").val();
        time = time.replace(/-/g,"").replace(/ /g,"");
        time_arr = time.split("to");
        if(time_arr.length!=2){
            showErrorMessage("查询时间输入有误!"); 
            return false;
        }
        var startDate = new Date(Date.parse(time_arr[0].replace(/-/g, "/")));
        var endDate= new Date(Date.parse(time_arr[1].replace(/-/g, "/")));
        if(startDate>endDate){
            showErrorMessage("查询时间输入有误!");
            return false;
        } 
        if(host==null || host.replace(/ /g,"").length==0){
            showErrorMessage("查询站点输入有误!");
            return false;
        }
        if(host.split(".").length<2){
            showErrorMessage("查询站点输入有误!");
            return false;
        }
        return true;
    }catch(err){
        return false;
    } 
    return false;
}

function hostSubmitAjax(){
    if(!checkParam()){
        return false;
    }
    var time = $("#host_form_time").val();
    var host = $("#host_form_host_name").val();
    var url = "/site_tools/index/";
    var param = $("#site_tools_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : param,
        success : function(result) {
            if(result.status){
                showTableData(result.msg); 
                showCharts(result.msg);
            }else{
                showErrorMessage(result.msg); 
            }
        }
    });
}

function showCharts(host_data_msg){
        host_data = eval(host_data_msg); 
        var pv_res = [];
        var uv_res = [];
        var clk_res = [];
        var android_clk_res = [];
        var ios_clk_res = [];
        var sc_clk_res = [];
        var nature_clk_res = [];
        var click_uv_res = [];
        for(var i=0;i<host_data.length;i++){
            var uv = host_data[i]["uv"];
            var pv = host_data[i]["pv"];
            var clk = host_data[i]["clk"];
            var android_clk = host_data[i]["android_clk"];
            var ios_clk = host_data[i]["ios_clk"];
            var sc_clk = host_data[i]["sc_click"];
            var nature_clk = host_data[i]["nature_click"];
            var clk_uv = host_data[i]["click_uv"];
            pv_res.push(pv);
            uv_res.push(uv);
            clk_res.push(clk);
            sc_clk_res.push(sc_clk);
            nature_clk_res.push(nature_clk);
            click_uv_res.push(clk_uv);
            android_clk_res.push(android_clk);
            ios_clk_res.push(ios_clk);
        }
        options = {
            title : {
                text: '',
                subtext: ''
            },
            tooltip : {
                trigger: 'axis'
            },
            legend: {
                data:['pv', 'uv','clk','android_clk','ios_clk','sc_clk','nature_clk','clk_uv']
            },
            calculable : true,
            toolbox: {
                show : true,
                feature : {
                    mark : {show: false},
                    dataView : {show: true, readOnly: false},
                    magicType : {show: false, type: ['line', 'bar']},
                    restore : {show: false},
                    saveAsImage : {show: true}
                }
            },
            dataZoom : {
                show : false,
                start : 0,
                end : 100
            },
            grid:{x:100,y:30,x2:10,y2:30},
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : true,
                    data : (function (){
                        var res = [];
                        for(var i=0;i<host_data.length;i++){
                            var table_name = host_data[i]["table_name"];
                            var day = table_name.substr("shenma_log_host_feature_".length);
                            res.push(day);
                        }
                        return res;
                    })()
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    scale: true,
                    name : '指标'
                }
            ],
            series : [
                {
                    name:'pv',
                    type:'line',
                    data:pv_res
                },
                {
                    name:'uv',
                    type:'line',
                    data:uv_res
                },
                {
                    name:'clk',
                    type:'line',
                    data:clk_res
                },
                {
                    name:'android_clk',
                    type:'line',
                    data:android_clk_res
                },
                {
                    name:'ios_clk',
                    type:'line',
                    data:ios_clk_res
                },
                {
                    name:'sc_clk',
                    type:'line',
                    data:sc_clk_res
                },
                {
                    name:'nature_clk',
                    type:'line',
                    data:nature_clk_res
                },
                {
                    name:'clk_uv',
                    type:'line',
                    data:click_uv_res
                }
            ]
        };
    if (myChart && myChart.dispose) {
        myChart.dispose();
    }
    myChart = echarts.init(domMain,curTheme);
    myChart.setOption(options,true)
    window.onresize = myChart.resize;
}


function showAttr(obj,type){
        var content = $(obj).parent().attr("info");
        detail_table = $("<table class=\"table table-bordered table-condensed\" style=\"margin-bottom:8px;width:100%;table-layout:fixed;word-break:break-all; word-wrap:break-all;\"></table");
        header_obj = $("<tr><th style=\"width:20%\">序号</th><th style=\"width:80%\">"+type+"</th></tr>");
        header_obj.appendTo(detail_table);
        if(content!=""){
                var lines = content.split("`");
                for(var i=0;i<lines.length;i++){
                    tr_obj = $("<tr></tr>");
                    tr_obj.appendTo(detail_table);
                    $("<td>"+(i+1)+"</td>").appendTo(tr_obj); 
                    if(type=="URL"){
                        url = lines[i];
                        inner_html_list = url.split('?');
                        inner_html = inner_html_list[0];
                        for (var iner_idx = 1; iner_idx < inner_html_list.length; ++iner_idx) {
                            inner_html += "\003" + inner_html_list[iner_idx];
                        }
                        inner_html = inner_html.replace(new RegExp("/", 'gm'), '\002');
                        inner_html = inner_html.replace(new RegExp("#", 'gm'), '\004');
                        inner_html = '/url_search/other_list/' + inner_html + '\001' + $("#host_form_time").val();

                        $("<td> <a href=\""+inner_html+"\" target=\"_blank\">"+(lines[i])+"</a></td>").appendTo(tr_obj); 
                    }else{
                        $("<td> <a href=\"/query_search/other_list/"+lines[i]+ '\001' + $("#host_form_time").val() + "/\" target=\"_blank\">"+(lines[i])+"</a></td>").appendTo(tr_obj); 
                        // $("<td>"+(lines[i])+"</td>").appendTo(tr_obj); 
                    }
                }
        }
        var height = 330;
        if (type == 'Query') {
            height = 250;
        }
        var d = dialog({
            title : '数据详情',
            id: "host_data_dialog",
            content : detail_table.prop("outerHTML"),
            width : 600,
            height: height,
            fixed : true,
            cancel: false,
            okValue: '确定',
            ok : true,
            dragStart:function(){
                $("#content:host_data_dialog").css("heigth","230px;");
            }
        });
        d.showModal();
}

function expandHost(obj,day,key){
    var url = "/site_tools/fuzzy_search/";
    var param = "host_time="+day+"&host_name="+key;
    $.ajax({
        type :'POST',
        url : url,
        data : param,
        success : function(result) {
            if(result.status){
                showDetailHost(obj,key,day,result.msg);
            }else{
                showErrorMessage(result.msg);
            }
        }
    });
}
function hideDetailModal(){
    $('#host_detail_modal').modal('hide');
}
function searchDetailHost(row){
    $("#host_form_host_name").val(row);
    $("#host_form_btn").click();  
    hideDetailModal();
}
function hostBrowSubmit(key){
    $("#host_form_host_name").val(key);
    $("#host_form_btn").click();  
}
function updateHostBrow(key){
    var row_arr = new Array();
    row_arr = key.split("");
    key = row_arr.reverse().join("");
    $("#hostBrowArea").empty();
    link_obj = "> <a href=\"javascript:void(0);\" onclick=\"hostBrowSubmit('"+key+"');\">"+key+"</a>";
    $("#hostBrowArea").html(link_obj);
}
function showDetailHost(obj,key,day,detail_data_msg){
    $("#host_detail_modal_table").empty();
    host_data = eval(detail_data_msg);
    if(host_data.length==0){
        showMessage("warn","提示","查询无结果！");
        return;
    }
    //刷新页眉
    updateHostBrow(key);
    var cur_tr = $(obj).parent().parent();
    div_obj = $("<div style=\"width: 100%;height:500px;margin: 0px auto; display: block;\" class=\"row\"></div>");
    detail_table = $("<table class=\"table table-bordered table-condensed\" style=\"margin-bottom:8px;table-layout:fixed;word-break:break-all; word-wrap:break-all;\"></table");

    detail_table.appendTo(div_obj);
    header_obj = $("<tr><th style=\"width:8%\">序号</th><th style=\"width:15%\">Host</th><th style=\"width:8%\">PV</th><th style=\"width:8%\">UV</th><th style=\"width:8%\">Click</th><th style=\"width:15%\">android点击</th><th style=\"width:8%\">ios点击</th><th style=\"width:8%\">sc点击</th><th style=\"width:8%\">自然结果点击</th><th style=\"width:8%\">有点击uv</th></tr>");
    header_obj.appendTo(detail_table);

    for(var i=0;i<host_data.length;i++){
        var tr = $("<tr style=\"height:15px;\"></tr>");
        var row = host_data[i]["row"];
        var row_arr = new Array();
        row_arr = row.split("");
        row = row_arr.reverse().join("");
        var table_name = host_data[i]["table_name"];
        var pv = host_data[i]["pv"];
        var uv = host_data[i]["uv"];
        var clk = host_data[i]["clk"];
        var android_clk = host_data[i]["android_clk"];
        var ios_clk = host_data[i]["ios_clk"];
        var sc_clk = host_data[i]["sc_click"];
        var nature_click = host_data[i]["nature_click"];
        var click_uv = host_data[i]["click_uv"];
   		    	 
    
        var row_td = $("<td tyle=\"width:25%\"><a href=\"javascript:void(0);\" onclick=\"searchDetailHost('"+row+"');\">"+row+"</a></td>"); 
        var pv_td = $("<td tyle=\"width:8%\">"+pv+"</td>"); 
        var uv_td = $("<td>"+uv+"</td>"); 
        var clk_td = $("<td>"+clk+"</td>"); 
        var android_clk_td = $("<td>"+android_clk+"</td>"); 
        var ios_clk_td = $("<td>"+ios_clk+"</td>"); 
	var sc_clk_td = $("<td>"+sc_clk+"</td>"); 
        var nature_clk_td = $("<td>"+nature_click+"</td>"); 
        var clk_uv_clk_td = $("<td>"+click_uv+"</td>"); 
        
        //append to tr
        $("<td>"+(i+1)+"</td>").appendTo(tr);
        row_td.appendTo(tr);
        pv_td.appendTo(tr);
        uv_td.appendTo(tr);
        clk_td.appendTo(tr);
        android_clk_td.appendTo(tr);
        ios_clk_td.appendTo(tr);
        sc_clk_td.appendTo(tr);
        nature_clk_td.appendTo(tr);
        clk_uv_clk_td.appendTo(tr);
        tr.appendTo(detail_table);
    }
    div_obj.appendTo($("#host_detail_modal_table"));
    $("#host_detail_modal").modal({
        show:true,        
    });
}

function showTableData(host_data_msg){
    host_table = $("#host_data_table");
    //清理数据行
    $("#host_data_table tr:gt(0)").remove();
    host_data = eval(host_data_msg);
    for(var i=0;i<host_data.length;i++){
        var tr = $("<tr></tr>");
        var row = host_data[i]["row"];
        var table_name = host_data[i]["table_name"];
        var day = table_name.substr("shenma_log_host_feature_".length);
        var pv = host_data[i]["pv"];
        var uv = host_data[i]["uv"];
        var clk = host_data[i]["clk"];
        var android_clk = host_data[i]["android_clk"];
        var ios_clk = host_data[i]["ios_clk"];
        var sc_clk = host_data[i]["sc_click"];
        var nature_click = host_data[i]["nature_click"];
        var click_uv = host_data[i]["click_uv"];
        var querys = host_data[i]["querys"];
        var urls = host_data[i]["urls"];
        var day_td = $("<td>"+day+"</td>"); 
        var pv_td = $("<td>"+pv+"</td>"); 
        var uv_td = $("<td>"+uv+"</td>"); 
        var clk_td = $("<td>"+clk+"</td>"); 
        var android_clk_td = $("<td>"+android_clk+"</td>"); 
        var ios_clk_td = $("<td>"+ios_clk+"</td>"); 
        var sc_clk_td = $("<td>"+sc_clk+"</td>"); 
        var nature_clk_td = $("<td>"+nature_click+"</td>"); 
        var clk_uv_clk_td = $("<td>"+click_uv+"</td>"); 
        var querys_td = $("<td info=\""+querys+"\"><a href=\"javascript:void(0);\" onclick=\"showAttr(this,'Query');\">查看</a></td>"); 
        var urls_td = $("<td info=\""+urls+"\"><a href=\"javascript:void(0);\" onclick=\"showAttr(this,'URL');\">查看</a></td>"); 
        var operator_td = $("<td><a href=\"javascript:void(0);\" onclick=\"expandHost(this,'"+day+"','"+row+"');\">详情</a></td>"); 
        
        //append to tr
        day_td.appendTo(tr);
        pv_td.appendTo(tr);
        uv_td.appendTo(tr);
        clk_td.appendTo(tr);
        android_clk_td.appendTo(tr);
        ios_clk_td.appendTo(tr);
        sc_clk_td.appendTo(tr);
        nature_clk_td.appendTo(tr);
        clk_uv_clk_td.appendTo(tr);
        querys_td.appendTo(tr);
        urls_td.appendTo(tr);
        operator_td.appendTo(tr);
        tr.appendTo(host_table);
    }
}

function requireLoadCallBack(ec){
    echarts = ec;
 //   $("#host_form_btn").click();  
}
function requireLoadThemeCallBack(tarTheme){
    curTheme = tarTheme;
}
function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10);
}

function exportFeature(){
    var time = $("#host_form_time").val();
    var host = $("#host_form_host_name").val();
    var url = "/site_tools/export_feature/";
    var param= time+"&"+host;
    /*
    $.ajax({
        type :'post',
        url : url,
        data : param,
        success : function(result) {
        }
    });
    */
    window.open('/site_tools/export_feature/'+param+"/");
    //$('#host_data_table').table2excel({filename:"aa.xls"});
}

$(document).ready(function(){
    $("#host_form_btn").click(function(){
        hostSubmitAjax();
        return false;
    });

    $("#export_feature").click(function(){
        exportFeature();
        return false;
    });
    end_date = yesterday = get_pre_date(1);
    start_date = last_week = get_pre_date(7);
    last_month = get_pre_month(1);
    min_day = get_pre_month(3);
    $('#host_form_time').daterangepicker(
            {
                "ranges": {
                    "昨天": [
                        yesterday,
                        yesterday
                    ],
                    "近一周": [
                        last_week,
                        yesterday
                    ],
                    "近一个月": [
                        last_month,
                        yesterday
                    ],
                },
                "locale": {
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "fromLabel": "From",
                    "toLabel": "To",
                    "customRangeLabel": "自定义时间",
                    "daysOfWeek": [
                        "日", 
                        "一", 
                        "二", 
                        "三", 
                        "四", 
                        "五", 
                        "六"
                    ],
                    "monthNames": [
                        "一月",  
                        "二月",  
                        "三月",  
                        "四月",
                        "五月",
                        "六月",
                        "七月",
                        "八月",
                        "九月",
                        "十月",
                        "十一月",
                        "十二月"
                    ],
                    "firstDay": 1
                },
                opens: (App.isRTL() ? 'left' : 'right'),
                format: 'yyyy-MM-dd',
                separator: ' to ',
                startDate: last_week,
                endDate: yesterday,
                minDate: min_day,
                maxDate: yesterday
            }
        );
    $("#host_form_time").val(start_date+" to "+end_date);
    require.config({
        packages:[
            {
            name:'echarts',
            location:'../../static/js/echarts/src',
            main:'echarts',
            },
            {
            name: 'zrender',
            location: '../../../static/js/zrender',
            main: 'zrender'
            },
            {
            name: 'theme',
            location: '../../../static/js/echarts/src/theme',
            main: 'zrender'
            }
        ]
    });
    require([
        'echarts',
        'echarts/chart/line',
        'echarts/chart/bar'
    ],
    requireLoadCallBack
    );
    require([
        'theme/macarons'
    ],
    requireLoadThemeCallBack
    );
    
});
