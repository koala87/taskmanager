var unnamed_title_no = 0;
var project_tables = {};
$(function(){
    $('#remove_resource').dialog('close');
    $('#dialog_maintain_info').dialog('close');
    $(document).on('change', ".input_resource_search", function(){
        //$('#resource_tree').tree("doFilter", $(".input_resource_search").val().trim());
        get_resource_tree();
    });
    $(document).on('click', "[name=resource_save]", function(){
        var file_id = $(this).parent().parent().attr("action-data-file_id");
        var project = $(this).parent().parent().attr("action-data-project");
        var name = $(this).parent().parent().attr("action-data-name");
        if(!file_id)
        {
            show_save_file_dialog();
        }
        else
        {
            do_update_resource_file(file_id, project, name);
        }
    });
    CodeMirror.commands.save_resource_file = function (cm) {
        $("#tab_title").tabs('getSelected').find('.local_obj_save').trigger('click');
    };
    $("#form_new_jar [name='jar_upload_type']").on('change', function(){
        $("#form_new_jar .div_local").toggle();
        $("#form_new_jar .div_pangu").toggle();
    });
    $("#dialog_auth_manager [name='auth_manager_type']").on('change', function(){
        $("#dialog_auth_manager .select_grant").toggle();
        $("#dialog_auth_manager .select_revoke").toggle();
    });
    $(document).on('change', ".code_op_btn [type='file']", function(){
        var cur_tab = $("#tab_title").tabs('getSelected');
        show_div_loading(cur_tab);
        var callback = callback_asyn_ajax_file_upload;
        var file_ele_id = $(this).attr('id');
        asyn_ajax_file_upload(file_ele_id, callback);
    });
});
function callback_asyn_ajax_file_upload(result)
{
    var cur_tab = $("#tab_title").tabs('getSelected');
    hide_div_loading(cur_tab);
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    cur_tab.children().find("textarea").html(result.content+(result.to_large ? ',暂不支持编辑' : ''));
    var code_id = cur_tab.children().find("textarea").attr('id');
    SuperCmdCodeMirror.format(code_id, result.to_large, 'save_resource_file');
    cur_tab.children().find(".local_obj_save").removeClass("disable");
    cur_tab.children().find(".local_obj_save").prop('disabled',false);
    cur_tab.children().find(".local_obj_save img").attr('src','/static/images/supper_cmd/save.png');
    if(result.to_large)
    {
        cur_tab.children().find(".local_obj_save").attr('cdn_url',result.cdn_url);
    }
    else
    {
        cur_tab.children().find(".local_obj_save").attr('cdn_url','');
    }
}
function switch_resource_tree()
{
    if($(".switch_btn").hasClass('active'))
    {
        $(".switch_btn").removeClass('active');
    }
    else
    {
        $(".switch_btn").addClass('active');
    }
    refresh_resource_tree();
}
function refresh_resource_tree()
{
    $(".input_resource_search").trigger('change');
}
function get_resource_tree()
{
    var url = '/supper_cmd/odps_resource/list/';
    show_div_loading($('#resource_tree'), '列表加载中...');
    $('#resource_tree').tree({
        url:url,
        animate:true,
        queryParams:{
            project:$("#cur_project").text().trim(),
            key_word:$(".input_resource_search").val(),
            category_mode:1,
        },
        dnd:false,
        loadFilter: function(result){
            var nodes = [];
            var switch_auth = false;
            if($(".switch_btn").hasClass('active')) {
                switch_auth = true;
            } 

            if(result.status == 0) {
                var sorted_type = ['py', 'file', 'jar', 'table', 'archive'];
                for(var category of sorted_type) {
                    if(result.data[category] == undefined) {
                        continue
                    }
                    var children = []
                    for(var i in result.data[category]) {
                        var t = result.data[category][i];
                        if(!switch_auth || (t.perms.read || t.perms.write || t.perms.delete || t.perms.all)) {

                            children.push({id:t.id, text:t.detail.name, dxp_account:t.dxp_account, user_info:t.user_info, project:t.project, perms:t.perms, comment:t.detail.comment, type:t.detail.type, source_table_name:t.detail.source_table_name});
                        }
                    }
                    nodes.push({id: 0, text: category, state: 'close', children: children});
                }
            } else {
                ark_notify(result);
            }
            hide_div_loading($("#resource_tree"));
            return nodes;
        },
        onBeforeCollapse: function(e, node) {
            if(node == undefined) {
                return true;
            }
        },
        onContextMenu:function(e, node){
            e.preventDefault();
            var root_id = $('#resource_tree').tree('getRoot').id;
            var menu_id = 'resource_tree_menu_';
            if(node.id != root_id && $('#resource_tree').tree('isLeaf', node.target))
            {
                $("#resource_tree_menu").html('');
                if(node.perms.all) {
                    $('#resource_tree_menu').menu('appendItem', {text:'权限管理', 'iconCls':'icon-auth', onclick:'manager_auth(\'resource\','+node.id+',\''+node.text+'\')'});
                } else {
                    $('#resource_tree_menu').menu('appendItem', {text:'申请权限', 'iconCls':'icon-auth-apply', onclick:'apply("resource",'+node.id+',"申请资源权限")'});
                }
                if(node.type != 'table') {
                    $('#resource_tree_menu').menu('appendItem', {text:'下载', 'iconCls':'icon-download', onclick:'resource_download('+node.id+')'});
                }
                $('#resource_tree_menu').menu('appendItem', {text:'编辑', 'iconCls':'icon-edit', onclick:'edit_resource('+node.id+')'});
                $('#resource_tree_menu').menu('appendItem', {text:'删除', 'iconCls':'icon-delete', onclick:'remove_resource('+node.id+')'});

                // select the node
                $('#resource_tree').tree('select', node.target);
                // display context menu
                $.parser.parse($('#resource_tree_menu'));
                $('#resource_tree_menu').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            }
        },
        onClick:function(node) {
            if($('#resource_tree').tree('isLeaf', node.target)) {
                show_resource_info(node);
            }
        },
        onDblClick:function(node) {
            if($('#resource_tree').tree('isLeaf', node.target)) {
                open_resource_file(node);
            } else {
                $('#resource_tree').tree('toggle', node.target);
            }
        },
    });
}
function add_resource_local()
{
    unnamed_title_no += 1;
    var file_title = 'unnamed_resource_'+unnamed_title_no;
    var code_id = 'unnamed_code_'+unnamed_title_no;
    var file_upload_id = 'unnamed_file_upload_'+unnamed_title_no;
    $('#tab_title').tabs('add',{
        title:file_title,
        content:'<div class="easyui-layout" fit="true">\
<div class="code_northregion" action-data-project="" action-data-name="" action-data-file_id="" region="north" split="true" border="true" style="min-height:85px;width:100%;height:1000%;background-color: #3a3d3f;overflow:hidden;">\
<div class="code_op_btn">\
<span>快捷上传:</span>\
<span title="打开本地文件" class="local_obj">本地文件</span><input type="file" name="file" id="'+file_upload_id+'" style="cursor: pointer;opacity:0;position:absolute;top:5px;left:89px;width:60px; height:22px;">\
<span title="打开pangu文件" class="local_obj" onclick="select_pangu_path()">pangu文件</span>\
<span style="margin-left:40%"><input type="checkbox" name="switch_tab_to_spaces" checked>4个空格替代Tab</input></span>\
<span title="保存" class="local_obj local_obj_save disable" name="resource_save"><img src="/static/images/supper_cmd/save_disable.png"/>保存</span>\
</div>\
<textarea id="'+code_id+'" name="code"></textarea>\
</div>\
</div>',
        closable:true
    });
    SuperCmdCodeMirror.format(code_id, false, 'save_resource_file');
}

function select_pangu_path()
{
    $('#dialog_preview_pangu').dialog({
        title: 'pangu文件',
        width: 600,
        height: 'auto',
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_preview_pangu();
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_preview_pangu').dialog('close');
                $('#form_preview_pangu').form('clear');
            }
        }]
    });
}
function do_preview_pangu()
{
    show_div_loading($("#dialog_preview_pangu").parent(), '处理中，请稍候...');
    var url = '/common/preview_pangu_file/';
    var post_data = {file_path:$("#form_preview_pangu #preview_pangu_path").val().trim()};
    var args = {};
    var callback = callback_do_preview_pangu;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_preview_pangu(result, args)
{
    hide_div_loading($("#dialog_preview_pangu").parent());
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    else
    {
        $('#dialog_preview_pangu').dialog('close');
        $('#form_preview_pangu').form('clear');
        var cur_tab = $("#tab_title").tabs('getSelected');
        cur_tab.children().find("textarea").val(result.data+(result.to_large ? ',暂不支持编辑' : ''));
        var code_id = cur_tab.children().find("textarea").attr('id');
        SuperCmdCodeMirror.format(code_id, result.to_large, 'save_resource_file');
        cur_tab.children().find(".local_obj_save").removeClass("disable");
        cur_tab.children().find(".local_obj_save").prop('disabled',false);
        cur_tab.children().find(".local_obj_save img").attr('src','/static/images/supper_cmd/save.png');
        if(result.to_large)
        {
            cur_tab.children().find(".local_obj_save").attr('cdn_url',result.cdn_url);
        }
        else
        {
            cur_tab.children().find(".local_obj_save").attr('cdn_url','');
        }
    }
}
function show_save_file_dialog()
{
    var cur_tab = $("#tab_title").tabs('getSelected');
    var orig_title = cur_tab.panel('options').title;
    $("#dialog_new_resource #resource_name").val(orig_title),
    $('#dialog_new_resource').dialog({
        title: '新建文件',
        width: 600,
        height: 'auto',
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_save_file();
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_new_resource').dialog('close');
                $('#form_new_resource').form('clear');
            }
        }]
    });
}
function do_save_file()
{
    show_div_loading($("#dialog_new_resource").parent(), '处理中，请稍候...');
    var cur_tab = $("#tab_title").tabs('getSelected');
    var code_id = cur_tab.children().find("textarea").attr('id');
    var content = window.editor[code_id].getValue();
    var url = '/supper_cmd/odps_resource/create/';
    var name = $("#dialog_new_resource #resource_name").val().trim();
    var project = $("#cur_project").text().trim();
    var post_data = {
        project:project,
        name:name,
        type:$("#dialog_new_resource #resource_type").combobox('getValue'),
        comment:$("#dialog_new_resource #resource_desc").val().trim(),
    };
    var cdn_url = cur_tab.children().find(".local_obj_save").attr('cdn_url');
    if(cdn_url == undefined || !cdn_url)
    {
        post_data.content = content;
    }
    else
    {
        post_data.cdn_url = cdn_url;
    }
    var callback = callback_do_save_file;
    var args = post_data;
    args.content = content;
    args.code_id = code_id;
    args.cur_tab = cur_tab;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_save_file(result, args)
{
    hide_div_loading($("#dialog_new_resource").parent());
    ark_notify(result);
    if(result.status ==0)
    {
        get_resource_tree();
        var new_code_id = 'code_'+result.data.id;
        args.cur_tab.children().find(".code_northregion").attr('action-data-file_id', result.data.id);
        args.cur_tab.children().find(".code_northregion").attr('action-data-project', args.project);
        args.cur_tab.children().find(".code_northregion").attr('action-data-name', args.name);
        args.cur_tab.children().find(".code_northregion").attr('action-data-comment', args.comment);
        args.cur_tab.children().find("textarea").attr('id', new_code_id);
        args.cur_tab.children().find("textarea").val(args.content);
        // args.cur_tab.children().find(".local_obj_save").before('<span title="信息维护" class="local_obj local_obj_maintain" onclick="maintain_info()"><img src="/static/images/supper_cmd/maintain.png">信息维护</span>');
        $("#tab_title").tabs('update', {
            tab:args.cur_tab,
            type:'header',
            options: {
                title: args.project+'.'+args.name,
            }
        });
        window.editor[new_code_id] = window.editor[args.code_id];
        window.editor[new_code_id].markClean();
        CodeMirror.signal(window.editor[new_code_id], 'change');
        $('#dialog_new_resource').dialog('close');
    }
}
function show_resource_info(node)
{
    if($("#obj_info_op").attr('action-data-node-id') == node.id) {
        return;
    }
    var html = '';
    $("#obj_info_op").attr('action-data-node-id', node.id);
    $("#obj_info_op .obj_info_btn").remove();

    html += '<img class="obj_info_btn" title="删除" onclick="remove_resource('+node.id+')" src="/static/images/supper_cmd/delete.png"></img>';
    html += '<img class="obj_info_btn" title="编辑" onclick="edit_resource('+node.id+')" src="/static/images/supper_cmd/edit.png"></img>';
    if(node.type != 'table') {
        html += '<img class="obj_info_btn" title="下载" onclick="resource_download('+node.id+')" src="/static/images/supper_cmd/download.png"></img>';
    }

    if(node.perms.all) {
        html += '<img class="obj_info_btn" title="权限管理" onclick="manager_auth(\'resource\','+node.id+',\''+node.text+'\')" src="/static/images/supper_cmd/auth.png"></img>';
    } else {
        html += '<img class="obj_info_btn" title="申请权限" onclick="apply(\'resource\','+node.id+',\'申请资源权限\')" src="/static/images/supper_cmd/auth_apply.png"></img>';
    }

    $("#obj_info_op").append(html);
    $("#obj_info_op .obj_info_name").html(node.text);
    var url = '/supper_cmd/odps_resource/detail/';
    var post_data = {id:node.id};
    var callback = callback_show_resource_info;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_resource_info(result, args)
{
    var html = '';
    if(result.status == 0)
    {
        html += '<p class="detail_title">创建者</p>';
        html += '<p class="content">'+((result.data.user_info == undefined || !result.data.user_info) ? result.data.detail.owner : result.data.user_info.username_dsp)+'</p>';
        html += '<p class="detail_title">描述</p>';
        var comment = result.data.detail.comment ? result.data.detail.comment : '无';
        comment = comment.split('\n').join('<br>');
        html += '<p class="content">'+comment+'</p>';
        html += '<p class="detail_title">大小</p>';
        html += '<p class="content">'+result.data.detail.size+'</p>';
        html += '<p class="detail_title">创建时间</p>';
        html += '<p class="content">'+result.data.detail.creation_time+'</p>';
        html += '<p class="detail_title">更新时间</p>';
        html += '<p class="content">'+result.data.detail.last_modified_time+'</p>';
    } 
    $("#obj_info_region .obj_detail").html(html);
}
function add_resource_jar(node)
{
    if(node != undefined)
    {
        $("#form_new_jar #resource_type").combobox('setValue', node.type);
        $("#form_new_jar #resource_type").combobox('disable');
        $("#form_new_jar [name='comment']").val(node.comment);
        $("#form_new_jar [name='name']").val(node.text);
        $("#form_new_jar [name='name']").prop('readonly', true);
    }
    else
    {
        $("#form_new_jar #resource_type").combobox('enable');
        $("#form_new_jar [name='name']").prop('readonly', false);
    }
    $('#form_new_jar').show();
    $('#dialog_new_jar').dialog({
        title: node == undefined ? '新建资源' : '修改资源',
        width: 600,
        height: 'auto',
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_add_resource_jar(node);
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_new_jar').dialog('close');
                $('#form_new_jar').form('clear');
                $("#form_new_jar [name='jar_upload_type']:eq(0)").prop('checked', true);
                $("#form_new_jar .div_local").show();
                $("#form_new_jar .div_pangu").hide();
                $("#form_new_jar #resource_type").combobox('setValue', 'jar');
                $('#form_new_jar').hide();
            }
        }]
    });
    $("#form_new_jar [name='comment']").focus();
}
function do_add_resource_jar(node)
{
    if($("#form_new_jar [name='jar_upload_type']:checked").val() == 1)//pangu
    {
        $("#id_jar_filebox").filebox('setValue', '');
    }
    $('#form_new_jar').form('submit', {
        url:node == undefined ? '/supper_cmd/odps_resource/create/' : '/supper_cmd/odps_resource/update/',
        onSubmit: function(param){
            show_div_loading($("#dialog_new_jar").parent(), '处理中，请稍后...');
            param.project = $("#cur_project").text().trim();
            if($("#form_new_jar [name='jar_upload_type']:checked").val() == 1)//pangu
            {
                param.pangu_file = $('#form_new_jar #jar_upload_pangu_path').val().trim();
            }
        },
        success: function(result) {
            hide_div_loading($("#dialog_new_jar").parent());
            result = JSON.parse(result);
            ark_notify(result);
            if(result.status == 0)
            {
                get_resource_tree();
                $('#dialog_new_jar').dialog('close');
                $('#form_new_jar').form('clear');
                $("#form_new_jar [name='jar_upload_type']:eq(0)").prop('checked', true);
                $("#form_new_jar .div_local").show();
                $("#form_new_jar .div_pangu").hide();
                $("#form_new_jar #resource_type").combobox('setValue', 'jar');
                $('#form_new_jar').hide();
            }
        },
    });
}
function add_resource_table(node_info)
{
    $('#form_new_table').form('clear');
    $("#form_new_table .type").combobox('setValue', 'table');
    var project = 'aliyun_searchlog';
    if(node_info != undefined) {
        var tmp = node_info.source_table_name.split(' ');
        var partition = tmp[1] ? tmp[1].match(new RegExp(/\((.*)\)/))[1] : tmp[1];
        project = tmp[0].split('.')[0];
        var table_name = tmp[0].split('.')[1];
        $("#form_new_table .name").val(node_info.text);
        $("#form_new_table .comment").val(node_info.comment),
        $("#form_new_table .project").combobox('setValue', project),
        $("#form_new_table .table").combobox('setValue', table_name),
        $("#form_new_table .partition").val(partition),
        $("#form_new_table .name").prop('disabled', true);
    } else {
        $("#form_new_table .name").prop('disabled', false);
        $("#form_new_table .project").combobox('setValue', project);
    }
    refresh_table_list(project);

    $('#form_new_table').show();
    $('#dialog_new_table').dialog({
        title: node_info == undefined ? '新建资源' : '修改资源',
        width: 600,
        height: 'auto',
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_add_resource_table(node_info);
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_new_table').dialog('close');
            }
        }]
    });
}
function do_add_resource_table(node_info)
{
    show_div_loading($("#dialog_new_table").parent(), '处理中，请稍后...');
    var url = node_info == undefined ? '/supper_cmd/odps_resource/create/' : '/supper_cmd/odps_resource/update/';
    var post_data = {
        project:$("#cur_project").text().trim(),
        name:$("#form_new_table .name").val().trim(),
        type:$("#form_new_table .type").combobox('getValue'),
        comment:$("#form_new_table .comment").val().trim(),
        project_name:$("#form_new_table .project").combobox('getValue'),
        table_name:$("#form_new_table .table").combobox('getValue'),
        partition:$("#form_new_table .partition").val(),
    };
    var callback = callback_do_add_resource_table;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_add_resource_table(result, args)
{
    hide_div_loading($("#dialog_new_table").parent());
    if (result.status != 0) {
        ark_notify(result);
        return false;
    }
    else
    {
        $('#dialog_new_table').dialog('close');
        //$('#form_new_table').hide();
        //$("#form_new_table .table").combobox('loadData', {});
        //$('#form_new_table').form('clear');
        get_resource_tree();
    }
}
function open_resource_file(node)
{
    var id = node.id;
    var text = node.text;
    var project = node.project;
    var tab_title = project+'.'+text;
    if(node.type == 'file' || node.type == 'py')
    {
        if($('#tab_title').tabs('exists', tab_title))
        {
            $('#tab_title').tabs('select',tab_title);
        }
        else
        {
            show_div_loading($("#tab_title"));
            var url = '/supper_cmd/odps_resource/preview/';
            var post_data = {id:id};
            var callback = callback_open_resource_file;
            var args = {id:id, title:text, tab_title:tab_title, project:project, comment:node.comment};
            makeAPost(url, post_data, true, callback, args);

        }
    }
    else if(node.type == 'table')
    {
        add_resource_table(node);
    }
    else if(node.type == 'jar' || node.type == 'archive')
    {
        add_resource_jar(node);
    }
}
function callback_open_resource_file(result, args)
{
    hide_div_loading($("#tab_title"));
    var file_title = args.title;
    var file_id = args.id;
    var code_id = "code_"+file_id;
    if(result.status !=0)
    {
        ark_notify(result);
        return;
    }
    var file_upload_id = 'saved_file_upload_'+file_id;
    $('#tab_title').tabs('add',{
        title:args.tab_title,
        content:'<div class="easyui-layout" fit="true">\
<div class="code_northregion" action-data-comment="'+args.comment+'" action-data-project="'+args.project+'" action-data-name="'+file_title+'" action-data-file_id="'+file_id+'" region="north" split="true" border="true" style="min-height:85px;width:100%;height:100%;background-color: #3a3d3f;overflow:hidden;">\
<div class="code_op_btn">\
<span>快捷上传:</span>\
<span title="打开本地文件" class="local_obj">本地文件</span><input type="file" name="file" id="'+file_upload_id+'" style="cursor: pointer;opacity:0;position:absolute;top:5px;left:89px;width:60px; height:22px;">\
<span title="打开pangu文件" class="local_obj" onclick="select_pangu_path()">pangu文件</span>\
<span style="margin-left:40%"><input type="checkbox" name="switch_tab_to_spaces" checked>4个空格替代Tab</input></span>\
<span title="保存" cdn_url="'+(result.to_large ? result.cdn_url : '')+'" class="local_obj local_obj_save disable" name="resource_save"><img src="/static/images/supper_cmd/save_disable.png">保存</span>\
</div>\
<textarea id="'+code_id+'" name="code">'+result.data.content+(result.to_large ? ',暂不支持编辑' : '')+'</textarea>\
</div>\
</div>',
        closable:true
    });
    SuperCmdCodeMirror.format(code_id, result.to_large, 'save_resource_file');
    window.editor[code_id].markClean();
    CodeMirror.signal(window.editor[code_id], 'change');

}
function do_update_resource_file(file_id, project, name)
{
    var cur_tab = $("#tab_title").tabs('getSelected');
    show_div_loading(cur_tab.find('.code_northregion'));
    var code_id = cur_tab.children().find("textarea").attr('id');
    var content = window.editor[code_id].getValue();
    var url = '/supper_cmd/odps_resource/update/';
    var post_data = {project:project, name:name};
    var cdn_url = cur_tab.children().find(".local_obj_save").attr('cdn_url');
    if(cdn_url == undefined || !cdn_url)
    {
        post_data.content = content;
    }
    else
    {
        post_data.cdn_url = cdn_url;
    }
    console.log(post_data);
    var args = {code_id:code_id, cur_tab:cur_tab};
    var callback = callback_do_update_resource_file;
    makeAPost(url, post_data, true, callback, args);
}
function callback_do_update_resource_file(result, args)
{
    hide_div_loading(args.cur_tab.find('.code_northregion'));
    if(result.status != 0)
    {
        ark_notify(result);
        return;
    }
    window.editor[args.code_id].markClean();
    CodeMirror.signal(window.editor[args.code_id], 'change');
}
function asyn_ajax_file_upload(file_ele_id, callback)
{
    $.ajaxFileUpload(
        {
            url: '/supper_cmd/odps_resource/upload_res_file/',
            secureuri: false,

            fileElementId :file_ele_id,//file控件id
            dataType : 'json',
            data:{return_file_content : true},
            async:true,
            success: function(result) {
                result_data = result;
                callback(result);
            },
            error: function(XMLHttpRequest, textStatus, error) {
                result_data = {'status':1,'msg':'系统出错'};
                callback(result);
            }

        });
} 
function edit_resource()
{
    var cur_node = $('#resource_tree').tree('getSelected');
    open_resource_file(cur_node);
}
function remove_resource() {
    $('#dialog_remove #obj_type').val('resource');
    $('#dialog_remove [name=confirm_msg]').html('您确定要删除此资源？');
    $('#dialog_remove').dialog('open');
}

function resource_download(file_id)
{
    var url = '/supper_cmd/odps_resource/download/'+file_id+'/';
    download_flag = true;
    location.href = url;
    //window.open(url);
}

function refresh_table_list(project) {
    var tables = project_tables[project];
    if(tables) {
        $("#select_table_list").combobox('loadData', tables);
    } else {
        var url = '/dms/odps_table/list/';
        show_div_loading($("#dialog_new_table"), '表格列表加载中...');
        makeAPost(url, {'project': project}, true, function(result) {
            tables = [];
            if(result.status == 0) {
                for(var i in result.data) {
                    tables.push({id:result.data[i], text:result.data[i]});
                }
            } else {
                ark_notify(result);
            }
            hide_div_loading($("#dialog_new_table"));
            project_tables[project] = tables;
            $("#select_table_list").combobox('loadData', tables);
        });
    }
}

function maintain_info()
{
    var cur_tab = $("#tab_title").tabs('getSelected');
    var obj = cur_tab.children().find(".code_northregion");
    $('#form_maintain_info .comment').val(obj.attr('action-data-comment'));
    $('#dialog_maintain_info').dialog({
        height: 'auto',
        closed: false,
        cache: false,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_maintain_info();
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_maintain_info').dialog('close');
                $('#form_maintain_info').form('clear');
            }
        }]
    });
}
function do_maintain_info()
{
    var cur_tab = $("#tab_title").tabs('getSelected');
    var obj = cur_tab.children().find(".code_northregion");
    var project = obj.attr('action-data-project');
    var name = obj.attr('action-data-name');
    var url = '/supper_cmd/odps_resource/update/';
    var comment = $('#form_maintain_info .comment').val().trim();
    var post_data = {project:project, name:name, comment:comment};
    result = makeAPost(url, post_data);
    ark_notify(result);
    if(result.status == 0)
    {
        obj.attr('action-data-comment', comment);
        $('#dialog_maintain_info').dialog('close');
        $('#form_maintain_info').form('clear');
        get_resource_tree();
    }

}

