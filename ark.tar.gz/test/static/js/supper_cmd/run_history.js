$(function(){
    var grid_id = '_history_grid';
    window.RunHistory = {
        show: function() {
            var title = '__supercmd_run_history';
            if($('#tab_title').tabs('exists', title)) {
                $('#tab_title').tabs('select', title);
            } else {
                var content = '<div style="margin:5px 0 5px 30px">*转成定时任务请进入查看流程，复制该流程并作相应配置<span class="code_op_span" style="margin-left:50%;" name="refresh_run_history"><img title="刷新" src="/static/images/supper_cmd/refresh.png" >刷新<span></div><div class="easyui-layout" fit="true" name="run_history"><table id="' + grid_id + '"></div></div>';
                $('#tab_title').tabs('add', {
                    title: title,
                    content: content,
                    closable: true
                });

                $('#' + grid_id).datagrid({
                    url: '/supper_cmd/run_history/list/',
                    rownumbers:true,
                    singleSelect:true,
                    loadMsg:'加载中...',
                    fit:true,
                    pagination:true,
                    pageSize:50,
                    columns:[[
                        {field:'username_dsp',title:'发起者',width:80},
                        {field:'type',title:'任务类型',width:60},
                        {field:'name',title:'名称',width:200},
                        {field:'description',title:'描述',width:150,
                         formatter: function(val, row, index) {
                             var val = val.replace(/"/g, '&quot;');
                             return '<span class="easyui-tooltip" title="' + val + '">' + val + '</span>';
                         }},
                        {field:'create_time',title:'起始时间',width:150},
                        {field:'run_time',title:'运行时长',width:100},
                        {field:'status',title:'状态',width:70,
                         formatter: function(val, row, index) {
                             var str = PipelineStatus.display_with_color(val);
                             return str;
                         }
                        },
                        {field:'id',title:'操作',width:120,
                         formatter: function(val, row, index) {
                             if(row.type == '插件') {
                                 return '<a name="run_history_log_view" plugin_name="' + row.name + '" history_id=' + row.id + ' href="#">详情</a>&nbsp;&nbsp;<a target="_blank" href="/pipeline/history/' + row.pipeline_name + '/">查看流程</a>';
                             } else {
                                 return '暂无';
                             }
                         }}
                    ]],
                    loadFilter: function(result){
                        if (result.status == 0){
                            return result.data
                        } else {
                            ark_notify(result);
                            return {'total': 0, 'rows': []}
                        }
                    }
                });
            }
        }
    }
    $(document).on('click', "[name=refresh_run_history]", function(){
        $('#' + grid_id).datagrid('reload');        
    });

    $(document).on('click', "[name=run_history_log_view]", function(){
        var plugin_name = $(this).attr('plugin_name');
        var history_id = $(this).attr('history_id');
        var content = $(this).parent();
        var title = Plugin.get_title(plugin_name, history_id);
        if($('#tab_title').tabs('exists', title)) {
            $('#tab_title').tabs('select', title);
        } else {
            makeAPost('/supper_cmd/run_history/detail/', {'id': history_id}, true, function(result) {
                if(result.status == 0) {
                    var pipeline_name = result.data.pipeline_name;
                    var content = Plugin.get_code_mirror_content(
                        title, {'name': plugin_name, 
                                'content': result.data.description,
                                'pipeline_name': pipeline_name}, 
                        true);

                    window.plugin_run_status[title] = {
                        'run_history_id': history_id,
                        'run_status': result.data.status,
                        'cur_pos': 0};

                    $('#tab_title').tabs('add', {
                        title: title,
                        content: content,
                        closable: true
                    });

                    var cur_tab = $("#tab_title").tabs('getSelected');
                    Plugin.update_tab(cur_tab, plugin_name, history_id, pipeline_name);
                    /*
                    code_div = cur_tab.find('[name=code]')[0];
                    SuperCmdCodeMirror.format(title, false, null, code_div);
                    cur_tab.find('.code_northregion').attr('run-history-id', history_id);
                    */

                    var log_tab = cur_tab.find("[name=log_output]").tabs('getTab', 0);
                    var log_str = "日志查询中......<br/>";
                    log_tab.append(log_str);

                    Plugin.display_disable(cur_tab);
                    window.plugin_daemon_log[title] = window.setInterval(
                        'PluginLog.get_status("' + title + '",' + history_id + ')', 3000);
                } else {
                    ark_notify(result);
                }
            });
        }
    });
});