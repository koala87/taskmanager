view_dialog_id = 'view_dialog'

instance_table = null;
latest_data = true;

function finish_stop_instance(result) {
    ark_notify(result);
    instance_table.draw();
}
function stop_instance(project, name) {
    var url = "/supper_cmd/odps_instance/stop/";
    var data = {'project': project, 'name': name};
    result = makeAPost(url, data, true, finish_stop_instance);
}

function init_account_select() {
    var url = "/ark_user/has_account_users/";
    result = makeAPost(url);
    if(result.status != 0) {
        ark_notify(result);
    } else {
        users = result.data;
        var data = [];
        for(var id in users) {
            data.push({id: id, text: users[id]});
        }
        $("[name=owner]").select2({
            data: data,
            allowClear: true,
            createSearchChoice:function(term, data) { 
                if ($(data).filter(function() { 
                    return this.text.localeCompare(term)===0; 
                }).length===0) {
                    return {id:term, text:term};
                } 
            },
        });
    }
}

function init_project_list() {
    var url = "/ark_user/has_account_users/";
    result = makeAPost(url);
    if(result.status != 0) {
        ark_notify(result);
    } else {
        users = result.data;
        var data = [];
        for(var id in users) {
            data.push({id: id, text: users[id]});
        }
        $("[name=project]").select2({
            data: data,
            allowClear: true,
            createSearchChoice:function(term, data) { 
                if ($(data).filter(function() { 
                    return this.text.localeCompare(term)===0; 
                }).length===0) {
                    return {id:term, text:term};
                } 
            },
        });
    }
}

function get_instance_detail( project, name, fn ) {
    var url = "/supper_cmd/odps_instance/task_infos/";
    $.ajax({
        type :'post',
        url : url,
        dataType:"json",
        data : {'project':project, 'name':name},
        success : function(result) {
            fn(result);
        }
    });
}

function get_busy_html(project, name) {
    busy_obj = $('#row_detail_div').clone().prop({id:'row_detail_div_' + project + '_' + name});
    busy_obj.show();
    return busy_obj[0];
}

$(function(){
    init_account_select();
    
    instance_table = $('#instance_list').DataTable({
        "processing": true,
        "serverSide": true,
        "bLengthChange": false,
        "bPaginate": false,
        "order": [[3, "desc"]],
        "dom": '<"top"i>rt<"bottom"flp><"clear">',
        "fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
            return "共 " + iTotal + " 条记录";
        },
        "ajax": {
            "url": "/supper_cmd/odps_instance/list/",
            "type": "POST",
            "data": function(d) {
                d.project = $("[name=query_filter_area] [name=project]").val();
                d.name = $("[name=query_filter_area] [name=name]").val();
                d.owner = $("[name=query_filter_area] [name=owner]").val();
                d.status = $("[name=query_filter_area] [name=status]").val();
            }
        },
        "oLanguage": {
            "sEmptyTable": "查无执行中的实例",
            "sZeroRecords": "查无执行中的实例",
            "sProcessing": "获取最新状态 ......",
            "oPaginate": {"sPrevious": "上一页", "sNext": "下一页"},
        },
        "columns": [
            {
                "data": "project",
                "bSortable": false,
            },
            {
                "data": "name",
                "bSortable": false,
                "render": function(data, type, full) {
                    return "<a target='_blank' href='" + full.logview + "'>" + full.name + "</a>";
                }
            },
            {
                "data": "owner",
                "bSortable": true,
                "render": function(data, type, full) {
                    if(full.user_info && full.user_info.username_dsp) {
                        return full.user_info.username_dsp;
                    }
                    return data;
                }
            },
            { 
                "data": "start_time",
                "bSortable": true,
                "orderSequence": ["desc", "asc"],
                "render": function(data, type, full) {
                    var items = data.split(' ');
                    var time = items[1];
                    return '<span data-toggle="tooltip" data-placement="bottom" title="' + data + '">' + time + '<span>';
                }
            },
            { 
                "data": "run_time",
                "bSortable": true,
                "orderSequence": ["desc", "asc"],
                "render": function(data, type, full) {
                    color = full.run_seconds > 60 * 60 ? 'red' : '';
                    return '<span style="color:' + color + '"data-toggle="tooltip" data-placement="bottom" title="">' + data + '<span>';
                }
            },
            {
                "data": "workers",
                "bSortable": true,
                "orderSequence": ["desc", "asc"],
                "render": function(data, type, full) {
                    color = full.total_worker > 5000 ? 'red' : '';
                    return '<span data-toggle="tooltip" style="color:' + color + '" data-placement="bottom" title="执行中/结束的/总的[进度]">' + data + '<span>';
                }
            },
            { 
                "data": "priority",
                "bSortable": false, 
                "render": function(data, type, full) {
                    return '<span data-toggle="tooltip" data-placement="bottom" title="1-9 数字越小，优先级越高">' + data + '<span>';
                }
            },
            { "data": "status","searchable":false,"bSortable": false},
            {
                "data": "id",
                "bSortable": false,
                "render": function(data, type, full) {
                    var op_str = "<a class='glyphicon glyphicon-chevron-down' name='detail-control' data-toggle='tooltip' data-placement='bottom' data-original-title='查看任务详情'></a>&nbsp;&nbsp;";
                    if(full.status == 'Running') {
                        op_str += "<a class='glyphicon glyphicon-stop' name='stop-control' data-toggle='tooltip' data-placement='bottom' data-original-title='停止instance' data-loading-text='操作中...'></a>&nbsp;&nbsp;";
                    }
                    return op_str;
                }
            },
        ],
    });

    $('#instance_list tbody').on('click', '[name="stop-control"]', function () {
        if($(this).attr('disabled')) {
            return;
        }
        var tr = $(this).closest('tr');
        var row = instance_table.row( tr );
        if(confirm('确定停止instance: ' + row.data().name + " ?")) {
            $(this).button('loading');
            $(this).attr('disabled', true);
            stop_instance(row.data().project, row.data().name);
        }
    });

    $('#instance_list tbody').on('dblclick', 'tr', function() {
        $(this).find('[name="detail-control"]').trigger('click');
    });

    // Add event listener for opening and closing details
    $('#instance_list tbody').on('click', '[name="detail-control"]', function () {
        var tr = $(this).closest('tr');
        var row = instance_table.row( tr );
        
        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            $(this).attr("class", "glyphicon glyphicon-chevron-down");
        }
        else {
            $(this).attr("class", "glyphicon glyphicon-chevron-up");
            // Open this row
            busy_html = get_busy_html(row.data().project, row.data().name)
            row.child(busy_html).show();
            row.child().addClass('no-hover')
            refresh_instance_detail(row.data().project, row.data().name);
        }
    } );

    $('#instance_list').on('draw.dt', function () {
        $("[name=btn_auto_refresh]").prop("disabled", false);
        latest_data = true;
        $("[name=btn_query]").button('reset');
    });

    $("#instance_list_filter").hide();
    $("[name=btn_query]").click(function() {
        var project = $("[name=query_filter_area] [name=project]").val();
        OdpsInstance.getAndDisplayUsage(project);
        $("[name=btn_auto_refresh]").prop("disabled", true);
        $(this).button('loading');
        instance_table.draw();
    });

    setInterval(function() {
        if($("[name=btn_auto_refresh]").is(':checked') &&
           $("[name=btn_auto_refresh]").is(':disabled')) {
            if(!latest_data) {
                instance_table.draw();
            } else {
                latest_data = false;
            }
        }
    }, 60000);
})

function refresh_instance_detail(project, name) {
    var detail_id = 'row_detail_div_' + project + '_' + name;
    result = get_instance_detail(
        project, name, 
        function(result){
            if(result.status == 0) {
                table_html = make_dsp_html(result.data);
                $('#' + detail_id + ' #table').html(table_html);
            } else {
                $('#' + detail_id + ' #table')
                    .html("<div align='middle'><font color='red'>" + result.msg + "</font></div>");
            }
            $('#' + detail_id + ' #busy_icon').hide();
        });
}

function make_dsp_html(data) {
    table_html = '<table class="table table-bordered table-condensed" style="margin-bottom:8px"><thead>';
    table_html += '<th style="width:25%">任务</th><th style="width:15%">类型</th><th>进度</th>';
    for(var i = 0; i < data.length; i++) {
        table_html += '<tr><td>' + data[i][0] + '</td>';
        table_html += '<td>' + data[i][1] + '</td><td>';
        for(var j = 0; j < data[i][2].length; j++) {
            table_html +=  data[i][2][j] + '<br>';
        }
        table_html += '</td></tr>';
    }
    table_html += '</thead>';
    table_html += '</table>'
    return table_html
}


$(function() {
    window.OdpsInstance = {
        getOdpsUsage: function(project, callback) {
            var timestamp = new Date().toISOString();
            result = makeAPost(
                '/supper_cmd/odps_instance/odps_usage/',
                {'project': project, 'timestamp': timestamp},
                true, function(result) {
                    callback(result);
                }
            );
            return result;
        },
        getRatioColor: function(ratio) {
            return ratio > 100 ? 'red' : ratio > 50 ? 'orange' : 'green';
        },
        makeUsageHtml: function(usage) {
            var quotas = usage.quotas;
            var html = '';
            
            var quota = quotas.length > 0 ? quotas[0] : null;
            if(quota) {
                var min_cpu = quota.minCpu;
                var max_cpu = quota.cpu;
                var min_mem = quota.minMem;
                var max_mem = quota.mem;
                var used_cpu = quota.usedCpu;
                var used_mem = quota.usedMem;

                html += '<tr>';
                var ratio = (used_cpu * 100 / min_cpu).toFixed(2);
                var color = OdpsInstance.getRatioColor(ratio);
                html += '<td><font color="' + color + '">MinCPUUsage: ' + ratio + '%</font> (' + used_cpu + '/' + min_cpu + ')</td>';

                ratio = (used_mem * 100 / min_mem).toFixed(2);
                color = OdpsInstance.getRatioColor(ratio);
                html += '<td><font  color="' + color + '">MinMemUsage: ' + ratio + '%</font> (' + used_mem + '/' + min_mem + ')</td>';
                html += '</tr>';

                html += '<tr>';
                ratio = (used_cpu * 100 / max_cpu).toFixed(2);
                color = OdpsInstance.getRatioColor(ratio);
                html += '<td><font color="' + color + '">MaxCPUUsage: ' + ratio + '%</font> (' + used_cpu + '/' + max_cpu + ')</td>';

                ratio = (used_mem * 100 / max_mem).toFixed(2);
                color = OdpsInstance.getRatioColor(ratio);
                html += '<td><font color="' + color + '">MaxMemUsage: ' + ratio + '%</font> (' + used_mem + '/' + max_mem + ')</td>';
                html += '</tr>';
            }
            return html;
        },
        displayUsage: function(usage) {
            if(usage.status != 0) {
                console.log(usage);
                ark_notify(usage);
            } else {
                var html = OdpsInstance.makeUsageHtml(usage);
                $("[name=odps_usage]").html(html);
            }
        },
        getAndDisplayUsage: function(project) {
            var result = OdpsInstance.getOdpsUsage(
                project, OdpsInstance.displayUsage);
        }
    }
    OdpsInstance.getAndDisplayUsage('aliyun_searchlog');
});