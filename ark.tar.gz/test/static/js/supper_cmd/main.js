window.editor = {};
window.sql_run_status = {};
window.daemon_log = {};
RUN_STATUS_STOPED = 0;
RUN_STATUS_RUNNING = 1;
TASK_RUNNING = 1; // 正在执行
TASK_SUCCEED = 2; //  执行成功
TASK_FAILED = 3;  // 执行失败
download_flag = false;
$(function(){
    $("#init_cover").remove();
    $.extend($.fn.tabs.methods, {
        setTabTitle:function(jq,opts){
            return jq.each(function(){
                var tab = opts.tab;
                var options = tab.panel("options");
                var tab = options.tab;
                options.title = opts.title;
                var title = tab.find("span.tabs-title");
                title.html(opts.title);
            });
        }
    });
    $(window).bind('beforeunload',function(e, a){
        //if(window.location.pathname == '/supper_cmd/download_odps_table_data/' || window.location.pathname == '/supper_cmd/download_result/')
        if(download_flag)
        {
            download_flag = false;
            return;
        }
        var url = '/supper_cmd/save_file_last_files/';
        var file_id_list = [];
        $(".code_northregion").each(function(){
            file_id_list.push($(this).attr('action-data-file_id'));
        });
        var post_data = {'file_id_list':file_id_list};
        makeAPost(url, post_data, false);
        for(var i in $("#tab_title").tabs('tabs'))
        {
            var title = $("#tab_title").tabs('tabs')[i].panel("options").title;
            if(title.indexOf('*') >= 0)
            {
                return "有未保存的文件";
            }
        }
    });
    $('#sure_dialog').dialog('close');
    $('#remove_file').dialog('close');
    $('#text_close').dialog('close');

    show_odps_tables(0);
    $(document).on('change', ".input_tables_search", function(){
        show_odps_tables(0);
    });
    $(document).on('click', ".refresh_btn", function(){
        //$(".input_tables_search").val("");
        show_odps_tables(1);
    });
    $(document).on('click', ".table_info_refresh_btn", function(){
        var table_name = $("#table_info_op .table_info_name").html();
        if(table_name == '')
        {
            return;
        }
        show_div_loading($("body>.layout-panel-west"), '正在加载中...');
        $("#partion_detail").hide();
        $("#table_info_detail").hide();
        $("#table_region .panel").hide();
        show_odps_table_schema(table_name, 1);
        show_table_partitions(table_name, 1);
        show_odps_table_detail(table_name, 1);
    });
    $(".view-type-div").on('click', function(){
        var type_name = $(this).attr('action-data-type-name');
        if(!$(this).hasClass("active"))
        {
            $(".view-type-div").removeClass('active');
            $(this).addClass('active');
            if(type_name == 'table')
            {
                var html = '<div class="easyui-layout" fit="true" style="height:100%;">\
                                <div region="north" class="north_tables_list" split="true" border="false" style="height:50%;background:#3c3f41;">\
                                    <div id="table_op_header">\
                                        <span class="title">Table</span>\
                                        <img class="refresh_btn" src="/static/images/supper_cmd/refresh.png"></img>\
                                        <input class="input_tables_search" type="text">\
                                    </div>\
                                    <div class="div_table_list">\
                                    </div>\
                                </div>\
                                <div id="table_region" region="center" border="false" style="height:50%;overflow:hidden;background:#3a3d3e;">\
                                    <div id="table_info_op">\
                                        <span class="table_info_name" hidden></span>\
                                        <span class="table_info_tab table_info_columns active">Columns</span>\
                                        <span class="table_info_tab table_info_partition">Partitions</span>\
                                        <span class="table_info_tab table_info_detail">Info</span>\
                                        <img class="table_info_refresh_btn" style="margin-top: -5px;" src="/static/images/supper_cmd/refresh.png"></img>\
                                    </div>\
                                    <table id="table_info" style="background:#3a3d3e;"\
                                            border="false" rownumbers="true"\
                                            fit="true" fitColumns="false" singleSelect="true">\
                                        <thead>\
                                            <tr>\
                                               <th field="columns" width="80">Columns</th>\
                                               <th field="type" width="80">Type</th>\
                                               <th field="desc" width="80">Desc.</th>\
                                            </tr>\
                                        </thead>\
                                        <tbody>\
                                        </tbody>\
                                    </table>\
                                    <div id="partion_detail" style="display:none;"></div>\
                                    <div id="table_info_detail" style="display:none;"></div>\
                                </div>\
                            </div>';
                $(".left_view_center").html(html);
                $.parser.parse($(".left_view_center").parent());
                init_table_info();
                $(".input_tables_search").trigger("change");
            }
            else if(type_name == 'favorite')
            {
                var html = '<div class="easyui-layout" style="height:100%;background:#3c3f41;">\
                                <div region="north" class="north_tables_list" split="false" border="false" style="overflow:auto;height:100%;background:#3c3f41;">\
                                    <div id="favorite_op_header" style="background:#3c3f41;">\
                                            <span class="title">File</span>\
                                            <input style="margin-right:10px;" class="input_favorite_search" type="text">\
                                    </div>\
                                    <ul id="favorite_tree"></ul>\
                                </div>\
                            </div>';
                $(".left_view_center").html(html);
                get_favorite_tree();
                $(".input_favorite_search").trigger("change");
            }
            else if(type_name == 'resource')
            {
                var html = '<div class="easyui-layout" fit="true" style="height:100%;background:#3c3f41;">\
                                <div region="north" class="north_tables_list" split="true" border="false" style="overflow:auto;height:50%;background:#3c3f41;">\
                                    <div id="resource_op_header" class="op_header" style="background:#3c3f41;">\
                                            <span class="title">Resource</span>\
                                            <img class="obj_btn easyui-menubutton" data-options="menu:\'#resource_add_op\'" src="/static/images/supper_cmd/add.png">\
                                            <img class="obj_btn easyui-linkbutton switch_btn" data-options="plain:true" title="权限过滤" onclick="switch_resource_tree()" src="/static/images/supper_cmd/filter.png">\
                                            <img class="obj_btn easyui-linkbutton" data-options="plain:true" title="刷新" onclick="refresh_resource_tree()" src="/static/images/supper_cmd/refresh.png">\
                                            <input name="input_obj_search" style="margin-right:10px;" class="input_resource_search" type="text">\
                                    </div>\
                                    <div id="resource_add_op" style="width:150px;">\
                                        <div onclick="add_resource_local()">新建file或py脚本</div>\
                                        <div onclick="add_resource_jar()">jar或archive</div>\
                                        <div onclick="add_resource_table()">选择table</div>\
                                    </div>\
                                    <ul id="resource_tree" class="obj_tree"></ul>\
                                </div>\
                                <div id="obj_info_region" region="center" border="false" style="height:50%;overflow:hidden;background:#3a3d3e;padding: 0 10px;">\
                                    <div id="obj_info_op" action-data-node-id="">\
                                        <span class="obj_info_name">summary:</span>\
                                    </div>\
                                    <div class="obj_detail" style="height: 90%;width:100%;overflow-y: auto;margin: 0 -10px;border-top: 4px solid #444;padding: 0 10px;">\
                                    </div>\
                                </div>\
                            </div>';
                $(".left_view_center").html(html);
                $.parser.parse($(".left_view_center").parent());
                $(".input_resource_search").trigger("change");
            }
            else if(type_name == 'function') {
                var html = '<div class="easyui-layout" fit="true" style="height:100%;background:#3c3f41;">\
                                <div region="north" class="north_tables_list" split="true" border="false" style="overflow:auto;height:50%;background:#3c3f41;">\
                                    <div id="function_op_header" class="op_header" style="background:#3c3f41;">\
                                            <span class="title">Function</span>\
                                            <img class="obj_btn easyui-menubutton" data-options="plain:true" onclick="add_function()" src="/static/images/supper_cmd/add.png">\
                                            <img class="obj_btn easyui-linkbutton switch_btn" data-options="plain:true" title="权限过滤" onclick="switch_function_tree()" src="/static/images/supper_cmd/filter.png">\
                                            <img class="obj_btn easyui-linkbutton" data-options="plain:true" title="刷新" onclick="refresh_function_tree()" src="/static/images/supper_cmd/refresh.png">\
                                            <input name="input_obj_search" style="margin-right:10px;" class="input_function_search" type="text">\
                                    </div>\
                                    <ul id="function_tree" class="obj_tree"></ul>\
                                </div>\
                                <div id="obj_info_region" region="center" border="false" style="height:50%;overflow:hidden;background:#3a3d3e;padding: 0 10px;">\
                                    <div id="obj_info_op" action-data-node-id="">\
                                        <span class="obj_info_name">summary:</span>\
                                    </div>\
                                    <div class="obj_detail" style="height: 90%;width:100%;overflow-y: auto;margin: 0 -10px;border-top: 4px solid #444;padding: 0 10px;">\
                                    </div>\
                                </div>\
                            </div>';

                // var html = $("#function_tab_layout").html();
                $(".left_view_center").html(html);
                $.parser.parse($(".left_view_center").parent());
                $(".input_function_search").trigger("change");
            } else if(type_name == 'sql_template') {
                var html = '<div class="easyui-layout" fit="true" style="height:100%;background:#3c3f41;">\
                                <div region="north" class="north_tables_list" split="true" border="false" style="overflow:auto;height:50%;background:#3c3f41;">\
                                    <div id="sql_template_op_header" class="op_header" style="background:#3c3f41;">\
                                            <span class="title">Template</span>\
                                            <img class="obj_btn easyui-menubutton" data-options="plain:true" onclick="SqlTemplate.new()" src="/static/images/supper_cmd/add.png">\
                                            <img class="obj_btn easyui-linkbutton" data-options="plain:true" title="刷新" onclick="SqlTemplate.refresh_tree()" src="/static/images/supper_cmd/refresh.png">\
                                            <input name="input_obj_search" style="margin-right:10px;" class="input_sql_template_search" type="text">\
                                    </div>\
                                    <ul id="sql_template_tree" class="obj_tree"></ul>\
                                </div>\
                                <div id="obj_info_region" region="center" border="false" style="height:50%;overflow:hidden;background:#3a3d3e;padding: 0 10px;">\
                                    <div id="obj_info_op" action-data-node-id="">\
                                        <span class="obj_info_name">summary:</span>\
                                    </div>\
                                    <div class="obj_detail" style="height: 90%;width:100%;overflow-y: auto;margin: 0 -10px;border-top: 4px solid #444;padding: 0 10px;">\
                                    </div>\
                                </div>\
                            </div>';

                // var html = $("#sql_template_tab_layout").html();
                $(".left_view_center").html(html);
                $.parser.parse($(".left_view_center").parent());
                $(".input_sql_template_search").trigger("change");
            } else if(type_name == 'plugin') {
                var html = Plugin.listHtml();
                $(".left_view_center").html(html);
                $.parser.parse($(".left_view_center").parent());
                $(".input_plugin_search").trigger("change");
            } else if(type_name == 'run_history') {
                RunHistory.show()
            }
        } else if(type_name == 'run_history') {
            RunHistory.show()
        }
    });
    $(document).on('change', ".input_favorite_search", function(){
        $('#favorite_tree').tree("doFilter", $(".input_favorite_search").val().trim());
    });
    $(document).on('click', ".div_table_list p", function(){
        if(!$(this).hasClass("checked"))
        {
            $(".div_table_list p").removeClass('checked');
            $(this).addClass("checked");
            $(".div_table_list p").css('background', 'none');
            $(this).css('background-color', '#0d293e');
            $("#table_info_op .table_info_name").html($(this).html());

            if(!$("#table_info_op .table_info_columns").hasClass("active"))
            {
                $("#table_info_op .table_info_columns").addClass("active");
                $("#table_info_op .table_info_partition").removeClass("active");
                $("#table_info_op .table_info_detail").removeClass("active");
            }
            show_odps_table_schema($(this).html(), 0);
            $("#partion_detail").html('');
            $("#table_info_detail").html('');
        }
    });
    $(document).on('dblclick', ".div_table_list p", function(){
        var table_name = $(this).html();
        open_tab(table_name);
    });
    init_table_info();
    $(document).on('click', "#tab_title .preview_search_span_btn", function(){
        var table_name = $(this).parent().attr("action-data-table_name");
        open_tab(table_name);
        //$(".div_table_list p[action-data='"+table_name+"']").trigger('dblclick');
        return;
        var part = $(this).parent().find(".preview_search_input_val").val().trim();
        var limit = $(this).parent().find(".preview_search_input_lines").val().trim();
        var url = '/supper_cmd/show_odps_table_datas/';
        var post_data = {'table_name':table_name, 'part':part, 'limit':limit, 'force_refresh': 1};
        var result = makeAPost(url, post_data, false);
        if(result.status == 0)
        {
            if(result.header.length > 0)
            {
                var columns = [];
                var table_id = $(this).parent().parent().find('table.table_preview').attr('id');
                for(index_col in result.header)
                {
                    columns.push({'field':result.header[index_col], 'title':result.header[index_col], 'width':180});
                }
                $("#"+table_id).datagrid({
                    url:"/supper_cmd/get_more_result/",
                    rownumbers:true,
                    singleSelect:true,
                    loadMsg:'加载中...',
                    fit:true,
                    pagination:true,
                    pageSize:50,
                    columns:[columns],
                    queryParams: {
                        result_no: result.result_no,
                        file_id:result.file_id
                    },
                    onDblClickRow:function(index,row){
                        var data_table = [];
                        for(key in row)
                        {
                            data_table.push({f1:key, f2:row[key]});
                        }
                        $("#dialog_row_detail_table").datagrid({
                            data: data_table,
                            columns:[[
                                {field:'f1',title:'column', width:40},
                                {field:'f2',title:'value', width:120}
                            ]],
                            fit:true,
                            fitColumns:true,
                            singleSelect:true,
                            nowrap:false,
                            rownumbers:true,
                                rowStyler: function(index,row){
                                    return 'background-color:#3c3f41;'; // return inline style
                                }
                        });
                        $('#dialog_row_detail').dialog({
                            title: 'Row Detail',
                            width: 600,
                            height: 400,
                            closed: false,
                            cache: false,
                            modal: true,
                            resizable:true,
                            buttons:[{
                                text:'关闭',
                                handler:function(){
                                    $('#dialog_row_detail').dialog('close');
                                }
                            }]
                        });
                    },
                    loadFilter: function(data){
                        return data.data;
                    }
                });
                //设置分页控件 
                var p = $("#"+table_id).datagrid('getPager'); 
                $(p).pagination({ 
                    pageSize: 50,//每页显示的记录条数，默认为10 
                    pageList: [50, 100, 200],//可以设置每页记录条数的列表 
                    beforePageText: '第',//页数文本框前显示的汉字 
                    afterPageText: '页    共 {pages} 页', 
                    displayMsg: '当前显示 {from} - {to} 条记录   共 {total} 条记录'
                });
            }
        }
        else
        {
            ark_notify(result);
        }
    
    });
    $(document).on('click', "#table_info_op .table_info_columns", function(){
        if(!$(this).hasClass("active"))
        {
            $("#table_info_op .table_info_partition").removeClass("active");
            $("#table_info_op .table_info_detail").removeClass("active");
            $("#table_info_op .table_info_columns").addClass("active");
            $("#partion_detail").hide();
            $("#table_info_detail").hide();
            if($("#table_info_op .table_info_name").html() != '')
            {
                $("#table_region .panel").show();
            }
        }
    });
    $(document).on('click', "#table_info_op .table_info_partition", function(){
        if(!$(this).hasClass("active"))
        {
            $("#table_info_op .table_info_columns").removeClass("active");
            $("#table_info_op .table_info_detail").removeClass("active");
            $("#table_info_op .table_info_partition").addClass("active");
            $("#table_region .panel").hide();
            $("#table_info_detail").hide();
            if($("#table_info_op .table_info_name").html() != '')
            {
                show_table_partitions($("#table_info_op .table_info_name").html(), 0);
            }
        }
    });
    $(document).on('click', "#table_info_op .table_info_detail", function(){
        if(!$(this).hasClass("active"))
        {
            $("#table_info_op .table_info_columns").removeClass("active");
            $("#table_info_op .table_info_partition").removeClass("active");
            $("#table_info_op .table_info_detail").addClass("active");
            $("#table_region .panel").hide();
            $("#partion_detail").hide();
            if($("#table_info_op .table_info_name").html() != '')
            {
                show_odps_table_detail($("#table_info_op .table_info_name").html(), 0);
            }
        }
    });
    $('input.easyui-validatebox').validatebox('disableValidation')
            .focus(function () { $(this).validatebox('enableValidation'); })
            .blur(function () { $(this).validatebox('validate') });
    $(document).on('click', "[name=sql].code_op_type_save", function(){
        var file_id = $(this).parent().parent().attr("action-data-file_id");
        var content = window.editor['code_'+file_id].getValue();
        save_file(file_id, content);
    });
    $(document).on('click', "[name=sql].code_op_type_run", function(){
        if($(this).hasClass("disable"))
        {
            return;
        }
        var file_id = $(this).parent().parent().attr("action-data-file_id");
        var content = window.editor['code_'+file_id].somethingSelected() ? window.editor['code_'+file_id].getSelection().trim() : window.editor['code_'+file_id].getValue().trim();
        if(content == '')
        {
            ark_notify({status:1,msg:'待执行的语句为空'});
            return;
        }
        var url = '/supper_cmd/run_sql/';
        var post_data = {'file_id':file_id, 'sql':content};
        var result = makeAPost(url, post_data, false);
        // ark_notify(result);
        if(result.status == 0)
        {
            /*
            $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save").addClass("disable");
            $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save img").attr('src','/static/images/supper_cmd/save_disable.png');

            window.editor['code_'+file_id].markClean();
            CodeMirror.signal(window.editor['code_'+file_id], 'change');
            */
            window.sql_run_status['status_'+file_id].run_status = RUN_STATUS_RUNNING;
            window.sql_run_status['status_'+file_id].cur_pos = 0;
            //清空日志
            //$("#tab_output_"+file_id).tabs('getTab', 0).html('');
            //关闭之前的结果
            for(var i=1; i<$("#tab_output_"+file_id).tabs("tabs").length;)
            {
                $("#tab_output_"+file_id).tabs("close", i);
            }
            log_str = "<br/>.<br/>.<br/>.<br/><br/>提交sql成功，正在执行中......<br/><br/>"
            $("#tab_output_" + file_id).tabs('getTab', 0).append(log_str);
            $(this).addClass("disable");
            $(this).find("img").attr('src','/static/images/supper_cmd/run_disable.png');
            $(this).parent().find(".code_op_type_stop").removeClass("disable");
            $(this).parent().find(".code_op_type_stop img").attr('src','/static/images/supper_cmd/stop.png');
            daemon_run_status();
        }
        else
        {
            ark_notify(result);
        }
    });
    $(document).on('click', "[name=sql].code_op_type_stop", function(){
        if($(this).hasClass("disable"))
        {
            return;
        }
        var file_id = $(this).parent().parent().attr("action-data-file_id");
        var url = '/supper_cmd/stop_task/';
        var post_data = {'file_id':file_id};
        var result = makeAPost(url, post_data, false);
        // ark_notify(result);
        if(result.status == 0)
        {
            window.sql_run_status['status_'+file_id].run_status = RUN_STATUS_STOPED;
            window.sql_run_status['status_'+file_id].cur_pos = 0;
            log_str = "<br/><font style='color:#DF6A53!important'>执行停止！</font><br/>"
            $("#tab_output_" + file_id).tabs('getTab', 0).append(log_str);
            clearInterval(window.daemon_log[file_id]);
            delete window.daemon_log[file_id];
            $(this).addClass("disable");
            $(this).find("img").attr('src','/static/images/supper_cmd/stop_disable.png');
            $(this).parent().find(".code_op_type_run").removeClass("disable");
            $(this).parent().find(".code_op_type_run img").attr('src','/static/images/supper_cmd/run.png');
            //daemon_run_status();
        }
    });
    $("#tab_title").tabs({
       onBeforeClose: function(title, index){
            if(/.*_preview$|^plugin\..+$/.test(title) == false) {
                var code_id = $("#tab_title").tabs('getTab', title).children().find("textarea").attr('id');
                if(window.editor[code_id] && window.editor[code_id].isClean() == false)
                {
                    $('#text_close').dialog('open');
                    $('#text_close').dialog({
                        modal: true,
                        buttons: [
                        {
                            text:'保存',
                            iconCls:'icon-save',
                            handler:function(){
                                if($("#tab_title").tabs('getTab', title).find('.code_northregion').attr('action-data-name') != undefined)//保存资源文件
                                {
                                    $("#tab_title").tabs('getTab', title).find('.local_resource_save').trigger('click');
                                }
                                else
                                {
                                    var split_arr = code_id.split('_');
                                    var file_id = split_arr[1];
                                    var content = window.editor[code_id].getValue();
                                    save_file(file_id, content);
                                }

                                var opts = $("#tab_title").tabs('options');
                                var bc = opts.onBeforeClose;
                                opts.onBeforeClose = function(){};  // allowed to close now
                                title_split = title.split('*');
                                title = title_split[0];
                                $("#tab_title").tabs('close', title);
                                opts.onBeforeClose = bc;  // restore the event function                            
                                $('#text_close').dialog('close');
                            }
                        },{
                            text:'不保存',
                            iconCls:'icon-undo',
                            handler:function(){
                                var opts = $("#tab_title").tabs('options');
                                var bc = opts.onBeforeClose;
                                opts.onBeforeClose = function(){};  // allowed to close now
                                $("#tab_title").tabs('close', title);
                                opts.onBeforeClose = bc;  // restore the event function                            
                                $('#text_close').dialog('close');
                            }
                        },{
                            text:'取消',
                            iconCls:'icon-clear',
                            handler:function(){
                                $('#text_close').dialog('close');
                            }
                        }]
                    });
                    /*
                    $.messager.confirm('确认','文件['+title+']未保存，您确定要关闭此文件吗？',function(r){
                        if(r)
                        {
                             var opts = $("#tab_title").tabs('options');
                             var bc = opts.onBeforeClose;
                             opts.onBeforeClose = function(){};  // allowed to close now
                             $("#tab_title").tabs('close', title);
                             opts.onBeforeClose = bc;  // restore the event function
                        }
                    });
                    */
                    return false;
                }
            }
       }
    });
    $(document).on('keyup', '.preview_search_input_val', function(e){
        var ev = document.all ? window.event : e;
        if(ev.keyCode==13) {
            $(this).parent().find(".preview_search_span_btn").trigger('click');
        }
    });
    $(document).on('keyup', '.preview_header  .validatebox-text', function(e){
        var ev = document.all ? window.event : e;
        if(ev.keyCode==13) {
            $(this).parent().parent().find(".preview_search_span_btn").trigger('click');
        }
    });
    $(document).on('keyup', '#dialog_new_panel input[name="file_name"]', function(e){
        var ev = document.all ? window.event : e;
        if(ev.keyCode==13) {
            do_add_panel();
        }
    });
    CodeMirror.commands.runcode = function (cm) {
        $("#tab_title").tabs('getSelected').find('.code_op_type_run').trigger('click');
    };
    CodeMirror.commands.savefile = function (cm) {
        $("#tab_title").tabs('getSelected').find('.code_op_type_save').trigger('click');
    };
    open_last_files();
});

function file_close_sure() {
    $('#remove_file').dialog('close');
    var cur_node = $('#favorite_tree').tree('getSelected');
    var old_name = cur_node.text;
    var url = '/supper_cmd/delete_file/';
    var post_data = {'file_id':cur_node.id};
    var result = makeAPost(url, post_data, false);
    if(result.status == 0)
    {
        if($('#tab_title').tabs('exists', old_name)) {
            $('#tab_title').tabs('close', old_name);
        }

        $('#favorite_tree').tree('remove', cur_node.target);
    } else {
        ark_notify(result);
    }
}
var tab_index = 0;

function add_panel_no_tree(){
    var url = '/supper_cmd/show_file_tree_ex/';
    var post_data = {'tree_type':0};
    var result = makeAPost(url, post_data, false);
    var file_tree = result;
    $("#tree_new_file").combotree({
        data:file_tree
    });
    $("#tree_new_file").combotree('setValue', result[0].id);
    $('#dialog_new_panel input[name="file_name"]').val("default");
    $('#dialog_new_panel').dialog({
        title: '新建文件',
        width: 600,
        height: 220,
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_add_panel();
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_new_panel').dialog('close');
                $('#form_new_file').form('clear');
            }
        }]
    });
}


function addPanel(){
    var url = '/supper_cmd/show_file_tree_ex/';
    var post_data = {'tree_type':0};
    var result = makeAPost(url, post_data, false);
    var file_tree = result;
    $("#tree_new_file").combotree({
        data:file_tree
    });
    var cur_node = $('#favorite_tree').tree('getSelected');
    $("#tree_new_file").combotree('setValue', cur_node.id);
    $('#dialog_new_panel input[name="file_name"]').val("default");
    $('#dialog_new_panel').dialog({
        title: '新建文件',
        width: 600,
        height: 220,
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_add_panel();
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_new_panel').dialog('close');
                $('#form_new_file').form('clear');
            }
        }]
    });
}

function do_add_panel()
{
    var url = '/supper_cmd/create_new_file/';
    $('#form_new_file').form({
        url:url,
        onSubmit: function(){
            var parent_id = $('#dialog_new_panel input[name="parent_id"]').val();
            if(parent_id =='' || isNaN(parent_id))
            {
                ark_notify({status:1,msg:'请输入文件名并选择文件位置'});
                return false;
            }
            return $(this).form('enableValidation').form('validate');
        },
        success:function(data){
            data = $.parseJSON(data);
            if(data.status ==0)
            {
                window.sql_run_status['status_'+data.file_id] = {'file_id':data.file_id, 'run_status':RUN_STATUS_STOPED};
                var title = $('#dialog_new_panel input[name="file_name"]').val();
                var code_id = "code_"+data.file_id;
                $('#tab_title').tabs('add',{
                    title: title,
                    selected: true,
                    content: '<div class="easyui-layout" fit="true" name="sql">\
                                   <div class="code_northregion" action-data-file_id="'+data.file_id+'" region="north" split="true" border="true" style="min-height:85px;width:100%;height:70%;background-color: #3a3d3f;overflow:hidden;">\
                                        <div class="code_op_btn">\
                                                <span name="sql" class="code_op_span code_op_type_run"><img src="/static/images/supper_cmd/run.png">Run(F8)</span>\
                                                <span name="sql" class="code_op_span code_op_type_stop disable"><img src="/static/images/supper_cmd/stop_disable.png">Stop</span>\
                                                <span name="sql" class="code_op_span code_op_type_save disable"><img src="/static/images/supper_cmd/save_disable.png">Save</span>\
<span style="margin-left:40%"><input type="checkbox" name="switch_tab_to_spaces" checked>4个空格替代Tab</input></span>\
                                        </div>\
                                        <textarea id="'+code_id+'" name="code"></textarea>\
                                    </div>\
                                    <div region="center" class="output" split="true"  border="true" data-options="minHeight:100" style="overflow:hidden;background-color: #3a3d3f;height:30%;">\
                                        <div id="tab_output_'+data.file_id+'" class="easyui-tabs" data-options="narrow:true,closable:true" style="width:100%;height:100%;background-color:#3c3f41;">\
                                            <div title="Logs" data-options="narrow:true,closable:false" style="background-color:#3c3f41;border-radius:0;height:100%;overflow:auto;padding:0 10px;">\
                                            </div>\
                                        </div>\
                                    </div>\
                              </div>',
                    closable: true
                });
                code_mirror_format(code_id);
                if ($(".view-type-div.active").attr('action-data-type-name') == "favorite") {
                    var t = $('#favorite_tree');

                    var node = t.tree('find', data.parent_id);
                    t.tree('append', {
                        parent: (node?node.target:null),
                        data: [{
                            id: data.file_id,
                            text: title
                        }]
                    });
                    t.tree('expand', node.target);
                    parent = t.tree('getParent', node.target);
                    var parent_arr = new Array();
                    while (parent) {
                        parent_arr.push(parent)
                        //t.tree('expand', parent.target);
                        parent = t.tree('getParent', parent.target);
                    }

                    parent = parent_arr.pop()
                    while (parent) {
                        t.tree('expand', parent.target);
                        parent = parent_arr.pop()
                    }
                    var new_node = t.tree('find', data.file_id);
                    t.tree('select', new_node.target);
                }
                $('#dialog_new_panel').dialog('close');
                $('#form_new_file').form('clear');
            }
            else
            {
                ark_notify(data);
            }
        }
    });
    // submit the form
    $('#form_new_file').submit();
    return;
}

function code_mirror_format(code_id)
{
    var editor = CodeMirror.fromTextArea(document.getElementById(code_id), {
        lineNumbers: true,
        styleActiveLine: true,
        matchBrackets: true,
        indentWithTabs: true,
        smartIndent: true,
        tabToSpaces: true,
        indentUnit: 4,
        mode: 'text/x-hive', 
        background:'#3a3d3f',
        extraKeys: {"F8":'runcode', 'Ctrl-S':'savefile', 
                    'Tab': SuperCmdCodeMirror.new_tab},
            theme: 'blackboard' 
    });
    editor.setSize('100%','100%');
    editor.on('change', function(e) {  
        var cur_tab = $("#tab_title").tabs('getSelected');
        var code_id = cur_tab.children().find("textarea").attr('id');
        var orig_titile = cur_tab.panel('options').title;
        orig_titile = orig_titile.replace(/\*/g, '');
        var new_title = orig_titile;
        var id_split = code_id.split('_');
        var file_id = id_split[1];
        if(window.editor[code_id].isClean() == false)
        {
            new_title = orig_titile+'*';
            $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save").removeClass("disable");
            $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save img").attr('src','/static/images/supper_cmd/save.png');
        }
        else
        {
            $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save").addClass("disable");
            $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save img").attr('src','/static/images/supper_cmd/save_disable.png');
        }
        $("#tab_title").tabs('setTabTitle', {tab:cur_tab,title:new_title});
    });
    editor.on('keydown', function() {  
        if(event.keyCode > 64 && event.keyCode < 91 && !event.ctrlKey)
        {
            editor.showHint({hint: CodeMirror.hint.deluge, completeSingle: false, closeOnUnfocus: true});
        }
    });
    window.editor[code_id] = editor;
}
function show_odps_tables(force_refresh)
{
    $(".div_table_list").html('');
    show_div_loading($(".div_table_list"), '数据加载中...');
    $("#table_info_op .table_info_name").html('');
    $("#table_region .panel").hide();
    $("#partion_detail").hide();
    $("#table_info_detail").hide();
    if(!$("#table_info_op .table_info_columns").hasClass("active"))
    {
        $("#table_info_op .table_info_columns").addClass("active");
        $("#table_info_op .table_info_partition").removeClass("active");
        $("#table_info_op .table_info_detail").removeClass("active");
    }
    var url = '/supper_cmd/show_odps_tables/';
    var post_data = {'match_str':$(".input_tables_search").val().trim(), 'force_refresh':force_refresh};
    var callback = callback_show_odps_tables;
    var args = {'force_refresh':force_refresh};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_odps_tables(result, args)
{
    var html = '';
    for(i in result.table_list)
    {
        html +="<p action-data="+result.table_list[i]+">"+result.table_list[i]+"</p>"
    }
    if(html == '')
    {
        html = "&nbsp;&nbsp;&nbsp;&nbsp;暂无结果";
    }
    $(".div_table_list").html(html);
}
function show_odps_table_schema(table_name, force_refresh)
{
    var url = '/supper_cmd/show_odps_table_schema/';
    var post_data = {'table_name':table_name, force_refresh:force_refresh};
    var callback = callback_show_odps_table_schema;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_odps_table_schema(result, args)
{   
    var html = '';
    for(i in result.field_list)
    {
        html +="<tr><td>"+result.field_list[i]['field_name']+"</td><td>"+result.field_list[i]['type']+"</td><td>"+result.field_list[i]['desc']+"</td></tr>"
    }
    $("#table_info tbody").html(html);
    init_table_info();
}
function show_table_partitions(table_name, force_refresh)
{
    if($("#partion_detail").html().trim() != '' && force_refresh == 0)
    {
        $("#partion_detail").show();
        return;
    }
    var url = '/supper_cmd/show_table_partitions/';
    var post_data = {'table_name':table_name, force_refresh:force_refresh};
    var callback = callback_show_table_partitions;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_table_partitions(result, args)
{
    var html = result.status == 1 ? result.msg : '';
    for(i in result.part_list)
    {
        html += '<p>'+result.part_list[i]+'</p>';
    }
    $("#partion_detail").html(html);
    if($("#table_info_op .table_info_partition").hasClass("active"))
    {
        $("#partion_detail").show();
        hide_div_loading($("body>.layout-panel-west"));
    }
}
function show_odps_table_detail(table_name, force_refresh)
{
    if($("#table_info_detail").html().trim() != '' && force_refresh == 0)
    {
        $("#table_info_detail").show();
        return;
    }
    var url = '/supper_cmd/show_odps_table_detail/';
    var post_data = {'table_name':table_name, force_refresh:force_refresh};
    var callback = callback_show_table_detail;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_table_detail(result, args)
{
    var html = '';
    for(i in result.detail_list) {
        for(key in result.detail_list[i]) {
            if(key == 'user_info') {
                continue
            }
            var value = result.detail_list[i][key];
            if(key == "创建人" && result.detail_list[i]['user_info']) {
                value = result.detail_list[i]['user_info']['username_dsp'];
            }
            html += '<p><span class="table_info_detail_key">'+key+':</span><span class="table_info_detail_val">'+value+'</span></p>';
        }
    }
    $("#table_info_detail").html(html);
    if($("#table_info_op .table_info_detail").hasClass("active"))
    {
        $("#table_info_detail").show();
        hide_div_loading($("body>.layout-panel-west"));
    }
}
function show_odps_table_datas(tab_title, table_name)
{
    var part = '';
    var limit = 50;
    var url = '/supper_cmd/show_odps_table_datas/';
    var post_data = {'table_name':table_name, 'part':part, 'limit':limit};
    var callback = callback_show_odps_table_datas;
    var args = {'tab_title':tab_title};
    makeAPost(url, post_data, true, callback, args);
    
}
function callback_show_odps_table_datas(result, args)
{
    var tab = $('#tab_title').tabs('getTab', args.tab_title);
    width = 200 * result.header.length + "px;";
    var  content = '<div class="preview_header preview_header_'+args.tab_title+'">\
                        <span class="preview_search_span_val">Partitions:</span><input class="preview_search_input_val" type="text">\
                        <span class="preview_search_span_lines">Lines:</span><input class="preview_search_input_lines easyui-numberbox" min="1" max="1000" type="text" value="50" data-options="required:true" style="width:50px;">\
                        <span class="preview_search_span_btn"><img src="/static/images/supper_cmd/search.png"></img>Search</span>\
                        <span class="preview_search_span_import"><img src="/static/images/supper_cmd/import.png"></img>数据导入</span>\
                        <span class="preview_search_span_export" onclick="download_odps_table_data(this)"><img src="/static/images/supper_cmd/export.png"></img>导出结果</span>\
                   </div>';
    content += '<table class="table_preview table_preview_'+args.tab_title+'" style="background:#3a3d3e;width:' + width + '"\
                           border="false" rownumbers="true"\
                           fit="true" fitColumns="false" singleSelect="true">\
                       <thead>\
                           <tr>';
    for(i in result.header)
    {
        content += '<th width="200px;" field="'+result.header[i]+'">'+result.header[i]+'</th>';
    }
    content += '</tr></thead><tbody>';
    for(i in result.item_list)
    {
        content += '<tr>';
        for(j in result.item_list[i])
        {
            content += '<td>'+result.item_list[i][j]+'</td>';
        }
        content += '</tr>';
    }
    content += '</tbody></table>';
    $('#tab_title').tabs('update',{
        'tab':tab,
        'options':{
            'content':content
        }
    });

    $('.table_preview_'+args.tab_title).datagrid({
        nowrap: true,
        onSelect: function(index,row){
        },
        onLoadSuccess:function(){
        },
        onDblClickRow:function(index,row){
            var data_table = [];
            for(key in row)
            {
                data_table.push({f1:key, f2:row[key]});
            }
            $("#dialog_row_detail_table").datagrid({
                data: data_table,
                columns:[[
                    {field:'f1',title:'column', width:40},
                    {field:'f2',title:'value', width:120}
                ]],
                fit:true,
                fitColumns:true,
                singleSelect:true,
                nowrap:false,
                rownumbers:true,
                    rowStyler: function(index,row){
                        return 'background-color:#3c3f41;'; // return inline style
                    }
            });
            $('#dialog_row_detail').dialog({
                title: 'Row Detail',
                width: 600,
                height: 400,
                closed: false,
                cache: false,
                modal: true,
                resizable:true,
                buttons:[{
                    text:'关闭',
                    handler:function(){
                        $('#dialog_row_detail').dialog('close');
                    }
                }]
            });
            },
        rowStyler: function(index,row){
            return 'background-color:#3c3f41;'; // return inline style
        }
    });

}
function get_favorite_tree()
{
    var url = '/supper_cmd/show_file_tree_ex/';
    $('#favorite_tree').tree({
        url:url,
        animate:true,
        dnd:true,
        onContextMenu:function(e, node){
            var root_id = $('#favorite_tree').tree('getRoot').id;
            var menu_id = 'file_tree_menu_';
            if(node.id == root_id)
            {
                menu_id += 'root';
            }
            else if($('#favorite_tree').tree('isLeaf', node.target))
            {
                menu_id += 'leaf';
            }
            else
            {
                menu_id += 'folder';
            }
            e.preventDefault();
            // select the node
            $('#favorite_tree').tree('select', node.target);
            // display context menu
            $('#'+menu_id).menu('show', {
                left: e.pageX,
                top: e.pageY
            });
        },
        onDragOver: function (target, source) {
            if($('#favorite_tree').tree('isLeaf', target)) {
                return false;
            }
        },
        onBeforeDrop: function(target, source, append){
            if (append != 'append') {
                target = $('#favorite_tree').tree('getParent', target);
                if (!target) {
                    return false;
                }
            } else {
                target = $('#favorite_tree').tree('getNode',target)
            }
            var url = '/supper_cmd/move_obj_from_one_folder_to_another/';
            var post_data = {'obj_id':source.id, 'des_folder_id':target.id};
            result = makeAPost(url, post_data, false);
            if (result.status != 0) {
                ark_notify(result);
                return false;
            }
        },
        onDrop: function(target, source, append){
            if ($(".view-type-div.active").attr('action-data-type-name') == "favorite") {
                var new_node = $('#favorite_tree').tree('find', source.id);
                $('#favorite_tree').tree('select', new_node.target);
            }
        },
        onDblClick:function(node){
            if($('#favorite_tree').tree('isLeaf', node.target))
            {
                open_favorite_file(node.id,node.text);  
            }
            else
            {
                $('#favorite_tree').tree('toggle', node.target);
            }
        },
    });
}
function init_table_info()
{
    $('#table_info').datagrid({
        onSelect: function(index,row){
            $('#cc').attr('src', row.link);
        },
        onLoadSuccess:function(){
            var rows = $(this).datagrid('getRows');
            if (rows.length){
                $(this).datagrid('selectRow',0); }
            $("#table_region .panel .datagrid-wrap").height($("#table_region .panel .datagrid-wrap").height()-30);
            $("#table_region .panel .datagrid-wrap .datagrid-view").height($("#table_region .panel .datagrid-wrap .datagrid-view").height()-30);
            $("#table_region .panel .datagrid-wrap .datagrid-view .datagrid-view1 .datagrid-body").height($("#table_region .panel .datagrid-wrap .datagrid-view .datagrid-view1 .datagrid-body").height()-30);
            $("#table_region .panel .datagrid-wrap .datagrid-view .datagrid-view2 .datagrid-body").height($("#table_region .panel .datagrid-wrap .datagrid-view .datagrid-view2 .datagrid-body").height()-30);
            if(!$("#table_info_op .table_info_columns").hasClass("active"))
            {
                $("#table_region .panel").hide();
            }
            else
            {
                hide_div_loading($("body>.layout-panel-west"));
            }
        },
        rowStyler: function(index,row){
            return 'background-color:#3c3f41;'; // return inline style
        }
    });

}
function open_favorite_file(file_id,file_title)
{
    if($('#tab_title').tabs('exists', file_title))
    {
        $('#tab_title').tabs('select',file_title);
    }
    else
    {
        window.sql_run_status['status_'+file_id] = {'file_id':file_id, 'run_status':RUN_STATUS_STOPED};
        var code_id = "code_"+file_id;
        var url = '/supper_cmd/get_file_detail/';
        var post_data = {'file_id':file_id};
        result = makeAPost(url, post_data);
        if(result.status !=0)
        {
            ark_notify(result);
            return;
        }
        $('#tab_title').tabs('add',{
            title:file_title,
            content:'<div class="easyui-layout" fit="true">\
                         <div class="code_northregion" action-data-file_id="'+file_id+'" region="north" split="true" border="true" style="min-height:85px;width:100%;height:70%;background-color: #3a3d3f;overflow:hidden;">\
                             <div class="code_op_btn">\
                                     <span name="sql" class="code_op_span code_op_type_run"><img src="/static/images/supper_cmd/run.png">Run(F8)</span>\
                                     <span name="sql" class="code_op_span code_op_type_stop disable"><img src="/static/images/supper_cmd/stop_disable.png">Stop</span>\
                                     <span name="sql" class="code_op_span code_op_type_save disable"><img src="/static/images/supper_cmd/save_disable.png">Save</span>\
<span style="margin-left:40%"><input type="checkbox" name="switch_tab_to_spaces" checked>4个空格替代Tab</input></span>\
                              </div>\
                              <textarea id="'+code_id+'" name="code">'+result.content+'</textarea>\
                         </div>\
                         <div region="center" class="output" split="true"  border="true" data-options="minHeight:100" style="overflow:hidden;background-color: #3a3d3f;height:30%;">\
                             <div id="tab_output_'+file_id+'" class="easyui-tabs" data-options="narrow:true,closable:true" style="width:100%;height:100%;background-color:#3c3f41;">\
                                 <div title="Logs" data-options="narrow:true,closable:false" style="background-color:#3c3f41;border-radius:0;height:100%;overflow:auto;padding:0 10px;word-wrap:break-word;">\
                                 </div>\
                             </div>\
                         </div>\
                     </div>',
            closable:true
        });
        code_mirror_format(code_id);
    }
}
function save_file(file_id, content)
{
    var url = '/supper_cmd/update_file/';
    var post_data = {'file_id':file_id, 'file_content':content};
    var result = makeAPost(url, post_data, false);
    if(result.status == 0)
    {
        $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save").addClass("disable");
        $(".code_northregion[action-data-file_id="+file_id+"] .code_op_type_save img").attr('src','/static/images/supper_cmd/save_disable.png');
        window.editor['code_'+file_id].markClean();
        CodeMirror.signal(window.editor['code_'+file_id], 'change');
    } else {
        ark_notify(result);
    }
}
function rename_file()
{
    var cur_node = $('#favorite_tree').tree('getSelected');
    $.messager.prompt('文件重命名', '请输入新的文件名:', function(r){
        if (r){
            do_rename_file(r);
        }
    });
}
function do_rename_file(r)
{
    var cur_node = $('#favorite_tree').tree('getSelected');
    var old_name = cur_node.text;
    var file_id = cur_node.id;
    var code_id = "code_"+file_id;
    var url = '/supper_cmd/update_file/';
    var post_data = {'file_id':cur_node.id, 'file_name':r};
    var result = makeAPost(url, post_data, false);
    if(result.status == 0)
    {
        if($('#tab_title').tabs('exists', old_name)) {
            var tmp_tab = $('#tab_title').tabs('getTab', old_name);
            $('#tab_title').tabs('update', {
                tab: tmp_tab, 
                options: {
		            title: r,
	            }
            });
            var content = window.editor[code_id].getValue();
            code_mirror_format(code_id);
            window.editor[code_id].setValue(content)
        }

        old_name = old_name + '*';
        if($('#tab_title').tabs('exists', old_name)) {
            var tmp_tab = $('#tab_title').tabs('getTab', old_name);
            $('#tab_title').tabs('update', {
                tab: tmp_tab, 
                options: {
		            title: r + '*',
	            }
            });
            var content = window.editor[code_id].getValue();
            code_mirror_format(code_id);
            window.editor[code_id].setValue(content)
        }

        if($(".view-type-div.active").attr('action-data-type-name') == "favorite")
        {
            $('#favorite_tree').tree('update', {target: cur_node.target, text: r});
        }
    } else {
        ark_notify(result);
    }
}
function rename_folder()
{
    var cur_node = $('#favorite_tree').tree('getSelected');
    $.messager.prompt('文件重命名', '请输入新的文件名:', function(r){
        if (r){
            do_rename_folder(r);
        }
    });
}

function do_rename_folder(r)
{
    var cur_node = $('#favorite_tree').tree('getSelected');
    var url = '/supper_cmd/rename_folder/';
    var post_data = {'file_id':cur_node.id, 'file_name':r, 'type': 0};
    var result = makeAPost(url, post_data, false);
    if(result.status == 0)
    {
        if($(".view-type-div.active").attr('action-data-type-name') == "favorite")
        {
            $('#favorite_tree').tree('update', {target: cur_node.target, text: r});
        }
    }else {
        ark_notify(result);
    }
}

function sure_remove_folder() {    
    $('#sure_dialog').dialog('close');

    var cur_node = $('#favorite_tree').tree('getSelected');
    var url = '/supper_cmd/delete_folder/';
    var post_data = {'file_id':cur_node.id, 'type': 0};

    var result = makeAPost(url, post_data, false);
    if(result.status == 0)
    {
        $('#favorite_tree').tree('remove', cur_node.target);
    } else {
        ark_notify(result);
    }
}
function remove_folder() {
    $('#sure_dialog').dialog('open');
}

function sure_remove_file() {
    $('#remove_file').dialog('close');
    var cur_node = $('#favorite_tree').tree('getSelected');
    var old_name = cur_node.text;
    var url = '/supper_cmd/delete_file/';
    var post_data = {'file_id':cur_node.id};
    var result = makeAPost(url, post_data, false);
    if(result.status == 0)
    {
        if($('#tab_title').tabs('exists', old_name)) {
            $('#tab_title').tabs('close', old_name);
        }

        $('#favorite_tree').tree('remove', cur_node.target);
    } else {
        ark_notify(result);
    }
}
function remove_file()
{
    $('#remove_file').dialog('open');
   
}
function new_folder(){
    $('#dialog_new_folder').dialog({
        title: '新建文件夹',
        width: 600,
        height: 160,
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_new_folder();
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_new_folder').dialog('close');
                $('#form_new_folder').form('clear');
            }
        }]
    });
}
function do_new_folder()
{
    var cur_node = $('#favorite_tree').tree('getSelected');
    var url = '/supper_cmd/create_folder/';
    folder_name = $("#dialog_new_folder input[name='folder_name']").val().trim();
//    var post_data = {'type':0,'parent_id':cur_node.id, 'folder_name':$("#dialog_new_folder input[name='folder_name']").val().trim()};
//    var result = makeAPost(url, post_data, false);
    $('#form_new_folder').form({
        url:url,
        queryParams:{'type':0,'parent_id':cur_node.id},
        onSubmit: function(){
            return $(this).form('enableValidation').form('validate');
        }, 
        success:function(data){
            data = $.parseJSON(data);
            if(data.status ==0)
            {
                $('#dialog_new_folder').dialog('close');
                $('#form_new_folder').form('clear');
                if($(".view-type-div.active").attr('action-data-type-name') == "favorite")
                {
                    var t = $('#favorite_tree');
                    var node = t.tree('getSelected');
                    children = t.tree('getChildren', node.target);
                    if (children.length > 0) {
                        t.tree('insert', {
                            before: children[0].target,
                            data: [{
                                id: data.file_id,
                                text: folder_name,
                                state: 'closed'
                            }]
                        });
                    } else {
                        t.tree('append', {
                            parent: (node?node.target:null),
                            data: [{
                                id: data.file_id,
                                text: folder_name,
                                state: 'closed'
                            }]
                        });
                    }
                   
                    t.tree('expand', node.target);
                    var new_node = t.tree('find', data.file_id);
                    t.tree('select', new_node.target);
                }
            }
            else
            {
                ark_notify(data);
            }
        }
    });
    $('#form_new_folder').submit();
    return;
}
function daemon_run_status()
{
    for(index in window.sql_run_status)
    {
        if(window.sql_run_status[index].run_status == RUN_STATUS_RUNNING && typeof(window.daemon_log[window.sql_run_status[index].file_id]) == 'undefined')
        {
            window.daemon_log[window.sql_run_status[index].file_id] = setInterval('get_run_log_and_result('+window.sql_run_status[index].file_id+')', 3000);
            console.log(window.daemon_log[window.sql_run_status[index].file_id]);
        }
    }
}
function get_run_log_and_result(file_id)
{
    var index = 'status_'+file_id;
    var pos = window.sql_run_status['status_'+file_id].cur_pos;
    var step = 1024*1024;
    var url = '/supper_cmd/check_status_and_get_progress_log/';
    var post_data = {'file_id':file_id,'start':pos,'count':step};
    var callback = callback_get_run_log_and_result;
    var args = {'file_id':file_id};
    makeAPost(url, post_data, true, callback, args);
}
function callback_get_run_log_and_result(result, args)
{
    if(result.status == 0)
    {
        window.sql_run_status['status_'+args.file_id].cur_pos = result.stderr_pos;
        //输出日志
        stderr = result.stderr.replace(new RegExp(" ", "gm"), '&nbsp;');
        stderr = stderr.replace(new RegExp("\t", "gm"), '&nbsp;&nbsp;&nbsp;&nbsp;');
        tmp_stderr = '';
        if (stderr.indexOf("http://webconsole.odps.aliyun-inc.com") >= 0) {
            stderr_list = stderr.split("\n");
            for (var idx = 0; idx < stderr_list.length; ++idx) {
                if (stderr_list[idx].indexOf("http://webconsole.odps.aliyun-inc.com") == 0) {
                    tmp_stderr += '<a target="_blank" href="' + stderr_list[idx] + '">' + stderr_list[idx] + '</a>' + '\n';
                } else {
                    tmp_stderr += stderr_list[idx] + '\n';
                }
            }
        } else {
            tmp_stderr = stderr;
        }

        stderr = tmp_stderr;
        tmp_stderr = '';
        if (stderr.indexOf("FAILED:") >= 0) {            
            stderr_list = stderr.split("\n");
            for (var idx = 0; idx < stderr_list.length; ++idx) {
                if (stderr_list[idx].indexOf("FAILED:") == 0) {
                    tmp_stderr += '<font style="color:#DF6A53!important">' + stderr_list[idx] + '</font>' + '\n';
                } else {
                    tmp_stderr += stderr_list[idx] + '\n';
                }
            }
        } else {
            tmp_stderr = stderr;
        }

        if(result.run_status == TASK_SUCCEED) {
            tmp_stderr += "\n<font style='color:#FFFFFF!important'>执行成功！</font>\n"
        }
       
        if(result.run_status == TASK_FAILED) {
            tmp_stderr += "\n<font style='color:#DF6A53!important'>执行失败！</font>\n"
        }
        stderr = tmp_stderr.replace(new RegExp("\n", "gm"), '<br/>');
        $("#tab_output_"+args.file_id).tabs('getTab', 0).append(stderr);
        changeHeight($("#tab_output_"+args.file_id+ " .panel-body"));
        if(result.run_status == TASK_SUCCEED || result.run_status == TASK_FAILED)
        {
            //停止轮询
            window.sql_run_status[index].run_status = RUN_STATUS_STOPED;
            clearInterval(window.daemon_log[args.file_id]);
            delete window.daemon_log[args.file_id];
            $(".code_northregion[action-data-file_id="+args.file_id+"] .code_op_type_stop").addClass("disable");
            $(".code_northregion[action-data-file_id="+args.file_id+"] .code_op_type_run").removeClass("disable");
            $(".code_northregion[action-data-file_id="+args.file_id+"] .code_op_type_run img").attr('src','/static/images/supper_cmd/run.png');
            $(".code_northregion[action-data-file_id="+args.file_id+"] .code_op_type_stop img").attr('src','/static/images/supper_cmd/stop_disable.png');
        }
        if(result.run_status == TASK_SUCCEED)
        {
            //获取结果
            display_result(args.file_id);
        }
    }
}
function display_result(file_id)
{
    var url = '/supper_cmd/get_run_result_all/';
    var post_data = {'file_id':file_id};
    var callback = callback_display_result;
    var args = {'file_id':file_id};
    makeAPost(url, post_data, true, callback, args);
}
//function callback_display_result(result, args)
//{
//    if(result.status == 0)
//    {
//        for(i in result.result_list)
//        {
//            var content = '';
//            if(result.result_list[i].header.length == 0)
//            {
//                content = result.result_list[i].stdout_pos
//            }
//            else
//            {
//                var table_id = 'result_table_'+args.file_id+'_'+(result.result_list[i].result_no+1);
//                content = '<table id="'+table_id+'" class="easyui-datagrid" style="width:100%;height:100%" url="/supper_cmd/get_more_result/"\
//                                    title="结果集" rownumbers="true" pagination="true">\
//                               <thead><tr>';
//                for(index_col in result.result_list[i].header)
//                {
//                    content += '<th field="'+result.result_list[i].header[index_col]+'" width="80">'+result.result_list[i].header[index_col]+'</th>';
//                }
//                content += '</tr></thead></table>';
//            }
//            $("#tab_output_"+args.file_id).tabs('add',{
//                    title:"Result_"+(result.result_list[i].result_no+1),
//                    content:content,
//                    selected:true
//            });
//            $("#"+table_id).datagrid({
//                queryParams: {
//                    result_no: result.result_list[i].result_no,
//                    file_id:args.file_id
//                },
//                loadFilter: function(data){
//                    return data.data;
//                }
//            });
//            //设置分页控件 
//            var p = $("#"+table_id).datagrid('getPager'); 
//            $(p).pagination({ 
//                pageSize: 10,//每页显示的记录条数，默认为10 
//                pageList: [10,20,50, 100],//可以设置每页记录条数的列表 
//                beforePageText: '第',//页数文本框前显示的汉字 
//                afterPageText: '页    共 {pages} 页', 
//                displayMsg: '当前显示 {from} - {to} 条记录   共 {total} 条记录'
//            });
//        }
//    }
//}
function callback_display_result(result, args)
{
    if(result.status == 0)
    {
        for(var i in result.result_list)
        {
            var content = '';
            var table_id = '';
            if(result.result_list[i].header.length == 0)
            {
                stdout = result.result_list[i].stdout.replace(new RegExp(" ", "gm"), '&nbsp;');
                stdout = stdout.replace(new RegExp("\t", "gm"), '&nbsp;&nbsp;&nbsp;&nbsp;');
                stdout_list = stdout.split('\n')
                var height = stdout_list.length * 16;
                stdout = stdout.replace(new RegExp("\n", "gm"), '<br/>');

                content = '<div style="background-color:#3c3f41;height:' + height + 'px;padding: 10px 10px;font-family:	Courier New;">'+stdout+'</div>';
            }
            else
            {
                table_id = 'result_table_'+args.file_id+'_'+(result.result_list[i].result_no+1);
                content = '<table id="'+table_id+'" data-options="multiSort:false"></table>';
                content += '<div id="toolbar_'+table_id+'"><a href="#" class="easyui-linkbutton" iconCls="icon-export" plain="true" onclick="big_file_download('+args.file_id+','+result.result_list[i].result_no+')">导出结果(共'+result.result_list[i].all_num+'条)</a></div>';
            }
            $("#tab_output_"+args.file_id).tabs('add',{
                    title:"Result_"+(result.result_list[i].result_no+1),
                    content:content,
                    closable:true,
                    selected:false
            });
            $("#tab_output_"+args.file_id).tabs('select',1);
            if(result.result_list[i].header.length > 0)
            {
                var columns = [];
                for(index_col in result.result_list[i].header)
                {
                    columns.push({'field':result.result_list[i].header[index_col], 'title':result.result_list[i].header[index_col], 'width':80, 'sortable':true});
                }
                $("#"+table_id).datagrid({
                    url:"/supper_cmd/get_more_result/",
                    rownumbers:true,
                    singleSelect:true,
                    pagination:true,
                    columns:[columns],
                    onDblClickRow:function(index,row){
                        var data_table = [];
                        var result_index = parseInt($(this).attr('id').substr(-1,1))-1;
                        for(idx in result.result_list[result_index].header)
                        {
                            key = result.result_list[result_index].header[idx]
                            data_table.push({f1:key, f2:row[key]});
                        }
                        $("#dialog_row_detail_table").datagrid({
                            data: data_table,
                            columns:[[
                                {field:'f1',title:'column', width:40},
                                {field:'f2',title:'value', width:120}
                            ]],
                            fit:true,
                            fitColumns:true,
                            singleSelect:true,
                            nowrap:false,
                            rownumbers:true,
                                rowStyler: function(index,row){
                                    return 'background-color:#3c3f41;'; // return inline style
                                }
                        });
                        $('#dialog_row_detail').dialog({
                            title: 'Row Detail',
                            width: 600,
                            height: 400,
                            closed: false,
                            cache: false,
                            modal: true,
                            resizable:true,
                            buttons:[{
                                text:'关闭',
                                handler:function(){
                                    $('#dialog_row_detail').dialog('close');
                                }
                            }]
                        });
                    },
                    queryParams: {
                        result_no: result.result_list[i].result_no,
                        file_id:args.file_id
                    },
                    toolbar:"#toolbar_"+table_id,
                    loadFilter: function(data){
                        return data.data;
                    }
                });
                //设置分页控件 
                var p = $("#"+table_id).datagrid('getPager'); 
                $(p).pagination({ 
                    pageSize: 10,//每页显示的记录条数，默认为10 
                    pageList: [10,20,50, 100],//可以设置每页记录条数的列表 
                    beforePageText: '第',//页数文本框前显示的汉字 
                    afterPageText: '页    共 {pages} 页', 
                    showRefresh:false,
                    displayMsg: '当前显示 {from} - {to} 条记录   共 {total} 条记录'
                });
            }
        }
    }
}
function changeHeight(obj)
{
    var beforeHeight = obj.scrollTop();
    obj.scrollTop(obj.scrollTop()+100);
    var afterHeight = obj.scrollTop();
    if(beforeHeight == afterHeight)
    {
        return;
    }
    else
    {
        setTimeout(function(){changeHeight(obj)},5);
    }
}
function download_odps_table_data(obj)
{
    var params = {
            'table_name':$(obj).parent().attr('action-data-table_name'),
            'part':$(obj).parent().find(".preview_search_input_val").val().trim(),
            'limit':$(obj).parent().find(".preview_search_input_lines").val().trim()
        };
    var url = '/supper_cmd/download_odps_table_data/?'+$.param(params);
    download_flag = true;
    location.href = url;
    //window.open(url);
}
function big_file_download(file_id, result_no)
{
    var params = {
            'file_id':file_id,
            'result_no':result_no
        };
    var url = '/supper_cmd/download_result/?'+$.param(params);
    download_flag = true;
    location.href = url;
    //window.open(url);
}
function init_table_preview(table_name, part, limit)
{
    var url = '/supper_cmd/show_odps_table_datas/';
    var post_data = {'table_name':table_name, 'part':part, 'limit':limit};
    var args = {'table_name':table_name,'part':part,'limit':limit};
    makeAPost(url, post_data, true, callback_init_table_preview, args);
}
function callback_init_table_preview(result, args)
{
    var table_name = args['table_name'];
    var title = args['table_name']+'_preview';
    var table_id = 'table_preview_'+title;
    if(result.status == 0)
    {
        if(result.run_status == TASK_FAILED)
        {
            if(result.stderr.indexOf('Authorization Failed') >= 0)
            {
                var tip = '<div style="width: 100%;height: 100%;background-color: #3c3f41;text-align: center;padding-top: 50px;;"><font style="font-size:15px">您无此数据权限，点击 <a href="http://ark.sm.cn/dms/inner_market_index/?key_word='+$("#cur_project").text().trim()+'.'+table_name+'" target="_blank">这里</a> 去申请吧~</font></div>';
                $("#tab_title").tabs('getTab', title).html(tip);
                return;
            }
            else
            {
                ark_notify({status:1,msg:result.stderr});
            }
            $('#tab_title').tabs('loaded');
            $('#tab_title').tabs('close', title);
            return;
        }
        var content = '<table class="table_preview" id="'+table_id+'"></table>';
        content += '<div class="preview_header preview_header_'+title+'" action-data-table_name="'+table_name+'">\
                            <span class="preview_search_span_val">Partitions:</span><input class="preview_search_input_val" type="text" value="'+args['part']+'">\
                            <span class="preview_search_span_lines">Lines:</span><input class="preview_search_input_lines easyui-numberbox" min="1" max="1000" type="text" data-options="required:true" style="width:60px;" value="'+args['limit']+'">\
                            <span class="preview_search_span_btn"><img src="/static/images/supper_cmd/search.png"></img>Search</span>\
                            <span class="preview_search_span_import"><img src="/static/images/supper_cmd/import.png"></img>导入数据</span>\
                            <span class="preview_search_span_export" onclick="download_odps_table_data(this)"><img src="/static/images/supper_cmd/export.png"></img>导出结果</span>\
                       </div>';
 
        $("#tab_title").tabs('getTab', title).html(content);
        $.parser.parse($(".preview_header_"+title+""));
        if(result.header.length > 0)
        {
            var columns = [];
            for(index_col in result.header)
            {
                columns.push({'field':result.header[index_col], 'title':result.header[index_col], 'width':180});
            }
            $("#"+table_id).datagrid({
                url:"/supper_cmd/get_more_result/",
                toolbar:'.preview_header_'+title,
                rownumbers:true,
                singleSelect:true,
                loadMsg:'加载中...',
                fit:true,
                pagination:true,
                pageSize:50,
                columns:[columns],
                queryParams: {
                    result_no: result.result_no,
                    file_id:result.file_id
                },
                onDblClickRow:function(index,row){
                    var data_table = [];
                    for(index_col in result.header)
                    {
                        key = result.header[index_col]
                        data_table.push({f1:key, f2:row[key]});
                    }
                    $("#dialog_row_detail_table").datagrid({
                        data: data_table,
                        columns:[[
                            {field:'f1',title:'column', width:40},
                            {field:'f2',title:'value', width:120}
                        ]],
                        fit:true,
                        fitColumns:true,
                        singleSelect:true,
                        nowrap:false,
                        rownumbers:true,
                            rowStyler: function(index,row){
                                return 'background-color:#3c3f41;'; // return inline style
                            }
                    });
                    $('#dialog_row_detail').dialog({
                        title: 'Row Detail',
                        width: 600,
                        height: 400,
                        closed: false,
                        cache: false,
                        modal: true,
                        resizable:true,
                        buttons:[{
                            text:'关闭',
                            handler:function(){
                                $('#dialog_row_detail').dialog('close');
                            }
                        }]
                    });
                    },
                    loadFilter: function(data){
                        return data.data;
                    }
                });
                //设置分页控件 
                var p = $("#"+table_id).datagrid('getPager'); 
                $(p).pagination({ 
                    pageSize: 50,//每页显示的记录条数，默认为10 
                    pageList: [50, 100, 200],//可以设置每页记录条数的列表 
                    beforePageText: '第',//页数文本框前显示的汉字 
                    afterPageText: '页    共 {pages} 页', 
                    showRefresh:false,
                    displayMsg: '当前显示 {from} - {to} 条记录   共 {total} 条记录'
                });
            }
        }
        else
        {
            $('#tab_title').tabs('loaded');
            if(!args.part)
            {
                $('#tab_title').tabs('close', title);
            }
            else
            {
                $("#"+table_id).datagrid('loadData', {status:0,data:{total:0, rows:[]}});
            }
            ark_notify(result);
        }
}
function open_last_files()
{
    var url = '/supper_cmd/open_the_last_files/';
    var post_data = {};
    var callback = callback_open_last_files;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_open_last_files(result, args)
{
    if(result.status == 0)
    {
        for(var i in result.last_files)
        {
            open_favorite_file(result.last_files[i].file_id, result.last_files[i].file_name);
        }
    }
}
function open_tab(table_name)
{
    var title = table_name+'_preview';
    var part = '';
    var limit = 50;
    if($('#tab_title').tabs('exists', title))
    {
        $('#tab_title').tabs('select',title);
        var dest_tab = $('#tab_title').tabs('getTab', title);
        part = dest_tab.find('.preview_search_input_val').val().trim();
        limit = dest_tab.find('.preview_search_input_lines').val().trim();
        //$('#tab_title').tabs('update', {
        //    tab:dest_tab,
        //    options:{
        //        content:'加载中...'
        //    }
        //});
    }
    else
    {
        var content = ''; 
        $('#tab_title').tabs('add',{
            title:title,
            content:content,
            closable:true
        });
    }
    $('#tab_title').tabs('loading', '正在加载中...');
    init_table_preview(table_name, part, limit);
}
function show_div_loading(obj, msg)
{
//   obj.html('');
   if (msg == undefined) {  
       msg = "正在加载数据，请稍候...";  
   }  
   $("<div class=\"datagrid-mask\"></div>").css({ display: "block", width: obj.width(), height: obj.height() }).appendTo(obj);  
   $("<div class=\"datagrid-mask-msg\"></div>").html(msg).appendTo(obj).css({ display: "block", left: (obj.width() - $("div.datagrid-mask-msg", obj).outerWidth()) / 2, top: (obj.height() - $("div.datagrid-mask-msg", obj).outerHeight()) / 2 });  
}
function hide_div_loading(obj)
{
    obj.find("div.datagrid-mask-msg").remove();  
    obj.find("div.datagrid-mask").remove();  
}
function change_project()
{
    //if($("#select_project").children().length < 1)
    //{
        var url = '/supper_cmd/get_project_list/';
        var post_data = {};
        var callback = callback_get_project_list;
        var args = {};
        makeAPost(url, post_data, true, callback, args);
    //}
    $('#dialog_project').dialog({
        title: '修改project',
        width: 600,
        height: 140,
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_change_project();
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_project').dialog('close');
            }
        }]
    });
}
function callback_get_project_list(result, args)
{
    if(result.status == 0)
    {
        $("#select_project").html('');
        for(var i in result.projects)
        {
            $("#select_project").append('<option value="'+result.projects[i]+'">'+result.projects[i]+'</option>');
        }
    }
    $("#select_project").combobox({
        filter:function(q,row){ 
            var opts=$(this).combobox("options"); 
            return row[opts.textField].indexOf(q)>-1;//将从头位置匹配改为任意匹配 
            },
        onHidePanel: function() {
            var valueField = $(this).combobox("options").valueField;
            var val = $(this).combobox("getValue");  //当前combobox的值
            var allData = $(this).combobox("getData");   //获取combobox所有数据
            var result = true;      //为true说明输入的值在下拉框数据中不存在
            for (var i = 0; i < allData.length; i++) {
                if (val == allData[i][valueField]) {
                    result = false;
                }
            }
            if (result) {
                $(this).combobox("clear");
            }
        },
        width:400,
        editable:true,
        required:true
    });
    $("#select_project").combobox('setValue', $("#cur_project").text().trim());
}
function do_change_project()
{
    var new_project = $("#select_project").combobox('getValue');
    if(new_project == '')
    {
        ark_notify({status:1, msg:'项目不能为空'});
        return;
    }
    var url = '/supper_cmd/update_user_odps_project/';
    var post_data = {project:new_project};
    var result = makeAPost(url, post_data, false);
    if(result.status == 0)
    {
        $('#dialog_project').dialog('close');
        $("#cur_project").text(new_project);
        if($(".div_table_list").length > 0)
        {
            show_odps_tables(0);
        } else if($(".input_resource_search").length > 0) {
            $(".input_resource_search").trigger("change");
        } else if($(".input_function_search").length > 0) {
            $(".input_function_search").trigger("change");
        } 
    }
    else
    {
        ark_notify(result);
    }
}
