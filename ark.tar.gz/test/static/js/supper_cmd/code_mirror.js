$(function() {
    window.SuperCmdCodeMirror = {
        new_tab: function(cm) {  
            if (cm.somethingSelected()) {
                cm.indentSelection('add');
            } else if(cm.getOption('tabToSpaces')) {
                var spaces = Array(cm.getOption("indentUnit") + 1).join(" ");
                cm.replaceSelection(spaces);
            } else {
                cm.execCommand('insertTab');
            }
        },
        format: function(code_id, read_only, save_func, div) {
            read_only = (read_only == undefined || !read_only) ? false : 'nocursor';
            if(div == undefined) {
                var div = document.getElementById(code_id);
            }
            var editor = CodeMirror.fromTextArea(div, {
                lineNumbers: true,
                readOnly : read_only,
                styleActiveLine: true,
                matchBrackets: true,
                indentWithTabs: true,
                smartIndent: true,
                tabToSpaces: true,
                indentUnit: 4,
                mode: 'text/x-hive', 
                background:'#3a3d3f',
                extraKeys: {"F8":'runcode', 'Ctrl-S':save_func,
                            "Tab": SuperCmdCodeMirror.new_tab},
                theme: 'blackboard',
            });
            editor.setSize('100%','100%');
            editor.on('change', function(e) {  
                var cur_tab = $("#tab_title").tabs('getSelected');
                if(window.editor[code_id].isClean() == false) {
                    cur_tab.children().find(".local_obj_save").removeClass("disable");
                    cur_tab.children().find(".local_obj_save").prop('disabled',false);
                    cur_tab.children().find(".local_obj_save img").attr('src','/static/images/supper_cmd/save.png');
                } else {
                    cur_tab.children().find(".local_obj_save").addClass("disable");
                    cur_tab.children().find(".local_obj_save").prop('disabled',true);
                    cur_tab.children().find(".local_obj_save img").attr('src','/static/images/supper_cmd/save_disable.png');
                }
            });
            window.editor[code_id] = editor;
        }    
    }
});

