var unnamed_title_no = 0;
var select_resource_list_inited = false;

function switch_function_tree() {
    if($(".switch_btn").hasClass('active'))
    {
        $(".switch_btn").removeClass('active');
    }
    else
    {
        $(".switch_btn").addClass('active');
    }
    refresh_function_tree()
}

function refresh_function_tree() {
    $(".input_function_search").trigger('change');
}
function get_function_tree()
{
    var url = '/supper_cmd/odps_function/list/';
    show_div_loading($("#function_tree"), '列表加载中...');
    $('#function_tree').tree({
        url:url,
        animate:true,
        queryParams:{
            project:$("#cur_project").text().trim(), 
            key_word:$(".input_function_search").val(),
        },
        dnd:false,
        loadFilter: function(result){
            var nodes = [];
            var switch_auth = false;
            if($(".switch_btn").hasClass('active')) {
                switch_auth = true;
            } 

            if(result.status == 0) {
                for(var category in result.data) {
                    var children = []
                    for(var i in result.data[category]) {
                        var t = result.data[category][i];
                        if(!switch_auth || (t.perms.read || t.perms.write || t.perms.delete || t.perms.all)) {

                            children.push({id:t.id, name:t.name, text:t.name, dxp_account:t.dxp_account, user_info:t.user_info, project:t.project, perms:t.perms, comment:t.detail.comment, resources:t.detail.resources, class_type:t.detail.class_type});
                        }
                    }
                    nodes.push({id: 0, text: category, state: 'close', children: children});
                }
            } else {
                ark_notify(result);
            }
            hide_div_loading($("#function_tree"));
            return nodes;
        },
        onContextMenu:function(e, node){
            e.preventDefault();
            var root_id = $('#function_tree').tree('getRoot').id;
            var menu_id = 'function_tree_menu_';
            if(node.id != root_id && $('#function_tree').tree('isLeaf', node.target))
            {
                $("#function_tree_menu").html('');
                if(node.perms.all) {
                    $('#function_tree_menu').menu('appendItem', {text:'权限管理', 'iconCls':'icon-auth', onclick:'manager_auth(\'function\','+node.id+',\''+node.text+'\')'});
                } else {
                    $('#function_tree_menu').menu('appendItem', {text:'申请权限', 'iconCls':'icon-auth-apply', onclick:'apply("function",'+node.id+',"申请方法权限")'});
                }
                $('#function_tree_menu').menu('appendItem', {text:'编辑', 'iconCls':'icon-edit', onclick:'create_update_function('+node.id+')'});
                $('#function_tree_menu').menu('appendItem', {text:'删除', 'iconCls':'icon-delete', onclick:'remove_function('+node.id+')'});
                // select the node
                $('#function_tree').tree('select', node.target);
                // display context menu
                $.parser.parse($('#function_tree_menu'));
                $('#function_tree_menu').menu('show', {
                    left: e.pageX,
                    top: e.pageY
                });
            }
        },
        onClick:function(node) {
            if($('#function_tree').tree('isLeaf', node.target)) {
                show_function_info(node);
            }
        },
        onDblClick:function(node){
            if($('#function_tree').tree('isLeaf', node.target)) {
                create_update_function(node.id);
            } else {
                $('#function_tree').tree('toggle', node.target);
            }
        },
    });
}

function show_function_info(node) {
    if($("#obj_info_op").attr('action-data-node-id') == node.id) {
        return;
    }
    var html = '';
    $("#obj_info_op").attr('action-data-node-id', node.id);
    $("#obj_info_op .obj_info_btn").remove();
    html += '<img class="obj_info_btn" title="删除" onclick="remove_function('+node.id+')" src="/static/images/supper_cmd/delete.png"></img>';
    html += '<img class="obj_info_btn" title="编辑" onclick="create_update_function('+node.id+')" src="/static/images/supper_cmd/edit.png"></img>';
    if(node.perms.all) {
        html += '<img class="obj_info_btn" title="权限管理" onclick="manager_auth(\'function\','+node.id+',\''+node.text+'\')" src="/static/images/supper_cmd/auth.png"></img>';
    } else {
        html += '<img class="obj_info_btn" title="申请权限" onclick="apply(\'function\','+node.id+',\'申请方法权限\')" src="/static/images/supper_cmd/auth_apply.png"></img>';
    }
    $("#obj_info_op").append(html);
    $("#obj_info_op .obj_info_name").html(node.text);
    var url = '/supper_cmd/odps_function/detail/';
    var post_data = {id:node.id};
    var callback = callback_show_function_info;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}

function callback_show_function_info(result, args) {
    var html = '';
    if(result.status == 0)
    {
        var owner = result.data.user_info ? result.data.user_info.username_dsp : result.data.dxp_account;
        var comment = result.data.detail.comment ? result.data.detail.comment : '无';
        comment = comment.split('\n').join('<br>');
        html += '<p class="detail_title">创建者</p>';
        html += '<p class="content">'+owner+'</p>';
        html += '<p class="detail_title">描述</p>';
        html += '<p class="content">'+comment+'</p>';
        html += '<p class="detail_title">创建时间</p>';
        html += '<p class="content">'+result.data.detail.creation_time+'</p>';
        html += '<p class="detail_title">依赖资源</p>';
        html += '<p class="content">';
        for(var i in result.data.detail._resources) {
            html += result.data.detail._resources[i] + '<br>';
        }
        html += '</p>';
        html += '<p class="detail_title">ClassType</p>';
        html += '<p class="content">'+result.data.detail.class_type+'</p>';
    } 
    $("#obj_info_region .obj_detail").html(html);
}

function add_function() {
    create_update_function();
}

function init_odps_resource_select(callback, arg) {
    if(select_resource_list_inited) {
        console.log('inited');
        // return true;
    }
    var url = '/supper_cmd/odps_resource/list/';
    show_div_loading($("#dialog_function").parent(), '信息加载中，请稍后...');
    result = makeAPost(
        url, {project:$("#cur_project").text().trim()},
        true, function(result) {
            if(result.status != 0) {
                ark_notify(result);
            } else {
                resources = [];
                for(var i = 0; i < result.data.length; i++) {
                    resources.push({'id': result.data[i].name, 
                                    'name': result.data[i].name});
                }
                MultiUserSelector.init(
                    $("#form_function [name=resources]"), resources, []);
                select_resource_list_inited = true;
                hide_div_loading($("#dialog_function").parent());
                callback(arg);
            }
        }
    );
}

function create_update_function(func_id) {
    $('#dialog_function').dialog({
        title: func_id == undefined ? '新建方法' : '修改方法',
        width: 600,
        height: 320,
        closed: false,
        cache: false,
        modal: true,
        resizable:true,
        buttons:[{
            text:'确定',
            handler:function(){
                do_create_update_function(func_id);
            }
        },{
            text:'关闭',
            handler:function(){
                $('#dialog_function').dialog('close');
                $('#form_function').form('clear');
            }
        }]
    });

    OdpsFunction.refresh_category_list();
    init_odps_resource_select(OdpsFunction.init_edit_form, func_id);
}

function do_create_update_function(func_id) {
    var data = {
        'project': $("#cur_project").text().trim(),
        'name': $("#form_function [name=name]").val(),
        'category': $("#form_function [name=category]").val(),
        'class_type': $("#form_function [name=class_type]").val(),
        'comment': $("#form_function [name=comment]").val(),
        'resources': $("#form_function [name=resources]").val(),
    };

    var url = '/supper_cmd/odps_function/' + (func_id == undefined ? 'create/' : 'update/');
    show_div_loading($("#dialog_function").parent(), '处理中，请稍后...');
    var result = makeAPost(url, data, true, function(result) {
        ark_notify(result);
        hide_div_loading($("#dialog_function").parent());
        if(result.status == 0) {
            $("#dialog_function").dialog('close');
            get_function_tree();
        }
    });
}

function remove_function() {
    $('#dialog_remove #obj_type').val('function');
    $('#dialog_remove [name=confirm_msg]').html('您确定要删除此方法？');
    $('#dialog_remove').dialog('open');
}

function resources_loader(param,success,error) {
    var q = param.q || '';
    result = makeAPost(
        '/supper_cmd/odps_resource/list/', 
        {match_str: q, project:$("#cur_project").text().trim()});
    if(result.status != 0) {
        ark_notify(result);
    } else {
        var items = [];
        for(var i in result.data) {
            items.push({id: result.data[i].id, text: result.data[i].name});
        }
        success(items);
    }
}

odps_function_categories = null;
$(function(){
    $(document).on('change', ".input_function_search", function(){
        get_function_tree();
    });

    window.OdpsFunction = {
        init_edit_form: function(func_id) {
            if(func_id != undefined) {
                var url = '/supper_cmd/odps_function/detail/';
                show_div_loading($("#dialog_function").parent(), '信息加载中，请稍后...');
                var result = makeAPost(url, {'id': func_id}, true, function(result) {
                    if(result.status != 0) {
                        ark_notify(result);
                    } else {
                        $("#dialog_function [name=name]").val(result.data.name);
                        $("#dialog_function [name=name]").prop('readonly', true);
                        $('#dialog_function #category').combobox('setValue', result.data.category);
                        $("#dialog_function [name=class_type]").val(result.data.detail.class_type);
                        $("#dialog_function [name=comment]").val(result.data.detail.comment);
                        $("#form_function [name=resources]").select2().select2("val", result.data.detail.resources);
                    }
                    hide_div_loading($("#dialog_function").parent());
                });
            } else {
                $("#dialog_function [name=name]").prop('readonly', false);
                $('#dialog_function #category').combobox('setValue', '其他');
                $("#form_function [name=resources]").select2("val", []);
            }


        },
        refresh_category_list: function() {
            if(odps_function_categories) {
                $("#dialog_function #category").combobox('loadData', odps_function_categories);
            } else {
                var url = '/supper_cmd/odps_function/get_categories/';
                show_div_loading($("#dialog_function").parent(), '分类列表加载中...');
                makeAPost(url, {}, true, function(result) {
                    items = [];
                    if(result.status == 0) {
                        for(var i in result.data) {
                            items.push({id:result.data[i], text:result.data[i]});
                        }
                    } else {
                        ark_notify(result);
                    }
                    odps_function_categories = items;
                    $("#dialog_function #category").combobox('loadData', odps_function_categories);
                    hide_div_loading($("#dialog_function").parent());

                });
            }
        },
    }

    $('#dialog_function').dialog('close');
    OdpsFunction.refresh_category_list();
});