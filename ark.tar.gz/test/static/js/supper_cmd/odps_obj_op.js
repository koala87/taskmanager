$(function(){
    $('#remove_resource').dialog('close');
    $('#dialog_auth_manager').dialog('close');
    $('#dialog_apply').dialog('close');
    $('#dialog_apply_accept').dialog('close');
    $('#dialog_apply_deny').dialog('close');
    $('#dialog_maintain_info').dialog('close');
    $('#dialog_remove').dialog('close');

    $(document).on('change', "[name='switch_tab_to_spaces']", function() {
        var cur_tab = $("#tab_title").tabs('getSelected');
        var code_id = cur_tab.children().find("textarea").attr('id');
        window.editor[code_id].setOption("tabToSpaces", $(this).is(":checked"));
    });
});

function manager_auth(obj_type, obj_id, obj_name)
{
    $('#form_auth_apply #auth_manager_obj_type').val(obj_type);
    $('#form_auth_apply #auth_manager_obj_id').val(obj_id);
    $("#dialog_auth_manager .grant").combobox('setValue', '');
    $("#dialog_auth_manager .revoke").combobox('setValue', '');
    $("#dialog_auth_manager [name='auth_manager_type']:eq(0)").prop('checked', true);
    $("#dialog_auth_manager .select_grant").show();
    $("#dialog_auth_manager .select_revoke").hide();
    $("#dialog_auth_manager .revoke").combobox('setValue', '');

    var title = 'resource' == obj_type ? '资源' : '方法';
    title += '['+obj_name+']权限管理';
    $('#dialog_auth_manager').dialog({
        title: title,
        width: '980px',
        height: '400px',
        closed: false,
        cache: false,
        resizable:false,
    });
    get_apply_list(obj_type, obj_id);
    get_user_list(obj_type, obj_id);
}

function grant_revoke_list_loader(param, success, error) {
    var q = param.q || '';
    $.ajax({
        url: '/ark_user/has_account_users/', 
        dataType: 'json',
        method: 'post',
        data: {
            match_str: q
        },
        success: function(data){
            var ret = [];
            if(data.status ==0) {
                for(var i in data.data) {
                    if(data.data[i].indexOf(q) > -1) {
                        ret.push({id:i, text:data.data[i]});
                    }
                }
            }
            success(ret);
        },
        error: function(){
            error.apply(this, arguments);
        }
    });
}

function grant_list_loader(param, success, error) {
    grant_revoke_list_loader(param, success, error);
}
function revoke_list_loader(param, success, error) {
    grant_revoke_list_loader(param, success, error);
}

function get_apply_list(obj_type, obj_id)
{
    $("#dialog_auth_manager .auth_manager_left .apply_user_list").html('加载中...');
    var url = obj_type == 'resource' ? '/supper_cmd/odps_resource/apply_users/' 
        : obj_type == 'function' ? '/supper_cmd/odps_function/apply_users/' : '' ;
    var post_data = {id: obj_id};
    makeAPost(url, post_data, true, callback_get_apply_list, obj_type, obj_id);
}

function callback_get_apply_list(result, obj_type, obj_id)
{
    $("#dialog_auth_manager .auth_manager_left .apply_user_list").html('');
    if(result.status == 0)
    {
        if(result.data.length < 1)
        {
            $("#dialog_auth_manager .auth_manager_left .apply_user_list").append('暂无');
        }
        for(var i in result.data)
        {
            $("#dialog_auth_manager .auth_manager_left .apply_user_list").append('<div class="apply_user_line">\
<span class="apply_name">'+result.data[i].username_dsp+'</span><span class="apply_type">'+result.data[i].permission+'</span><a class="easyui-linkbutton" data-options="iconCls:\'icon-ok\'" onclick="confirm_accept_deny(\''+obj_type+'\','+obj_id+','+result.data[i].id+',\'accept\')">同意</a><a class="easyui-linkbutton" data-options="iconCls:\'icon-no\'" onclick="confirm_accept_deny(\''+obj_type+'\','+obj_id+','+result.data[i].id+',\'deny\')">拒绝</a></div>');
        }
        $.parser.parse($("#dialog_auth_manager .auth_manager_left .apply_user_list"));
    }
    else
    {
        $("#dialog_auth_manager .auth_manager_left .apply_user_list").append('读取失败');
    }
}

function get_user_list(obj_type, obj_id)
{
    $("#dialog_auth_manager .auth_manager_left .auth_manager_users .user_list").html('加载中...');
    var url = obj_type == 'resource' ? '/supper_cmd/odps_resource/users/' 
        : obj_type == 'function' ? '/supper_cmd/odps_function/users/' : '' ;

    var post_data = {id: obj_id};
    makeAPost(url, post_data, true, callback_get_user_list, {});
}

function callback_get_user_list(result, args)
{
    $("#dialog_auth_manager .auth_manager_left .auth_manager_users .user_list").html('');
    if(result.status == 0)
    {
        if(result.data.length < 1)
        {
            $("#dialog_auth_manager .auth_manager_left .auth_manager_users .user_list").append('暂无');
        }
        for(var i in result.data)
        {
            var username = result.data[i].user_info == undefined ? result.data[i].account : result.data[i].user_info.username_dsp;
            var perms = result.data[i].perms;
            $("#dialog_auth_manager .auth_manager_left .auth_manager_users .user_list").append('<div class="user_line"><span class="user_name">'+username+'</span><span class="auth_type">'+perms+'</span></div>');
        }
    }
    else
    {
        $("#dialog_auth_manager .auth_manager_left .auth_manager_users .user_list").append('读取失败');
    }
}

function do_grant_revoke() {
    var obj_type = $('#dialog_auth_manager #auth_manager_obj_type').val();
    var obj_id = $('#dialog_auth_manager #auth_manager_obj_id').val();
    var url = obj_type == 'resource' ? '/supper_cmd/odps_resource/' 
        : obj_type == 'function' ? '/supper_cmd/odps_function/' : '' ;

    var auth_type = $("#dialog_auth_manager [name='auth_manager_type']:checked").val();
    url += auth_type == 0 ? 'grant/' : 'revoke/';

    var post_data = {id: obj_id};
    post_data.read = $("#dialog_auth_manager [name='apply_type']:eq(0)").is(':checked') ? 1 : 0;
    post_data.write = $("#dialog_auth_manager [name='apply_type']:eq(1)").is(':checked') ? 1 : 0;
    var user_id = auth_type == 0 ? $("#dialog_auth_manager .grant").combobox('getValue') : $("#dialog_auth_manager .revoke").combobox('getValue');

    post_data.accounts = [user_id];

    show_div_loading($("#dialog_auth_manager").parent(), '处理中，请稍后...');
    result = makeAPost(url, post_data, true, function(result) {
        ark_notify(result);
        if(result.status == 0) {
            $("#dialog_auth_manager .grant").combobox('setValue', '');
            $("#dialog_auth_manager .revoke").combobox('setValue', '');
            get_user_list(obj_type, obj_id);
        }
        hide_div_loading($("#dialog_auth_manager").parent());
    });
}

function confirm_accept_deny(obj_type, obj_id, hist_id, op) {
    $("#dialog_apply_" + op + " #obj_type").val(obj_type);
    $("#dialog_apply_" + op + " #obj_id").val(obj_id);
    $("#dialog_apply_" + op + " #hist_id").val(hist_id);
    $("#dialog_apply_" + op).dialog('open');
}

function do_accept_deny(ok_btn, op) {
    var dlg = ok_btn.parent().prev('.easyui-dialog');
    var obj_type = dlg.find('#obj_type').val();
    var obj_id = dlg.find('#obj_id').val();
    var hist_id = dlg.find('#hist_id').val();

    var url = obj_type == 'resource' ? '/supper_cmd/odps_resource/' 
        : obj_type == 'function' ? '/supper_cmd/odps_function/' : '' ;
    url += op + '/';  // op=accept or op=deny

    var post_data = {hist_id: hist_id};
    var result = makeAPost(url, post_data);
    ark_notify(result);
    if(result.status == 0) {
        get_apply_list(obj_type, obj_id);
        get_user_list(obj_type, obj_id);
        dlg.dialog('close');
    }
}

function apply(obj_type, obj_id, title) {
    dlg_id = 'dialog_apply';
    form_id = 'form_apply';
    $('#' + dlg_id).dialog({
        height: 'auto',
        closed: false,
        cache: false,
        resizable:true,
        title: title,
        buttons:[{
            text:'确定',
            handler:function(){
                do_apply(obj_type, $(this), function(result) {
                    ark_notify(result);
                    if(result.status == 0) {
                        $('#' + dlg_id).dialog('close');
                        $('#' + form_id).form('clear');
                    }
                });
            }
        },{
            text:'关闭',
            handler:function(){
                $('#' + dlg_id).dialog('close');
                $('#' + form_id).form('clear');
            }
        }]
    });

    var url = '/supper_cmd/' + (obj_type == 'resource' ? 'odps_resource' : 'odps_function') + '/detail/';
    show_div_loading($("#" + dlg_id).parent(), '信息加载中，请稍后...');
    var result = makeAPost(url, {'id': obj_id}, true, function(result) {
        if(result.status != 0) {
            ark_notify(result);
        } else {
            $('#' + dlg_id + ' #id').val(obj_id);
            $('#' + form_id + ' #name').val(result.data.name);
            owner = result.data.user_info ? result.data.user_info.username_dsp : result.data.dxp_account;
            $('#' + form_id + ' #owner').val(owner);
        }
        hide_div_loading($("#" + dlg_id).parent());
    });
}

function do_apply(obj_type, ok_btn, callback) {
    var url = '/supper_cmd/' + (obj_type == 'resource' ? 'odps_resource' : 'odps_function') + '/apply/';
    var post_data = {};
    var dlg = ok_btn.parent().prev('.easyui-dialog');
    post_data.id = dlg.find("#id").val().trim();
    post_data.read = dlg.find('[name="type"]:eq(0)').is(':checked') ? 1 : 0;
    post_data.write = dlg.find('[name="type"]:eq(1)').is(':checked') ? 1 : 0;
    post_data.reason = dlg.find("#reason").val().trim();
    result = makeAPost(url, post_data);

    callback(result);
}

function do_remove() {
    var obj_type = $('#dialog_remove #obj_type').val();

    var tree_id = obj_type + '_tree';
    var cur_node = $('#' + tree_id).tree('getSelected');
    var old_name = cur_node.text;

    var url = '/supper_cmd/' + (obj_type == 'resource' ? 'odps_resource' : 
                                obj_type == 'function' ? 'odps_function' :
                                obj_type == 'sql_template' ? 'sql_template' : '') + '/delete/';
    var post_data = null;
    var title = '';
    if(obj_type == 'sql_template') {
        post_data = {id: cur_node.id};
        title = SqlTemplate.get_title(cur_node.name, cur_node.id);
    } else {
        post_data = {project:cur_node.project, name:old_name};
        title = cur_node.project+'.'+old_name;
    }

    show_div_loading($('#dialog_remove').parent(), '处理中，请稍后...');
    var result = makeAPost(url, post_data, true, function(result) {
        if(result.status == 0) {
            if($('#tab_title').tabs('exists', title)) {
                $('#tab_title').tabs('close', title);
            }
            if($("#obj_info_op").attr('action-data-node-id') == cur_node.id)
            {
                $("#obj_info_op").attr('action-data-node-id', '');
                $("#obj_info_op").html('<span class="obj_info_name">summary:</span>');
                $("#obj_info_region .obj_detail").html('');
            }
            $('#' + tree_id).tree('remove', cur_node.target);
        }
        hide_div_loading($('#dialog_remove').parent());
        ark_notify(result);
        $('#dialog_remove').dialog('close');
    });
}

