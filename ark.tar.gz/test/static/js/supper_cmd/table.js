$(function(){
    window.OdpsTable = {
        import_file: function() {
            var project = $("#cur_project").text().trim();
            $("#form_import_file").form('submit', {
                url: '/supper_cmd/odps_table/import_file/',
                onSubmit: function(param) {
                    show_div_loading($("#dialog_import_file").parent(), '处理中，请稍后...');
                    param.project = $("#cur_project").text().trim();
                },
                success: function(result) {
                    hide_div_loading($("#dialog_import_file").parent());
                    result = JSON.parse(result);
                    ark_notify(result);
                    if(result.status == 0) {
                        $('#form_import_file').form('clear');
                        $('#dialog_import_file').dialog('close');
                    }
                }
            });
        },
        begin_import_file: function(table_name, partition) {
            $("#dialog_import_file [name=table]").val(table_name);
            $("#dialog_import_file [name=partition]").val(partition);
            $("#dialog_import_file [name=overwrite]").prop("checked", true);
            $("#dialog_import_file [name=auto_create_partition]").prop("checked", true);
            $('#dialog_import_file').dialog({
                title: '本地上传',
                width: 600,
                height: 260,
                closed: false,
                cache: false,
                modal: true,
                resizable:true,
                buttons:[{
                    text:'确定',
                    handler:function() {
                        OdpsTable.import_file();
                    }
                },{
                    text:'关闭',
                    handler:function(){
                        $('#dialog_import_file').dialog('close');
                        $('#form_import_file').form('clear');
                    }
                }]
            });
            
        }
    }

    $(document).on('click', ".preview_search_span_import", function(){
        var table_name = $(this).parent().attr('action-data-table_name');
        var partition = $(this).parent().find(".preview_search_input_val").val().trim();
        OdpsTable.begin_import_file(table_name, partition);
    });

    $('#dialog_import_file').dialog('close');
});