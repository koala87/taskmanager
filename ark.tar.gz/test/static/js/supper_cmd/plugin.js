$(function(){
    var plugin_html = '<div class="easyui-layout" fit="true" style="height:100%;background:#3c3f41;">\
<div region="north" class="north_tables_list" split="true" border="false" style="overflow:auto;height:50%;background:#3c3f41;">\
<div id="plugin_op_header" class="op_header" style="background:#3c3f41;">\
<span class="title">Plugin</span>\
<img class="obj_btn easyui-linkbutton" data-options="plain:true" title="刷新" onclick="Plugin.refresh_tree()" src="/static/images/supper_cmd/refresh.png">\
<input name="input_obj_search" style="margin-right:10px;" class="input_plugin_search" type="text">\
</div>\
<ul id="plugin_tree" class="obj_tree"></ul>\
</div>\
<div id="obj_info_region" region="center" border="false" style="height:50%;overflow:hidden;background:#3a3d3e;padding: 0 10px;">\
<div id="obj_info_op" action-data-node-id="">\
<span class="obj_info_name">summary:</span>\
</div>\
<div class="obj_detail" style="height: 90%;width:100%;overflow-y: auto;margin: 0 -10px;border-top: 4px solid #444;padding: 0 10px;">\
</div>\
</div>\
</div>';

    window.plugin_run_status = {};
    window.plugin_daemon_log = {};

    window.PluginLog = {
        stop_daemon: function(id) {
            console.log('stop checking log for: ' + id);
            clearInterval(window.plugin_daemon_log[id]);
            delete window.plugin_daemon_log[id];
        },
        daemon: function() {
            for(id in window.plugin_run_status) {
                var run_status = window.plugin_run_status[id].run_status;
                var history_id = window.plugin_run_status[id].run_history_id;
                var start_pos = window.plugin_run_status[id].cur_pos;

                var log = window.plugin_daemon_log[id];
                if((run_status == RUN_STATUS_RUNNING || start_pos == 0)
                   && typeof(log) == 'undefined') {
                    window.plugin_daemon_log[id] = window.setInterval(
                        'PluginLog.get_status("' + id + '",' + history_id + ')', 3000);
                }
            }
        },
        get_status: function(id, history_id) {
            var start_pos = window.plugin_run_status[id].cur_pos;
            var read_len = 1024 * 1024;
            var url = '/supper_cmd/run_history/get_status_log/';
            var post_data = {'id': history_id, 
                             'start_pos': start_pos, 
                             'read_len': read_len};
            var args = {'id': id};
            var callback = PluginLog.update_status;
            makeAPost(url, post_data, true, callback, args);
        },
        update_status: function(result, args) {
            var title = args.id;
            var cur_tab = null;
            if($('#tab_title').tabs('exists', title)) {
                cur_tab = $('#tab_title').tabs('getTab', title);
            }
            if(!cur_tab) {
                PluginLog.stop_daemon(title);
                return;
            }
            
            var log = '';
            var pipeline_status = -1;
            if(result.status == 0) {
                log = result.data.log
                window.plugin_run_status[title].cur_pos += log.length;
                var pipeline_status = result.data.status.pipe_status;
            } else {
                log = "<font style='color:#DF6A53!important'>" + result.msg + "</font>\n";
            }

            if(log == '') {
                log = '...... ';
            }
            log = log.replace(new RegExp(" ", "gm"), '&nbsp;');
            log = log.replace(new RegExp("\t", "gm"), '&nbsp;&nbsp;&nbsp;&nbsp;');
            tmp_log = '';
            if (log.indexOf("http://webconsole.odps.aliyun-inc.com") >= 0) {
                log_list = log.split("\n");
                for (var idx = 0; idx < log_list.length; ++idx) {
                    if (log_list[idx].indexOf("http://webconsole.odps.aliyun-inc.com") == 0) {
                        tmp_log += '<a target="_blank" href="' + log_list[idx] + '">' + log_list[idx] + '</a>' + '\n';
                    } else {
                        tmp_log += log_list[idx] + '\n';
                    }
                }
            } else {
                tmp_log = log;
            }

            log = tmp_log;
            tmp_log = '';
            if (log.indexOf("FAILED:") >= 0) {        
                log_list = log.split("\n");
                for (var idx = 0; idx < log_list.length; ++idx) {
                    if (log_list[idx].indexOf("FAILED:") == 0) {
                        tmp_log += '<font style="color:#DF6A53!important">' + log_list[idx] + '</font>' + '\n';
                    } else {
                        tmp_log += log_list[idx] + '\n';
                    }
                }
            } else {
                tmp_log = log;
            }

            if(pipeline_status == TASK_SUCCEED) {
                tmp_log += "\n<font style='color:#12dc12!important'>执行成功！</font>\n"
            }
            
            if(pipeline_status == TASK_FAILED) {
                tmp_log += "\n<font style='color:red!important'>执行失败！</font>\n"
            }
            log = tmp_log.replace(new RegExp("\n", "gm"), '<br/>');

            var log_div = cur_tab.find("[name=log_output]");
            log_div.tabs('getTab', 0).append(log);
            changeHeight(log_div.find(" .panel-body"));

            console.log(pipeline_status);
            if(pipeline_status == TASK_SUCCEED 
               || pipeline_status == TASK_FAILED) {
                PluginLog.stop_daemon(title);
                var tab = Plugin.get_tab_by_id("tab_title", title);
                Plugin.display_stoped(tab);
            }
        }
    },

    window.Plugin = {
        get_tab_by_id: function(div_id, id) {
            return $('#' + div_id).tabs('getTab', id);
        },
        listHtml: function() {
            return plugin_html;
        },
        list: function() {
            if($(".switch_btn").hasClass('active')) {
                $(".switch_btn").removeClass('active');
            } else {
                $(".switch_btn").addClass('active');
            }
            Plugin.refresh_tree()
        },
        refresh_tree: function() {
            $(".input_plugin_search").trigger('change');
        },
        get_tree: function()
        {
            var url = '/supper_cmd/plugin/list/';
            show_div_loading($("#plugin_tree"), '数据加载中...');
            $('#plugin_tree').tree({
                url:url,
                animate:true,
                queryParams:{
                    project:$("#cur_project").text().trim(), 
                    key_word:$(".input_plugin_search").val()},
                dnd:false,
                loadFilter: function(result){
                    var nodes = [];
                    var switch_auth = $(".switch_btn").hasClass('active');
                    if(result.status == 0) {
                        for(var category in result.data) {
                            var children = []
                            for(var i in result.data[category]) {
                                var t = result.data[category][i];
                                children.push({id: t.id, name: t.name, text: t.name});
                            }
                            nodes.push({id: 0, text: category, state: 'close', children: children});
                        }
                    }
                    if(nodes.length > 0) {
                        nodes[0]['state'] = 'open';
                    }
                    hide_div_loading($("#plugin_tree"));
                    return nodes;
                },
                onClick:function(node) {
                    if($('#plugin_tree').tree('isLeaf', node.target)) {
                        Plugin.show_info(node);
                    }
                },
                onDblClick:function(node){
                    if($('#plugin_tree').tree('isLeaf', node.target)) {
                        Plugin.open(node);
                    } else {
                        $('#plugin_tree').tree('toggle', node.target);
                    }
                },
            });
        },
        show_info: function(node) {
            if($("#obj_info_op").attr('action-data-node-id') == node.name) {
                return;
            }
            var html = '';
            $("#obj_info_op").attr('action-data-node-id', node.name);
            $("#obj_info_op .obj_info_btn").remove();
            html += '<img class="obj_info_btn" title="执行" onclick="Plugin.open()" src="/static/images/supper_cmd/edit.png"></img>';
            $("#obj_info_op").append(html);
            $("#obj_info_op .obj_info_name").html(node.text);
            var url = '/supper_cmd/plugin/detail/';
            var post_data = {name: node.name};
            var args = {};

            show_div_loading($("#obj_info_op").parent());
            makeAPost(url, post_data, true, Plugin.callback_show_info, args);
        },
        callback_show_info: function(result, args) {
            var html = '';
            if(result.status == 0) {
                var owner = result.data.username_dsp != "" ? result.data.username_dsp : result.data.owner_id;
                html += '<p class="detail_title">创建者</p>';
                html += '<p class="content">'+owner+'</p>';

                var description = result.data.description ? result.data.description : '无';
                description = description.split('\n').join('<br>');
                html += '<p class="detail_title">描述</p>';
                html += '<p class="content">'+description+'</p>';
                html += '<p class="detail_title">更新时间</p>';
                html += '<p class="content">'+result.data.update_time+'</p>';
            } 
            $("#obj_info_region .obj_detail").html(html);
            hide_div_loading($("#obj_info_op").parent());
        },
        get_title: function(name, id) {
            var title = 'plugin.' + name;
            if(id)
                title += '.' + id;
            return title;
        },
        update_tab: function(tab, plugin_name, run_history_id, pipeline_name) {
            var old_title = tab.panel('options').title;
            var new_title = Plugin.get_title(plugin_name, run_history_id);
            if(new_title != old_title) {
                $("#tab_title").tabs('update', {
                    tab: tab, 
                    options: {title: new_title}
                });
                tab = $("#tab_title").tabs('getSelected');
                window.editor[new_title] = window.editor[old_title];
                delete window.editor[old_title];
            }

            tab.find('.code_northregion').attr('run-history-id', run_history_id);
            tab.find('[name=link_to_pipeline]').attr('href', '/pipeline/history/' + pipeline_name)
            tab.find('[name=link_to_pipeline]').parent().show()
            tab.find('[name=result_downloader]').parent().show()

            var content = window.editor[new_title] ? window.editor[new_title].getValue() : null;
            var code_div = tab.find("[name=code]");
            code_div.attr('id', new_title);
            SuperCmdCodeMirror.format(new_title, false, null, code_div[0]);
            if(content) {
                window.editor[new_title].setValue(content);
            }

            return new_title;
        },
        display_disable: function(tab) {
            var run_btn = tab.find(".code_op_type_run");
            run_btn.addClass("disable");
            run_btn.find("img").attr('src','/static/images/supper_cmd/run_disable.png');

            var stop_btn = tab.find(".code_op_type_stop");
            stop_btn.addClass("disable");
            stop_btn.find("img").attr('src','/static/images/supper_cmd/stop_disable.png');
        },
        display_running: function(tab) {
            var run_btn = tab.find(".code_op_type_run");
            run_btn.addClass("disable");
            run_btn.find("img").attr('src','/static/images/supper_cmd/run_disable.png');

            var stop_btn = tab.find(".code_op_type_stop");
            stop_btn.removeClass("disable");
            stop_btn.find("img").attr('src','/static/images/supper_cmd/stop.png');
        },
        display_stoped: function(tab) {
            var run_btn = tab.find(".code_op_type_run");
            run_btn.removeClass("disable");
            run_btn.find("img").attr('src','/static/images/supper_cmd/run.png');

            var stop_btn = tab.find(".code_op_type_stop");
            stop_btn.addClass("disable");
            stop_btn.find("img").attr('src','/static/images/supper_cmd/stop_disable.png');
        },
        get_code_mirror_content: function(code_id, obj) {
            var name = obj.name == undefined ? '': obj.name;
            var content = obj.content ? obj.content : '';
            var pipeline_name = obj.pipeline_name ? obj.pipeline_name : '';
            var m_content = '<div class="easyui-layout" fit="true" name="plugin"><div class="code_northregion" run-history-id="" plugin-name="'+name+'" region="north" split="true" border="true" style="min-height:85px;width:100%;height:70%;background-color: #3a3d3f;overflow:hidden;">';
            m_content += '<div class="code_op_btn">';
            m_content += '<span class="code_op_span code_op_type_run"><img src="/static/images/supper_cmd/run.png">Run(F8)</span>';
            m_content += '<span class="code_op_span code_op_type_stop disable"><img src="/static/images/supper_cmd/stop_disable.png">Stop</span>';

            m_content += '<span style="margin-left:50%;display:none"><a name="link_to_pipeline" target="_blank" href="/pipeline/history/' + pipeline_name + '">查看流程</a></span>';

            m_content += '<span style="margin-left:10%;display:none"><a name="result_downloader">pangu结果下载</a></span>';
            m_content += '</div><textarea id="' + code_id + '" name="code">' + content + '</textarea></div>';
            m_content += '<div region="center" class="output" split="true"  border="true" data-options="minHeight:100" style="overflow:hidden;background-color: #3a3d3f;height:30%;">';
            m_content += '<div name="log_output" class="easyui-tabs" data-options="narrow:true,closable:true" style="width:100%;height:100%;background-color:#3c3f41;">';
            m_content += '<div title="Logs" data-options="narrow:true,closable:false" style="background-color:#3c3f41;border-radius:0;height:100%;overflow:auto;padding:0 10px;">';
            m_content += '</div></div></div>';
            m_content += '</div>';

            return m_content;
        },
        open: function(node) {
            if(node == undefined) {
                node = $('#plugin_tree').tree('getSelected');
            }
            var tab_title = Plugin.get_title(node.text);
            var code_id = tab_title;
            if($('#tab_title').tabs('exists', tab_title)) {
                $('#tab_title').tabs('select', tab_title);
            } else {
                show_div_loading($("#tab_title"));
                var url = '/supper_cmd/plugin/cmd_content/';
                result = makeAPost(
                    url, 
                    {'name': node.name, 
                     'project': $("#cur_project").text().trim()}, 
                    true, function(result) {

                        var readonly = false;
                        var code_div = null;
                        if(result.status != 0) {
                            ark_notify(result);
                        } else {
                            var content = Plugin.get_code_mirror_content(
                                code_id, {'name': node.name, 
                                          'content': result.data}, 
                                readonly);
                            $('#tab_title').tabs('add', {
                                title: tab_title,
                                content: content,
                                closable: true
                            });

                            var cur_tab = $("#tab_title").tabs('getSelected');
                            code_div = cur_tab.find('[name=code]')[0];
                        }
                        
                        SuperCmdCodeMirror.format(code_id, readonly, null, code_div);
                        hide_div_loading($("#tab_title"));
                        window.editor[code_id].markClean();
                        CodeMirror.signal(window.editor[code_id], 'change');
                    });
            }
        },
    }

    $(document).on('change', ".input_plugin_search", function(){
        Plugin.get_tree();
    });

    $(document).on('click', "[name=result_downloader]", function(){
        var cur_tab = $("#tab_title").tabs('getSelected');
        var run_history_id = cur_tab.find('.code_northregion').attr('run-history-id');

        var url = '/supper_cmd/plugin/download_result/';
        var post_data = {'history_id': run_history_id};
        show_div_loading($("#tab_title"), '处理中...');
        makeAPost(url, post_data, true, function(result) {
            if(result.status != 0) {
                ark_notify(result);
            } else {
                var file_path = result.data;
                var download_url = '/common/pangu/download_file/?file_path=' + file_path;
                hide_div_loading($("#tab_title"));
                window.open(download_url, '_blank');
            }
            hide_div_loading($("#tab_title"));
        });
    });

    $(document).on('click', "[name=plugin] .code_op_type_run", function(){
        if($(this).hasClass("disable")) {
            return;
        }

        var cur_tab = $("#tab_title").tabs('getSelected');
        var tab_div = $(this).parent().parent();
        var plugin_name = tab_div.attr('plugin-name');
        var code_id = cur_tab.panel('options').title;
        var run_history_id = tab_div.attr('run-history-id');
        var content = window.editor[code_id].getValue().trim();
        if(content == '') {
            ark_notify({status:1, msg:'配置不能为空'});
            return;
        }

        var url = '/supper_cmd/plugin/run/';
        var post_data = {'name': plugin_name, 'cmd_content': content};
        
        show_div_loading($("#tab_title"), '处理中...');
        var result = makeAPost(url, post_data, true, function(result) {
            if(result.status == 0) {
                var run_history_id = result.data.id;
                var pipeline_name = result.data.pipeline_name;
                var new_title = Plugin.update_tab(
                    cur_tab, plugin_name, run_history_id, pipeline_name);
                window.plugin_run_status[new_title] = {
                    'run_history_id': run_history_id,
                    'run_status': RUN_STATUS_RUNNING,
                    'cur_pos': 0};

                cur_tab = $("#tab_title").tabs('getSelected');
                var log_tab = cur_tab.find("[name=log_output]").tabs('getTab', 0);
                var log_str = "提交任务成功，正在执行中......<br/><br/>";
                log_tab.append(log_str);

                Plugin.display_running(cur_tab);
                PluginLog.daemon();
            }
            ark_notify(result);
            hide_div_loading($("#tab_title"));
        });
    });
    $(document).on('click', "[name=plugin] .code_op_type_stop", function(){
        if($(this).hasClass("disable")) {
            return;
        }
        var cur_tab = $("#tab_title").tabs('getSelected');
        var title = cur_tab.panel('options').title;
        // var tab_div = $(this).parent().parent();
        var run_history_id = cur_tab.find('.code_northregion').attr('run-history-id');

        var url = '/supper_cmd/plugin/stop/';
        var post_data = {'history_id': run_history_id};
        show_div_loading($("#tab_title"), '处理中...');
        var result = makeAPost(url, post_data, true, function(result) {

            if(result.status == 0) {
                window.plugin_run_status[title] = {
                    'run_history_id': run_history_id,
                    'run_status': RUN_STATUS_STOPED,
                    'cur_pos': 0};

                log_str = "<br/><font style='color:#DF6A53!important'>执行停止！</font><br/>";
                var log_div = cur_tab.find("[name=log_output]");
                log_div.tabs('getTab', 0).append(log_str);

                PluginLog.stop_daemon(title);
                Plugin.display_stoped(cur_tab);
            } else {
                ark_notify(result);
            }
            hide_div_loading($("#tab_title"));
        });
    });
});