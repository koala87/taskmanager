var unnamed_title_no = 0;
var sql_template_categories = null;
$(function(){
    window.SqlTemplate = {
        switch_tree: function() {
            if($(".switch_btn").hasClass('active')) {
                $(".switch_btn").removeClass('active');
            } else {
                $(".switch_btn").addClass('active');
            }
            SqlTemplate.refresh_tree()
        },
        refresh_tree: function() {
            $(".input_sql_template_search").trigger('change');
        },
        get_tree: function()
        {
            var url = '/supper_cmd/sql_template/list/';
            show_div_loading($("#sql_template_tree"), '数据加载中...');
            $('#sql_template_tree').tree({
                url:url,
                animate:true,
                queryParams:{
                    project:$("#cur_project").text().trim(), 
                    key_word:$(".input_sql_template_search").val()},
                dnd:false,
                loadFilter: function(result){
                    var nodes = [];
                    var switch_auth = $(".switch_btn").hasClass('active');
                    if(result.status == 0) {
                        for(var category in result.data) {
                            var children = []
                            for(var i in result.data[category]) {
                                var t = result.data[category][i];
                                children.push({id: t.id, name: t.name, text: t.name});
                            }
                            nodes.push({id: 0, text: category, state: 'close', children: children});
                        }
                    }
                    if(nodes.length > 0) {
                        nodes[0]['state'] = 'open';
                    }
                    hide_div_loading($("#sql_template_tree"));
                    return nodes;
                },
                onContextMenu:function(e, node){
                    e.preventDefault();
                    var root_id = $('#sql_template_tree').tree('getRoot').id;
                    var menu_id = 'sql_template_tree_menu_';
                    if(node.id != root_id && $('#sql_template_tree').tree('isLeaf', node.target))
                    {
                        $("#sql_template_tree_menu").html('');
                        $('#sql_template_tree_menu').menu('appendItem', {text:'编辑', 'iconCls':'icon-edit', onclick:'SqlTemplate.open()'});
                        $('#sql_template_tree_menu').menu('appendItem', {text:'删除', 'iconCls':'icon-delete', onclick:'SqlTemplate.remove()'});
                        // select the node
                        $('#sql_template_tree').tree('select', node.target);
                        // display context menu
                        $.parser.parse($('#sql_template_tree_menu'));
                        $('#sql_template_tree_menu').menu('show', {
                            left: e.pageX,
                            top: e.pageY
                        });
                    }
                },
                onClick:function(node) {
                    if($('#sql_template_tree').tree('isLeaf', node.target)) {
                        SqlTemplate.show_info(node);
                    }
                },
                onDblClick:function(node){
                    if($('#sql_template_tree').tree('isLeaf', node.target)) {
                        SqlTemplate.open(node);
                    } else {
                        $('#sql_template_tree').tree('toggle', node.target);
                    }
                },
            });
        },
        show_info: function(node) {
            if($("#obj_info_op").attr('action-data-node-id') == node.id) {
                return;
            }
            var html = '';
            $("#obj_info_op").attr('action-data-node-id', node.id);
            $("#obj_info_op .obj_info_btn").remove();
            html += '<img class="obj_info_btn" title="编辑" onclick="SqlTemplate.open()" src="/static/images/supper_cmd/edit.png"></img>';
            html += '<img class="obj_info_btn" title="删除" onclick="SqlTemplate.remove()" src="/static/images/supper_cmd/delete.png"></img>';
            $("#obj_info_op").append(html);
            $("#obj_info_op .obj_info_name").html(node.text);
            var url = '/supper_cmd/sql_template/detail/';
            var post_data = {id:node.id};
            var args = {};
            makeAPost(url, post_data, true, SqlTemplate.callback_show_info, args);
        },

        callback_show_info: function(result, args) {
            var html = '';
            if(result.status == 0)
            {
                var owner = result.data.username_dsp != "" ? result.data.username_dsp : result.data.username;
                html += '<p class="detail_title">创建者</p>';
                html += '<p class="content">'+owner+'</p>';
                html += '<p class="detail_title">分类</p>';
                html += '<p class="content">'+result.data.category+'</p>';

                var description = result.data.description ? result.data.description : '无';
                description = description.split('\n').join('<br>');
                html += '<p class="detail_title">描述</p>';
                html += '<p class="content">'+description+'</p>';
                html += '<p class="detail_title">创建时间</p>';
                html += '<p class="content">'+result.data.create_time+'</p>';
                html += '<p class="detail_title">更新时间</p>';
                html += '<p class="content">'+result.data.update_time+'</p>';
            } 
            $("#obj_info_region .obj_detail").html(html);
        },

        new: function() {
            var title = 'template.new.' + unnamed_title_no;
            var code_id = "code_sql_template_" + unnamed_title_no;
            var content = SqlTemplate.get_code_mirror_content(code_id, {}, false);
            $('#tab_title').tabs('add', {
                title: title,
                content: content,
                closable: true,
            });
            unnamed_title_no += 1;
            SuperCmdCodeMirror.format(code_id, false, 'do_update_content');
            var cur_tab = $("#tab_title").tabs('getSelected');
            SqlTemplate.init_zero_clipboard(cur_tab);

        },

        open: function(node) {
            if(node == undefined) {
                node = $('#sql_template_tree').tree('getSelected');
            }
            var tab_title = SqlTemplate.get_title(node.text, node.id);
            var code_id = "code_sql_template_" + node.id;
            if($('#tab_title').tabs('exists', tab_title)) {
                $('#tab_title').tabs('select', tab_title);
            } else {
                show_div_loading($("#tab_title"));
                var url = '/supper_cmd/sql_template/detail/';
                result = makeAPost(url, {'id': node.id}, true, function(result) {
                    var readonly = !result.data.has_perm;
                    if(result.status != 0) {
                        ark_notify(result);
                    } else {
                        var content = SqlTemplate.get_code_mirror_content(
                            code_id, {'id': node.id, 'content': result.data.content}, readonly);
                        $('#tab_title').tabs('add', {
                            title: tab_title,
                            content: content,
                            closable: true
                        });
                    }
                    SuperCmdCodeMirror.format(code_id, readonly, 'do_update_content');
                    hide_div_loading($("#tab_title"));
                    window.editor[code_id].markClean();
                    CodeMirror.signal(window.editor[code_id], 'change');

                    var cur_tab = $("#tab_title").tabs('getSelected');
                    SqlTemplate.init_zero_clipboard(cur_tab);
                });
            }
        },


        do_update_content: function(item_id) {
            var cur_tab = $("#tab_title").tabs('getSelected');
            var code_id = cur_tab.children().find("textarea").attr('id');
            var content = window.editor[code_id].getValue();

            var url = '/supper_cmd/sql_template/update_content/';
            var data = {id: item_id, content: content};

            show_div_loading(cur_tab.find('.code_northregion'));
            var result = makeAPost(url, data, true, function(result) {
                ark_notify(result);
                hide_div_loading(cur_tab.find('.code_northregion'));
                if(result.status == 0) {
                    window.editor[code_id].markClean();
                    CodeMirror.signal(window.editor[code_id], 'change');
                }
            });
        },
        get_code_mirror_content: function(code_id, obj, readonly) {
            var id = obj.id == undefined ? '': obj.id;
            var content = obj.content ? obj.content : '';
            var m_content = '<div class="easyui-layout" fit="true"><div class="code_northregion" action-data-id="'+id+'" region="north" split="true" border="true" style="min-height:85px;width:100%;height:100%;background-color: #3a3d3f;overflow:hidden;">';
            m_content += '<div class="code_op_btn">';
            if(readonly) {
                m_content += '<span id="copy_code_to_clipboard" class="local_obj">复制到剪切板</span>';
                m_content += '<span>只读</span>';
            } else {
                if(id) {
                    m_content += '<span title="信息维护" class="local_obj local_obj_maintain" name="sql_template_maintain_info"><img src="/static/images/supper_cmd/maintain.png">信息维护</span>';
                }
                m_content += '<span id="copy_code_to_clipboard" class="local_obj">复制到剪切板</span>';
                m_content += '<span style="margin-left:45%"><input type="checkbox" name="switch_tab_to_spaces" checked>4个空格替代Tab</input></span>';
                m_content += '<span title="保存" class="local_obj local_obj_save disable" name="sql_template_save"><img src="/static/images/supper_cmd/save_disable.png">保存</span>';
            }
            m_content += '</div><textarea id="' + code_id + '"  name="code">' + content + '</textarea>';
            m_content += '</div></div>';
            return m_content;
        },
        remove: function() {
            $('#dialog_remove #obj_type').val('sql_template');
            $('#dialog_remove [name=confirm_msg]').html('您确定要删除此模板？');
            $('#dialog_remove').dialog('open');
        },
        refresh_category_list: function() {
            if(sql_template_categories) {
                $("#dialog_sql_template #category").combobox('loadData', sql_template_categories);
            } else {
                var url = '/supper_cmd/sql_template/get_categories/';
                show_div_loading($("#dialog_sql_template").parent(), '分类列表加载中...');
                makeAPost(url, {}, true, function(result) {
                    items = [];
                    if(result.status == 0) {
                        for(var i in result.data) {
                            items.push({id:result.data[i], text:result.data[i]});
                        }
                    } else {
                        ark_notify(result);
                    }
                    sql_template_categories = items;
                    $("#dialog_sql_template #category").combobox('loadData', sql_template_categories);
                    hide_div_loading($("#dialog_sql_template").parent());

                });
            }
        },
        refresh_category_list: function() {
            if(sql_template_categories) {
                $("#dialog_sql_template #category").combobox('loadData', sql_template_categories);
            } else {
                var url = '/supper_cmd/sql_template/get_categories/';
                show_div_loading($("#dialog_sql_template").parent(), '分类列表加载中...');
                makeAPost(url, {}, true, function(result) {
                    items = [];
                    if(result.status == 0) {
                        for(var i in result.data) {
                            items.push({id:result.data[i], text:result.data[i]});
                        }
                    } else {
                        ark_notify(result);
                    }
                    sql_template_categories = items;
                    $("#dialog_sql_template #category").combobox('loadData', sql_template_categories);
                    hide_div_loading($("#dialog_sql_template").parent());

                });
            }
        },
        do_save: function(id) {
            var id = $('#dialog_sql_template #id').val();
            var name = $('#dialog_sql_template #name').val();
            var category = $('#dialog_sql_template #category').combobox('getValue');
            var description = $('#dialog_sql_template #description').val();

            var cur_tab = $("#tab_title").tabs('getSelected');
            var code_id = cur_tab.children().find("textarea").attr('id');
            var content = '';
            if(id == '') {
                content = window.editor[code_id].getValue();
            }

            var data = {'id': id, 'name': name, 'category': category,
                        'description': description, 'content': content};
            var url = '/supper_cmd/sql_template/' + (id == '' ? 'create/' : 'update_info/');
            show_div_loading($('#dialog_sql_template').parent());
            makeAPost(url, data, true, function(result) {
                hide_div_loading($('#dialog_sql_template').parent());
                ark_notify(result);
                if(result.status == 0) {
                    $('#dialog_sql_template').dialog('close');
                }
                if(id == '') {
                    window.editor[code_id].markClean();
                    CodeMirror.signal(window.editor[code_id], 'change');
                    id = result.data.id;
                    cur_tab.children().find(".code_northregion").attr('action-data-id', result.data.id);
                    cur_tab.children().find(".local_obj_save").before('<span title="信息维护" class="local_obj local_obj_maintain" name="sql_template_maintain_info" ><img src="/static/images/supper_cmd/maintain.png">信息维护</span>');
                }
                SqlTemplate.refresh_tree();
                var new_title = SqlTemplate.get_title(name, id);
                $("#tab_title").tabs('update', {
                    tab: cur_tab,
                    type: 'header',
                    options: {
                        title: new_title,
                    }
                });
            });
        },
        get_title: function(name, id) {
            return 'template.' + name + '.' + id;
        },
        init_zero_clipboard: function(cur_tab) {
            var cli = new ZeroClipboard(cur_tab.find("#copy_code_to_clipboard"));
            cli.on( "ready", function( readyEvent ) {
                cli.on( "copy", function( event ) {
                    var code_id = cur_tab.children().find("textarea").attr('id');
                    var content = window.editor[code_id].getValue();
                    if(content == "") {
                        cli.empty();
                    }
                    cli.setText(content);
                });
                cli.on( "aftercopy", function( event ) {
                    ark_notify({'status': 0, 'msg': '模板内容已复制到剪切板'});
                });
            });
        },
        show_save_dialog: function(id) {
            var title = id == '' ? '新建模板' : '信息维护';
            $('#dialog_sql_template').dialog({
                title: title,
                width: 600,
                height: 'auto',
                closed: false,
                cache: false,
                modal: true,
                resizable:true,
                buttons:[{
                    text:'确定',
                    handler:function(){
                        SqlTemplate.do_save(id);
                    }
                },{
                    text:'关闭',
                    handler:function(){
                        $('#dialog_sql_template').dialog('close');
                    }
                }]
            });

            SqlTemplate.refresh_category_list();

            if(id) {
                var url = '/supper_cmd/sql_template/detail/';
                show_div_loading($('#dialog_sql_template').parent(), '信息加载中，请稍后...');
                var result = makeAPost(url, {'id': id}, true, function(result) {
                    if(result.status != 0) {
                        ark_notify(result);
                    } else {
                        $('#dialog_sql_template #id').val(id);
                        $('#dialog_sql_template #name').val(result.data.name);
                        $('#dialog_sql_template #category').combobox('setValue', result.data.category);
                        $('#dialog_sql_template #description').val(result.data.description);
                    }
                    hide_div_loading($('#dialog_sql_template').parent());
                });
            } else {
                var cur_tab = $("#tab_title").tabs('getSelected');
                $('#dialog_sql_template #id').val('');
                $('#dialog_sql_template #name').val('');
                $('#dialog_sql_template #description').val('');
            }
        }
    }

    $(document).on('change', ".input_sql_template_search", function(){
        SqlTemplate.get_tree();
    });

    CodeMirror.commands.do_update_content = function (cm) {
        $("#tab_title").tabs('getSelected').find('.local_obj_save').trigger('click');
    };

    $(document).on('click', "[name=sql_template_save]", function(){
        var id = $(this).parent().parent().attr("action-data-id");
        if(id == '') {
            SqlTemplate.show_save_dialog(id);
        } else {
            SqlTemplate.do_update_content(id);
        }
    });

    $(document).on('click', "[name=sql_template_maintain_info]", function(){
        var id = $(this).parent().parent().attr("action-data-id");
        SqlTemplate.show_save_dialog(id);
    });

    $('#dialog_sql_template').dialog('close');
});