window.qr['runPage'] = function (opt) {
    'use strict';
    var $doc = $(document.body);
    var loading = 'loading';
    var render = {
        appList: function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
__p += '<div id="qr-item-list" class="col-md-3 column qr-item-list">\n    <div id="qr-apps" class="clearfix dropdown qr-dropdown">\n        ';
 var list = obj.data; ;
__p += '\n        <div class="qr-app-list">\n            <div class="qr-app-con">\n                ';
 if (list.length) {;
__p += '\n                <select id="qr-dropdown-menu" class="dropdown-menu select2-hidden-accessible" role="menu" aria-labelledby="qr-select" style="width: 100%">\n                    ';
 for (var i = 0,len = list.length; i < len; i++) { ;
__p += '\n                    <option value="' +
((__t = ( list[i].id )) == null ? '' : __t) +
'">' +
((__t = ( list[i].name )) == null ? '' : __t) +
'</option>\n                    ';
 } ;
__p += '\n                </select>\n                ';
 } ;
__p += '\n            </div>\n            <p class="pull-right qr-btns">\n                <span id="qr-set" class="qr-app-set glyphicon glyphicon-cog"></span>\n                <span data-back class="qr-back"><i class="glyphicon glyphicon-chevron-left"></i>返回</span>\n            </p>\n        </div>\n    </div>\n    <div id="qr-app-detail" class="qr-app-detail">\n        <div id="qr-list-body">\n            <div id="qr-list-show" class="qr-list-wrapper">数据正在加载,请等待...</div>\n            <div id="qr-list-set" class="qr-list-wrapper">数据正在加载,请等待...</div>\n        </div>\n        <div class="qr-list-footer">\n            <button id="add-group" type="button" class="btn btn-default btn-block btn-sm">+添加分组</button>\n            <button id="save-ads" type="button" class="btn btn-default btn-block qr-save btn-sm">导入ads并重新加载</button>\n        </div>\n    </div>\n</div>\n<div class="sider-line"></div>\n<div id="qr-quanren-panel" class="col-md-9 column qr-quanren-panel">\n    <div id="qr-panel-view" class="qr-wrapper panel panel-default">\n        <div class="clearfix qr-people-main">\n            <div class="form-horizontal col-md-7">\n                <div class="form-group">\n                    <label class="col-sm-3 control-label">人群名称</label>\n                    <div class="col-sm-8">\n                      <input type="text" class="form-control" placeholder="请输入" data-peoplename>\n                    </div>\n                </div>\n                <div class="form-group">\n                    <label class="col-sm-3 control-label">人群标签</label>\n                    <div class="col-sm-8">\n                        <input type="text" class="qr-people-tag" value="" data-peopletags>\n                    </div>\n                </div>\n            </div>\n            <div class="col-md-2">\n                <a href="javascript:;" data-counttotal>计算人群总数</a>\n                <p data-totalnum></p>\n            </div>\n            <div class="col-md-3">\n                <button type="button" class="btn btn-default qr-btn-primary" id="qr-people-save">保存</button>\n                <button type="button" class="btn btn-default qr-btn-sub" id="qr-clear-field">清空条件</button>\n            </div>\n        </div>\n        <div class="qr-filter-detail"></div>\n    </div>\n    <div id="qr-panel-set" class="qr-wrapper panel-default"></div>\n</div>';
return __p
}, // 渲染应用列表
        appDetail: function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }

 var data = obj.data;;
__p += '\n';
 for (var i = 0, len = data.length; i < len; i++) { ;
__p += '\n';
 var subLen = data[i].sub_list && data[i].sub_list.length; ;
__p += '\n';
 var isSetPanel = obj.isSet; ;
__p += '\n<dl class="qr-unextend" >\n    <dt data-group="' +
((__t = ( data[i].group_name )) == null ? '' : __t) +
'"  data-toggle>\n        <span class="glyphicon glyphicon-folder-close"></span>\n        ' +
((__t = ( data[i].group_name )) == null ? '' : __t) +
'\n        ';
 if (isSetPanel) { ;
__p += '\n            <span class="glyphicon glyphicon-remove pull-right" data-delete="group"></span>\n        ';
 } ;
__p += '\n    </dt>\n    ';
if (subLen) { ;
__p += '\n        ';
 for (var j = 0, jlen = subLen; j < jlen; j++) {;
__p += '\n        ';
var canUse = data[i].sub_list[j].can_use === 0 ? false : true;;
__p += '\n        <dd data-fieldname="' +
((__t = ( data[i].sub_list[j].field_name )) == null ? '' : __t) +
'" data-id="' +
((__t = (data[i].sub_list[j].field_id)) == null ? '' : __t) +
'" ';
if(!canUse){;
__p += ' class="undo qr-filter clearfix" ';
} else {;
__p += ' class="qr-filter clearfix" ';
};
__p += '>\n            <i class="set-canuse glyphicon glyphicon-ok-sign"></i>\n            ' +
((__t = ( data[i].sub_list[j].field_name )) == null ? '' : __t) +
'\n            ';
 if(isSetPanel) { ;
__p += '\n                <span class="pull-right glyphicon glyphicon-remove" data-delete="filter"></span>\n            ';
};
__p += '\n            <i class="glyphicon glyphicon-ok pull-right"></i>\n        </dd>\n        ';
 } ;
__p += '\n    ';
 } ;
__p += '\n    ';
 if (isSetPanel) { ;
__p += '\n        <dd class="qr-add-item"><button type="button" class="btn btn-default" data-addfilter>+模块项</button></dd>\n    ';
 } ;
__p += '\n</dl>\n';
 } ;
__p += '\n\n\n';
return __p
}, // 渲染应用筛选及分组
        modal: function (obj) {
var __t, __p = '';
__p += '<div class="modal qr-modal" id="qr-modal">\n    <div class="modal-dialog">\n        <div class="modal-content">\n            <div class="modal-header">\n                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true"></span><span class="sr-only"></span></button>\n                <h4 class="modal-title">' +
((__t = ( obj.title )) == null ? '' : __t) +
'</h4>\n            </div>\n            <div class="modal-body">\n                ' +
((__t = ( obj.body )) == null ? '' : __t) +
'\n            </div>\n            <div class="modal-footer">\n                <button type="button" class="btn btn-default qr-btn-sub" data-dismiss="modal">取消</button>\n                <button type="button" class="btn qr-btn-primary qr-btn-ok">确定</button>\n            </div>\n        </div>\n    </div>\n</div>\n';
return __p
}, // 渲染弹窗
        addGroup: function (obj) {
var __t, __p = '';
__p += '<div class="form-horizontal qr-form">\n    <div class="form-group">\n        <label class="col-sm-3 control-label"><em>*</em>分组名称</label>\n        <div class="col-sm-8">\n            <input type="text" class="form-control" placeholder="请输入分组">\n        </div>\n    </div>\n</div>\n';
return __p
}, // 渲染分组弹窗
        addFilter: function (obj) {
var __t, __p = '';
__p += '<div class="form-horizontal qr-form">\n    <div class="form-group">\n        <label class="col-sm-3 control-label"><em>*</em>模块项名称</label>\n        <div class="col-sm-8">\n            <input type="text" class="form-control" placeholder="请输入模块项名称">\n        </div>\n    </div>\n</div>';
return __p
}, // 渲染筛选条件弹窗
        setFilter: function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }

 var data = obj.data; ;
__p += '\n';
 var field_json = data.field_json || []; ;
__p += '\n<div class="panel panel-default qr-set-filter" id="qr-set-filter">\n    <div class="panel-heading clearfix">\n        <h4 class="panel-title pull-left">' +
((__t = ( obj.name )) == null ? '' : __t) +
'</h4>\n        <button type="button" class="btn btn-default pull-right qr-btn-sub"  data-deletefilter="' +
((__t = ( data.field_id )) == null ? '' : __t) +
'">删除</button>&nbsp;&nbsp;&nbsp;&nbsp;\n        <button type="button" class="btn btn-default pull-right qr-btn-primary" id="save-filter" data-field="' +
((__t = ( obj.field_id )) == null ? '' : __t) +
'" data-filtername="' +
((__t = ( obj.name )) == null ? '' : __t) +
'">确认条件</button>\n    </div>\n    <div class="panel-body qr-set-edit">\n        <div class="form-horizontal">\n            <div class="form-group">\n                <label class="col-md-2 control-label"><em>*</em>数据字段</label>\n                <div class="col-md-4">\n                    <select id="qr-data-attr" class="form-control">\n                        <option value=""></option>\n                    </select>\n                </div>\n            </div>\n            <div class="qr-conditions-wrapper">\n            </div>\n            <div class="form-group">\n                <label class="col-md-2 control-label">&nbsp;</label>\n                <button class="col-md-10 btn qr-add-control">+添加条件项</button>\n            </div>\n            ';
 var ori = 'form-group qr-condition-relation'; ;
__p += '\n            ';
 var oribtn = 'btn btn-default btn-group-sm'; ;
__p += '\n            ';
 var onoribtn = oribtn + ' qr-on'; ;
__p += '\n            ';
 if (field_json.length > 1 && data.and_or_tag) { ;
__p += '\n                ';
 ori += ' qr-show-rela'; ;
__p += '\n            ';
} ;
__p += '\n            <div class="' +
((__t = ( ori )) == null ? '' : __t) +
'">\n                <label class="col-md-2 control-label"><em>*</em>多条件关系</label>\n                <div class="col-md-4 btn-group">\n                    <button type="button" ';
if (data.and_or_tag == 1) {;
__p += ' class="' +
((__t = ( onoribtn )) == null ? '' : __t) +
'" ';
} else {;
__p += ' class="' +
((__t = ( oribtn )) == null ? '' : __t) +
'" ';
};
__p += ' data-relation="1">且</button>\n                    <button type="button" ';
if (data.and_or_tag == 2) {;
__p += ' class="' +
((__t = ( onoribtn )) == null ? '' : __t) +
'" ';
} else {;
__p += ' class="' +
((__t = ( oribtn )) == null ? '' : __t) +
'" ';
};
__p += ' data-relation="2">或</button>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n';
return __p
}, // 渲染筛选条件配置
        setConditionValue: function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }

 switch(obj.container) { case '2': ;
__p += '\n    ';
 var values = (obj.value || '').split(','); ;
__p += '\n    <input type="text" class="form-control qr-range" value="' +
((__t = ( values[0] )) == null ? '' : __t) +
'" placeholder="输入值" data-qrinput>\n    <div class="qr-to-line">-</div>\n    <input type="text" class="form-control qr-range" value="' +
((__t = ( values[1] )) == null ? '' : __t) +
'" placeholder="输入值" data-qrinput>\n\n    ';
 break; ;
__p += '\n    ';
 case '0' : ;
__p += '\n        <input type="text" data-qrinput class="form-control qr-inputtags"  placeholder="输入值域" value="' +
((__t = ( obj.value )) == null ? '' : __t) +
'">\n        ';
 break; ;
__p += '\n    ';
 case '3': ;
__p += '\n    ';
 case '4': ;
__p += '\n    ';
 case '5': ;
__p += '\n    ';
 case '6': ;
__p += '\n        <input type="text" data-qrinput class="form-control"  placeholder="输入值域" value="' +
((__t = ( obj.value )) == null ? '' : __t) +
'" ';
 if (!obj.value) {;
__p += ' disabled ';
};
__p += ' >\n        ';
 break; ;
__p += '\n';
 default: ;
__p += '\n    <input type="text" data-qrinput class="form-control"  placeholder="输入值域" value="' +
((__t = ( obj.value )) == null ? '' : __t) +
'">\n';
 } ;
__p += '\n\n\n';
return __p
}, // 渲染控件联动值域
        previewFilterSet: function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }

 var data = obj.data.field_json; ;
__p += '\n\n<div class="qr-preview panel panel-default" data-fieldid="' +
((__t = ( obj.data.field_id )) == null ? '' : __t) +
'" >\n    <div class="qr-preview-title clearfix panel-heading">\n        <h4 class="panel-title pull-left">' +
((__t = ( obj.name )) == null ? '' : __t) +
'</h4>\n\n        <button type="button" class="btn btn-default pull-right qr-btn-sub"  data-deletefilter="' +
((__t = ( obj.field_id )) == null ? '' : __t) +
'">删除</button>&nbsp;&nbsp;&nbsp;&nbsp;\n        <button type="button" class="btn btn-default pull-right qr-btn-primary" data-field="' +
((__t = ( obj.field_id )) == null ? '' : __t) +
'" data-filtername="' +
((__t = ( obj.name )) == null ? '' : __t) +
'" id="qr-field-modify">编辑条件</button>\n    </div>\n    <div class="panel-body">\n        ';
 for(var i = 0, len = data.length; i < len; i++) { ;
__p += '\n        ';
 var containerType = data[i].container; ;
__p += '\n        ';
 var fieldType = data[i].field_type; ;
__p += '\n        ';
 if (i !== 0) {;
__p += '\n            ';
 var relation = obj.data.and_or_tag == 1 ? '且' : '或'; ;
__p += '\n            <div class="row qr-relation-wrapper">\n                <div class="col-xs-3">\n                    <p>|</p>\n                    <p class="qr-reletion-type">' +
((__t = ( relation )) == null ? '' : __t) +
'</p>\n                    <p>|</p>\n                </div>\n            </div>\n        ';
 } ;
__p += '\n\n        <div data-containertype="' +
((__t = ( containerType )) == null ? '' : __t) +
'" data-fieldtype="' +
((__t = ( fieldType )) == null ? '' : __t) +
'" class="row form-horizontal">\n            <label class="col-xs-3 control-label">\n                ' +
((__t = ( data[i].field_name )) == null ? '' : __t) +
'\n            </label>\n            <div class="col-xs-5 form-inputs-row clearfix">\n            ';
 switch (containerType * 1) { case 0: ;
__p += '\n                    <input type="text" value="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" class="form-control qr-inputtags" data-qrinput>\n                    ';
 break; ;
__p += '\n                ';
 case 1: ;
__p += '\n                ';
 case 7: ;
__p += ' <!-- 单（多）选下拉框 -->\n                    ';
 var multiple = containerType == 1; ;
__p += '\n                    ';
 var seclass = multiple ? ' qr-multiple' : ''; ;
__p += '\n                    <select class="js-states select2-hidden-accessible form-control ' +
((__t = ( seclass )) == null ? '' : __t) +
'" ';
if (multiple) {;
__p += ' multiple="multiple" ';
};
__p += ' style="width: 100%">\n                        ';
 if(multiple) { ;
__p += '\n                        <option value="全选">全选</option>\n                        ';
 } ;
__p += '\n                        ';
 var vals = (data[i].default_values || '').split(','); ;
__p += '\n                        ';
 for (var j = 0, jlen = vals.length; j < jlen; j++) { ;
__p += '\n                            <option value="' +
((__t = ( vals[j] )) == null ? '' : __t) +
'">' +
((__t = ( vals[j] )) == null ? '' : __t) +
'</option>\n                        ';
 } ;
__p += '\n                    </select>\n                    ';
 break; ;
__p += '\n                ';
 case 2: ;
__p += ' <!-- 数值区间 -->\n                    ';
 var values = (data[i].default_values || '').split(','); ;
__p += '\n                    <div class="col-xs-5 row">\n                        <input class="form-control" type="text" value="' +
((__t = ( values[0] || '' )) == null ? '' : __t) +
'" data-qrinput>\n                    </div>\n                    <div class="range-line pull-left">－</div>\n                    <div class="col-xs-5 row">\n                     <input type="text" value="' +
((__t = ( values[1] || '' )) == null ? '' : __t) +
'" class="form-control" data-qrinput>\n                    </div>\n                    ';
 break; ;
__p += '\n                ';
 case 3: ;
__p += ' <!-- 月时间单选 -->\n                    <div class="calendar">\n                        <input class="form-control qr-datetimepicker" type="text" value="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" data-qrinput="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" data-datetype="month" >\n                    </div>\n                    ';
 break; ;
__p += '\n                ';
 case 4: ;
__p += ' <!-- 月时间区间 -->\n                    ';
 var values = (data[i].default_values || '').split(','); ;
__p += '\n                    <div class="calendar col-xs-5 row">\n                        <input class="form-control qr-datetimepicker" type="text" value="' +
((__t = ( values[0] || '' )) == null ? '' : __t) +
'"  data-qrinput="' +
((__t = ( values[0] || '' )) == null ? '' : __t) +
'" data-datetype="month">\n                    </div>\n                    <div class="range-line pull-left">－</div>\n                    <div class="calendar col-xs-5 row" >\n                        <input class="form-control qr-datetimepicker" type="text" value="' +
((__t = ( values[1] || '' )) == null ? '' : __t) +
'"  data-qrinput="' +
((__t = ( values[1] || '' )) == null ? '' : __t) +
'" data-datetype="month">\n                    </div>\n                    ';
 break; ;
__p += '\n                ';
 case 5: ;
__p += ' <!-- 天时间单选 -->\n                    <div class="calendar">\n                        <input class="qr-datetimepicker form-control" type="text" data-qrinput="data[i].default_values" value="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" data-datetype="day">\n                    </div>\n                    ';
 break; ;
__p += '\n                ';
 case 6: ;
__p += ' <!-- 天时间区间 -->\n                    ';
 var values = (data[i].default_values || '').split(','); ;
__p += '\n                    <div class="col-xs-5 calendar row">\n                        <input class="qr-datetimepicker form-control" type="text" data-qrinput="' +
((__t = ( values[0] || '' )) == null ? '' : __t) +
'" value="' +
((__t = ( values[0] || '' )) == null ? '' : __t) +
'" data-datetype="day">\n                    </div>\n                    <div class="range-line pull-left">－</div>\n                    <div class="col-xs-5 calendar row">\n                        <input class="qr-datetimepicker form-control" type="text" data-qrinput="' +
((__t = ( values[1] || '' )) == null ? '' : __t) +
'" value="' +
((__t = ( values[1] || '' )) == null ? '' : __t) +
'" data-datetype="day">\n                    </div>\n                    ';
 break; ;
__p += '\n            ';
 } ;
__p += '\n            </div>\n        </div>\n    ';
 } ;
__p += '\n    </div>\n</div>\n';
return __p
}, // 预览筛选条件设置
        renderFilter: function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
__p += '\n<div class="qr-filter-wrapper clearfix" data-fieldid="' +
((__t = ( obj.field_id )) == null ? '' : __t) +
'">\n    <div class="col-md-7">\n        <div class="filter-title">\n            <h4>' +
((__t = ( obj.name )) == null ? '' : __t) +
'</h4>\n        </div>\n        ';
 var data = obj.data.field_json;;
__p += '\n        ';
 for(var i = 0, len = data.length; i < len; i++) { ;
__p += '\n            ';
 var containerType = data[i].container; ;
__p += '\n            ';
 var fieldType = data[i].field_type; ;
__p += '\n            ';
 if (i !== 0) {;
__p += '\n                ';
 var relation = obj.data.and_or_tag == 1 ? '且' : '或'; ;
__p += '\n                <div class="row qr-relation-wrapper">\n                    <div class="col-md-3">\n                        <p>|</p>\n                        <p class="qr-reletion-type">' +
((__t = ( relation )) == null ? '' : __t) +
'</p>\n                        <p>|</p>\n                    </div>\n                </div>\n            ';
 } ;
__p += '\n\n            <div data-containertype="' +
((__t = ( containerType )) == null ? '' : __t) +
'" data-fieldtype="' +
((__t = ( fieldType )) == null ? '' : __t) +
'" class="row form-horizontal show-filter-row" data-query>\n                <label class="col-sm-3 control-label">\n                    ' +
((__t = ( data[i].field_name )) == null ? '' : __t) +
'\n                </label>\n                <div class="col-sm-8">\n                ';
 switch (containerType * 1) { case 0: ;
__p += '\n                        <input type="text" value="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" class="form-control qr-inputtags" data-qrinput>\n                        ';
 break; ;
__p += '\n                    ';
 case 1: ;
__p += '\n                    ';
 case 7: ;
__p += ' <!-- 单（多）选下拉框 -->\n                        ';
 var multiple = containerType == 1; ;
__p += '\n                        ';
 var seclass = multiple ? ' qr-multiple' : ''; ;
__p += '\n                        <select data-ismust="' +
((__t = ( data[i].must )) == null ? '' : __t) +
'" class="js-states select2-hidden-accessible form-control ' +
((__t = ( seclass )) == null ? '' : __t) +
'" ';
if (multiple) {;
__p += ' multiple="multiple" ';
};
__p += ' style="width: 100%">\n\n                            ';
 if(multiple) { ;
__p += '\n                            <option value="全选">全选</option>\n                            ';
 } else { ;
__p += '\n                                <option value></option>\n                            ';
 } ;
__p += '\n                            ';
 var vals = (data[i].default_values || '').split(','); ;
__p += '\n                            ';
 for (var j = 0, jlen = vals.length; j < jlen; j++) { ;
__p += '\n                                <option value="' +
((__t = ( vals[j] )) == null ? '' : __t) +
'">' +
((__t = ( vals[j] )) == null ? '' : __t) +
'</option>\n                            ';
 } ;
__p += '\n                        </select>\n                        ';
 break; ;
__p += '\n                    ';
 case 2: ;
__p += ' <!-- 数值区间 -->\n                        ';
 var values = (data[i].default_values || '').split(','); ;
__p += '\n                        <div class="col-xs-5 row qr-range-input">\n                            <input class="form-control" type="text" value="' +
((__t = ( values[0] || '' )) == null ? '' : __t) +
'" data-qrinput>\n                        </div>\n                        <div class="range-line pull-left">－</div>\n                        <div class="col-xs-5 row qr-range-input">\n                            <input type="text" value="' +
((__t = ( values[1] || '' )) == null ? '' : __t) +
'" class="form-control" data-qrinput>\n                        </div>\n                        ';
 break; ;
__p += '\n                    ';
 case 3: ;
__p += ' <!-- 月时间单选 -->\n                        <div class="calendar" >\n                            <input type="text" value="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" class="form-control qr-datetimepicker" data-qrinput="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" data-datetype="month" >\n                        </div>\n                        ';
 break; ;
__p += '\n                    ';
 case 4: ;
__p += ' <!-- 月时间区间 -->\n                        ';
 var values = (data[i].default_values || '').split(','); ;
__p += '\n\n                        <div class="calendar col-xs-5 row clearfix">\n                            <input type="text" value="' +
((__t = ( values[0] )) == null ? '' : __t) +
'" class="form-control qr-datetimepicker pull-left" data-qrinput="' +
((__t = ( values[0] )) == null ? '' : __t) +
'" data-datetype="month" >\n                        </div>\n                        <div class="range-line pull-left">－</div>\n                        <div class="calendar col-xs-5 row clearfix">\n                            <input type="text" value="' +
((__t = ( values[1] )) == null ? '' : __t) +
'" class="form-control qr-datetimepicker pull-right" data-qrinput="' +
((__t = ( values[1] )) == null ? '' : __t) +
'" data-datetype="month" >\n                        </div>\n                        ';
 break; ;
__p += '\n                    ';
 case 5: ;
__p += ' <!-- 天时间单选 -->\n                        <input type="text" value="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" class="form-control qr-datetimepicker" data-qrinput="' +
((__t = ( data[i].default_values )) == null ? '' : __t) +
'" data-datetype="day" >\n                        ';
 break; ;
__p += '\n                    ';
 case 6: ;
__p += ' <!-- 天时间区间 -->\n                        ';
 var values = (data[i].default_values || '').split(','); ;
__p += '\n                        <div class="calendar col-xs-5 row clearfix">\n                            <input class="qr-datetimepicker form-control pull-left" type="text" data-qrinput="' +
((__t = ( values[0] )) == null ? '' : __t) +
'" data-datetype="day" value="' +
((__t = ( values[0] )) == null ? '' : __t) +
'" >\n                        </div>\n                        <div class="range-line pull-left">－</div>\n                        <div class="calendar col-xs-5 row clearfix">\n                            <input class="qr-datetimepicker form-control pull-right" type="text" data-qrinput="' +
((__t = ( values[1] )) == null ? '' : __t) +
'" data-datetype="day" value="' +
((__t = ( values[1] )) == null ? '' : __t) +
'" >\n                        </div>\n                        ';
 break; ;
__p += '\n                ';
 } ;
__p += '\n                </div>\n            </div>\n        ';
 } ;
__p += '\n    </div>\n    <div class="col-md-2">\n        <a href="javascript:;" data-countpeople="' +
((__t = ( obj.field_id )) == null ? '' : __t) +
'">计算人群数</a>\n            <p data-totalnum></p>\n    </div>\n    <div class="col-md-3">\n        <span class="glyphicon glyphicon-remove qr-filter-close" data-fieldid="' +
((__t = ( obj.field_id )) == null ? '' : __t) +
'"></span>\n    </div>\n</div>';
return __p
}
    };
    var lc = {
        table_id: null,
        sql: null
    };
    var $setPanel;
    var $viewPanel;

    $.datetimepicker.setLocale('ch');

    window.qr.ajax({
        url: '/interest_graphs/shuqi_toufang/get_table_list/',
        // url: '/page/quanren/applist.json',
        data: {
            start_idx: 0,
            end_idx: 10000
        },
        success: function (data) {
            $('.qr-quanren').html(render.appList({data: data}));
            $setPanel = $('#qr-panel-set');
            $viewPanel = $('#qr-panel-view');
            getPeopleSet(data[0].id);
        }
    });
    function renderAppDetail(id) {
        getAppDetail(id);
        lc.table_id = id;
        $('#qr-dropdown-menu').select2();
        $('#qr-dropdown-menu').on('change', function () {
            getAppDetail(this.value);
            lc.table_id = this.value;
            $('.qr-filter-detail').html('');
        });
        initSetFilterEvent();
        initEvent();
    }
    function renderFilterForCount(params) {
        var html = render.renderFilter(params);

        var $newHtml = $('.qr-filter-detail').append(html);

        $newHtml.find('.show-filter-row').each(function (index, ele) {
            (function ($ele){
                // initDatePicker($ele);
                initInputs($ele.data('containertype'), $ele);
            })($(ele));
        });
        // $newHtml.find('select').each(function (index, ele) {
        //     (function ($ele){
        //         if ($ele.data('ismust')) {
        //             $ele.select2({
        //                 placeholder: '请选择'
        //             });
        //         } else {
        //             $ele.select2({
        //                 placeholder: '请选择',
        //                 allowClear: true
        //             });
        //         }
        //     })($(ele));

        // });
        return $newHtml;
    }
    // 渲染人群信息
    function getPeopleSet(tableId) {
        if (opt.group_id && opt.group_id !== -1) { // 回填人群设置
            window.qr.ajax({
                url: '/interest_graphs/shuqi_toufang/get_saved_circle_people/',
                data: {
                    group_id: opt.group_id
                },
                success: function (data) {
                    lc.sql = data.sql;
                    renderAppDetail(data.table_id);
                    // 回填筛选条件
                    // 初始化标签
                    $('#qr-panel-view [data-peoplename]').val(data.name);
                    $('#qr-panel-view [data-peopletags]').importTags(data.name);
                    var query = data.query_json;

                    for (var i = 0, len = query.length; i < len; i++) {
                        var group = query[i].field_info.group_name;
                        var fieldId = query[i].field_id;
                        var name = query[i].field_info.con_name;

                        $('#qr-list-show [data-group="' + group + '"]').closest('dl').addClass('qr-extend');
                        $('#qr-list-show [data-id="' + fieldId + '"]').addClass('qr-filter-on');

                        var $html = renderFilterForCount({
                            data: query[i].field_info,
                            name: name,
                            field_id: fieldId
                        });

                        // 设置值
                        $html.find('.qr-filter-wrapper').each(function (index, ele) {
                            setQueryValues($(ele), query[index].value_list);
                        });
                    }
                }
            });
        } else {
            renderAppDetail(tableId);
        }
    }
    // 左侧列表事件注册
    function initEvent() {
        $('.qr-people-tag').tagsInput({
            defaultText: '添加标签'
        });
        $('#qr-item-list')
            .on('click', '[data-toggle]', function (e) {
                if ($(e.target).data('delete')) {
                    return false;
                }
                $(this).closest('dl').toggleClass('qr-extend');
            })
            .on('click', '#qr-set, [data-back]', function () {
                $(this).closest('.qr-item-list').toggleClass('qr-list-edit');
                var $setP = $('#qr-list-set');
                var $showP = $('#qr-list-show');

                if (this.id) {
                    $setPanel.show();
                    $setP.show();
                    $viewPanel.hide();
                    $showP.hide();
                    $('#qr-dropdown-menu').prop('disabled', true);
                } else {
                    $setPanel.hide();
                    $setP.hide();
                    $viewPanel.show();
                    $showP.show();
                    $('#qr-dropdown-menu').prop('disabled', false);
                    $('#qr-dropdown-menu').trigger('change');
                }
            })
            .on('click', '#add-group', function () {
                $('body').append(render.modal({
                    title: '新建分组',
                    body: render.addGroup()
                }));
                $('#qr-modal').modal('show');
                $('#qr-modal').on('click', '.qr-btn-ok', function () {
                    var name = $('#qr-modal').find('input').val();

                    if (!name) {
                        window.qr.tips({
                            text: '请填写分组名称!',
                            type: 'worn'
                        });
                        return;
                    }
                    name = name.trim();
                    window.qr.ajax({
                        url: '/interest_graphs/shuqi_toufang/create_group/',
                        data: {
                            table_id: lc.table_id,
                            group_name: name
                        },
                        success: function (data) {
                            $('#qr-modal').modal('hide');
                            $('#qr-list-set').append(render.appDetail({
                                data: [{
                                    group_name: name
                                }],
                                isSet: true
                            }));
                        }
                    });
                });
            })
            .on('click', '#qr-dropdown-menu li', function () {
                lc.table_id = $(this).data('id');
            })
            .on('click', '#qr-list-set [data-addfilter]', function () {
                var $target = $(this);

                $('body').append(render.modal({
                    title: '添加模块项',
                    body: render.addFilter()
                }));
                $('#qr-modal').modal('show');
                $('#qr-modal').on('click', '.qr-btn-ok', function (e) {
                    var group = $target.closest('dl').find('[data-group]').data('group');
                    var name = $('#qr-modal').find('input').val();

                    if (!name) {
                        window.qr.tips({
                            text: '请填写模块项名称!',
                            type: 'worn'
                        });
                        return;
                    }
                    name = name.trim();
                    window.qr.ajax({
                        url: '/interest_graphs/shuqi_toufang/create_field/',
                        // url: '/page/quanren/addfilter.json',
                        data: {
                            table_id: lc.table_id,
                            group_name: group,
                            field_name: name
                        },
                        success: function (data) {
                            $('#qr-modal').modal('hide');
                            var str = [
                                '<dd class="qr-filter" data-fieldname="' + name + '" data-id="' + data.id + '">' + name,
                                    '<span class="pull-right glyphicon glyphicon-remove" data-delete="filter"></span>',
                                '</dd>'
                            ];

                            var $filter = $(str.join('')).insertBefore($target.closest('dd'));

                            $('#qr-item-list .qr-filter').removeClass('current');
                            $filter.addClass('current');
                            setFilterDetail({
                                name: name,
                                data: {
                                    field_id: data.id,
                                    odps_field_name: '',
                                    field_json: [
                                        {
                                            field_name: '',
                                            default_values: '',
                                            accumulate: false,
                                            must: true
                                        }
                                    ]
                                },
                                field_id: data.id
                            });
                        }
                    });
                });
            })
            .on('click', '#qr-list-set .qr-filter', function () {
                $('#qr-list-set .qr-filter').removeClass('current');
                $(this).addClass('current');
                getFilterDetail({
                    id: $(this).data('id'),
                    name: $(this).data('fieldname')
                }, $(this));
            })
            .on('click', '#qr-list-set [data-delete]', function () {

                var $target = $(this);
                var type = $target.data('delete');
                var url;
                var data = {};
                var success;

                $('body').append(render.modal({
                    title: '删除',
                    body: '确定进行删除操作吗？'
                }));
                $('#qr-modal').modal('show');
                $('#qr-modal').on('click', '.qr-btn-ok', function () {
                    switch (type) {
                        case 'group':
                            url = '/interest_graphs/shuqi_toufang/delete_group/';
                            data = {
                                group_name: $target.closest('dt').data('group'),
                                table_id: lc.table_id
                            };
                            success = function () {
                                $target.closest('dl').remove();
                                clearFilterDetail();
                            };
                            break;
                        case 'filter':
                            url = '/interest_graphs/shuqi_toufang/delete_field/';
                            data = {
                                field_id: $target.closest('dd').data('id')
                            };
                            success = function () {
                                $target.closest('dd').remove();
                                clearFilterDetail();
                            };
                            break;
                    }
                    window.qr.ajax({
                        url: url,
                        data: data,
                        success: function () {
                            success();
                            window.qr.tips({
                                text: '删除成功',
                                type: 'success'
                            });
                            $('#qr-modal').modal('hide');
                        }
                    });
                });
            })
            .on('click', '#save-ads', function () {

                $.ajax({
                    url: '/interest_graphs/shuqi_toufang/get_data_loading_status/',
                    async: false,
                    type: 'POST',
                    data: {
                        table_id: lc.table_id
                    },
                    dataType: 'json',
                    success: function (result) {
                        if (result.status == 0){
                            var msgTable = '';

                            if (result.data.loading) {
                                for (var i in result.data.loading) {
                                    msgTable += '<tr>';
                                    msgTable += '<td>' + i + '</td>';
                                    msgTable += '<td>' + result.data.loading[i].join('、') + '</td>';
                                    msgTable += '</tr>';
                                }
                            }
                            var msg = '';

                            if (msgTable != '') {
                                var htmlTable = '';

                                htmlTable += '<table class="table table-hover table-bordered qr-table dataTable no-footer" id="table_list_status" style="table-layout: fixed; word-break: break-all; font-family: MicrosoftYaHei, &quot;Microsoft YaHei&quot;font-size: 10px; width: 100%;" cellspacing="0" width="100%" role="grid" >';
                                htmlTable += '<thead>';
                                htmlTable += '<th width="10%">分组</th>';
                                htmlTable += '<th width="15%">模块项</th>';
                                htmlTable += '</thead><tbody>';
                                htmlTable += msgTable;
                                htmlTable += '</tbody></table>';;

                                msg = '<div style="font-size:13px">加载中的模块项</div>';
                                msg += htmlTable;
                                msg += '<div class="clearfix" style="margin-top:20px"></div>';

                                var bodyMsg = '<p style="font-size:13px"><span style="color:red">除以上模块项外，</span>所有模块项都会在保存后加载到ads，并且新增筛选条件的字段名，字段类型将不可修改！确定保存吗？</p>'

                            } else {
                                var bodyMsg = '<p style="font-size:13px">保存后，会重新加载数据到ads，并且新增筛选条件的字段名，字段类型将不可修改！确定保存吗？</p>'
                            }

                            var bodyStr = '<p>' + msg + '</p>' + bodyMsg;

                            $('#qr-modal').remove();
                            $('body').append(render.modal({
                                title: '提示',
                                body: bodyStr,
                            }));
                            $('#qr-modal .modal-dialog .modal-content').css('width', '600px');
                            $('#qr-modal').modal('show');

                            $('#qr-modal').on('click', '.qr-btn-ok', function () {
                                window.qr.ajax({
                                    url: '/interest_graphs/shuqi_toufang/save_all/',
                                    data: {
                                        table_id: lc.table_id
                                    },
                                    success: function (data) {
                                        window.qr.tips({
                                            text: '操作成功',
                                            type: 'success'
                                        });
                                        $('#qr-modal').modal('hide');
                                    }
                                });
                            });
                        } else {
                            window.qr.tips({
                                text: msg,
                                type: 'error'
                            });
                        }
                    }
                });
            });
        $('#qr-list-show')
            .on('click', '.qr-filter', function () {
                var $target = $(this);
                var id = $target.data('id');

                if ($target.hasClass('undo')) {
                    window.qr.tips({
                        text: '当前模块项不可用',
                        type: 'worn'
                    });
                    return;
                }
                $target.toggleClass('qr-filter-on');
                if ($target.hasClass('qr-filter-on')) { // 渲染圈人条件
                    window.qr.ajax({
                        url: '/interest_graphs/shuqi_toufang/get_field/',
                        // url: '/page/quanren/getfield.json',
                        data: {
                            field_id: id
                        },
                        success: function (data) {
                            renderFilterForCount({
                                data: data,
                                name: data.con_name,
                                field_id: id
                            });
                            // var html = render.renderFilter({
                            //     data: data,
                            //     name: data.con_name,
                            //     field_id: id
                            // });

                            // var $newHtml = $('.qr-filter-detail').append(html);

                            // $newHtml.find('.show-filter-row').each(function (index, ele) {
                            //     (function ($ele){
                            //         initDatePicker($ele);
                            //     })($(ele));
                            // });
                            // $newHtml.find('select').each(function (index, ele) {
                            //     $(ele).select2();
                            // });
                        }
                    });
                } else { // 移除圈人条件
                    var $filter = $('.qr-filter-wrapper[data-fieldid="' + id + '"]');

                    if (!$filter.length) {
                        return;
                    }
                    $filter.remove();
                }
            });
        $doc
            .on('click', '.qr-filter-wrapper .qr-filter-close', function () {
                $('#qr-list-show [data-id="' + $(this).data('fieldid') + '"').trigger('click');
            })
            .on('click', '[data-countpeople]', function () {
                var fieldId = $(this).data('countpeople');
                var $scope = $(this).closest('.qr-filter-wrapper');

                getTotalNum({
                    $target: $(this),
                    query: [{
                        field_id: fieldId,
                        value_list: getQueryValues($scope)
                    }],
                    $scope: $scope
                });
            })
            .on('click', '[data-counttotal]:not(.loading)', function (e, cb) {
                var $target = $(this);

                if (!$('.qr-filter-detail .qr-filter-wrapper').length) {
                    window.qr.tips({
                        text: '请先选择圈人条件'
                    });
                    return;
                }
                var data = [];

                $('.qr-filter-detail .qr-filter-wrapper').each(function (index, ele) {
                    data.push({
                        field_id: $(ele).data('fieldid'),
                        value_list: getQueryValues($(ele))
                    });
                });
                getTotalNum({
                    $target: $target,
                    query: data,
                    $scope: $target.closest('.qr-people-main'),
                    cb: cb
                });
            })
            .on('click', '#qr-people-save', function () {
                var name = $('.qr-people-main [data-peoplename]').val();
                var tags = $('.qr-people-main [data-peopletags]').val();
                var str = '请填写';

                if (!name || !tags) {
                    if (!name) {
                        str += '人群名称';
                    }
                    if (!tags) {
                        str += '人群标签';
                    }
                    window.qr.tips({
                        text: str
                    });
                    return;
                }

                $('.qr-people-main [data-counttotal]').trigger('click', [function (params) {
                    window.qr.ajax({
                        url: '/interest_graphs/shuqi_toufang/save_circle_people/',
                        data: $.extend({}, params, {
                            name: name,
                            tag: tags,
                            sql: lc.sql
                        }),
                        success: function (result) {
                            change_page_toufang(result.group_id, opt.cid, result.sql);
                            window.qr.tips({
                                text: '人群保存成功',
                                type: 'success'
                            });
                        }
                    });
                }]);
            })
            .on('click', '#qr-clear-field', function () {
                var $filters = $('.qr-filter-detail .qr-filter-close');

                if (!$filters.length) {
                    window.qr.tips({
                        text: '无可清空条件项'
                    });
                    return;
                }
                $filters.trigger('click');
            })
            .on('select2:selecting', 'select', function () {
                var value = $(this).val() || [];
                var index = value.indexOf('全选');

                if (index !== -1) { // 存在全选则清空
                    $(this).val(null).trigger('change');
                }
            })
            .on('select2:select', 'select', function () {
                var value = $(this).val() || [];
                var index = value.indexOf('全选');

                if (index !== -1) { // 存在全选则过滤
                    $(this).val(value[index]).trigger('change');
                }
            });
    }
    // 获取应用分组及筛选
    function getAppDetail(id) {
        window.qr.ajax({
            url: '/interest_graphs/shuqi_toufang/get_group_and_fieds/',
            // url: '/page/quanren/appdetail.json',
            data: {
                table_id: id
            },
            success: function (data) {
                var html = '<p class="bg-warning qr-warning">暂无可用模块，请进行模块配置</p>';

                if (data.length) {
                    html = render.appDetail({data: data, isSet: false});
                }
                $('#qr-list-show').html(html);
                $('#qr-list-set').html(render.appDetail({data: data, isSet: true}));
            }
        });
    }
    // 获取odps字段
    function getOdps($select, odps) {
        window.qr.ajax({
            url: '/interest_graphs/shuqi_toufang/get_odps_fields/',
            // url: '/page/quanren/dataAttr.json',
            data: {
                table_id: lc.table_id,
                force_refresh: '0'
            },
            success: function (data) {
                var optins = [];
                var values = $.extend([], data);

                for (var i = 0, len = values.length; i < len; i++) {
                    if (!values[i].is_part) {
                        optins.push({
                            id: values[i].field_name,
                            text: values[i].field_name
                        });
                    }
                }
                $select.select2({
                    placeholder: '请选择数据字段',
                    allowClear: true,
                    data: optins
                });
                if (odps) {
                    $select.val(odps).trigger('change');
                }
            }
        });
    }
    // 配置及重置筛选条件
    function setFilterDetail(obj) {
        $('#qr-panel-set').html(render.setFilter(obj));
        getOdps($('#qr-data-attr'), obj.data.odps_field_name);
        $('.qr-conditions-wrapper').html(function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }

 var field_json = obj.field_json_item || {}; ;
__p += '\n';
 var strclass = obj.index == 1 ? '' : ' qr-multiple qr-con-addition'; ;
__p += '\n<div class="form-group qr-set-condition ' +
((__t = ( strclass )) == null ? '' : __t) +
'" data-condition>\n    <label class="col-md-2 control-label qr-filter-label"><em>*</em>条件项' +
((__t = ( obj.index )) == null ? '' : __t) +
'</label>\n    <div class="col-md-10">\n        <div class="row qr-filter-row">\n            <div class="col-xs-3">\n                <input type="text" class="form-control" placeholder="条件项名称" data-fieldname value="' +
((__t = ( field_json.field_name || '')) == null ? '' : __t) +
'">\n            </div>\n            <div class="col-xs-4 qr-condition-select">\n                <select class="js-example-tags form-control select2-hidden-accessible" style="width: 100%">\n                    <option value=""></option>\n                </select>\n            </div>\n\n            <div class="col-xs-4 qr-condition-value clearfix">\n                <div class="value-wrapper">\n                    ';
 if (field_json.container == 2) { ;
__p += '\n                        ';
 var val = field_json.default_values.split(','); ;
__p += '\n                        <input type="text" class="form-control qr-range" value="' +
((__t = ( val[0] || '')) == null ? '' : __t) +
'">\n                        <div class="qr-to-line">-</div>\n                        <input type="text" class="form-control qr-range" value="' +
((__t = ( val[1] || '')) == null ? '' : __t) +
'">\n                    ';
 } else { ;
__p += '\n                        <input type="text" class="form-control"  placeholder="输入值域" data-fieldvalue value="' +
((__t = ( field_json.default_values )) == null ? '' : __t) +
'">\n                    ';
 } ;
__p += '\n                </div>\n                ';
if (obj.index !== 1) {;
__p += '\n                <div class="checkbox qr-check-plus">\n                    <label>\n                      <input type="checkbox" ';
 if(field_json.accumulate || field_json.accumulate == undefined){;
__p += ' checked="checked" ';
 } ;
__p += ' data-plus>累加\n                    </label>\n                </div>\n                ';
};
__p += '\n            </div>\n            ';
 var isLock = (field_json.must == undefined || field_json.must) ? 'lock' : 'unlock'; ;
__p += '\n\n            <div class="pull-right checkbox qr-check-must ' +
((__t = ( isLock)) == null ? '' : __t) +
'">\n                <a href="javascript:;" class="qr-ismust-icon"></a>\n\n            </div>\n        </div>\n    </div>\n    ';
if (obj.index !== 1) {;
__p += '\n        <div class="qr-condition-delete pull-left">\n            <span class="glyphicon glyphicon-minus-sign"></span>\n        </div>\n    ';
};
__p += '\n</div>\n';
return __p
}({
            index: 1,
            field_json_item: {}
        }));
        // initSetFilterEvent();
        initConditionSelect($('.qr-condition-select'), obj);
    }
    // 注册筛选配置区域事件
    function initSetFilterEvent() {
        // var conditions = $scope.find('.qr-set-condition').clone(true);

        $doc.on('click', '#qr-set-filter .qr-add-control', function () {

            var $addCon = $(function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }

 var field_json = obj.field_json_item || {}; ;
__p += '\n';
 var strclass = obj.index == 1 ? '' : ' qr-multiple qr-con-addition'; ;
__p += '\n<div class="form-group qr-set-condition ' +
((__t = ( strclass )) == null ? '' : __t) +
'" data-condition>\n    <label class="col-md-2 control-label qr-filter-label"><em>*</em>条件项' +
((__t = ( obj.index )) == null ? '' : __t) +
'</label>\n    <div class="col-md-10">\n        <div class="row qr-filter-row">\n            <div class="col-xs-3">\n                <input type="text" class="form-control" placeholder="条件项名称" data-fieldname value="' +
((__t = ( field_json.field_name || '')) == null ? '' : __t) +
'">\n            </div>\n            <div class="col-xs-4 qr-condition-select">\n                <select class="js-example-tags form-control select2-hidden-accessible" style="width: 100%">\n                    <option value=""></option>\n                </select>\n            </div>\n\n            <div class="col-xs-4 qr-condition-value clearfix">\n                <div class="value-wrapper">\n                    ';
 if (field_json.container == 2) { ;
__p += '\n                        ';
 var val = field_json.default_values.split(','); ;
__p += '\n                        <input type="text" class="form-control qr-range" value="' +
((__t = ( val[0] || '')) == null ? '' : __t) +
'">\n                        <div class="qr-to-line">-</div>\n                        <input type="text" class="form-control qr-range" value="' +
((__t = ( val[1] || '')) == null ? '' : __t) +
'">\n                    ';
 } else { ;
__p += '\n                        <input type="text" class="form-control"  placeholder="输入值域" data-fieldvalue value="' +
((__t = ( field_json.default_values )) == null ? '' : __t) +
'">\n                    ';
 } ;
__p += '\n                </div>\n                ';
if (obj.index !== 1) {;
__p += '\n                <div class="checkbox qr-check-plus">\n                    <label>\n                      <input type="checkbox" ';
 if(field_json.accumulate || field_json.accumulate == undefined){;
__p += ' checked="checked" ';
 } ;
__p += ' data-plus>累加\n                    </label>\n                </div>\n                ';
};
__p += '\n            </div>\n            ';
 var isLock = (field_json.must == undefined || field_json.must) ? 'lock' : 'unlock'; ;
__p += '\n\n            <div class="pull-right checkbox qr-check-must ' +
((__t = ( isLock)) == null ? '' : __t) +
'">\n                <a href="javascript:;" class="qr-ismust-icon"></a>\n\n            </div>\n        </div>\n    </div>\n    ';
if (obj.index !== 1) {;
__p += '\n        <div class="qr-condition-delete pull-left">\n            <span class="glyphicon glyphicon-minus-sign"></span>\n        </div>\n    ';
};
__p += '\n</div>\n';
return __p
}({
                index: $('.qr-conditions-wrapper .qr-set-condition').length + 1,
                field_json_item: {}
            })).appendTo($('.qr-conditions-wrapper'));
            initConditionSelect($addCon.find('.qr-condition-select'));
            $doc.find('#qr-set-filter .qr-set-condition').addClass('qr-multiple');
            $doc.find('.qr-condition-relation').addClass('qr-show-rela');
            $doc.find('.qr-condition-relation button:first-child').trigger('click');
            isCanPlus();
        });

        $doc.on('click', '#qr-set-filter .qr-condition-relation button', function () {
            var $relationBtns = $doc.find('.qr-condition-relation button');

            $relationBtns.removeClass('qr-on');
            $(this).addClass('qr-on');
        });
        $doc
            .on('click', '#qr-set-filter .qr-con-addition .qr-condition-delete', function () {
                $(this).closest('.qr-set-condition').remove();
                if ($doc.find('[data-condition]').length === 1) {
                    $doc.find('.qr-condition-relation').removeClass('qr-show-rela');
                    $doc.find('.qr-set-condition').removeClass('qr-multiple');
                }
                isCanPlus();
            })
            .on('click', '.qr-check-must', function () {
                $(this).toggleClass('unlock');
            })
            .on('mouseenter', '.qr-check-must .qr-ismust-icon', function () {
                var tips = '必填';
                var $parent = $(this).closest('.qr-check-must');

                if ($parent.hasClass('unlock')) {
                    tips = '非必填';
                }
                $(this).tooltip({
                    title: tips
                });
                $(this).tooltip('show');
            })
            .on('mouseout', '.qr-check-must .qr-ismust-icon', function () {
                $(this)
                    .tooltip('show')
                    .tooltip('destroy');
            });
        $doc
            .on('click', '#qr-set-filter #save-filter', function () {
                var fieldName = $(this).data('filtername');
                var odpsName = $('#qr-data-attr').val();
                var fieldJson = [];
                var relation = $doc.find('.qr-show-rela .qr-on').data('relation');
                var errorStr = '';

                if (!odpsName) {
                    errorStr = '请选择数据字段!';
                    window.qr.tips({
                        text: errorStr,
                        type: 'worn'
                    });
                    return;
                }
                $doc.find('.qr-set-condition').each(function (index, ele) {
                    var $select = $(ele).find('select');

                    if (!$select.val()) {
                        errorStr = '请选择控件';
                        return false;
                    }
                    var type = $select.val().split('-');
                    var conditionName = $(ele).find('[data-fieldname]').val();

                    if (!conditionName) {
                        errorStr = '请填写条件项';
                        return false;
                    }
                    var data = {
                        field_name: $(ele).find('[data-fieldname]').val(),
                        field_type: type[0],
                        container: type[1],
                        default_values: (function () {
                            var val = [];

                            $(ele).find('.qr-condition-value input[data-qrinput]').each(function (index, ele) {
                                var value = $(ele).val();

                                if ((type[1] == 1 || type[1] == 7) && !value) {
                                    errorStr = '请为下拉列表填写值域!';
                                    return false;
                                }
                                val.push(value);
                            });

                            return val.join(',');
                        })(),
                        must: $(ele).find('.unlock').length ? false : true
                    };

                    if ($(ele).hasClass('qr-plus')) {
                        data.accumulate = $(ele).find('[data-plus]')[0].checked;
                    }

                    fieldJson.push(data);
                });
                if (errorStr) {
                    window.qr.tips({
                        text: errorStr,
                        type: 'worn'
                    });
                    return;
                }
                var params = {
                    odps_field_name: odpsName,
                    field_id: $(this).data('field'),
                    field_json: fieldJson
                };

                if (relation) {
                    params.and_or_tag = parseInt(relation);
                }
                window.qr.ajax({
                    url: '/interest_graphs/shuqi_toufang/update_field/',
                    // url: '/page/quanren/delete.json',
                    data: $.extend({}, params, {
                        field_json: JSON.stringify(params.field_json)
                    }),
                    success: function (data) {
                        var detailParams = {
                            data: params,
                            name: fieldName,
                            field_id: params.field_id
                        };

                        showFilterDetail(detailParams);

                        $('.qr-preview').on('click', function () {
                            render.setFilter(detailParams);
                        });
                    }
                });
            })
            .on('click', '#qr-set-filter [data-deletefilter]', function () {
                var selector = '[data-id="' + $(this).data('deletefilter') + '"] [data-delete]';

                $('#qr-list-body').find(selector).trigger('click');
            });
    }
    // 清空筛选详情
    function clearFilterDetail() {
        $('#qr-panel-set').html('');
    }
    // 初始化控件组选择下拉
    function initConditionSelect($scope, params) {
        var txt = {
            '0': '多个文本输入框',
            '1': '多选下拉框',
            '2': '数值区间',
            '3': '月时间单选',
            '4': '月时间区间',
            '5': '天时间单选',
            '6': '天时间区间',
            '7': '单选下拉列表'
        };

        var options = {
            'string': {
                type: '3',
                contain: [0, 1, 7]
            },
            'int': {
                type: '0',
                contain: [0, 1, 2, 7]
            },
            'double': {
                type: '1',
                contain: [2]
            },
            'datetime': {
                type: '2',
                contain: [3, 4, 5, 6]
            },
            '多值列': {
                type: '4',
                contain: [0, 1, 7]
            }
        };
        var $select = $scope.find('select');

        $select.select2({
            placeholder: '选择控件',
            data: (function () {
                var data = [];

                for (var i in options) {
                    var obj = {
                        text: i,
                        children: (function (i) {
                            var arr = [];

                            for (var j = 0, jlen = options[i].contain.length; j < jlen; j++) {
                                arr.push({
                                    id: options[i].type + '-' + options[i].contain[j],
                                    text: txt[options[i].contain[j]]
                                });
                            }
                            return arr;
                        })(i)
                    };

                    data.push(obj);
                }
                return data;
            })()
        })
        .on('change', function (e, data) {
            var value = this.value.split('-');
            var $selectValue = render.setConditionValue({
                container: value[1],
                value: data
            });

            var $html = $(this).closest('.qr-filter-row').find('.value-wrapper').html($selectValue);

            $html.find('.qr-inputtags').tagsInput({
                defaultText: '添加默认值'
            });
            isCanPlus();
        });
        if (params && params.data.field_json) { // 存在默认值
            $scope.find('select').each(function (index, ele){
                var data = params.data.field_json[index];

                $(ele).val(data.field_type + '-' + data.container).trigger('change', [data.default_values]);
            });
        }
    }
    // 是否累加
    function isCanPlus() {
        var $conditions = $('#qr-set-filter .qr-con-addition');

        if (!$conditions.length) {
            return;
        }
        var $lastCond = $conditions.eq($conditions.length - 1);
        var $select = $lastCond.find('select');

        if (!$select.val()) {
            $conditions.removeClass('qr-plus');
            return;
        }
        $conditions.removeClass('qr-plus');
        if ($select.val().split('-')[0] == '0' || $select.val().split('-')[0] == '1') {
            $lastCond.addClass('qr-plus');
        }
    }
    // 渲染筛选项详情
    function showFilterDetail(data) {
        var html = render.previewFilterSet(data);

        $('#qr-panel-set').html(html);

        $('.qr-preview [data-containertype]').each(function (index, ele) {
            (function ($ele){
                initInputs($ele.data('containertype'), $ele);
            })($(ele));
        });

        $('.qr-preview').on('click', '#qr-field-modify', function () {

            $('#qr-panel-set').html(render.setFilter({
                name: data.name,
                data: data.data,
                field_id: $(this).data('field')
            }));
            getOdps($('#qr-data-attr'), data.data.odps_field_name);
            var json = data.data.field_json;
            var html = '';

            for (var i = 0, ilen = json.length; i < ilen; i++) {
                html += function (obj) {
var __t, __p = '', __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }

 var field_json = obj.field_json_item || {}; ;
__p += '\n';
 var strclass = obj.index == 1 ? '' : ' qr-multiple qr-con-addition'; ;
__p += '\n<div class="form-group qr-set-condition ' +
((__t = ( strclass )) == null ? '' : __t) +
'" data-condition>\n    <label class="col-md-2 control-label qr-filter-label"><em>*</em>条件项' +
((__t = ( obj.index )) == null ? '' : __t) +
'</label>\n    <div class="col-md-10">\n        <div class="row qr-filter-row">\n            <div class="col-xs-3">\n                <input type="text" class="form-control" placeholder="条件项名称" data-fieldname value="' +
((__t = ( field_json.field_name || '')) == null ? '' : __t) +
'">\n            </div>\n            <div class="col-xs-4 qr-condition-select">\n                <select class="js-example-tags form-control select2-hidden-accessible" style="width: 100%">\n                    <option value=""></option>\n                </select>\n            </div>\n\n            <div class="col-xs-4 qr-condition-value clearfix">\n                <div class="value-wrapper">\n                    ';
 if (field_json.container == 2) { ;
__p += '\n                        ';
 var val = field_json.default_values.split(','); ;
__p += '\n                        <input type="text" class="form-control qr-range" value="' +
((__t = ( val[0] || '')) == null ? '' : __t) +
'">\n                        <div class="qr-to-line">-</div>\n                        <input type="text" class="form-control qr-range" value="' +
((__t = ( val[1] || '')) == null ? '' : __t) +
'">\n                    ';
 } else { ;
__p += '\n                        <input type="text" class="form-control"  placeholder="输入值域" data-fieldvalue value="' +
((__t = ( field_json.default_values )) == null ? '' : __t) +
'">\n                    ';
 } ;
__p += '\n                </div>\n                ';
if (obj.index !== 1) {;
__p += '\n                <div class="checkbox qr-check-plus">\n                    <label>\n                      <input type="checkbox" ';
 if(field_json.accumulate || field_json.accumulate == undefined){;
__p += ' checked="checked" ';
 } ;
__p += ' data-plus>累加\n                    </label>\n                </div>\n                ';
};
__p += '\n            </div>\n            ';
 var isLock = (field_json.must == undefined || field_json.must) ? 'lock' : 'unlock'; ;
__p += '\n\n            <div class="pull-right checkbox qr-check-must ' +
((__t = ( isLock)) == null ? '' : __t) +
'">\n                <a href="javascript:;" class="qr-ismust-icon"></a>\n\n            </div>\n        </div>\n    </div>\n    ';
if (obj.index !== 1) {;
__p += '\n        <div class="qr-condition-delete pull-left">\n            <span class="glyphicon glyphicon-minus-sign"></span>\n        </div>\n    ';
};
__p += '\n</div>\n';
return __p
}({
                    index: i + 1,
                    field_json_item: json[i]
                });
            }
            $('.qr-conditions-wrapper').html(html);
            if ($('.qr-conditions-wrapper .qr-con-addition').length) {
                $('.qr-conditions-wrapper .qr-set-condition').addClass('qr-multiple');
            }
            // initSetFilterEvent();
            initConditionSelect($('.qr-condition-select'), data);
        });
    }
    // 获取筛选项详情
    function getFilterDetail(obj, $target) {
        window.qr.ajax({
            url: '/interest_graphs/shuqi_toufang/get_field/',
            // url: '/page/quanren/getfield.json',
            data: {
                field_id: obj.id
            },
            success: function (data) {
                var type = showFilterDetail;

                if (!data.field_json) {
                    if ($target.closest('.qr-list-wrapper').attr('id') == 'qr-list-show') {
                        window.qr.tips({
                            text: '此模块项未经过配置，详情展示失败',
                            type: 'worn'
                        });
                        return;
                    }
                    window.qr.tips({
                        text: '此模块项未配置，请先进行配置!',
                        type: 'worn'
                    });
                    type = setFilterDetail;
                }
                type({
                    name: obj.name,
                    data: data,
                    field_id: obj.id
                });
            }
        });
    }
    // 获取圈人条件
    function getQueryValues($scope) {
        var values = [];

        $scope.find('[data-containertype]').each(function (index, ele) {
            var type = $(ele).data('containertype');

            switch (type) {
                case 1:
                    values.push(($(ele).find('select').val() || []).join(','));
                    break;
                case 7:
                    values.push($(ele).find('select').val() || '');
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                    var dates = [];

                    $(ele).find('input[data-qrinput]').each(function (index, ele) {
                        var date = $(ele).val();

                        switch ($(ele).data('datetype')) {
                            case 'month':
                                date += '-01';
                                break;
                        }
                        dates.push(date + ' 00:00:00');
                    });
                    values.push(dates.join(','));
                    break;
                default:
                    var inputs = [];

                    $(ele).find('input[data-qrinput]').each(function (index, ele) {
                        inputs.push($(ele).val());
                    });
                    values.push(inputs.join(','));
                    break;
            }
        });
        return values;
    }
    function getTotalNum(obj) {
        var queryJson = JSON.stringify(obj.query);
        var loadingstatus = false;

        !loadingstatus && window.qr.ajax({
            url: '/interest_graphs/shuqi_toufang/circl_people/',
            data: {
                table_id: lc.table_id,
                query_json: queryJson
            },
            beforeSend: function () {
                loadingstatus = true;
                obj.$target.addClass(loading);
            },
            success: function (data) {
                obj.$scope.find('[data-totalnum]').html(data.num);
                if (obj.cb && typeof obj.cb == 'function') {
                    lc.sql = data.sql;
                    obj.cb.apply(null, [{
                        query_json: queryJson,
                        people_num: data.num,
                        table_id: lc.table_id
                    }]);
                }
            },
            complete: function () {
                loadingstatus = false;
                obj.$target.removeClass(loading);
            }
        });
    }
    function initDatePicker($target) {
        var $dates = $target.find('[data-datetype]');
        var $start = $dates.eq(0) || null;
        var $end = $dates.eq(1) || null;

        if (!$start) {
            return;
        }

        switch ($start.data('datetype')) {
            case 'month':
                var onChange = function (dp, $input) {
                    $input.datetimepicker({
                        value: dp
                    });
                };
                var monformat = 'YYYY-MM';

                $start.datetimepicker({
                    timepicker: false,
                    format: monformat,
                    validateOnBlur: true,
                    scrollInput: false,
                    allowDates: ['9999-12-32'],
                    onGenerate: function () {
                        setDateFormatter(monformat);
                    },
                    onChangeMonth: function (dp, $input) {
                        onChange(dp, $input);
                    },
                    onChangeYear: function (dp, $input) {
                        onChange(dp, $input);
                    },
                    onShow: function () {
                        this.setOptions({
                            maxDate: $end.val() ? $end.val() : false
                        });
                    }
                });
                $end && $end.datetimepicker({
                    timepicker: false,
                    format: monformat,
                    scrollInput: false,
                    validateOnBlur: true,
                    allowDates: ['9999-12-32'],
                    onGenerate: function () {
                        setDateFormatter(monformat);
                    },
                    onChangeMonth: function (dp, $input) {
                        onChange(dp, $input);
                    },
                    onChangeYear: function (dp, $input) {
                        onChange(dp, $input);
                    },
                    onShow: function () {
                        this.setOptions({
                            minDate: $start.val() ? $start.val() : false
                        });
                    }
                });
                break;
            case 'day':
                var dayformat = 'YYYY-MM-DD';

                $start.datetimepicker({
                    timepicker: false,
                    format: dayformat,
                    scrollInput: false,
                    onGenerate: function () {
                        setDateFormatter(dayformat);
                    },
                    onShow: function () {
                        this.setOptions({
                            maxDate: $end.val() ? $end.val() : false
                        });
                    }
                });
                $end && $end.datetimepicker({
                    timepicker: false,
                    format: dayformat,
                    scrollInput: false,
                    onGenerate: function () {
                        setDateFormatter(dayformat);
                    },
                    onShow: function () {
                        this.setOptions({
                            minDate: $start.val() ? $start.val() : false
                        });
                    }
                });
                break;
        }
    }
    function setDateFormatter(newformat) {
        $.datetimepicker.setDateFormatter({
            parseDate: function (date, format) {
                var d = qr.moment(date, newformat);

                return d.isValid() ? d.toDate() : false;
            },
            formatDate: function (date, format) {

                return qr.moment(date).format(newformat);
            }
        });
    }
    function setQueryValues($scope, valueList) {

        $scope.find('[data-containertype]').each(function (index, ele) {
            var type = $(ele).data('containertype');
            var value = valueList[index];

            switch (type) {
                case 0:
                    $(ele).find('input').importTags(value);
                    break;
                case 1:
                case 7:
                    var values = value.split(',');

                    for (var i = 0, ilen = values.length; i < ilen; i++) {
                        $(ele).find('select').val(values[i]).trigger('change');
                    }
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                    var datevalues = value.split(',');

                    $(ele).find('input[data-qrinput]').each(function (index, ele) {
                        $(ele).data('qrinput', datevalues[index]);
                        $(ele).val(datevalues[index]);
                    });
                    break;
                default:
                    var invalues = value.split(',');

                    $(ele).find('input[data-qrinput]').each(function (index, ele) {
                        $(ele).val(invalues[index]);
                    });
                    break;
            }
        });
    }
    // 初始化form组件
    function initInputs(type, $scope) {
        switch (type) {
            case 0:
                $scope.find('.qr-inputtags').tagsInput({
                    defaultText: '输入值'
                });
                break;
            case 1:
            case 7:
                var $select = $scope.find('select');

                if ($select.data('ismust')) {
                    $select.select2({
                        placeholder: '请选择'
                    });
                } else {
                    $select.select2({
                        placeholder: '请选择',
                        allowClear: true
                    });
                }

                $select
                    .on('select2:selecting', function () {
                        var value = $(this).val() || [];
                        var index = value.indexOf('全选');

                        if (index !== -1) { // 存在全选则清空
                            $(this).val(null).trigger('change');
                        }
                    })
                    .on('select2:select', function () {
                        var value = $(this).val() || [];
                        var index = value.indexOf('全选');

                        if (index !== -1) { // 存在全选则过滤
                            $(this).val(value[index]).trigger('change');
                        }
                    });
                break;
            case 3:
            case 4:
            case 5:
            case 6:
                initDatePicker($scope);
                break;
        }
        // $('.qr-preview .form-inputs-row').each(function (index, ele) {
        //     (function ($ele){
        //         initDatePicker($ele);
        //     })($(ele));
        // });
        // // $('.qr-preview select').each(function (index, ele) {
        // //     $(ele).select2({
        // //         placeholder: '请选择'
        // //     });
        // //     $(ele)
        // //         .on('select2:selecting', function () {
        // //             var value = $(this).val() || [];
        // //             var index = value.indexOf('全选');

        // //             if (index !== -1) { // 存在全选则清空
        // //                 $(this).val(null).trigger('change');
        // //             }
        // //         })
        // //         .on('select2:select', function () {
        // //             var value = $(this).val() || [];
        // //             var index = value.indexOf('全选');

        // //             if (index !== -1) { // 存在全选则过滤
        // //                 $(this).val(value[index]).trigger('change');
        // //             }
        // //         });
        // // });
        // $('.qr-preview .qr-inputtags').each(function (index, ele) {
        //     $(ele).tagsInput({
        //         defaultText: '添加默认值'
        //     });
        // });
    }
};

function change_page_toufang(group_id, cid, sql) {
    $.extend({
        StandardPost: function (url, args) {
            var form = $("<form method='post'></form>"),
            input;
            form.attr({ "action": url });
            $.each(args, function (key, value) {
                input = $("<input type='hidden'>");
                input.attr({ "name": key });
                input.val(value);
                form.append(input);
            });
            form.submit();
        }
    });

    $.StandardPost('http://106.11.148.15:8003/launching_platform/#/profiles/detail/', { group_id: group_id, cid: cid, sql: sql });
}
