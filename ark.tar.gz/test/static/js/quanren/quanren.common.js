(function (win){
    var qr = {
        ajax: function (opt) {
            $.ajax({
                url: opt.url,
                type: 'post',
                dataType: 'json',
                async: opt.async || true,
                data: $.extend({}, opt.data) || {},
                beforeSend: function () {
                    opt.beforeSend && typeof (opt.beforeSend) == 'function' && opt.beforeSend.apply();
                },
                success: function (data) {
                    if (!data.status) { // 接口正常
                        // if (data.data) { // 正常返回数据
                        opt.success && typeof (opt.success) == 'function' && opt.success.apply(this, [data.data]);
                        // } else {
                        //     opt.error && typeof (opt.error) == 'function' && opt.error.apply(this, [data.data]);
                        // }

                    } else { // 接口错误
                        window.qr.tips({
                            text: data.msg
                        });

                        opt.error && typeof (opt.error) == 'function' && opt.error.apply(this, [data]);
                    }
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) { // 请求失败
                    window.qr.tips({
                        text: '请检查请求参数或网络是否正常～'
                    });

                    opt.error && typeof (opt.error) == 'function' && opt.error.apply();
                },
                complete: function () {
                    opt.complete && typeof (opt.complete) == 'function' && opt.complete.apply();
                }
            });
        },
        tips: function (obj) {
            if (obj.type == 'success') {
                obj.title = '操作成功';
            }
            new PNotify($.extend({
                title: '操作失败!',
                text: '操作失败',
                type: 'error',
                styling: 'bootstrap3'
            }, obj));
        }
    };
    qr.moment = window.moment;
    win.qr = qr;
    $('body').on('hidden.bs.modal', '#qr-modal', function (e) {
        $('#qr-modal').remove();
    });
})(window);
