var choosevalue = 0;
var table_task_list = null;

$(function(){
    $('.changevalue').on('click',function(){
        choosevalue=1;
        $('#modalcheck').modal('hide');
    });

    init_task_list();
    setInterval( function(){refresh_table();}, 60000);
    run_history_table_init();
    $(document).on('change', "#autorunConfigModal #autorun_type", function(){
        if($(this).val() == 0)
        {
            $("#autorun_runtime").parent().html('<input type="text" class="form-control" id="autorun_runtime" value="1" placeholder="运行时间">');
            $("#autorun_runtime").datetimepicker('refresh');
            $("#autorun_runtime").datetimepicker({
                format:'H:i',
                showMinute:false,
                datepicker:false,
                language:'ch',
                step:1, 
            });
        }
        else
        {
            var html = '<select id="autorun_runtime" class="form-control">';
            for(var i=0;i<60;i++)
            {
                var str_display = i<10 ? '0'+i : i;
                html += '<option value="'+str_display+'">'+str_display+'分</optuion>';
            }
            html += '</select>';
            $("#autorun_runtime").parent().html(html);
            $("#autorun_runtime").datetimepicker('destroy');
        }
    });
    $("#switch_task_type a").on('click', function(){
        if(!$(this).hasClass('active'))
        {
            $("#switch_task_type a").removeClass('active');
            $(this).addClass('active');
            refresh_table(true);
        }
    });
});

var id_mapping_id = 0;
var run_his_table = null;
function show_runhistory(id) {
    id_mapping_id = id;
    $('#run_history_dlg').modal('show');
    url = "/id_mapping/show_run_history/";
    run_his_table.ajax.url(url).load();
}

function init_task_list()
{
    table_task_list = $('#table_task_list').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
         "ajax": {
               "url": "/id_mapping/show_id_mapping_list/",
               "type": "POST",
               "data": function(d){
                    d.auto_run_tag=$("#switch_task_type a.active").attr('action-data');
                },
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "显示 _MENU_ 条记录",
            "sInfo": "显示第 _START_ 至 _END_ 条记录，共 _TOTAL_ 条",
            "sInfoEmpty": "显示第 0 至 0 条记录，共 0 条",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
         {
            data: "no",
            bSortable: false
        }, {
            data: "input_table",
            bSortable: false
        }, {
            data: "input_id_type",
            bSortable: false
        }, {
            data: "output_table",
            bSortable: false
        }, {
            data: "output_id_type",
            bSortable: false
        }, {
            data: "is_auto_schedule",
            bSortable: false
        }, {
            data: "run_status",
            bSortable: false
        }, {
            data: "create_time",
            bSortable: false
       }],

        "columnDefs": [
        {
           "targets":[1,3],
            "render":function(data,type,full){
                return '<a href="javasciipt:void(0)" title="点击查看详情" onclick="show_all_text(this)">'+data+'</a>';
            },
        },{
           "targets":[5],
            "render":function(data,type,full){
                if(data == 0)
                {
                    return '<a href="javasciipt:void(0)" title="点击开启自动调度" data-action="'+full.id+'" style="margin-left: 10px;" onclick="config_autorun_info('+full.id+')"><img src="/static/images/id_mapping/autorun_no.png"></img></a>';
                }
                else
                {
                    return '<a href="javasciipt:void(0)" title="点击关闭自动调度" data-action="'+full.id+'" style="margin-left: 10px;" onclick="cancel_autorun('+full.id+')"><img src="/static/images/id_mapping/autorun_yes.png"></img></a>';
                }
            },
        },{
           "targets":[6],
            "render":function(data,type,full){
                var html = '';
                var html_text = '';
                var html_text_color = '';
                var html_progress_color = '';
                var html_progress_value = 0;
                if(full.run_status == -1)
                {
                    html_text = '失败';
                    html_text_color = 'red';
                    html_progress_color = 'red';
                    html_progress_value = 100;
                }
                else if(full.run_status == 100)
                {
                    html_text = '成功';
                    html_text_color = 'green';
                    html_progress_color = 'green';
                    html_progress_value = full.run_status;
                }
                else if(full.run_status == 101)
                {
                    html_text = '未执行';
                    html_text_color = 'black';
                    html_progress_color = '#F90';
                    html_progress_value = 0;
                }
                else 
                {
                    html_text = full.run_status+'%';
                    html_text_color = 'black';
                    html_progress_color = '#F90';
                    html_progress_value = full.run_status;
                }
                html = '<span style="width:44px;position:absolute;text-align:right;cursor:pointer" onclick="show_runhistory(' + full.id +');" title="点击查看执行历史"><a href="#" style="color:'+html_text_color+';" onclick="show_runhistory(' + full.id +');">'+html_text+'</a></span>';
                html += '<a href="#"><div class="status_progress_div" onclick="show_runhistory(' + full.id +');" title="点击查看执行历史"><span class="status_progress_span" style="width:'+html_progress_value+'%;background-color:'+html_progress_color+'"></span></div></a>';
                return html;
            }
        },{
           "targets":[8],
            "render":function(data,type,full){
                var html = '<a href="/id_mapping/update_task/?id='+full.id+'">编辑</a>';
                if(full.run_status > -1 && full.run_status < 101)
                {
                    html += '<a href="javascript:void(0)" style="margin: 0 10px;" onclick="index_stop_task('+full.id+')">停止</a>';
                }
                else
                {
                    html += '<a href="javascript:void(0)" style="margin: 0 10px;" onclick="index_start_task('+full.id+')">执行</a>';
                }
                html += '<a href="javascript:void(0)" onclick="delete_task('+full.id+')">删除</a>';
                return html;
            }
        }]
    });
}
function config_autorun_info(id)
{
    var html = '<div class="row">\
            <div class="col-md-2" style="text-align: right;">调度时间</div>\
            </div>';
    var html = '<form class="form-inline" style="text-align:center;">\
                  <div class="form-group">\
                    <label style="font-weight: normal;margin-right: 10px;">调度时间</label>\
                    <select class="form-control" id="autorun_type">\
                        <option value="0">每天</option>\
                        <option value="1">每小时</option>\
                    </select>\
                  </div>\
                  <div class="form-group">\
                    <input type="text" class="form-control" id="autorun_runtime" placeholder="运行时间">\
                  </div>\
                  <div class="form-group">\
                    <input type="number" min="0" class="form-control" id="autorun_offset" value="1" placeholder="偏移时间">\
                    <img data-toggle="tooltip" data-placement="bottom" title="偏移时间：单位：天，‘1’即使用调度时间1天前的数据，‘2’即使用调度时间2天前的任务，以此类推，默认为1" src="/static/images/id_mapping/tip_incon.png"></img>\
                  </div>\
                </form>';
    $("#autorunConfigModal .modal-body").html(html);
    $("[data-toggle='tooltip']").tooltip();
    $("#autorun_runtime").datetimepicker({
        format:'H:i',
        showMinute:false,
        datepicker:false,
        language:'ch',
        step:1, 
    });
    $("#btn_do_autorun_config").off('click');
    $("#btn_do_autorun_config").on('click', function(){
        $(this).button('loading');
        var url = '/id_mapping/create_auto_schedule/';
        var post_data = get_autorun_config_data();
        post_data['id'] = id;
        var callback = callback_do_autorun_config;
        var args = {id:id};
        makeAPost(url, post_data, true, callback, args);
    });
    $("#autorunConfigModal").modal('show');
}
function callback_do_autorun_config(result, args)
{
    $("#btn_do_autorun_config").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $('#table_task_list tbody td>a[data-action="'+args['id']+'"]').parent().html('<a href="javasciipt:void(0)" title="点击关闭自动调度" data-action="'+args.id+'" style="margin-left: 10px;" onclick="cancel_auto('+args.id+')"><img src="/static/images/id_mapping/autorun_yes.png"></img></a>');
        $("#autorunConfigModal").modal('hide');
    }
}
function cancel_autorun(id)
{
    $("#btn_cancel_autorun").off('click');
    $("#btn_cancel_autorun").on('click', function(){
        $(this).button('loading');
        var url = '/id_mapping/stop_auto_schedule/';
        var post_data = {id:id};
        var callback = callback_do_cancel_autorun;
        var args = {id:id};
        makeAPost(url, post_data, true, callback, args);
    });
    $("#cancelAutorunConfirmModal").modal('show');

}
function callback_do_cancel_autorun(result, args)
{
    $("#btn_cancel_autorun").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $('#table_task_list tbody td>a[data-action="'+args['id']+'"]').parent().html('<a href="javasciipt:void(0)" title="点击关闭自动调度" data-action="'+args.id+'" style="margin-left: 10px;" onclick="config_autorun_info('+args.id+')"><img src="/static/images/id_mapping/autorun_no.png"></img></a>');
        $("#cancelAutorunConfirmModal").modal('hide');
    }
}
function get_autorun_config_data()
{
    var post_data = {};
    post_data['type'] = $("#autorun_type").val();
    post_data['runtime'] = $("#autorun_runtime").val();
    post_data['offset'] = $("#autorun_offset").val();
    return post_data;
}
function index_start_task(task_id) 
{
    $("#runTaskConfirmModal #btn_run_task").off('click');
    $("#runTaskConfirmModal #btn_run_task").on('click', function(){
        $(this).button('loading');
        var url = '/id_mapping/run_task/';
        var post_data = {};
        post_data['id'] = task_id;
        var callback = callback_index_start_task;
        var args = {id:task_id};
        makeAPost(url, post_data, true, callback, args);
    });
    $("#runTaskConfirmModal").modal('show');
}
function callback_index_start_task(result, args)
{
    $("#runTaskConfirmModal #btn_run_task").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#runTaskConfirmModal").modal('hide');
        refresh_table();
    }
}
function index_stop_task(task_id) 
{
    $("#stopTaskConfirmModal #btn_stop_task").off('click');
    $("#stopTaskConfirmModal #btn_stop_task").on('click', function(){
        $(this).button('loading');
        var url = '/id_mapping/stop_task/';
        var post_data = {};
        post_data['id'] = task_id;
        var callback = callback_index_stop_task;
        var args = {id:task_id};
        makeAPost(url, post_data, true, callback, args);
    });
    $("#stopTaskConfirmModal").modal('show');
}
function callback_index_stop_task(result, args)
{
    $("#stopTaskConfirmModal #btn_stop_task").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#stopTaskConfirmModal").modal('hide');
        refresh_table();
    }
}
function run_task(busy_id, id, run_time, auto) {
    $('#modalcheck').unbind('hide.bs.modal');
    $('#modalcheck .modal-body h5').text('确定要重跑吗?');
    $('.changevalue').text('确定');
    $('#modalcheck').modal('show');
    choosevalue = 0;
    $('#modalcheck').on('hide.bs.modal',function (){
        if(choosevalue==1){
            if (busy_id >= 0) {
                $('#new_busy_icon_' + busy_id).show()
            }
            var url = '/id_mapping/run_task/';
            var post_data = {'id':id, 'run_time': run_time, 'auto': auto};
            var args = {'busy_id':busy_id};
            var result = makeAPost(url, post_data, true, run_task_call_back, args);
        }
    });
}

function run_task_call_back(result, args) {
        if (args.busy_id >= 0) {
            $('#new_busy_icon_' + args.busy_id).hide()
        }
        if(result.status == 0)
        {
            url = "/id_mapping/show_run_history/";
            run_his_table.ajax.url(url).load();
        } else {
            ark_notify(result);
        }
}

function stop_task(busy_id, id, run_time, auto) {
    $('#modalcheck').unbind('hide.bs.modal');
    $('#modalcheck .modal-body h5').text('确定要停止吗?');
    $('.changevalue').text('确定');
    $('#modalcheck').modal('show');
    choosevalue = 0;
    $('#modalcheck').on('hide.bs.modal',function (){
        if(choosevalue==1){
            if (busy_id >= 0) {
                $('#new_busy_icon_' + busy_id).show()
            }
            var url = '/id_mapping/stop_task/';
            var post_data = {'id':id, 'run_time': run_time, 'auto': auto};
            var args = {'busy_id':busy_id};
            var result = makeAPost(url, post_data, true, stop_task_call_back, args);
        }
    });
}

function stop_task_call_back(result, args) {
    if (args.busy_id >= 0) {
        $('#new_busy_icon_' + args.busy_id).hide()
    }

    if(result.status == 0)
    {
        url = "/id_mapping/show_run_history/";
        run_his_table.ajax.url(url).load();
    } else {
        ark_notify(result);
    }
}

function get_error_log(id, run_time, auto) {
    var url = '/id_mapping/get_error_log/';
    var post_data = {'id':id, 'run_time': run_time, 'auto': auto};
    var result = makeAPost(url, post_data, false);
    if (result.status == 0) {
        $('#error_log_view').unbind('hide.bs.modal');
        $("#error_log_area").find("textarea").val(result.msg);
        $('#error_log_view').modal('show');
    } else {
        ark_notify(result);
    }
}

function run_history_table_init() {
    run_his_table = $('#run_history_table').DataTable({
        "bDestroy":true,
        "processing": true,
        "serverSide": true,
        "searching": false,
        "ajax": {
            "url": "/id_mapping/show_run_history/",
            "type": "POST",
            "data": function ( d ) {
                d.id = id_mapping_id;
            }
        },
        "pageLength":10,
        "lengthChange": false,
        "language":{
            "sLengthMenu": "",
            "sInfo": "",
            "sInfoEmpty": "",
            "zeroRecords": '暂无结果',
            "paginate":{
                'next':'下一页',
                'previous':'上一页',
            },
        },
        columns: [
        {
            data: "no",
            bSortable: false
        }, {
            data: "run_time",
            bSortable: false
        }, {
            data: "status",
            bSortable: false
        }, {
            data: "auto",
            bSortable: false
        }, {
            data: "start_time",
            bSortable: false
        }, {
            data: "status",
            bSortable: false
        }],
                
        "columnDefs": [
            {
                "targets":[2],
                "render":function(data,type,full){
                    if(data == 0)
                    {
                        return '<font style="color:rgb(255,153,0)">正在执行</font>';
                    }
                    else if(data == 1)
                    {
                        return '<font style="color:rgb(255,153,0)">正在执行</font>';
                    }
                    else if(data == 2)
                    {
                        return '<font style="color:rgb(0,153,0)">执行成功</font>';
                    }
                    else if(data == 3)
                    {
                        return '<font style="color:rgb(234,0,0)">执行失败</font>';
                    }
                    else if(data == 5)
                    {
                        return '<font style="color:rgb(255,153,0)">正在执行</font>';
                    }
                    else if(data == 6)
                    {
                        return '<font style="color:rgb(0,0,0)">用户停止</font>';
                    }
                    else {
                        return '<font style="color:rgb(255,153,0)">正在执行</font>';
                    }
                },
            },
            {
                "targets":[3],
                "render":function(data,type,full){
                    if(data == 0)
                    {
                        return '手动';
                    }
                    else if(data == 1)
                    {
                        return '自动';
                    }
                },
            },
            {
                "targets":[4],
                "render":function(data,type,full){
                    return data;
                },
            },
            {
                "targets":[5],
                "render":function(data,type,full){
                    if(full.status == 0)
                    {
                        return '<img id="new_busy_icon_' + full.no + '" src="/static/images/busy.gif" style="display:none;float:left;" >&nbsp;&nbsp;<a href="#" onclick="stop_task('+ full.no + ',' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">停止</a>';
                    }
                    else if(full.status == 1)
                    {
                        return '<img id="new_busy_icon_' + full.no + '" src="/static/images/busy.gif" style="display:none;float:left;">&nbsp;&nbsp;<a href="#" onclick="stop_task('+ full.no + ',' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">停止</a>';
                    }
                    else if(full.status == 2)
                    {
                        return '<img id="new_busy_icon_' + full.no + '" src="/static/images/busy.gif" style="display:none;float:left;">&nbsp;&nbsp;<a href="#" onclick="run_task('+ full.no + ',' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">重跑</a>' 
                    }
                    else if(full.status == 3)
                    {
                        return '<img id="new_busy_icon_' + full.no + '" src="/static/images/busy.gif" style="display:none;float:left;">&nbsp;&nbsp;<a href="#" onclick="run_task('+ full.no + ',' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">重跑</a>' + '&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" onclick="get_error_log(' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">日志</a>';
                    }
                    else if(full.status == 5)
                    {
                        return '<img id="new_busy_icon_' + full.no + '" src="/static/images/busy.gif" style="display:none;float:left;">&nbsp;&nbsp;<a href="#" onclick="stop_task('+ full.no + ',' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">停止</a>';
                    }
                    else if(full.status == 6)
                    {
                        return '<img id="new_busy_icon_' + full.no + '" src="/static/images/busy.gif" style="display:none;float:left;">&nbsp;&nbsp;<a href="#" onclick="run_task('+ full.no + ',' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">重跑</a>'
                    }
                    else {
                        return '<img id="new_busy_icon_' + full.no + '" src="/static/images/busy.gif" style="display:none;float:left;">&nbsp;&nbsp;<a href="#" onclick="stop_task('+ full.no + ',' + id_mapping_id + ',' + full.run_time + ',' + full.auto + ');">停止</a>';
                    }
                },
            },
        ]

    });
}
function delete_task(task_id)
{
    $("#deleteTaskConfirmModal #btn_delete_task").off('click');
    $("#deleteTaskConfirmModal #btn_delete_task").on('click', function(){
        $(this).button('loading');
        delete_id_mapping(task_id);
    });
    $("#deleteTaskConfirmModal").modal('show');
}
function delete_id_mapping(task_id)
{
    var url = '/id_mapping/delete_id_mapping/';
    var post_data = {};
    post_data['id'] = task_id;
    var callback = callback_delete_id_mapping;
    var args = {id:task_id};
    makeAPost(url, post_data, true, callback, args);
}
function callback_delete_id_mapping(result, args)
{
    $("#deleteTaskConfirmModal #btn_delete_task").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        $("#deleteTaskConfirmModal").modal('hide');
        refresh_table();
    }
}
function refresh_table(force)
{
    force = force ? true : false;
    if(table_task_list)
    {
        table_task_list.ajax.reload(null, force);
        //var oSettings = table_task_list.fnSettings();
        //var iPage = oSettings._iDisplayStart>0 ? oSettings._iDisplayStart/oSettings._iDisplayLength : 0;
        //table_task_list.fnPageChange(iPage, true);
    }
}
function show_all_text (obj)
{
    $("#fullTextModal .modal-body p").html($(obj).html());
    $("#fullTextModal").modal('show');
}
