cols_checked_history = {};
modal_ok_clicked_flag = false;
$(function(){
    if($("#btn_update_id_mapping").length > 0)//编辑操作
    {
        init_task_detail();
        $("#output_cols").on('click', function(){
            show_output_cols(callback_show_output_cols_update);
        });
    }
    else
    {
        $("#output_cols").on('click', function(){
            show_output_cols(callback_show_output_cols);
        });
    }
    $('#schemaColSelectModal').on('hidden.bs.modal', function (e) {
        if(!modal_ok_clicked_flag)
        {
            restore_cols_checked_history();
        }
        modal_ok_clicked_flag = false;
    })
    $("#access_key_eye").on('click', function(){
        if($("#access_key").attr('type') == 'text')
        {
            $(this).attr('src', '/static/images/id_mapping/eye_close.png');
            $("#access_key").attr('type', 'password');
        }
        else
        {
            $(this).attr('src', '/static/images/id_mapping/eye_open.png');
            $("#access_key").attr('type', 'text');
        }
    });
});
function show_output_cols(callback)
{
    if($("#table_fields_list").children().length > 0)
    {
        $('#schemaColSelectModal').modal('show');
        return;
    }
    if($("#input_table").val().trim() == '')
    {
        ark_notify({status:1,'msg':'请填写输入表名'});
        return;
    }
    $("#output_cols").button('loading');
    var url = '/id_mapping/get_odps_table_schema/';
    var odps_project = $("#input_project").val().trim();
    var table = $("#input_table").val().trim();
    var access_id = $("#access_id").val().trim();
    var access_key = $("#access_key").val().trim();
    var output_project = $("#output_project").val().trim();
    var post_data = { 'odps_project': odps_project, 'table': table, 'access_id': access_id, 'access_key': access_key, 'out_odps_project': output_project };
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_show_output_cols_update(result, args)
{
    $("#output_cols").button('reset');
    if(result.status == 0)
    {
        var html = '';
        for(var i in result.field_list)
        {
            if(result.field_list[i].is_part == 1)
            {
                continue;
            }
            var checked_str = (task_info.output_col_list == '' || task_info.output_col_list.split(',').indexOf(result.field_list[i].field_name) > -1) ? 'checked' : '';
            html += '<tr>\
                        <td>\
                            <input type="checkbox" '+checked_str+' onchange="single_filed_change(this)" name="checkbox_output_col" value="'+result.field_list[i].field_name+'">\
                        </td>\
                        <td>'+(parseInt(i)+1)+'</td>\
                        <td>'+result.field_list[i].field_name+'</td>\
                        <td>'+result.field_list[i].type+'</td>\
                        <td>'+result.field_list[i].desc+'</td>\
                    </tr>';
        }
        $("#table_fields_list").html(html);
        $("#allChooseCheckbox").prop('checked', ($("#table_fields_list input[name='checkbox_output_col']:not(:checked)").length > 0) ? false : true);
    }
    get_cols_checked_history();
    $('#schemaColSelectModal').modal('show');
}
function callback_show_output_cols(result, args)
{
    $("#output_cols").button('reset');
    if(result.status == 0)
    {
        var html = '';
        for(var i in result.field_list)
        {
            if(result.field_list[i].is_part == 1)
            {
                continue;
            }
            html += '<tr>\
                        <td>\
                            <input type="checkbox" checked onchange="single_filed_change(this)" name="checkbox_output_col" value="'+result.field_list[i].field_name+'">\
                        </td>\
                        <td>'+(parseInt(i)+1)+'</td>\
                        <td>'+result.field_list[i].field_name+'</td>\
                        <td>'+result.field_list[i].type+'</td>\
                        <td>'+result.field_list[i].desc+'</td>\
                    </tr>';
        }
        $("#table_fields_list").html(html);
    }
    get_cols_checked_history();
    $('#schemaColSelectModal').modal('show');
}
function update_output_cols()
{
    var output_col_list = [];
    var cols_selected = $("#table_fields_list input[name='checkbox_output_col']:checked");
    for(var i=0; i < cols_selected.length; i++)
    {
        output_col_list.push(cols_selected[i].value.trim());
    }
    if(output_col_list.length>0)
    {
        $("#cols_show_str").html('已选择 <font color=red>'+output_col_list.length+'</font> 项:'+output_col_list.join(','));
        $("#cols_show_str").css('color', 'black');
        $("#cols_show_str").attr('title', output_col_list.join(', '));
    }
    else
    {
        $("#cols_show_str").html('不选默认输出原表全部列');
        $("#cols_show_str").css('color', 'red');
        $("#cols_show_str").attr('title', '');
    }
    modal_ok_clicked_flag = true;
    get_cols_checked_history();
    $('#schemaColSelectModal').modal('hide');
}
function clean_schema()
{
    $("#table_fields_list").html('');
}
function create_id_mapping()
{
    $("#btn_create_id_mapping").button('loading');
    var url = '/id_mapping/create_task/';
    var post_data = get_post_data();
    var callback = callback_create_id_mapping;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_create_id_mapping(result, args)
{
    $("#btn_create_id_mapping").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        window.location = '/id_mapping/index/';
    }
}
function update_id_mapping()
{
    $("#btn_update_id_mapping").button('loading');
    var url = '/id_mapping/update_task/';
    var post_data = get_post_data();
    post_data['id'] = task_info.id;
    var callback = callback_update_id_mapping;
    var args = {};
    makeAPost(url, post_data, true, callback, args);
}
function callback_update_id_mapping(result, args)
{
    $("#btn_update_id_mapping").button('reset');
    ark_notify(result);
    if(result.status == 0)
    {
        window.location = '/id_mapping/index/';
    }
}
function get_post_data()
{
    var odps_account = $("#cloud_account").val().trim();
    var odps_id = $("#access_id").val().trim();
    var odps_key = $("#access_key").val().trim();
    var input_project = $("#input_project").val().trim();
    var input_table = $("#input_table").val().trim();
    var input_part = $("#input_partition").val().trim();
    var input_id_col_name = $("#input_col").val().trim();
    var input_id_type = $("#input_col_type").val().trim();
    var output_project = $("#output_project").val().trim();
    var output_table = $("#output_table").val().trim();
    var output_part = $("#output_partition").val().trim();
    var output_id_type = $("#output_id").val().trim();
    var output_col_list = [];
    var cols_selected = $("#table_fields_list input[name='checkbox_output_col']:checked");
    for(var i=0; i < cols_selected.length; i++)
    {
        output_col_list.push(cols_selected[i].value.trim());
    }
    
    var post_data = {};
    post_data['odps_account'] = odps_account;
    post_data['odps_id'] = odps_id;
    post_data['odps_key'] = odps_key;
    post_data['input_project'] = input_project;
    post_data['input_table'] = input_table;
    post_data['input_part'] = input_part;
    post_data['input_id_col_name'] = input_id_col_name;
    post_data['input_id_type'] = input_id_type;
    post_data['output_project'] = output_project;
    post_data['output_table'] = output_table;
    post_data['output_part'] = output_part;
    post_data['output_id_type'] = output_id_type;
    if(output_col_list.length >0)
    {
        post_data['output_col_list'] = output_col_list.join(',');
    }

    return post_data;
}
function choose_all(obj)
{
    var value = $(obj).is(':checked');
    $("#table_fields_list input[name='checkbox_output_col']").each(function(){
        $(this).prop('checked', value);
    });
}
function single_filed_change(obj)
{
    var value = $(obj).is(':checked');
    if(value == false)
    {
        $("#allChooseCheckbox").prop('checked', false);
    }
    else
    {
        if($("#table_fields_list input[name='checkbox_output_col']:not(:checked)").length > 0)
        {
            $("#allChooseCheckbox").prop('checked', false);
        }
        else
        {
            $("#allChooseCheckbox").prop('checked', true);
        }
    }
}
function init_task_detail()
{
    //$("#btn_update_id_mapping").on('cilck', function(){
    //    update_id_mapping(task_info.id);
    //});
    $("#cloud_account").val(task_info.odps_account);
    $("#access_id").val(task_info.odps_id);
    $("#access_key").val(task_info.odps_key);
    $("#input_project").val(task_info.input_project);
    $("#input_table").val(task_info.input_table);
    $("#input_partition").val(task_info.input_part);
    $("#input_col").val(task_info.input_id_col_name);
    $("#input_col_type").val(task_info.input_id_type);
    $("#output_project").val(task_info.output_project);
    $("#output_table").val(task_info.output_table);
    $("#output_partition").val(task_info.output_part);
    $("#output_id").val(task_info.output_id_type);
    if(task_info.output_col_list == '')
    {
        $("#cols_show_str").html('已全选');
        $("#cols_show_str").css('color', 'black');
    }
    else
    {
        $("#cols_show_str").html('已选择 <font color=red>'+task_info.output_col_list.split(',').length+'</font> 项:'+task_info.output_col_list);
        $("#cols_show_str").css('color', 'black');
        $("#cols_show_str").attr('title', task_info.output_col_list.split(',').join(', '));
    }
}
function get_cols_checked_history()
{
    cols_checked_history = {};
    cols_checked_history['is_all_choose'] = $("#allChooseCheckbox").prop('checked');
    cols_checked_history['cols_list'] = {};
    $("#table_fields_list input[name='checkbox_output_col']").each(function(){
        var col_name = $(this).val();
        cols_checked_history['cols_list'][col_name] = $(this).prop('checked');
    });
}
function restore_cols_checked_history()
{
    $("#allChooseCheckbox").prop('checked', cols_checked_history.is_all_choose);
    $("#table_fields_list input[name='checkbox_output_col']").each(function(){
        var col_name = $(this).val();
        $(this).prop('checked', cols_checked_history['cols_list'][col_name]);
    });
}
function return_prev_page()
{
    if ((navigator.userAgent.indexOf('MSIE') >= 0) && (navigator.userAgent.indexOf('Opera') < 0)){ // IE
            if(history.length > 0){  
                window.history.go( -1 );  
            }else{  
                window.opener=null;window.close();  
            }  
    }
    else{ //非IE浏览器  
        if (navigator.userAgent.indexOf('Firefox') >= 0 ||  
            navigator.userAgent.indexOf('Opera') >= 0 ||  
            navigator.userAgent.indexOf('Safari') >= 0 ||  
            navigator.userAgent.indexOf('Chrome') >= 0 ||  
            navigator.userAgent.indexOf('WebKit') >= 0){  
    
            if(window.history.length > 1){  
                window.history.go( -1 );  
            }else{  
                window.opener=null;window.close();  
            }  
        }else{ //未知的浏览器  
            window.history.go( -1 );  
        }  
    }
}
