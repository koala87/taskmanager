function auth_manager(project_name, project_id, callback)
{
    var url = '/statistic/get_project_group_info/';
    var post_data = {};
    var group_comments = {0: '普通用户组，自定义对各个报表的权限',
                         1: '管理员组，用户可查看、管理所有报表',
                         2: '只读用户组，用户可查看所有报表',}

    post_data["project_id"] = project_id;
    makeAPost(url, post_data, true, function(data) {
        if(data.status == 0) {
            $("#authConfModal .modal-header h4").html(project_name+'-权限管理');
            $("#authConfModal .modal-body .form-group-user").html('');
            var html = '';
            for(var j=0;j<data.data.length;j++)
            {
                var cur_user_list = {};
                for(var k=0;k<data.data[j].users.length;k++)
                {
                    cur_user_list[data.data[j].users[k].id] = true;
                }

                var group_comment = group_comments[data.data[j].type];
                var op_html = "";
                if(data.data[j].type != 1 && data.data[j].type != 2) {//1管理员组 2只读用户组
                    op_html = '<button type="button" onclick="delete_auth_group('+project_id+','+data.data[j].id+')" class="btn btn-danger" style="float: right;"><i class="fa fa-trash-o"></i>删除</button>\
                                   <button type="button" onclick="edit_auth_group('+project_id+','+data.data[j].id+')" class="btn btn-primary" style="float: right;margin-right: 8px;"><i class="fa fa-edit"></i>编辑</button>';
                }

                html += '<div class="form-group-user" style="margin-bottom: 12px;" action-data="'+data.data[j].id+'">\
                         <label>'+data.data[j].name+'<sup class="fa fa-info-circle" data-toggle="tooltip" data-placement="right" data-original-title="' + group_comment + '"></sup></label>' + op_html + '<select class="select2-select-00 full-width-fix form-control user_group_select2" multiple="multiple" action-data="'+data.data[j].id+'">'
                for(var i=0;i<all_user_list.length;i++)
                {
                    var selected_str = all_user_list[i].id in cur_user_list ? ' selected ' : '';
                    html += '<option value="'+all_user_list[i].id+'"'+selected_str+'>'+all_user_list[i].name+'</option>';
                }
                html +='</select>\</div>';
            }
            $("#authConfModal .modal-body form").prepend(html);
            $("#btn_auth_project").unbind("click").bind("click", function() {
                do_auth_project(project_id, $(this));
            });
            $("#btn_add_group").attr('onclick','add_group("'+project_name+'",'+project_id+')');
            $("#authConfModal").modal('show');
            init_select2_async();
        } else { 
            ark_notify(data);
        }
        callback();
    });
}
function do_auth_project(project_id, btn_save)
{
    var url = '/statistic/update_group_user/';
    var post_data_val = [];
    $("#authConfModal select.user_group_select2").each(function(){
        post_data_val.push(JSON.stringify({'group_id':$(this).attr('action-data'),'user_ids':$(this).val() ? $(this).val() : []}));
    });
    var post_data = {'config':JSON.stringify(post_data_val), 'project_id':project_id};
    btn_save.button("loading");
    makeAPost(url, post_data, true, function(result) {
        btn_save.button("reset");
        ark_notify(result);
        if(result.status == 0) {
            $("#authConfModal").modal('hide');
        }
    });
}
function add_group(project_name, project_id)
{
    var url = "/statistic/report_tree/" + project_id;
    $.post(url, {}, function(data){
        if(data.status == 0)
        {
            var exist_report = false;
            var res_html;
            for(var i=0;i<data.data.length;i++)
            {
                if(data.data[i]['type'] == 'report')
                {
                    exist_report = true;
                    break;
                }
            }
            if(exist_report)
            {
                var html = filterArrayWithHtml(data.data, '#');
                res_html = '<li>\
                                <label class="radio-inline"><span class="glyphicon glyphicon-triangle-bottom" aria-hidden="true"></span>全部</label>\
                                <label class="radio-inline radio-right radio_readwrite">\
                                  <input type="radio" name="inlineRadioOptions_#" id="inlineRadio1" value="1"> 读写\
                                </label>\
                                <label class="radio-inline radio-right radio_readonly">\
                                  <input type="radio" name="inlineRadioOptions_#" id="inlineRadio2" value="0"> 读权限\
                                </label>\
                                <label class="radio-inline radio-right radio_no">\
                                  <input type="radio" name="inlineRadioOptions_#" id="inlineRadio2" value="-1" checked> 无\
                                </label>'+html+'</li>';
            }
            else
            {
                res_html = '<li style="margin-top: 7px;">当前项目下无报表</li>';
            }
            $("#add_group_modal #ul_auth_tree").children().remove();
            $("#add_group_modal #ul_auth_tree").append(res_html);
            $("#add_group_modal .modal-header h4").html(project_name+'-权限管理-添加权限组');
            $("#add_group_modal #btn_do_add_group").attr('onclick','do_add_group('+project_id+')');
            $("#auth_group_name").val('');
            $("#auth_group_desc").val('');
            $('#add_group_modal').modal('show');
        }
        else
        {
            ark_notify(data);
        }
    }, 'json');

}
function do_add_group(project_id)
{
    var url = '/statistic/add_user_group/';
    user_group_upsert(url, project_id, 'add_group_modal');
}
function user_group_upsert(url, project_id, modal_id)
{
    var post_data = {};
    post_data['project_id'] = project_id;
    post_data['name'] = $("#"+modal_id+" #auth_group_name").val().trim();
    post_data['description'] = $("#"+modal_id+" #auth_group_desc").val().trim();
    if($("#group_id_update_group_modal").val().trim())
    {
        post_data['group_id'] = $("#group_id_update_group_modal").val().trim();
    }
    post_data['perms'] = [];
    $("#"+modal_id+" #ul_auth_tree ul:first li").each(function(){
        var id = $(this).attr('action-data');
        var type = $("#"+modal_id+" [name='inlineRadioOptions_"+id+"']:checked").val();
        if(type != -1 && (id.indexOf('report_') >= 0))
        {
            report_id = $(this).attr("action-data-db-id");
            post_data['perms'].push(JSON.stringify({'id':report_id,'type':type}));
        }
    });
    post_data['perms'] = JSON.stringify(post_data['perms']);
    $.post(url, post_data, function(data){
        ark_notify(data);
        if(data.status == 0)
        {
            $("#"+modal_id+"").modal('hide');
            if(modal_id == 'add_group_modal')
            {
                var html = '<div class="form-group-user" style="margin-bottom: 12px;" action-data="'+data.data+'">\
                    <label>'+post_data['name']+'</label>\
                    <button type="button" onclick="delete_auth_group('+project_id+','+data.data+')" class="btn btn-danger" style="float: right;"><i class="fa fa-trash-o"></i>删除</button>\
                    <button type="button" onclick="edit_auth_group('+project_id+','+data.data+')" class="btn btn-primary" style="float: right;margin-right: 8px;"><i class="fa fa-edit"></i>编辑</button>\
                    <select class="select2-select-00 full-width-fix form-control user_group_select2" multiple="multiple" action-data="'+data.data+'">'
                for(var i=0;i<all_user_list.length;i++)
                {
                    html += '<option value="'+all_user_list[i].id+'">'+all_user_list[i].name+'</option>';
                }
                html +='</select>\
                  </div>';
                $(".form-group-add-group").before(html);
                init_select2_async();
            }
            else
            {
                $("#authConfModal .form-group-user[action-data='"+post_data['group_id']+"'] label").html(post_data['name']);
            }
        }
    });
}
function init_add_group_radio()
{
    $(document).on('change', "#ul_auth_tree .radio_readonly", function(){
        $(this).parent().find(".radio_readonly input").prop('checked',true);
        $(this).parent().find(".radio_readwrite input").prop('checked',false);
        $(this).parent().find(".radio_no input").prop('checked',false);
    });
    $(document).on('change', "#ul_auth_tree .radio_readwrite", function(){
        $(this).parent().find(".radio_readwrite input").prop('checked',true);
        $(this).parent().find(".radio_readonly input").prop('checked',false);
        $(this).parent().find(".radio_no input").prop('checked',false);
    });
    $(document).on('change', "#ul_auth_tree .radio_no", function(){
        $(this).parent().find(".radio_no input").prop('checked',true);
        $(this).parent().find(".radio_readwrite input").prop('checked',false);
        $(this).parent().find(".radio_readonly input").prop('checked',false);
    });
}
function delete_auth_group(project_id, group_id)
{
    $("#deleteGroupConfirmModal #btn_do_delete_auth_group").attr('onclick', 'do_delete_auth_group('+project_id+','+ group_id+')');
    $("#deleteGroupConfirmModal").modal('show');
}
function do_delete_auth_group(project_id, group_id)
{
    var url = '/statistic/delete_user_group/';
    var post_data = {'project_id':project_id,'group_id':group_id};
    $.post(url, post_data, function(data){
        ark_notify(data);
        if(data.status == 0)
        {
            $("#deleteGroupConfirmModal").modal('hide');
            $("select[action-data='"+group_id+"']").parent().remove();
        }
    });
}
function edit_auth_group(project_id, group_id)
{
    var url = '/statistic/auth_group_detail/';
    var post_data = {'project_id':project_id,'group_id':group_id};
    $.post(url, post_data, function(data){
        if(data.status == 0)
        {
            var html = filterArrayWithHtml(data.data.reports, '#');
            var res_html = '<li>\
                            <label class="radio-inline"><span class="glyphicon glyphicon-triangle-bottom" aria-hidden="true"></span>全部</label>\
                            <label class="radio-inline radio-right radio_readwrite">\
                              <input type="radio" name="inlineRadioOptions_#" id="inlineRadio1" value="1"> 读写\
                            </label>\
                            <label class="radio-inline radio-right radio_readonly">\
                              <input type="radio" name="inlineRadioOptions_#" id="inlineRadio2" value="0"> 读权限\
                            </label>\
                            <label class="radio-inline radio-right radio_no">\
                              <input type="radio" name="inlineRadioOptions_#" id="inlineRadio2" value="-1" checked> 无\
                            </label>'+html+'</li>';
            $("#update_group_modal #ul_auth_tree").children().remove();
            $("#update_group_modal #ul_auth_tree").append(res_html);
            $("#update_group_modal .modal-header h4").html(data.project_name+'-权限管理-修改权限组');
            $("#update_group_modal #btn_do_add_group").attr('onclick','do_edit_group('+project_id+')');
            $("#update_group_modal #auth_group_name").val(data.data.name);
            $("#update_group_modal #auth_group_desc").val(data.data.description);
            $("#update_group_modal #btn_do_edit_auth_group").attr('onclick', 'do_edit_auth_group('+project_id+','+ group_id+')');
            for(var i=0;i<data.data.reports.length;i++)
            {
                if(data.data.reports[i].perm != null)
                {
                    $('[name="inlineRadioOptions_'+data.data.reports[i].id+'"][value="'+data.data.reports[i].perm+'"]').prop('checked', true);
                }
            }
            $("#update_group_modal").modal('show');
 
        }
        else
        {
            ark_notify(data);
        }
    });

}
function do_edit_auth_group(project_id, group_id)
{
    var url = '/statistic/update_user_group/';
    $("#group_id_update_group_modal").val(group_id);
    user_group_upsert(url, project_id, 'update_group_modal');
}
function init_select2_async()
{
    $(".select2-select-00").select2({
        allowClear: true
    });
    $(".select2-select-01").select2({
        minimumInputLength: 3
    });
    $(".select2-select-02").select2({
        tags: ["Sport", "Gadget", "Politics"]
    });
    if ($.fn.spinner) {
        $("#spinner-default").spinner();
        $("#spinner-decimal").spinner({
            step: 0.01,
            numberFormat: "n"
        });
        $("#culture").change(function() {
            var a = $("#spinner-decimal").spinner("value");
            Globalize.culture($(this).val());
            $("#spinner-decimal").spinner("value", a)
        });
        $("#currency").change(function() {
            $("#spinner-currency").spinner("option", "culture", $(this).val())
        });
        $("#spinner-currency").spinner({
            min: 5,
            max: 2500,
            step: 25,
            start: 1000,
            numberFormat: "C"
        });
        $("#spinner-overflow").spinner({
            spin: function(a, b) {
                if (b.value > 10) {
                    $(this).spinner("value", -10);
                    return false
                } else {
                    if (b.value < -10) {
                        $(this).spinner("value", 10);
                        return false
                    }
                }
            }
        });
        $.widget("ui.timespinner", $.ui.spinner, {
            options: {
                step: 60 * 1000,
                page: 60
            },
            _parse: function(a) {
                if (typeof a === "string") {
                    if (Number(a) == a) {
                        return Number(a)
                    }
                    return + Globalize.parseDate(a)
                }
                return a
            },
            _format: function(a) {
                return Globalize.format(new Date(a), "t")
            }
        });
        $("#spinner-time").timespinner();
        $("#culture-time").change(function() {
            var a = $("#spinner-time").timespinner("value");
            Globalize.culture($(this).val());
            $("#spinner-time").timespinner("value", a)
        });
        $("#spinner-validation").spinner()
    }
}
function filterArrayWithHtml(data, id) {
    var fa = function(pId) {
        var _array = [];
        var html = '';
        html += '<ul class="list-unstyled">';
        for (var i = 0; i < data.length; i++) {
            var n = data[i];
            if (n.pId === pId) {
                html += '<li action-data="'+data[i].id+'" action-data-db-id="'+data[i].db_id+'"><label class="radio-inline" title="'+data[i].name+'">';
                if(data[i].type == 'group')
                {
                    html += '<span class="glyphicon glyphicon-triangle-bottom" aria-hidden="true"></span>';
                }
                html += data[i].name+'</label>\
                         <label class="radio-inline radio-right radio_readwrite">\
                           <input type="radio" name="inlineRadioOptions_'+data[i].id+'" id="inlineRadio1" value="1"> 读写\
                         </label>\
                         <label class="radio-inline radio-right radio_readonly">\
                           <input type="radio" name="inlineRadioOptions_'+data[i].id+'" id="inlineRadio2" value="0"> 读权限\
                         </label>\
                         <label class="radio-inline radio-right radio_no">\
                           <input type="radio" name="inlineRadioOptions_'+data[i].id+'" id="inlineRadio2" value="-1" checked> 无\
                         </label>';
                html += fa(n.id)+'</li>';
            }
        }
        html += '</ul>';
        return html;
    }
    return fa(id);
}

$(function() {
    $("#project_auth_conf").click(function() {
        var obj = $(this);
        obj.button("loading");
        var project_name = obj.attr("project_name");
        var project_id = obj.attr("project_id");
        auth_manager(project_name, project_id, function() {
            obj.button("reset");
        });
    });
});