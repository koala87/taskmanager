var proj_cate = '';
var project_modal_init_html = '';
$(function(){
    init_add_group_radio();
    get_project_list();
    init_search_input();
    init_switch_other_project();
    $(document).on('click', '.delete_single_or', function(){
        var dom = $(this).parent().parent().parent().parent();
        if(dom.prev().length >0)
        {
            dom.prev().remove();
        }
        else
        {
            dom.parent().find('.line-or').eq(0).remove();
        }
        dom.remove();
    });
    $(document).on('click', ".add_single_or", function(){
        var dom = $(this).parent().parent().parent().parent();
        var html1 = '<div class="form-group line-or">\
                      <label class="col-sm-3 control-label">或</label>\
                    </div>';
        var html2 = '<div class="form-group">\
                      <label for="inputProName" class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="字段"></div> \
                              <div class="col-sm-4"><select class="form-control" id="selectProType">';
        html2 += $("#select_op_list").html();
        html2 += '</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="值"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>';
        if(dom.prev().length >0)
        {
            dom.before(html1+html2);
        }
        else
        {
            dom.before(html2);
        }
    });
    $(document).on('click', '.delete_and', function(){
        var dom = $(this).parent().parent().parent();
        if(dom.prev(".line-and").length>0)
        {
            dom.prev(".line-and").remove();
        }
        else
        {
            dom.next(".line-and").remove();
        }
        dom.remove();
    });
    $(document).on('click', '.add_and', function(){
        var html = '<div class="filter_and">\
                    <div class="row">\
                    <div id="id_div_filter" style="border: 1px solid #ccc; padding-top: 15px;" class="col-sm-10">\
                    <div class="form-group">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="字段"></div> \
                              <div class="col-sm-4"><select class="form-control" id="selectProType">'+$("#select_op_list").html()+'</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="值"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>\
                    <div class="form-group line-or">\
                      <label class="col-sm-3 control-label">或</label>\
                    </div>\
                    <div class="form-group">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="字段"></div> \
                              <div class="col-sm-4"><select class="form-control">'+$("#select_op_list").html()+'</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="值"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>\
                    <div class="form-group form-group-add-or">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                          <div class="col-sm-3"><span class="glyphicon glyphicon-plus-sign add_single_or" aria-hidden="true"></span></div>\
                      </div>\
                    </div>\
                    </div>\
                    </div>\
                    <div class="col-sm-2 col-sm-offet-10">\
                        <span class="glyphicon glyphicon-minus-sign delete_and" aria-hidden="true">\
                    </span></div>\
                    </div>\
                  </div>';
        if($(this).parent().parent().next(".filter_and").length>0)
        {
            html += '<div class="line-and"><p>且</p></div>';
        }
        $(this).parent().parent().after(html);
    });
    $(document).on('click', '.delete_single_config', function(){
        $(this).parent().parent().remove();
    });
    $(document).on('click', '.add_single_config', function(){
        var html = '<div class="row single_config_row">\
              <div class="col-md-9 col-md-offset-1" style="border:1px solid #ccc;padding:0px 0px 25px 0px;">\
                <span class="single_config_title">日志</span>\
                <form class="form-horizontal">\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*日志别名：</label>\
                    <div class="col-sm-8">\
                      <input type="text" class="form-control" placeholder="请输入日志别名">\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*数据源：</label>\
                    <div class="col-sm-5">\
                      <select class="form-control combobox">'+$("#select_datasource_list").html()+'</select>\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">日期列：</label>\
                    <div class="col-sm-2">\
                      <input type="text" class="form-control" placeholder="请输入日期列">\
                    </div>\
                    <label class="col-sm-2 control-label">日期格式：</label>\
                    <div class="col-sm-4">\
                      <select class="form-control">\
                        <option value="YYYYMMDD">YYYYMMDD</option>\
                        <option value="YYYY-MM-DD">YYYY-MM-DD</option>\
                        <option value="YYYY/MM/DD">YYYY/MM/DD</option>\
                        <option value="YYMMDD">YYMMDD</option>\
                        <option value="YY-MM-DD">YY-MM-DD</option>\
                        <option value="YY/MM/DD">YY/MM/DD</option>\
                      </select>\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*小时列：</label>\
                    <div class="col-sm-8">\
                      <input type="text" class="form-control" placeholder="请输入小时列">\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*uid列：</label>\
                    <div class="col-sm-8">\
                      <input type="text" class="form-control" placeholder="请输入uid列">\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*过滤条件：</label>\
                    <div class="col-sm-3">\
                      <button type="button" class="form-control btn btn-success add_and">+添加</button>\
                    </div>\
                  </div>\
                  <div class="filter_and">\
                    <div class="row">\
                    <div id="id_div_filter" style="border: 1px solid #ccc; padding-top: 15px;" class="col-sm-10">\
                    <div class="form-group">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="字段"></div> \
                              <div class="col-sm-4"><select class="form-control" id="selectProType">'+$("#select_op_list").html()+'</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="值"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>\
                    <div class="form-group line-or">\
                      <label class="col-sm-3 control-label">或</label>\
                    </div>\
                    <div class="form-group">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="字段"></div> \
                              <div class="col-sm-4"><select class="form-control">'+$("#select_op_list").html()+'</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="值"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>\
                    <div class="form-group form-group-add-or">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                          <div class="col-sm-3"><span class="glyphicon glyphicon-plus-sign add_single_or" aria-hidden="true"></span></div>\
                      </div>\
                    </div>\
                    </div>\
                    </div>\
                    <div class="col-sm-2 col-sm-offet-10">\
                        <span class="glyphicon glyphicon-minus-sign delete_and" aria-hidden="true">\
                    </span></div>\
                    </div>\
                  </div>\
                  <div class="line-and">\
                    <p>且</p>\
                  </div>\
                  <div class="filter_and">\
                    <div class="row">\
                    <div id="id_div_filter" style="border: 1px solid #ccc; padding-top: 15px;" class="col-sm-10">\
                    <div class="form-group">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="字段"></div> \
                              <div class="col-sm-4"><select class="form-control">'+$("#select_op_list").html()+'</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="值"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>\
                    <div class="form-group line-or">\
                     <label class="col-sm-3 control-label">或</label>\
                    </div>\
                    <div class="form-group">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="字段"></div> \
                              <div class="col-sm-4"><select class="form-control">'+$("#select_op_list").html()+'</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" placeholder="值"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>\
                    <div class="form-group form-group-add-or">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                          <div class="col-sm-3"><span class="glyphicon glyphicon-plus-sign add_single_or" aria-hidden="true"></span></div>\
                      </div>\
                    </div>\
                    </div>\
                    </div>\
                    <div style="margin-top:16%" class="col-sm-2 col-sm-offet-10">\
                        <span class="glyphicon glyphicon-minus-sign delete_and" aria-hidden="true">\
                    </span></div>\
                  </div>    \
                 </div>\
                </form>\
             </div>\
             <div class="col-md-2" style="position: relative;display: block;margin-top: 40%;">\
               <span class="glyphicon glyphicon-minus-sign delete_single_config" aria-hidden="true">\
             </span></div>\
            </div>';
        $(this).parent().parent().parent().before(html);
        $('.combobox').last().combobox();
    });

    $(document).on("click", "#btn_save_create_project", function(){
        var url = '/statistic/create_project/';
        var post_data = {};
        post_data["name"] = $("#project_name").val().trim();
        post_data["category"] = $("#project_category").val().trim();
        post_data["description"] = $("#project_description").val().trim();
        post_data["logs"] = JSON.stringify(get_create_project_log_config());

        $.ajax({
            url: url,
            type: "POST",
            async: false,
            data: post_data,
            success: function(result) {
                ark_notify(result);
                if(result.status == 0)
                {
                    $("#createProjectModal").modal('hide');
                    get_project_list();       
                }
            }
        });
    });
    $('.combobox_create').combobox();
});

function get_create_project_log_config()
{
    var ret = [];
    $(".single_config_row").each(function(index){
        ret[index] = {};
        ret[index]['name'] = $($(this).find(".form-group").get(0)).find("input").val().trim();
        ret[index]['data_id'] = $($(this).find(".form-group").get(1)).find("select").val().trim();
        ret[index]['day_column'] = $($(this).find(".form-group").get(2)).find("input").val().trim();
        ret[index]['day_format'] = $($(this).find(".form-group").get(2)).find("select").val().trim();
        ret[index]['hour_column'] = $($(this).find(".form-group").get(3)).find("input").val().trim();
        ret[index]['uid_column'] = $($(this).find(".form-group").get(4)).find("input").val().trim();
        ret[index]['filter'] = [];
        $(this).find(".filter_and").each(function(index_and){
            ret[index]['filter'][index_and] = [];
            $(this).children().find(".form-group:not(.line-or):not(.form-group-add-or)").each(function(index_or){
                ret[index]['filter'][index_and][index_or] = [];
                ret[index]['filter'][index_and][index_or][0] = $(this).find('input').eq(0).val().trim();
                ret[index]['filter'][index_and][index_or][1] = $(this).find('select').val().trim();
                ret[index]['filter'][index_and][index_or][2] = $(this).find('input').eq(1).val().trim();
            });
        });
        ret[index]['filter'] = JSON.stringify(ret[index]['filter']);
    });
    return ret;
}
function get_project_list()
{
    $("#wrap_unauthed_projexts_p").hide();
    $(".project-list").html('<p style="text-align:center;"><i class="fa fa-refresh fa-spin"></i> 数据加载中...</p>');
    $(".project-list_unauthed").hide();
    var post_data = {"name_desc":$("#project_search_filter").val().trim(), "category":proj_cate};
    $.post("/statistic/list/", post_data, function(data){
        if(data.status == 0)
        {
            $(".project-list").html('');
            $(".project-list_unauthed").html('');
            var html_no_privilege = '';
            var html_unauth = '';
            var html_authed = '';
            var html_deny = '';
            for(var i=0;i<data.data.length;i++)
            {
                var edit_action_data = 'id='+data.data[i].id+'&name='+data.data[i].name+'&description='+data.data[i].description+'&status='+data.data[i].status+'&category='+data.data[i].category;
                //临时隐藏: <li><a href="javascript:void(0)" onclick="show_log_config_modal('+data.data[i].id+')">日志配置</a></li>\
                var tools = '';
                var img_addr = '/static/images/statistic/box_no_privilegew.png';
                var reason_tip = '';
                var img_title_tip = '';
                var title_str = data.data[i].name;
                if(data.data[i].can_view_project)
                {
                    if(data.data[i].status == 0)//未审核
                    {
                        if(data.data[i].can_manage_project)//未审核
                        {
                            tools = '<div class="box-tools pull-right">\
                                        <div class="btn-group">\
                                          <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">\
                                            <img style="width:20px;" src="/static/images/statistic/box_tooltip.png"></img></button>\
                                          <ul class="dropdown-menu" role="menu">\
                                            <li><a href="javascript:void(0)" onclick="delete_project('+data.data[i].id+')">删除</a></li>\
                                          </ul>\
                                        </div>\
                                      </div>';
                        }
                        img_addr = '/static/images/statistic/box_auditing.png';
                    }
                    else if(data.data[i].status == 1)//审核通过
                    {
                        if(data.data[i].can_manage_project)//未审核
                        {
                            tools = '<div class="box-tools pull-right" data-loading-text="权限加载中...">\
                                        <div class="btn-group">\
                                          <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">\
                                            <img style="width:20px;" src="/static/images/statistic/box_tooltip.png"></img></button>\
                                          <ul class="dropdown-menu" role="menu">\
                                            <li><a href="javascript:void(0)" action-data="'+edit_action_data+'" onclick="edit_project(this)">编辑</a></li>\
                                            <li><a href="javascript:void(0)" onclick="auth_conf(this,'+data.data[i].id+')">权限管理</a></li>\
                                            <li><a href="javascript:void(0)" onclick="delete_project('+data.data[i].id+')">删除</a></li>\
                                          </ul>\
                                        </div>\
                                      </div>';
                        }
                        img_addr = '/static/images/statistic/box_authed.png';
                        title_str = '<a style="color:#00c0ef;" href="/statistic/report_manager/?project_id='+data.data[i].id+'">'+data.data[i].name+'</a>';
                        img_title_tip = 'onclick="location='+"'/statistic/report_manager/?project_id="+data.data[i].id+"'"+ '" data-toggle="tooltip" data-placement="left" data-original-title="点击进入项目";'
                    }
                    else if(data.data[i].status == 2)//已拒绝
                    {
                        if(data.data[i].can_manage_project)//未审核
                        {
                            //reason_tip = 'title="拒绝原因:'+(data.data[i].status_reason ? data.data[i].status_reason : '无') +'";'
                            reason_tip = 'data-toggle="tooltip" data-placement="left" data-original-title="拒绝原因:'+(data.data[i].status_reason ? data.data[i].status_reason : '无') +'";'
                            tools = '<div class="box-tools pull-right" data-loading-text="加载中...">\
                                        <div class="btn-group">\
                                          <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">\
                                            <img style="width:20px;" src="/static/images/statistic/box_tooltip.png"></img></button>\
                                          <ul class="dropdown-menu" role="menu">\
                                            <li><a href="javascript:void(0)" action-data="'+edit_action_data+'" onclick="edit_project(this)">编辑</a></li>\
                                            <li><a href="javascript:void(0)" onclick="re_submit('+data.data[i].id+')">提交审核</a></li>\
                                            <li><a href="javascript:void(0)" onclick="delete_project('+data.data[i].id+')">删除</a></li>\ </ul>\
                                        </div>\
                                      </div>';
                        }
                        img_addr = '/static/images/statistic/box_deny.png';
                    }
                }
                var description_dsp = data.data[i].description ? data.data[i].description : '无';
                var html = '<div class="col-md-4">\
                          <div class="box">\
                            <div class="box-header with-border">\
                              <h3 class="box-title" title="'+data.data[i].name+'">'+title_str+'</h3>'
                            +tools+'</div>\
                            <!-- /.box-header -->\
                            <div class="box-body">\
                                <div class="row">\
                                  <div class="col-md-8">\
                                    <div class="row">\
                                        <div class="col-md-6 dl_col_2_left" style="width:65%;">\
                                            <dl class="dl-horizontal">\
                                            <dt>创建者</dt>\
                                            <dd data-toggle="tooltip" data-placement="bottom" data-original-title="'+data.data[i].owner_username+'">'+data.data[i].owner_username+'</dd>\
                                            <dt>成员</dt>\
                                            <dd>'+data.data[i].user_num+'</dd>\
                                            </dl>\
                                        </div>\
                                        <div class="col-md-6 dl_col_2_right" style="width:35%;">\
                                            <dl class="dl-horizontal">\
                                            <dt>类型</dt>\
                                            <dd title="'+data.data[i].category+'">'+data.data[i].category+'</dd>\
                                            <dt>报表</dt>\
                                            <dd>'+data.data[i].report_num+'</dd>\
                                            </dl>\
                                        </div>\
                                    </div>\
                                    <div class="row">\
                                        <div class="col-md-12 dl_col_1">\
                                            <dl class="dl-horizontal">\
                                            <dt style="margin-top:-4px;">描述</dt>\
                                            <dd title="'+description_dsp+'" style="line-height: 14pt;margin-top:5px;">'+description_dsp+'</dd>\
                                            </dl>\
                                        </div>\
                                    </div>\
                                  </div>\
                                  <div class="col-md-4" ' + reason_tip + '>\
                                    <img class="status_img" '+img_title_tip+' src="'+img_addr+'"></img>\
                                  </div>\
                                 </div>\
                            </div>\
                          </div>\
                        </div>';
                
                if(data.data[i].can_view_project)
                {
                    if(data.data[i].status == 0)//未审核
                        html_unauth += html;
                    else if(data.data[i].status == 1)//审核通过
                        html_authed += html;
                    else if(data.data[i].status == 2)//审核通过
                        html_deny += html;
                }
                else
                {
                    if(data.data[i].status == 1)//审核通过
                        html_no_privilege += html;
                }
            }
            var res_top_html = html_authed+html_unauth+html_deny;
            if(!res_top_html)
            {
                var tip_str = $("#project_search_filter").val().trim() ? '<h4 style="font-size: 28px;margin-top: -62px;margin-left: 58px;margin-bottom: 28px;font-family:microsoft yahei,微软雅黑,tahoma,open sans,Helvetica Neue,Helvetica,Arial,sans-serif">未找到您搜索的项目!</h4>' : '<h4 style="font-size: 28px;margin-top: -62px;margin-left: 58px;font-family:microsoft yahei,微软雅黑,tahoma,open sans,Helvetica Neue,Helvetica,Arial,sans-serif">您尚无该类型的项目!</h4><p style="margin-left: 58px;">请赶紧<a href="javacript:" data-toggle="modal" data-target="#createProjectModal">创建项目</a>或加入一个项目</p>';
                res_top_html = '<div style="text-align: center;background-color: white;padding-bottom: 4px;margin-bottom: 10px;">\
                                  <img src="/static/images/statistic/empty_tip.png" style="width: 1100px;"></img>'+tip_str+'</div>';
            }
            $(".project-list").append(res_top_html);
            $(".project-list_unauthed").append(html_no_privilege);
            if(!html_no_privilege)
            {
                $("#wrap_unauthed_projexts_p").hide();
            }
            else
            {
                $("#wrap_unauthed_projexts_p").show();
            }
        }
    })
}
function init_search_input()
{
    $("#project_search_filter").on("keydown", function(e){
        var e=e||window.event;
        var enter= e.keyCode|| e.which;
        if(enter==13){
            get_project_list();
            return false;
        }
    });
}
function search_category(obj)
{
    var category = $(obj).parent().text().trim();
    if(category == '全部项目')
    {
        proj_cate = '';
    }
    else
    {
        proj_cate = category;
    }
    $(".inner-nav li").removeClass("active");
    $(obj).parent().addClass("active");
    $("#project_search_filter").val("");
    get_project_list();
}
function edit_project(obj)
{
    var action_data = $(obj).attr('action-data');
    var chunk_list = action_data.split("&");
    var id = chunk_list[0].split("=")[1];
    var name = chunk_list[1].split("=")[1];
    var description = chunk_list[2].split("=")[1];
    var status_audit = chunk_list[3].split("=")[1];
    var category = chunk_list[4].split("=")[1];
    $("#projectEditModal #project_name").val(name);
    $("#projectEditModal #project_category").val(category);
    $("#projectEditModal #project_description").val(description);
    if(status_audit == 1 && _is_super == "False")
    {
        $("#projectEditModal #project_category").prop("disabled", true);
    }
    else
    {
        $("#projectEditModal #project_category").prop("disabled", false);
    }
    $("#projectEditModal .save_project").attr("onclick", "do_save_project('"+id+"')");
    $("#projectEditModal").modal("show");
}
function do_save_project(id)
{
    var post_data = {'id':id,'name':$("#projectEditModal #project_name").val().trim(),'description':$("#projectEditModal #project_description").val().trim(),'category':$("#projectEditModal #project_category").val().trim()};
    url = '/statistic/update/';
    $.post(url, post_data, function(data){
        ark_notify(data);
        if(data.status == 0)
        {
            $("#projectEditModal").modal('hide');
            get_project_list();
        }
    }, 'json');
}

function show_log_config_modal(project_id)
{
    $.post('/statistic/detail/', {'id':project_id}, function(data){
        if(data.status != 0)
        {
            ark_notify(data);
//            new PNotify({
//                   title: '通知',
//                   text: '编辑失败',
//                   type: 'error',
//                   hide: false,
//                   closer: true,
//                   addclass: 'custom'
//            });
            return false;
        }
        var op_list = get_op_list();
        var datasource_list = get_datasource_list();
        //获取项目配置详情
        var logs_conf = data.data.logs;
        var tmp = logs_conf;
//tmp = [];
//tmp[0] = {};
//tmp[0]['data_source'] = 241;
//tmp[0]['day_column'] = "a";
//tmp[0]['day_format'] = "YYYY/MM/DD";
//tmp[0]['hour_column'] = "a";
//tmp[0]['name'] = "1";
//tmp[0]['uid_column'] = "a";
//tmp[0]['filter'] = [];
//tmp[0]['filter'][0] = [];
//tmp[0]['filter'][1] = [];
//tmp[0]['filter'][0][0] = ["a","is_null","a"];
//tmp[0]['filter'][0][1] = ["a","is_not_null","a"];
//tmp[0]['filter'][1][0] = ["a","regexp","a"];
//tmp[0]['filter'][1][1] = ["a","ge","a"];
        var html = '';
        for(var i=0; i<tmp.length;i++)
        {
            tmp[i]['filter'] = eval(tmp[i]['filter']);
            html += '<div class="row single_config_row">\
              <div class="col-md-9 col-md-offset-1" style="border:1px solid #ccc;padding:0px 0px 25px 0px;">\
                <span class="single_config_title">日志</span>\
                <form class="form-horizontal">\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*日志别名：</label>\
                    <div class="col-sm-8">\
                      <input type="text" class="form-control" id="" value="'+tmp[i]['name']+'" placeholder="请输入日志别名">\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*数据源：</label>\
                    <div class="col-sm-5">\
                      <select class="form-control combobox">';
            for(var index_datasource=0;index_datasource<datasource_list.length;index_datasource++)
            {
                html += '<option value="'+datasource_list[index_datasource][0]+'"'+(tmp[i]['data_id'] == datasource_list[index_datasource][0] ? ' selected ' : '')+'>'+datasource_list[index_datasource][1]+'</option>';
            }
            html += '</select>\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">日期列：</label>\
                    <div class="col-sm-2">\
                      <input type="text" class="form-control" value="'+tmp[i]['day_column']+'" placeholder="请输入日期列">\
                    </div>\
                    <label class="col-sm-2 control-label">日期格式：</label>\
                    <div class="col-sm-4">\
                      <select class="form-control">';
            html += '<option value="YYYYMMDD"'+(tmp[i]['day_format'] == 'YYYYMMDD' ? ' selected ' : '')+'>YYYYMMDD</option>';
            html += '<option value="YYYY-MM-DD"'+(tmp[i]['day_format'] == 'YYYY-MM-DD' ? ' selected ' : '')+'>YYYY-MM-DD</option>';
            html += '<option value="YYYY/MM/DD"'+(tmp[i]['day_format'] == 'YYYY/MM/DD' ? ' selected ' : '')+'>YYYY/MM/DD</option>';
            html += '<option value="YYMMDD"'+(tmp[i]['day_format'] == 'YYMMDD' ? ' selected ' : '')+'>YYMMDD</option>';
            html += '<option value="YY-MM-DD"'+(tmp[i]['day_format'] == 'YY-MM-DD' ? ' selected ' : '')+'>YY-MM-DD</option>';
            html += '<option value="YY/MM/DD"'+(tmp[i]['day_format'] == 'YY/MM/DD' ? ' selected ' : '')+'>YY/MM/DD</option>';
            html += '</select>\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*小时列：</label>\
                    <div class="col-sm-8">\
                      <input type="text" class="form-control" value="'+tmp[i]['hour_column']+'" placeholder="请输入小时列">\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*uid列：</label>\
                    <div class="col-sm-8">\
                      <input type="text" class="form-control" value="'+tmp[i]['uid_column']+'" placeholder="请输入uid列">\
                    </div>\
                  </div>\
                  <div class="form-group">\
                    <label class="col-sm-3 control-label">*过滤条件：</label>\
                    <div class="col-sm-3">\
                      <button type="button" class="form-control btn btn-success add_and">+添加</button>\
                    </div>\
                  </div>'
            for(var j=0; j<tmp[i].filter.length;j++)
            {
                html += '<div class="filter_and"><div class="row">';
                html += '<div id="id_div_filter" style="border: 1px solid #ccc; padding-top: 15px;" class="col-sm-10">';
                for(var k=0; k<tmp[i].filter[j].length;k++)
                {
                    html += '<div class="form-group">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="字段" value="'+tmp[i].filter[j][k][0]+'"></div> \
                              <div class="col-sm-4">\
                                <select class="form-control" id="selectProType">';
                        for(var op_set_index=0; op_set_index<op_list.length; op_set_index++ )
                        {
                            var selected_str = op_list[op_set_index][0] == tmp[i].filter[j][k][1] ? " selected " : "";
                            html += '<option '+selected_str+'value="'+op_list[op_set_index][0]+'">'+op_list[op_set_index][1]+'</option>';
                        }
                        html += '</select></div>\
                              <div class="col-sm-3"><input type="text" class="form-control" id="inputProName" placeholder="值" value="'+tmp[i].filter[j][k][2]+'"></div>\
                              <div class="col-sm-1"><span class="glyphicon glyphicon-minus-sign delete_single_or" aria-hidden="true"></span></div>\
                          </div>\
                      </div>\
                    </div>';
                    if(k<tmp[i].filter[j].length-1)
                    {
                        html += '<div class="form-group line-or"><label class="col-sm-3 control-label">或</label></div>';
                    }
                }
                html += '<div class="form-group form-group-add-or">\
                      <label class="col-sm-3 control-label"></label>\
                      <div class="col-sm-8">\
                          <div class="row">\
                          <div class="col-sm-3"><span class="glyphicon glyphicon-plus-sign add_single_or" aria-hidden="true"></span></div>\
                      </div>\
                    </div>\
                    </div>';
                html += '</div>';
                html += '<div class="col-sm-2 col-sm-offet-10">\
                        <span class="glyphicon glyphicon-minus-sign delete_and" aria-hidden="true">\
                        </span></div></div></div>'
                //不是最后一个时，显示且
                if(j != tmp[i].filter.length-1)
                {
                    html += '<div class="line-and"><p>且</p></div>';
                }
            }
            html += '</form>\
                  </div>\
                  <div class="col-md-2" style="position: relative;display: block;margin-top: 40%;">\
                    <span class="glyphicon glyphicon-minus-sign delete_single_config" aria-hidden="true">\
                  </div>\
                  </div>';
        }
//        html += '<div class="row" style="margin-top: -35px;">\
//              <div class="col-md-9 col-md-offset-1">\
//                <div class="col-sm-2 col-md-offset-4" style="margin-top: 20px; text-align: center;">\
//                    <span class="glyphicon glyphicon-plus-sign add_single_config" aria-hidden="true">\
//                </span></div>\
//              </div>\
//            </div>';
        $("#modifyLogConfigModal hr").nextAll(".single_config_row").remove();
        $("#modifyLogConfigModal hr").after(html);
        $('.combobox').combobox();
        $("#btn_update_project_log").on('click',function(){update_project_log_conf(project_id);});
        $("#modifyLogConfigModal").modal('show');
    }, 'json');
}

function get_op_list()
{
    var ret = [];
    $("#select_op_list option").each(function(index){
        ret[index] = [$("#select_op_list option").eq(index).val(), $("#select_op_list option").eq(index).text()];
    });

    return ret;
}

function get_datasource_list()
{
    var ret = [];
    $("#select_datasource_list option").each(function(index){
        ret[index] = [$("#select_datasource_list option").eq(index).val(), $("#select_datasource_list option").eq(index).text()];
    });

    return ret;
}
function init_create_project_modal()
{
    if(project_modal_init_html)
    {
        $("#createProjectModal").html(project_modal_init_html);
        var node_select = $(".combobox_create").eq(1).prop("outerHTML");
        $(".combobox_create").eq(1).parent().remove();
        $(".single_config_row .form-group").eq(1).append('<div class="col-sm-5">'+node_select+'</div>');
        $('.combobox_create').combobox();
    }
    else
    {
        project_modal_init_html = $("#createProjectModal").html();
    }
}
function update_project_log_conf(project_id)
{
    var url = '/statistic/update_project_log/';
    var post_data = {};
    post_data["id"] = project_id;
    post_data["logs"] = JSON.stringify(get_create_project_log_config());
    $.post(url, post_data, function(data){
        ark_notify(result);
        if(data.status == 0)
        {
            $("#modifyLogConfigModal").hide();
            get_project_list();
        }
    }, 'json');
}
function re_submit(project_id)
{
    $("#btn_re_submit").attr('onclick', 'do_re_submit('+project_id+')');
    $("#applyProjectModal").modal('show');
}
function do_re_submit(project_id)
{
    var url = '/statistic/project_apply/';
    var post_data = {};
    post_data["project_id"] = project_id;
    post_data["reason"] = $("#apply_reason").val();
    $.post(url, post_data, function(data){
        ark_notify(data);
        if(data.status == 0)
        {
            $("#applyProjectModal").modal('hide');
            get_project_list();
        }
    }, 'json');
}
function delete_project(project_id)
{
    $("#btn_delete_project").unbind('click');
    $("#btn_delete_project").on('click', function(){do_delete_project(project_id)});
    $("#deleteProjectModal").modal('show');
}
function do_delete_project(project_id)
{
    var url = '/statistic/delete_project/';
    var post_data = {};
    post_data["id"] = project_id;
    $.post(url, post_data, function(data){
        ark_notify(data);
        if(data.status == 0)
        {
            $("#deleteProjectModal").modal('hide');
            get_project_list();
        }
    }, 'json');
   
}
function filterArray(data, id) {
    var fa = function(pId) {
        var _array = [];
        for (var i = 0; i < data.length; i++) {
            var n = data[i];
            if (n.pId === pId) {
                n.children = fa(n.id);
                _array.push(n);
            }
        }
        return _array;
    }
    return fa(id);
}
function auth_conf(obj, project_id)
{
    var project_name = $(obj).parent().parent().parent().parent().prev().find('a').html();
    var box_tools = $(obj).parents(".box-tools").first();
    box_tools.button("loading");
    auth_manager(project_name, project_id, function() {
        box_tools.button("reset");
    });
}
function init_switch_other_project()
{
    $("#wrap_unauthed_projexts_span").on('click', function(){
        if($(".project-list_unauthed").is(':hidden'))
        {
            $("#wrap_unauthed_projexts_span span").text("收起全部项目");
            $("#wrap_unauthed_projexts_span span").removeClass("glyphicon-triangle-down");
            $("#wrap_unauthed_projexts_span span").addClass("glyphicon-triangle-top");
            $(".project-list_unauthed").css('display','block');
        }
        else
        {
            $("#wrap_unauthed_projexts_span span").text("展开全部项目");
            $("#wrap_unauthed_projexts_span span").addClass("glyphicon-triangle-down");
            $("#wrap_unauthed_projexts_span span").removeClass("glyphicon-triangle-top");
            $(".project-list_unauthed").css('display','none');
        }
    });
}
