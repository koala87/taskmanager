$(function() {
    var dim_selector_inited = 0;
    var empty_value = "___empty___";
    var empty_value_text = "--选择或输入--";
    var dim_filter_result = null;

    window.DimFilter = {
        initEmptyValue: function(ele) {
            ele.find("input.select_dim_filter_value").val(empty_value);
        },
        getSelectDims: function(ele) {
            var values = []
            ele.find("input[type=checkbox]:checked").each(function() {
                values.push($(this).val());
            });
            return values;
        },
        inited: function() {

        },
        updateDimSelector: function(result, ele) {
            if(result.status != 0) {
                result['msg'] = '获取维度下拉框列表失败';
                ark_notify(result);
            } else {
                for(var dim in result.data) {
                    var name = "filter_value_" + dim;
                    var data = [{id: empty_value, text: empty_value_text}];
                    for(var i in result.data[dim]) {
                        data.push({id: result.data[dim][i], text: result.data[dim][i]});
                    }

                    var ele_val = ele.find("[name=" + name + "]");
                    ele_val.select2(
                        {data: data,
                         allowClear: true,
                         createSearchChoice:function(term, data) { 
                             if ($(data).filter(function() { 
                                 return this.text.localeCompare(term)===0; 
                             }).length===0) {
                                 return {id:term, text:term};
                             } 
                         },
                        }).on('select2-open', function(e) {
                            var input = $(".select2-drop.select2-display-none.select2-with-searchbox.select2-drop-active input");
                            console.log(input);
                            if($(this).val() != empty_value) {
                                input.val($(this).val());
                            }
                        }).on('select2-removed', function(e) {
                            $(this).select2("val", empty_value);
                        });
                    ele_val.select2("val", empty_value);
                }

                ele.find("select.select_dim_filter").change(function() {
                        var ele_val = $(this).parent().parent().find("input.select_dim_filter_value");
                        if($(this).val() == 'is_null' || $(this).val() == 'is_not_null') {
                            
                            ele_val.prop('disabled', true);
                        } else {
                            ele_val.prop('disabled', false);
                        }
                    });

                dim_filter_result = result;
                dim_selector_inited = 1;

                DimFilter.setDimFilter(ele, _init_dim_filter);
            }
        },

        initDimSelector: function(ele, async, refresh, callback) {
            if(typeof(async) == 'undefined') {
                async = true;
            }
            if(dim_selector_inited == 1 && (!refresh || typeof(refresh) == 'undefined')) {
                if(callback) {
                    callback();
                }
                return;
            }
            var url = "/statistic/distinct_dim_values/" + _report_id + "/";
            var data = {'dims': _all_dims, 'refresh': refresh};
            makeAPost(url, data, async, function(result) {
                if(callback) {
                    callback();
                }
                DimFilter.updateDimSelector(result, ele);
            });
        },
        getDimFilter: function(ele) {
            dim_data = []
            for(var i in _all_dims) {
                dim = _all_dims[i];
                var name = "filter_value_" + dim;
                var op = ele.find("[name=filter_" + dim + "]").val();
                var v = ele.find("[name=" + name + "]").val().trim();
                if(op == 'is_null' || op == 'is_not_null') {
                    v = "";
                }
                if(v != empty_value) {
                    dim_data.push([dim, op, v]);
                }
            }
            return dim_data;
        },
        setDimFilter: function(ele, dim_filter) {
            for(var i in dim_filter) {
                if(dim_filter[i].length != 3) {
                    continue
                }
                var dim = dim_filter[i][0];
                var op = dim_filter[i][1];
                var v = dim_filter[i][2];
                var name = "filter_value_" + dim;
                ele.find("[name=filter_" + dim + "]").val(op);
                ele.find("[name=filter_value_" + dim + "]").select2("data", {id:v, text:v});
            }
        }
    }
});
