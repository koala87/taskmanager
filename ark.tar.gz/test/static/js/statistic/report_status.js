function get_latest_status(dsp_obj, status_obj, report_id) {
    var url = "/statistic/report_latest_status/" + report_id + "/";
    dsp_obj.html("查询中...");
    makeAPost(url, {}, true, function(result) {
        if(result.status != 0) {
            ark_notify(result);
            dsp_obj.html("<font color='red'>" + result.msg + "</font>");
        } else {
            if(status_obj) {
                status_obj.attr("data_time", result.latest_status.data_time);
                status_obj.attr(
                    "data-original-title", 
                    "最新状态 " + result.latest_status.run_time + "\n点击查看日志");
            }
            var dsp = makeStatusDsp(result.latest_status.pipe_status, "font");
            dsp_obj.html(dsp);
        }
    });
}

function show_run_status(trigger_obj, report_id, start_time, end_time)
{
    _report_id = report_id;
    //    var str = $(obj).attr('action-data');
    //    var res = eval(str.replace(new RegExp(/(u')/g),"'").replace(new RegExp(/(')/g),'"'));
    $("#run_status_list_modal tbody").html('');
    $("#run_status_list_modal #run_status_input_reportid").val(report_id);
    var url = '/statistic/report_status/';
    var post_data = {
        'report_id': report_id,
        'start_time': start_time,
        'end_time': end_time,
    };
    trigger_obj.button("loading");
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            if(result.status == 0)
            {
                for(var i=1;i<=result.data.length;i++)
                {
                    var status_str = makeStatusDsp(result.data[i-1]['pipe_status'], "a");
                    $("#run_status_list_modal tbody").append("<tr run_time='" + result.data[i-1]["run_time"] + "' detail='" + JSON.stringify(result.data[i-1]["task_list"]) + "'><td>"+i+"</td><td name='data_time'>"+result.data[i-1]["data_time"]+"</td><td name='run_time'>" + result.data[i-1]["run_time"] + "</td><td>" + status_str+"</td><td><button type='button' class='btn' style='font-size: 12px;padding-top: 0;padding-bottom: 0;background-color: white;border: 0;color: blue;' data-loading-text='重跑中...' onclick='report_rerun(this)'>重跑</button></td>");
                }
                $("#run_status_list_modal tbody tr td a[name='status']").click(function() {
                    display_detail($(this));
                });
                $("#run_status_list_modal").modal('show');
            } 
            else
            {
                ark_notify(result);
            }
            trigger_obj.button("reset");
        }   
    });
}

function display_detail(obj) {
    var detail = obj.parent().parent().attr('detail');
    var run_time = obj.parent().parent().attr('run_time');
    detail = JSON.parse(obj.parent().parent().attr('detail'));
    for(var i in detail) {
        var task_id = detail[i].id;
        var task_name = detail[i].name;
        var status = detail[i].status;
        var color = getStatusColor(status);
        var status_text = getStatusText(status);
        $('#run_status_detail [name="'+task_name+'"] .status_text').html(status_text);
        $('#run_status_detail [name="'+task_name+'"]').attr("class", "small-box bg-"+color);

        var log_exists = "1";
        var log_ctrl = $('#run_status_detail [name=' + task_name + '] [name=log_ctrl]');
        if(status == 0 || status == 5 || status == 6) {
            log_ctrl.text("暂无日志");
            log_exists = "0";
            log_ctrl.attr('onclick', '');
        } else {
            log_ctrl.html('日志 <i class="fa fa-eye"></i>');
        }

        log_ctrl.attr("log_exists", log_exists);
        log_ctrl.attr("run_time", run_time);
        log_ctrl.attr("task_id", task_id);
    }
    
    var notice = new PNotify({
        text: $('#run_status_detail').html(),
        title: run_time + " 日志",
        addclass: 'custom-info',
        width: '500px',
        hide: false,
        buttons: {
            sticker: false
        },
        insert_brs: false,
        type: 'info',
        //left: 'middle',
    });
}

function report_rerun(obj)
{
    $(obj).button('loading');
    var report_id = $("#run_status_list_modal #run_status_input_reportid").val();
    var run_time = $(obj).parent().parent().find("td[name=run_time]").first().text();
    var url = '/statistic/report_run/';
    var post_data = {
        'report_id': report_id,
        'time_type': 'run_time',
        'start_time': run_time};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            $(obj).button('reset');
            ark_notify(result);
        }   
    });
}

function getStatusColor(status) {
    var color = "black";
    if(status == 0 || status == 5 || status == 6) {
        color = "gray";
    } else if(status == 1) {
        color = "#00c0ef";
    } else if(status == 2) {
        color = "green";
    } else if(status == 3) {
        color = "red";
    }
    return color;
}

function getStatusText(status) {
    var disp_str = '未知';
    if(!status) {
        disp_str = '无';
    } else if(status == 0 || status == 5) {
        disp_str = '等待中';
    } else if(status == 1) {
        disp_str = '执行中';
    } else if(status == 2) {
        disp_str = '成功';
    } else if(status == 3) {
        disp_str = '失败';
    } else if(status == 6) {
        disp_str = '被禁止';
    }
    return disp_str;
}


function makeStatusDsp(status, tag) {
    var color = getStatusColor(status);
    var disp_str = getStatusText(status);
    var style_str = 'style="color:'+color+';"';

    return "<" + tag + " name='status'" + style_str + "'>" + disp_str + "<sup class='fa fa-info-circle' data-toggle='tooltip' data-original-title='点击查看日志'></sup></" + tag + ">";
}

function getTaskLog(obj) {
    obj.button('loading');
    var log_exists = obj.attr('log_exists');
    if(log_exists == "0")
        return;

    // view task log
    var run_time = obj.attr('run_time');
    var task_id = obj.attr('task_id');
    var task_name = obj.parent().parent().attr('name');
    var url = "/statistic/report_task_log/" + _report_id + "/";

    var post_data = {'run_time': run_time, 'task_id': task_id};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            obj.button('reset');
            var ret = result;
            if(result.status == 0) {
                ret = {'status': 0, 
                       'title': task_name + ' 日志内容', 
                       'msg':  result.log};
            }
            var notice = new PNotify({
                text: ret.msg,
                title: ret.title ? ret.title : "通知",
                addclass: 'custom-notice',
                width: '500px',
                hide: false,
                buttons: {
                    sticker: false
                },
                type: 'notice',
                //left: 'middle',
            });
        }
    });
}


$(function() {
    // change latest status display text
});
