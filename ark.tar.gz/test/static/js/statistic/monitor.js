$(function() {
    var ele_monitor_list = $("div[name=monitor_list]");
    var ele_monitor_item_view = $("div[name=monitor_item_view]");
    var ele_monitor_item_edit = $("div[name=monitor_item_edit]");
    var html_loading = '<div style="align:center"><i class="fa fa-refresh fa-spin"></i> 加载中...</div>';
    var html_no_monitors = '<span style="align:center">当前报表无监控配置</span>';
    var html_list_error = '<span style="align:center">加载监控列表失败</span>';
    var monitor_num = 0;
    window.Monitor = {
        switch: function(id) {
            var url = "/statistic/switch_monitor/" + _report_id + "/";
            return makeAPost(url, {'monitor_id': id});
        },
        data: function(id) {
            var url = "/statistic/monitor_data/";
            return makeAPost(url, {'monitor_id': id});
        },
        list: function() {
            var url = "/statistic/list_monitor/" + _report_id + "/";
            return makeAPost(url, null);
        },
        add: function(monitor_data) {
            var url = "/statistic/add_monitor/" + _report_id + "/";
            return makeAPost(url, monitor_data);
        },
        update: function(monitor_data) {
            var url = "/statistic/update_monitor/";
            return makeAPost(url, monitor_data);
        },
        delete: function(id) {
            var url = "/statistic/delete_monitor/" + _report_id + "/";
            return makeAPost(url, {'monitor_id': id});
        }
    }
    
    window.MonitorUi = {
        getSelectFeats: function(ele) {
            var feats = [];
            ele.find("input[type=checkbox][name='feat']:checked").each(function() {
                feats.push($(this).val());
            });
            return feats;
        },
        collectData: function(ele) {
            var monitor_id = ele.attr("monitor_id");
            var switch_status = Number(ele.find("input[type=checkbox][name=monitor_switch]").is(':checked'));
            var name = ele.find("input[name=monitor_name]").val();
            var creator = ele.find("input[name=monitor_creator]").val();
            var send_mail = Number(ele.find("input[name=monitor_send_mail]").is(':checked'));
            var send_sms = Number(ele.find("input[name=monitor_send_sms]").is(':checked'));
            var receiver = ele.find("input[name=monitor_receiver]").val();

            var rule = {}
            rule['or_trigger'] = Number(ele.find("[name=monitor_rule] input[type=checkbox][name=or_trigger_switch]").is(':checked'));

            for(key of ["day_diff", "week_diff", "month_diff"]) {
                var value = ele.find("[name=monitor_rule] input[name=" + key + "]").val().trim();
                if(value && !isNaN(value)) {
                    rule[key] = Number(value);
                } else if(value) {
                    ark_notify({'status': 1, 'msg': key + '波动比例必须为数值'});
                    return null;
                }
            }
            var range_1 = ele.find("[name=monitor_rule] input[name=range_1]").val().trim();
            var range_2 = ele.find("[name=monitor_rule] input[name=range_2]").val().trim();
            if(range_1 && !isNaN(range_1) || range_2 && !isNaN(range_2)) {
                if(range_1 && !isNaN(range_1)) {
                    range_1 = Number(range_1);
                } else if(range_1) {
                    ark_notify({'status': 1, 'msg': '范围1必须为数值'});
                    return null;
                }
                if(range_2 && !isNaN(range_2)) {
                    range_2 = Number(range_2);
                } else if(range_2) {
                    ark_notify({'status': 1, 'msg': '范围2必须为数值'});
                    return null;
                }
                rule["range"] = [range_1, range_2];
            } else if (range_1 || range_2) {
                ark_notify({'status': 1, 'msg': '范围必须为数值'});
                return null;
            }

            var receiver = ele.find("select[name=monitor_receiver]").val();
            if(receiver == null) {
                receiver = [];
            }

            var ele_filter = ele.find("[name=monitor_dim_filter]");
            var select_dims = DimFilter.getSelectDims(ele_filter);
            var dim_filter = DimFilter.getDimFilter(ele_filter);

            var ele_feats = ele.find("[name=monitor_feats]");
            var feats = MonitorUi.getSelectFeats(ele_feats);

            var config = {"dim_filter": dim_filter,
                          "select_dims": select_dims,
                          "feats": feats,
                          "rule": rule}

            data = {'monitor_id': monitor_id,
                    'switch': switch_status,
                    'name': name,
                    'creator': creator,
                    'config': JSON.stringify(config),
                    'send_mail': send_mail,
                    'send_sms': send_sms,
                    'receiver': JSON.stringify(receiver),
                   }
            return data;
        },
        initView: function(ele, data, monitor_id) {
            ele.find(".monitor-box").attr("monitor_id", monitor_id);
            ele.find("[name=monitor_name]").html(data['name']);
            ele.find("[name=monitor_creator]").html(data['creator']);
            MonitorUi.initMonitorSwitch(ele, data['switch']);
            ele.find("input[name=monitor_switch]").on('switchChange.bootstrapSwitch', function(event, state) {
                var result = Monitor.switch(monitor_id);
                ark_notify(result);
                if(result.status != 0) {
                    $(this).bootstrapSwitch('state', !state, true);
                }
            });

            var config = data['config'];
            if(typeof config === 'string') {
                config = JSON.parse(config);
            }
            var feat_str = '';
            if(config['feats']) {
                for(var feat of config['feats']) {
                    if(feat_str != '') {
                        feat_str += '、';
                    }
                    feat_str += _column_dsp[feat];
                }
            }
            ele.find("[name=monitor_feats]").html(feat_str);

            var str = '';
            if(config['select_dims']) {
                for(var item of config['select_dims']) {
                    if(str != '') {
                        str += '、';
                    }
                    str += _column_dsp[item];
                }
            }
            if(!str) {
                str = '无';
            }
            ele.find("[name=monitor_select_dims]").html(str);

            var str = '';
            if(config['dim_filter']) {
                for(var item of config['dim_filter']) {
                    if(str != '') {
                        str += '；';
                    }
                    var dim = _column_dsp[item[0]];
                    var op = _sql_filter_dsp[item[1]];
                    var value = item[2];
                    str += dim + " " + op + " " + value;
                }
            }
            if(!str) {
                str = '无';
            }
            ele.find("[name=monitor_dim_filter]").html(str);

            var str = '';
            var rule = config['rule'];
            var trigger_str = '';
            if(!rule || rule["or_trigger"]) {
                trigger_str = " <b>或</b> ";
            } else {
                trigger_str = " <b>且</b> ";
            }
            for(var item in rule) {
                var value = rule[item];
                if(!value) {
                    continue;
                }
                if(str != "") {
                    str += trigger_str;
                }
                if(item == "day_diff") {
                    str += "日环比 >" + value + "%";
                }
                if(item == "week_diff") {
                    str += "周同比 >" + value + "%";
                }
                if(item == "month_diff") {
                    str += "月同比 >" + value + "%";
                }
                if(item == "range") {
                    str += "值范围不在 " + value[0] + " ~ " + value[1];
                }
            }
            str = "触发条件：" + str;
            ele.find("[name=monitor_rule]").html(str);

            var str = '';
            if(data['send_mail']) {
                str += '邮件 ';
            }
            if(data['send_sms']) {
                str += '短信 ';
            }
            ele.find("[name=monitor_send_type]").html(str);

            var str = '';
            var receiver = data['receiver'];
            if(typeof receiver === 'string') {
                receiver = JSON.parse(receiver);
            }
            if(receiver) {
                for(var id of receiver) {
                    str += _all_users[id] + " ";
                }
            }
            ele.find("[name=monitor_receiver]").html(str);
            
        },
        initEdit: function(ele, data) {
            var receiver = ele.find("select[name=monitor_receiver]");
            var selected_users = !data ? [_curr_user_id.toString()] : data['receiver'];
            MultiUserSelector.init(receiver, _all_users, selected_users);
            DimFilter.initDimSelector(ele, false, true);

            var trigger_status = data && data['config']['rule']['or_trigger'] == 0 ? false : true;
            MonitorUi.initOrTriggerSwitch(ele, trigger_status);
            if(!data) {
                ele.find("[name=monitor_name]").val('规则_' + Date.now());
                ele.find("[name=monitor_name]").select();
                return;
            }

            ele.find("input[type=checkbox][name=monitor_switch]").prop('checked', data['switch']);

            ele.find(".monitor-box").attr("monitor_id", data['id']);
            ele.find("[name=monitor_name]").val(data['name']);
            ele.find("[name=monitor_creator]").val(data['creator']);

            var config = data['config'];
            for(var item of config['feats']) {
                ele.find("[name=monitor_feats] input[type=checkbox][value=" + item + "]").prop("checked", true);
            }

            ele.find("[name=monitor_dim_filter] input[type=checkbox]").each(function() {
                var dim = $(this).attr('value');
                if(-1 == config['select_dims'].indexOf(dim)) {
                    $(this).prop('checked', false);
                }
            });

            for(var item of config['dim_filter']) {
                var dim = item[0];
                var filter = item[1];
                var value = item[2];
                ele.find("[name=monitor_dim_filter] select[name=filter_" + dim + "]").val(filter);
                if(filter == 'is_null' || filter == 'is_not_null') {
                    ele.find("[name=monitor_dim_filter] [name=filter_value_" + dim + "]").prop('disabled', true);
                } else {
                    ele.find("[name=monitor_dim_filter] [name=filter_value_" + dim + "]").select2("data", {id:value, text:value});
                }
            }

            var rule = config['rule'];
            for(var key of ['day_diff', 'week_diff', 'month_diff']) {
                var value = rule[key];
                if(value) {
                    ele.find("[name=monitor_rule] input[name=" + key + "]").val(value);
                }
            }
            var range = rule['range'];
            if(range) {
                var range_1 = range[0];
                ele.find("[name=monitor_rule] input[name=range_1]").val(range_1);
                var range_2 = range[1];
                ele.find("[name=monitor_rule] input[name=range_2]").val(range_2);
            }
            
            var ck_status = data['send_mail'] ? true : false;
            ele.find("input[type=checkbox][name=monitor_send_mail]").prop("checked", ck_status);

            var ck_status = data['send_sms'] ? true : false;
            ele.find("input[type=checkbox][name=monitor_send_sms]").prop("checked", ck_status);

            

        },
        add: function() {
            var ele = ele_monitor_list.prepend(ele_monitor_item_edit.html());
            MonitorUi.initEdit(ele);
        },
        save: function(ele) {
            var box = ele.parents(".monitor-box").first();
            var monitor_data = MonitorUi.collectData(box);
            if(!monitor_data) {
                return;
            }

            var monitor_id = monitor_data["monitor_id"];
            if(monitor_id == 0) {
                result = Monitor.add(monitor_data);
            } else {
                result = Monitor.update(monitor_data);
            }

            if(result.status == 0) {
                var monitor_id = result.data.id;
                var view_box = $(ele_monitor_item_view.html());
                box.parent().replaceWith(view_box);
                MonitorUi.initView(view_box, monitor_data, monitor_id);
            }
            ark_notify(result);
        },
        cancel: function(ele) {
            var box = ele.parents(".monitor-box").first();
            var monitor_id = box.attr("monitor_id");
            if(monitor_id == 0) {
                box.parent().remove();
            } else {
                var result = Monitor.data(monitor_id);
                var view_box = $(ele_monitor_item_view.html());
                box.parent().replaceWith(view_box);
                MonitorUi.initView(view_box, result.data, monitor_id);
            }
        },
        edit: function(ele) {
            var box = ele.parents(".monitor-box").first();
            var monitor_id = box.attr("monitor_id");
            var result = Monitor.data(monitor_id);
            if(result.status == 0) {
                var monitor_id = result.data.id;
                var edit_box = $(ele_monitor_item_edit.html());
                box.parent().replaceWith(edit_box);
                MonitorUi.initEdit(edit_box, result.data);
            } else {
                ark_notify(result);
            }
        },
        delete: function(ele) {
            var box = ele.parents(".monitor-box").first();
            var monitor_id = box.attr("monitor_id");
            if(monitor_id == 0) {
                box.parent().remove();
            } else {
                (new PNotify({
                    title: '删除确认',
                    text: "确定删除该监控？",
                    hide: false,
                    confirm: {
                        confirm: true,
                        buttons: [{
                            text: '确认',
                            click: function(notice){
                                result = Monitor.delete(monitor_id);
                                if(result.status == 0) {
                                    box.parent().remove();
                                }
                                ark_notify(result);
                                notice.remove();
                            }}, {
                                text: '取消',
                            }]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    },
                    addclass: 'stack-modal',
                    stack: {'dir1': 'down', 'dir2': 'left', 'modal': true},
                    type: 'notice',
                }));
            }
        },
        list: function() {
            ele_monitor_list.html(html_loading);
            result_data = Monitor.list();
            if(result_data.status != 0) {
                ele_monitor_list.html(html_list_error);
            } else {
                var monitor_num = result_data.monitors.length;
                if(monitor_num == 0) {
                    ele_monitor_list.html(html_no_monitors);
                } else {
                    ele_monitor_list.html('');
                    for(var i = 0; i < monitor_num; i++) {
                        var monitor_data = result_data.monitors[i];
                        var monitor_id = monitor_data.id;
                        ele_monitor_list.append(ele_monitor_item_view.html());
                        var ele = ele_monitor_list.children().last();
                        MonitorUi.initView(ele, monitor_data, monitor_id);
                    }
                }
            }
        },
        initMonitorSwitch: function(ele, state) {
            ele_switch = ele.find("input[name=monitor_switch]");
            ele_switch.bootstrapSwitch({
                "size": "mini",
                "onText": "开",
                "offText": "关",
                "state": state});
        },
        initOrTriggerSwitch: function(ele, state) {
            ele_switch = ele.find("input[name=or_trigger_switch]");
            ele_switch.bootstrapSwitch({
                "size": "mini",
                "onText": "或",
                "offText": "且",
                "state": state});
        },
    }

    $("button[name=add_monitor]").click(function() {
        MonitorUi.add();
    });

    MonitorUi.list();
});

