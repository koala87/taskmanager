$(function() {
    var data_time = "";
    var graph_name = '散点图';
    var display_zone_id = 'feat_graph_scatter';
    var display_zone = $("#" + display_zone_id);
    var display_zone_ele = document.getElementById(display_zone_id);
    var chart = null;
    var box = $(".feat-table-box[name=scatter]");
    var time_selector = $(".feat-table-box[name=scatter] input[name=feat_time_selector]");

    window.FeatGraphScatter = {
        get_data_time: function() {
            return $(".feat-table-box[name=scatter] input[name=feat_time_selector]").val();
        },
        get_data : function(callback){
            var url = "/statistic/feat_graph_scatter/" + _report_id + "/";
            data_time = FeatGraphScatter.get_data_time()
            if(data_time == "") {
                data_time = TimeRange.get_pre_date(1);
            }

            data = {'data_time': data_time,
                    'select_dims': _select_dims,
                    'dim_filter': JSON.stringify(_dim_filter),
                    'top_n': $(".filter-panel[name=scatter] [name=top_n]").val(),
                    'order_feat': $(".filter-panel[name=scatter] [name=order_feat]").val(),}
            makeAPost(url, data, true, FeatGraphScatter.callback);
        },
        // 初始化过滤面板
        init_filter: function() {
            // 初始化x、y轴选择的指标
            var y = $(".filter-panel[name=scatter] [name=y_feat]");
            if(_basic_feats.length > 1) {
                y.val(_basic_feats[1]);
            } else if(_ext_feats.length > 1) {
                y.val(_ext_feats[1]);
            }
        },
        // 获取要展现的指标，最多展现两个指标（对应两个坐标轴）
        get_dsp_feats: function() {
            var x_feat = $(".filter-panel[name=scatter] [name=x_feat]").val();
            var y_feat = $(".filter-panel[name=scatter] [name=y_feat]").val();
            return [x_feat, y_feat];
        },
        make_option: function(data) {
            if(!data) {
                data = {};
            }
            var legend_data = [''];
            var series_data = [];
            var dsp_feats = FeatGraphScatter.get_dsp_feats();
            var x_feat = dsp_feats[0];
            var y_feat = dsp_feats[1];

            for(var dim in data) {
                var dim_data = [];
                for(var i in data[dim]) {
                    var kv = data[dim][i];
                    dim_data.push([kv[x_feat], kv[y_feat]]);
                }
                legend_data.push(dim);
                series_data.push({
                    name: dim,
                    type: 'scatter',
                    data: dim_data});
            }
            
            var title = _column_dsp[x_feat] + "（" + x_feat + "） " + _column_dsp[y_feat] + "（" + y_feat + "）";
            var option = StatEcharts.get_scatter_option(
                title, legend_data, series_data)
            return option;
        },
        display_data: function(data) {
            var option = FeatGraphScatter.make_option(data);
            chart.setOption(option);
            chart.hideLoading();
        },
        refresh: function() {
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/scatter',
            ], function(ec) {
                chart = ec.init(display_zone_ele, 'macarons');
            });

            if(chart) {
                chart.showLoading();
            }
            result = FeatGraphScatter.get_data();
        },
        callback: function(result) {
            if(result.status != 0) {
                result.msg = graph_name + '：' + result.msg;
                ark_notify(result);
            }
            FeatGraphScatter.display_data(result.data);
        },
    }

    FeatGraphScatter.init_filter();
    $("#btn_scatter_query").click(
        function() {
            box.parent().removeClass('filter-panel-open');
            FeatGraphScatter.refresh();
        });
    time_selector.change(function() {
        box.parent().removeClass('filter-panel-open');
        FeatGraphScatter.refresh();
    });
});
