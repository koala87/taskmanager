$(function() {
    var ele_subscription_list = $("div[name=subscription_list]");
    var ele_subscription_item_view = $("div[name=subscription_item_view]");
    var ele_subscription_item_edit = $("div[name=subscription_item_edit]");
    var html_loading = '<div style="align:center"><i class="fa fa-refresh fa-spin"></i> 加载中...</div>';
    var html_no_subscriptions = '<span style="align:center">当前报表无订阅配置</span>';
    var html_list_error = '<span style="align:center">加载订阅列表失败</span>';
    var subscription_num = 0;
    window.Subscription = {
        switch: function(id) {
            var url = "/statistic/switch_subscription/" + _report_id + "/";
            return makeAPost(url, {'subscription_id': id});
        },
        data: function(id) {
            var url = "/statistic/subscription_data/";
            return makeAPost(url, {'subscription_id': id});
        },
        list: function() {
            var url = "/statistic/list_subscription/" + _report_id + "/";
            return makeAPost(url, null);
        },
        add: function(subscription_data) {
            var url = "/statistic/add_subscription/" + _report_id + "/";
            return makeAPost(url, subscription_data);
        },
        update: function(subscription_data) {
            var url = "/statistic/update_subscription/";
            return makeAPost(url, subscription_data);
        },
        delete: function(id) {
            var url = "/statistic/delete_subscription/" + _report_id + "/";
            return makeAPost(url, {'subscription_id': id});
        },
        subscribe: function(ele, id) {
            var url = "/statistic/subscribe/";
            return makeAPost(url, {'subscription_id': id}, true, SubscriptionUi.finishSubscribe, ele);
        }
    }
    
    window.SubscriptionUi = {
        getSelectFeats: function(ele) {
            var feats = [];
            ele.find("input[type=checkbox][name='feat']:checked").each(function() {
                feats.push($(this).val());
            });
            return feats;
        },
        collectData: function(ele) {
            var subscription_id = ele.attr("id");
            var switch_status = Number(ele.find("[type=checkbox][name=switch]").is(':checked'));
            var name = ele.find("[name=name]").val();
            var creator = ele.find("[name=creator]").val();

            var time_range = ele.find("input:radio:checked[name=time_range]").val().trim();
            var ct_time = ele.find("[name=ct_time]").val();
            var table_caption = ele.find("[name=table_caption]").val();
            var table_feat_order = ele.find("[name=table_feat_order]").val().trim();
            var table_comment = ele.find("textarea[name=table_comment]").val().trim();
            var mail_conf = {"table_caption": table_caption,
                             "table_feat_order": table_feat_order,
                             "table_comment": table_comment}

            var receiver = ele.find("[name=receiver]").val();
            if(receiver == null) {
                receiver = [];
            }
            var receive_mails_config = ele.find("[name=receive_mails]").val();
            var receive_mails = [];
            for(var item of receive_mails_config.split('\n')) {
                item = item.trim();
                if(item) {
                    receive_mails.push(item);
                }
            }

            var ele_filter = ele.find("[name=dim_filter]");
            var select_dims = DimFilter.getSelectDims(ele_filter);
            var dim_filter = DimFilter.getDimFilter(ele_filter);

            var ele_feats = ele.find("[name=feats]");
            var feats = SubscriptionUi.getSelectFeats(ele_feats);

            var config = {"time_range": time_range,
                          "dim_filter": dim_filter,
                          "select_dims": select_dims,
                          "feats": feats,
                          "mail_conf": mail_conf}

            data = {'subscription_id': subscription_id,
                    'switch': switch_status,
                    'name': name,
                    'creator': creator,
                    'config': JSON.stringify(config),
                    'ct_time': ct_time,
                    'receiver': JSON.stringify(receiver),
                    'receive_mails': JSON.stringify(receive_mails),
                   }
            return data;
        },
        initView: function(ele, data, subscription_id) {
            ele.find(".subscription-box").attr("id", subscription_id);
            ele.find("[name=name]").html(data['name']);
            ele.find("[name=creator]").html(data['creator']);
            if(data['ct_time']) {
                ele.find("[name=ct_time]").html(data['ct_time']);
            }
            SubscriptionUi.initSubscriptionSwitch(ele, data['switch']);

            ele.find("[name=switch]").on('switchChange.bootstrapSwitch', function(event, state) {
                var result = Subscription.switch(subscription_id);
                ark_notify(result);
                if(result.status != 0) {
                    $(this).bootstrapSwitch('state', !state, true);
                }
            });

            var config = data['config'];
            if(typeof config === 'string') {
                config = JSON.parse(config);
            }

            var time_range = config['time_range'];
            var time_range = time_range == '1day' ?
                '单天' : time_range == '1week' ?
                '一周' : time_range == '15days' ?
                '15天' : time_range == '1month' ?
                '一个月' : '不支持的时间配置';
            ele.find("[name=time_range]").html(time_range);

            var feat_str = '';
            if(config['feats']) {
                for(var feat of config['feats']) {
                    if(feat_str != '') {
                        feat_str += '、';
                    }
                    feat_str += _column_dsp[feat];
                }
            }
            ele.find("[name=feats]").html(feat_str);

            var str = '';
            if(config['select_dims']) {
                for(var item of config['select_dims']) {
                    if(str != '') {
                        str += '、';
                    }
                    str += _column_dsp[item];
                }
            }
            if(!str) {
                str = '无';
            }
            ele.find("[name=select_dims]").html(str);

            var str = '';
            if(config['dim_filter']) {
                for(var item of config['dim_filter']) {
                    if(str != '') {
                        str += '；';
                    }
                    var dim = _column_dsp[item[0]];
                    var op = _sql_filter_dsp[item[1]];
                    var value = item[2];
                    str += dim + " " + op + " " + value;
                }
            }
            if(!str) {
                str = '无';
            }
            ele.find("[name=dim_filter]").html(str);

            var mail_conf = config['mail_conf']

            var table_caption = mail_conf['table_caption'] ? mail_conf['table_caption'] : '空';
            ele.find("[name=table_caption]").html(table_caption);

            var table_feat_order = mail_conf['table_feat_order'];
            if(table_feat_order && table_feat_order.trim()) {
                ele.find("[name=table_feat_order]").html(table_feat_order.trim());
            }

            var table_comment = mail_conf['table_comment'] ? mail_conf['table_comment'] : '空';
            ele.find("[name=table_comment]").html(table_comment);

            var str = '';
            var receiver = data['receiver'];
            if(typeof receiver === 'string') {
                receiver = JSON.parse(receiver);
            }
            if(receiver) {
                for(var id of receiver) {
                    str += _all_users[id] + " ";
                }
            }
            ele.find("[name=receiver]").html(str);

            var receive_mails = data['receive_mails'];
            if(typeof receive_mails === 'string') {
                receive_mails = JSON.parse(receive_mails);
            }
            if(receive_mails.length == 0) {
                receive_mails = '无';
            } else {
                receive_mails = receive_mails.join(' ');
            }
            ele.find("[name=receive_mails]").html(receive_mails);
        },
        initDimFilter: function(ele, select_dims, dim_filter) {
            if(select_dims) {
                ele.find("[name=dim_filter] input[type=checkbox]").each(function() {
                    var dim = $(this).attr('value');
                    if(-1 == select_dims.indexOf(dim)) {
                        $(this).prop('checked', false);
                    }
                });
            }

            if(dim_filter) {
                for(var item of dim_filter) {
                    var dim = item[0];
                    var filter = item[1];
                    var value = item[2];
                    ele.find("[name=dim_filter] select[name=filter_" + dim + "]").val(filter);
                    if(filter == 'is_null' || filter == 'is_not_null') {
                        ele.find("[name=dim_filter] [name=filter_value_" + dim + "]").prop('disabled', true);
                    } else {
                        ele.find("[name=dim_filter] [name=filter_value_" + dim + "]").select2("data", {id:value, text:value});
                    }
                }
            }
        },
        initEdit: function(ele, data) {
            console.log(data);
            var receiver = ele.find("select[name=receiver]");
            var selected_users = !data ? [_curr_user_id.toString()] : data['receiver'];
            MultiUserSelector.init(receiver, _all_users, selected_users);
            DimFilter.initDimSelector(ele, false, true);
            if(!data) {
                ele.find("[name=name]").val('${report_name}_订阅名称(${run_time})');
                ele.find("[name=name]").select();
                ele.find("[name=creator]").val(_all_users[_curr_user_id]);
                SubscriptionUi.initDefaultFeats(ele);

                var time_range = _all_dims.length > 0 ? '1day' : '1week';
                ele.find("input:radio[name=time_range][value=" + time_range + "]").prop('checked', true);
                return;
            }

            ele.find("input[type=checkbox][name=switch]").prop('checked', data['switch']);

            ele.find(".subscription-box").attr("id", data['id']);
            ele.find("[name=name]").val(data['name']);
            ele.find("[name=ct_time]").val(data['ct_time']);
            ele.find("[name=creator]").val(data['creator']);

            var config = data['config'];
            for(var item of config['feats']) {
                ele.find("[name=feats] input[type=checkbox][value=" + item + "]").prop("checked", true);
            }

            var select_dims = config['select_dims'];
            var dim_filter = config['dim_filter'];
            SubscriptionUi.initDimFilter(ele, select_dims, dim_filter);

            var mail_conf = config['mail_conf'];
            var time_range = config['time_range'];
            ele.find("input:radio[name=time_range][value=" + time_range + "]").prop('checked', true);

            ele.find("[name=table_caption]").val(mail_conf['table_caption']);
            ele.find("[name=table_feat_order]").val(mail_conf['table_feat_order']);
            ele.find("[name=table_comment]").val(mail_conf['table_comment']);

            var receive_mails = data['receive_mails'].join('\n');
            ele.find("[name=receive_mails]").val(receive_mails);
        },
        add: function() {
            var ele = ele_subscription_list.prepend(ele_subscription_item_edit.html());
            console.log(ele);
            SubscriptionUi.initEdit(ele);
            return ele;
        },
        save: function(ele) {
            var box = ele.parents(".subscription-box").first();
            var subscription_data = SubscriptionUi.collectData(box);
            if(!subscription_data) {
                return;
            }

            var subscription_id = subscription_data["subscription_id"];
            if(subscription_id == 0) {
                result = Subscription.add(subscription_data);
            } else {
                result = Subscription.update(subscription_data);
            }

            if(result.status == 0) {
                var subscription_id = result.data.id;
                var view_box = $(ele_subscription_item_view.html());
                box.parent().replaceWith(view_box);
                SubscriptionUi.initView(view_box, subscription_data, subscription_id);
            }
            ark_notify(result);
        },
        cancel: function(ele) {
            var box = ele.parents(".subscription-box").first();
            var subscription_id = box.attr("id");
            if(subscription_id == 0) {
                box.parent().remove();
            } else {
                var result = Subscription.data(subscription_id);
                var view_box = $(ele_subscription_item_view.html());
                box.parent().replaceWith(view_box);
                SubscriptionUi.initView(view_box, result.data, subscription_id);
            }
        },
        edit: function(ele) {
            var box = ele.parents(".subscription-box").first();
            var subscription_id = box.attr("id");
            var result = Subscription.data(subscription_id);
            if(result.status == 0) {
                var subscription_id = result.data.id;
                var edit_box = $(ele_subscription_item_edit.html());
                box.parent().replaceWith(edit_box);
                SubscriptionUi.initEdit(edit_box, result.data);
            } else {
                ark_notify(result);
            }
        },
        finishSubscribe: function(result, ele) {
            ele.button('reset');
            ark_notify(result);
        },
        subscribe: function(ele) {
            var box = ele.parents(".subscription-box").first();
            var subscription_id = box.attr("id");
            if(subscription_id == 0) {
                ark_notify({'status': 1, 'msg': '无效的订阅id'})
            } else {
                ele.button('loading');
                Subscription.subscribe(ele, subscription_id);
            }
        },
        delete: function(ele) {
            var box = ele.parents(".subscription-box").first();
            var subscription_id = box.attr("id");
            if(subscription_id == 0) {
                box.parent().remove();
            } else {
                (new PNotify({
                    title: '删除确认',
                    text: "确定删除该订阅？",
                    hide: false,
                    confirm: {
                        confirm: true,
                        buttons: [{
                            text: '确认',
                            click: function(notice){
                                result = Subscription.delete(subscription_id);
                                if(result.status == 0) {
                                    box.parent().remove();
                                }
                                ark_notify(result);
                                notice.remove();
                            }}, {
                                text: '取消',
                            }]
                    },
                    buttons: {
                        closer: false,
                        sticker: false
                    },
                    history: {
                        history: false
                    },
                    addclass: 'stack-modal',
                    stack: {'dir1': 'down', 'dir2': 'left', 'modal': true},
                    type: 'notice',
                }));
            }
        },
        list: function() {
            ele_subscription_list.html(html_loading);
            result_data = Subscription.list();
            if(result_data.status != 0) {
                ele_subscription_list.html(html_list_error);
            } else {
                var subscription_num = result_data.subscriptions.length;
                if(subscription_num == 0) {
                    ele_subscription_list.html(html_no_subscriptions);
                } else {
                    ele_subscription_list.html('');
                    for(var i = 0; i < subscription_num; i++) {
                        var subscription_data = result_data.subscriptions[i];
                        var subscription_id = subscription_data.id;
                        ele_subscription_list.append(ele_subscription_item_view.html());
                        var ele = ele_subscription_list.children().last();
                        SubscriptionUi.initView(ele, subscription_data, subscription_id);
                    }
                }
            }
        },
        initSubscriptionSwitch: function(ele, state) {
            ele_switch = ele.find("input[name=switch]");
            ele_switch.bootstrapSwitch({
                "size": "mini",
                "onText": "开",
                "offText": "关",
                "state": state});
        },
        initDefaultFeats: function(ele) {
            ele.find("[name=feats] input[type=checkbox]").each(function() {
                var feat = $(this).val();
                if(_column_show_hide[feat]) {
                    $(this).prop("checked", true);
                }
            });
        }
    }

    $("button[name=add_subscription]").click(function() {
        SubscriptionUi.add();
    });

    SubscriptionUi.list();
    if(_init_select_dims || _init_dim_filter || _init_time_range) {
        console.log(_init_dim_filter);
        console.log(_init_select_dims);
        console.log(_init_time_range);
        ele = SubscriptionUi.add();
        SubscriptionUi.initDimFilter(ele, _init_select_dims, _init_dim_filter);

        if(_init_time_range) {
            ele.find("input:radio[name=time_range][value=" + _init_time_range + "]").prop('checked', true);
        }
    }
});

