$(function() {
    window.ReportFilter = {
        initFilter: function(refresh) {
            var btn_refresh = $("[name=btn_refresh_search_reports]");
            btn_refresh.button("loading");
            ReportFilter.getReports(function(result) {
                if(result.status == 0) {
                    data = [];
                    var report_id = $.urlParam("report_id") != undefined ? $.urlParam("report_id") : 0;
                    for(var i in result.reports) {
                        var name = '项目：' + result.reports[i].name;
                        var reports = result.reports[i].reports;
                        var report_data = [];
                        for(var j in reports) {
                            report_data.push({id: j, text: reports[j]});
                        }
                        data.push({'text': name, 'children': report_data});
                    }

                    var ele = $("[name=header_report_filter]");
                    ele.select2(
                        {data: data}).on('change', function(e) {
                            if(report_id != $(this).val()) {
                                window.location = '/statistic/report_index/?report_id=' 
                                    + $(this).val();
                            }
                            
                        });
                    if(report_id) {
                        ele.select2("val", report_id);
                    }
                }
                btn_refresh.button("reset");
            }, refresh);
        },
        getReports: function(callback, refresh) {
            var url = "/statistic/search_reports/";
            if(refresh) {
                url += "?refresh=1";
            }
            makeAPost(url, {}, true, callback);
        }
    }

    ReportFilter.initFilter();
    $("[name=btn_refresh_search_reports]").click(function() {
        ReportFilter.initFilter(true);
    });    
});
