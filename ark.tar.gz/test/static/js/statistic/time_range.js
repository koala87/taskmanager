$(function() {
    var daysOfWeek = [
        "日", 
        "一", 
        "二", 
        "三", 
        "四", 
        "五", 
        "六"
    ];
    var monthNames= [
        "一月",  
        "二月",  
        "三月",  
        "四月",
        "五月",
        "六月",
        "七月",
        "八月",
        "九月",
        "十月",
        "十一月",
        "十二月"
    ];
    window.TimeRange = {
        get_pre_time: function(day_offset, hour_offset) {
            var date = new Date();
            date.setDate(date.getDate() - day_offset)
            date.setHours(date.getHours() - hour_offset)
            return moment(date).format(time_format);
        },

        get_pre_date: function(offset) {
            var date = new Date();
            date.setDate(date.getDate() - offset)
            return moment(date).format(time_format);
        },

        get_pre_month: function(offset) {
            var date = new Date();
            date.setMonth(date.getMonth() - offset)
            return moment(date).format(time_format);
        },

        init_feat_time_range: function(obj) {
            if(_report_cycle == 'hour') {
                start_time = TimeRange.get_pre_time(1, _report_delay);
                end_time = TimeRange.get_pre_time(0, _report_delay);
            } else {
                start_time = TimeRange.get_pre_time(_report_delay + 6, 0);
                end_time = TimeRange.get_pre_time(_report_delay, 0);
            }

            yesterday = TimeRange.get_pre_date(1);
            last_week = TimeRange.get_pre_date(7);
            last_month = TimeRange.get_pre_month(1);
            obj.daterangepicker({
                "timePicker": true,
                "timePicker24Hour": true,
                "timePickerIncrement": 60,
                "ranges": {
                    "昨天": [
                        yesterday,
                        end_time
                    ],
                    "近一周": [
                        last_week,
                        end_time
                    ],
                    "近一个月": [
                        last_month,
                        end_time
                    ],
                },
                "locale": {
                    "format": time_format,
                    "separator": " 到 ",
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "customRangeLabel": "自定义时间",
                    "daysOfWeek": daysOfWeek,
                    "monthNames": monthNames,
                    "firstDay": 1,
                },
                "startDate": start_time,
                "endDate": end_time,
                "opens": "right"
            }, function(start, end, label) {
            });
        },
        init_feat_time: function(obj) {

            if(_report_cycle == 'hour') {
                start_time = TimeRange.get_pre_time(0, _report_delay);
            } else {
                start_time = TimeRange.get_pre_time(_report_delay, 0);
            }
            return obj.daterangepicker({
                "timePicker": true,
                "timePicker24Hour": true,
                "timePickerIncrement": 60,
                "singleDatePicker": true,
                "locale": {
                    "format": time_format,
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "daysOfWeek": daysOfWeek,
                    "monthNames": monthNames,
                    "firstDay": 1,
                },
                "startDate": start_time,
                "opens": "right",
            }, function(start, end, label) {
            });
        }
    }
})