var formatDate = function (date) {
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    var d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    return y + '/' + m + '/' + d;
};
$(function(){
    var end_date = formatDate(new Date());
    var start_date = formatDate(new Date(new Date().getTime()-86400000*3));
    $('#search_op_time').daterangepicker({
        startDate:start_date,
        endDate:end_date});
    get_op_log_list();
    $("#search_op_type").on('change', function(){
        get_op_log_list();
    });
    $("#search_op_time").on('change', function(){
        get_op_log_list();
    });
    $("#search_op_time").on('keydown', function(event){
        var event=event||window.event;
        if(event.keyCode==13||event.which==13){
            get_op_log_list();
        }
    });
    $("#search_op_report_name").on('keydown', function(event){
        var event=event||window.event;
        if(event.keyCode==13||event.which==13){
            get_op_log_list();
        }
    });
    $("#search_op_username").on('keydown', function(event){
        var event=event||window.event;
        if(event.keyCode==13||event.which==13){
            get_op_log_list();
        }
    });
    $("#search_op_desc").on('keydown', function(event){
        var event=event||window.event;
        if(event.keyCode==13||event.which==13){
            get_op_log_list();
        }
    });
});
function get_op_log_list()
{
    var project_id = $("#inout_project_id").val();
    var url = '/statistic/report_op_log/';
    var post_data = {'project_id':project_id};
    if($("#search_op_type").val())
    {
        post_data['type'] = $("#search_op_type").val().trim();
    }
    if($("#search_op_time").val())
    {
        var period = $("#search_op_time").val().split('-');
        if(period.length > 1)
        {
            var start_time = period[0].trim().replace(new RegExp(/\//g), '');
            var end_time = period[1].trim().replace(new RegExp(/\//g), '');
            post_data['start_time'] = start_time;
            post_data['end_time'] = end_time;
        }
    }
    if($("#search_op_report_name").val())
    {
        post_data['report_name'] = $("#search_op_report_name").val().trim();
    }
    if($("#search_op_username").val())
    {
        post_data['operator_name'] = $("#search_op_username").val().trim();
    }
    if($("#search_op_desc").val())
    {
        post_data['content'] = $("#search_op_desc").val().trim();
    }
    //post_data['cycle'] = $(".exec_cycle:checked").val();
    //post_data['name'] = $("#report_name").val().trim();
    //post_data['config'] = JSON.stringify(get_odps_sql_config());
    //post_data['graphs'] = JSON.stringify(get_odps_sql_graphs());
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            var html = '<table class="table table-bordered table-hover" id="report_op_log_table" style="table-layout: fixed;">\
                            <thead>\
                                <td style="width:3%;">#</td>\
                                <td style="width:5%;">类型</td>\
                                <td style="width:5%;">用户</td>\
                                <td style="width:35%;">描述</td>\
                                <td style="width:8%;">操作时间</td>\
                            </thead>\
                            <tbody>';
            if(result.status == 0)
            {
                for(var i=0;i<result.data.length;i++)
                {
                    html += '<tr><td>'+result.data[i].no+'</td><td>'+result.data[i].type+
                            '</td><td>'+result.data[i].operator+'</td><td><a href="javascript:void(0)" onclick="show_all_desc(this)">'+result.data[i].content+'</a>'+
                            '</td><td>'+result.data[i].create_time+'</td></tr>';
                }
            }
            else
            {
                ark_notify(result);
            }
            html += '</tbody></table>';
            $("#table_container").html(html);
            $('#report_op_log_table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": false,
                "info": true,
                "autoWidth": false
            });
        }
    });
}
function show_all_desc(obj)
{
    $("#desc_full_modal .modal-body p").html($(obj).text().replace(new RegExp(/\n/), '</br>'));
    $("#desc_full_modal").modal('show');
}
