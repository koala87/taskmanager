report_table = null;
function view_odps_sql(ele) {
    (new PNotify({
        title: 'odps sql',
        text: ele.attr('odps_sql'),
        type: 'notice',
        addclass: 'custom-content',
        height: '100px',
        width: '600px',
        opacity: 0.8,
    }));
};


$(function(){

    report_table = $('#report_list').DataTable({
        "processing": true,
        "serverSide": true,
        "bLengthChange": false,
        "bPaginate": false,
        "order": [],
        "dom": '<"top"i>rt<"bottom"flp><"clear">',
        "fnInfoCallback": function( oSettings, iStart, iEnd, iMax, iTotal, sPre ) {
            return "共 " + iTotal + " 条记录";
        },
        "ajax": {
            "url": "/statistic/reports_for_table/",
            "type": "POST",
            "data": function(d) {
                d.table_name = $("[name=table_name]").val();
                d.online_only = $("[name=ck_online_only]").is(':checked') ? 1 : 0;
                d.cycle = $("[name=report_cycle]").val();
            }
        },
        "oLanguage": {
            "sEmptyTable": "查无结果",
            "sZeroRecords": "查无结果",
            "sProcessing": "查询中 ......",
            "oPaginate": {"sPrevious": "上一页", "sNext": "下一页"},
        },
        "columns": [
            {
                "bSortable": false,
                "render":function(data, type, full){
                    return "<input type='checkbox' style='margin-left:10px;' name='report_checkbox' report_id='" + full.id + "' />";
                }
            },
            {
                "data": "name",
                "bSortable": false,
                "render": function(data, type, full) {
                    return "<a target='_blank' href='/statistic/report_index/?report_id=" + full.id + "'>" + full.name + "</a>";
                }
            },
            {
                "data": "project",
                "bSortable": false,
            },
            {
                "data": "username_dsp",
                "bSortable": false,
            },
            {
                "data": "cycle",
                "bSortable": false,
                "render": function(data, type, full) {
                    return data == 'day' ? '天级' : '小时级';
                }
            },
            {
                "data": "id",
                "bSortable": false,
                "render": function(data, type, full) {
                    var odps_sql = full.config.odps_sql.replace(/'/g, '&quot;');
                    return "<a href='#' odps_sql='" + odps_sql + "' onclick='view_odps_sql($(this))'>查看sql</a>";
                }
            }
        ],
    });

    $("#report_list_filter").hide();
    $("[name=btn_query]").click(function() {
        report_table.draw();
    });
    $('[name=report_checkbox_all]').on('change',function(){
        if($(this).is(':checked')){
            $('[name=report_checkbox]').each(function(){
                $(this).prop('checked',true);
            });
        } else{
            $('[name=report_checkbox]').each(function(){
                $(this).prop('checked',false);
            });
        }
    });

    document.onkeydown = function(e){
        if(!e){
            e = window.event;
        }
        if((e.keyCode || e.which) == 13){
            $("[name=btn_query]").trigger('click');
        }
    }

    _report_cycle = 'day';
    _report_delay = 1;
    time_format = 'YYYYMMDDHH';
    $("[name=feat_time_range_selector]").each(
        function() {
            TimeRange.init_feat_time_range($(this));
        });

    
    var run_time_input = $('[name=feat_time_range_selector]');
    var run_time_picker = run_time_input.data('daterangepicker');
    run_time_input.on('apply.daterangepicker', function(ev, picker) {
        var start_time = run_time_picker.startDate.format(time_format);
        var end_time = run_time_picker.endDate.format(time_format);
        var confirm_msg = "确定刷新 " + start_time + " 到 " + end_time + " 之间的数据吗？";

        if($('[name=report_checkbox]:checked').length == 0) {
            ark_notify({'status': 1, 'msg': '请选择至少一个报表'});
            return;
        }

        var ids = [];
        $('[name=report_checkbox]:checked').each(function() {
            ids.push($(this).attr('report_id'));
        });
        console.log(ids);
        (new PNotify({
            title: '刷新确认',
            text: confirm_msg,
            hide: false,
            confirm: {
                confirm: true,
                buttons: [{
                    text: '确认',
                    click: function(notice){
                        notice.update({
                            text: '操作中...',
                        });
                        notice.get().find("button").hide();

                        var url = "/statistic/report_run/";
                        var data = {"start_time": start_time, 
                                    "end_time": end_time};
                        for(var i in ids) {
                            data['report_id'] = ids[i];

                            makeAPost(url, data, true, function(result) {
                                if(result.status != 0) {
                                    ark_notify(result);
                                }
                            });
                        }
                        notice.remove();
                        ark_notify({
                            'status':0, 'msg': '任务提交中，其稍后查询'});
                    }}, {
                        text: '取消',
                    }]
            },
            buttons: {
                closer: false,
                sticker: false
            },
            history: {
                history: false
            },
            addclass: 'stack-modal',
            stack: {'dir1': 'down', 'dir2': 'left', 'modal': true},
            type: 'notice',
        }));
    });

})
