var pIndex = 1;
pipeline_result_cache = '';
//type day/hour
function online_report(report_id ,type)
{
    $("#onlineConfirmModal #online_input_reportid").val(report_id);
    if(type == 'day')
    {
        time_input_str = '每天<input type="number" class="form-control" max="23" min="0" id="online_hour" placeholder="0~23">时';
    }
    else
    {
        time_input_str = '每小时';
    }
    $("#onlineConfirmModal .modal-body").html('\
        <form class="form-horizontal">\
          <div class="form-group">\
            <label class="col-sm-3 control-label">运行时间：</label>\
            <div class="col-sm-6">'+time_input_str+
              '<input type="number" class="form-control" max="59" min="0" id="online_minute" placeholder="0~59">分\
            </div>\
          </div>\
        </form>\
        <form class="form-horizontal">\
          <div class="form-group">\
            <label class="col-sm-3 control-label">上线周期：</label>\
            <div class="col-sm-6">\
              <select class="form-control" id="online_cycle">\
                <option value="7">7天</option>\
                <option value="30">1个月</option>\
                <option value="90">3个月</option>\
                <option value="180">6个月</option>\
              </select>\
            </div>\
          </div>\
        </form>\
        <form class="form-horizontal" id="plDiv">\
          <div class="form-group">\
            <label class="col-sm-3 control-label">依赖任务：</label>\
            <a target="_blank" href="/static/wiki/table_task/index.html">常见odps表对应流程</a>\
            <div class="col-sm-1 control-label">\
            <i class="fa fa-plus-square" style="color:green;cursor:pointer" title="添加" onclick="addPipeTask()" href="javascript:void(0)"></i>\
            </div>\
          </div>\
        </form>\
        ');
    $("#onlineConfirmModal").modal('show');
}
function do_online_report(obj)
{
    var url = '/statistic/report_online/';
    var report_id = $("#onlineConfirmModal #online_input_reportid").val();
    var online_hour = $("#online_hour").val();
    var online_minute = $("#online_minute").val();
    var re = /^[0-9]+[0-9]*$/;
    if(online_hour == undefined)
    {
        if(!re.test(online_minute) || isNaN(online_minute) || online_minute <0 || online_minute>59)
        {
            ark_notify({'status':1,'msg':"请输入正确的运行时间"});
            return;
        }
        online_hour = '';
    }
    else if(!re.test(online_hour)  || isNaN(online_hour) || online_hour<0 || online_hour>23 || !re.test(online_minute) || isNaN(online_minute) || online_minute <0 || online_minute>59)
    {
        ark_notify({'status':1,'msg':"请输入正确的运行时间"});
        return;
    }
    var online_rely_pipeline = $("#rely_pipeline").val();
    var online_rely_task = [];
    $("#plDiv div").each(function(){
        $(this).find("select").each(function(i){
            if(i == 1 && $(this).val() != ''){
                online_rely_task.push($(this).val());
            }
        });
    })
    var online_cycle = $("#online_cycle").val();
    var post_data = {};
    post_data['report_id'] = report_id;
    post_data['cycle'] = online_cycle;
    if(online_hour == '')
    {
        post_data['ct_time'] = online_minute+' * * * *';
    }
    else
    {
        post_data['ct_time'] = online_minute+' '+online_hour+' * * *';
    }
    post_data['rely_task_list'] = online_rely_task;
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            if(result.status == 0)
            {
                $("#onlineConfirmModal").modal('hide');
                if(typeof(_report_cycle) != 'undefined')
                {
                    $("#status_font").html('已上线<sup class="fa fa-info-circle" data-toggle="tooltip" data-original-title="点击查看详情"></sup>');
                    $("#status_font").css("color", 'green');
                    // $("#status_font").attr("onclick", 'get_report_online_info("'+_report_id+'")');
                    $("#status_a").html("下线");
                    $("#status_a").attr("onclick", 'offline_report("'+_report_id+'")');
                }
                else
                {
                    location.reload(true);
                }
            } 
        }   
    });

}
function offline_report(report_id)
{
    $("#offlineConfirmModal #offline_input_reportid").val(report_id);
    $("#offlineConfirmModal").modal('show');
}
function do_offline_report()
{
    var url = '/statistic/report_offline/';
    var report_id = $("#offlineConfirmModal #offline_input_reportid").val();
    var post_data = {'report_id':report_id};
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            if(result.status == 0)
            {
                if(typeof(_report_cycle) != 'undefined')
                {
                    $("#status_font").html('已下线<sup class="fa fa-info-circle" data-toggle="tooltip" data-original-title="上线后才会例行执行"><sup>');
                    $("#status_font").css("color", 'black');
                    $("#status_a").html("上线");
                    $("#status_a").attr("onclick", 'online_report("'+_report_id+'","'+_report_cycle+'")');
                }
                else
                {
                    location.reload(true);
                }
            } 
        }   
    });
}
function addPipeTask(){
    if(pipeline_result_cache == '')
    {
        $.ajax({
            type : 'post',
            async: false,
            url  : '/statistic/report_pipeline_list/',
            data : {'report_id': $("#online_input_reportid").val()},
            success : function(result) {
                    pipeline_result_cache = result;
                    do_add_rely_line(result);
            }
        }); 
    }
    else
    {
        do_add_rely_line(pipeline_result_cache);
    }
    pIndex++;
}
function do_add_rely_line(result)
{
    if(result.status == 0){
            var select_str = "";
            pipelines = result.data;
            if(pipelines.length > 0){
                select_str += "<div class='form-group'"+
                    " style='margin-left: 5px;'><select id='rely_pipeline"+pIndex+
                    "' onchange='getTasks("+pIndex+")' style='width:176px'"+
                    " class='combobox select2-select-00 full-width-fix select2-offscreen'>"+
                    "<option value=''>--请选择流程--</option>";

                for(i = 0;i<pipelines.length;i++){
                    select_str += "<option value='"+pipelines[i].id+"' >"+
                    pipelines[i].name+"</option>";
                }
               
                select_str += "</select>&nbsp<select id='rely_task"+pIndex+
               "' style='width:176px' class='combobox select2-select-00 full-width-fix select2-offscreen'>"+
               "<option value=''>--请选择任务--</option></select>&nbsp;"+
               "<i class='fa fa-plus-square' style='cursor:pointer;color:green;' title='添加' onclick='addPipeTask()' href='javascript:void(0)'></i>&nbsp;"+
                "<i title='删除' class='fa fa-minus-square' style='cursor:pointer;color:red' onclick='deletePlDiv(this)'"+
                " href='javascript:void(0)'></i></div>";

     
                $("#plDiv").append(select_str);

                $('#rely_pipeline'+pIndex).select2();
                $('#s2id_rely_pipeline'+pIndex).css({
                      'width':'180px',
                      'margin-left':'25%'
                }); 
                 $('#rely_pipeline'+pIndex).prev().find('.select2-chosen').text('--请选择流程--'); 
               // $('#rely_task'+pIndex).combobox();
                //by xiaolin
               var addinput= $('#rely_pipeline'+pIndex).prev().find('input').eq(1);
                var text=addinput.val();
                addinput.on('blur',function(){
                    if($(this).val()==""){
                    $(this).val(text);
                    }
                });
                $('#rely_task'+pIndex).select2();
                $('#rely_task'+pIndex).prev().find('.select2-chosen').text('--请选择任务--');
                $('#s2id_rely_task'+pIndex).css({
                    'width':'180px',
                    'margin-left':'9px'
                });
            }
            else {
                alert("你没有拥有权限的流程，不能添加依赖！");
            }
    }
}
function deletePlDiv(obj) {
    $(obj).parent().remove();
}


function getTasks(index){
    var id = $("#rely_pipeline"+index).val();
    //by xiaolin
    $('#rely_task'+index).prev().find('.select2-chosen').text('--请选择任务--');


    var url = "/statistic/report_task_list/";
    var task_select = '';
    if(id != ''&&id!=null){
        $.ajax({
            type:'post',
            url:url,
            async: false,
            dataType:'json',
            data:{'pipeline_id':id, 'report_id': $("#online_input_reportid").val()},
            success:function(result){
                $("#rely_task"+index).empty();
                var task_list = result.data;
                if(task_list.length>0){
                    for(var i=0;i<task_list.length;i++){
                        task_select += "<option value='"+task_list[i].id+"'>"+
                        task_list[i].name+"</option>";
                    }
                }
                else{
                    task_select = "<option value=''>无</option>";
                }
                 
                $("#rely_task"+index).append(task_select);
                 
               // $('#rely_task'+index).combobox('refresh');
               
               // $('#rely_task'+index).combobox();
                
     
                              
            }
        });
    }
    else{
        //流程为空
        $("#rely_task"+index).empty();
    }
}

