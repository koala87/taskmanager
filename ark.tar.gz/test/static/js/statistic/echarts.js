$(function() {
    var option = {
        title: {
            text: 'title',
            x: 'center',
        },
        tooltip: {
            show : true,
        },
        toolbox: {
            show : true,
            feature : {
                saveAsImage : {show: true},
                dataView : {show: true, readOnly: false},
                restore : {show: true},
            }
        },
        legend: {
            data:[]
        },
        series : []
    };

    window.StatEcharts = {
        get_line_option: function(title, time_list, legend_data, series_data) {
            var o = $.extend(true, {}, option);
            o['title']['text'] = title;
            o['legend']['data'] = legend_data;
            if(series_data.length == 0) {
                o['series'] = [{'type':'line'}];
            } else {
                o['series'] = series_data;
            }

            var r = time_list.length <= 7 ? 10 : time_list.length <= 15 ? 15 : 25;
            o['xAxis'] = [
                {
                    type : 'category',
                    data : time_list,
                    axisLabel: {rotate: r, interval: 0},
                }
            ];
            o['yAxis'] = [
                {
                    type : 'value',
                    scale: true,
                    min: 'dataMin',
                    max: 'dataMax',
                },
                {
                    type : 'value',
                    scale: true,
                    min: 'dataMin',
                    max: 'dataMax',
                }
            ];
            o['toolbox']['feature']['magicType'] = {show: true, type: ['line', 'bar']};
            return o;
        },
        get_pie_option: function(title, sub_title, legend_data, series_data) {
            var o = $.extend(true, {}, option);
            o['title']['text'] = title;
            o['title']['subtext'] = sub_title;
            o['tooltip']['trigger'] = 'item';
            o['tooltip']['formatter'] = '{a} <br/>{b} : {c} ({d}%)';
            legend_data.splice(0, 0, '');
            legend_data.splice(0, 0, '');
            o['legend'] = {data: legend_data, 
                           orient : 'vertical', 
                           x: 'left',
                           padding: [50,-200]
                          };
            if(series_data.length == 0) {
                o['series'] = [{'type':'pie'}];
            } else {
                o['series'] = series_data;
            }
            return o;
        },
        get_scatter_option: function(title, legend_data, series_data) {
            var o = $.extend(true, {}, option);
            o['title']['text'] = title;
            o['legend']['data'] = legend_data;
            if(series_data.length == 0) {
                o['series'] = [{'type':'scatter'}];
            } else {
                o['series'] = series_data;
            }
            o['xAxis'] = [
                {
                    type : 'value',
                }
            ];
            o['yAxis'] = [
                {
                    type : 'value'
                },
            ];
            return o;
        },

    }
});