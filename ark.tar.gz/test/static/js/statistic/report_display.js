$(function() {
    console.log('report_display.js');
});