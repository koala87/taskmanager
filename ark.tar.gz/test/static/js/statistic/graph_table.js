
$(function() {
    var graph_name = '结果集';
    var time_picker = $(".feat-table-box[name=main] [name=feat_time_range_selector]").data("daterangepicker");
    var start_time;
    var end_time;
    $.fn.dataTable.ext.errMode = function(settings, helpPage, message) {
        ark_notify({'status': 1, 'msg': graph_name + "：" + message});
    }

    window.FeatGraphTable = {
        get_time: function() {
            start_time = time_picker.startDate.format(time_format);
            end_time = time_picker.endDate.format(time_format);
        },
        show_data_ops: function() {
            $(".feat-table-box[name=table] button[name=btn_download]").show();
        },
        hide_data_ops: function() {
            $(".feat-table-box[name=table] button[name=btn_download]").hide();
        },
        init_feat_check: function() {
            var items = $(".feat-table-box[name=table] input[type=checkbox][name='feat']");
            items.each(function() {
                $(this).prop("checked", true); 
            });
        },
        update_table_header : function() {
            header = [_time_column].concat(_select_dims)
                .concat(_basic_feats).concat(_ext_feats);
            columns = [];
            html = "<tr>";
            for(var i in header) {
                col = col_dsp = header[i];
                if(_column_dsp[col])
                    col_dsp = _column_dsp[col];
                html += "<th>" + col_dsp + "</th>";
                columns.push({'name': col, 'title': col_dsp});
            }
            html += "</tr>";
            html = "<thead>" + html + "</thead>";
            $("#feat_graph_table").html(html);
            return columns;
        },

        get_order_config : function() {
            var config = [];
            for(var i = 0; i < 1 + _select_dims.length; i++) {
                config.push({"orderSequence": ["desc", "asc", null]});
            }
            for(var i = 0; i < _basic_feats.length; i++) {
                config.push({"orderSequence": ["desc", "asc", null],
                             "mRender": function (data, type, full) {
                                 return Number.isInteger(data) ? data : data.toFixed(3);
                             }});
            }

            for(var i in _ext_feats) {
                config.push({"orderSequence": [null],
                             "mRender": function (data, type, full) {
                                 return Number.isInteger(data) ? data : data.toFixed(3);
                             }});
            }
            return config;
        },
        show_hide_init: function() {
            header = [_time_column].concat(_select_dims).concat(_basic_feats).concat(_ext_feats);
            $('#sample_2_column_toggler input[type="checkbox"]').not(":checked").each(function(){
                var i = $(this).attr("data-column");
                _feat_graph_table.column(i).visible(!_feat_graph_table.column(i).visible());
            });
        },
        refresh : function(callback, arg) {
            var feat_url = "/statistic/feat_graph_table/" + _report_id + "/";
            var display_length = 30;
            if(_feat_graph_table) {
                display_length = $('#feat_graph_table_length select[name=feat_graph_table_length]').val();
                _feat_graph_table.destroy();
            }
            columns = FeatGraphTable.update_table_header();
            order_config = FeatGraphTable.get_order_config();

            FeatGraphTable.get_time();
            _feat_graph_table = $('#feat_graph_table').DataTable({
                "processing": true,
                "serverSide": true,
                "language": {
                    "zeroRecords": "该时段无指标数据",
                    "lengthMenu": "  条数 _MENU_ " 
                },
                dom: 'Bl<"#table_feat_summary">rti',
                buttons: [ ],
                "ajax": {
                    "url": feat_url,
                    "type": "POST",
                    "data": function(d) {
                        d.start_time = start_time;
                        d.end_time = end_time;
                        d.select_dims = _select_dims;
                        d.dim_filter = JSON.stringify(_dim_filter);
                    },
                    "dataSrc" : function (result) {
                        if(result.data && result.data.length > 0) {
                            var summary = FeatGraphTable.calcu_summary(result.data);
                            result.data = summary.concat(result.data);
                        }
                        return result.data;
                    },
                },
                "iDisplayLength": display_length,
                "aoColumns": order_config,
                "bPaginate": true,
                "aLengthMenu": [[30, 100, 1000, 5000, 10000], [30, 100, 1000, 5000, 10000]],
                "bInfo": false,
                "bFilter": false,
                "order": [[0, "desc"]],
                "fnDrawCallback": function(oSettings) {
                    if(oSettings.aoData.length > 0) {
                        FeatGraphTable.show_data_ops();
                    } else {
                        FeatGraphTable.hide_data_ops();
                    }                

                    $("#table_feat_summary").html($("#div_feat_summary").html());
                    $("#table_feat_summary").addClass("box-tools pull-right");
                    $("#table_feat_summary").css("margin-right", "20%");

                    FeatGraphTable.display_summary();

		    if(callback) {
			callback(arg);
			callback = null;
		    }
                },
            });
            FeatGraphTable.show_hide_init();
            $('#feat_graph_table').wrap("<div class='scrolledTable'></div>");
            $('#feat_graph_table').attr("style", "width:100%");
        },
        calcu_avg: function(data) {
            var feat_idx = _select_dims.length + 1;
            var feat_num = _basic_feats.length + _ext_feats.length;
            var row_length = feat_idx + feat_num;
            var avg = Array(feat_num).fill(0);
            var avg_row = ['均值'].concat(Array(_select_dims.length).fill('')).concat(avg);
            for(var i = 0; i < data.length; i++) {
                for(var j = feat_idx; j < row_length; j++) {
                    avg_row[j] += data[i][j];
                }
            }
            for(var i = feat_idx; i < row_length; i++) {
                avg_row[i] = avg_row[i] / data.length;
            }
            return avg_row;
        },
        calcu_summary: function(data) {
            var feat_idx = _select_dims.length + 1;
            var feat_num = _basic_feats.length + _ext_feats.length;
            var row_length = feat_idx + feat_num;
            var avg = Array(feat_num).fill(0);
            var avg_row = ['均值'].concat(Array(_select_dims.length).fill('')).concat(avg);

            var sum = Array(feat_num).fill(0);
            var sum_row = ['求和'].concat(Array(_select_dims.length).fill('')).concat(sum);

            var max = Array(feat_num).fill('');
            var max_row = ['最大值'].concat(Array(_select_dims.length).fill('')).concat(max);

            var min = Array(feat_num).fill('');
            var min_row = ['最小值'].concat(Array(_select_dims.length).fill('')).concat(min);

            for(var i = 0; i < data.length; i++) {
                for(var j = feat_idx; j < row_length; j++) {
                    sum_row[j] += data[i][j];
                    if(max_row[j] == '' || max_row[j] < data[i][j]) {
                        max_row[j] = data[i][j];
                    }
                    if(min_row[j] == '' || min_row[j] > data[i][j]) {
                        min_row[j] = data[i][j];
                    }
                }
            }
            for(var i = feat_idx; i < row_length; i++) {
                avg_row[i] = sum_row[i] / data.length;
            }
            return [avg_row, sum_row, max_row, min_row];
        },
        display_summary: function() {
            $("#table_feat_summary input[type=checkbox][group=feat_summary]").each(function() {
                var val = $(this).val();
                $(this).prop("checked", $("#div_feat_summary input[type=checkbox][name=" + $(this).attr("name") + "]").prop("checked"));
                if($(this).is(":checked")) {
                    $("td:first-child:contains(" + val + ")").parent().show();
                } else {
                    $("td:first-child:contains(" + val + ")").parent().hide();
                }
            });

            $("input[type=checkbox][group=feat_summary]").on("click", function() {
                var val = $(this).val();
                var name = $(this).attr("name");
                $("#div_feat_summary input[type=checkbox][name=" + name + "]").prop("checked", $(this).is(":checked"));
                if($(this).is(":checked")) {
                    $("td:first-child:contains(" + val + ")").parent().show();
                } else {
                    $("td:first-child:contains(" + val + ")").parent().hide();
                }
            });
        },
	download: function (feat_box) {
            feat_box.find("#feat_graph_table_wrapper").table2excel(
		{filename: _report_name+"_"+start_time + "_" + end_time}
            );
	    feat_box.find('.overlay').hide();
	}
    }

    $("[name='download_op']").click(function() {
        if(!start_time || !end_time) {
            ark_notify({'status': 1, 'msg': '导出数据为空'});
            return;
        }

        var value = $(this).attr('value');
        var old_num = parseInt($('#feat_graph_table_length select[name=feat_graph_table_length]').val());
        var feat_box = $(this).parents(".feat-table-box").first();
	feat_box.find('.overlay').show();
	var max_line_num = 10000;
	var summary_line_num = 4;
	if(value == "current" || old_num == max_line_num || _feat_graph_table.rows()[0].length < old_num + summary_line_num) {
	    FeatGraphTable.download(feat_box);
	} else {
            $('#feat_graph_table_length select[name=feat_graph_table_length]').val(max_line_num);
	    FeatGraphTable.refresh(FeatGraphTable.download, feat_box); 
	}
    });

    function subscribe() {
        $("#subscribe_feats_form input[name=select_dims]").val(
            JSON.stringify(_select_dims));
        $("#subscribe_feats_form input[name=dim_filter]").val(
            JSON.stringify(_dim_filter));
        $("#subscribe_feats_form input[name=start_time]").val(start_time);
        $("#subscribe_feats_form input[name=end_time]").val(end_time);

        $("#subscribe_feats_form").submit();
    }
    $("[name='btn_subscribe']").click(function() {

        $btn = $(this);
        if(_feat_graph_table.data().length != 0) {
            subscribe();
        } else {
            $btn.prop('disabled', true);
            (new PNotify({
                title: '订阅确认',
                text: '结果为空，确定订阅？',
                hide: false,
                confirm: {
                    confirm: true,
                    buttons: [{
                        text: '确认',
                        click: function(notice){
                            subscribe()
                            notice.remove();
                            $btn.prop('disabled', false);
                        }}, {
                            text: '取消',
                            click: function(notice){
                                notice.remove();
                                $btn.prop('disabled', false);
                            }
                        }]
                },
                buttons: {
                    closer: false,
                    sticker: false
                },
                history: {
                    history: false
                },
                addclass: 'stack-modal',
                stack: {'dir1': 'down', 'dir2': 'left', 'modal': true},
                type: 'notice',
            }));
        }

    });

    FeatGraphTable.init_feat_check();
    FeatGraphTable.refresh();
    //显示隐藏列
    header = [_time_column].concat(_select_dims).concat(_basic_feats).concat(_ext_feats);
    for(var i in header) { 
        col = col_dsp = header[i];
        if(_column_dsp[col])
            col_dsp = _column_dsp[col];
        var checked_flag = _column_show_hide[col] ? 'checked' : '';
        if(_column_show_hide[col] == 0)
        {
            _feat_graph_table.column(i).visible(!_feat_graph_table.column(i).visible());
        }
        $("#sample_2_column_toggler").append('<label><div class="checker"><span class="checked"><input type="checkbox" '+checked_flag+' data-column="'+i+'" action-data-col="'+col+'"></span></div>'+col_dsp+'</label>');
    }
    $(document).on('click', "#sample_2_column_toggler", function(e) { 
        e.stopPropagation(); 
    });
    $(document).off('change', '#sample_2_column_toggler input[type="checkbox"]');
    $(document).on('change', '#sample_2_column_toggler input[type="checkbox"]', function (e) {
        e.preventDefault();
        var column = _feat_graph_table.column($(this).attr('data-column'));
        column.visible(!column.visible());
    });
    $(".feat-table-box .box-body").scroll(function(){
        $(".dataTables_wrapper .dataTables_length").css('top', 50-$(".feat-table-box .box-body").scrollTop());
        if($(".feat-table-box .box-body").scrollTop() > 25)
        {
            $(".dataTables_wrapper .dataTables_length").hide();
        }
        else
        {
            $(".dataTables_wrapper .dataTables_length").show();
        }
    });
});
