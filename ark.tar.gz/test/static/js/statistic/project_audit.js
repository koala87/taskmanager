$(function(){
    get_project_list();
});
function get_project_list()
{
    var url = '/statistic/list/';
    var post_data = {'name_desc':'','category':''};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            var html = '<table class="table table-bordered table-hover" id="audit_table">\
                            <thead>\
                                <td style="width:3%;">#</td>\
                                <td style="width:10%;">项目名</td>\
                                <td style="width:9%;">分类</td>\
                                <td style="width:35%;">描述</td>\
                                <td style="width:9%;">创建者</td>\
                                <td style="width:13%;">创建时间</td>\
                                <td style="width:12%;">操作</td>\
                            </thead>\
                            <tbody>';
            if(result.status == 0)
            {
                for(var i=0;i<result.data.length;i++)
                {
                    var no = i+1;
                    var op_str = '';
                    var reason_tip = "";
                    if(result.data[i].status_reason)
                    {
                        reason_tip = '<sup data-toggle="tooltip" data-placement="left" data-original-title="'+result.data[i].status_reason+'"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span></sup>';
                    }
                    if(result.data[i].status==0)
                        op_str = '审核中'+reason_tip+'&nbsp;&nbsp;<a href="javascript:void(0)" onclick="audit_agree(this)">同意</a>&nbsp;&nbsp;<a href="javascript:void(0)" onclick="audit_deny(this)">拒绝</a>';
                    else if(result.data[i].status==1)
                        op_str = '审核通过';
                    else if(result.data[i].status==2)
                    {
                        op_str = '已拒绝'+reason_tip;
                    }
                    html += '<tr action-data-id="'+result.data[i].id+'"><td>'+no+'</td>'+
                            '<td>'+result.data[i].name+'</td>'+
                            '<td>'+result.data[i].category+'</td>'+
                            '<td title="'+result.data[i].description+'">'+result.data[i].description+'</td>'+
                            '<td>'+result.data[i].owner_username+'</td>'+
                            '<td>'+result.data[i].create_time+'</td>'+
                            '<td>'+op_str+'</td>'+
                            '</tr>';
                }
            }
            else
            {
                ark_notify(result);
            }
            html += '</tbody></table>';
            $("#table_container").html(html);
            $('#audit_table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": false,
                "info": true,
                "autoWidth": false
            });
        }
    });
}
function audit_agree(obj)
{
    var project_id = $(obj).parent().parent().attr('action-data-id');
    $("#audit_agree_modal #btn_audit_agree_ok").attr('onclick','do_audit_agree('+project_id+')');
    $("#audit_agree_modal").modal('show');
}
function do_audit_agree(project_id)
{
    var url = '/statistic/project_accept/';
    var post_data = {'project_id':project_id};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            if(result.status == 0)
            {
                $("#audit_agree_modal").modal('hide');
                location.href = '/statistic/project_audit/';
            }
        }
    });
}
function audit_deny(obj)
{
    var project_id = $(obj).parent().parent().attr('action-data-id');
    $("#audit_deny_modal #btn_audit_deny_ok").attr('onclick','do_audit_deny('+project_id+')');
    $("#audit_deny_modal").modal('show');
}
function do_audit_deny(project_id)
{
    var url = '/statistic/project_deny/';
    var post_data = {'project_id':project_id,'reason':$("#deny_reason").val().trim()};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            if(result.status == 0)
            {
                $("#audit_deny_modal").modal('hide');
                location.href = '/statistic/project_audit/';
            }
        }
    });
}
