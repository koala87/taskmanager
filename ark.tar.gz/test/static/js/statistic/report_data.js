$(function() {
    var filter_panel_main = $(".filter-panel[name=main]");

    $("[name=btn_back_to_top]").first().click(function() {

        element = $('body');
        offset = element.offset();
        offset_top = offset.top;
        $('html, body').animate({scrollTop: offset_top}, 200, 'linear');

    });

    function getSelectDims() {
        var values = []
        $(".filter-panel[name=main] input[type=checkbox]:checked").each(function() {
            values.push($(this).val());
        });
        return values;
    }

    function updateFilterParam() {
        if(_init_select_dims && _init_select_dims.length != 0) {
            _select_dims = _init_select_dims;
            _init_select_dims = null;
        } else {
            _select_dims = getSelectDims(filter_panel_main);
        }

        if(_init_dim_filter && _init_dim_filter.length != 0) {
            _dim_filter = _init_dim_filter;
            _init_dim_filter = null;
        } else {
            _dim_filter = DimFilter.getDimFilter(filter_panel_main);
        }

        //显示隐藏列
        header = [_time_column].concat(_select_dims).concat(_basic_feats).concat(_ext_feats);
        var pre_checked_list = {};
        $('#sample_2_column_toggler input[type="checkbox"]').each(function(){
            pre_checked_list[$(this).attr('action-data-col')] = $(this).prop('checked');
        })

        var html_new_show_hide = '';
        for(var i in header) { 
            col = col_dsp = header[i];
            if(_column_dsp[col])
                col_dsp = _column_dsp[col];
            var checked_flag = pre_checked_list[col] == true || pre_checked_list[col] == undefined ? 'checked' : '';
            html_new_show_hide += '<label><div class="checker"><span class="checked"><input type="checkbox" '+checked_flag+' data-column="'+i+'" action-data-col="'+col+'"></span></div>'+col_dsp+'</label>';
        }
        $("#sample_2_column_toggler").html(html_new_show_hide);

    }

    window.FeatGraph = {

        refreshAllGraphs: function() {
            for(var i in _report_graphs) {
                var type = _report_graphs[i].type;
                switch(type) {
                case 'growth_table':
                    FeatGraphGrowthTable.refresh();
                    break;
                case 'line':
                    FeatGraphLine.refresh();
                    break;
                case 'scatter':
                    FeatGraphScatter.refresh();
                    break;
                case 'pie':
                    FeatGraphPie.refresh();
                    break;
                default:
                    ark_notify({'status': 1, 'msg': '不支持的图表' + type}
                              );
                    break;
                }
            }
        }
    }

    $("#btn_feat_query").click(function() {
        update_main_time();
        _main_box.parent().removeClass('filter-panel-open');
        updateFilterParam();
        FeatGraphTable.refresh();
        FeatGraph.refreshAllGraphs();
    });

    $("[name=filter-panel-toggle]").click(
        function() {
            var box = $(this).parents('.box').first();
            box.parent().toggleClass('filter-panel-open');

            if(box.attr('name') == 'main') {
                var panel = box.parent().find(".filter-panel[name=main]");
                var btn_refresh = box.parent().find("[name=btn_refresh_dim_filter]");
                btn_refresh.button("loading");
                DimFilter.initDimSelector(panel, true, false, function() {
                    btn_refresh.button("reset");
                });
            }
        });

    $("[name=btn_refresh_dim_filter]").click(function() {
        var panel = $(this).parents().find(".filter-panel[name=main]");
        var obj = $(this);
        if(panel) {
            obj.button("loading");
            DimFilter.initDimSelector(panel, true, true, function() {
                obj.button("reset");
            });
        }
    });

    $("[name=feat_time_range_selector]").each(
        function() {
            TimeRange.init_feat_time_range($(this));
        });

    function update_time_range_input(picker, start_time, end_time) {
        var old_val = picker.element.val();

        if(!start_time) {
            start_time = picker.startDate.format(time_format);
        } else {
            picker.setStartDate(start_time);
        }
        if(!end_time) {
            end_time = picker.endDate.format(time_format);
        } else {
            picker.setEndDate(end_time);
        }

        var new_val = start_time + " 到 " + end_time;
        if(new_val == old_val) {
            return;
        }

        picker.element.val(new_val);
    }

    function update_time_input(picker, time) {
        var old_val = picker.element.val();
        var new_val = time;
        if(new_val == old_val) {
            return;
        }

        picker.setStartDate(time);
        picker.setEndDate(time);
        picker.element.val(time);
    }

    var _main_box = $(".feat-table-box[name=main]")
    var _main_time_selector = $(".feat-table-box[name=main] input[name=feat_time_range_selector]");
    var _main_time_picker = _main_time_selector.data("daterangepicker");
    function update_main_time() {
        start_time = _main_time_picker.startDate.format(time_format);
        end_time = _main_time_picker.endDate.format(time_format);
        $("[name=feat_time_selector]").each(function() {
            update_time_input(
                $(this).data("daterangepicker"), end_time);
        });
        $("[name=feat_time_range_selector]").each(function() {
            // 不更新刷新数据使用的timerangepicker
            if("run_report" === $(this).parent().attr('id') && $(this).val()) {
                return true;
            } else {
                update_time_range_input(
                    $(this).data("daterangepicker"), start_time, end_time);
            }
        });
    }

    $("[name=feat_time_selector]").each(
        function() {
            obj = TimeRange.init_feat_time($(this));
        });

    $("#run_report").click(function() {
        run_time_picker.show();
    });
    var run_time_input = $("#run_report").find('[name=feat_time_range_selector]');
    var run_time_picker = run_time_input.data('daterangepicker');
    run_time_picker.startDate = run_time_picker.endDate;
    update_time_range_input(run_time_picker);
    
    run_time_input.on('apply.daterangepicker', function(ev, picker) {
        var start_time = run_time_picker.startDate.format(time_format);
        var end_time = run_time_picker.endDate.format(time_format);
        var confirm_msg = "确定刷新 " + start_time + " 到 " + end_time + " 之间的数据吗？";

        (new PNotify({
            title: '刷新确认',
            text: confirm_msg,
            hide: false,
            confirm: {
                confirm: true,
                buttons: [{
                    text: '确认',
                    click: function(notice){
                        var url = "/statistic/report_run/";
                        var data = {"report_id": _report_id,
                                    "start_time": start_time, 
                                    "end_time": end_time};
                        notice.update({
                            text: '操作中...',
                        });
                        notice.get().find("button").hide();
                        result = makeAPost(url, data, true, function(result) {
                            if(result.status == 0) {
                                result['title'] = '正在刷新，请稍后查看指标';
                            }
                            ark_notify(result);
                            notice.remove();
                        });
                    }}, {
                        text: '取消',
                    }]
            },
            buttons: {
                closer: false,
                sticker: false
            },
            history: {
                history: false
            },
            addclass: 'stack-modal',
            stack: {'dir1': 'down', 'dir2': 'left', 'modal': true},
            type: 'notice',
        }));
    });

    _main_time_selector.change(function() {
        console.log("trigger query...");
        $("#btn_feat_query").trigger("click");
    });
    $(".select_dim_filter").on('change', function(){
        obj_select2 = $("#s2id_"+$(this).attr('action-data-val-select2'));
        obj_select2.attr('data-toggle', "tooltip");
        obj_select2.attr('data-placement', "top");
        obj_select2.attr('data-original-title', $(this).find("option:selected").attr("action-data-tooltip"));
    });

    DimFilter.initEmptyValue(filter_panel_main);
    if(_init_select_dims && _init_select_dims.length > 0) {
        _select_dims = _init_select_dims;
    }
    if(_init_dim_filter && _init_dim_filter.length > 0) {
        _dim_filter = _init_dim_filter;
    }

    
    var detail_loaded = false;
    $("a[href=#report_detail]").click(function() {
        if(!detail_loaded && !$("#report_detail").is(".active")) {
            displayLoading($("#report_detail"));
            var url = "/statistic/report_detail/" + _report_id + "/";
            $("#report_detail").load(url);
            detail_loaded = true;
        }
    });
    
});
