$(function(){
    init_search_input();
    init_add_group_radio();
//    get_report_list();
    $(document).on('click', '#btn_move_report_group_ok', function(){
        var treeObj = $.fn.zTree.getZTreeObj("tree_group_move");
        var selected = treeObj.getSelectedNodes();
        if(selected.length == 0)
        {
            ark_notify({'status':1,'msg':'请选择要移动到的节点'});
            return;
        }
        var node_id_self = $("#move_report_group_id").val();
        var node_id_to = selected[0].id;
        do_move_group(node_id_self, node_id_to); 
    });

    $(document).on('click', '#btn_move_report_ok', function(){
        var treeObj = $.fn.zTree.getZTreeObj("tree_report_move");
        var selected = treeObj.getSelectedNodes();
        if(selected.length == 0)
        {
            ark_notify({'status':1,'msg':'请选择要移动到的节点'});
            return;
        }
        var node_id_self = $("#move_report_id").val();
        var node_id_to = selected[0].id;
        do_move_report(node_id_self, node_id_to); 
    });
    $(document).on('click', '.a_report_group', function(){
    })

    $("[name=latest_status_dsp]").each(function() {
        var report_id = $(this).attr("report_id");
        get_latest_status($(this), $(this).parent(), report_id);
    });

    $("[name=latest_status_dsp]").click(function() {
        var report_id = $(this).attr("report_id");
        show_run_status($(this), report_id);
    });

    $("[name=status_font]").click(function() {
        var report_id = $(this).attr("report_id");
        get_report_online_info($(this), report_id);
    });
});

function get_report_list()
{
    var url = '/statistic/report_list/?project_id='+$("#input_project_id").val();
    var post_data = {};
    if($("#input_report_search").val().trim() != '')
    {
        post_data['search_val'] = $("#input_report_search").val().trim();
    }
    else
    {
       location.reload();
        return;
    }
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            if(result.status == 0)
            {
                if(result.data.length > 0)
                {
                    $(".breadcrumbs li:gt(0)").remove();
                    $(".breadcrumbs").append('<li><a href="/statistic/report_manager/?project_id='+$("#input_project_id").val()+'"><font>'+$("#input_project_name").val()+'</font></a></li>');
                    $(".breadcrumbs").append('<li class="search_tip"><font class="active">搜索"'+$("#input_report_search").val().trim()+'"</font></li>');
                    //if($("#report_list thead .new_added_td").length == 0)
                    //{
                    //    $("#report_list thead td").eq(1).after("<td class='new_added_td'>所在分组</td>");
                    //}
                    var html = '';
                    for(var i=0;i<result.data.length;i++)
                    {
                        var report_id = result.data[i].id;
                        html += '<tr action-data-id="'+report_id+'" action-data-name="'+result.data[i].name+'">';
                        html += '<td><img style="width: 25px;" src="/static/images/statistic/report_manager_file.png"></img><a href="/statistic/report_index/?report_id='+result.data[i].id+'">'+result.data[i].name+'</a></td>';
                        html += '<td>'+result.data[i].creator+'</td>';
                        html += '<td>'+result.data[i].group+'</td>';
                        if(result.data[i].status == 0)
                        {
                            html += '<td class="td_status"><a href="javascript:void(0)" style="color:black;cursor:text;">已下线</a><a href="javascript:void(0)" onclick="online_report('+result.data[i].id+', '+"'"+result.data[i].cycle+"'"+')">上线</a></td>';
                        }
                        else if(result.data[i].status == 1)
                        {
                            var color_flag = 'green';
                            if((new Date(result.data[i].expire_time) - new Date())/86400000 < 7)
                            {
                                color_flag = '#FF9900';
                            }
                            html += '<td class="td_status"><a href="javascript:void(0)" style="color:black;cursor:text;">已上线<i title="过期时间:'+result.data[i].expire_time+'" class="fa fa-fw fa-circle" style="color:'+color_flag+'"></i></a><a href="javascript:void(0)" onclick="offline_report('+result.data[i].id+')">下线</a></td>';
                        }
                        else
                        {
                            html += '<td>未知</td>';
                        }
                        if(result.data[i].cycle == 'day')
                            html += '<td>天级</td>';
                        else
                            html += '<td>小时级</td>';
                        var status_disp = '未知';
                        if(result.data[i].latest_status == {})
                        {
                            status_disp = '无';
                            html += '<td>'+status_disp+'</td>';
                        } else if(typeof(result.data[i].latest_status) == 'string')
                        {
                            status_disp = result.data[i].latest_status;
                            html += '<td>'+status_disp+'</td>';
                        } else {
                            var color = "black";
                            var status_disp = "未知";
                            switch(result.data[i].latest_status.pipe_status) {
                            case 0:
                                color = "gray";
                                status_disp = "等待中";
                                break;
                            case 1:
                                color = "#00c0ef";
                                status_disp = "执行中";
                                break;
                            case 2:
                                color = "green";
                                status_disp = "成功";
                                break;
                            case 3:
                                color = "red";
                                status_disp = "失败";
                                break;
                            }
                            console.log(report_id);
                            html += '<td><a style="color:' + color + ';margin-left: 0;" href="javascript:void(0)" onclick="show_run_status($(this),' + report_id + ')" action-data="'+JSON.stringify(result.data[i].latest_status.task_list)+'">'+status_disp+'</a></td>';  
                        }

                        html += '<td><a href="/statistic/report_update/?project_id='+$("#input_project_id").val()+'&group_id='+$("#input_group_id").val()+'&report_id='+report_id+'">编辑</a><div class="btn-group"  style="margin-left: 14px;">\
                                    <a class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown" aria-expanded="true">\
                                        <img style="width:20px;" src="/static/images/statistic/box_tooltip.png"></img>\
                                    </a>\
                                    <ul class="dropdown-menu" role="menu">\
                                        <li><a href="javascript:void(0)" onclick="copy_report(this)">复制到</a></li>\
                                        <li><a href="javascript:void(0)" onclick="move_report(this)">移动到</a></li>\
                                        <li><a href="javascript:void(0)" onclick="delete_report(this)">删除</a></li>\
                                    </ul>\
                                    </div></td></tr>'
                    }
                    $("#div_report_list").html('<table class="table table-hover" id="report_list" style="table-layout:fixed;">\
                                                    <thead>\
                                                        <td style="width:27%">报表名</td>\
                                                        <td style="width:8%">创建者</td>\
                                                        <td>所在分组</td>\
                                                        <td style="width:15%">报表状态</td>\
                                                        <td style="width:7%">更新周期</td>\
                                                        <td style="width:10%">最近运行状况</td>\
                                                        <td style="width:10%">操作</td>\
                                                    </thead>\
                                                    <tbody>'+html+'</tbody></table>');
                }
                else
                {
                    $("#div_report_list").html('<div class="callout callout-info">\
                                                  <h4>提醒!</h4>\
                                                  <p>搜索无结果</p>\
                                                </div>');
                }
            }
            else
            {
                ark_notify(result);
            }
        }
    });
}
function init_search_input()
{
    $("#input_report_search").on("keydown", function(e){
        var e=e||window.event;
        var enter= e.keyCode|| e.which;
        if(enter==13){
            get_report_list();
            return false;
        }
    });
}
function add_new_group()
{
    if($("#report_list").length < 1)
    {
        tmp_revert_html = $("#div_report_list").html();
        $("#div_report_list").html('<table class="table table-hover" id="report_list" style="table-layout:fixed;">\
           <thead>\
               <td style="width:27%">报表名</td>\
               <td style="width:8%">创建者</td>\
               <td style="width:15%">报表状态</td>\
               <td style="width:7%">更新周期</td>\
               <td style="width:10%">最近运行状况</td>\
               <td style="width:10%">操作</td>\
           </thead>\
           <tbody></tbody></table>');
 
    }
    var td_empty_str = '';
    for(var i=1;i<$("#div_report_list thead tr>td").length;i++)
    {
        td_empty_str +='<td></td>';
    }
    $("#report_list tbody").prepend('<tr><td><img style="width: 20px;" src="/static/images/statistic/report_manager_folder.png"></img><input type="text" placeholder="新建分组"/><img onclick="do_add_report_group(this)" src="/static/images/statistic/rename_ok.png" style="margin:0 3px 0 10px;width: 20px;"></img><img onclick="cancel_add_group(this)" src="/static/images/statistic/rename_cancel.png" style="margin: 0 0 0 3px;width:25px"></img></td>'+td_empty_str+'</tr>');
}
function do_add_report_group(obj)
{
    var group_name = $(obj).parent().find('input').val().trim();
    if(!group_name)
    {
        ark_notify({'status':1,'msg':'请输入分组名称'});
        return;
    }
    var url = '/statistic/report_add_group/?project_id='+$("#input_project_id").val();
    var report_group_id = $("#input_group_id").val();
    if(report_group_id)
    {
        url += '&report_group_id='+report_group_id;
    }
    var post_data = {'name':group_name};
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            if(result.status == 0)
            {
                $(obj).parent().prev().html('<i class="fa fa-fw fa-folder" aria-hidden="true"></i>');
                $(obj).parent().parent().find("td:last").html('<a href="javascript:void(0)" onclick="rename_group_outside(this)">重命名</a><div class="btn-group">\
                                <a class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown" aria-expanded="true">\
                                    <img style="width:20px;" src="/static/images/statistic/box_tooltip.png"></img>\
                                </a>\
                                <ul class="dropdown-menu" role="menu">\
                                    <li hidden><a href="javascript:void(0)" onclick="rename_report_group(this)">重命名</a></li>\
                                    <li><a href="javascript:void(0)" onclick="move_report_group(this)">移动到</a></li>\
                                    <li><a href="javascript:void(0)" onclick="delete_report_group(this)">删除</a></li>\
                                </ul>\
                            </div>');
                $(obj).parent().parent().attr('action-data-id', result.data);
                $(obj).parent().parent().attr('action-data-name', group_name);
                $(obj).parent().html('<img style="width: 20px;" src="/static/images/statistic/report_manager_folder.png"></img><a href="/statistic/report_manager/?project_id='+$("#input_project_id").val()+'&group_id='+result.data+'">'+group_name+'</a>');
            } 
            else
            { 
                ark_notify(result);
            }
        }   
    });
}
function cancel_add_group(obj)
{
    if($("#report_list tbody tr").length < 2)
    {
        $("#div_report_list").html(tmp_revert_html );
    }
    else
    {
        $(obj).parent().parent().remove();
    }
}
function rename_group_outside(obj)
{
    $(obj).next().find(".dropdown-menu a:eq(0)").trigger('click');
}
function rename_report_group(obj)
{
    var obj_td = $(obj).parent().parent().parent().parent().parent().find('td').eq(0);
    obj_td.next().next().next().next().next().hide();
    var html = '<input type="text" value="'+obj_td.find('a').html()+'"/><img onclick="do_rename_report_group(this)" src="/static/images/statistic/rename_ok.png" style="margin:0 3px 0 10px;width: 20px;"></img><img onclick="cancel_rename_group(this)" src="/static/images/statistic/rename_cancel.png" style="margin: 0 0 0 3px;width:25px"></img>';
    obj_td.find('a').remove();
    obj_td.append(html);
}
function do_rename_report_group(obj)
{
    var group_name = $(obj).parent().find('input').val().trim();
    if(!group_name)
    {
        ark_notify({'status':1,'msg':'分组名称不能为空'});
        return;
    }
    var url = '/statistic/report_rename_group/';
    var post_data = {'name':group_name};
    post_data['group_id'] = $(obj).parent().parent().attr('action-data-id');
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            if(result.status == 0)
            {
                $(obj).parent().next().next().next().next().next().show();
                $(obj).parent().parent().attr('action-data-name', group_name);
                $(obj).parent().html('<img style="width: 20px;" src="/static/images/statistic/report_manager_folder.png"></img><a href="/statistic/report_manager/?project_id='+$("#input_project_id").val()+'&group_id='+$(obj).parent().parent().attr('action-data-id')+'">'+group_name+'</a>');
            } 
            else
            { 
                ark_notify(result);
            }
        }   
    });
}
function cancel_rename_group(obj)
{
    $(obj).parent().next().next().next().next().next().show();
    $(obj).parent().html('<img style="width: 20px;" src="/static/images/statistic/report_manager_folder.png"></img><a href="/statistic/report_manager/?project_id='+$("#input_project_id").val()+'&group_id='+$(obj).parent().parent().attr('action-data-id')+'">'+$(obj).parent().parent().attr('action-data-name')+'</a>');
}
function delete_report_group(obj)
{
    $("#deleteReportGroupConfirmModal #btn_delete_report_group_ok").attr('onclick','do_delete_report_group('+$(obj).parent().parent().parent().parent().parent().attr('action-data-id')+')');
    $("#deleteReportGroupConfirmModal").modal('show');
}
function do_delete_report_group(id)
{
    $("#deleteReportGroupConfirmModal #btn_delete_report_group_ok").button('loading');
    var url = '/statistic/report_delete_group/';
    var post_data = {};
    post_data['group_id'] = id;
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            $("#deleteReportGroupConfirmModal #btn_delete_report_group_ok").button('reset');
            if(result.status == 0)
            {
                $("#report_list tr[action-data-id="+id+"]").remove();
            } 
        }   
    });

}
function delete_report(obj)
{
    $("#deleteReportConfirmModal #delete_input_reportid").val($(obj).parent().parent().parent().parent().parent().attr('action-data-id'));
    $("#deleteReportConfirmModal").modal('show');
}
function do_delete_report()
{
    $("#deleteReportConfirmModal #btn_delete_ok").button("loading");
    var url = '/statistic/report_delete/';
    var post_data = {};
    var report_id = $("#deleteReportConfirmModal #delete_input_reportid").val();
    var post_data = {'report_id':report_id};
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            $("#deleteReportConfirmModal #btn_delete_ok").button("reset");
            if(result.status == 0)
            {
                $("#report_list tr[action-data-id="+report_id+"]").remove();
            } 
        }   
    });
}
function move_report_group(obj)
{
//    $("#move_report_group_name").val($(obj).parent().parent().parent().parent().parent().attr("action-data-name")+'-副本');
    $("#move_report_group_id").val($(obj).parent().parent().parent().parent().parent().attr("action-data-id"));
    reflash_zTree('tree_group_move');
    $("#moveGroupConfirmModal").modal('show');
}
function do_move_group(node_id_self, node_id_to)
{
    var url = '/statistic/report_move_group/';
    var post_data = {};
    post_data['group_id'] = node_id_self;
    if(node_id_to != -1)
    {
        post_data['parent_id'] = node_id_to;
    }
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            if(result.status == 0)
            {
                if(node_id_to != $("#input_parent_node_id").val())
                {
                    $("#report_list tr[action-data-id="+node_id_self+"]").remove();
                }
            } 
        }   
    });
}
function copy_report(obj)
{
//    $("#move_report_name").val($(obj).parent().parent().parent().parent().parent().attr("action-data-name")+'-副本');
    $("#copy_report_id").val($(obj).parent().parent().parent().parent().parent().attr("action-data-id"));
    reflash_zTree('tree_report_copy');
    $("#copyReportConfirmModal").modal('show');
}
function jump_copy_page()
{
    var treeObj = $.fn.zTree.getZTreeObj("tree_report_copy");
    var selected = treeObj.getSelectedNodes();
    if(selected.length == 0)
    {
        ark_notify({'status':1,'msg':'请选择要复制到的节点'});
        return;
    }
    var node_id_self = $("#copy_report_id").val();
    var node_id_to = selected[0].id == -1 ? '' : selected[0].id;
    var url = '/statistic/report_copy/?project_id='+$("#input_project_id").val()+'&group_id='+node_id_to+'&report_id='+node_id_self;;
    location.href=url;
//    do_move_report(node_id_self, node_id_to); 
}
function move_report(obj)
{
//    $("#move_report_name").val($(obj).parent().parent().parent().parent().parent().attr("action-data-name")+'-副本');
    $("#move_report_id").val($(obj).parent().parent().parent().parent().parent().attr("action-data-id"));
    reflash_zTree('tree_report_move');
    $("#moveReportConfirmModal").modal('show');
}
function do_move_report(node_id_self, node_id_to)
{
    var url = '/statistic/report_move_report/';
    var post_data = {};
    post_data['report_id'] = node_id_self;
    if(node_id_to != -1)
    {
        post_data['parent_id'] = node_id_to;
    }
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            if(result.status == 0)
            {
                $("#moveReportConfirmModal").modal('hide');
                if(node_id_to != $("#input_parent_node_id").val())
                {
                    $("#report_list tr[action-data-id="+node_id_self+"]").remove();
                }
            } 
        }   
    });
}

function discard_report(obj)
{
    $("#discardConfirmModal #discard_input_reportid").val($(obj).parent().parent().attr("action-data-id"));
    $("#discardConfirmModal").modal('show');
}
function do_discard_report()
{
    var url = '/statistic/report_discard/';
    var report_id = $("#discardConfirmModal #discard_input_reportid").val();
    var post_data = {'report_id':report_id};
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: post_data,
        success: function(result) {
            ark_notify(result);
            if(result.status == 0)
            {
                location.reload(true);
            } 
        }   
    });
}
function reflash_zTree(tree_id)
{
    var project_id = $("#input_project_id").val();
    var url = '/statistic/report_group_tree/' + project_id;
    var zNodes = [{id:"-1", pid:0,name:$("#input_project_name").val(), open:true}];
    $.ajax({
        url: url,
        type: "POST",
        async: false,
        data: {},
        success: function(result) {
            if(result.status == 0)
            {
                for(var i=0;i<result.data.length;i++)
                {
                    var pid_org = result.data[i].pId;
                    var pid = pid_org == '#' ? -1 : parseInt(pid_org.slice(6));
                    zNodes.push({'id':result.data[i].db_id, pId:pid, name:result.data[i].name, isParent:true});
                }
                treeObj = $.fn.zTree.init($("#"+tree_id+""), setting, zNodes);
            } 
            else
            {
                ark_notify(result);
            }
        }   
    });   
}

//function enter_group(obj)
//{
//    //处理新建报表链接
//    var href = $('#btn_create_report').attr('href');
//    var url_pre = '';
//    if(href.indexOf('&') != -1)
//    {
//        url_pre = href.substr(0, href.indexOf('&'));
//    }
//    else
//    {
//        url_pre = href;
//    }
//    var new_href = url_pre+'&report_id='+$(obj).parent().parent().attr('action-data-id');
//    $('#btn_create_report').attr('href', new_href);
//    
//    //更新当前分组id
//    $("#input_group_id").val($(obj).parent().parent().attr('action-data-id'));
//    get_mixed_report_list();
//}
//function get_mixed_report_list()
//{
//    var project_id = $("#input_project_id").val();
//    var group_id = $("#input_group_id").val();
//    var run_time = $(obj).parent().prev().prev().text();
//    var url = '/statistic/report_mixed_report_list/';
//    var post_data = {};
//    post_data['project_id'] = project_id;
//    if(group_id){
//        post_data['group_id'] = group_id;
//    }
//    $.ajax({
//        url: url,
//        type: "POST",
//        async: false,
//        data: post_data,
//        success: function(result) {
//            ark_notify(result);
//        }   
//    });
//
//}
