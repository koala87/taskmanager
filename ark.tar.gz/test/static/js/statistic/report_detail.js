$(function() {
    get_latest_status(
        $("[name=latest_status_dsp]").first(), 
        $("[name=report_status]").first(), _init_report_id);
    $("[name=latest_status_dsp]").click(function() {
        var start_time = null;
        var end_time = $(this).attr("data_time");
        show_run_status($(this), _report_id, start_time, end_time);
    });
    var url = "/statistic/report_admin_users/" + _init_report_id + "/";
    displayLoading($("#report_admin_users"));
    $("#report_admin_users").load(url);
});
