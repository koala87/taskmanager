$(function() {
    var data_time = "";
    var graph_name = '饼图';
    var display_zone_id = 'feat_graph_pie';
    var display_zone = $("#" + display_zone_id);
    var display_zone_ele = document.getElementById(display_zone_id);
    var chart = null;
    var box = $(".feat-table-box[name=pie]");
    var time_selector = $(".feat-table-box[name=pie] input[name=feat_time_selector]");

    window.FeatGraphPie = {
        get_data_time: function() {
            return $(".feat-table-box[name=pie] input[name=feat_time_selector]").val();
        },
        get_data : function(callback){
            var url = "/statistic/feat_graph_pie/" + _report_id + "/";
            data_time = FeatGraphPie.get_data_time()
            if(data_time == "") {
                data_time = TimeRange.get_pre_date(1);
            }

            data = {'data_time': data_time,
                    'select_dims': _select_dims,
                    'dim_filter': JSON.stringify(_dim_filter),
                    'top_n': $(".filter-panel[name=pie] [name=top_n]").val(),
                    'order_feat': $(".filter-panel[name=pie] [name=feat]").val(),}
            makeAPost(url, data, true, FeatGraphPie.callback);
        },
        // 初始化过滤面板
        init_filter: function() {
            var radio = $(".filter-panel[name=pie] input[type=radio][name='feat']");
            if(_basic_feats.length > 0) {
                radio.filter("[value=" + _basic_feats[0] + "]").prop("checked", true);
            } else if(_ext_feats.length > 0) {
                radio.filter("[value=" + _ext_feats[0] + "]").prop("checked", true);
            }
        },
        get_dsp_feat: function() {
            return $(".filter-panel[name=pie] input[type=radio][name='feat']:checked").val();
        },
        make_option: function(data, dsp_feat) {
            if(!data) {
                data = {};
            }
            var legend_data = [''];
            var y_axis_index = 0;

            var dsp_data = data ? data[dsp_feat] : {};
            for(var item in dsp_data) {
                legend_data.push(dsp_data[item].name);
            }
            var series_data = [{
                name: _column_dsp[dsp_feat],
                type: 'pie',
                center: ['50%', '60%'],
                radius: '55%',
                data: dsp_data
            }];

            var title = _column_dsp[dsp_feat] + "（" + dsp_feat + "）";
            var sub_title = "已选维度: " + _select_dims;
            option = StatEcharts.get_pie_option(
                title, sub_title, legend_data, series_data);
            return option;
        },
        display_data: function(data) {
            var dsp_feat = FeatGraphPie.get_dsp_feat();
            var option = FeatGraphPie.make_option(data, dsp_feat);
            chart.setOption(option);
            chart.hideLoading();
        },
        refresh: function() {
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/pie',
            ], function(ec) {
                chart = ec.init(display_zone_ele, 'macarons');
            });

            if(chart) {
                chart.showLoading();
            }
            FeatGraphPie.get_data();
        },
        callback: function(result) {
            if(result.status != 0) {
                result.msg = graph_name + '：' + result.msg;
                ark_notify(result);
            }
            FeatGraphPie.display_data(result.data);
        },
    }

    FeatGraphPie.init_filter();
    $("#btn_pie_query").click(
        function() {
            box.parent().removeClass('filter-panel-open');
            FeatGraphPie.refresh();
        });
    time_selector.change(function() {
        console.log('triggger click...........');
        console.log($(this).defaultValue);
        console.log($(this).val());

        $("#btn_pie_query").trigger("click");
    });
});
