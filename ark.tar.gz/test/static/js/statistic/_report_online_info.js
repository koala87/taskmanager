function get_report_online_info(trigger_obj, report_id)
{
    var url = "/statistic/report_online_info/"+report_id+"/";
    var post_data = {};
    trigger_obj.button("loading");
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            if(result.msg !='')
            {
                ark_notify(result);
            }
            if(result.status == 0)
            {
                html ='';
                html +='<tr><td>上线时间</td><td cols="2">'+result.data.online_time+'</td><td cols="2"></td></tr>';
                html +='<tr><td>过期时间</td><td cols="2">'+result.data.expire_time+'</td><td cols="2"></td></tr>';
                html +='<tr><td>调度时间</td><td cols="2">'+result.data.ct_time+'</td><td cols="2"></td></tr>';
                html +='<tr><td>依赖任务</td>';
                if(result.data.rely_tasks.length > 0) {
                    html += '<td col="2">流程名</td><td col="2">任务名</td></tr>';
                } else {
                    html += '<td col="4">无</td></tr>';
                }
                for(var i in result.data.rely_tasks)
                {
                    html +='<tr><td></td><td col="2">'+result.data.rely_tasks[i].pipeline_name+'</td><td col="2">'+result.data.rely_tasks[i].name+'</td></tr>';
                }
                $("#online_info_modal tbody").html(html);
                $("#online_info_modal").modal('show');
            }
            trigger_obj.button("reset");
        }
    });
}

$(function() {
    $("#status_font").click(function() {
        get_report_online_info($(this), _report_id);
    });
});