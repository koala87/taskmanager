tree_datas = {}
test_tree_data = [
    {id:1, pId:0, name:"1", open:true},
    {id:101, pId:1, name:"101", file:"core/standardData", iconOpen:"fa fa-folder"},
    {id:102, pId:1, name:"102", file:"core/simpleData"},
    {id:103, pId:102, name:"103", file:"core/simpleData"},
    
    {id:2, pId:0, name:"2", open:open},
    {id:206, pId:2, name:"206", file:"excheck/checkbox_nocheck"},
];

function displayLoading(zone) {
    zone.html($("[name=div_loading]").html());
}

var report_tree_setting = {
    view: {
        dblClickExpand: false,
        showLine: false,
    },
    data: {
        simpleData: {
            enable:true,
            idKey: "id",
            pIdKey: "pId",
            rootPId: ""
        }
    },
    callback: {
        beforeClick: function(treeId, treeNode) {
            var zTree = $.fn.zTree.getZTreeObj(treeId);
            if (treeNode.isParent) {
                zTree.expandNode(treeNode);
                return false;
            } else {
                return true;
            }
        },
        onClick: function(event, treeId, treeNode) {
            var zTree = $.fn.zTree.getZTreeObj(treeId);
            if(treeNode.type == 'report') {
                window.history.pushState("", "", '/statistic/report_index/?report_id=' + treeNode.db_id);
                displayLoading($("#report_data"));
                var url = "/statistic/report_data/" + treeNode.db_id + "/";
                $("#report_data").load(url);
                _init_report_id = treeNode.db_id;
            }
        }
    }
};

$(function(){
    $('body').bind('click', function(event) {
        if($('.filter-panel-open').length > 0)
        {
            var evt = event.srcElement ? event.srcElement : event.target;    
            if(evt.name != 'filter-panel-toggle')
            {
                if($(evt).closest(".filter-panel-open .filter-panel").length > 0 || (evt.classList.length>0 && evt.classList[0] == 'filter-panel')) return; // 如果是元素本身，则返回
                else {
                    $('.filter-panel-open').removeClass('filter-panel-open'); // 如不是则隐藏元素
                }
            }
        }   
    });

    function displayProjects(show_allow_only) {
        if(show_allow_only) {
            $(".treeview[can_view_project='False']").hide();
        } else {
            $(".treeview[can_view_project='False']").show();
        }
    }

    $("#ckbox-view-allow-reports").click(function() {
        displayProjects($(this).is(':checked'));
        var active_li = $("li[class='treeview active']");
        
        if(active_li.length > 0) {
            active_li.each(function() {
                var project_id = $(this).find("a").first().attr("project_id");
                loadReports(project_id);
            });
        }
    });

    function custom_tree_data(tree_data) {
        for(var i in tree_data) {
            var type = tree_data[i].type;
            if('group' == type) {
                tree_data[i]['iconSkin'] = 'group';
            } else {
                tree_data[i]['iconSkin'] = 'report';
            }
        }
        return tree_data;
    }

    function loadReports(project_id) {
        var zone = $("#reports_of_" + project_id);
        var allow_only = isShowAllowOnly();

        displayLoading(zone);

        if(tree_datas[allow_only] 
           && tree_datas[allow_only][project_id]) {
            tree_data = tree_datas[allow_only][project_id];
            tree = $.fn.zTree.init(zone, report_tree_setting, tree_data);
            return;
        }

        getReports(project_id, allow_only, function(result) {
            if(result.status != 0) {
                ark_notify(result);
                zone.html("<font color='red'>获取报表失败</font>");
            } else {
                tree_data = result.data;
                tree_data = custom_tree_data(tree_data);
                if(!tree_datas[allow_only])
                    tree_datas[allow_only] = {};
                if(tree_data.length != 0) {
                    tree_datas[allow_only][project_id] = tree_data;
                    tree = $.fn.zTree.init(zone, report_tree_setting, tree_data);
                    if(_init_report_id) {
                        node = tree.getNodeByParam("id", "report_" + _init_report_id);
                        var p_nodes = [];
                        p_node = node.getParentNode();
                        while(p_node) {
                            p_nodes.push(p_node);
                            p_node = p_node.getParentNode();
                        }
                        for(var i = p_nodes.length; i >= 1; i--) {
                            tree.expandNode(p_nodes[i - 1]);
                        }
                        $("#" + node.tId + "_a").trigger("click");
                        // _init_report_id = null;
                    }
                } else {
                    zone.html("<font color='red'>暂无可见报表</font>");
                }
            }
        });
    }

    $("a[name='project']").click(
        function() {
            var project_id = $(this).attr('project_id');
            var parent = $(this).parent();
            if(parent.is('.treeview') && parent.is('.active')) {
                return;
            }
            loadReports(project_id);
        });

    $("button[name=btn_refresh_main_sidebar]").click(
        function() {
            Sidebar.load("1");
        });

    window.Sidebar = {
        load: function(refresh) {
            displayLoading($("#report_sidebar .main-sidebar .sidebar"));
            var url = "/statistic/main_sidebar/?refresh=" + refresh + "&report_id=" + _init_report_id;
            $("#report_sidebar .main-sidebar .sidebar").load(url);
            $("#report_sidebar .main-sidebar .sidebar").slimScroll();
        }
    }

    function autoDisplay() {
        if(_init_project_id) {
            $("a[name=project][project_id="+_init_project_id+"]").trigger("click");
        }
    }

    if(!_sidebar_inited) {
        Sidebar.load("0");
        _sidebar_inited = true;
    }
    autoDisplay();
});

function isShowAllowOnly() {
    return $("#ckbox-view-allow-reports").is(':checked');
}

function getReports(project_id, allow_only, callback) {

    var url = "/statistic/report_tree/";
    var data = {'allow_only': allow_only}
    makeAPost(url + project_id, data, true, callback);
}
