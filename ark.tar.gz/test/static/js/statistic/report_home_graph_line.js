$(function() {
    var graph_name = '线状图';
    var display_zone_id = 'report_home_graph_line';
    var display_zone = $("#" + display_zone_id);
    var display_zone_ele = document.getElementById(display_zone_id);
    var chart = null;
    var graph_type = 'line';

    window.HomeGraphLine = {
        get_data : function(){
            var url = "/statistic/feat_graph_line/" + _report_id + "/";
            data = {};
            result = makeAPost(url, data);
            return result;
        },
        make_option: function(data) {
            if(!data) {
                data = {};
            }
            var legend_data = ['', '已上线报表数','总报表数'];
            var series_data = [{
                                   "name": '已上线报表数',
                                   "type": graph_type,
                                   "data": data.data.online_nums
                               },
                               {
                                   "name": '总报表数',
                                   "type": graph_type,
                                   "data": data.data.total_nums
                               }];
            var title_text = '报表总数量增长趋势';
            option = StatEcharts.get_line_option(
                title_text, data.time_list, legend_data, series_data)
            return option;
        },
        display_data: function(data) {
            var option = HomeGraphLine.make_option(data);
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/line',
                'echarts/chart/bar',
            ], function(ec) {
                chart = ec.init(display_zone_ele, 'macarons');
                chart.setOption(option);
            });

        },
        refresh: function() {
            if(chart) {
                chart.showLoading();
            }
            result = _report_trend;
            HomeGraphLine.display_data(result);
        },
    }

    HomeGraphLine.refresh();
});
