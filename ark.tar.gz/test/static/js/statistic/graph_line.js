$(function() {
    var graph_name = '线状图';
    var display_zone_id = 'feat_graph_line';
    var display_zone = $("#" + display_zone_id);
    var display_zone_ele = document.getElementById(display_zone_id);
    var chart = null;
    var box = $(".feat-table-box[name=line]");
    var time_selector = $(".feat-table-box[name=line] input[name=feat_time_range_selector]").first();
    var time_selector_icon2 = $(".feat-table-box[name=line] input[name=time_selector_icon2]");
    var time_selector2 = $(".feat-table-box[name=line] input[name=feat_time_range_selector]").last();
    var time_picker = time_selector.data("daterangepicker");
    var time_picker2 = time_selector2.data("daterangepicker");
    var max_select_feat_num = 8;
    var start_time;
    var end_time;
    var legend_data = [''];
    var series_data = [];
    var dsp_feats = [];

    window.FeatGraphLine = {
        cmp_mode: function() {
            return $("#time_range_comparor").find("[name=comparor_icon]").hasClass('fa-minus');
        },
        get_time: function() {
            start_time = time_picker.startDate.format(time_format);
            end_time = time_picker.endDate.format(time_format);
        },
        get_cmp_time: function() {
            var cmp_start_time = '';
            var cmp_end_time = '';
            if(FeatGraphLine.cmp_mode()) {
                cmp_start_time = time_picker2.startDate.format(time_format);
                cmp_end_time = time_picker2.endDate.format(time_format);
            }
            return [cmp_start_time, cmp_end_time];
        },
        get_data : function(callback){
            var url = "/statistic/feat_graph_line/" + _report_id + "/";
            FeatGraphLine.get_time();
            var res = FeatGraphLine.get_cmp_time();
            var cmp_start_time = res[0];
            var cmp_end_time = res[1];
            var data = {'start_time': start_time,
                        'end_time': end_time,
                        'cmp_start_time': cmp_start_time,
                        'cmp_end_time': cmp_end_time,
                        'select_dims': _select_dims,
                        'dim_filter': JSON.stringify(_dim_filter),
                        'top_n': $(".filter-panel[name=line] [name=top_n]").val(),
                        'order_feat': $(".filter-panel[name=line] [name=order_feat]").val(),}
            makeAPost(url, data, true, FeatGraphLine.callback);
        },
        // 获取要展现的指标，最多展现两个指标（对应两个坐标轴）
        get_dsp_feats: function() {
            var feats = [];
            $(".filter-panel[name=line] input[type=checkbox][name='feat']:checked").each(function() {
                feats.push($(this).val());
            });
            return feats;
        },
        init_filter: function() {
            var items = $(".filter-panel[name=line] input[type=checkbox][name='feat']");
            var i = 0;
            items.each(function() {
                var feat = $(this).val();
                if(i >= max_select_feat_num) {
                    return true;
                }
                if(_column_show_hide[feat]) {
                    $(this).prop("checked", true);
                    i += 1;
                }
            });
        },
        make_feat_data: function(feat_data, prefix) {
            for(var feat in feat_data) {
                if(dsp_feats.indexOf(feat) == -1) {
                    continue;
                }

                var feat_dsp = _column_dsp[feat];
                if(!feat_dsp) {
                    feat_dsp = feat;
                }
                for(var dim_value in feat_data[feat]) {
                    var dsp = dim_value;
                    if(prefix) {
                        dsp = prefix + dim_value;
                    }
                    if(dsp) {
                        dsp = dsp + " " + feat_dsp;
                    } else {
                        dsp = feat_dsp;
                    }
                    legend_data.push(dsp);
                    series_data.push({
                        "name": dsp,
                        "type": 'line',
                        "yAxisIndex": 0,
                        "data": feat_data[feat][dim_value]
                    });
                }
            }
        },
        make_option: function(data, cmp_data) {
            if(!data) {
                data = {};
            }

            legend_data = [''];
            series_data = [];
            dsp_feats = FeatGraphLine.get_dsp_feats();

            var has_cmp_data = cmp_data && !jQuery.isEmptyObject(cmp_data);
            FeatGraphLine.make_feat_data(data.feat_data, '');
            FeatGraphLine.make_feat_data(cmp_data.feat_data, 'CMP: ');

            var time_list = data.time_list;
            if(has_cmp_data) {
                var cmp_time_list = cmp_data.time_list;
                for(var i in time_list) {
                    time_list[i] += 'vs' + cmp_time_list[i];
                }
            }
            var title_text = '指标对比';
            option = StatEcharts.get_line_option(
                title_text, time_list, legend_data, series_data)
            return option;
        },
        display_data: function(result) {
            var data = result.data;
            var cmp_data = result.cmp_data;
            var option = FeatGraphLine.make_option(data, cmp_data);
            chart.setOption(option);
            chart.hideLoading();
        },
        refresh: function() {
            require([
                'echarts',
                'echarts/theme/macarons',
                'echarts/chart/line',
                'echarts/chart/bar',
            ], function(ec) {
                chart = ec.init(display_zone_ele, 'macarons');
            });

            if(chart) {
                chart.showLoading();
            }
            FeatGraphLine.get_data();
        },
        callback: function(result) {
            if(result.status != 0) {
                result.msg = graph_name + "：" + result.msg;
                ark_notify(result);
            }
            FeatGraphLine.display_data(result);
        },
    }

    FeatGraphLine.init_filter();
    $("#btn_line_query").click(
        function() {
            box.parent().removeClass('filter-panel-open');
            FeatGraphLine.refresh();
        });
    time_selector.change(function() {
        box.parent().removeClass('filter-panel-open');
        FeatGraphLine.refresh();
    });

    $("#time_range_comparor").click(
        function() {
            $(this).find("[name=comparor_icon]").toggleClass('fa-plus');
            $(this).find("[name=comparor_icon]").toggleClass('fa-minus');
            time_selector_icon2.toggle();
            time_selector2.toggle();
        });

    time_selector2.change(function() {
        FeatGraphLine.refresh();
    });
});

