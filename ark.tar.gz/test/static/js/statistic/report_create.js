parsed_result_json = {};
$(function(){
    $("#report_sql").autoHeight();
    $(".ui-sortable").sortable();
    $(document).on('click', '.fa-trash-o', function(){
        $(this).parent().parent().remove();
    });
    //设置可选图表的比例
    $(".chart_type_item").each(function(){
        $(this).height($(this).width()*180/280);
    });
    $(".choosed_chart_list").parent().css('min-height', $(".chart_type_item").eq(0).height());
    $(document).on('click', '#add_norm', function(){
        $('.norm-list').append('<li>\
                    <span class="handle ui-sortable-handle" style="width:2%;">\
                      <i class="fa fa-ellipsis-v"></i>                      <i class="fa fa-ellipsis-v"></i>\
                    </span>                    <span class="text" style="width:53%;"><input type="text"  style="width:30%;" placeholder="指标" />&nbsp;=&nbsp;<input type="text" style="width:63%;" placeholder="运算表达式" /></span>\
                    <span class="text" style="width:20%;">\
                        <input type="text" style="width:100%;" placeholder="显示名" />\
                    </span>\
                    <span class="text" style="width:13%;">\
                        <label class="checkbox-inline"><input type="checkbox" value="2" checked>默认展现</label>\
                    </span>\
                    <div class="tools" style="display: inline-block;">\
                      <i class="fa fa-trash-o" style="font-size: 22px;"></i>\
                    </div>\
                  </li>');
    });
    $(document).on('click', '#add_real_feats', function(){
        $('#parsed_ul').append('<li>\
                                    <span class="handle ui-sortable-handle">\
                                        <i class="fa fa-ellipsis-v"></i>\
                                        <i class="fa fa-ellipsis-v"></i>\
                                    </span>\
                                    <span class="text">\
                                        指标\
                                    </span>\
                                    <span class="text">\
                                        <input type="text" placeholder="字段">\
                                    </span>\
                                    <span class="text">\
                                        <input type="text" placeholder="显示名">\
                                    </span>\
                                    <span class="text">\
                                        <label class="checkbox-inline" onclick="dim_change(this)"><input type="checkbox" value="1">设为维度</label>\
                                        <label class="checkbox-inline"><input type="checkbox" value="2" checked>默认展现</label>\
                                    </span>\
                                    <div class="tools" style="display: inline-block;">\
                                        <i class="fa fa-trash-o" style="font-size: 22px;"></i>\
                                    </div>\
                                </li>');
    });
    $(document).on('click', '#create_odps_norm_btn', function(){
        $("#create_odps_norm_btn").button('loading');
        var url = '/statistic/report_create/';
        upsert_report(url, this);
    });
    $(document).on('click', '#copy_odps_norm_btn', function(){
        $("#copy_odps_norm_btn").button('loading');
        //$("#copy_odps_norm_btn").val('loading');
        //$("#copy_odps_norm_btn").attr('disabled', true);
        var url = '/statistic/report_copy/';
        upsert_report(url, this);
    });
    $(document).on('click', '#update_odps_norm_btn', function(){
        var obj = this;
        var url_update_confirm = '/statistic/report_update_check/';
        var post_data = {};
        post_data['report_id'] = $("#input_report_id").val().trim();
        var config = get_new_dim_and_feats();
        post_data['dimensions'] = JSON.stringify(config['dimensions']);
        post_data['basic_feats'] = JSON.stringify(config['basic_feats']);
        $.ajax({
            url: url_update_confirm,
            type: "POST",
            async: true,
            data: post_data,
            success: function(result) {
                if(result.status == 0)
                {
                    if(result.data.length != 0)
                    {
                        //由用户确认
                        var warning_html = '';
                        for(var i=0;i<result.data.length;i++)
                        {
                            warning_html += '<p>'+result.data[i]+'</p>';
                        }
                        $("#normChangeConfirmModal .modal-body").html(warning_html);
                        $("#normChangeConfirmModal").modal('show');
                    }
                    else
                    {
                        $("#update_odps_norm_btn").button('loading');
                        do_update_report(obj); 
                    }
                }
                else
                {
                    ark_notify(result);
                    return;
                }
            }
        });
    });
    $(document).on('click', '#report_parse', function(){
        $("#report_parse").button('loading');
        var url = '/statistic/report_sql_parse/';
        var post_data = {};
        post_data['sql'] = $("#report_sql").val().trim();
        //TODO
        $.ajax({
            url: url,
            type: "POST",
            async: true,
            data: post_data,
            success: function(result) {
                parsed_result_json = result;
                $("#report_parse").button('reset');
                if(result.status == 0)
                {
                    if(result.msg != '' && result.msg != [])
                    {
                        ark_notify(result);
                    }
                    $("#parsed_exchange_modal .modal-body").html('<p>您确定要用如下解析结果替换原有内容吗?</p>');
                    if($("#parsed_ul li").length > 0)
                    {
                        if(!exist_sql_modify())
                        {
                            return;
                        }
                        var dim_arr = [];
                        var feat_arr = [];
                        for(var i=0;i<parsed_result_json.data.length;i++)
                        {
                            if(parsed_result_json.data[i].is_dimension)
                            {
                                dim_arr.push(parsed_result_json.data[i].name);
                            }
                            else
                            {
                                feat_arr.push(parsed_result_json.data[i].name);
                            }
                        }
                        var html = '';
                        if(dim_arr.length == 0)
                        {
                            dim_arr.push('无');
                        }
                        if(feat_arr.length == 0)
                        {
                            feat_arr.push('无');
                        }
                        html += '<p>&nbsp;&nbsp;维度:&nbsp;&nbsp;'+dim_arr.join(', ')+'</p>';
                        html += '<p>&nbsp;&nbsp;指标:&nbsp;&nbsp;'+feat_arr.join(', ')+'</p>';
                        $("#parsed_exchange_modal .modal-body").append(html);
                        $("#parsed_exchange_modal").modal('show');
                    }
                    else
                    {
                        do_parse_exchange();
                    }
                }
                else
                {
                    ark_notify(result);
                    if($("#parsed_ul li").length == 0)
                    {
                        do_parse_exchange();
                    }
                }
            }
        });
    });
    $(document).on('click', '#choose_img_list .chart_type_item', function(){
        var img_obj = $(this).find('img');
        if(img_obj[0].className.trim() == 'choosed')
        {
            return;
        }
        else
        {
            img_obj.removeClass();
            img_obj.addClass("choosed");
        }
        var html = '<li>\
                            <span class="handle ui-sortable-handle">\
                            <i class="fa fa-ellipsis-v"></i>\
                            <i class="fa fa-ellipsis-v"></i>\
                            </span>\
                        <span class="text" action-data="'+$(this).attr("action-data")+'">'+$(this).attr("action-data-name")+'</span>\
                        <div class="tools" style="display:inline-block;margin-left: 22px;">\
                        <i class="fa fa-trash-o chart_type_delete" style="font-size: 22px;"></i>\
                        </div>\
                    </li>';
        $(".choosed_chart_list").append(html);
    });
    $(document).on('click', '.choosed_chart_list .chart_type_delete', function(){
        var chart_type = $(this).parent().prev().attr('action-data');
        var item_left = $("#choose_img_list .chart_type_item[action-data='"+chart_type+"'] img");
        item_left.removeClass();
        item_left.addClass("unchoosed");
        $(this).parent().parent().remove();
    });
});

function get_odps_sql_config()
{
    var ret = {};
    ret['dimensions'] = [];
    ret['basic_feats'] = [];
    $("#parsed_ul li").each(function(index){
        if($(this).find('[type="checkbox"]').eq(0).is(':checked'))
        {
            ret['dimensions'].push({
                'name':$(this).find('span').eq(2).find('input').val().trim(),
                'dsp_tag':$(this).find('span').eq(3).find('input').val().trim(),
                'select':$(this).find('[type="checkbox"]').eq(1).is(':checked') ? 1 : 0,
                'pos':index
            });
        }
        else
        {
            ret['basic_feats'].push({
                'name':$(this).find('span').eq(2).find('input').val().trim(),
                'dsp_tag':$(this).find('span').eq(3).find('input').val().trim(),
                'select':$(this).find('[type="checkbox"]').eq(1).is(':checked') ? 1 : 0,
                'pos':index
            });
        }
    });
    ret['ext_feats'] = [];
    $(".norm-list li").each(function(){
        ret['ext_feats'].push({
            'name':$(this).find('input').eq(0).val().trim(),
            'calcu':$(this).find('input').eq(1).val().trim(),
            'dsp_tag':$(this).find('input').eq(2).val().trim(),
            'select':$(this).find('[type="checkbox"]').eq(0).is(':checked') ? 1 : 0
        });
    });
    ret['odps_sql'] = $("#report_sql").val().trim();

    return ret;
}

function get_new_dim_and_feats()
{
    var ret = {};
    ret['dimensions'] = [];
    ret['basic_feats'] = [];
    $("#parsed_ul li").each(function(){
        if($(this).find('[type="checkbox"]').eq(0).is(':checked'))
        {
            ret['dimensions'].push($(this).find('span').eq(2).find('input').val().trim());
        }
        else
        {
            ret['basic_feats'].push($(this).find('span').eq(2).find('input').val().trim());
        }
    });

    return ret;
}
function get_odps_sql_graphs()
{
    var ret = [];
    $(".choosed_chart_list li").each(function(){
        ret.push({'type':$(this).find("span").eq(1).attr('action-data')});
    });
    return ret;
}
function upsert_report(url, obj){
    var post_data = {};
    post_data['project_id'] = $("#input_project_id").val();
    if($("#input_group_id").val().trim())
    {
        post_data['group_id'] = $("#input_group_id").val();
    }
    post_data['report_type'] = 1;
    if($("#input_report_id").val())
    {
        post_data['report_id'] = $("#input_report_id").val().trim();
    }
    post_data['cycle'] = $(".exec_cycle:checked").val();
    post_data["delay"] = $("#id_delay").val().trim();
    post_data["feat_keep_days"] = $("#id_feat_keep_days").val().trim();
    post_data['name'] = $("#report_name").val().trim();
    post_data['description'] = $("#report_desc").val().trim();
    post_data['config'] = JSON.stringify(get_odps_sql_config());
    post_data['graphs'] = JSON.stringify(get_odps_sql_graphs());
    console.log(post_data);
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            $(obj).button('reset');
            ark_notify(result);
            if(result.status == 0)
            {
                var reload_url = "/statistic/report_manager/?project_id="+$("#input_project_id").val();
                if($("#input_group_id").val())
                {
                    reload_url += "&group_id="+$("#input_group_id").val();
                }
                window.location.href = reload_url;
            }
        }
    });
}
function do_update_report(obj)
{
    var url_update = '/statistic/report_update/';
    upsert_report(url_update, obj);
}
function dim_change(obj)
{
    if($(obj).find("input").is(":checked") == true)
    {
        $(obj).parent().prev().prev().prev().css('color','#FEB219');
        $(obj).parent().prev().prev().prev().html('维度');
    }
    else
    {
        $(obj).parent().prev().prev().prev().css('color','#000');
        $(obj).parent().prev().prev().prev().html('指标');
    }
}
function exist_sql_modify()
{
    var ret = false;
    var history_conf = get_history_conf();
    if(parsed_result_json.data.length == Object.keys(history_conf).length)
    {
        for(var i=0;i<parsed_result_json.data.length;i++)
        {
            if(history_conf[parsed_result_json.data[i].name] == undefined || history_conf[parsed_result_json.data[i].name].is_dimension != parsed_result_json.data[i].is_dimension)
            {
                ret = true;
            }
        }
    }
    else
    {
        ret = true;
    }

    return ret;
}
function do_parse_exchange()
{
   var history_conf = get_history_conf();
   result = parsed_result_json;
   $("#parsed_ul").empty();
   $("#parsed_res").show();
   for(var i=0; i<result.data.length;i++)
   {
       var dsp_name = (history_conf[result.data[i].name] != undefined && history_conf[result.data[i].name].dsp_tag) ? history_conf[result.data[i].name].dsp_tag : result.data[i].name; 
       if(result.data[i].is_dimension || (history_conf[result.data[i].name] != undefined && history_conf[result.data[i].name].is_dimension))
       {
           var str_flag_tip = '维度';
           var str_checkbox = ' checked ';
           var str_style = ' style="color: #FEB219;"' ;
       }
       else
       {
           var str_flag_tip = '指标';
           var str_checkbox = '';
           var str_style = '' ;
       }
       $("#parsed_ul").append('<li>\
                                   <span class="handle ui-sortable-handle">\
                                       <i class="fa fa-ellipsis-v"></i>\
                                       <i class="fa fa-ellipsis-v"></i>\
                                   </span>\
                                   <span class="text"'+str_style+'>'+str_flag_tip+'</span>\
                                   <span class="text">\
                                       <input type="text" placeholder="字段" value="'+result.data[i].name+'">\
                                   </span>\
                                   <span class="text">\
                                       <input type="text" placeholder="显示名" value="'+dsp_name+'">\
                                   </span>\
                                   <span class="text">\
                                       <label class="checkbox-inline" onclick="dim_change(this)"><input type="checkbox" value="1" '+str_checkbox+'>设为维度</label>\
                                       <label class="checkbox-inline"><input type="checkbox" value="2" checked>默认展现</label>\
                                   </span>\
                                   <div class="tools" style="display: inline-block;">\
                                       <i class="fa fa-trash-o" style="font-size: 22px;"></i>\
                                   </div>\
                               </li>');
   }

}
var cur_sql_textarea_height = "126px";
jQuery.fn.extend({
    autoHeight: function(){
        return this.each(function(){
            var $this = jQuery(this);
            if( !$this.attr('_initAdjustHeight') ){
                $this.attr('_initAdjustHeight', '126px');
            }
            $(this).css("max-height",$(document.body).height()*0.6+"px");
            _adjustH(this).on('input', function(){
                _adjustH(this);
            });
            $(this).on('blur',function(){
                $(this).height(cur_sql_textarea_height);
            });
            $(this).on('focus',function(){
                cur_sql_textarea_height = $(this).height();
                _adjustH(this);
            });
        });
        /**
         * 重置高度 
         * @param {Object} elem
         */
        function _adjustH(elem){
            var $obj = jQuery(elem);
            return $obj.css({height: $obj.attr('_initAdjustHeight'), 'overflow-y': 'auto'})
                    .height( elem.scrollHeight );
        }
    }
});
function get_history_conf()
{
    var history_conf = {};
    $("#parsed_ul li").each(function(){
        history_conf[$(this).find('span').eq(2).find('input').val().trim()] = {
                'dsp_tag':$(this).find('span').eq(3).find('input').val().trim(),
                'is_dimension':$(this).find('[type="checkbox"]').eq(0).is(':checked') ? 1 : 0
            };
    });
    return history_conf;
}
function return_prev_page()
{
    if ((navigator.userAgent.indexOf('MSIE') >= 0) && (navigator.userAgent.indexOf('Opera') < 0)){ // IE
            if(history.length > 0){  
                window.history.go( -1 );  
            }else{  
                window.opener=null;window.close();  
            }  
    }
    else{ //非IE浏览器  
        if (navigator.userAgent.indexOf('Firefox') >= 0 ||  
            navigator.userAgent.indexOf('Opera') >= 0 ||  
            navigator.userAgent.indexOf('Safari') >= 0 ||  
            navigator.userAgent.indexOf('Chrome') >= 0 ||  
            navigator.userAgent.indexOf('WebKit') >= 0){  
    
            if(window.history.length > 1){  
                window.history.go( -1 );  
            }else{  
                window.opener=null;window.close();  
            }  
        }else{ //未知的浏览器  
            window.history.go( -1 );  
        }  
    }
}
