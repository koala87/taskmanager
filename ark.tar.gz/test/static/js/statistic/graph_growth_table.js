$(function() {
    var data_time = "";
    var diff_keys = ["day_diff", "week_diff", "month_diff"];
    var display_zone = $(".feat-table-box[name=growth_table] .feat-graph");
    var box = $(".feat-table-box[name=growth_table]");
    var time_selector = $(".feat-table-box[name=growth_table] input[name=feat_time_selector]");

    window.FeatGraphGrowthTable = {
        get_data_time: function() {
            return time_selector.val();
        },
        get_dsp_feats: function() {
            var feats = [];
            $(".filter-panel[name=growth_table] input[type=checkbox][name='feat']:checked").each(function() {
                feats.push($(this).val());
            });
            return feats;
        },
        init_filter: function() {
            var items = $(".filter-panel[name=growth_table] input[type=checkbox][name='feat']");
            items.each(function() {
                $(this).prop("checked", true);
            });
        },
        get_data : function(callback){
            var url = "/statistic/feat_graph_growth_table/" + _report_id + "/";
            data_time = FeatGraphGrowthTable.get_data_time();
            if(data_time == "") {
                data_time = TimeRange.get_pre_date(1);
            }

            data = {'data_time': data_time,
                    'select_dims': _select_dims,
                    'dim_filter': JSON.stringify(_dim_filter),
                    'order_feat': $(".filter-panel[name=growth_table] [name=order_feat]").val(),}
            makeAPost(url, data, true, FeatGraphGrowthTable.callback);
        },
        display_data: function(data, dim_cond) {
            html = "<table class='table table-bordered table-hover'>";
            html += "<caption><center>维度条件：" + dim_cond + "</center></caption>";
            html += "<tr><th>" + data_time + "</th>" 
                + "<th>值</th><th>同比昨天</th>"
                + "<th>同比上周变化率</th>"
                + "<th>同比上月变化率</th></tr>";
            var dsp_feats = FeatGraphGrowthTable.get_dsp_feats();
            for(var feat in data) {
                if(dsp_feats.indexOf(feat) == -1) {
                    continue;
                }

                var feat_dsp = _column_dsp[feat];
                html += "<tr><td>" + feat_dsp + "</td>" + "<td>" + data[feat]['value'] + "</td>";
                for(var i in diff_keys) {
                    var key = diff_keys[i];
                    var value = data[feat][key];
                    var color = "black";
                    if(value && value > 0) {
                        color = "red";
                    } else if (value && value < 0) {
                        color = "green";
                    } else {
                        color = "blue";
                    }

                    if(value) {
                        value = value * 100;
                        value = value.toFixed(2) + "%";
                    } else {
                        value = "无";
                    }

                    html += "<td>"
                    html += "<font color='" + color + "'>";
                    html += value;
                    html += "</font>";
                    html += "</td>";
                }
                html += "</tr>";
            }
            if(Object.keys(data).length === 0) {
                html += "<tr><td colspan=5>当天无数据，可能未产出</td></tr>"
            }
            html += "</table>";
            display_zone.html(html);
        },
        refresh: function() {
            displayLoading(display_zone);
            result = FeatGraphGrowthTable.get_data();
        },
        callback: function(result) {
            if(result.status != 0) {
                result.msg = '同比表格图：' + result.msg;
                ark_notify(result);
            }
            FeatGraphGrowthTable.display_data(result.data, result.dim_cond);
        },
    }

    FeatGraphGrowthTable.init_filter();
    $("#btn_growth_table_query").click(
        function() {
            $(this).parent().parent().removeClass('filter-panel-open');
            FeatGraphGrowthTable.refresh();
        });
    time_selector.change(function() {
        box.parent().removeClass('filter-panel-open');
        FeatGraphGrowthTable.refresh();
    });

});
