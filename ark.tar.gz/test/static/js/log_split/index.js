view_dialog_id = 'view_dialog'
query_data_table = null;

function get_busy_html(channel_id) {
    busy_obj = $('#row_detail_div').clone().prop({id:'row_detail_div_' + channel_id});
    busy_obj.show();
    return busy_obj[0];
}

$(function(){
})

