var host_table = null;
var query_data_table;
var global_pl_id = 0;
var global_data_source = 0;

function showMessage(type,title,msg){
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg){
    showMessage("error","错误提示",msg);
}

function checkParam(){
    try{
        return true;
    }catch(err){
        return false;
    } 
    return false;
}

function query_action(busy) {
    if (busy) {
        $("#run_busy").show()
        $('#log_config_btn').attr('disabled',"true");
    } else {
        $("#run_busy").hide()
        $('#log_config_btn').removeAttr("disabled"); 
    }
}
function querySubmitAjax(){
    if(!checkParam()){
        query_action(false);
        return false;
    }
    var url = "/log_split/addTask/";
    var param = $("#log_config_form").serialize();
    $.ajax({
        type :'post',
        url : url,
        dataType : "json",
        data : param,
        success : function(result) {
            if(result.status){
                showErrorMessage(result.msg); 
            }else{
                hideModal();
                showMessage('info', '成功', result.msg); 
                load_table_list();
            }
            query_action(false);
        }
    });
}

function addTask(){
    $("#log_config_modal").modal({
        backdrop:false,
        show:true,        
    });
    $("#log_config_btn_reset").click();
    $("#config_id").val("");
    update_log_source(0);
}

function hideModal(){
    $('#log_config_modal').modal('hide');
    return false;
}

function query_action(busy) {
    if (busy) {
        $("#run_busy").show()
        $('#query_form_btn').attr('disabled',"true");
    } else {
        $("#run_busy").hide()
        $('#query_form_btn').removeAttr("disabled"); 
    }
}

function update_log_source(sourceType) {
    $("#log_source_area").empty();
    sel = $("<select id=\"config_source_name\" name=\"source_name\" style=\"width:200px;height:30px;table-layout: fixed;margin-left:23px;\">");
    if (sourceType == 0) {
        $("<option value=\"table_raw_click_s_aliyun_com_access\">全网JS打点服务器</option>").appendTo(sel);
        $("<option value=\"table_raw_shenma_third_party_nginx_access\">自有应用打点</option>").appendTo(sel);
        $("<option value=\"table_raw_ali_new_online_web_fpm\">全网PHP打点服务器</option>").appendTo(sel);
        $("<option value=\"s_tt_shenma_click_rec_access_tt4\">推荐日志打点服务器</option>").appendTo(sel);
    } else {
        $("<option value=\"table_100002_logdata\">table_100002_logdata</option>").appendTo(sel);
        $("<option value=\"raw_web_normal_activity_logdata\">raw_web_normal_activity_logdata</option>").appendTo(sel);
    }
    sel.appendTo($("#log_source_area"));
}

function show_config(id){
    url = "/log_split/get_config/";
    post_data = "id="+id;
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            if(result.status==0){
                //show modal
                $("#log_config_modal").modal({
                    backdrop:false,
                    show:true,        
                });
                config = result.data; 
                $("#config_id").val(config.id);
                $("#config_name").val(config.name);
                $("#config_service_name").val(config.service_name);
                if(config.source_type==0){
                    update_log_source(config.source_type);
                    $("#log_source_type0").attr("checked","checked");
                    $("#config_source_name").val(config.source_name); 
                }else{
                    update_log_source(config.source_type);
                    $("#log_source_type1").attr("checked","checked");
                    $("#config_source_name").val(config.source_name); 
                }
                $("#config_output_table").val(config.output_table); 
                $("#config_lifecycle").val(config.lifecycle); 
                $("#config_condition_fields").val(config.condition_fields); 
                $("#config_condition").val(config.condition); 
                $("#config_output_schema").val(config.output_schema); 
                $("#config_description").val(config.description); 
                $("#config_decode_fields").val(config.decode_fields); 
                $("#id_description").val(config.description); 
            }
        }
    });

}

function del_config(id){
    url = "/log_split/del_config/";
    post_data = "id="+id;
    if(window.confirm("确定删除该条目？")) {
        $.ajax({
            url: url,
            type: "POST",
            async: true,
            data: post_data,
            success: function(result) {
                if(result.status==0){
                    showMessage("success","操作提示",result.msg); 
                    load_table_list();
                }else{
                    showErrorMessage(result.msg);
                }
            }
        });
    }
}

function update_status(id,status){
    $("#updateStatusFrmModel").modal({backdrop:false, show:true});
    $("#update_status_id").val(id);  
    $("#update_status_code").val(status);  
    if(status==0){
        $("#confirm_msg_text").html("您确认下线该日志吗？");  
    }else if(status==1){
        $("#confirm_msg_text").html("您确认申请上线该日志吗？");  
    }else if(status==2){
        $("#confirm_msg_text").html("您确认同意上线该日志吗？");  
    }
}

function do_update_status(){
    id  = $("#update_status_id").val();  
    status = $("#update_status_code").val();  
    url = "/log_split/update_status/";
    post_data = "id="+id+"&status="+status;
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            if(result.status==0){
                showMessage("success","操作提示",result.msg); 
                load_table_list();
            }else{
                showErrorMessage(result.msg);
            }
        }
    });
}

function load_table_list(){
    url = "/log_split/list/";
    post_data = "";
    $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: post_data,
        success: function(result) {
            var html = '<table class="table table-bordered table-hover" id="log_config_table" style="table-layout: fixed;">\
<thead>\
<td style="width:3%;">#</td>\
<td style="width:7%;">日志名</td>\
<td style="width:6%;">创建者</td>\
<td style="width:7%;">业务线</td>\
<td style="width:10%;">数据源</td>\
<td style="width:5%;">生命周期</td>\
<td style="width:5%;">状态</td>\
<td style="width:10%;">更新时间</td>\
<td style="width:10%;">操作</td>\
</thead>\
<tbody>';
            if(result.status == 0)
            {
                for(var i=0;i<result.data.length;i++)
                {
                    html += '<tr>'+
                        '<td>'+(i+1)+'</td>'+
                        '<td>'+result.data[i].name+'</td>'+
                        '<td>'+result.data[i].username_dsp+'</td>'+
                        '<td>'+result.data[i].service_name+'</td>'+
                        '<td>'+result.data[i].source_name+'</td>'+
                        '<td>'+result.data[i].lifecycle+'天</td>'+
                        '<td>'+result.data[i].status+'</td>'+
                        '<td>'+result.data[i].update_time+'</td>'+
                        '<td style="text-align:center;">'+
                        '<a type="button" href="#" title="查看" rel="tooltip" onclick="show_config('+result.data[i].id+');"><font class="oper-Font">查看</font></a>&nbsp;&nbsp;'+
                        '<a type="button" href="#" title="删除" rel="tooltip" onclick="del_config('+result.data[i].id+');"><font class="oper-Font">删除</font></a>&nbsp;&nbsp;';
                    if(result.data[i].status=='未上线')
                    {
                        html+='<a type="button" href="#" title="上线" onclick="update_status('+result.data[i].id+',1);"><font class="oper-Font">申请上线</font></a>&nbsp;&nbsp;';
                    }
                    if(result.data[i].status=='审核中' && result.is_super==1)
                    {
                        html+='<a type="button" href="#" title="同意" onclick="update_status('+result.data[i].id+',2);"><font class="oper-Font">同意</font></a>&nbsp;&nbsp;';
                        html+='<a type="button" href="#" title="拒绝" onclick="update_status('+result.data[i].id+',0);"><font class="oper-Font">拒绝</font></a>&nbsp;&nbsp;';
                    }
                    if(result.data[i].status=='已上线')
                    {
                        html+='<a type="button" href="#" title="下线" onclick="update_status('+result.data[i].id+',0);"><font class="oper-Font">下线</font></a>&nbsp;&nbsp;';
                        var report_id = 974;
                        var url = "http://shudu.sm.cn/statistic/report_index/?report_id=" + report_id + '&dim_filter=[["output_table","eq","' + result.data[i].output_table + '"],["counter_name","eq","output_total"]]';
                        html+="<a type='button' href='" + url + "'><font class='oper-Font'>趋势</font></a>";
                    }
                    html+=  '</td>'+
                        '</tr>';
                }
            }
            else
            {
                showErrorMessage(result.msg);
            }
            html += '</tbody></table>';
            $("#log_config_table_list").html(html);
            $('#log_config_table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        }
    });
}

$(document).ready(function(){    
    load_table_list();
    
    $("#log_config_submit").click(function(){
        addTask();
    });
    

    $("#log_config_btn").click(function(){
        document.documentElement.scrollTop = document.body.scrollTop =0;
        querySubmitAjax();
        return false;
    });
});
