var host_table = null;
var url_data_table;
var global_pl_id = 0;
var global_data_source = 0;

function showMessage(type,title,msg){
    new PNotify({
        title: title,
        text: msg,
        addclass: 'custom',
        type: type
    });
}

function showErrorMessage(msg){
    showMessage("error","错误提示",msg);
}

function get_pre_date(offset) {
    var date = new Date();
    date.setDate(date.getDate() - offset)
    return date.toISOString().slice(0,10);
}

function get_pre_month(offset) {
    var date = new Date();
    date.setMonth(date.getMonth() - offset)
    return date.toISOString().slice(0,10);
}

function url_sieving_submit() {
    $('#wait_busy_icon').show();
    $('#submit_button').attr('disabled', "true");
    url = "/url_search/list/"
    url_data_table.ajax.url(url).load();
}

function show_query(query_list) {    
    if (query_list != "") {
        query_list = query_list.split('^');
        var tb = document.getElementById('_table');
        var rowNum=tb.rows.length;
        for (i=0;i<rowNum;i++) {
            tb.deleteRow(i);
            rowNum=rowNum-1;
            i=i-1;
        }

        $("#preview_div", window.parent.document).modal('show');

        var row = document.createElement("tr");
        document.getElementById("_table").appendChild(row);
        table = ["query", "点击数"];
        for (cell in table) {
            var key_cell = document.createElement("td");
            key_cell.innerText = table[cell];
            key_cell.style.fontWeight="bold";
            row.appendChild(key_cell);
        }

        for (var i = 0; i < query_list.length; i++) {
            var row = document.createElement("tr");
            document.getElementById("_table").appendChild(row);
            item_list = query_list[i].split(':');
            for (var field_idx = item_list.length - 1; field_idx >= 0; --field_idx) {
                var key_cell = document.createElement("td");
                inner_html = item_list[field_idx];
                inner_html = inner_html.replace(new RegExp("\002", 'gm'), "#");
                inner_html = inner_html.replace(new RegExp("\005", 'gm'), "'");
                src_html = inner_html
                inner_html_list = inner_html.split('?');
                inner_html = inner_html_list[0];
                for (var inner_idx = 1; inner_idx < inner_html_list.length; ++inner_idx) {
                    inner_html += '\003' + inner_html_list[inner_idx];
                }

                if (field_idx == 1) {
                    inner_html = '<a style = "text-decoration:none;" href="/query_search/other_list/' + inner_html + '\001' + $('#time_field').val() + '/" target="_blank">&nbsp;&nbsp;' + src_html + '</a>';
                }
                key_cell.innerHTML = inner_html;
                row.appendChild(key_cell);
            }
        }
    }

}

$(function(){
    url_data_table = $('#url_search_table').DataTable({
        "processing": true,
        "serverSide": true,
        "paging": false,
        "searching": false,
        "ajax": {
            "url": "/url_search/list/",
            "type": "POST",
            "async": true,
            "data": function ( d ) {
                d.date_period = $('#time_field').val();
                d.url = $('#url').val();
            }
        },
        "columnDefs": [
            {
                "targets": [0],
                "searchable": false,
                "bSortable": false,
                "data": "time",
            },
            {
                "targets": [1],
                "searchable": false,
                "bSortable": false,
                "data": "url",
                "render": function(data, type, full) {
                    return '<a style="text-decoration:none;" href="' + data + '" target="_blank">'+ data + '</a>';
                }
            },
            {
                "targets": [2],
                "searchable": false,
                "bSortable": false,
                "data": "clicks",
            },
            {
                "targets": [3],
                "searchable": false,
                "bSortable": false,
                "render": function(data, type, full) {
                    full.query_list = full.query_list.replace(new RegExp("#", 'gm'), "\002");
                    full.query_list = full.query_list.replace(new RegExp("'", 'gm'), "\005");
                    return '<a style="text-decoration:none;" href="javascript:void(0);" onclick="show_query(\'' + full.query_list + '\');">[ 查看 ]</a>';
                }
            },
        ],

        "iDisplayLength": 100,
    });

    url_data_table.on( 'draw.dt', function () {
        $('#wait_busy_icon').hide();
        $('#submit_button').removeAttr("disabled");
    } );

    end_date = yesterday = get_pre_date(1);
    start_date = end_date;
    last_week = get_pre_date(7);
    last_month = get_pre_month(1);
    $('#time_field').daterangepicker(
            {
                "ranges": {
                    "昨天": [
                        yesterday,
                        yesterday
                    ],
                    "近一周": [
                        last_week,
                        yesterday
                    ],
                    "近一个月": [
                        last_month,
                        yesterday
                    ],
                },
                "locale": {
                    "applyLabel": "确定",
                    "cancelLabel": "取消",
                    "fromLabel": "From",
                    "toLabel": "To",
                    "customRangeLabel": "自定义时间",
                    "daysOfWeek": [
                        "日", 
                        "一", 
                        "二", 
                        "三", 
                        "四", 
                        "五", 
                        "六"
                    ],
                    "monthNames": [
                        "一月",  
                        "二月",  
                        "三月",  
                        "四月",
                        "五月",
                        "六月",
                        "七月",
                        "八月",
                        "九月",
                        "十月",
                        "十一月",
                        "十二月"
                    ],
                    "firstDay": 1
                },
                opens: (App.isRTL() ? 'left' : 'right'),
                format: 'yyyy-MM-dd',
                separator: ' to ',
                startDate: yesterday,
                endDate: yesterday,
                minDate: last_month,
                maxDate: yesterday
            }
        );
   
    $("#time_field").val(start_date+" to "+end_date);
    $(document).mousewheel(function(event, delta) {
        mousewheelEvent(event,delta);
    });

    if($('#other_query').val() != ""){
        $('#url').val($('#other_query').val());
        $('#time_field').val($('#other_date').val());
        url = "/url_search/list/"
        url_data_table.ajax.url(url).load();
    }

});
function mousewheelEvent(e, delta) {
    $(".daterangepicker").eq(0).css("display","none");    
}
