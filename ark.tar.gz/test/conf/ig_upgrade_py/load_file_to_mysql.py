###############################################################################
# coding: utf-8
#
# Copyright (c) 2016 alibaba-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
将本地文件数据写入mysql

Authors: xielei.xl(xielei.xl@alibaba-inc.com)
"""

import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import os
import exceptions
import traceback
import hashlib
import json
import datetime

import pymysql
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.styles import Color
from openpyxl import load_workbook

import no_block_sys_cmd

class LoadFileToMysql(object):
    def __init__(self, file_path, table_name, cols):
        self.__file_path = file_path
        self.__table_name = table_name
        self.__cols = json.loads(cols)
        '''
        self.__sql_conn = pymysql.connect(
                host='11.251.177.179',
                port=3306,
                user='root',
                passwd='*ark_123456',
                db='ark_tools',
                charset='utf8')
        '''
        self.__sql_conn = pymysql.connect(
                host='11.226.2.70',
                port=13309,
                user='logarktools',
                passwd='iOid3978Ld9KdshKdf',
                db='log_ark_tools',
                charset='utf8')

        self.__hash_code_set = set()
        self.__no_block_cmd = no_block_sys_cmd.NoBlockSysCommand(None)

    def run(self):
        self.__get_all_hash_code_from_mysql()

        print self.__file_path
        if self.__file_path.endswith(".xls") or self.__file_path.endswith(".xlsx"):
            self.__load_excel_data()
        else:
            self.__load_odps_table_data()
        print "insert mysql ended"
        #self.__update_dict_end_update_time()
        print "update time ended"

    def __update_dict_end_update_time(self):
        now_time = datetime.datetime.utcnow() + datetime.timedelta(hours=8)
        now_time = now_time.strftime("%Y-%m-%d %H:%M:%S")
        dict_id = self.__table_name.split('_')[-1]
        sql = "update `interest_graphs_dict` set `data_end_update_time`='%s' where `id` = %s;" % (
                now_time, 
                dict_id)
        print sql
        cursor = self.__sql_conn.cursor()
        cursor.execute(sql) 
        self.__sql_conn.commit()

    def __load_excel_data(self):
        values_list = []
        col_len = len(self.__cols)
        update_str, cols_str = self.__get_update_col_sql()

        progress_fd = open('progress.log', 'w')
        line_count = 0
        wb2 = load_workbook(self.__file_path)
        ws = wb2[wb2.get_sheet_names()[0]]

        unvalid_num = 0
        all_line_num = 0

        header_passed = False
        for row in ws.rows:
            if not header_passed:
                header_passed = True
                continue

            line_list = []
            for cell in row:
                '''
                x = cell.value
                v = x
                if isinstance(x, unicode):
                    v = x.encode('utf8')
                elif not isinstance(x, basestring):
                    v = str(x)
                '''
                line_list.append(str(cell.value))

            line = '\t'.join(line_list)

            line_count += 1
            all_line_num += 1
            line = line.replace("'", " ")
            line = line.replace("\\", " ")
            m = hashlib.md5(line)
            hash_code = m.hexdigest()
            if hash_code in self.__hash_code_set:
                continue

            self.__hash_code_set.add(hash_code)
            line_split = line.split('\t')
            if len(line_split) != col_len:
                unvalid_num += 1
                continue

            tmp_val_list = []
            for i in range(0, col_len):
                if line_split[i] == '':
                    tmp_val_list.append("NULL")
                    continue

                if (self.__cols[i]["value_type"].startswith('varchar') or 
                        self.__cols[i]["value_type"] == 'text'):
                    tmp_val_list.append("'%s'" % line_split[i].strip())
                else:
                    tmp_val_list.append("%s" % line_split[i].strip())

            tmp_val_list.append("'%s'" % hash_code)
            values_list.append('(%s)' % ','.join(tmp_val_list))

            if len(values_list) >= 2000:
                sql = "insert into %s (%s) values %s on duplicate key update %s;" % (
                        self.__table_name,
                        cols_str,
                        ','.join(values_list),
                        update_str)
                cursor = self.__sql_conn.cursor()
                cursor.execute(sql) 
                self.__sql_conn.commit()
                values_list = []
                progress_fd.write("%s/%s\n" % (line_count, all_line_num))
                progress_fd.flush()

        if len(values_list) > 0:
            sql = "insert into %s (%s) values %s on duplicate key update %s;" % (
                    self.__table_name,
                    cols_str,
                    ','.join(values_list),
                    update_str)
            cursor = self.__sql_conn.cursor()
            cursor.execute(sql) 
            self.__sql_conn.commit()
            values_list = []
            progress_fd.write("%s/%s\n" % (all_line_num, all_line_num))

        if float(unvalid_num) / float(all_line_num) > 0.5:
            progress_fd.write("数据字段数与给定mysql字段数不一致！\n")
            progress_fd.close()
            raise exceptions.Exception("数据字段数与给定mysql字段数不一致！")
        progress_fd.write("%s/%s\n" % (all_line_num, all_line_num))
        progress_fd.close()

    def __load_odps_table_data(self):
        values_list = []
        col_len = len(self.__cols)
        update_str, cols_str = self.__get_update_col_sql()

        fd = open(self.__file_path, 'r')
        progress_fd = open('progress.log', 'w')
        all_line_num = self.__get_file_line()
        line_count = 0
        unvalid_num = 0
        while True:
            line = fd.readline()
            if line is None or line == '':
                break

            line_count += 1
            line = line.replace("'", " ")
            line = line.replace("\\", " ")
            m = hashlib.md5(line)
            hash_code = m.hexdigest()
            if hash_code in self.__hash_code_set:
                continue

            self.__hash_code_set.add(hash_code)
            line_split = line.split('\t')
            if len(line_split) != col_len:
                unvalid_num += 1
                continue

            tmp_val_list = []
            for i in range(0, col_len):
                if line_split[i] == '':
                    tmp_val_list.append("NULL")
                    continue

                if (self.__cols[i]["value_type"].startswith('varchar') or 
                        self.__cols[i]["value_type"] == 'text'):
                    tmp_val_list.append("'%s'" % line_split[i].strip())
                else:
                    tmp_val_list.append("%s" % line_split[i].strip())

            tmp_val_list.append("'%s'" % hash_code)
            values_list.append('(%s)' % ','.join(tmp_val_list))

            if len(values_list) >= 2000:
                sql = "insert into %s (%s) values %s on duplicate key update %s;" % (
                        self.__table_name,
                        cols_str,
                        ','.join(values_list),
                        update_str)
                cursor = self.__sql_conn.cursor()
                cursor.execute(sql) 
                self.__sql_conn.commit()
                values_list = []
                progress_fd.write("%s/%s\n" % (line_count, all_line_num))
                progress_fd.flush()

        if len(values_list) > 0:
            sql = "insert into %s (%s) values %s on duplicate key update %s;" % (
                    self.__table_name,
                    cols_str,
                    ','.join(values_list),
                    update_str)
            cursor = self.__sql_conn.cursor()
            cursor.execute(sql) 
            self.__sql_conn.commit()
            values_list = []
            progress_fd.write("%s/%s\n" % (all_line_num, all_line_num))

        fd.close()
        if float(unvalid_num) / float(all_line_num) > 0.5:
            progress_fd.write("数据字段数与给定mysql字段数不一致！\n")
            progress_fd.close()
            raise exceptions.Exception("数据字段数与给定mysql字段数不一致！")

        progress_fd.close()

    def __get_update_col_sql(self):
        update_list = []
        cols_str_list = []
        for col in self.__cols:
            update_list.append('%s=values(%s)' % (col["col_name"], col["col_name"]))
            cols_str_list.append(col["col_name"])

        update_list.append('%s=values(%s)' % ('hash_code', 'hash_code'))
        cols_str_list.append("hash_code")
        return ','.join(update_list), ','.join(cols_str_list)

    def __get_all_hash_code_from_mysql(self):
        start_pos = 0
        while True:
            tmp_sql = ("select hash_code from %s limit %s, 100000;" % (
                    self.__table_name, start_pos))
            cursor = self.__sql_conn.cursor()
            cursor.execute(tmp_sql) 
            rows = cursor.fetchall()
                
            for row in rows:
                self.__hash_code_set.add(row[0])
                
            if len(rows) < 100000:
                break

            start_pos += 100000

    def __get_file_line(self):
        cmd = "wc -l %s | awk -F' ' '{print $1}'" % self.__file_path
        stdout, stderr, ret = self.__no_block_cmd.run_once(cmd)
        return int(stdout)

if __name__ == '__main__':
    file_path = sys.argv[1]
    table_name = sys.argv[2]
    cols = sys.argv[3]
    file_to_sql = LoadFileToMysql(file_path, table_name, cols)
    file_to_sql.run()
