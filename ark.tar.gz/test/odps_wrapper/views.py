#coding=utf-8
from django.shortcuts import render
import logging
import sys
sys.setrecursionlimit(10000)
import os
import json
import datetime
import exceptions
from django.contrib.auth import authenticate
from django.conf import settings
from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.db.models import Q
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import StreamingHttpResponse
from common.http_helper import * 
from models import OdpsCommandInfo 

import ConfigParser
from django.http import StreamingHttpResponse

config = ConfigParser.RawConfigParser()
config.read("./conf/tools.conf")
pu_cmd = config.get("query_tools", "pu_cmd").strip()
pangu_path = config.get("query_tools", "pangu_path").strip()
local_path = config.get("query_tools", "local_path").strip()

# Create your views here.
ignore_cmds = [
    'LoginCommand',
    'UseProjectCommand',
    'MachineReadableCommand',
    'InteractiveCommand',
    'HelpCommand',
    'ShowVersionCommand',
    'FinanceJsonCommand',
    'SetRetryCommand',
    'SkipCommand',
    'InstancePriorityCommand',
    'DryRunCommand',
    'AccessUrlCommand',
    'AlterMatrixLifecycleCommand',
    'AuthorizationCommand',
    'CreateMatrixCommand',
    'ShowTablesCommand',
    'UnSetCommand',
    'UpdateCommand',
    'WhoamiCommand',
]

STAGE_START = "1"
STAGE_AFTER = "2"
STAGE_FINISHED = "3"
def heartbeat(request):
    try:
        stage = request.GET.get('stage')
        if STAGE_START == stage:
            project = request.GET.get('project')
            end_point = request.GET.get('end_point')
            access_id = request.GET.get('access_id')
            access_key = request.GET.get('access_key')
            proirity = request.GET.get('proirity')
            cmd_type = request.GET.get('cmd_type')
            cmd_text = request.GET.get('cmd_text')
            instance_id = request.GET.get('instance_id')
            instance_status = request.GET.get('instance_status')
            entity = OdpsCommandInfo()
            if proirity:
                entity.priority =  int(proirity)
            entity.project = project
            entity.end_point = end_point 
            entity.access_id = access_id 
            entity.access_key = access_key 
            entity.cmd_type = cmd_type 
            entity.cmd_text = cmd_text 
            entity.start_time = datetime.datetime.now() 
            entity.creator = User.objects.get(id = 13)
            entity.save()
            return JsonHttpResponse({'status':0,'sm_dp_id':str(entity.id)})
        elif STAGE_AFTER==stage or STAGE_FINISHED==stage:
            sm_dp_id = request.GET.get('sm_dp_id')
            instance_id = request.GET.get('instance_id')
            instance_status = request.GET.get('instance_status')
            if sm_dp_id:
                entity = OdpsCommandInfo.objects.get(id = int(sm_dp_id)) 
                if instance_id:
                    entity.instance_id = instance_id 
                if instance_status:
                    entity.instance_status = instance_status 
                entity.end_time = datetime.datetime.now() 
                entity.save()
                return JsonHttpResponse({'status':0,'sm_dp_id':str(entity.id)})
        elif STAGE_FINISHED==stage:
            pass
        return JsonHttpResponse({'status':0})
    except Exception, ex:
        logger.error('get pipeline abstract info failed: <%s>' % str(ex))
    return JsonHttpResponse({'status':1})

def init(request):
    try:
        print 'start'
        project = request.GET.get('project')
        end_point = request.GET.get('end_point')
        access_id = request.GET.get('access_id')
        access_key = request.GET.get('access_key')
        proirity = request.GET.get('proirity')
        cmd_type = request.GET.get('cmd_type')
        cmd_text = request.GET.get('cmd_text')
        entity = OdpsCommandInfo()
        if proirity:
            entity.priority =  int(proirity)
        entity.project = project
        entity.end_point = end_point 
        entity.access_id = access_id 
        entity.access_key = access_key 
        entity.cmd_type = 'initCommand'
        entity.cmd_text = '' 
        entity.start_time = datetime.datetime.now() 
        entity.end_time = datetime.datetime.now() 
        entity.creator = User.objects.get(id = 13)
        entity.save()
        ignore_cmds_str = ','.join(ignore_cmds)
        return JsonHttpResponse(
            {'status':0,'ignore_cmd':ignore_cmds_str})
    except Exception, ex:
        logger.error('process init request failed: <%s>' % str(ex))
        return JsonHttpResponse(
            {'status':1,'msg':str(ex)})


