#encoding:utf-8
import sys
reload(sys)  
sys.setdefaultencoding('utf-8')
import logging
import traceback
import django.db
from django.db import models
from django.conf import settings
import django.db.models
import django.core.exceptions

logger = logging.getLogger(settings.PROJECT_NAME)

class OdpsCommandInfoManager(models.Manager):

    def create_one(self, commandInfo):
        try:
            commandInfo.save()
        except Exception, ex:
            logger.error('create instance fail: (%s)' % str(ex))
            print traceback.format_exc()

        return commandInfo 
