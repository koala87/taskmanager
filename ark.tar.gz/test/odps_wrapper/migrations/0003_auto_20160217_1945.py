# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('odps_wrapper', '0002_auto_20160217_1911'),
    ]

    operations = [
        migrations.AddField(
            model_name='odpscommandinfo',
            name='cmd_text',
            field=models.CharField(default=b'', max_length=5000, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='odpscommandinfo',
            name='cmd_type',
            field=models.CharField(default=b'', max_length=50, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='odpscommandinfo',
            name='end_point',
            field=models.CharField(default=b'', max_length=500, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='odpscommandinfo',
            name='instance_status',
            field=models.CharField(default=b'', max_length=10, null=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='odpscommandinfo',
            name='end_time',
            field=models.DateTimeField(null=True),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='odpscommandinfo',
            name='start_time',
            field=models.DateTimeField(null=True),
            preserve_default=True,
        ),
    ]
