# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='OdpsCommandInfo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('priority', models.IntegerField(default=0, db_index=True)),
                ('start_time', models.DateTimeField()),
                ('end_time', models.DateTimeField()),
                ('instance_id', models.CharField(default=b'', max_length=50, null=True)),
                ('access_key', models.CharField(default=b'', max_length=50, null=True)),
                ('access_id', models.CharField(default=b'', max_length=50, null=True)),
                ('project', models.CharField(default=b'', max_length=50, null=True)),
                ('creator', models.ForeignKey(related_name='creator', to=settings.AUTH_USER_MODEL)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
