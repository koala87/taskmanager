from django.conf.urls import patterns, url
from odps_wrapper import views

urlpatterns = patterns('',
    url(r'^heartbeat/$',views.heartbeat),
    url(r'^init/$',views.init),
)
