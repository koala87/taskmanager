#encoding:utf-8
import sys
import random
import re
import logging
from django.core.validators import MaxLengthValidator
from django.core.validators import RegexValidator
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)
from odps_command_info_manager import OdpsCommandInfoManager 

class OdpsCommandInfo(models.Model):

    class Meta:
        pass

    creator = models.ForeignKey(User, related_name = 'creator')

    priority = models.IntegerField(default=0)
    start_time = models.DateTimeField(auto_now_add = False,null=True)
    end_time = models.DateTimeField(auto_now_add = False,null=True)

    instance_id = models.CharField(max_length=50, default='', null=True)
    instance_status = models.CharField(max_length=10, default='', null=True)
    access_key = models.CharField(max_length=50, default='', null=True)
    access_id = models.CharField(max_length=50, default='', null=True)
    project = models.CharField(max_length=50, default='', null=True)
    cmd_type = models.CharField(max_length=50, default='', null=True)
    cmd_text = models.CharField(max_length=5000, default='', null=True)
    end_point = models.CharField(max_length=500, default='', null=True)

    objects = OdpsCommandInfoManager()

