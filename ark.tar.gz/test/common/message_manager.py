import logging
from django.db import models
from django.conf import settings
from ark_user.admin import get_site_admin, alarm

logger = logging.getLogger(settings.PROJECT_NAME)

from django.contrib.auth.models import User

class MessageManager(models.Manager):

    def site_notice(self, receiver, content, send_mail = False, 
                    mail_subject = '', msg_type = 0):
        logger.debug('send mail to:%s, content:%s' % (str(receiver), content))
        admin, email = get_site_admin()
        self.send(admin, receiver, content, send_mail = send_mail,
                  mail_subject = mail_subject, msg_type = msg_type)

    def send(self, sender, receiver, content, send_mail = False, 
             mail_subject = '', msg_type = 0):
        if isinstance(receiver, User):
            receiver = [receiver]

        for item in receiver:
            self.create(
                sender = sender,
                receiver = item,
                content = content,
                type = msg_type)

        logger.debug('send mail to:%s, content:%s' % (str(receiver), content))
        if send_mail and mail_subject:
            alarm(mail_subject, content, user_list = receiver)

    # id_list: id or id list
    # delete a list of messages
    def delete(self, id = None, receiver = None, read = None):
                
        if id is None and receiver is None and read is None:
            raise Exception('at least 1 argument is given')
        
        id_list = id
        if isinstance(id, int) or isinstance(id, long):
            id_list = [id]

        messages = None
        if isinstance(id_list, list):
            messages = self.select_for_update().filter(id__in = id_list)
        if receiver is not None:
            messages = messages.filter(receiver = receiver)
        if read is not None and isinstance(read, bool):
            messages = messages.filter(read = read)

        try:
            messages.update(deleted = True)
        except Exception, ex:
            logger.error('delete messages fail: <%s>' % str(ex))
            raise Exception('delete messages fail')

        return True

    def read(self, id = None, receiver = None):

        if id is None and receiver is None:
            raise Exception('at least 1 argument is given')
        
        if id is None:
            id = []
        id_list = id
        if not isinstance(id, list):
            try:
                id_list = [long(id)]
            except Exception, ex:
                logger.error('invalid param, id:%s' % str(id))
                raise ex

        messages = None
        if isinstance(id_list, list) and id_list:
            messages = self.select_for_update().filter(id__in = id_list)
        if receiver is not None:
            if messages:
                messages = messages.filter(receiver = receiver)
            else:
                messages = self.select_for_update().filter(receiver = receiver)
            
        try:
            messages.update(read = True)
        except Exception, ex:
            logger.error('read messages fail: <%s>' % str(ex))
            raise Exception('read messages fail')

        return True
        
    # list user's messages
    def list(self, receiver, read = None):
                
        messages = self.filter(receiver = receiver).exclude(deleted = True)
        if read is not None and isinstance(read, bool):
            messages = messages.filter(read = read)

        return messages

    # list user's messages
    def count(self, receiver, read = None):
             
        messages = self.list(receiver, read)
        return messages.count()



