#coding:utf8
import logging
import datetime
logger = logging.getLogger('common')

from horae.tools_util import TaskState
class PipelineStatus():

    @staticmethod
    def has_log_status(status):
        return status in (
            TaskState.TASK_RUNNING, 
            TaskState.TASK_SUCCEED, 
            TaskState.TASK_FAILED, 
            TaskState.TASK_STOPED_BY_USER, )

    @staticmethod
    def is_terminated(status):
        return status in (
            TaskState.TASK_SUCCEED, 
            TaskState.TASK_FAILED, 
            TaskState.TASK_STOPED_BY_USER, 
            TaskState.TASK_PREV_FAILED, )

