from django.conf.urls import patterns, url
from common import pangu_views as views

urlpatterns = patterns('',
    url(r'^download_file/$', views.download_file),
    url(r'^ls/$', views.ls),
)


