#coding:utf8
import logging
import traceback
from django.db import models

logger = logging.getLogger('common')

class OpHistoryManager(models.Manager):
    def add(self, operator, obj, info):
        app = obj._meta.app_label
        klass = obj._meta.object_name
        self.create(
            operator = operator, app = app,
            klass = klass,
            info = info)

