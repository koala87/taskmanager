from django.test import TestCase
from django.contrib.auth.models import User
from models import PermHistory
from dms.models import Config

# Create your tests here.
class PermHistoryTest(TestCase):

    def setUp(self):
        self.user1 = User.objects.create(username = 'user1')
        self.user2 = User.objects.create(username = 'user2')
        self.user3 = User.objects.create(username = 'user3')
        self.user4 = User.objects.create(username = 'user4')
 
        self.data_config1 = Config.objects.create(
            owner = self.user1,
            name = 'test1',
            type = Config.TYPE_ODPS,
            path = "odps://table_name:day='%yyyy%%mm%%dd%'",
            update_user = self.user1)
            

    def test_grant(self):
        
        resource_type = Config.__name__
        PermHistory.objects.grant(
            grantor = self.user1,
            recipient = self.user2,
            resource_type = resource_type,
            resource_id = self.data_config1.id,
            reason = 'test_grant')

        self.assertEqual(1, PermHistory.objects.all().count())

        PermHistory.objects.grant(
            grantor = self.user1,
            recipient = [self.user3, self.user4],
            resource_type = resource_type,
            resource_id = self.data_config1.id,
            reason = 'test_grant')

        items = PermHistory.objects.filter(
                grantor = self.user1,
                permission = 'read',
                resource_type = resource_type,
                resource_id = self.data_config1.id,
                status = PermHistory.GRANTED_STATUS)
        self.assertEqual(3, items.count())
        self.assertEqual(1, items.filter(applicant = self.user2).count())
        self.assertEqual(1, items.filter(applicant = self.user3).count())
        self.assertEqual(1, items.filter(applicant = self.user4).count())
        

    def test_revoke(self):
        
        resource_type = Config.__name__
        PermHistory.objects.revoke(
            revoker = self.user1,
            resource_type = resource_type,
            resource_id = self.data_config1.id,
            from_user = self.user2,
            reason = 'test_revoke',
            update = True,
            execute = True)

        self.assertEqual(1, PermHistory.objects.filter(
                grantor = self.user1,
                applicant = self.user2,
                permission = 'update|execute',
                resource_type = resource_type,
                resource_id = self.data_config1.id,
                status = PermHistory.REVOKED_STATUS).count())

    def test_apply(self):
        
        resource_type = Config.__name__
        PermHistory.objects.apply(
            applicant = self.user2,
            resource_type = resource_type,
            resource_id = self.data_config1.id,
            grantor = self.user1,
            reason = 'test_apply',
            update = True,
            execute = True)

        self.assertEqual(1, PermHistory.objects.all().count())
        self.assertEqual(1, PermHistory.objects.filter(
                grantor = self.user1,
                applicant = self.user2,
                permission = 'read|update|execute',
                reason = 'test_apply',
                resource_type = resource_type,
                resource_id = self.data_config1.id,
                status = PermHistory.PENDING_STATUS).count())

        PermHistory.objects.apply(
            applicant = self.user2,
            resource_type = resource_type,
            resource_id = self.data_config1.id,
            grantor = self.user1,
            reason = 'test_apply_update',
            execute = True)
        self.assertEqual(1, PermHistory.objects.all().count())
        self.assertEqual(1, PermHistory.objects.filter(
                grantor = self.user1,
                applicant = self.user2,
                permission = 'read|execute',
                reason = 'test_apply_update',
                resource_type = resource_type,
                resource_id = self.data_config1.id,
                status = PermHistory.PENDING_STATUS).count())


    def test_accept(self):

        resource_type = Config.__name__
        item = PermHistory.objects.apply(
            applicant = self.user2,
            resource_type = resource_type,
            resource_id = self.data_config1.id,
            grantor = self.user1,
            reason = 'test_accept',
            update = True,
            execute = True)

        PermHistory.objects.accept(hist_id = item.id,
                                   reason = 'accepted')

        self.assertEqual(1, PermHistory.objects.all().count())
        self.assertEqual(1, PermHistory.objects.filter(
                grantor = self.user1,
                applicant = self.user2,
                permission = 'read|update|execute',
                resource_type = resource_type,
                resource_id = self.data_config1.id,
                status = PermHistory.ACCEPTED_STATUS).count())


    def test_deny(self):

        resource_type = Config.__name__
        item = PermHistory.objects.apply(
            applicant = self.user2,
            resource_type = resource_type,
            resource_id = self.data_config1.id,
            grantor = self.user1,
            reason = 'test_accept',
            update = True,
            execute = True)

        PermHistory.objects.deny(hist_id = item.id,
                                 reason = 'accepted')

        self.assertEqual(1, PermHistory.objects.all().count())
        self.assertEqual(1, PermHistory.objects.filter(
                grantor = self.user1,
                applicant = self.user2,
                permission = 'read|update|execute',
                resource_type = resource_type,
                resource_id = self.data_config1.id,
                status = PermHistory.DENIED_STATUS).count())


    def test_list(self):
        resource_type = Config.__name__

        PermHistory.objects.create(
            resource_type = resource_type, resource_id = self.data_config1.id,
            permission = 'read', grantor = self.user1, applicant = self.user2,
            reason = 'test', status = PermHistory.PENDING_STATUS)

        PermHistory.objects.create(
            resource_type = resource_type, resource_id = self.data_config1.id,
            permission = 'update', grantor = self.user1, applicant = self.user2,
            reason = 'test', status = PermHistory.GRANTED_STATUS)

        objs = PermHistory.objects.list(
            Config.__name__, self.data_config1.id, self.user1)
        self.assertEqual(2, objs.count())

        objs = PermHistory.objects.list(
            Config.__name__, self.data_config1.id, self.user1,
            pending_only = True)
        self.assertEqual(1, objs.count())
