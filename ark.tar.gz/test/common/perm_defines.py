
PERM_TYPE_READ = 'read'
PERM_TYPE_UPDATE = 'update'
PERM_TYPE_DELETE = 'delete'
PERM_TYPE_EXECUTE = 'execute'
PERM_TYPES = (PERM_TYPE_READ, PERM_TYPE_UPDATE, 
              PERM_TYPE_DELETE, PERM_TYPE_EXECUTE)
PERM_SEP = '|'

def parse_permission(permission):

    perms = {}
    if isinstance(permission, basestring):
        for perm in permission.split(PERM_SEP):
            if perm in PERM_TYPES:
                perms[perm] = True
    return perms


def make_permission(read = None, update = None, 
                    delete = None, execute = None):
        
    perms = ((PERM_TYPE_READ, read),
             (PERM_TYPE_UPDATE, update),
             (PERM_TYPE_DELETE, delete),
             (PERM_TYPE_EXECUTE, execute))
    perm_list = []
    for perm, value in perms:
        if True == value:
            perm_list.append(perm)
    return PERM_SEP.join(perm_list)
