import time
import datetime
from django.test import TestCase
from ark_time import *

# Create your tests here.
class ArkTimeTest(TestCase):

    def setUp(self):
        pass

    def test_make_range_time(self):

        start = '20150401'
        end = '20150403'
        # daily, cut
        result = ArkTime.make_range_time(start, end)
        self.assertEqual(['20150401', '20150402'], result)

        result = ArkTime.make_range_time(start, end, include_right = True)
        self.assertEqual(['20150401', '20150402', '20150403'], result)

        # daily, not cut
        result = ArkTime.make_range_time(start, end, cut_str = False)
        self.assertEqual(['20150401000000', '20150402000000'], result)

        # hourly
        start = '2015040101'
        end = '2015040103'
        result = ArkTime.make_range_time(start, end, frequency = FREQUENCY_HOURLY)
        self.assertEqual(['2015040101', '2015040102'], result)

        # minutely
        start = '201504010203'
        end = '201504010205'
        result = ArkTime.make_range_time(start, end, 
                                         frequency = FREQUENCY_MINUTELY)
        self.assertEqual(['201504010203', '201504010204'], result)
        result = ArkTime.make_range_time(start, end, 
                                         frequency = FREQUENCY_MINUTELY, 
                                         cut_str = False)
        self.assertEqual(['20150401020300', '20150401020400'], result)

        # range length is 1
        start = '2015040102'
        end = '2015040102'
        result = ArkTime.make_range_time(start, end, frequency = FREQUENCY_DAILY)
        self.assertEqual(['20150401'], result)

        start = '20150401'
        end = '20150401'
        result = ArkTime.make_range_time(
            start, end, frequency = FREQUENCY_DAILY, include_right = True)
        self.assertEqual(['20150401'], result)


    def test_timing_freq(self):
        self.assertTrue(ArkTime.timing_freq('day'))
        self.assertTrue(ArkTime.timing_freq('hour'))
        self.assertTrue(ArkTime.timing_freq('minute'))
        self.assertFalse(ArkTime.timing_freq('other'))

    def test_get_time(self):
        time_str = '20150403'
        result = ArkTime.get_time(time_str)
        new_time_str = datetime.date.strftime(result, TIME_FORMAT_14)
        self.assertEqual('20150403000000', new_time_str)

        result = ArkTime.get_time(time_str, offset = -1)
        new_time_str = datetime.date.strftime(result, TIME_FORMAT_14)
        self.assertEqual('20150402000000', new_time_str)

        result = ArkTime.get_time(time_str, frequency = FREQUENCY_HOURLY, offset = -2)
        new_time_str = datetime.date.strftime(result, TIME_FORMAT_14)
        self.assertEqual('20150402220000', new_time_str)

        result = ArkTime.get_time(time_str, frequency = FREQUENCY_MINUTELY, offset = -2)
        new_time_str = datetime.date.strftime(result, TIME_FORMAT_14)
        self.assertEqual('20150402235800', new_time_str)

        base_time = datetime.datetime.now()
        result = ArkTime.get_time(base_time, frequency = FREQUENCY_HOURLY, 
                                  offset = -2)
        print 'get_time hour delay 2:', result
        result = ArkTime.get_time(base_time, frequency = FREQUENCY_DAILY, offset = -2)
        print 'get_time day delay 2:', result

        
    def test_get_pre_day(self):
        time_str = '20150403'
        result = ArkTime.get_pre_day(time_str, -1, str_result = True, cut_str = True)
        self.assertEqual('20150404', result)

        time_str = '2015040304'
        result = ArkTime.get_pre_day(time_str, -1, str_result = True, cut_str = True, frequency = 'hour')
        self.assertEqual('2015040404', result)
        
    def test_get_pre_time(self):
        time_str = '20150403'
        result = ArkTime.get_pre_time(time_str, 'day', -1, str_result = True, cut_str = True)
        self.assertEqual('20150404', result)

        time_str = '20150403'
        result = ArkTime.get_pre_time(time_str, 'hour', -1, str_result = True, cut_str = True)
        self.assertEqual('2015040301', result)

        
    def test_get_pre_hour(self):
        time_str = '20150403'
        result = ArkTime.get_pre_hour(time_str, -1, str_result = True, cut_str = True)
        self.assertEqual('2015040301', result)

        time_str = '2015040304'
        result = ArkTime.get_pre_hour(time_str, -1, str_result = True, cut_str = True)
        self.assertEqual('2015040305', result)

        
    def test_get_pre_week(self):
        time_str = '20150403'
        result = ArkTime.get_pre_week(time_str, str_result = True)
        self.assertEqual('20150327000000', result)

        time_str = '20150403'
        result = ArkTime.get_pre_week(time_str, offset = 2, str_result = True)
        self.assertEqual('20150320000000', result)



    def test_get_pre_month(self):
        time_str = '20150331'
        result = ArkTime.get_pre_month(time_str, str_result = True)
        self.assertEqual('20150228000000', result)

        time_str = '20150329'
        result = ArkTime.get_pre_month(time_str, str_result = True)
        self.assertEqual('20150228000000', result)

        time_str = '20150327'
        result = ArkTime.get_pre_month(time_str, str_result = True)
        self.assertEqual('20150227000000', result)

        time_str = '20150831'
        result = ArkTime.get_pre_month(time_str, offset = 2, str_result = True)
        self.assertEqual('20150630000000', result)


    def test_get_real_path(self):

        time_str = '20150403060708'
        base_time = datetime.datetime.strptime(time_str, TIME_FORMAT_14)
        path = 'pangu://AY54/test/%year%_%month%_%day%/%hour%/%min%/%sec%/'
        self.assertEqual('pangu://AY54/test/2015_04_03/06/07/08/',
                         ArkTime.get_real_path(path, base_time))
        self.assertEqual('pangu://AY54/test/2015_04_02/06/07/08/',
                         ArkTime.get_real_path(path, base_time, offset = -1))

        path = 'pangu://AY54/test/%yyyy%_%mm%_%dd%/%HH%/%MM%/%SS%/'
        self.assertEqual('pangu://AY54/test/2015_04_03/06/07/08/',
                         ArkTime.get_real_path(path, base_time))

        path = 'pangu://AY54/test/%yyyy%%mm%%dd%/%HH%/'
        self.assertEqual('pangu://AY54/test/20150403/06/',
                         ArkTime.get_real_path(path, base_time))

        # single hour: 06-->6
        path = 'pangu://AY54/test/%yyyy%_%m%_%d%/%H%/%M%/%S%/'
        self.assertEqual('pangu://AY54/test/2015_4_3/6/7/8/',
                         ArkTime.get_real_path(path, base_time))

        # support for {} tag
        path = 'pangu://AY54/test/{yyyymmdd}/{hh}/'
        self.assertEqual('pangu://AY54/test/20150403/06/',
                         ArkTime.get_real_path(path, base_time))
