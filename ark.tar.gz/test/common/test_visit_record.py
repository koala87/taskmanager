from django.test import TestCase
from django.contrib.auth.models import User
from models import VisitRecord
        

# Create your tests here.
class VisitRecordTest(TestCase):

    def setUp(self):
        self.user1 = User.objects.create(username = 'user1')
        self.user2 = User.objects.create(username = 'user2')

    def test_all(self):
        self.assertEqual(0, VisitRecord.objects.all().count())
        VisitRecord.add('t1', 'uri11')
        VisitRecord.add('t1', 'uri11', user = self.user1)
        VisitRecord.add('t1', 'uri12', user = self.user1)
        VisitRecord.add('t1', 'uri12', user = self.user2)
        VisitRecord.add('t2', 'uri21')
        VisitRecord.add('t2', 'uri21', user = self.user1)
        VisitRecord.add('t2', 'uri21', user = self.user2)
        self.assertEqual(7, VisitRecord.objects.all().count())

        self.assertEqual(7, VisitRecord.count())
        self.assertEqual(4, VisitRecord.count({'app': 't1'}))
        self.assertEqual(2, VisitRecord.count(
                {'app': 't1', 'uri': 'uri11'}))
        self.assertEqual(3, VisitRecord.count(
                {'app': 't2', 'uri': 'uri21'}))
        self.assertEqual(1, VisitRecord.count(
                {'app': 't2', 'uri': 'uri21', 'user': self.user2}))


