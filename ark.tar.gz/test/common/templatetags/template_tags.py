#encoding:utf-8
import logging
import json
import traceback
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)

from common.ark_perm import is_admin
from common.models import Message
from common.models import Config

from django import template
register = template.Library()

@register.assignment_tag
def user_is_admin(user):
    result = is_admin(user)
    return result

@register.simple_tag
def user_display(user):
    dsp = user.username
    try:
        info = user.user_info
        if info.ali_name:
            dsp = info.ali_name
    except:
        pass
    return dsp

@register.simple_tag
def message_count(user):
    count = Message.objects.count(user,False)
    return count

@register.assignment_tag
def system_header_urls():
    value = Config.objects.get_config_value(
        'sys_header_urls')
    urls = []
    for item in value.split('\n'):
        item = item.strip()
        parts = item.split()
        if len(parts) != 2:
            logger.error('invalid sys_header_urls config, %s' % item)
        else:
            urls.append([parts[0], parts[1],])
    return urls
                        

@register.assignment_tag
def home_sys_introductions():
    infos = []
    value = Config.objects.get_config_value(
        'home_sys_introductions')
    try:
        infos = json.loads(value)
    except:
        logger.error('parse home_sys_introductions fail, %s' % traceback.format_exc())

    return infos

                        
@register.assignment_tag
def ark_main_site_host(user):
    value = Config.objects.get_config_value(
        'ark_main_site_host')
    return value









