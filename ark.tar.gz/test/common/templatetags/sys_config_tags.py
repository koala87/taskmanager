#encoding:utf-8
import logging
from common.models import Config
from django.conf import settings
logger = logging.getLogger('statistic')

from django import template
register = template.Library()

@register.simple_tag
@register.filter
def get_data_url():
    return Config.objects.get_config_value(
        'sys_url_data', '/data/index/')






