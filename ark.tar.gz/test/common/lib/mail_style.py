#!/bin/env python
#-*- coding: utf-8 -*-
common_style = '''
<style type="text/css">
html, body, span {
  font-family: 微软雅黑,'microsoft yahei',tahoma,Arial,sans-serif;
  font-size: 15px;
}
</style>
'''

table_style = '''
<style type="text/css">
    body {
        font-family: verdana,arial,sans-serif;
    }
    p {
        font-family: verdana,arial,sans-serif;
        font-size:13px;
    }
    caption {
        font-size:16px;
    }
    table.altrowstable {
        font-family: verdana,arial,sans-serif;
        font-size:11px;
        color:#333333;
        border-width: 1px;
        border-color: #a9c6c9;
        border-collapse: collapse;
    }
    table.altrowstable th {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #a9c6c9;
    }
    table.altrowstable td {
        border-width: 1px;
        padding: 8px;
        border-style: solid;
        border-color: #a9c6c9;
    }
    .oddrowcolor{
        background-color:#d4e3e5;
    }
    .evenrowcolor{
        background-color:#c3dde0;
    }
</style>
'''
