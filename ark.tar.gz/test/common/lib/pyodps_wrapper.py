#coding:utf8
import logging
import traceback
from odps import ODPS
from django.conf import settings
SIZE_NOT_FOUND = -1
logger = logging.getLogger('common')

endpoint = 'http://service.odps.aliyun-inc.com/api'

class OdpsWrapper():

    @staticmethod
    def get_columns(table):
        columns = []
        try:
            for c in table.schema.columns:
                columns.append(
                    {'name': c.name, 
                     'type': str(c.type), 
                     'comment': c.comment})
        except Exception, ex:
            logger.error('get table: %s columns fail, %s' \
                             % (table.name, traceback.format_exc()))
            raise Exception('获取表列详情失败 %s %s' % (table.name, str(ex)))
        return columns

    @staticmethod
    def get_partitions(table, start_time, end_time):
        partitions = []
        for p in table.partitions:
            if p.creation_time >= start_time and p.creation_time < end_time:
                partitions.append(
                    {'name': p.name,
                     'size': p.size,
                     'creation_time': p.creation_time})

        return partitions

    @staticmethod
    def latest(table, start_time, end_time):
        partitions = []
        for p in table.partitions:
            if p.creation_time >= start_time and p.creation_time < end_time:
                partitions.append(
                    {'name': p.name,
                     'size': p.size,
                     'creation_time': p.creation_time})

        return partitions

    @staticmethod
    def can_read(table, start_time, end_time):
        partitions = []
        for p in table.partitions:
            if p.creation_time >= start_time and p.creation_time < end_time:
                partitions.append(
                    {'name': p.name,
                     'size': p.size,
                     'creation_time': p.creation_time})

        return partitions


        

