#!/bin/env python
#-*- coding: utf-8 -*-
'''
    Author: liujianfeng
    Mail: jianfeng.liu@shenma-inc.com
    Date: 2014.03.04
    Description: 
        邮件报表html生成封装
'''
import os
import sys
import hashlib
import datetime

class HtmlGenerator:

    # style
    def get_style(self):
        '''html style'''
        style_str = '''
            <style type="text/css">
                body {
                    font-family: verdana,arial,sans-serif;
                }
                p {
                    font-family: verdana,arial,sans-serif;
                    font-size:13px;
                }
                caption {
                    font-size:16px;
                }
                table.altrowstable {
                    font-family: verdana,arial,sans-serif;
                    font-size:11px;
                    color:#333333;
                    border-width: 1px;
                    border-color: #a9c6c9;
                    border-collapse: collapse;
                }
                table.altrowstable th {
                    border-width: 1px;
                    padding: 8px;
                    border-style: solid;
                    border-color: #a9c6c9;
                }
                table.altrowstable td {
                    border-width: 1px;
                    padding: 8px;
                    border-style: solid;
                    border-color: #a9c6c9;
                }
                .oddrowcolor{
                    background-color:#d4e3e5;
                }
                .evenrowcolor{
                    background-color:#c3dde0;
                }
            </style>
        '''
        return style_str

class Table(HtmlGenerator):

    def mk_table(self, header, data, caption = ''):
        begin = self.get_begin(caption)
        end = self.get_end()
        
        html = self.mk_header(header)
        for idx, item in enumerate(data):
            html += self.mk_rowspan(item, idx)

        html = begin + html + end
        return html


    # 构建表头 支持两级表头
    # [headtext, t1.col1, [subhead1 : [t1.col2, t1.col3]], t2.col1, t2.co2]
    # 占用两行，其中subhead1占用两列
    def mk_header(self, header):
        '''构造表头'''
        
        html_str = ''
        max_row = 1
        for item in header:
            if isinstance(item, list):
                max_row = 2
                break

        rows = [[], []]
        for item in header:
            if isinstance(item, basestring):
                rows[0].append((item, max_row, 1))
            elif isinstance(item, list):
                if 2 != len(item) or not isinstance(item[1], list):
                    raise Exception('header配置有问题：%s' % str(item))
                rows[0].append((item[0], 1, len(item[1])))
                for subitem in item[1]:
                    rows[1].append((subitem, 1, 1))
        for row in rows:
            if not row:
                continue
            html_str += '<tr>'
            for item in row:
                html_str += '<th align="middle" rowspan="%d" colspan="%d"><B>%s</B></th>' % (item[1], item[2], item[0])
            html_str += '</tr>'
        return html_str

    # 构造表的一行
    def mk_rowspan(self, value_list, idx = 0):
        '''构造表的一行，idx是行号，用于奇偶数行显示不同颜色'''
        class_name = 'oddrowcolor' if idx % 2 == 0 else 'evenrowcolor'
        html_str    =   '<tr class = "%s">' % class_name
        for item in value_list:
            if isinstance(item, list):
                value, rowspan = item
            else:
                value = item
                rowspan = 1
            if 0 == rowspan:
                continue
            html_str += '<th align="middle" rowspan = "%s"><B>%s</B></th>' % (rowspan, value)
        html_str    +=  '</tr>'
        return html_str

    # 添加图片
    def mk_image(self, img_file):
        '''生成插入一张图片的html'''
        if not img_file:
            return ''
        return '<img src="cid:%s" />' % hashlib.md5(img_file).hexdigest()

    def get_begin(self, caption = ''):
        return "<table class='altrowstable' border='1'><caption>%s</caption>" % caption

    def get_end(self):
        return "</table>";


    def get_report_begin(self, prefix):
        return "<DIV><BR>%s<BR></DIV>" % (prefix)
   
    def get_report_end(self,suffix):
        return "<DIV><BR>%s<BR></DIV>" % (suffix)  
