#-*- coding: utf-8 -*-
import os
import sys
import urllib2
import urllib
import tempfile
reload(sys)
sys.setdefaultencoding("utf-8")

def run_once(cmd):
    stdout_file = tempfile.NamedTemporaryFile()
    stderr_file = tempfile.NamedTemporaryFile()
    cmd = '%(cmd)s 1>>%(out)s 2>>%(err)s' % {
            'cmd': cmd, 
            'out': stdout_file.name, 
            'err': stderr_file.name
        }
    code = os.system(cmd)
    stdout = stdout_file.read()
    stderr = stderr_file.read()
    stdout_file.close()
    stderr_file.close()
    return stdout, stderr, code

class Mobile(object):
    api_addr = 'http://10.181.204.100:8088/message_sender/MobileMsg'
    def __init__(self, type_id, tpl_id, source_id):
        self.type_id = type_id
        self.tpl_id = tpl_id
        self.source_id = source_id
        self.param = {'typeId': self.type_id,
                      'tplId': self.tpl_id,
                      'sourceId': self.source_id}

    def send(self, info):
        self.param.update(info)
        params = []
        for key, value in self.param.items():
            params.append('%s=%s' % (key, value))
        http_addr = '%s?%s' % (self.api_addr, '&'.join(params))    

        curl_cmd = 'curl "%s" ' % http_addr
        stdout, stderr, code = run_once(curl_cmd)
        return stdout, stderr, code


class MonitorMobile(Mobile):
    def __init__(self):
        super(MonitorMobile, self).__init__('740320655', '250679410', 'sm_ark*monitor')

    def send(self, info):
        for key in info:
            if key not in ('status', 'receiver'):
                info[key] = ':%s;' % info[key]
        return super(MonitorMobile, self).send(info)


if __name__ == "__main__":
    #cmd: python sms.py 18612290572,15167156873 category resource_item 20160228 0

    receiver = sys.argv[1]
    category = sys.argv[2]
    resource_item = sys.argv[3]
    run_time = sys.argv[4]
    status = sys.argv[5]

    m = MonitorMobile()
    info={}
    info["receiver"] = receiver
    info["category"] = category
    info["resource_item"] = resource_item
    info["run_time"] = run_time
    info["status"] = status
    print(m.send(info))


