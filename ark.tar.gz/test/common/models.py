#coding:utf8
from django.db import models
from django.conf import settings
import logging
from django.contrib.auth.models import User
from message_manager import MessageManager
from perm_history_manager import PermHistoryManager
from config_manager import ConfigManager
from op_history_manager import OpHistoryManager

from django.core.validators import MaxLengthValidator
from django.core.validators import RegexValidator

logger = logging.getLogger('common')

def addslashes(s):
    if not isinstance(s, basestring):
        return s
    l = ["\\", '"', "'", "\0", ]
    for i in l:
        if i in s:
            s = s.replace(i, '\\'+i)
    return s

class ConfigType(models.Model):
    name = models.CharField(max_length = 64)
    create_time = models.DateTimeField(auto_now_add = True)
    update_time = models.DateTimeField(auto_now = True)
    

class Config(models.Model):
    key = models.CharField(max_length = 128)
    value = models.TextField()
    description = models.CharField(max_length = 1024, default = '')

    TYPE_TEXT = 0
    TYPE_TEXTAREA = 1
    type_choices = (
        (TYPE_TEXT, '单行文本'),
        (TYPE_TEXTAREA, '文本框'),
    )
    value_type = models.PositiveSmallIntegerField(
        choices = type_choices,
        default = TYPE_TEXT)

    config_type = models.ForeignKey(ConfigType, related_name = 'config_type')
    create_time = models.DateTimeField(auto_now_add = True)
    update_time = models.DateTimeField(auto_now = True)

    objects = ConfigManager()


class PermHistory(models.Model):

    resource_type = models.CharField(max_length = 16)
    resource_id = models.BigIntegerField()
    permission = models.CharField(
        max_length = 200,
        verbose_name = 'seprated by |, like: read|update')
    applicant = models.ForeignKey(User, related_name = 'proposer_user')
    grantor = models.ForeignKey(User, related_name = 'grantor_user')

    (PENDING_STATUS, ACCEPTED_STATUS, DENIED_STATUS, 
     GRANTED_STATUS, REVOKED_STATUS) = range(5)
    status_choices = (
        (PENDING_STATUS, 'pending'),
        (ACCEPTED_STATUS, 'accepted'),
        (DENIED_STATUS, 'denied'),
        (GRANTED_STATUS, 'unsolicited grant'),
        (REVOKED_STATUS, 'unsolicited revoke'),
    )
    status = models.PositiveSmallIntegerField(
        choices = status_choices,
        default = PENDING_STATUS)
    deadline = models.DateTimeField(null = True, blank = True, default='2000-01-01 00:00:00') 
    update_time = models.DateTimeField(auto_now = True)
    create_time = models.DateTimeField(auto_now_add = True)
    reason = models.CharField(max_length = 512)

    # 同项目 
    PERM_TYPE_INSIDE_PROJECT = 0
    # 跨项目
    PERM_TYPE_CROSS_PROJECT = 1  
    odps_perm_type = models.IntegerField(default=-1, null=True)
    objects = PermHistoryManager(
        PENDING_STATUS, ACCEPTED_STATUS, DENIED_STATUS,
        GRANTED_STATUS, REVOKED_STATUS)
    

class Message(models.Model):
    
    sender = models.ForeignKey(User, related_name = 'message_sender')
    receiver = models.ForeignKey(User, related_name = 'message_receiver')
    content = models.TextField()
    create_time = models.DateTimeField(auto_now_add = True)
    read = models.BooleanField(default = False)
    deleted = models.BooleanField(default = False)
    

    # !!!! 添加状态，要在最后，避免影响现有数据
    (TYPE_COMMON, TYPE_MONITOR, TYPE_DATA, TYPE_DATA_AUTO_CLEAN,
     TYPE_ACCOUNT, TYPE_PERMISSION) = range(6)
    type_choices = (
        (TYPE_COMMON, '未分类'),
        (TYPE_MONITOR, '监控报警'),
        (TYPE_DATA_AUTO_CLEAN, '数据清理'),
        (TYPE_DATA, '数据变更'),
        (TYPE_ACCOUNT, '账户变更'),
        (TYPE_PERMISSION, '权限变更'),
    )
    type = models.PositiveSmallIntegerField(
        choices = type_choices,
        default = TYPE_COMMON)

    objects = MessageManager()

class VisitRecord(models.Model):
    app = models.CharField(max_length = 128)
    uri = models.CharField(max_length = 128)
    param = models.CharField(max_length = 128, default = '')
    user = models.ForeignKey(
        User, null = True, related_name = 'user_view_history')
    description = models.CharField(max_length = 1024, default = '')
    ip = models.CharField(max_length = 64, default = '')
    visit_time = models.DateTimeField(auto_now_add = True)

    @staticmethod
    def add(app, uri, param = '', user = None, description = '', ip = ''):
        VisitRecord.objects.create(
            app = app, uri = uri, param = param,
            user = user, description = description,
            ip = ip)

    @staticmethod
    def request_add(request, param = '', description = ''):
        from django.core.urlresolvers import resolve
        items = request.path.split('/')
        app = items[1] if len(items) >= 2 \
            else items[0] if len(items) >= 1 else 'none'

        user = request.user if not request.user.is_anonymous() else None
        VisitRecord.add(app, request.path, param = param,
            user = user, description = description,
            ip = request.META['REMOTE_ADDR'])

    @staticmethod
    def count(conditions = None):
        # conditions: {'user': user, 'uri': 'uri', 'app': 'app'}
        # key可能为user uri app中的0个或多个
        if not conditions:
            conditions = {}
        return VisitRecord.objects.filter(**conditions).count()


class Performance(models.Model):
    
    # !!!! 添加状态，要在最后，避免影响现有数据
    (TYPE_COMMON, TYPE_SITE, TYPE_DATA, TYPE_STATISTIC) = range(4)
    type_choices = (
        (TYPE_SITE, '未分类'),
        (TYPE_SITE, '站点'),
        (TYPE_DATA, '数据'),
        (TYPE_STATISTIC, '统计'),
    )
    type = models.PositiveSmallIntegerField(
        choices = type_choices,
        default = TYPE_COMMON)
    
    key = models.CharField(max_length = 64)
    value = models.CharField(max_length = 1024, default = '')
    description = models.CharField(max_length = 1024, default = '')
    create_time = models.DateTimeField(auto_now_add = True)


# 重要的系统操作记录
class OpHistory(models.Model):
    operator = models.ForeignKey(User)
    app = models.CharField(max_length = 16)
    klass = models.CharField(max_length = 16)
    info = models.TextField()
    create_time = models.DateTimeField(auto_now_add = True)

    objects = OpHistoryManager()


# 首页用户常用链接
class UserLink(models.Model):
    user = models.ForeignKey(User)
    link = models.ForeignKey(Config)


from south.db import dbs
feature_db_config = settings.FEATURE_DB_CONFIG
feature_db = dbs[feature_db_config]
class FeatTable():
    @staticmethod
    # fields: ((name, type), (name, type))
    def create(table_name, fields):
        feature_db.create_table(table_name, fields)

    @staticmethod
    def create_index(table_name, column_names, **args):
        feature_db.create_index(table_name, column_names, **args)

    @staticmethod
    def delete(table_name):
        feature_db.delete_table(table_name)
        
    @staticmethod
    def add_column(table_name, field_name, field_type, db_index = False):
        feature_db.add_column(table_name, field_name, field_type)
        if db_index is True:
            feature_db.create_index(table_name, [field_name, ])

    @staticmethod
    def delete_column(table_name, column_name):
        feature_db.delete_column(table_name, column_name)

    @staticmethod
    def rename_column(table_name, column_name, new_column_name):
        feature_db.rename_column(table_name, column_name, new_column_name)

    @staticmethod
    def alter_column(table_name, column_name, field):
        feature_db.alter_column(table_name, column_name, field)

    @staticmethod
    def desc(table_name):
        return feature_db.execute('desc %s' % table_name)

    @staticmethod
    def list():
        from django.db import connections
        connection = connections[feature_db_config]
        return connection.introspection.table_names()

    @staticmethod
    def exists(table):
        return table in FeatTable.list()

    @staticmethod
    def bulk_insert(table_name, columns, records):
        sql_columns = ["`%s`" % addslashes(column) for column in columns]
        sql = 'insert into %s (%s) values' % (table_name, ','.join(sql_columns))

        sql_values = []
        for record in records:
            sql_values.append(
                ' (%s)' % ','.join(["'%s'" % addslashes(item) for item in record]))
        sql = sql + ','.join(sql_values)
        logger.info('executing sql: %s' % sql)
        FeatTable.execute(sql)

    @staticmethod
    def delete_by_time(table_name, time_column, time):
        sql = "delete from %s where `%s`='%s'" \
            % (table_name, time_column, time)
        FeatTable.execute(sql)

    @staticmethod
    def execute(sql):
        logger.info("execute sql: %s" % sql)
        return feature_db.execute(sql)
    
class common_validate():
    name_validator = RegexValidator(
            regex = u'^[\w\u4e00-\u9fa5 ]+$',
            message = '名称必须由字母数字下划线和中文组成')
    
    word_validator = RegexValidator(
            regex = u'^[\w]*$',
            message = '名称必须由字母数字下划线组成')
    
    len_name_validators = [
        MaxLengthValidator,
        name_validator]
        
    len_word_validators = [
        MaxLengthValidator,
        word_validator]

import datetime
def format_time(time):
    format = '%Y-%m-%d %H:%M:%S'
    try:
        return datetime.date.strftime(time, format)
    except:
        return None

def handle_uploaded_file(f, dest):
    with open(dest, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

def get_md5(s):
    import hashlib
    m = hashlib.md5()
    m.update(s)
    return m.hexdigest()
