import re
import time
import datetime
import dateutil.relativedelta
import logging

from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)


TIME_FORMAT_8 = '%Y%m%d'
TIME_FORMAT_10 = '%Y%m%d%H'
TIME_FORMAT_12 = '%Y%m%d%H%M'
TIME_FORMAT_14 = '%Y%m%d%H%M%S'
FREQUENCY_DAILY = 'day'
FREQUENCY_HOURLY = 'hour'
FREQUENCY_MINUTELY = 'minute'
DAILY_TIME_LEN = 8
HOURLY_TIME_LEN = 10
MINUTELY_TIME_LEN = 12
MAX_TIME_LEN = 14

class ArkTime():

    @staticmethod
    def day_diff(start_time, end_time):
        start_time = ArkTime.get_time(start_time)
        end_time = ArkTime.get_time(end_time)
        diff = (end_time - start_time).days
        return diff

    @staticmethod
    def cut_str(frequency, range_time):
        length = DAILY_TIME_LEN if frequency == FREQUENCY_DAILY \
            else HOURLY_TIME_LEN if frequency == FREQUENCY_HOURLY \
            else MINUTELY_TIME_LEN 

        if isinstance(range_time, basestring):
            range_time = range_time[:length]
        else:
            range_time = map(lambda x: x[:length], range_time)
        return range_time
        
    @staticmethod
    def get_current_time():
        return datetime.date.strftime(
            datetime.datetime.now(), TIME_FORMAT_14)

    @staticmethod
    def just_time_str(time_str, length = 14):
        time_str = time_str.ljust(length, '0')
        return time_str[:length]

    @staticmethod
    def cut_time_str(time_str, length):
        return time_str[:length]
    
    @staticmethod
    def make_range_time(start, end, frequency = FREQUENCY_DAILY, 
                        include_right = False, cut_str = True):
        '''
        make a list of time_str: [start, end] or [start, end)
        @param include_right: when True, end is included
        start=20140410,end=20140411 return=[20140410,20140411]
        start=2014041000,end=2014041001 return=[2014041000,2014041001]
        if cut_str=False: the length of each item is 14
        '''
        if not isinstance(start, basestring) \
                or not isinstance(end, basestring) \
                or not isinstance(frequency, basestring) \
                or not isinstance(cut_str, bool):
            return []

        start = ArkTime.just_time_str(start)
        end = ArkTime.just_time_str(end)

        base_time = datetime.datetime.strptime(start, TIME_FORMAT_14)
    
        offset = 1 
        range_time = [start]
        while True:
            delta = ArkTime.get_delta(frequency, offset)
            new_time = datetime.date.strftime(base_time + delta, TIME_FORMAT_14)
            if new_time == start \
                    or new_time > end \
                    or not include_right and new_time == end:
                break
            else:
                range_time.append(new_time)
            offset += 1

        if cut_str:
            range_time = ArkTime.cut_str(frequency, range_time)

        return range_time


    @staticmethod
    def get_real_path(path, base_time, frequency = FREQUENCY_DAILY, offset = 0):

        if not base_time or not isinstance(
            base_time, (basestring, datetime.datetime)):
            logger.error('base_time should be a string or datetime instance')
            return path

        base_time = ArkTime.get_time(base_time, frequency, offset)
        replaces = {'%year%' : '%s' % base_time.year,
                   '%yyyy%' : '%s' % base_time.year,
                   '%month%' : '%02d' % base_time.month,
                   '%mm%' : '%02d' % base_time.month,
                   '%day%' : '%02d' % base_time.day,
                   '%dd%' : '%02d' % base_time.day,
                   '%hour%' : '%02d' % base_time.hour,
                   '%HH%' : '%02d' % base_time.hour,
                   '%min%' : '%02d' % base_time.minute,
                   '%MM%' : '%02d' % base_time.minute,
                   '%sec%' : '%02d' % base_time.second,
                   '%SS%' : '%02d' % base_time.second,
                   '%m%' : '%s' % base_time.month,
                   '%d%' : '%s' % base_time.day,
                   '%H%' : '%s' % base_time.hour,
                   '%M%' : '%s' % base_time.minute,
                   '%S%' : '%s' % base_time.second,}

        for key, value in replaces.items():
            path = path.replace(key, value)
                   
        replaces = {'yyyy' : '%s' % base_time.year,
                   'mm' : '%02d' % base_time.month,
                   'dd' : '%02d' % base_time.day,
                   'HH' : '%02d' % base_time.hour,
                   'hh' : '%02d' % base_time.hour,
                   'MM' : '%02d' % base_time.minute,
                   'SS' : '%02d' % base_time.second}

        #support {} express
        m = re.search("\\{.*?\\}",path)
        while m:
            time_expr = m.group(0)
            real_str = time_expr[1:len(time_expr)-1]
            for key, value in replaces.items():
                real_str = real_str.replace(key, value)
            path = path.replace(time_expr,real_str)
            m = re.search("\\{.*?\\}",path)
        return path

    @staticmethod
    def timing_freq(frequency):
        return isinstance(frequency, basestring) and \
            frequency in (FREQUENCY_DAILY, FREQUENCY_HOURLY, FREQUENCY_MINUTELY)

    @staticmethod
    def get_time(base_time, frequency = FREQUENCY_DAILY, 
                 offset = 0, str_result = False, cut_str = False):

        if isinstance(base_time, basestring):
            base_time = ArkTime.just_time_str(base_time, MAX_TIME_LEN)
            base_time = datetime.datetime.strptime(base_time, TIME_FORMAT_14)

        assert isinstance(base_time, datetime.datetime)

        if offset:
            delta = ArkTime.get_delta(frequency, offset)
            base_time = base_time + delta

        if str_result:
            base_time = datetime.date.strftime(base_time, TIME_FORMAT_14)
            if cut_str:
                base_time = ArkTime.cut_str(frequency, base_time)

        return base_time

    @staticmethod
    def get_pre_time(base_time, frequency, offset = 1, 
                     str_result = False, 
                     cut_str = False):
        if frequency == FREQUENCY_DAILY:
            return ArkTime.get_pre_day(
                base_time, offset = offset,
                str_result = str_result,
                cut_str = cut_str)
        elif frequency == FREQUENCY_HOURLY:
            return ArkTime.get_pre_hour(
                base_time, offset = offset,
                str_result = str_result,
                cut_str = cut_str)

    @staticmethod
    def get_pre_hour(base_time, offset = 1, 
                    str_result = False, 
                    cut_str = False):
        pre_hour = ArkTime.get_time(
            base_time, FREQUENCY_HOURLY, -offset, str_result)
        if str_result and cut_str:
            pre_hour = ArkTime.cut_str(FREQUENCY_HOURLY, pre_hour)
        return pre_hour

    @staticmethod
    def get_pre_day(base_time, offset = 1, 
                    str_result = False, 
                    frequency = FREQUENCY_DAILY, 
                    cut_str = False):
        pre_day = ArkTime.get_time(
            base_time, FREQUENCY_DAILY, -offset, str_result)
        if str_result and cut_str:
            pre_day = ArkTime.cut_str(frequency, pre_day)
        return pre_day

    @staticmethod
    def get_pre_week(base_time, offset = 1, 
                     str_result = False, 
                     frequency = FREQUENCY_DAILY, 
                     cut_str = False):
        return ArkTime.get_pre_day(base_time, offset * 7, str_result,
                            frequency, cut_str)


    @staticmethod
    def get_pre_month(base_time, offset = 1, str_result = False):

        if isinstance(base_time, basestring):
            base_time = ArkTime.just_time_str(base_time, MAX_TIME_LEN)
            base_time = datetime.datetime.strptime(base_time, TIME_FORMAT_14)

        assert isinstance(base_time, datetime.datetime)
        if offset:
            base_time = base_time - \
                dateutil.relativedelta.relativedelta(months = offset)

        if str_result:
            base_time = datetime.date.strftime(base_time, TIME_FORMAT_14)

        return base_time


    @staticmethod
    def get_delta(frequency, offset):
        delta = datetime.timedelta()
        if frequency == FREQUENCY_DAILY:
            delta = datetime.timedelta(days = offset)
        if frequency == FREQUENCY_HOURLY:
            delta = datetime.timedelta(hours = offset)
        if frequency == FREQUENCY_MINUTELY:
            delta = datetime.timedelta(minutes = offset)
        return delta


