from django.test import TestCase
from models import ConfigType, Config
        

# Create your tests here.
class ConfigTest(TestCase):

    def setUp(self):
        self.type1 = ConfigType.objects.create(name = 'type1')
        self.type2 = ConfigType.objects.create(name = 'type2')

        self.config1 = Config.objects.create(
            key = 'key1',
            value = 'value1',
            config_type = self.type1)

        self.config2 = Config.objects.create(
            key = 'key2',
            value = 'value2',
            config_type = self.type1)

        self.config3 = Config.objects.create(
            key = 'key3',
            value = 'value3',
            config_type = self.type2)


    def test_get_value(self):
        self.assertEqual('value1', Config.objects.get_value('key1'))
        self.assertEqual('value2', Config.objects.get_value('key2'))
        self.assertEqual('value3', Config.objects.get_value('key3'))
        self.assertRaises(Exception, Config.objects.get_value, 'not_exist_key')


    def test_set_value(self):

        key = 'key1'
        value = 'value1'
        self.assertEqual(value, Config.objects.get_value(key))

        new_value = 'new_value'
        self.assertEqual(1, Config.objects.set_value(key, new_value))
        self.assertEqual(new_value, Config.objects.get_value(key))

        self.assertEqual(0, Config.objects.set_value('not_exist_key', 'value'))


    def test_list(self):
        self.assertEqual(
            2, Config.objects.list(config_type_id = self.type1.id).count())
        self.assertEqual(
            1, Config.objects.list(config_type_id = self.type2.id).count())


