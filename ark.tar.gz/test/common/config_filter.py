#coding=utf-8
import logging
from django.db import models
from django.conf import settings
from common.convert_time import *
from common.models import ConfigType
from common.models import Config
logger = logging.getLogger(settings.PROJECT_NAME)


def get_filter_option(filter_options, idx):
    
    key = 'columns[%d][data]' % idx
    search_column = filter_options.get(key, '')
    
    regex_key = 'columns[%d][search][regex]' % idx
    regex = filter_options.get(regex_key, '')

    value_key = 'columns[%d][search][value]' % idx
    value = filter_options.get(value_key, '')

    return search_column, value, regex


def config_filter_list(config_list, filter_options):
    MAX_COLUMN_NUM = 100
    for idx in range(MAX_COLUMN_NUM):
        search_column, value, regex = get_filter_option(filter_options, idx)

        if not search_column:
            break
        if not value:
            continue

        if search_column == 'key':
            config_list = config_list.filter(key__contains = value)
        if search_column == 'value':
            config_list = config_list.filter(value__contains = value)
        elif search_column == 'value_type':
            if value:
                config_list = config_list.filter(value_type = int(value))
        elif search_column == 'config_type':
            if value:
                config_list = config_list.filter(config_type_id = int(value))
                
    return config_list


def config_type_filter_list(config_type_list, filter_options):
    MAX_COLUMN_NUM = 100
    for idx in range(MAX_COLUMN_NUM):
        search_column, value, regex = get_filter_option(filter_options, idx)

        if not search_column:
            break
        if not value:
            continue

        if search_column == 'name':
            config_type_list = config_type_list.filter(name__contains = value)
                
    return config_type_list


def custom_config_table(configs,draw,total_count,filter_count):
    result = {"draw":draw,"recordsTotal": total_count,
                "recordsFiltered": filter_count}
    data = []
    for item in configs:
        item['fields']["id"]=item['pk']
        value_type = item['fields']["value_type"]
        item['fields']["value_type"]=Config.type_choices[value_type][1]
        item['fields']["value_type_id"]=value_type

        config_type = item['fields']["config_type"]
        item['fields']["config_type"] = \
            ConfigType.objects.get(id=int(config_type)).name
        item['fields']["config_type_id"]=config_type

        other_style_time = convert_time(item['fields']["update_time"])
        item['fields']["update_time"] = other_style_time

        data.append(item['fields'])
    result['data'] = data
    return result


def custom_config_type_table(config_types,draw,total_count,filter_count):
    result = {"draw":draw,"recordsTotal": total_count,
                "recordsFiltered": filter_count}
    data = []
    for item in config_types:
        item['fields']["id"]=item['pk']
        other_style_time = convert_time(item['fields']["update_time"])
        item['fields']["update_time"] = other_style_time

        data.append(item['fields'])
    result['data'] = data
    return result




















