#encoding:utf8
from django.contrib.auth.models import User
from ark_user.models import Info

# 需要在系统配置里配置测试用的账号
# 普通用户账号
test_account = 'test_odps_access_id_key'
# 管理员账号配置
aliyun_searchlog_owner_account = 'test_odps_admin_access_id_key'
default_project = 'aliyun_searchlog'
odps_account = 'ALIYUN$bstnhomgmj7y@aliyun.com'
admin_odps_account = 'ALIYUN$dxp_87889631@aliyun.com'
# 普通账号(zhijie.yang)
test_odps_account = 'ALIYUN$bsmeeokql2gs@aliyun.com'

def get_test_odps_account(admin = False):
    from south.db import dbs
    db = dbs['default']
    key = aliyun_searchlog_owner_account if admin else test_account
    sql = 'select value from ark_tools.common_config where `key`="%s"' % key
    res = db.execute(sql)
    return res[0][0].split()

def prepare_user():

    user1 = User.objects.create(
        username = 'jianfeng.liu', email = 'jianfeng.liujf1@alibaba-inc.com')
    access_id, access_key = get_test_odps_account(admin = False)
    info = Info.objects.create(
        user = user1,
        odps_dxp_account = odps_account,
        odps_access_id = access_id,
        odps_access_key = access_key,
        odps_project = default_project,)

    ark_admin = User.objects.create(
        username = 'ark_admin',
        email = 'jianfeng.liujf1@alibaba-inc.com')

    access_id, access_key = get_test_odps_account(admin = True)
    info = Info.objects.create(
        user = ark_admin,
        odps_dxp_account = admin_odps_account,
        odps_access_id = access_id,
        odps_access_key = access_key,
        odps_project = default_project,
        owner_projects = default_project)
    return user1, ark_admin
