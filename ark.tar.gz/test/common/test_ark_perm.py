from django.conf import settings
from django.test import TestCase
from django.contrib.auth.models import User, Permission
from django.contrib.contenttypes.models import ContentType
from guardian.shortcuts import assign_perm
from guardian.shortcuts import remove_perm
from guardian.shortcuts import get_users_with_perms
from dms.models import Config
from models import PermHistory
from perm_defines import PERM_TYPE_READ, PERM_TYPE_UPDATE
from perm_defines import PERM_TYPE_DELETE, PERM_TYPE_EXECUTE
from perm_defines import make_permission
from ark_perm import UserPerm, is_admin

# Create your tests here.
class UserPermTest(TestCase):

    def setUp(self):
        self.user1 = User.objects.create(username = 'user1')
        self.user2 = User.objects.create(username = 'user2')
        self.user3 = User.objects.create(username = 'user3')
        self.ark_admin = User.objects.create(
            username = 'ark_admin', email = 'jianfeng.liu@shenma-inc.com')
        self.config1 = Config.objects.create(
            name = 'test1',
            type = Config.TYPE_ODPS,
            owner = self.user1,
            update_user = self.user1)

        self.config2 = Config.objects.create(
            name = 'test2',
            type = Config.TYPE_PANGU,
            owner = self.user1,
            update_user = self.user1)

        self.content_type = ContentType.objects.get_for_model(Config)

    def test_is_admin(self):
        self.assertTrue(is_admin(settings.SITE_ADMIN))
        self.assertFalse(is_admin(self.user1))
        self.assertTrue(is_admin(self.ark_admin))


    def test_perm(self):
        self.assertFalse(self.user1.has_perm(PERM_TYPE_READ, self.config1))
        assign_perm(PERM_TYPE_READ, self.user1, self.config1)
        assign_perm(PERM_TYPE_READ, self.user1, self.config1)
        self.assertTrue(self.user1.has_perm(PERM_TYPE_READ, self.config1))

        remove_perm(PERM_TYPE_READ, self.user1, self.config1)
        self.assertFalse(self.user1.has_perm(PERM_TYPE_READ, self.config1))

    def test_grant(self):
        
        # prepare
        self.assertEqual(0, PermHistory.objects.all().count())
        self.assertFalse(self.user2.has_perm(PERM_TYPE_READ, self.config1))
        self.assertFalse(self.user2.has_perm(PERM_TYPE_UPDATE, self.config1))
        self.assertFalse(self.user3.has_perm(PERM_TYPE_READ, self.config1))
        self.assertFalse(self.user3.has_perm(PERM_TYPE_DELETE, self.config1))

        # test
        UserPerm.grant(self.user1, self.user2, self.config1, 'test',
                       read = True, update = True)
        UserPerm.grant(self.user1, self.user3, self.config1, 'test',
                       delete = True)

        self.assertEqual(2, PermHistory.objects.all().count())
        self.assertTrue(self.user2.has_perm(PERM_TYPE_READ, self.config1))
        self.assertTrue(self.user2.has_perm(PERM_TYPE_UPDATE, self.config1))
        self.assertFalse(self.user2.has_perm(PERM_TYPE_DELETE, self.config1))
        self.assertTrue(self.user3.has_perm(PERM_TYPE_READ, self.config1))
        self.assertTrue(self.user3.has_perm(PERM_TYPE_DELETE, self.config1))


    def test_revoke(self):

        # prepare
        self.assertEqual(0, PermHistory.objects.all().count())
        assign_perm(PERM_TYPE_READ, self.user2, self.config1)
        assign_perm(PERM_TYPE_UPDATE, self.user2, self.config1)
        assign_perm(PERM_TYPE_DELETE, self.user2, self.config1)
        self.assertTrue(self.user2.has_perm(PERM_TYPE_READ, self.config1))
        self.assertTrue(self.user2.has_perm(PERM_TYPE_UPDATE, self.config1))
        self.assertTrue(self.user2.has_perm(PERM_TYPE_DELETE, self.config1))

        # test
        UserPerm.revoke(self.user1, self.user2, self.config1, 'test',
                        update = True)
        self.assertFalse(self.user2.has_perm(PERM_TYPE_READ, self.config1))
        self.assertFalse(self.user2.has_perm(PERM_TYPE_UPDATE, self.config1))
        self.assertEqual(1, PermHistory.objects.all().count())

        UserPerm.revoke(self.user1, self.user2, self.config1, 'test',
                        delete = True)
        self.assertFalse(self.user2.has_perm(PERM_TYPE_DELETE, self.config1))

        self.assertEqual(2, PermHistory.objects.all().count())


    def test_apply(self):
        self.assertEqual(0, PermHistory.objects.all().count())
        perm_history = UserPerm.apply(
            self.user2, self.user1, self.config1, 
            'test', update = True, delete = True)
        self.assertEqual(1, PermHistory.objects.all().count())

        perm_str = make_permission(True, True, True)
        perm_history = PermHistory.objects.get(pk = perm_history.id)
        self.assertEqual(perm_str, perm_history.permission)


    def test_accept(self):
        user = User.objects.create(username = 'user')
        
        perm_history = PermHistory.objects.apply(
            user, self.user1, type(self.config1).__name__, 
            self.config1.id, reason = 'test', read = True, update = True)
        self.assertFalse(user.has_perm(PERM_TYPE_READ, self.config1))
        self.assertFalse(user.has_perm(PERM_TYPE_UPDATE, self.config1))
        count = PermHistory.objects.all().count()

        UserPerm.accept(self.user1, user, self.config1, perm_history.id, 'test')
        self.assertEqual(count, PermHistory.objects.all().count())
        self.assertTrue(user.has_perm(PERM_TYPE_READ, self.config1))
        self.assertTrue(user.has_perm(PERM_TYPE_UPDATE, self.config1))
        
    def test_deny(self):
        
        user = User.objects.create(username = 'user')
        
        perm_history = PermHistory.objects.apply(
            user, self.user1, type(self.config1).__name__, 
            self.config1.id, reason = 'test', read = True, update = True)
        self.assertFalse(user.has_perm(PERM_TYPE_READ, self.config1))
        self.assertFalse(user.has_perm(PERM_TYPE_UPDATE, self.config1))
        count = PermHistory.objects.all().count()
        
        UserPerm.deny(perm_history.id, 'test')
        self.assertEqual(count, PermHistory.objects.all().count())
        self.assertFalse(user.has_perm(PERM_TYPE_READ, self.config1))
        self.assertFalse(user.has_perm(PERM_TYPE_UPDATE, self.config1))

    
    def test_get_granting_users(self):
        user1 = User.objects.create(username = 'get_granting_users')
        assign_perm(PERM_TYPE_READ, self.user2, self.config1)
        granting_users = UserPerm.get_granting_users(self.user1, self.config1)
        self.assertListEqual([self.user3, self.ark_admin, user1], granting_users)


    def test_get_allowed_users(self):
        user1 = User.objects.create(username = 'get_users_user1')
        user2 = User.objects.create(username = 'get_users_user2')
        assign_perm(PERM_TYPE_READ, user1, self.config1)
        assign_perm(PERM_TYPE_UPDATE, user1, self.config1)
        assign_perm(PERM_TYPE_DELETE, user1, self.config1)
        assign_perm(PERM_TYPE_READ, user2, self.config1)

        users = UserPerm.get_allowed_users(self.config1)
        print users
        self.assertEqual(2, len(users))


    def test_has_read_perm(self):
        # owner
        self.assertTrue(UserPerm.has_read_perm(self.user1, self.config1))

        user = User.objects.create(username = 'user_has_read_perm')
        self.assertFalse(UserPerm.has_read_perm(user, self.config1))
        assign_perm(PERM_TYPE_READ, user, self.config1)
        self.assertTrue(UserPerm.has_read_perm(user, self.config1))

    def test_has_update_perm(self):
        # owner
        self.assertTrue(UserPerm.has_update_perm(self.user1, self.config1))

        user = User.objects.create(username = 'user_has_update_perm')
        self.assertFalse(UserPerm.has_update_perm(user, self.config1))
        assign_perm(PERM_TYPE_UPDATE, user, self.config1)
        self.assertTrue(UserPerm.has_update_perm(user, self.config1))

    def test_has_delete_perm(self):
        # owner
        self.assertTrue(UserPerm.has_delete_perm(self.user1, self.config1))

        user = User.objects.create(username = 'user_has_delete_perm')
        self.assertFalse(UserPerm.has_delete_perm(user, self.config1))
        assign_perm(PERM_TYPE_DELETE, user, self.config1)
        self.assertTrue(UserPerm.has_delete_perm(user, self.config1))

    def test_has_execute_perm(self):
        # config has no execute perm
        pass

    def test_is_owner(self):
        self.assertFalse(UserPerm.is_owner(self.user2, self.config1))
        self.assertTrue(UserPerm.is_owner(self.user1, self.config1))

    def test_has_grant_perm(self):
        self.assertFalse(UserPerm.has_grant_perm(self.user2, self.config1))
        self.assertTrue(UserPerm.has_grant_perm(self.user1, self.config1))

    def test_get_user_perms(self):
        user = User.objects.create(username = 'user_get_perms')
        assign_perm(PERM_TYPE_DELETE, user, self.config1)
        assign_perm(PERM_TYPE_UPDATE, user, self.config1)
        print UserPerm.get_user_perms(user, self.config1)

    def test_get_objs_for_user(self):
        user = User.objects.create(username = 'user_get_perms')
        assign_perm(PERM_TYPE_READ, user, self.config1)
        assign_perm(PERM_TYPE_READ, user, self.config2)

        config = Config.objects.create(
            name = 'test',
            type = Config.TYPE_ODPS,
            owner = self.user1,
            update_user = self.user1)
        assign_perm(PERM_TYPE_UPDATE, user, config)

        print UserPerm.get_objs_for_user(user, app = Config._meta.app_label)
