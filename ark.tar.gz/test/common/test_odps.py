#encoding:utf8
from django.test import TestCase
from odps import Odps
from odps import OdpsPrivilege
from odps import OdpsPackage
from odps import OdpsRole
from test_functions import get_test_odps_account

# Create your tests here.
class OdpsTest(TestCase):

    def setUp(self):
        # create table t_ljf_test_partition (name string) partitioned by (day string, hour string);
        self.partition_table = 't_ljf_test_partition'
        self.table = 't_ljf_test'
        self.dev_table = 'aliyun_searchlog_dev.ljf_test_partition'

        self.access_id, self.access_key = get_test_odps_account()
        self.admin_access_id, self.admin_access_key = get_test_odps_account(admin = True)
        from odps import OdpsPackage
        self.project = 'aliyun_searchlog'
        self.project_dev = self.project + '_dev'

        self.account = 'bstnhomgmj7y@aliyun.com'
        self.owner_account = 'ALIYUN$dxp_87889631@aliyun.com'
        self.admin_account = 'ALIYUN$bsxz0wvskix4@aliyun.com'

    def test_list(self):

        project = 'aliyun_searchlog'
        print 'list %s:' % project, Odps.list(project)

        project = 'aliyun_searchlog_dev'
        print 'list %s:' % project, Odps.list(project)

        project = 'not_exist_project'
        self.assertRaises(Exception, Odps.list, project)

    def test_schema(self):
        print 'table %s schema:' % self.partition_table, Odps.schema(self.partition_table)

        print 'table %s schema:' % self.dev_table, Odps.schema(self.dev_table)

        table = 'not_exist_table'
        self.assertRaises(Exception, Odps.schema, table)

    def test_meta(self):
        print 'table %s meta:' % self.partition_table, Odps.meta(self.partition_table)

        print 'table %s meta:' % self.dev_table, Odps.meta(self.dev_table)

        table = 'not_exist_table'
        self.assertRaises(Exception, Odps.schema, table)


    def test_size(self):
        self.assertGreaterEqual(Odps.size(self.partition_table), 0)
        self.assertEqual(0, Odps.size(self.partition_table, 'day=20150504,hour=00'))

        self.assertRaises(Exception, Odps.size, 'not_exist_table')


    def test_count(self):
        table = 'online_homepage_ark_log_hour'
        self.assertGreaterEqual(Odps.count(table), 1)

        import datetime
        day = datetime.datetime.now() + datetime.timedelta(days = -2)
        day = day.strftime('%Y%m%d') 
        self.assertGreaterEqual(Odps.count(table, 'day=%s,hour=00' % day), 100)

        self.assertRaises(Exception, Odps.count, 'not_exist_table')


    def test_partitions(self):
        # alter table t_ljf_test_partition add partition(day='20160414',hour='10');
        partitions = Odps.partitions(
            self.partition_table, 
            project = 'aliyun_searchlog', 
            odps_id = self.access_id, 
            odps_key = self.access_key)
        print 'get partitions:', partitions
        self.assertTrue(isinstance(partitions, list) 
                        and len(partitions) > 0
                        and isinstance(partitions[0], basestring))

        partitions = Odps.partitions(
            self.partition_table, detail = True,
            project = 'aliyun_searchlog', 
            odps_id = self.access_id, 
            odps_key = self.access_key)
        print 'get partitions:', partitions
        self.assertTrue(isinstance(partitions, list) 
                        and len(partitions) > 0
                        and isinstance(partitions[0], dict))

        partitions = Odps.partitions('baidu_user',
            project = 'aliyun_searchlog', 
            odps_id = self.access_id, 
            odps_key = self.access_key)
        self.assertListEqual([], partitions)

        partitions = Odps.partitions('not_exist_table',
            project = 'aliyun_searchlog', 
            odps_id = self.access_id, 
            odps_key = self.access_key)
        self.assertListEqual([], partitions)
        # self.assertRaises(Exception, Odps.partitions, 'not_exist_table')


    def test_delete(self):

        # create table t_ljf_test (name string) partitioned by (day string);
        # alter table t_ljf_test add partition (day='20150313');
        # alter table t_ljf_test add partition (day='20150314');
        # alter table t_ljf_test add partition (day='20150315');
        # self.assertTrue(Odps.delete('ljf_test', 'day=20150315'))
        # self.assertTrue(Odps.delete('ljf_test'))

        # table(partition) not exist
        self.assertRaises(Exception, Odps.delete, self.access_id, self.access_key, 'aliyun_searchlog', 't_ljf_test', 'day=20150315')
        self.assertRaises(Exception, Odps.delete, self.access_id, self.access_key, 'aliyun_searchlog', 't_ljf_test')


    def test_get_life_cycle(self):
        table = 'tmp_ucweb_sc_click_log'
        life_cycle = Odps.get_life_cycle(table)
        self.assertEqual(720, life_cycle)


    def test_change_life_cycle(self):

        old_life_cycle = Odps.get_life_cycle(self.partition_table)
        new_life_cycle = int(old_life_cycle) + 1
        Odps.change_life_cycle(
            'aliyun_searchlog', self.partition_table, new_life_cycle, 
            self.access_id, self.access_key)
        life_cycle = Odps.get_life_cycle(self.partition_table)
        self.assertEqual(new_life_cycle, life_cycle)


class OdpsPrivilegeTest(OdpsTest):

    def test_grant_project(self):
        OdpsPrivilege.grant_project(
            self.project, self.account, self.access_id, self.access_key)

        self.assertRaises(Exception, OdpsPrivilege.grant_project, 
            self.project, 'not_exist@xx.com', self.access_id, self.access_key)

    def test_revoke_project(self):
        OdpsPrivilege.revoke_project(
            self.project, self.account, self.access_id, self.access_key)


    def test_grant_table(self):
        OdpsPrivilege.grant_table(
            self.project, self.table, self.account, self.access_id, self.access_key)


    def test_revoke_table(self):
        OdpsPrivilege.revoke_table(
            self.project, self.table, self.account, self.access_id, self.access_key)

    def test_is_project_owner(self):
        self.assertTrue(
            OdpsPrivilege.is_project_owner(
                self.project, self.owner_account, 
                self.admin_access_id, self.admin_access_key)
            )
        self.assertFalse(
            OdpsPrivilege.is_project_owner(
                self.project, self.account, 
                self.access_id, self.access_key)
            )

    def test_is_project_admin(self):
        self.assertTrue(
            OdpsPrivilege.is_project_admin(
                self.project, self.admin_account, 
                self.admin_access_id, self.admin_access_key)
            )
        self.assertFalse(
            OdpsPrivilege.is_project_admin(
                self.project, self.account, 
                self.access_id, self.access_key)
            )



class OdpsPackageTest(OdpsTest):
    def setUp(self):
        super(OdpsPackageTest, self).setUp()
        self.odps_package = OdpsPackage(
            self.project, self.admin_access_id, self.admin_access_key)
        self.odps_package_dev = OdpsPackage(
            self.project_dev, self.admin_access_id, self.admin_access_key)

    def test_exists(self):
        self.assertFalse(self.odps_package.exists('not_exists'))
        self.assertTrue(self.odps_package.exists(
                'aliyun_searchlog.ark_package_for_table_t_ljf_test'))

    def test_all(self):
        package_name = 't_ark_test_package'
        full_package_name = self.project + '.' + package_name
        self.odps_package.drop(package_name)
        self.assertFalse(self.odps_package.exists(package_name))
        self.odps_package.create(package_name)
        self.assertTrue(self.odps_package.exists(package_name))

        info = self.odps_package.desc(package_name)
        self.assertFalse(self.table in info)
        self.assertTrue(self.odps_package.no_tables(package_name))
        self.odps_package.add_table(package_name, self.table)
        info = self.odps_package.desc(package_name)
        self.assertTrue(self.table in info)
        self.assertFalse(self.odps_package.no_tables(package_name))

        self.odps_package.allow_install(self.project_dev, package_name)
        self.assertFalse(self.odps_package_dev.exists(full_package_name))
        self.odps_package_dev.install(full_package_name)
        self.assertTrue(self.odps_package_dev.exists(full_package_name))
        self.odps_package_dev.grant_read(full_package_name, self.account)

        self.odps_package_dev.revoke_read(full_package_name, self.account)
        self.odps_package_dev.uninstall(full_package_name)
        self.odps_package.remove_table(package_name, self.table)
        self.odps_package.drop(package_name)
        self.assertFalse(self.odps_package.exists(package_name))

class OdpsRoleTest(OdpsTest):
    
    def setUp(self):
        super(OdpsRoleTest, self).setUp()
        self.odps_role = OdpsRole(
            self.project, self.admin_access_id, self.admin_access_key)

    def test_all(self):
        role_name = 't_ark_test_role'

        self.odps_role.drop(role_name, force = True)
        self.assertFalse(self.odps_role.exists(role_name))
        self.odps_role.create(role_name)
        self.assertTrue(self.odps_role.exists(role_name))

        self.assertTrue(self.odps_role.no_tables(role_name))
        self.odps_role.add_table(role_name, self.table)
        self.assertFalse(self.odps_role.no_tables(role_name))
        
        self.assertTrue(self.odps_role.no_users(role_name))
        self.odps_role.grant(role_name, self.account)
        self.assertFalse(self.odps_role.no_users(role_name))

        self.odps_role.revoke(role_name, self.account)
        self.odps_role.remove_table(role_name, self.table)
        self.odps_role.drop(role_name)
        self.assertFalse(self.odps_role.exists(role_name))

