#coding=utf-8
import time

#时间格式转换
'''
def convert_time(time_str):
    time_array = time.strptime(time_str, "%Y-%m-%dT%H:%M:%SZ")
    time_stamp = int(time.mktime(time_array) +3600*8)
    time_array = time.localtime(time_stamp)
    other_style_time = time.strftime("%Y-%m-%d %H:%M:%S", time_array)
    return other_style_time
'''

def convert_time(time_str):
    time_array = time.strptime(time_str, "%Y-%m-%dT%H:%M:%S")
    time_stamp = int(time.mktime(time_array))
    time_array = time.localtime(time_stamp)
    other_style_time = time.strftime("%Y-%m-%d %H:%M:%S", time_array)
    return other_style_time











