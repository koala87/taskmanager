#coding=utf-8
import logging
import json
import traceback
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from common.models import ConfigType
from common.models import Config
from common.http_decorators import add_visit_record
from common.http_decorators import validate_params
from http_helper import JsonHttpResponse
from home_link import Homelink

logger = logging.getLogger('common')
login_url='/login/'


@add_visit_record
def list(request):
    try:
        links = Homelink.list(request.user)
        return JsonHttpResponse({'status': 0, 'data': links})
    except Exception, ex:
        logger.error('list links fail, %s' % traceback.format_exc())
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})


@add_visit_record
def list_all(request):
    try:
        links = Homelink.list_all()
        return JsonHttpResponse({'status': 0, 'data': links})
    except Exception, ex:
        logger.error('list all links fail, %s' % traceback.format_exc())
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})


@login_required(login_url = login_url)
@validate_params(check_params = ['id'])
@add_visit_record
def add(request):
    id = request.POST.get('id')
    try:
        home_link = Homelink.add(request.user, id)
        return JsonHttpResponse({'status': 0, 'data': home_link.id})
    except Exception, ex:
        logger.error('list links fail, %s' % traceback.format_exc())
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})


@login_required(login_url = login_url)
@validate_params(check_params = ['id'])
@add_visit_record
def remove(request):
    id = request.POST.get('id')
    try:
        Homelink.remove(request.user, id)
        return JsonHttpResponse({'status': 0, 'msg': '移除成功'})
    except Exception, ex:
        logger.error('list links fail, %s' % traceback.format_exc())
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})
