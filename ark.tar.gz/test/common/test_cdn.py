#coding=utf-8
import os
from django.test import TestCase
from common.cdn_file import Cdn

class CdnTest(TestCase):
    def test_all(self):
        local_file = './test_cdn_file'
        print Cdn.upload(local_file)
