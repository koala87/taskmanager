﻿#encoding:utf-8
import os
import tempfile
import traceback
import commands
import logging
logger = logging.getLogger('interest_graphs')
import common.no_block_sys_cmd as no_block_sys_cmd

class Cdn(object):

    @staticmethod
    def parse_cdn_url(stdout):
        import json
        cdn_url = ''
        try:
            stdout = json.loads(stdout)
            cdn_url = stdout['msg'].strip()
            assert cdn_url != ''
        except Exception, ex:
            logger.error('parse stdout fail, stdout=%s, %s' \
                             % (str(stdout), traceback.format_exc()))
            raise Exception('解析cdn_url失败')

        return cdn_url

    @staticmethod
    def upload(local_file, project = 'ark'):
        import hashlib 
        file_md5 = hashlib.md5(open(local_file, 'rb').read()).hexdigest()
        filename = os.path.basename(local_file)
        filename = os.path.splitext(filename)[0] + '_%s' % file_md5

        local_file = os.path.abspath(local_file)
        cmd_upload = "curl -F 'uploadfile=@%s' -F 'project=%s' -F 'action=upload' -F 'filename=%s' http://boss.m.sm.cn/internalapi/OssFile.php" \
            % (local_file, project, filename)

        logger.info(cmd_upload)
        status = output = ''
        try:
            __no_block_cmd = no_block_sys_cmd.NoBlockSysCommand(logger)
            stdout, stderr, status = __no_block_cmd.run_once(cmd_upload)
            assert status == 0
        except Exception, ex:
            logger.error('upload cdn file fail, stdout=%s, stderr=%s, %s' \
                             % (stdout, stderr, traceback.format_exc()))
            raise Exception('上传cdn文件失败')

        logger.error(stdout)
        logger.error(stderr)
        return Cdn.parse_cdn_url(stdout)

    @staticmethod
    def download(cdn_url, local_file = None):
        if local_file is None:
            local_file = tempfile.NamedTemporaryFile().name

        try:
            urllib.urlretrieve(cdn_url, local_file)
        except Exception, ex:
            logger.error('get cdn file fail, url=%s, %s' \
                             % (cdn_url, traceback.format_exc()))
            raise Exception('下载cdn文件失败')
        return local_file
