#coding:utf8
import logging
import datetime
import csv
logger = logging.getLogger('common')

def group_by_category(data, category_key = 'category'):
    d = {}
    for item in data:
        category = item
        for k in category_key.split('.'):
            category = category.get(k, '')
            if isinstance(category, basestring):
                break
        if category not in d:
            d[category] = []
        d[category].append(item)
    return d
        
def convert_size(size, current_unit = None):
    size_unit = ['K', 'M', 'G', 'P']
    start_idx = 0
    if current_unit and current_unit in size_unit:
        start_idx = size_unit.index(current_unit)
    
    for i in range(start_idx, len(size_unit)):
        if size < 1:
            break
        size = size / 1024.0

    current_unit = size_unit[i]
    return '%.2f %s' % (size, current_unit)
    
def convert_time_interval(interval):
    seconds = interval.seconds
    units = ['秒', '分', '时']
    values = []
    parts = []
    for i, unit in enumerate(units):
        if i == len(units) - 1:
            value = seconds
        else:
            value = seconds % 60
            seconds = seconds / 60
        values.append(value)
        if seconds == 0:
            break
    if interval.days > 0:
        values[-1] += 24 * interval.days

    for i, value in enumerate(values):
        parts.append('%d%s' % (value, units[i]))
    parts.reverse()
    return ''.join(parts)

        
def convert_to_east_8(t):
    if not isinstance(t, datetime.datetime):
        return t
    delta = datetime.timedelta(hours = 8)
    return t + delta


def read_local_file(local_file, size_limit = None):
    import os
    statinfo = os.stat(local_file)
    content = ''
    from pangu import PREVIEW_MAX_SIZE
    if size_limit is None:
        size_limit = PREVIEW_MAX_SIZE

    if statinfo.st_size > size_limit:
        raise Exception('文件大小超过 %d' % size_limit)
    else:
        try:
            f = open(local_file, 'r')
            content = f.read()
            f.close()
        except Exception, ex:
            logger.error('read file %s fail, %s' % (local_file, traceback.format_exc()))
            raise Exception('文件读取失败 %s' % str(ex))
    return content

def read_excel(local_file):
    import xlrd
    data = xlrd.open_workbook(local_file)
    lines = []
    for sheet in data.sheets():
        for i in range(0, sheet.nrows):
            line = []
            for j in range(0, sheet.ncols):
                value = sheet.cell(i, j).value
                if sheet.cell(i, j).ctype == xlrd.XL_CELL_NUMBER:
                    value = str(long(value)) if long(value) == value else str(value)
                print sheet.cell(i, j).ctype
                line.append(value)
            lines.append(line)
    return lines

def read_csv(local_file):
    lines = []
    with open(local_file, 'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for line in spamreader:
            line = map(lambda x: x.decode('GB2312'), line)
            lines.append(line)
    logger.debug(lines)
    return lines

def read_local_file_lines(local_file, filename, item_sep):
    if filename.endswith('.xls') \
            or filename.endswith('.xlsx'):
        return read_excel(local_file)

    if filename.endswith('.csv'):
        # lines = unicode_csv_reader(open(local_file, 'rb'))
        lines = read_csv(local_file)
        logger.debug(lines)
        return lines
    
    f = open(local_file, 'r')
    lines = f.readlines()
    lines = map(lambda x: x.strip().split(item_sep), lines)
    f.close()
    return lines

