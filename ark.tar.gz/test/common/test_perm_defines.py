from django.test import TestCase
from perm_defines import *

# Create your tests here.
class PermDefinesTest(TestCase):

    def setUp(self):
        pass

    def test_parse_permission(self):

        permission = ''
        perms = parse_permission(permission)
        self.assertEqual({}, perms)

        permission = None
        perms = parse_permission(permission)
        self.assertEqual({}, perms)

        permission = 'read|update|delete'
        perms = parse_permission(permission)
        self.assertEqual({'read': True, 'update': True, 'delete': True}, perms)

        permission = 'read'
        perms = parse_permission(permission)
        self.assertEqual({'read': True}, perms)

        permission = 'read|unknown'
        perms = parse_permission(permission)
        self.assertEqual({'read': True}, perms)


    def test_make_permission(self):

        permission = make_permission()
        self.assertEqual('', permission)

        permission = make_permission(read = True)
        self.assertEqual('read', permission)

        permission = make_permission(read = True, update = True)
        self.assertEqual('read|update', permission)

        permission = make_permission(read = 'test', update = True)
        self.assertEqual('update', permission)






