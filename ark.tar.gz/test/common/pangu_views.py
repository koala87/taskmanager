#coding=utf-8
import logging
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from http_helper import JsonHttpResponse
from common.pangu import Pangu
from common.views import get_download_response
from common.http_decorators import validate_params
logger = logging.getLogger('common')
login_url='/login/'

@login_required(login_url = login_url)
def download_file(request):
    from common.pangu import Pangu
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    local_file = temp_file.name

    file_path = request.GET.get('file_path')
    if file_path is None:
        return JsonHttpResponse({'status': 1, 'msg': 'file_path不能为空'})

    if Pangu.is_dir(file_path) or Pangu.direxists(file_path):
        return render(request, 'pangu_file_list.html',
                {'file_path': file_path})
        
    try:
        Pangu.download_file(file_path, local_file)
    except Exception, ex:
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})

    f = open(local_file, 'rb')
    content = f.read()
    f.close()
    
    return get_download_response(file_path.split('/').pop(), content)


@login_required(login_url = login_url)
@validate_params(check_params = ['dir'])
def ls(request):
    from common.pangu import Pangu
    dir = request.POST.get('dir')
    try:
        items = Pangu.ls(dir)
        return JsonHttpResponse({'status': 0, 'data': items})
    except Exception, ex:
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})    
