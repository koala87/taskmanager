#coding:utf8
from captcha.models import CaptchaStore
from captcha.helpers import captcha_image_url

class Captcha():
    
    @staticmethod
    def generate():
        key = CaptchaStore.generate_key()
        img = captcha_image_url(key)
        return key, img
