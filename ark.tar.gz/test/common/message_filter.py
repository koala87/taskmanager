#coding=utf-8
import logging
from django.db import models
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)


def get_filter_option(filter_options, idx):
    
    key = 'columns[%d][data]' % idx
    search_column = filter_options.get(key, '')
    
    regex_key = 'columns[%d][search][regex]' % idx
    regex = filter_options.get(regex_key, '')

    value_key = 'columns[%d][search][value]' % idx
    value = filter_options.get(value_key, '')

    return search_column, value, regex


def message_filter_list(message_list, filter_options, current_user):
    MAX_COLUMN_NUM = 100
    for idx in range(MAX_COLUMN_NUM):
        search_column, value, regex = get_filter_option(filter_options, idx)

        if not search_column:
            break
        if not value:
            continue

        if search_column == 'content':
            message_list = message_list.filter(content__contains = value)
        elif search_column == 'read':
            if value == str(0):
                message_list = message_list.filter(read = True)
            if value == str(1):
                message_list = message_list.filter(read = False)
        elif search_column == 'type':
            if value:
                message_list = message_list.filter(type = int(value))
                
    return message_list
