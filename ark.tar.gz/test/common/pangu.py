#coding:utf8
import os
import re
import commands
import logging

from django.conf import settings
logger = logging.getLogger('common')
SIZE_NOT_FOUND = -1

PATH_PREFIX = 'pangu://'
PATH_SEP = '/'
ALL_FILE_SUFFIX = '/.*'
PREVIEW_MAX_SIZE = 1024 * 1024 * 5
class Pangu():
    client = '/apsara/deploy/pu'
    META_LENGTH = 'Length'

    @staticmethod
    def ls(path):
        if Pangu.direxists(path + PATH_SEP):
            cmd = '%s ls %s' % (Pangu.client, path)
            status, output = commands.getstatusoutput(cmd)
            if status != 0:
                logger.error('ls directory fail: <%s>, msg: <%s>' % (path, output))
                raise Exception('ls directory fail')
            return [x for x in output.split('\n') if x]
        else:
            raise Exception('路径不存在')

    @staticmethod
    def parse_path(path, min_root_deep = 2):
        pure_path = path[len(PATH_PREFIX):]
        items = pure_path.split(PATH_SEP)
        items = [x for x in items if x]
        if path.endswith(PATH_SEP):
            items[-1] += PATH_SEP

        for i in range(len(items) - 1, min_root_deep, -1):
            root = PATH_PREFIX + PATH_SEP.join(items[:i+1])
            if Pangu.path_exists(root):
                return root, items[i+1:len(items)]

        root = PATH_PREFIX + PATH_SEP.join(items[:min_root_deep])
        patterns = items[min_root_deep:]
        return root, patterns


    @staticmethod
    def ls_recursively(path, patterns):
        if not patterns:
            return [path]
        new_path = path.strip(PATH_SEP) + PATH_SEP + patterns[0]
        if Pangu.path_exists(new_path):
            if len(patterns) == 1:
                return [new_path]
            else:
                return Pangu.ls_recursively(new_path, patterns[1:])

        try:
            ls_result = Pangu.ls(path)
        except:
            ls_result = []
        if not ls_result:
            return []

        files = []
        pattern = re.compile('^' + patterns[0] + '[/]?$') if patterns else None
        for item in ls_result:
            item = item.strip() 
            if pattern and not re.match(pattern, item):
                continue
            tmp_path = path.strip(PATH_SEP) + PATH_SEP + item
            if item[-1] == PATH_SEP:
                files += Pangu.ls_recursively(tmp_path, patterns[1:])
            else:
                files.append(tmp_path)
        return files
            

    @staticmethod
    def pattern_ls(path):
        root, pattern_list = Pangu.parse_path(path)
        print root, pattern_list
        return Pangu.ls_recursively(root, pattern_list)
        

    @staticmethod
    def exists(path):
        cmd = '%s meta %s' % (Pangu.client, path)
        status, output = commands.getstatusoutput(cmd)
        return status == 0


    @staticmethod
    def mkdir(path):
        cmd = '%s mkdir %s' % (Pangu.client, path)
        status, output = commands.getstatusoutput(cmd)
        return status == 0

    @staticmethod
    def get_size(info):
        size = SIZE_NOT_FOUND
        try:
            for item in [x.strip() for x in info.split('\n')]:
                if Pangu.META_LENGTH in item:
                    parts = item.split(':', 1)
                    if len(parts) == 2 and Pangu.META_LENGTH in parts[0]:
                        size = int(parts[1])
                        break
        except Exception, ex:
            logger.error('get size fail, info: <%s>, msg: <%s>' % \
                             (info, str(ex)))
        return size


    @staticmethod
    def size(path):

        if path.endswith(ALL_FILE_SUFFIX):
            path = path[:-len(ALL_FILE_SUFFIX)+1]

        info = ''
        if not path.endswith(PATH_SEP):
            try:
                info = Pangu.meta(path)
            except Exception, ex:
                logger.error('get meta fail: %s' % str(ex))
                pass
        
        if not info:
            try:
                info = Pangu.dirmeta(path)
            except Exception, ex:
                logger.error('get dirmeta fail: %s' % str(ex))
                pass

        size = Pangu.get_size(info) if info else SIZE_NOT_FOUND
        return size

    @staticmethod
    def pattern_size(path):
        if path.endswith(ALL_FILE_SUFFIX):
            path = path[:-len(ALL_FILE_SUFFIX)+1]
        paths = Pangu.pattern_ls(path)
        size = 0
        for path in paths:
            size += Pangu.size(path)
        return size, paths

    @staticmethod
    def path_exists(path):
        return Pangu.exists(path) or Pangu.direxists(path)

    @staticmethod
    def direxists(path):
        cmd = '%s dirmeta %s/' % (Pangu.client, path.strip())
        status, output = commands.getstatusoutput(cmd)
        return status == 0

    @staticmethod
    def dirmeta(path):
        cmd = '%s dirmeta %s/' % (Pangu.client, path.strip())
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            raise Exception('get directory[%s] meta fail' % path)
        return output

    @staticmethod
    def detail_dirmeta(path):
        cmd = '%s ls %s/ -xcare' % (Pangu.client, path.strip())
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            raise Exception('get directory[%s] detail meta fail' % path)
        return output

    @staticmethod
    def meta(path):
        cmd = '%s meta %s' % (Pangu.client, path)
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            logger.error('get file meta fail: <%s>, msg: <%s>' % (path, output))
            raise Exception('get file meta fail')
        return output

    @staticmethod
    def rm(path):
        cmd = '%s -f rm %s' % (Pangu.client, path)
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            logger.error('remove file fail: <%s>, msg: <%s>' % (path, output))
            raise Exception('remove file fail')
        return True

    @staticmethod
    def rmdir(path):
        cmd = '%s rmdir -f %s' % (Pangu.client, path)
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            logger.error('remove directory file fail: <%s>, msg: <%s>' % (path, output))
            raise Exception('remove directory fail')
        return True

    @staticmethod
    def header(path, line_num = 1000):
        cmd = '%s cat %s' % (Pangu.client, path)
        if line_num:
            cmd += ' | head -n %d' % line_num
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            logger.error('header file fail: <%s>, msg: <%s>' % (path, output))
            raise Exception('header file fail')
        return output.split('\n')

    @staticmethod
    def preview(file_path):
        if not Pangu.exists(file_path):
            raise Exception('路径不存在')

        size = Pangu.size(file_path)
        if size > PREVIEW_MAX_SIZE:
            raise Exception('不可预览，文件大小大于 %d' % PREVIEW_MAX_SIZE)
        lines = Pangu.header(file_path)
        return '\n'.join(lines)


    @staticmethod
    def download_dir(pangu_dir, local_dir):
        if not Pangu.direxists(pangu_dir):
            raise Exception('路径不存在')

        cmd = '%s cpdir %s %s' % (Pangu.client, pangu_dir, local_dir)
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            logger.error('download dir: <%s> fail: <%s>' % (pangu_dir, output))
            raise Exception('download dir fail')
        return True

    @staticmethod
    def download_file(pangu_path, local_file):
        if not Pangu.exists(pangu_path):
            raise Exception('文件不存在')

        cmd = '%s cp %s %s' % (Pangu.client, pangu_path, local_file)
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            logger.error('download file fail, cmd:<%s>, %s' % (cmd, output))
            raise Exception('download file fail')
        return True

    @staticmethod
    def is_dir(path):
        return path.endswith('/')
