#coding=utf-8
import logging
import traceback
import urllib
import urllib2
import httplib
import json
from django.conf import settings

logger = logging.getLogger('common')

REQ_URI = '/api/pipeline/auto_post_pipeline/'

class HttpPipeline():

    @staticmethod
    def make_config_str(config):
        kvs = map(lambda x: "%s=%s" % (str(x[0]), str(x[1])), config.items())
        config_str = '\n'.join(kvs)
        return config_str

    @staticmethod
    def req(data, timeout=30):
        try:
            logger.error(json.dumps(data))
            json_str = json.dumps(data).encode('gbk')
            req_package = {'req_pkg': urllib2.quote(json_str)}
            req_data = urllib.urlencode(req_package)

            headers = {
                "Content-type": "application/x-www-form-urlencoded",
                "Accept": "text/plain"}
            http_client = httplib.HTTPConnection(
                settings.PIPELINE_INTERFACE_ADDR, timeout=timeout)
            http_client.request("POST", REQ_URI, req_data, headers)
            response = http_client.getresponse()
  
            result = response.read()

            result = json.loads(result)
            result = json.loads(result)
            if result.get('status', 0) != 0:
                logger.info('request result error, msg: %s' % result)
                info = result.get('info', '')
                items = info.split(',Traceback', 1)
                if items:
                    result['info'] = items[0]
            return result
        except Exception, ex:
            logger.error('request error, msg: %s, %s' % (traceback.format_exc(), str(ex)))
            raise Exception('与pipeline接口交互失败')

    @staticmethod
    def copy(req_pack, timeout=30):
        result = ''
        try:
            result = HttpPipeline.req(req_pack, timeout)
            logger.debug(json.dumps(result))
            assert 0 == result.get('status', 0)
            return result['pl_id']
        except Exception, ex:
            logger.error('copy pipeline fail, result: %s, msg: %s' \
                             % (result, traceback.format_exc()))
            raise Exception('拷贝流程失败')                    

    @staticmethod
    def run(username, password, pipeline_name, run_time):
        req_pack = {
            'cmd': 'run_pipeline',
            'username': username,
            'password': password,
            'pipeline_name': pipeline_name,
            'run_time': run_time,
            }
        
        try:
            result = HttpPipeline.req(req_pack)
            assert 0 == result.get('status', 0)
            return result
        except Exception, ex:
            logger.error('run pipeline fail, msg: %s' \
                             % traceback.format_exc())
            raise Exception('执行流程失败')                    


    @staticmethod
    def stop(username, password, pipeline_name, run_time):
        req_pack = {
            'cmd': 'stop_pipeline',
            'username': username,
            'password': password,
            'pipeline_name': pipeline_name,
            'run_time': run_time,
            }
        
        try:
            result = HttpPipeline.req(req_pack)
            assert 0 == result.get('status', 0)
            return result
        except Exception, ex:
            logger.error('stop pipeline fail, msg: %s' \
                             % traceback.format_exc())
            raise Exception('停止流程失败')                    

    @staticmethod
    def status(username, password, pipeline_name, run_time):
        req_pack = {
            'cmd': 'get_pipe_status',
            'username': username,
            'password': password,
            'name': pipeline_name,
            'run_time': run_time,
            }
        
        result = ''
        try:
            result = HttpPipeline.req(req_pack)
            logger.error(json.dumps(result, ensure_ascii=False))
            assert 0 == result.get('status', 0)
            return result
        except Exception, ex:
            logger.error('get pipeline status fail, msg: %s ,result: %s'\
                             % (traceback.format_exc(), str(result)))
            raise Exception('获取流程状态失败')                    


    @staticmethod
    def task_log(username, password, 
                 pipeline_name, task_id, 
                 run_time, file_name):

        data = {
            "cmd": "get_file_content",
            'username': username,
            'password': password,
            "name": pipeline_name,
            "task_id": task_id,
            "run_time": run_time,
            "file_name": file_name,
            "read_len": 1024 * 1024
            }

        result = None
        try:
            result = HttpPipeline.req(data)
            not_exists_str = 'Schedule matching query does not exist'
            assert 0 == result.get('status', 0) \
                or result.get('info', '').startswith(not_exists_str)

            return result.get('file_content', '无')
        except Exception, ex:
            logger.error('get task run log fail, result: %s, msg: %s'\
                             % (str(result),traceback.format_exc()))
            raise Exception('获取任务日志失败')

    @staticmethod
    def delete_pipeline(username, password, pipeline_name):
        req_pack = {
            'cmd': 'delete_pipeline',
            'username': username,
            'password': password,
            'name': pipeline_name,
            }
        
        try:
            result = HttpPipeline.req(req_pack)
            assert 0 == result.get('status', 0)
            return result
        except Exception, ex:
            logger.error('delete pipeline fail, msg: %s, %s' \
                             % (traceback.format_exc(),str(ex)))
            raise Exception('删除流程失败')                    

    @staticmethod
    def exist_pipeline(username, password, pipeline_name):
        req_pack = {
            'cmd': 'get_pipeline',
            'username': username,
            'password': password,
            'name': pipeline_name,
            }
        
        try:
            result = HttpPipeline.req(req_pack)
            assert 0 == result.get('status', 0)
            return True
        except Exception, ex:
            logger.error('get pipeline fail, msg: %s' \
                             % traceback.format_exc())
            return False

    @staticmethod
    def set_pl_ct_time(username, password, pipeline_name, ct_time):
        req_pack = {
            'cmd': 'update_pipeline',
            'username': username,
            'password': password,
            'name': pipeline_name,
            'enable': 1,
            'ct_time': ct_time,
            'monitor_way': 3,
            }
        
        try:
            result = HttpPipeline.req(req_pack)
            assert 0 == result.get('status', 0)
            return True
        except Exception, ex:
            logger.error('set cron_time pipeline fail, msg: %s' \
                             % traceback.format_exc())
            return False

    @staticmethod
    def set_pl_monitor(username, password, pipeline_name, user_list='', monitor_way=3):
        req_pack = {
            'cmd': 'update_pipeline',
            'username': username,
            'password': password,
            'name': pipeline_name,
            'monitor_way': monitor_way,
            'owners_name': user_list,
            }
        
        try:
            result = HttpPipeline.req(req_pack)
            assert 0 == result.get('status', 0)
            return True
        except Exception, ex:
            logger.error('set pipeline monitor fail, msg: %s' \
                             % traceback.format_exc())
            return False

    @staticmethod
    def update_task_config(username, password, pipeline_name, task_name, config, retry_count=0):
        config_list = []
        for item in config:
            config_list.append('%s = %s' % (item, config[item]))
        req_pack = {
            'cmd': 'update_task',
            'username': username,
            'password': password,
            'pipeline_name': pipeline_name,
            'retry_count': retry_count,
            'task':{
                'name':task_name,
                'config': '\n '.join(config_list),
            }
        }
        
        try:
            result = HttpPipeline.req(req_pack)
            assert 0 == result.get('status', 0)
            return True
        except Exception, ex:
            logger.error('update task fail, msg: %s' \
                             % traceback.format_exc())
            return False


