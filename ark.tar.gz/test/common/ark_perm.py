#encoding:utf-8
import logging
import numbers
from django.contrib.auth.models import User
from guardian.shortcuts import assign_perm
from guardian.shortcuts import remove_perm
from guardian.shortcuts import get_users_with_perms
from guardian.shortcuts import get_objects_for_user
from guardian.shortcuts import get_perms
from django.conf import settings
logger = logging.getLogger(settings.PROJECT_NAME)
from models import PermHistory
from models import Config
from perm_defines import *

def get_admins():
    ''' 获取管理员账号，在系统配置中 '''
    try:
        v = Config.objects.get_value('sys_ark_admins')
        users = v.split()
        users = map(lambda x: x.strip(), users)
        return users
    except Exception, ex:
        logger.error('get system ark admins fail, msg: %s' \
                         % traceback.format_exc())
        raise Exception('获取系统管理配置失败')


def is_admin(user):
    ''' @param user: string or User '''
    if isinstance(user, (numbers.Number, basestring)):
        try:
            user = User.objects.get(pk = user)
        except Exception, ex:
            raise Exception('用户不存在 id=%s' % str(user))

    name = ''
    if isinstance(user, str):
        name = user
    if isinstance(user, User):
        name = user.username

    if name == settings.SITE_ADMIN or user.is_superuser:
        return int(True)

    admins = []
    try:
        admins = get_admins()
    except:
        pass
    return int(name in admins)


class UserPerm():

    @staticmethod
    # obj is a instance of resource, like data_config, pipeline
    def grant(operator, to_user, obj, reason = '', read = True, update = False, 
              delete = False, execute = False):
        PermHistory.objects.grant(operator, to_user, type(obj).__name__, obj.id, 
                                  reason = reason, read = read, 
                                  update = update, delete = delete, 
                                  execute = execute)
        if read is True:
            assign_perm(PERM_TYPE_READ, to_user, obj)
            
        if update is True:
            assign_perm(PERM_TYPE_UPDATE, to_user, obj)

        if delete is True:
            assign_perm(PERM_TYPE_DELETE, to_user, obj)

        if execute is True:
            assign_perm(PERM_TYPE_EXECUTE, to_user, obj)

    @staticmethod
    # obj is a instance of resource, like data_config, pipeline
    def revoke(operator, from_user, obj, reason = '', read = True, 
               update = False, delete = False, execute = False, odps_perm_type=-1):
        PermHistory.objects.revoke(
            operator, from_user, type(obj).__name__, obj.id, reason = reason, 
            read = read, update = update, delete = delete, execute = execute, odps_perm_type=odps_perm_type)

        if read is True:
            remove_perm(PERM_TYPE_READ, from_user, obj)

        if update is True:
            remove_perm(PERM_TYPE_UPDATE, from_user, obj)

        if delete is True:
            remove_perm(PERM_TYPE_DELETE, from_user, obj)

        if execute is True: 
            remove_perm(PERM_TYPE_EXECUTE, from_user, obj)


    @staticmethod
    # obj is a instance of resource, like data_config, pipeline
    def apply(applicant, grantor, obj, reason = '', read = True, update = False, 
              delete = False, execute = False):
        return PermHistory.objects.apply(
            applicant, grantor, type(obj).__name__, obj.id, reason = reason, 
            read = read, update = update, delete = delete, execute = execute)


    @staticmethod
    # obj is a instance of resource, like data_config, pipeline
    def accept(operator, applicant, obj, hist_id, reason = ''):
        perm_history = PermHistory.objects.get(pk = hist_id)
        if perm_history:
            perms = parse_permission(perm_history.permission)
            read = perms.get(PERM_TYPE_READ, False)
            update = perms.get(PERM_TYPE_UPDATE, False)
            delete = perms.get(PERM_TYPE_DELETE, False)
            execute = perms.get(PERM_TYPE_EXECUTE, False)
        
            PermHistory.objects.accept(hist_id, reason)

            if read is True:
                assign_perm(PERM_TYPE_READ, applicant, obj)
                
            if update is True:
                assign_perm(PERM_TYPE_UPDATE, applicant, obj)
                    
            if delete is True:
                assign_perm(PERM_TYPE_DELETE, applicant, obj)

            if execute is True:
                assign_perm(PERM_TYPE_EXECUTE, applicant, obj)


    @staticmethod
    # obj is a instance of resource, like data_config, pipeline
    def deny(hist_id, reason = ''):
        PermHistory.objects.deny(hist_id, reason)


    @staticmethod
    # return: {<User: get_users_user1>: [u'delete', u'read', u'update'], 
    #          <User: get_users_user2>: [u'read']}
    def get_allowed_users(obj):
        return get_users_with_perms(obj, attach_perms = True)

    @staticmethod
    def get_objs_for_user(user, app = 'common', perms = ['update'], klass = None):
        perms = ['%s.%s' % (app, x) for x in perms]
        try:
            return get_objects_for_user(user, perms, klass = klass)
        except Exception, ex:
            logger.error(str(ex))
            return []

    @staticmethod
    def get_user_perms(user, obj):
        return get_perms(user, obj)

    @staticmethod
    # get the users to grant
    def get_granting_users(owner, obj):
        allowed_users = UserPerm.get_allowed_users(obj)
        allowed_users = allowed_users.keys()

        all_users = list(User.objects.filter(id__gt = 0))
        return [user for user in all_users 
                if user != owner and user not in allowed_users]

    @staticmethod
    def has_perm(user, perm_type, obj):
        return is_admin(user) \
            or UserPerm.is_owner(user, obj) \
            or user.has_perm(perm_type, obj)

    @staticmethod
    def has_read_perm(user, obj):
        return UserPerm.has_perm(user, PERM_TYPE_READ, obj)

    @staticmethod
    def has_update_perm(user, obj):
        return UserPerm.has_perm(user, PERM_TYPE_UPDATE, obj)

    @staticmethod
    def has_delete_perm(user, obj):
        return UserPerm.has_perm(user, PERM_TYPE_DELETE, obj)

    @staticmethod
    def has_execute_perm(user, obj):
        return UserPerm.has_perm(user, PERM_TYPE_EXECUTE, obj)

    @staticmethod
    def is_owner(user, obj):
        return hasattr(obj, 'owner_id') and user.id == obj.owner_id

    @staticmethod
    def has_grant_perm(user, obj):
        # TODO: simple logic, upgrade
        return is_admin(user) or UserPerm.is_owner(user, obj)         
