#coding: utf8
import json
import traceback
import logging
from common.models import Config
from common.models import ConfigType
from common.models import UserLink

logger = logging.getLogger('common')

class Homelink():
    config_type = '首页链接'
    user_default_links = 'home_user_default_links'

    @staticmethod
    def links_value(items):
        links = []
        has_error = False
        try:
            for item in items:
                try:
                    link = json.loads(item.value)
                except Exception, ex:
                    logger.error('parse link fail, key=%s, %s' % (
                            item.key, traceback.format_exc()))
                    has_error = True
                link['id'] = item.id
                links.append(link)
            return links
        except Exception, ex:
            logger.error('parse link fail, %s' % traceback.format_exc())
            raise Exception('解析连接配置失败')        


    @staticmethod
    def list_all():
        items = []
        try:
            t = ConfigType.objects.get(name = Homelink.config_type)
            items = Config.objects.filter(config_type = t)
        except Exception, ex:
            logger.error('config type fail, msg: %s' % traceback.format_exc())
            raise Exception('获取连接配置失败')
        
        links = Homelink.links_value(items)
        category_links = {}
        for link in links:
            category = link.get('category', '其他')
            if category not in category_links:
                category_links[category] = []
            category_links[category].append(link)


        # order link in each group
        order_key = 'order'
        for category, links in category_links.items():
            links = sorted(links, lambda x, y: cmp(x.get(order_key, 0), y.get(order_key, 0)))
            category_links[category] = links
        return category_links


    @staticmethod
    def user_default():
        items = []
        try:
            item = Config.objects.get(key = Homelink.user_default_links)
            names = item.value.strip().split()
            names = map(lambda x: x.strip(), names)
            items = Config.objects.filter(key__in = names)
        except Exception, ex:
            logger.error('get home_user_default_links fail, msg: %s' \
                             % traceback.format_exc())
            raise Exception('获取用户默认收藏连接失败')
        return items


    @staticmethod
    def get_link(id):
        config = None
        try:
            config = Config.objects.select_related('config_type').get(pk = id)
            assert config.config_type.name == Homelink.config_type
        except Exception, ex:
            logger.error('get link fail, %s' % traceback.format_exc())
            raise Exception('不存在链接 id=%s' % str(id))
        return config


    @staticmethod
    def add(user, id):
        link = Homelink.get_link(id)
        user_link = None
        if not UserLink.objects.filter(user = user, link = link).exists():
            user_link = UserLink.objects.create(user = user, link = link)
        else:
            user_link = UserLink.objects.get(user = user, link = link)
        return user_link


    @staticmethod
    def remove(user, id):
        link = Homelink.get_link(id)
        UserLink.objects.filter(user = user, link = link).delete()
        

    @staticmethod
    def list(user):
        items = []
        if user and user.is_authenticated():
            for item in UserLink.objects.filter(user = user):
                items.append(item.link)
        if len(items) == 0:
            items = Homelink.user_default()
        return Homelink.links_value(items)





