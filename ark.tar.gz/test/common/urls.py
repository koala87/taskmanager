from django.conf.urls import patterns, include, url
from common import views
from common import message_views

urlpatterns = patterns('',
    url(r'^message/$',message_views.message),
    url(r'^message_list/$',message_views.message_list),
    url(r'^messageCount/$',message_views.message_count),
    url(r'^read/$',message_views.set_read),
    url(r'^read_all/$',message_views.read_all),
    url(r'^delete_message/$',message_views.delete_message),
    url(r'^message_content/(?P<id>\d+)/$',message_views.content),
    url(r'^config/$',views.config),
    url(r'^configType/$',views.config_type),
    url(r'^configList/(?P<data_id>\d+)/$',views.config_list),
    url(r'^configTypeList/(?P<data_id>\d+)/$',views.config_list),
    url(r'^createConfig/$',views.create_config),
    url(r'^createConfigType/$',views.create_config_type),
    url(r'^deleteConfig/$',views.delete_config),
    url(r'^deleteConfigType/$',views.delete_config),
    url(r'^updateConfig/$',views.update_config),
    url(r'^updateConfigType/$',views.update_config_type),

    url(r'^preview_pangu_file/$', views.preview_pangu_file),

    url(r'^pangu/', include('common.pangu_urls')),

    url(r'^home_link/', include('common.home_link_urls')),
)


