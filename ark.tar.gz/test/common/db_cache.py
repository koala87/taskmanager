#coding=utf-8

from django.core.cache import get_cache
db_cache = get_cache('database')
default_cache_time = 60 * 60 * 24

class DbCache():
    @staticmethod
    def get_data(key, default = None):
        res = db_cache.get(key)
        if default is not None and res is None:
            res = default
        return res

    @staticmethod
    def set_data(key, data, cache_time = default_cache_time):
        return db_cache.set(key, data, cache_time)
