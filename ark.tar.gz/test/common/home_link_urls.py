from django.conf.urls import patterns, url
from common import home_link_views as views

urlpatterns = patterns('',
    url(r'^list_all/', views.list_all),
    url(r'^add/', views.add),
    url(r'^remove/', views.remove),
    url(r'^list/', views.list),
)


