from django.test import TestCase
from django.contrib.auth.models import User
from models import ConfigType
from models import Config
from models import OpHistory
import test_functions 

# Create your tests here.
class ConfigTest(TestCase):

    def setUp(self):
        self.user1, self.ark_admin = test_functions.prepare_user()
        self.type1 = ConfigType.objects.create(name = 'type1')

        self.config1 = Config.objects.create(
            key = 'key1',
            value = 'value1',
            config_type = self.type1)

    def test_all(self):
        self.assertEqual(0, OpHistory.objects.all().count())
        OpHistory.objects.add(self.user1, Config, 'test1')
        OpHistory.objects.add(self.user1, ConfigType, 'test2')
        self.assertEqual(2, OpHistory.objects.all().count())
