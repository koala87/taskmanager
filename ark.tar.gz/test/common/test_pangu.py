import os
import shutil
import commands
from django.test import TestCase
from common.pangu_oprations import mk_tmp_file
from common.pangu_oprations import mk_tmp_dir
from pangu import Pangu, PATH_SEP

# Create your tests here.
class PanguTest(TestCase):

    def setUp(self):
        self.dir_path = 'pangu://AY500/product/shenma_log/tmp/'\
            'ljf_ark_tools_unittest/dir/'
        self.file_path = self.dir_path + 'tmp'
        self.tmp_file_path = 'pangu://AY54/ark_test/ljf_test_file'
        self.tmp_dir_path = 'pangu://AY54/ark_test/ljf_test/'

    def test_meta(self):
        meta = Pangu.meta(self.file_path)
        print 'get meta:', meta

    def test_dirmeta(self):
        dirmeta = Pangu.dirmeta(self.dir_path)
        print 'get dirmeta:', dirmeta

    def test_detail_dirmeta(self):
        dirmeta = Pangu.detail_dirmeta(self.dir_path)
        print 'get detail dirmeta:', dirmeta

    def test_exists(self):
        self.assertFalse(Pangu.exists(self.file_path + '_nothing'))
        self.assertTrue(Pangu.exists(self.file_path))

    def test_ls(self):
        output = Pangu.ls(self.dir_path)
        print output

    def test_parse_path(self):
        root, patterns = Pangu.parse_path(self.dir_path)
        self.assertEqual(root, self.dir_path)
        self.assertListEqual(patterns, [])

        path = self.dir_path + '.*'
        root, patterns = Pangu.parse_path(path)
        self.assertEqual(root, self.dir_path.strip(PATH_SEP))
        self.assertListEqual(patterns, ['.*'])

        path = self.dir_path + '2015.*/file0'
        root, patterns = Pangu.parse_path(path)
        self.assertEqual(root, self.dir_path.strip(PATH_SEP))
        self.assertListEqual(patterns, ['2015.*', 'file0'])


    def test_ls_recursively(self):
        base_dir = 'pangu://AY500/product/shenma_log/tmp/ljf_ark_tools_unittest'

        files = Pangu.ls_recursively(
            base_dir, ['pattern.*', '201506.*'])
        f1 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', ''])
        f2 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150602', ''])
        self.assertListEqual([f1, f2], files)

        files = Pangu.ls_recursively(
            base_dir, ['pattern_dir1', '2015.*', 'f0'])
        f1 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f0'])
        f2 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150602', 'f0'])
        self.assertListEqual([f1, f2], files)

        files = Pangu.ls_recursively(
            base_dir, ['pattern_dir1', '20150601', '.*'])
        f1 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f0'])
        f2 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f1'])
        self.assertListEqual([f1, f2], files)

        files = Pangu.ls_recursively(
            base_dir, ['pattern_dir1', '20150601', 'f0'])
        f1 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f0'])
        self.assertListEqual([f1], files)


    def test_pattern_ls(self):
        base_dir = 'pangu://AY500/product/shenma_log/tmp/ljf_ark_tools_unittest'

        files = Pangu.pattern_ls(base_dir + '/pattern.*/201506.*')
        f1 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', ''])
        f2 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150602', ''])
        self.assertListEqual([f1, f2], files)

        files = Pangu.pattern_ls(base_dir + '/pattern_dir1/2015.*/f0')
        f1 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f0'])
        f2 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150602', 'f0'])
        self.assertListEqual([f1, f2], files)

        files = Pangu.pattern_ls(base_dir + '/pattern_dir1/20150601/.*')
        f1 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f0'])
        f2 = PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f1'])
        self.assertListEqual([f1, f2], files)

        files = Pangu.pattern_ls(base_dir + '/pattern_dir1/20150601/f0')
        expect_files = [PATH_SEP.join([base_dir, 'pattern_dir1', '20150601', 'f0']),]
        self.assertListEqual(expect_files, files)

    def test_mkdir(self):
        Pangu.mkdir(self.tmp_dir_path)
        self.assertTrue(Pangu.direxists(self.tmp_dir_path))

    def test_direxists(self):
        self.assertFalse(Pangu.exists(self.dir_path + '_nothing'))
        self.assertTrue(Pangu.direxists(self.dir_path))

    def test_header(self):
        mk_tmp_file(self.tmp_file_path)
        header = Pangu.header(self.tmp_file_path)
        self.assertEqual(['xxx', 'yyy'], header)

    def test_rm(self):
        mk_tmp_file(self.tmp_file_path)
        self.assertTrue(Pangu.rm(self.tmp_file_path))

    def test_rmdir(self):
        mk_tmp_dir(self.tmp_dir_path)
        self.assertTrue(Pangu.rmdir(self.tmp_dir_path))

    def test_size(self):
        size = Pangu.size(self.file_path)
        print 'get file size:', size
        self.assertNotEqual(-1, size)

        size = Pangu.size(self.dir_path)
        print 'get directory size:', size
        self.assertNotEqual(-1, size)

        dir_path = self.dir_path + '/.*'
        size = Pangu.size(dir_path)
        print 'get directory size:', size
        self.assertNotEqual(-1, size)


    def test_pattern_size(self):
        pattern_size, paths = Pangu.pattern_size(self.file_path)
        size = Pangu.size(self.file_path)
        self.assertNotEqual(-1, size)
        self.assertNotEqual(0, size)
        self.assertListEqual([self.file_path], paths)
        self.assertEqual(size, pattern_size)

        base_dir = 'pangu://AY500/product/shenma_log/tmp/ljf_ark_tools_unittest'
        pattern_size, paths = Pangu.pattern_size(
            base_dir + PATH_SEP + 'pattern_.*')
        p1 = base_dir + PATH_SEP + 'pattern_dir1/'
        p2 = base_dir + PATH_SEP + 'pattern_dir2/'
        p1_size = Pangu.size(p1)
        p2_size = Pangu.size(p2)
        self.assertListEqual([p1, p2], paths)
        self.assertEqual(p1_size + p2_size, pattern_size)

        pattern_size, paths = Pangu.pattern_size(
            base_dir + PATH_SEP + 'pattern_.*1/201506[\d]+/')
        p1 = base_dir + PATH_SEP + 'pattern_dir1/20150601/'
        p2 = base_dir + PATH_SEP + 'pattern_dir1/20150602/'
        p1_size = Pangu.size(p1)
        p2_size = Pangu.size(p2)
        self.assertListEqual([p1, p2], paths)
        self.assertEqual(p1_size + p2_size, pattern_size)

        dir = base_dir + '/pattern_dir1/20150601/.*'
        pattern_size, paths = Pangu.pattern_size(dir)
        p = base_dir + PATH_SEP + 'pattern_dir1/20150601/'
        p_size = Pangu.size(p)
        self.assertListEqual([p], paths)
        self.assertEqual(p_size, pattern_size)


    def test_download_dir(self):
        local_dir = '/home/jianfeng.liujf1/doc/tmp/test_download_dir'
        pangu_dir = self.dir_path

        if os.path.exists(local_dir):
            shutil.rmtree(local_dir)
        self.assertFalse(os.path.exists(local_dir))
        
        Pangu.download_dir(pangu_dir, local_dir)
        self.assertTrue(os.path.exists(local_dir))
        
