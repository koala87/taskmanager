#coding=utf-8
import logging
import json
import traceback
from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.contrib.auth.decorators import login_required
from common.models import Message
from common.message_manager import MessageManager
from common.message_filter import *
from common.ark_perm import is_admin
from common.http_helper import JsonHttpResponse
from convert_time import *
logger = logging.getLogger('common')
IS_READ = 1
IS_NOT_READ = 0
CUSTOM_MESSAGE_TABLE_CUT = 130

login_url='/login/'

def str_cut(str, cut_len):
    items = str.split('</style>')
    if len(items) > 1:
        str = items[-1].strip()
        
    if str.startswith('<body>'):
        str = str[6:]
    while str.startswith('<br>'):
        str = str[4:].strip()
    while str.endswith('<br>'):
        str = str[:-5].strip()
    if(len(str)>cut_len):
        str = str[0:cut_len] + "..."
    return str

@login_required(login_url='/login/')
def message(request):
    return HttpResponseRedirect('/ucenter/?tab=user_message')


@login_required(login_url = login_url)
def message_count(request):
    if request.method == 'POST' and request.is_ajax():
        user = request.user
        count = Message.objects.count(user,False)
    return JsonHttpResponse(
            {'status':0,'count':count})


@login_required(login_url='/login/')
def delete_message(request):
    if request.method == 'POST' and request.is_ajax():
        message_id = request.POST.get('id')
        try:
            messages = message_id.strip().split(',')
            if messages:
                Message.objects.delete(messages, receiver = request.user)
        except Exception, ex:
            logger.error('delete messages fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'删除成功！'})


@login_required(login_url = login_url)
def set_read(request):
    if request.method == 'POST' and request.is_ajax():
        message_id = request.POST.get('id')
        user = request.user
        try:
            Message.objects.read(int(message_id))
            count = Message.objects.count(user,False)
        except Exception, ex:
            logger.error('read messages fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'消息已读！','count':count})

def read_all(request):
    if request.method == 'POST' and request.is_ajax():
        try:
            Message.objects.read(receiver = request.user)
        except Exception, ex:
            logger.error('read all messages fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'已全部设为已读！'})

def convert_desc(desc):
    if desc.split("'")>1:
        desc.replace("'",'')
    return desc


def custom_message_table(messages,draw,total_count,filter_count):
    result = {"draw":draw,"recordsTotal": total_count,
                "recordsFiltered": filter_count}
    data = []
    for item in messages:
        item['fields']["id"]=item['pk']
        is_read = item['fields']["read"]
        item['fields']["is_read"] = is_read
        type = item['fields']["type"]
        if type >= len(Message.type_choices):
            item['fields']["type"] = Message.type_choices[0][1] 
        else:
            item['fields']["type"] = Message.type_choices[type][1] 
        read_tag = IS_READ if is_read else IS_NOT_READ
        item['fields']["read"] = "<p id='status_"+str(item['pk'])+\
            "'>已读</p>" if is_read else "<p id='status_"+\
            str(item['pk'])+"'>未读</p>"
        other_style_time = convert_time(item['fields']["create_time"])
        item['fields']["create_time"] = other_style_time
        desc = item['fields']["content"]

        dsp_content = str_cut(desc, CUSTOM_MESSAGE_TABLE_CUT)
            
        item['fields']["content"] = "<font id='content_"+\
            str(item['pk'])+"' message_type='"+str(type)+\
            "' title='点击查看详情'" + \
            " is_read='"+str(read_tag)+\
            "'>"+dsp_content+"</font>"

        data.append(item['fields'])
    result['data'] = data

    result['type_choices'] = Message.type_choices
    return result


@login_required(login_url = login_url)
#条件search
def filter(request,message_list):
    message_total_count = message_list.count()
    message_filter_count = message_total_count

    draw = request.POST.get('draw')
    start = request.POST.get('start')
    length = request.POST.get('length')
    page = int(start)/int(length)+1

    #生成一个piginator分页使用
    paginator = Paginator(message_list, int(length))
    return paginator,page,draw,message_total_count,message_filter_count


@login_required(login_url = login_url)
def message_list(request):
    user = request.user
    message_list = Message.objects.list(user)
    message_list = message_list.order_by('-create_time')

    message_list = message_filter_list(message_list,request.POST,request.user)

    #经过筛选之后的paginator
    paginator,page,draw,message_total_count,message_filter_count = \
        filter(request,message_list)

    try:
        messages = paginator.page(page)
    except PageNotAnInteger:
        messages = paginator.page(1)
    except EmptyPage:
        messages = paginator.page(paginator.num_pages)

    json_str = serializers.serialize('json',messages.object_list)
    result = json.loads(json_str)
    
    result = custom_message_table(result,int(draw),message_total_count,\
            message_filter_count)
    return HttpResponse(json.dumps(result), content_type='application/json')


@login_required(login_url = login_url)
def content(request, id):
    item = None
    try:
        item = Message.objects.get(pk = id)
    except Exception, ex:
        logger.error('get message fail, id=%s, %s' \
                         % (str(id), traceback.format_exc()))
        return JsonHttpResponse({'status':1, 'msg':'无效的消息id %s' % str(id)})

    from ark_perm import is_admin
    if request.user not in (item.sender, item.receiver) \
            and not is_admin(request.user):
        return JsonHttpResponse({'status':1, 'msg':'无此权限'})

    return JsonHttpResponse({'status':0, 'content':item.content})
        
