from django.test import TestCase
from django.contrib.auth.models import User
from models import Message
from message_manager import MessageManager

# Create your tests here.
class MessageTest(TestCase):

    def setUp(self):
        self.user1 = User.objects.create(username = 'user1')
        self.user2 = User.objects.create(username = 'user2')

        self.message121 = Message.objects.create(
            sender = self.user1,
            receiver = self.user2,
            content = 'test121')
        self.message122 = Message.objects.create(
            sender = self.user1,
            receiver = self.user2,
            content = 'test122')
        self.message123 = Message.objects.create(
            sender = self.user1,
            receiver = self.user2,
            content = 'test123')

        self.message211 = Message.objects.create(
            sender = self.user2,
            receiver = self.user1,
            content = 'test211')
        self.message212 = Message.objects.create(
            sender = self.user2,
            receiver = self.user1,
            content = 'test212')

    def test_read(self):

        self.assertEqual(3, Message.objects.filter(
                receiver = self.user2).count())

        # read single message
        self.assertTrue(Message.objects.read(id = self.message121.id))
        self.assertEqual(1, Message.objects.filter(
                receiver = self.user2,
                read = True).count())

        # read a list of messages
        self.assertTrue(Message.objects.read(
                id = [self.message122.id, self.message123.id]))
        self.assertEqual(3, Message.objects.filter(
                receiver = self.user2,
                read = True).count())

        # read single message with wrong receiver
        self.assertEqual(0, Message.objects.filter(
                receiver = self.user1,
                read = True).count())
        self.assertTrue(Message.objects.read(
                id = self.message211.id,
                receiver = self.user2))
        self.assertEqual(0, Message.objects.filter(
                receiver = self.user1,
                read = True).count())

    def test_delete(self):

        self.assertEqual(3, Message.objects.filter(
                receiver = self.user2).count())

        # delete single message
        self.assertTrue(Message.objects.delete(id = self.message121.id))
        self.assertEqual(3, Message.objects.filter(
                receiver = self.user2).count())
        self.assertEqual(1, Message.objects.filter(
                receiver = self.user2,
                deleted = True).count())

        # delete a list of messages
        self.assertTrue(Message.objects.delete(
                id = [self.message122.id, self.message123.id]))
        self.assertEqual(3, Message.objects.filter(
                receiver = self.user2,
                deleted = True).count())

        # delete single message with wrong receiver
        self.assertEqual(0, Message.objects.filter(
                receiver = self.user1,
                deleted = True).count())
        self.assertTrue(Message.objects.delete(
                id = self.message211.id,
                receiver = self.user2))
        self.assertEqual(0, Message.objects.filter(
                receiver = self.user1,
                deleted = True).count())

    def test_list(self):

        self.user3 = User.objects.create(username = 'user3')
        self.message231 = Message.objects.create(
            sender = self.user2,
            receiver = self.user3,
            content = 'test231')
        self.message232 = Message.objects.create(
            sender = self.user2,
            receiver = self.user3,
            content = 'test232')
        self.message233 = Message.objects.create(
            sender = self.user2,
            receiver = self.user3,
            content = 'test233')
        
        self.assertEqual(3, Message.objects.list(self.user3).count())
    
        Message.objects.select_for_update().filter(
            pk = self.message231.id).update(read = True)
        self.assertEqual(1, Message.objects.list(
                self.user3, read = True).count())
        self.assertEqual(2, Message.objects.list(
                self.user3, read = False).count())

    def test_count(self):

        self.user4 = User.objects.create(username = 'user4')
        self.message241 = Message.objects.create(
            sender = self.user2,
            receiver = self.user4,
            content = 'test241')
        self.message242 = Message.objects.create(
            sender = self.user2,
            receiver = self.user4,
            content = 'test242')
        self.message244 = Message.objects.create(
            sender = self.user2,
            receiver = self.user4,
            content = 'test233')
        
        self.assertEqual(3, Message.objects.count(self.user4))
        
        Message.objects.select_for_update().filter(
            pk = self.message241.id).update(read = True)
        self.assertEqual(1, Message.objects.count(
                self.user4,
                read = True))
        self.assertEqual(2, Message.objects.count(
                self.user4,
                read = False))





                                                      



