#coding=utf-8
import logging
import json
from django.shortcuts import render,render_to_response
from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.decorators import login_required
from django.core import serializers
from common.models import Message
from common.models import ConfigType
from common.models import Config
from common.message_manager import MessageManager
from common.message_filter import *
from common.config_filter import *
from common.ark_perm import is_admin
from common.common_func import read_local_file
from common.http_decorators import validate_params

from http_helper import *
from convert_time import *
logger = logging.getLogger(settings.PROJECT_NAME)
CONFIG = 1
CONFIG_TYPE = 2

login_url='/login/'

#条件search
def filter(request,message_list):
    message_total_count = message_list.count()
    message_filter_count = message_total_count

    draw = request.POST.get('draw')
    start = request.POST.get('start')
    length = request.POST.get('length')
    page = int(start)/int(length)+1

    #生成一个piginator分页使用
    paginator = Paginator(message_list, int(length))
    return paginator,page,draw,message_total_count,message_filter_count


@login_required(login_url = login_url)
def config(request):
    if not is_admin(request.user):
        return render(request,'perm_feedback.html',
                {'msg':'您没有此权限！'})

    value_type_choices = ''
    choices = Config.type_choices
    for type in choices:
        value_type_choices += type[1]+','
    value_type_choices = value_type_choices[0:len(value_type_choices)-1]

    data = []
    config_types = ConfigType.objects.all()
    for config_type in config_types:
        id = config_type.id
        name = config_type.name
        config_data = {}
        config_data["id"] = id
        config_data["name"] = name
        data.append(config_data)

    config_type_choices = json.dumps(data)
    
    return render(request,'config_manage.html',{
            'value_type_choices':value_type_choices,
            'config_type_choices':config_type_choices
            })


@login_required(login_url = login_url)
def config_type(request):
    if(is_admin(request.user)):
        return render(request,'config_type_manage.html')
    else:
        return render(request,'perm_feedback.html',
                {'msg':'您没有此权限！'})


def create_config_unique(key):
    try:
        configs = Config.objects.filter(key=key)
        if configs:
            return {'status':1,'msg':'配置键值：%s 已存在！' % key}
    except Exception, ex:
        logger.error('create config fail: <%s>' % str(ex))
        raise ex

@login_required(login_url = login_url)
def create_config(request):
    if request.method == 'POST' and request.is_ajax():
        if not is_admin(request.user):
            return JsonHttpResponse(
                {'status':1,'msg':'无此权限'})
        key = request.POST.get('key')
        config_type = request.POST.get('config_type')
        value_type = request.POST.get('value_type')
        value = request.POST.get('value')
        desc = request.POST.get('desc')
    try:
        result = create_config_unique(key)
        if result:
            return JsonHttpResponse(result)
        config_type = ConfigType.objects.get(id = config_type)
        config = Config.objects.create(key=key,value=value,\
                config_type=config_type,value_type=value_type,\
                description=desc)
    except Exception, ex:
        logger.error('create config fail: <%s>' % str(ex))
        return JsonHttpResponse(
            {'status':1,'msg':str(ex)})
    return JsonHttpResponse(
            {'status':0,'msg':'创建成功！'})


def create_type_unique(type_name):
    try:
        config_type = ConfigType.objects.filter(name=type_name)
        if config_type:
            return {'status':1,'msg':'配置类型名称：%s 已存在！' % type_name}
    except Exception, ex:
        logger.error('create config_type fail: <%s>' % str(ex))
        raise ex
        

@login_required(login_url = login_url)
def create_config_type(request):
    if request.method == 'POST' and request.is_ajax():
        type_name = request.POST.get('name')
        try:
            result = create_type_unique(type_name)
            if result:
                return JsonHttpResponse(result)
            config_type = ConfigType.objects.create(name=type_name)
        except Exception, ex:
            logger.error('create config_type fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':str(ex)})

        return JsonHttpResponse(
                {'status':0,'msg':'创建成功！'})


@login_required(login_url = login_url)
def delete_config(request):
    if request.method == 'POST' and request.is_ajax():
        if not is_admin(request.user):
            return JsonHttpResponse(
                {'status':1,'msg':'无此权限'})
        id = request.POST.get('id')
        type = request.POST.get('type')
        try:
            if CONFIG == int(type):
                config = Config.objects.get(id = int(id))
            else:
                config = ConfigType.objects.get(id = int(id))
                configs = Config.objects.list(id)
                if configs:
                    return JsonHttpResponse(
                            {'status':1,'msg':\
                            '删除失败！仍存在此类型的配置！'})

            config.delete()
        except Exception, ex:
            logger.error('delete fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'删除成功！'})


def update_type_unique(config_type,type_name):
    try:
        config_types = ConfigType.objects.filter(name=type_name)
        if config_types:
            if not config_type in config_types:
                return {'status':1,'msg':'配置类型名称：%s 已存在！' % type_name}
    except Exception, ex:
        logger.error('update config_type fail: <%s>' % str(ex))
        raise ex

@login_required(login_url = login_url)
def update_config_type(request):
    if request.method == 'POST' and request.is_ajax():
        if not is_admin(request.user):
            return JsonHttpResponse(
                {'status':1,'msg':'无此权限'})
        id = request.POST.get('id')
        name = request.POST.get('name')
        try:
            config_type = ConfigType.objects.get(id = int(id))
            result = update_type_unique(config_type,name)
            if result:
                return JsonHttpResponse(result)
            config_type.name = name
            config_type.save()
        except Exception, ex:
            logger.error('update config_type fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'修改成功！'})


def update_config_unique(config,key):
    try:
        configs = Config.objects.filter(key=key)
        if configs:
            if not config in configs:
                return {'status':1,'msg':'配置键值：%s 已存在！' % key}
    except Exception, ex:
        logger.error('update config fail: <%s>' % str(ex))
        raise ex


@login_required(login_url = login_url)
def update_config(request):
    if request.method == 'POST' and request.is_ajax():
        if not is_admin(request.user):
            return JsonHttpResponse(
                {'status':1,'msg':'无此权限'})
            
        id = request.POST.get('id')
        key = request.POST.get('key')
        config_type = request.POST.get('config_type')
        value_type = request.POST.get('value_type')
        value = request.POST.get('value')
        desc = request.POST.get('desc')

        try:
            config = Config.objects.get(id = id)
            result = update_config_unique(config,key)
            if result:
                return JsonHttpResponse(result)
                
            config_type = ConfigType.objects.get(id = config_type)
            config.key = key
            config.value = value
            config.config_type = config_type
            config.value_type = value_type
            config.description = desc
            config.save()
        except Exception, ex:
            logger.error('update config fail: <%s>' % str(ex))
            return JsonHttpResponse(
                {'status':1,'msg':'error:' + str(ex)})
        return JsonHttpResponse(
                {'status':0,'msg':'修改成功！'})


def config_list(request,data_id):
    if data_id == str(CONFIG):
        config_list = Config.objects.order_by('-update_time')
        config_list = config_filter_list(config_list,request.POST)
    else:
        config_list = ConfigType.objects.order_by('-update_time')
        config_list = config_type_filter_list(config_list,request.POST)

    #经过筛选之后的paginator
    paginator,page,draw,config_total_count,config_filter_count = \
        filter(request,config_list)

    try:
        configs = paginator.page(page)
    except PageNotAnInteger:
        configs = paginator.page(1)
    except EmptyPage:
        configs = paginator.page(paginator.num_pages)

    json_str = serializers.serialize('json',configs.object_list)
    result = json.loads(json_str)
    
    if data_id == str(CONFIG):
        result = custom_config_table(result,int(draw),config_total_count,\
                config_filter_count)
    else:
        result = custom_config_type_table(result,int(draw),config_total_count,\
                config_filter_count)

    return HttpResponse(json.dumps(result), content_type='application/json')


@login_required(login_url = login_url)
def upload_file(request, project = 'ark_common'):
    if not request.FILES['file']:
        return JsonHttpResponse({'status': 1, 'msg': 'file不能为空'})

    import tempfile
    from common.models import handle_uploaded_file
    local_file = tempfile.NamedTemporaryFile()
    handle_uploaded_file(request.FILES['file'], local_file.name)
    from common.cdn_file import Cdn
    try:
        cdn_url = Cdn.upload(
            local_file.name, project = project)

        content = ''
        to_large = False
        # 是否返回内容
        if request.POST['return_file_content']:
            try:
                content = read_local_file(local_file.name)
            except Exception, ex:
                if '文件大小超过' in str(ex):
                    to_large = True
                    content = str(ex)
                    
        return JsonHttpResponse(
            {'status': 0, 'cdn_url': cdn_url, 
             'content': content, 'to_large': to_large})
    except Exception, ex:
        logger.error('upload cdn file fail, %s' % traceback.format_exc())
        return JsonHttpResponse({'status': 1, 'msg': '上传文件失败'})


@login_required(login_url = login_url)
@validate_params(check_params = ['file_path'])
def preview_pangu_file(request):
    from common.pangu import Pangu
    file_path = request.POST.get('file_path')
    try:
        data = Pangu.preview(file_path)
        return JsonHttpResponse({'status': 0, 'data': data})
    except Exception, ex:
        logger.error('preview pangu file fail, %s' % traceback.format_exc())
        return JsonHttpResponse({'status': 1, 'msg': str(ex)})


def get_download_response(filename, content):
    response = HttpResponse(content_type='application/force-download')
    response = StreamingHttpResponse(content)
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Disposition'] = 'attachment;filename="%s"' % filename
    return response

