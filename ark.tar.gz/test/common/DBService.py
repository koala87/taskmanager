﻿###############################################################################
# coding: utf-8
#
# Copyright (c) 2017 alibaba-inc.com, Inc. All Rights Reserved
#
###############################################################################
"""
相关db操作

Authors: huaifeng.hhf(huaifeng.hhf@alibaba-inc.com)
"""

import os
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import exceptions
import time
import traceback
import logging

import django.db
import django.db.models
import django.core.exceptions
import django.contrib.auth.models


class DBService(object):
    def __init__(self, logger, logger_flag=False):
        self.__log = logger
        self.logger_flag = logger_flag
        pass


    def get_query_result(self, sql, options=None):
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()

            if self.logger_flag:
                self.__log.info("run_sql success, sql:[%s]" % sql)

            return rows
        except exceptions.Exception as ex:
            if self.logger_flag:
                self.__log.error("run_sql failed![%s][%s]" % (
                    str(ex), traceback.format_exc()))
            return None

    def get_query_result_dict(self, sql, options=None):
        "Return all rows from a cursor as a dict"
        try:
            cursor = django.db.connection.cursor()
            cursor.execute(sql)
            columns = [col[0].replace("`", "") for col in cursor.description]
            rows = [
                dict(zip(columns, row))
                for row in cursor.fetchall()
            ]

            if self.logger_flag:
                self.__log.info("run_sql success, sql:[%s]" % sql)

            return rows
        except exceptions.Exception as ex:
            if self.logger_flag:
                self.__log.error("run_sql failed![%s][%s]" % (
                    str(ex), traceback.format_exc()))
            return None



    def get_query_count(self, sql, options=None):
        count = 0
        rows = self.get_query_result(sql, options)
        if rows is not None :
            if len(rows) > 0 and rows[0][0] is not None:
                count = int(rows[0][0])

        return count
