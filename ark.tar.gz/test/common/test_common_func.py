#coding:utf8
import os
import shutil
import commands
import datetime
from django.test import TestCase
from common_func import convert_time_interval

# Create your tests here.
class CommnTest(TestCase):

    def setUp(self):
        pass

    def test_convert_time_interval(self):
        delta = datetime.timedelta(minutes = 2, seconds = 2)
        self.assertEqual('2分2秒', convert_time_interval(delta))
