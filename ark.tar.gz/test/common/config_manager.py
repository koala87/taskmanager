import logging
import traceback
from django.db import models
from django.conf import settings

logger = logging.getLogger(settings.PROJECT_NAME)

class ConfigManager(models.Manager):

    def get_value(self, key):
        config = self.get(key = key)
        return config.value.strip()

    def set_value(self, key, value):
        return self.select_for_update().filter(key = key)\
            .update(value = value.strip())

    def list(self, config_type_id):
        return self.filter(config_type_id = config_type_id)

    def get_config_value(self, key, default = ''):
        value = None
        try:
            value = self.get_value(key)
        except Exception, ex:
            logger.error('get config: %s fail, msg: %s' \
                             % (key, traceback.format_exc()))
        if value is None:
            value = default
        return value

