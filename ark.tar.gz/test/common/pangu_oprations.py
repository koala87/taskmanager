import os
import commands

def rm_tmp_dir(dir):
    status, output = commands.getstatusoutput(
        '/apsara/deploy/pu rmdir -f %s' % dir)

def mk_tmp_dir(dir):
    rm_tmp_dir(dir)
    status, output = commands.getstatusoutput(
        '/apsara/deploy/pu mkdir %s' % dir)

def rm_tmp_file(path):
    status, output = commands.getstatusoutput(
        '/apsara/deploy/pu rm -f %s' % path)

def mk_tmp_file(path):
    rm_tmp_file(path)
    status, output = commands.getstatusoutput('echo "xxx\nyyy" > ljf_test')
    status, output = commands.getstatusoutput(
        '/apsara/deploy/pu cp ljf_test %s' % path)
    os.remove('ljf_test')

