#coding:utf8
import os
import time
import hashlib
import commands
import logging
import json
import exceptions
import traceback
import urllib2

from django.conf import settings
SIZE_NOT_FOUND = -1
logger = logging.getLogger('common')

class CmdErrLog():
    MAX_LINE = 1000

    @staticmethod
    def get_log_file(cmd):
        time_str = time.strftime('%Y%m%d%H%M%S', time.localtime())
        return '%s/err_%s_%s' % (
            settings.PROJECT_LOG_ROOT,
            time_str,
            hashlib.md5(cmd).hexdigest())

    @staticmethod
    def read_log(path, line_num = MAX_LINE):
        log = ''
        f = None
        try:
            f = open(path)
            lines = f.readlines(line_num)
            log = '\n'.join(lines)
        except IOError:
            logger.error('error log not found: <%s>' % path)
        finally:
            if f:
                f.close()
        return log

    @staticmethod
    def rm_log_file(path):
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception, ex:
                logger.error('remove log file:<s> fail, msg:<%s>' 
                             % (path, str(ex)))

class Odps():
    ODPS_CMD_PATH = '/home/admin/odps/bin/odpscmd'
    JAVA_BIN_PATH = '/usr/ali/bin/java'

    client = settings.PROJECT_ROOT + '/common/lib/odps-0.1.0-SNAPSHOT.jar'
    tool_client = settings.PROJECT_ROOT + '/common/lib/odps_tools.jar'

    # project.object --> project, object
    @staticmethod
    def parse_name(name):
        items = name.split('.', 1)
        if len(items) == 2:
            return items
        else:
            return '', name

    @staticmethod
    def req_odps_http_server(req_url):
        # 编码， 用于发送请求
        url_stream = "FAIL"
        try:
            url_stream = urllib2.urlopen(req_url).read()
        except exceptions.Exception as ex:
            url_stream = str(ex)
            
        return url_stream

    #table: table_name or project.table_name
    @staticmethod
    def list(project):
        cmd = '%s -jar %s prj -l %s' % \
            (Odps.JAVA_BIN_PATH, Odps.client, project)

        result = Odps.exec_cmd(cmd, 'list project tables')
        return result.get('result', '').split(';')


    #table: table_name or project.table_name
    @staticmethod
    def schema(table, project = None, odps_id=None, odps_key=None):
        if project is not None and odps_id is not None and odps_key is not None:
            req_url = ("http://10.181.204.100:8088/message_sender/odps/table_schema.do?"
                       "access_id=%s&access_key=%s&table_name=%s.%s" %(
                       odps_id, odps_key, project, table))
            logger.error(req_url)
            result = Odps.req_odps_http_server(req_url)
            res_map = json.loads(result)
            return res_map.get('result', {})

        cmd = '%s -jar %s table --schema %s' % \
            (Odps.JAVA_BIN_PATH, Odps.client, table)

        result = Odps.exec_cmd(cmd, 'get schema')
        schema = json.loads(result.get('result', '{}'))
        return schema


    #table: table_name or project.table_name
    @staticmethod
    def meta(table, project = None, odps_id=None, odps_key=None):
        if project is not None and odps_id is not None and odps_key is not None:
            req_url = ("http://10.181.204.100:8088/message_sender/odps/table_meta.do?"
                       "access_id=%s&access_key=%s&table_name=%s.%s" %(
                       odps_id, odps_key, project, table))
            result = Odps.req_odps_http_server(req_url)
            res_map = json.loads(result)
            return res_map.get('result', {})

        cmd = '%s -jar %s table -m %s' % \
            (Odps.JAVA_BIN_PATH, Odps.client, table)

        result = Odps.exec_cmd(cmd, 'get meta')
        result = json.loads(result.get('result', '{}'))
        return result


    #table: table_name or project.table_name
    @staticmethod
    def size(table, partition = None, project = None, odps_id=None, odps_key=None):
        if project is not None and odps_id is not None and odps_key is not None:
            if partition is not None:
                table = "%s.%s:%s" % (project, table, partition)
            else:
                table = "%s.%s" % (project, table)

            req_url = ("http://10.181.204.100:8088/message_sender/odps/table_size.do?"
                       "access_id=%s&access_key=%s&table_name=%s" %(
                       odps_id, odps_key, table))
            result = Odps.req_odps_http_server(req_url)
            res_map = json.loads(result)
            return res_map.get('result', '{}')

        if project is not None and project != 'aliyun_searchlog':
            table = '%s.%s' % (project, table)
        cmd = '%s -jar %s table -s %s' % \
            (Odps.JAVA_BIN_PATH, Odps.client, table)
        if partition and isinstance(partition, basestring):
            cmd = '%s:%s' % (cmd, partition)

        result = Odps.exec_cmd(cmd, 'get size')
        return int(result.get('size', SIZE_NOT_FOUND))


    #table: table_name or project.table_name
    @staticmethod
    def count(table, partition = None, project = None, odps_id=None, odps_key=None):
        if project is not None and odps_id is not None and odps_key is not None:
            if partition is not None:
                table = "%s.%s:%s" % (project, table, partition)
            else:
                table = "%s.%s" % (project, table)

            req_url = ("http://10.181.204.100:8088/message_sender/odps/table_count.do?"
                       "access_id=%s&access_key=%s&table_name=%s" %(
                       odps_id, odps_key, table))
            result = Odps.req_odps_http_server(req_url)
            res_map = json.loads(result)
            return res_map.get('result', '{}')

        cmd = '%s -jar %s table -c %s' % \
            (Odps.JAVA_BIN_PATH, Odps.client, table)
        if partition and isinstance(partition, basestring):
            cmd = '%s:%s' % (cmd, partition)

        result = Odps.exec_cmd(cmd, 'get count')
        return int(result.get('count', 0))


    #table: table_name or project.table_name
    @staticmethod
    def partitions(table, detail = False, num = 1, project = None, odps_id=None, odps_key=None):
        if project is not None and odps_id is not None and odps_key is not None:
            table = "%s.%s" % (project, table)
            req_url = ("http://10.181.204.100:8088/message_sender/odps/partition_list.do?"
                       "access_id=%s&access_key=%s&table_name=%s&max=%s" %(
                       odps_id, odps_key, table, num))
            print req_url
            result = Odps.req_odps_http_server(req_url)
            res_map = json.loads(result)
            partitions = res_map.get('result', [])
            if not detail:
                partitions = [x['name'] for x in partitions]
            return partitions

        cmd = '%s -jar %s table -l %s -c %d' % \
            (Odps.JAVA_BIN_PATH, Odps.client, table, num)
        result = Odps.exec_cmd(cmd, 'get partitions')
        partitions = json.loads(result.get('result', '[]'))
        if not detail:
            partitions = [x['name'] for x in partitions]
        return partitions


    #table: table_name or project.table_name
    @staticmethod
    def delete(odps_id, odps_key, project, table, partition = None):
        if partition is not None:
            table = "%s.%s:%s" % (project, table, partition)
        else:
            table = "%s.%s" % (project, table)

        req_url = ("http://10.181.204.100:8088/message_sender/odps/table_delete.do?"
                   "access_id=%s&access_key=%s&table_name=%s" %(
                odps_id, odps_key, table))
        result = Odps.req_odps_http_server(req_url)
        res_map = json.loads(result)
        print res_map
        return res_map.get('result', '{}')


    @staticmethod
    def exec_cmd(cmd, cmd_type, json_result = True, ok_msg = None):
        
        err_file = CmdErrLog.get_log_file(cmd)
        cmd = '%s 2>%s' % (cmd, err_file)

        logger.info('executing cmd:<%s>' % cmd)
        status, output = commands.getstatusoutput(cmd)
        if status != 0:
            err_log = CmdErrLog.read_log(err_file).strip()
            CmdErrLog.rm_log_file(err_file)
            if not ok_msg or ok_msg not in err_log:
                logger.error('<%s> fail: <%s>, msg: <%s>' 
                             % (cmd_type, cmd, err_log))
                raise Exception(err_log)

        CmdErrLog.rm_log_file(err_file)
        try:
            if json_result:
                result = json.loads(output)
            else:
                result = output
        except Exception as msg:
            ret_msg = 'invalid json result: <%s>, msg: <%s>' % (output, msg)
            logger.error(ret_msg)
            raise Exception(ret_msg)
        
        if json_result and 0 != int(result.get('code', 1)):
            logger.error('cmd:<%s>, output:<%s>' % (cmd, output))
            raise Exception(result.get('msg', 'msg key not found'))

        return result


    @staticmethod
    def get_life_cycle(table, project=None, odps_id=None, odps_key=None):
        life_cycle = -1
        try:
            meta = Odps.meta(table, project, odps_id, odps_key)
            life_cycle = int(meta.get('lifecycle', -1))
        except Exception, ex:
            logger.error('get life_cycle fail:<%s>' % str(ex))
            life_cycle = 'get table life_cycle fail'
        return life_cycle

    @staticmethod
    def update_column_desc(project, table, column, desc, access_id, access_key):
        from common.lib.pyodps_wrapper import endpoint
        from common.lib.pyodps_wrapper import ODPS
        o = ODPS(access_id, access_key, 
                 project = project, endpoint = endpoint) 
        odps_sql = "alter table %s.%s change column %s comment '%s'"%\
                    (project, table, column, desc)

        try:
            o.execute_sql(odps_sql)
        except Exception, ex:
            if "You have NO privilege 'odps:Alter' on" in str(ex):
                raise Exception('无此权限')
            raise ex


    #table: table_name or project.table_name
    @staticmethod
    def change_life_cycle(project, table, life_cycle, access_id, access_key):
        from common.lib.pyodps_wrapper import endpoint
        from common.lib.pyodps_wrapper import ODPS
        o = ODPS(access_id, access_key, 
                 project = project, endpoint = endpoint) 
        odps_sql = 'alter table %s set lifecycle %d' % (table, life_cycle)

        try:
            o.execute_sql(odps_sql)
        except Exception, ex:
            if "You have NO privilege 'odps:Alter' on" in str(ex):
                raise Exception('无此权限')
            raise ex


    @staticmethod
    def exec_odps_sql(access_id, access_key, project, sql_name, sql, ok_msg = None):
        cmd = '%s -u %s -p %s --project=%s -M -e "%s"' % \
            (Odps.ODPS_CMD_PATH, access_id, access_key, project, sql)
        try:
            return Odps.exec_cmd(cmd, sql_name, json_result = False, ok_msg = ok_msg)
        except Exception, ex:

            logger.error('%s fail, msg:<%s>' % (sql_name, str(ex)))
            raise ex


class OdpsPrivilege(Odps):
    DEF_PROJECT_PRIVILEGE = 'List, CreateInstance, CreateFunction, '\
        'CreateResource, CreateTable'
    DEF_TABLE_PRIVILEGE = 'Describe, Select'
    ACCOUNT_PREFIX = 'ALIYUN$'
    CMD_ACCOUNT_PREFIX = 'ALIYUN\\$'

    def __init__(self, project, access_id, access_key):
        self.project = project
        self.access_id = access_id
        self.access_key = access_key
    
    @staticmethod
    def get_aliyun_account(account, escape_dolar = True):
        account = account.strip()
        if not account.startswith(OdpsPrivilege.ACCOUNT_PREFIX):
            account = OdpsPrivilege.ACCOUNT_PREFIX + account
        if escape_dolar:
            account = account.replace('$', '\\$')
        return account


    @staticmethod
    def add_user(project, account, access_id, access_key):
        if not account.startswith(OdpsPrivilege.ACCOUNT_PREFIX):
            account = OdpsPrivilege.ACCOUNT_PREFIX + account
        sql = 'add user %s' % account
        Odps.exec_odps_sql(access_id, access_key, project, 'add_user', sql)

    @staticmethod
    def grant_project(project, account, access_id, access_key):
        account = OdpsPrivilege.get_aliyun_account(account)
        try:
            OdpsPrivilege.add_user(project, account, access_id, access_key)
        except Exception, ex:
            logger.error('add project user fail:<%s>' % str(ex))

        sql = 'grant %s on project %s to user %s' \
            % (OdpsPrivilege.DEF_PROJECT_PRIVILEGE, project, account)
        Odps.exec_odps_sql(access_id, access_key, project, 'grant_project', sql)

    @staticmethod
    def revoke_project(project, account, access_id, access_key):
        account = OdpsPrivilege.get_aliyun_account(account)
        sql = 'revoke %s on project %s from user %s' \
            % (OdpsPrivilege.DEF_PROJECT_PRIVILEGE, project, account)
        Odps.exec_odps_sql(access_id, access_key, project, 'revoke_project', sql)


    @staticmethod
    def grant_label(project, table, account, access_id, access_key, label = 3):
        account = OdpsPrivilege.get_aliyun_account(account)
        def_exp_day = 365*10
        sql = "grant label %d on table %s to user %s with exp %d;" % (label, table, account, def_exp_day)
        Odps.exec_odps_sql(
            access_id, access_key, project, 
            'grant_label_to_user', sql)        


    @staticmethod
    def grant_table(project, table, account, access_id, access_key):
        account = OdpsPrivilege.get_aliyun_account(account)
        sql = 'use %s; grant %s on table %s to user %s' \
            % (project, OdpsPrivilege.DEF_TABLE_PRIVILEGE, table, account)
        Odps.exec_odps_sql(access_id, access_key, project, 'grant_table', sql)

    @staticmethod
    def revoke_table(project, table, account, access_id, access_key):
        account = OdpsPrivilege.get_aliyun_account(account)
        sql = 'use %s; revoke %s on table %s from user %s' \
            % (project, OdpsPrivilege.DEF_TABLE_PRIVILEGE, table, account)
        Odps.exec_odps_sql(access_id, access_key, project, 'revoke_table', sql)


    # grant privileges on project or table to account using access_id/access_key
    @staticmethod
    def grant(project, table, account, access_id, access_key):
        assert project
        try:
            OdpsPrivilege.grant_project(project, account, access_id, access_key)
            if table:
                OdpsPrivilege.grant_table(
                    project, table, account, access_id, access_key)
        except Exception, ex:
            logger.error('grant project privilege fail, msg:<%s>' % str(ex))
            raise Exception('授权失败: %s' % (str(ex)))

    # 跨project通过package授权
    @staticmethod
    def allow_and_install_package(
        from_project, from_access_id, from_access_key,
        to_project, to_access_id, to_access_key, package):

        OdpsPackage(from_project, from_access_id, from_access_key)\
            .allow_install(to_project, package)

        OdpsPackage(to_project,to_access_id, to_access_key)\
            .install('%s.%s' % (from_project, package))

    # revoke privileges on project or table from account using access_id/access_key
    @staticmethod
    def revoke(project, table, account, access_id, access_key):
        assert project
        assert table

        try:
            OdpsPrivilege.revoke_table(
                project, table, account, access_id, access_key)
        except Exception, ex:
            logger.error('grant project privilege fail, msg:<%s>' % str(ex))
            raise Exception('回收权限失败: %s' % str(ex))

    @staticmethod
    def whoami(project, access_id, access_key):
        result = Odps.exec_odps_sql(
            access_id, access_key, project,
            'whoami', 'whoami')
        prefix = 'Name:'
        items = result.split('\n')
        account = ''
        for item in items:
            if item.startswith(prefix):
                account = item[len(prefix):].strip()
        return account

    @staticmethod
    def show_grants(
        project, user_account, access_id, access_key):

        from common.lib.pyodps_wrapper import endpoint
        from common.lib.pyodps_wrapper import ODPS
        user_account = OdpsPrivilege.get_aliyun_account(
            user_account, escape_dolar = False)
        o = ODPS(access_id, access_key, 
                 project = project, endpoint = endpoint) 
        query = "show grants for %s" % user_account

        grants = None
        try:
            grants = o.run_security_query(query)
        except Exception, ex:
            raise ex
        return grants

    @staticmethod
    def is_project_owner(
        project, user_account, access_id, access_key):

        grants = OdpsPrivilege.show_grants(
            project, user_account, access_id, access_key)
        return 'ProjectOwner' in grants


    @staticmethod
    def is_project_admin(
        project, user_account, access_id, access_key):

        grants = OdpsPrivilege.show_grants(
            project, user_account, access_id, access_key)
        return 'admin' in grants['Roles']

    @staticmethod
    def is_project_owner_or_admin(
        project, user_account, access_id, access_key):

        grants = OdpsPrivilege.show_grants(
            project, user_account, access_id, access_key)
        return 'ProjectOwner' in grants or 'admin' in grants['Roles']

class OdpsPackage(OdpsPrivilege):

    def exists(self, name):
        sql = 'desc package %s' % name
        try:
            result = Odps.exec_odps_sql(
                self.access_id, self.access_key, self.project,
                'package_exists', sql)
            return True
        except Exception, ex:
            return False

    def desc(self, name):
        sql = 'desc package %s' % name
        try:
            result = Odps.exec_odps_sql(
                self.access_id, self.access_key, self.project,
                'package_desc', sql)
            return result
        except Exception, ex:
            return ''

    # 是否有table存在
    def no_tables(self, name):
        table_exists = False
        desc = self.desc(name)
        items = desc.split('Object List', 1)
        if len(items) == 2:
            items = items[1].split('Allowed Project List', 1)
            if len(items) == 2:
                table_exists = 'TABLE' in items[0]

        return not table_exists

    def allow_install(self, to_project, package, with_label = 3):
        project, package = Odps.parse_name(package)
        sql = 'allow project %s to install package %s using label %d' \
            % (to_project, package, with_label)
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'allow_install_package', sql,
            ok_msg = 'already exist for the update operation')

    def grant_read(self, package, user_account):
        user_account = OdpsPrivilege.get_aliyun_account(user_account)

        sql = "grant read on package %s to user %s;" \
            % (package, user_account)
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'grant_package_read', sql)

    def grant_read_to_role(self, package, role):
        sql = "grant read on package %s to role %s;" \
            % (package, role)
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'grant_package_read_to_role', sql)

    def install(self, package):
        sql = "install package %s" % package
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'install_package', sql, 
            ok_msg = 'already exist for the update operation')

    def uninstall(self, package):
        sql = "uninstall package %s" % package
        ok_msg = 'FAILED: The package %s is not installed.' % package
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'uninstall_package', sql, ok_msg = ok_msg)

    # 收回package权限
    def revoke_read(self, package, user_account):
        user_account = OdpsPrivilege.get_aliyun_account(user_account)
        sql = "revoke read on package %s from user %s;" \
            % (package, user_account)
        ok_msg = 'FAILED: The package %s is not installed.' % package
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'revoke_package_read', sql, ok_msg = ok_msg)

    # 收回package权限
    def revoke_read_from_role(self, package, role):
        sql = "revoke read on package %s from role %s;" \
            % (package, role)
        ok_msg = 'FAILED: The package %s is not installed.' % package
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'revoke_package_read_from_role', sql, ok_msg = ok_msg)

    def create(self, name):
        project, name = Odps.parse_name(name)
        if not self.exists(name):
            sql = 'create package %s' % name
            Odps.exec_odps_sql(
                self.access_id, self.access_key, self.project, 
                'create_package', sql)

    def drop(self, name):
        project, name = Odps.parse_name(name)
        if self.exists(name):
            sql = 'drop package %s' % name
            Odps.exec_odps_sql(
                self.access_id, self.access_key, self.project, 
                'drop_package', sql)

    def drop_if_no_tables(self, name):
        if self.no_tables(name):
            self.drop(name)

    def add_table(self, package_name, table):
        project, package_name = Odps.parse_name(package_name)
        sql = 'add table %s to package %s' % (table, package_name)
        exists_msg = 'FAILED: TABLE %s already exists in the package resource list.' \
            % table
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'add_table_to_package', sql, ok_msg = exists_msg)

    def add_tables(self, package_name, tables):
        for table in tables:
            self.add_table(package_name, table)

    def remove_table(self, package_name, table):
        project, package_name = Odps.parse_name(package_name)
        sql = 'remove table %s from package %s' % (table, package_name)
        exists_msg = 'FAILED: TABLE %s does not exist in the package resource list.' \
            % table
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'remove_table_from_package', sql, ok_msg = exists_msg)

    def remove_tables(self, package_name, tables):
        for table in tables:
            self.remove_table(package_name, table)


class OdpsRole(OdpsPrivilege):
    def create(self, name):
        sql = 'create role %s' % name
        exists_msg = "FAILED: the role '%s' already exists" % name
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'create_role', sql, ok_msg = exists_msg)

    def drop(self, name, force = False):
        project, name = Odps.parse_name(name)
        if force:
            users = self.users(name)
            for user in users:
                self.revoke(name, user)

        sql = 'drop role %s' % name
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'drop_role', sql)

    def drop_if_empty(self, name, force = False):
        if self.no_tables(name) and (self.no_users(name) or force):
            self.drop(name, force)

    def grant(self, name, user_account):
        user_account = OdpsPrivilege.get_aliyun_account(user_account)
        sql = "grant %s to %s;" % (name, user_account)
        ok_msg = 'FAILED: User already have the Role:%s.' % name
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'grant_role_to_user', sql, ok_msg = ok_msg)

    def grant_batch(self, name, user_accounts):
        for user_account in user_accounts:
            self.grant(name, user_account)

    def revoke(self, name, user_account):
        user_account = OdpsPrivilege.get_aliyun_account(user_account)
        sql = "revoke %s from %s;" % (name, user_account)
        ok_msg = 'FAILED: User do not have the Role:%s.' % name
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'revoke_role_from_user', sql, ok_msg = ok_msg)

    def revoke_batch(self, name, user_accounts):
        for user_account in user_accounts:
            self.revoke(name, user_account)

    def exists(self, name):
        sql = 'desc role %s' % name
        try:
            result = Odps.exec_odps_sql(
                self.access_id, self.access_key, self.project,
                'role_exists', sql)
            return True
        except Exception, ex:
            return False

    def add_table(self, name, table):
        sql = "grant %s on table %s to role %s;" \
            % (self.DEF_TABLE_PRIVILEGE, table, name)
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'grant_table_to_role', sql)

    def add_tables(self, name, tables):
        for table in tables:
            self.add_table(name, table)

    def remove_table(self, name, table):
        sql = "revoke %s on table %s from role %s;" \
            % (self.DEF_TABLE_PRIVILEGE, table, name)
        Odps.exec_odps_sql(
            self.access_id, self.access_key, self.project, 
            'revoke_table_from_role', sql)

    def remove_tables(self, name, tables):
        for table in tables:
            self.remove_table(name, table)

    def desc(self, name):
        sql = 'desc role %s' % name
        try:
            result = Odps.exec_odps_sql(
                self.access_id, self.access_key, self.project,
                'role_desc', sql)
            return result
        except Exception, ex:
            return ''

    # 有该角色的用户
    def users(self, name):
        users = []
        desc = self.desc(name)
        items = desc.split('[users]', 1)
        if len(items) == 2:
            users_part = items[1]
            items = items[1].split('Authorization Type: ACL', 1)
            if len(items) == 2:
                users_part = items[0]
            users = users_part.strip().split(',')
            users = map(lambda x: x.strip(), users)
        return users

    # 是否有用户有该角色
    def no_users(self, name):
        users = self.users(name)
        return len(users) == 0

    # 角色有权限的table
    def tables(self, name):
        tables = []
        desc = self.desc(name)
        items = desc.split('Authorization Type: ACL', 1)
        if len(items) == 2:
            tables = items[1].strip().split('\n')
        return tables

    # 该角色是否有table权限
    def no_tables(self, name):
        tables = self.tables(name)
        return len(tables) == 0

